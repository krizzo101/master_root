"""Tests for Claude Code Clone configuration."""

import pytest
from claude_code.config import ClaudeCodeConfig


def test_default_config():
    """Test default configuration values."""
    config = ClaudeCodeConfig()

    assert config.provider == "openai"
    assert config.model == "gpt-5-mini"
    assert config.working_directory == "."
    assert config.max_tokens == 4000
    assert config.temperature == 0.1
    assert config.enable_file_operations is True
    assert config.enable_streaming is True


def test_config_with_values():
    """Test configuration with custom values."""
    config = ClaudeCodeConfig(
        provider="anthropic",
        model="claude-3-opus",
        api_key="test_key",
        max_tokens=8000,
        temperature=0.5,
    )

    assert config.provider == "anthropic"
    assert config.model == "claude-3-opus"
    assert config.api_key == "test_key"
    assert config.max_tokens == 8000
    assert config.temperature == 0.5


def test_allowed_file_extensions():
    """Test allowed file extensions configuration."""
    config = ClaudeCodeConfig()

    assert ".py" in config.allowed_file_extensions
    assert ".js" in config.allowed_file_extensions
    assert ".ts" in config.allowed_file_extensions
    assert ".java" in config.allowed_file_extensions
    assert ".cpp" in config.allowed_file_extensions
