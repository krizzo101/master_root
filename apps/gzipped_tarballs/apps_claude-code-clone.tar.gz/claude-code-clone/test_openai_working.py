"""
openai_health_check.py

Simple, production-ready function to test whether the OpenAI API is reachable and the provided API key works.

This file:
- Defines a PingResult dataclass describing the result.
- Provides test_openai_api() that queries the /v1/models endpoint.
- Handles common errors (missing key, network issues, invalid JSON).
- Includes an example usage block.

Dependencies:
- requests

Install dependency:
    pip install requests
"""

from dataclasses import dataclass
import os
from typing import Optional, Dict, Any
import requests


@dataclass
class PingResult:
    """Result returned by test_openai_api."""
    ok: bool
    status_code: Optional[int]
    message: str
    details: Optional[Dict[str, Any]] = None


def test_openai_api(
    api_key: Optional[str] = None,
    timeout: float = 10.0,
    base_url: str = "https://api.openai.com/v1/models",
) -> PingResult:
    """
    Test whether the OpenAI API is reachable and the provided API key is valid.

    The function sends a GET request to the models endpoint and returns a PingResult.

    Parameters:
    - api_key: Optional API key string. If None, will read OPENAI_API_KEY from environment.
    - timeout: Request timeout in seconds.
    - base_url: The OpenAI endpoint to call (defaults to /v1/models). Can be replaced for
      alternate endpoints or local testing proxies.

    Returns:
    - PingResult with fields:
        ok: True if API responded with HTTP 200.
        status_code: HTTP status code or None if request failed before getting a response.
        message: Human-readable message describing the outcome.
        details: Optional dictionary with limited response details (e.g., model count).
    """
    if api_key is None:
        api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        return PingResult(
            ok=False,
            status_code=None,
            message="No API key provided and OPENAI_API_KEY environment variable is not set.",
            details=None,
        )

    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        resp = requests.get(base_url, headers=headers, timeout=timeout)
    except requests.exceptions.Timeout:
        return PingResult(
            ok=False,
            status_code=None,
            message=f"Request timed out after {timeout} seconds.",
            details=None,
        )
    except requests.exceptions.ConnectionError as exc:
        return PingResult(
            ok=False,
            status_code=None,
            message=f"Connection error while attempting to contact OpenAI API: {exc}",
            details=None,
        )
    except requests.RequestException as exc:
        return PingResult(
            ok=False,
            status_code=None,
            message=f"Unexpected error while attempting request: {exc}",
            details=None,
        )

    # We have a response; interpret status codes and content
    status = resp.status_code
    if status == 200:
        # Try to parse JSON safely and include a small summary in details
        try:
            payload = resp.json()
            # Attempt to summarize models if present to avoid returning huge payloads
            models = payload.get("data")
            model_count = None
            sample_models = None
            if isinstance(models, list):
                model_count = len(models)
                # provide up to 5 model ids as a sample
                sample_models = [m.get("id") for m in models[:5] if isinstance(m, dict)]
            details = {"model_count": model_count, "sample_models": sample_models}
        except ValueError:
            # JSON decode error
            details = {"raw_text": resp.text[:1000]}  # truncated
        return PingResult(ok=True, status_code=200, message="OpenAI API reachable and responded successfully.", details=details)

    # Common error codes: 401 unauthorized, 429 rate limit, 5xx server errors
    msg = f"OpenAI API returned status code {status}."
    try:
        err_payload = resp.json()
        # Try to extract an error message from the payload if available
        if isinstance(err_payload, dict):
            # OpenAI error format is often {"error": {"message": "...", "type": ...}}
            err_obj = err_payload.get("error")
            if isinstance(err_obj, dict):
                err_msg = err_obj.get("message")
                if err_msg:
                    msg += f" Error message: {err_msg}"
            else:
                # fallback: include top-level keys
                msg += f" Response keys: {list(err_payload.keys())}"
        details = {"raw": err_payload}
    except ValueError:
        details = {"raw_text": resp.text[:1000]}  # truncated

    return PingResult(ok=False, status_code=status, message=msg, details=details)


if __name__ == "__main__":
    # Example usage:
    # 1) Set your API key in the environment: export OPENAI_API_KEY="sk-..."
    # 2) Run this script: python openai_health_check.py
    #
    # You can also pass an API key directly:
    #   result = test_openai_api(api_key="sk-...")
    #
    # This __main__ block performs a simple print of the result.
    import json
    result = test_openai_api()
    print("OpenAI API health check result:")
    # Use json.dumps to pretty-print dataclass as a dict
    print(json.dumps(result.__dict__, indent=2))