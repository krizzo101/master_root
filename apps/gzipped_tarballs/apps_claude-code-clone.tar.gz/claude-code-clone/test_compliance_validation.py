#!/usr/bin/env python3
"""Test OpenAI Compliance Layer for production readiness."""

import os
import sys
import json
import time
from typing import Dict, Any, List
from dataclasses import dataclass, asdict

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from claude_code.compliance.openai_compliance import (
    OpenAIComplianceLayer,
    ComplianceRequest,
    ComplianceResponse,
    ReasoningEffort,
    create_simple_request,
    create_reasoning_request,
    create_structured_request,
    OpenAIComplianceError
)

@dataclass
class TestResult:
    """Test result structure."""
    test_name: str
    passed: bool
    execution_time: float
    error_message: str = ""
    details: Dict[str, Any] = None

    def to_dict(self):
        return asdict(self)


class ComplianceValidator:
    """Validate OpenAI compliance layer."""
    
    def __init__(self):
        self.compliance = OpenAIComplianceLayer()
        self.results = []
    
    def run_test(self, test_name: str, test_func):
        """Run a single test with timing and error handling."""
        print(f"\n🔍 Testing: {test_name}")
        start_time = time.time()
        
        try:
            result = test_func()
            execution_time = time.time() - start_time
            
            test_result = TestResult(
                test_name=test_name,
                passed=result.get("passed", False),
                execution_time=execution_time,
                error_message=result.get("error", ""),
                details=result.get("details", {})
            )
            
            if test_result.passed:
                print(f"  ✅ PASSED ({execution_time:.3f}s)")
            else:
                print(f"  ❌ FAILED: {test_result.error_message}")
            
        except Exception as e:
            execution_time = time.time() - start_time
            test_result = TestResult(
                test_name=test_name,
                passed=False,
                execution_time=execution_time,
                error_message=str(e)
            )
            print(f"  ❌ EXCEPTION: {e}")
        
        self.results.append(test_result)
        return test_result
    
    def test_approved_models(self) -> Dict[str, Any]:
        """Test that only approved models are allowed."""
        # Test approved models
        approved_models = ["gpt-5-nano", "gpt-5-mini", "gpt-5", "o4-mini"]
        
        for model in approved_models:
            try:
                request = ComplianceRequest(
                    prompt="Test prompt",
                    max_tokens=100,
                    model_override=model
                )
                response = self.compliance.build_compliant_request(request)
                
                if response.model != model:
                    return {
                        "passed": False,
                        "error": f"Model {model} was not correctly set",
                        "details": {"expected": model, "got": response.model}
                    }
            except Exception as e:
                return {
                    "passed": False,
                    "error": f"Failed to use approved model {model}: {e}"
                }
        
        # Test forbidden models
        forbidden_models = ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo", "o3", "claude-3"]
        
        for model in forbidden_models:
            try:
                request = ComplianceRequest(
                    prompt="Test prompt",
                    max_tokens=100,
                    model_override=model
                )
                response = self.compliance.build_compliant_request(request)
                return {
                    "passed": False,
                    "error": f"Forbidden model {model} was allowed!",
                    "details": {"model": model, "response": response.model}
                }
            except OpenAIComplianceError:
                # Expected behavior - forbidden model rejected
                pass
            except Exception as e:
                return {
                    "passed": False,
                    "error": f"Unexpected error for forbidden model {model}: {e}"
                }
        
        return {
            "passed": True,
            "details": {
                "approved_models_tested": approved_models,
                "forbidden_models_tested": forbidden_models
            }
        }
    
    def test_reasoning_routing(self) -> Dict[str, Any]:
        """Test reasoning model routing."""
        # Test reasoning request routes to o4-mini
        request = create_reasoning_request(
            prompt="Solve this complex problem",
            effort=ReasoningEffort.HIGH
        )
        
        try:
            response = self.compliance.build_compliant_request(request)
            
            if response.model != "o4-mini":
                return {
                    "passed": False,
                    "error": f"Reasoning request not routed to o4-mini",
                    "details": {"expected": "o4-mini", "got": response.model}
                }
            
            if response.family.value != "o-series":
                return {
                    "passed": False,
                    "error": f"Reasoning request not marked as o-series family",
                    "details": {"family": response.family.value}
                }
            
            # Check reasoning effort in payload
            if "reasoning" not in response.request:
                return {
                    "passed": False,
                    "error": "Reasoning parameter missing from request"
                }
            
            return {
                "passed": True,
                "details": {
                    "model": response.model,
                    "family": response.family.value,
                    "reasoning_effort": response.request.get("reasoning", {}).get("effort")
                }
            }
            
        except Exception as e:
            return {
                "passed": False,
                "error": f"Failed to create reasoning request: {e}"
            }
    
    def test_structured_output_enforcement(self) -> Dict[str, Any]:
        """Test that structured output is enforced by default."""
        # Test default structured output
        request = create_simple_request("Generate text", max_tokens=100)
        
        try:
            response = self.compliance.build_compliant_request(request)
            
            if "response_format" not in response.request:
                return {
                    "passed": False,
                    "error": "Structured output not enforced by default"
                }
            
            # Test with custom schema
            custom_schema = {
                "name": "analysis",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string"},
                        "score": {"type": "number"}
                    },
                    "required": ["summary", "score"]
                }
            }
            
            request2 = create_structured_request(
                prompt="Analyze this",
                schema=custom_schema,
                max_tokens=200
            )
            
            response2 = self.compliance.build_compliant_request(request2)
            
            if response2.request.get("response_format", {}).get("json_schema") != custom_schema:
                return {
                    "passed": False,
                    "error": "Custom schema not correctly applied"
                }
            
            return {
                "passed": True,
                "details": {
                    "default_schema_applied": True,
                    "custom_schema_applied": True
                }
            }
            
        except Exception as e:
            return {
                "passed": False,
                "error": f"Failed structured output test: {e}"
            }
    
    def test_responses_api_format(self) -> Dict[str, Any]:
        """Test that requests use Responses API format."""
        request = ComplianceRequest(
            prompt="Test prompt",
            max_tokens=1000,
            model_override="gpt-5-mini"
        )
        
        try:
            response = self.compliance.build_compliant_request(request)
            
            # Check endpoint
            if response.endpoint != "/v1/responses":
                return {
                    "passed": False,
                    "error": f"Wrong endpoint: {response.endpoint}",
                    "details": {"expected": "/v1/responses", "got": response.endpoint}
                }
            
            # Check required fields for Responses API
            required_fields = ["model", "input", "max_output_tokens"]
            missing_fields = [f for f in required_fields if f not in response.request]
            
            if missing_fields:
                return {
                    "passed": False,
                    "error": f"Missing required Responses API fields: {missing_fields}"
                }
            
            # Check that we're using correct field names
            if "messages" in response.request or "prompt" in response.request:
                return {
                    "passed": False,
                    "error": "Using legacy API field names instead of Responses API format"
                }
            
            return {
                "passed": True,
                "details": {
                    "endpoint": response.endpoint,
                    "request_fields": list(response.request.keys()),
                    "proof_blob": response.proof_blob
                }
            }
            
        except Exception as e:
            return {
                "passed": False,
                "error": f"Failed Responses API format test: {e}"
            }
    
    def test_proof_blob_generation(self) -> Dict[str, Any]:
        """Test audit trail proof blob generation."""
        request = create_reasoning_request(
            prompt="Complex analysis",
            effort=ReasoningEffort.HIGH,
            reuse_from="prev-123"
        )
        
        try:
            response = self.compliance.build_compliant_request(request)
            
            if not response.proof_blob:
                return {
                    "passed": False,
                    "error": "No proof blob generated"
                }
            
            required_proof_fields = [
                "api", "model", "family", "structured",
                "compliance_version", "enforcement"
            ]
            
            missing_fields = [f for f in required_proof_fields if f not in response.proof_blob]
            
            if missing_fields:
                return {
                    "passed": False,
                    "error": f"Missing proof blob fields: {missing_fields}"
                }
            
            if response.proof_blob["api"] != "responses":
                return {
                    "passed": False,
                    "error": "Proof blob not indicating Responses API usage"
                }
            
            if response.proof_blob["enforcement"] != "strict":
                return {
                    "passed": False,
                    "error": "Proof blob not indicating strict enforcement"
                }
            
            return {
                "passed": True,
                "details": response.proof_blob
            }
            
        except Exception as e:
            return {
                "passed": False,
                "error": f"Failed proof blob test: {e}"
            }
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Run all compliance validation tests."""
        print("\n" + "="*60)
        print("🔐 OPENAI COMPLIANCE LAYER VALIDATION")
        print("="*60)
        
        # Run tests
        self.run_test("Approved Models Only", self.test_approved_models)
        self.run_test("Reasoning Model Routing", self.test_reasoning_routing)
        self.run_test("Structured Output Enforcement", self.test_structured_output_enforcement)
        self.run_test("Responses API Format", self.test_responses_api_format)
        self.run_test("Audit Proof Blob", self.test_proof_blob_generation)
        
        # Generate summary
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results if r.passed)
        failed_tests = total_tests - passed_tests
        total_time = sum(r.execution_time for r in self.results)
        
        print("\n" + "="*60)
        print("📊 VALIDATION SUMMARY")
        print("="*60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Total Execution Time: {total_time:.3f}s")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        return {
            "summary": {
                "total_tests": total_tests,
                "passed": passed_tests,
                "failed": failed_tests,
                "success_rate": (passed_tests/total_tests)*100,
                "total_time": total_time
            },
            "results": [r.to_dict() for r in self.results],
            "compliance_ready": failed_tests == 0
        }


if __name__ == "__main__":
    validator = ComplianceValidator()
    report = validator.run_all_tests()
    
    # Save report
    report_file = "compliance_validation_report.json"
    with open(report_file, "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📝 Full report saved to: {report_file}")
    
    # Exit with appropriate code
    sys.exit(0 if report["compliance_ready"] else 1)