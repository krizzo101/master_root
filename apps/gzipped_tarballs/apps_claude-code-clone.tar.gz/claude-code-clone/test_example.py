#!/usr/bin/env python3
"""Test example for Claude Code Clone."""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig, ClaudeCodeExecutor


async def test_basic_functionality():
    """Test basic functionality of Claude Code Clone."""
    print("🧪 Testing Claude Code Clone...")

    # Create configuration
    config = ClaudeCodeConfig(
        provider="openai",
        model="gpt-5-mini",
        working_directory=".",
        enable_file_operations=False,  # Disable for testing
        api_key="test_key",  # This won't work without real key, but tests config
    )

    print(f"✅ Configuration created: {config.provider} with {config.model}")

    # Test executor creation
    try:
        executor = ClaudeCodeExecutor(config)
        print("✅ Executor created successfully")

        # Test basic prompt execution (this will fail without real API key, but tests structure)
        try:
            result = await executor.execute_prompt("Hello, world!")
            print(f"✅ Prompt execution successful: {result[:50]}...")
        except Exception as e:
            print(f"⚠️  Prompt execution failed (expected without real API key): {e}")

        await executor.close()
        print("✅ Executor closed successfully")

    except Exception as e:
        print(f"❌ Executor creation failed: {e}")
        return False

    print("🎉 All basic tests passed!")
    return True


if __name__ == "__main__":
    success = asyncio.run(test_basic_functionality())
    sys.exit(0 if success else 1)
