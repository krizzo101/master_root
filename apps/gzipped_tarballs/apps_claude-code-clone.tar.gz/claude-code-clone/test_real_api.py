#!/usr/bin/env python3
"""Test Claude Code Clone with real API key from environment."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig, ClaudeCodeExecutor


async def test_with_real_api():
    """Test with real API key from environment."""
    print("🧪 Testing Claude Code Clone with real API key...")

    # Get API key from environment
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ No OPENAI_API_KEY found in environment")
        return False

    print(f"✅ Found API key: {api_key[:20]}...")

    try:
        # Create config with real API key using approved model
        config = ClaudeCodeConfig(
            provider="openai",
            model="gpt-5-mini",  # Using approved model from OpenAI API Standards 2025
            api_key=api_key,
            working_directory=".",
            enable_file_operations=False,
        )

        print("✅ Configuration created successfully")

        # Create executor
        executor = ClaudeCodeExecutor(config)
        await executor.initialize()

        print("✅ Executor initialized successfully")

        # Test simple prompt
        result = await executor.execute_prompt("Say 'Test successful' and nothing else")
        print(f"✅ Test result: {result}")

        await executor.close()
        print("✅ Test completed successfully!")
        return True

    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False


if __name__ == "__main__":
    success = asyncio.run(test_with_real_api())
    sys.exit(0 if success else 1)
