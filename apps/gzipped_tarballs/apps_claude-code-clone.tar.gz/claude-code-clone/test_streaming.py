#!/usr/bin/env python3
"""Test streaming functionality specifically."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig, ClaudeCodeExecutor


async def test_streaming():
    """Test streaming functionality."""
    print("🧪 Testing Streaming Functionality...")

    # Get API key from environment
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ No OPENAI_API_KEY found in environment")
        return False

    try:
        # Create config
        config = ClaudeCodeConfig(
            provider="openai",
            model="gpt-5-mini",
            api_key=api_key,
            working_directory=".",
            enable_file_operations=False,
        )

        # Create executor
        executor = ClaudeCodeExecutor(config)
        await executor.initialize()

        print("✅ Executor initialized")

        # Test streaming
        print("🔄 Testing streaming response...")
        response_stream = await executor.execute_prompt(
            "Count from 1 to 3, one number per line", stream=True
        )

        print("📡 Streaming response:")
        collected_response = ""
        chunk_count = 0

        async for chunk in response_stream:
            chunk_count += 1
            print(f"Chunk {chunk_count}: '{chunk}' (type: {type(chunk)})")
            collected_response += chunk

        print(f"✅ Total chunks received: {chunk_count}")
        print(f"✅ Collected response: '{collected_response}'")

        if "1" in collected_response and "3" in collected_response:
            print("✅ Streaming test passed!")
            await executor.close()
            return True
        else:
            print("❌ Streaming test failed - missing expected content")
            await executor.close()
            return False

    except Exception as e:
        print(f"❌ Streaming test failed: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_streaming())
    sys.exit(0 if success else 1)
