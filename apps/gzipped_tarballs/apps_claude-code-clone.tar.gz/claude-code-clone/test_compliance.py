#!/usr/bin/env python3
"""Test OpenAI API Standards 2025 Compliance Layer."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig
from claude_code.compliance import (
    OpenAIComplianceLayer,
    OpenAIComplianceError,
    ComplianceRequest,
    ReasoningEffort,
    create_simple_request,
    create_reasoning_request,
    create_structured_request,
)
from claude_code.providers.llm_adapter import LLMAdapter


class ComplianceTestSuite:
    """Test suite for OpenAI compliance."""
    
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.compliance = OpenAIComplianceLayer()
    
    def test_pass(self, test_name: str, details: str = ""):
        """Log test pass."""
        self.passed += 1
        print(f"✅ PASS: {test_name}")
        if details:
            print(f"    {details}")
    
    def test_fail(self, test_name: str, details: str = ""):
        """Log test failure."""
        self.failed += 1
        print(f"❌ FAIL: {test_name}")
        if details:
            print(f"    {details}")
    
    def test_model_validation(self):
        """Test model validation enforcement."""
        print("\n🔐 Testing Model Validation")
        print("-" * 30)
        
        # Test approved models
        try:
            req = create_simple_request("test", model="gpt-5-mini")
            response = self.compliance.build_compliant_request(req)
            if response.model == "gpt-5-mini":
                self.test_pass("Approved model acceptance", f"Model: {response.model}")
            else:
                self.test_fail("Approved model acceptance", f"Wrong model: {response.model}")
        except Exception as e:
            self.test_fail("Approved model acceptance", str(e))
        
        # Test unapproved model rejection
        try:
            req = ComplianceRequest(
                prompt="test",
                max_tokens=100,
                model_override="gpt-4o"  # Unapproved model
            )
            self.compliance.build_compliant_request(req)
            self.test_fail("Unapproved model rejection", "Should have rejected gpt-4o")
        except OpenAIComplianceError as e:
            if "UNAUTHORIZED MODEL" in str(e):
                self.test_pass("Unapproved model rejection", "Correctly rejected gpt-4o")
            else:
                self.test_fail("Unapproved model rejection", f"Wrong error: {e}")
        except Exception as e:
            self.test_fail("Unapproved model rejection", f"Unexpected error: {e}")
    
    def test_reasoning_requests(self):
        """Test reasoning parameter handling."""
        print("\n🧠 Testing Reasoning Requests")
        print("-" * 30)
        
        # Test reasoning request
        try:
            req = create_reasoning_request("Solve this problem", ReasoningEffort.MEDIUM)
            response = self.compliance.build_compliant_request(req)
            
            if response.model == "o4-mini" and response.family.value == "o-series":
                self.test_pass("Reasoning model routing", f"Model: {response.model}")
            else:
                self.test_fail("Reasoning model routing", f"Wrong model/family: {response.model}/{response.family}")
            
            # Check reasoning parameters in request
            if "reasoning" in response.request and response.request["reasoning"]["effort"] == "medium":
                self.test_pass("Reasoning parameters", "Effort: medium")
            else:
                self.test_fail("Reasoning parameters", f"Missing or wrong reasoning: {response.request.get('reasoning')}")
                
        except Exception as e:
            self.test_fail("Reasoning request", str(e))
        
        # Test reasoning with invalid model
        try:
            req = ComplianceRequest(
                prompt="test",
                max_tokens=100,
                reasoning=ReasoningEffort.HIGH,
                model_override="gpt-5-mini"  # Wrong model for reasoning
            )
            self.compliance.build_compliant_request(req)
            self.test_fail("Invalid reasoning model", "Should reject reasoning on non-o4-mini")
        except OpenAIComplianceError:
            self.test_pass("Invalid reasoning model", "Correctly rejected reasoning on gpt-5-mini")
        except Exception as e:
            self.test_fail("Invalid reasoning model", f"Unexpected error: {e}")
    
    def test_structured_outputs(self):
        """Test structured output enforcement."""
        print("\n📋 Testing Structured Outputs")
        print("-" * 30)
        
        # Test with custom schema
        try:
            schema = {
                "name": "test_schema",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {"result": {"type": "string"}},
                    "required": ["result"]
                }
            }
            req = create_structured_request("test", schema)
            response = self.compliance.build_compliant_request(req)
            
            if "response_format" in response.request:
                format_type = response.request["response_format"]["type"]
                if format_type == "json_schema":
                    self.test_pass("Custom schema enforcement", "JSON Schema format applied")
                else:
                    self.test_fail("Custom schema enforcement", f"Wrong format: {format_type}")
            else:
                self.test_fail("Custom schema enforcement", "No response_format found")
                
        except Exception as e:
            self.test_fail("Custom schema enforcement", str(e))
        
        # Test default schema
        try:
            req = create_simple_request("test")
            response = self.compliance.build_compliant_request(req)
            
            if "response_format" in response.request:
                schema_name = response.request["response_format"]["json_schema"]["name"]
                if schema_name == "text_payload":
                    self.test_pass("Default schema application", "Default text_payload schema")
                else:
                    self.test_fail("Default schema application", f"Wrong schema: {schema_name}")
            else:
                self.test_fail("Default schema application", "No default schema applied")
                
        except Exception as e:
            self.test_fail("Default schema application", str(e))
    
    def test_compliance_integration(self):
        """Test compliance integration with LLM adapter."""
        print("\n🔗 Testing Compliance Integration")
        print("-" * 30)
        
        # Get API key
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            self.test_fail("API key check", "No OPENAI_API_KEY found")
            return
        
        try:
            # Create config
            config = ClaudeCodeConfig(
                provider="openai",
                model="gpt-5-mini",
                api_key=api_key,
                working_directory=".",
                enable_file_operations=False
            )
            
            # Create adapter
            adapter = LLMAdapter(config)
            
            # Check compliance layer initialization
            if hasattr(adapter, '_compliance'):
                self.test_pass("Compliance layer initialization", "Compliance layer present")
            else:
                self.test_fail("Compliance layer initialization", "No compliance layer found")
            
        except Exception as e:
            self.test_fail("Compliance integration", str(e))
    
    def test_proof_blob_generation(self):
        """Test proof blob generation for audit trail."""
        print("\n📝 Testing Proof Blob Generation")
        print("-" * 30)
        
        try:
            req = create_reasoning_request("test", ReasoningEffort.HIGH)
            response = self.compliance.build_compliant_request(req)
            
            proof = response.proof_blob
            
            # Check required fields
            required_fields = ["api", "model", "family", "structured", "compliance_version"]
            missing = [field for field in required_fields if field not in proof]
            
            if not missing:
                self.test_pass("Proof blob completeness", f"All required fields present")
            else:
                self.test_fail("Proof blob completeness", f"Missing fields: {missing}")
            
            # Check values
            if proof["api"] == "responses" and proof["compliance_version"] == "2025-09-07":
                self.test_pass("Proof blob values", "Correct API and version")
            else:
                self.test_fail("Proof blob values", f"Wrong values: {proof}")
                
        except Exception as e:
            self.test_fail("Proof blob generation", str(e))
    
    async def run_all_tests(self):
        """Run all compliance tests."""
        print("🚀 OpenAI API Standards 2025 Compliance Test Suite")
        print("=" * 55)
        
        self.test_model_validation()
        self.test_reasoning_requests()
        self.test_structured_outputs()
        self.test_compliance_integration()
        self.test_proof_blob_generation()
        
        # Summary
        print("\n📊 TEST SUMMARY")
        print("=" * 20)
        total = self.passed + self.failed
        success_rate = (self.passed / total * 100) if total > 0 else 0
        
        print(f"Total Tests: {total}")
        print(f"Passed: {self.passed}")
        print(f"Failed: {self.failed}")
        print(f"Success Rate: {success_rate:.1f}%")
        
        if self.failed == 0:
            print("\n🎉 ALL COMPLIANCE TESTS PASSED!")
            print("🔐 OpenAI API Standards 2025 enforcement is working correctly!")
            return True
        else:
            print(f"\n⚠️  {self.failed} tests failed. Check compliance implementation.")
            return False


async def main():
    """Main test execution."""
    suite = ComplianceTestSuite()
    success = await suite.run_all_tests()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
