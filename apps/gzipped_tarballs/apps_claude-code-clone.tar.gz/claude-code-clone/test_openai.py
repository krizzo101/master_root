print('Hello OpenAI\!')
