#!/usr/bin/env python3
"""Test response format to understand the new structure."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig
from claude_code.providers.llm_adapter import LLMAdapter
from opsvi_llm import Message


async def test_response_format():
    """Test response format to understand the new structure."""
    print("🧪 Testing Response Format...")

    # Get API key from environment
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ No OPENAI_API_KEY found in environment")
        return False

    try:
        # Create config
        config = ClaudeCodeConfig(
            provider="openai",
            model="gpt-5-mini",
            api_key=api_key,
            working_directory=".",
            enable_file_operations=False,
        )

        # Create LLM adapter
        adapter = LLMAdapter(config)
        await adapter.initialize()

        # Test direct chat completion
        messages = [
            Message(role="user", content="Say 'Test successful' and nothing else")
        ]

        print("🔄 Testing chat completion...")
        response = await adapter.chat_completion(messages)

        print(f"✅ Response type: {type(response)}")

        # Check for different possible content fields
        content_fields = ["output_text", "text", "content", "choices", "output"]

        for field in content_fields:
            if hasattr(response, field):
                value = getattr(response, field)
                print(f"✅ {field}: {value}")

                # If it's a complex object, try to get text from it
                if hasattr(value, "text"):
                    print(f"   └─ text: {value.text}")
                if hasattr(value, "content"):
                    print(f"   └─ content: {value.content}")

        # Try to get the actual response text
        if hasattr(response, "output_text"):
            output_text = response.output_text
            if hasattr(output_text, "text"):
                print(f"✅ Final response text: {output_text.text}")
            else:
                print(f"✅ Output text object: {output_text}")

        await adapter.close()
        print("✅ Test completed successfully!")
        return True

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_response_format())
    sys.exit(0 if success else 1)
