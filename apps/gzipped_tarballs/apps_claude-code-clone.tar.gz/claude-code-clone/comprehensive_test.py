#!/usr/bin/env python3
"""Comprehensive test execution for Claude Code Clone with OpenAI integration."""

import asyncio
import os
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig, ClaudeCodeExecutor, CodeAnalyzer


class ComprehensiveTester:
    """Comprehensive tester for Claude Code Clone OpenAI integration."""

    def __init__(self):
        self.session_start = datetime.now()
        self.results = {
            "total_tests": 0,
            "passed_tests": 0,
            "failed_tests": 0,
            "test_details": [],
        }

    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Log test result."""
        self.results["total_tests"] += 1
        if success:
            self.results["passed_tests"] += 1
            status = "✅ PASS"
        else:
            self.results["failed_tests"] += 1
            status = "❌ FAIL"

        self.results["test_details"].append(
            {"name": test_name, "status": status, "details": details}
        )

        print(f"{status} {test_name}")
        if details:
            print(f"    {details}")

    async def test_basic_prompt(self, executor: ClaudeCodeExecutor) -> bool:
        """Test basic prompt execution."""
        try:
            result = await executor.execute_prompt(
                "Say 'Hello from Claude Code Clone!' and nothing else"
            )
            if "Hello from Claude Code Clone" in result:
                self.log_test("Basic Prompt Execution", True, f"Response: {result}")
                return True
            else:
                self.log_test(
                    "Basic Prompt Execution", False, f"Unexpected response: {result}"
                )
                return False
        except Exception as e:
            self.log_test("Basic Prompt Execution", False, f"Error: {e}")
            return False

    async def test_code_analysis(self, executor: ClaudeCodeExecutor) -> bool:
        """Test code analysis functionality."""
        try:
            # Create a simple test file
            test_file = Path("test_code.py")
            test_file.write_text(
                """
def hello_world():
    print("Hello, World!")
    return "success"

if __name__ == "__main__":
    hello_world()
"""
            )

            # Analyze the file
            analysis = await executor.analyze_file(
                str(test_file), analysis_type="general"
            )

            if (
                analysis and len(analysis) > 10
            ):  # Basic check that we got meaningful analysis
                self.log_test(
                    "Code Analysis", True, f"Analysis length: {len(analysis)} chars"
                )
                # Clean up
                test_file.unlink()
                return True
            else:
                self.log_test("Code Analysis", False, f"Analysis too short: {analysis}")
                test_file.unlink()
                return False
        except Exception as e:
            self.log_test("Code Analysis", False, f"Error: {e}")
            return False

    async def test_code_generation(self, executor: ClaudeCodeExecutor) -> bool:
        """Test code generation functionality."""
        try:
            # Generate a simple Python function
            code = await executor.generate_file(
                "generated_function.py",
                "Create a Python function that calculates the factorial of a number",
                language="python",
            )

            if code and "def" in code and "factorial" in code.lower():
                self.log_test(
                    "Code Generation", True, f"Generated {len(code)} chars of code"
                )
                # Clean up
                Path("generated_function.py").unlink()
                return True
            else:
                self.log_test("Code Generation", False, f"Generated code: {code}")
                return False
        except Exception as e:
            self.log_test("Code Generation", False, f"Error: {e}")
            return False

    async def test_streaming(self, executor: ClaudeCodeExecutor) -> bool:
        """Test streaming response."""
        try:
            response_stream = await executor.execute_prompt(
                "Count from 1 to 5, one number per line", stream=True
            )

            collected_response = ""
            async for chunk in response_stream:
                collected_response += chunk

            if "1" in collected_response and "5" in collected_response:
                self.log_test(
                    "Streaming Response",
                    True,
                    f"Streamed {len(collected_response)} chars",
                )
                return True
            else:
                self.log_test(
                    "Streaming Response",
                    False,
                    f"Streamed content: {collected_response}",
                )
                return False
        except Exception as e:
            self.log_test("Streaming Response", False, f"Error: {e}")
            return False

    async def run_comprehensive_test(self):
        """Run all comprehensive tests."""
        print("🚀 COMPREHENSIVE CLAUDE CODE CLONE TEST EXECUTION")
        print("=" * 60)
        print(f"Session started: {self.session_start}")
        print()

        # Get API key from environment
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print("❌ No OPENAI_API_KEY found in environment")
            return False

        print(f"✅ Using API key: {api_key[:20]}...")
        print()

        try:
            # Create configuration
            config = ClaudeCodeConfig(
                provider="openai",
                model="gpt-5-mini",  # Using approved model from OpenAI API Standards 2025
                api_key=api_key,
                working_directory=".",
                enable_file_operations=True,  # Enable for comprehensive testing
                max_tokens=1000,
                temperature=0.7,
            )

            # Create executor
            executor = ClaudeCodeExecutor(config)
            await executor.initialize()

            print("✅ Executor initialized successfully")
            print()

            # Run all tests
            await self.test_basic_prompt(executor)
            await self.test_code_analysis(executor)
            await self.test_code_generation(executor)
            await self.test_streaming(executor)

            # Cleanup
            await executor.close()

            # Print results
            print()
            print("📊 TEST RESULTS SUMMARY")
            print("=" * 30)
            print(f"Total Tests: {self.results['total_tests']}")
            print(f"Passed: {self.results['passed_tests']}")
            print(f"Failed: {self.results['failed_tests']}")
            print(
                f"Success Rate: {(self.results['passed_tests'] / self.results['total_tests'] * 100):.1f}%"
            )

            session_duration = datetime.now() - self.session_start
            print(f"Session Duration: {session_duration.total_seconds():.2f} seconds")

            if self.results["failed_tests"] == 0:
                print()
                print("🎉 ALL TESTS PASSED! Claude Code Clone is working perfectly!")
                return True
            else:
                print()
                print("⚠️  Some tests failed. Check the details above.")
                return False

        except Exception as e:
            print(f"❌ Comprehensive test failed: {e}")
            import traceback

            traceback.print_exc()
            return False


async def main():
    """Main test execution."""
    tester = ComprehensiveTester()
    success = await tester.run_comprehensive_test()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
