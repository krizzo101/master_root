#!/usr/bin/env python3
"""Test streaming at the LLM adapter level."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig
from claude_code.providers.llm_adapter import LLMAdapter
from opsvi_llm import Message


async def test_streaming_adapter():
    """Test streaming at the LLM adapter level."""
    print("🧪 Testing LLM Adapter Streaming...")

    # Get API key from environment
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ No OPENAI_API_KEY found in environment")
        return False

    try:
        # Create config
        config = ClaudeCodeConfig(
            provider="openai",
            model="gpt-5-mini",
            api_key=api_key,
            working_directory=".",
            enable_file_operations=False,
        )

        # Create LLM adapter
        adapter = LLMAdapter(config)
        await adapter.initialize()

        print("✅ LLM Adapter initialized")

        # Test streaming
        messages = [
            Message(role="user", content="Count from 1 to 3, one number per line")
        ]

        print("🔄 Testing streaming chat completion...")
        response_stream = await adapter.chat_completion(messages, stream=True)

        print("📡 Streaming response:")
        chunk_count = 0

        async for chunk in response_stream:
            chunk_count += 1
            print(f"Chunk {chunk_count}: {chunk} (type: {type(chunk)})")
            print(f"  Attributes: {dir(chunk)}")

            # Check for different possible content fields
            if hasattr(chunk, "output_text"):
                print(f"  output_text: {chunk.output_text}")
            if hasattr(chunk, "choices"):
                print(f"  choices: {chunk.choices}")
            if hasattr(chunk, "content"):
                print(f"  content: {chunk.content}")
            if hasattr(chunk, "text"):
                print(f"  text: {chunk.text}")

        print(f"✅ Total chunks received: {chunk_count}")

        await adapter.close()

        if chunk_count > 0:
            print("✅ Streaming adapter test passed!")
            return True
        else:
            print("❌ Streaming adapter test failed - no chunks received")
            return False

    except Exception as e:
        print(f"❌ Streaming adapter test failed: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_streaming_adapter())
    sys.exit(0 if success else 1)
