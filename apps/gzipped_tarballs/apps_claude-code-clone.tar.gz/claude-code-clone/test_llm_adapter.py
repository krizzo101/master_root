#!/usr/bin/env python3
"""Test LLM Adapter directly to debug response format."""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_code import ClaudeCodeConfig
from claude_code.providers.llm_adapter import LLMAdapter
from opsvi_llm import Message


async def test_llm_adapter():
    """Test LLM adapter directly."""
    print("🧪 Testing LLM Adapter directly...")

    # Get API key from environment
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ No OPENAI_API_KEY found in environment")
        return False

    print(f"✅ Found API key: {api_key[:20]}...")

    try:
        # Create config
        config = ClaudeCodeConfig(
            provider="openai",
            model="gpt-5-mini",
            api_key=api_key,
            working_directory=".",
            enable_file_operations=False,
        )

        # Create LLM adapter
        adapter = LLMAdapter(config)
        await adapter.initialize()

        print("✅ LLM Adapter initialized successfully")

        # Test direct chat completion
        messages = [
            Message(role="user", content="Say 'Test successful' and nothing else")
        ]

        print("🔄 Testing chat completion...")
        response = await adapter.chat_completion(messages)

        print(f"✅ Response type: {type(response)}")
        print(f"✅ Response attributes: {dir(response)}")

        # Try to extract content
        if hasattr(response, "choices"):
            print(f"✅ Response has choices: {response.choices}")
            if response.choices and len(response.choices) > 0:
                choice = response.choices[0]
                print(f"✅ Choice type: {type(choice)}")
                print(f"✅ Choice attributes: {dir(choice)}")
                if hasattr(choice, "message"):
                    print(f"✅ Message content: {choice.message.content}")
                else:
                    print(f"✅ Choice content: {choice.content}")
        elif hasattr(response, "content"):
            print(f"✅ Response content: {response.content}")
        elif hasattr(response, "text"):
            print(f"✅ Response text: {response.text}")
        else:
            print(f"✅ Raw response: {response}")

        await adapter.close()
        print("✅ Test completed successfully!")
        return True

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_llm_adapter())
    sys.exit(0 if success else 1)
