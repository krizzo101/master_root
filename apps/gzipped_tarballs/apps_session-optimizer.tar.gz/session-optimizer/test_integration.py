#!/usr/bin/env python3
"""
Test integration between ClaudeFormatAdapter and SessionAnalyticsEngine
to identify compatibility gaps and validate functionality.
"""

import sys
import json
from pathlib import Path

# Add src to path for imports
sys.path.append(str(Path(__file__).parent / "src"))

from claude_format_adapter import ClaudeFormatAdapter, AdapterConfig
from session_analytics_engine import SessionAnalyticsEngine, LogParser, MessageNode

def test_claude_format_compatibility():
    """Test if Claude format adapter works with SessionAnalyticsEngine"""
    
    # Find a sample Claude .jsonl file
    claude_projects = Path("/home/opsvi/.claude/projects")
    sample_files = list(claude_projects.glob("**/*.jsonl"))[:3]  # Take first 3
    
    if not sample_files:
        print("❌ No Claude session files found for testing")
        return False
    
    print(f"🔍 Testing with {len(sample_files)} sample files...")
    
    # Test 1: Direct SessionAnalyticsEngine parsing
    print("\n📊 Test 1: Direct SessionAnalyticsEngine parsing")
    analytics_engine = SessionAnalyticsEngine()
    direct_results = []
    
    for sample_file in sample_files:
        try:
            print(f"  Analyzing {sample_file.name}...")
            report = analytics_engine.analyze_session(sample_file)
            direct_results.append({
                "file": sample_file.name,
                "success": True,
                "message_count": report.conversation_flow.conversation_length,
                "tool_count": sum(report.tool_usage.tool_counts.values()),
                "complexity": report.complexity_rating
            })
        except Exception as e:
            direct_results.append({
                "file": sample_file.name,
                "success": False,
                "error": str(e)
            })
    
    # Test 2: ClaudeFormatAdapter conversion then analytics
    print("\n🔄 Test 2: ClaudeFormatAdapter + SessionAnalyticsEngine")
    adapter = ClaudeFormatAdapter(AdapterConfig(
        preserve_all_metadata=True,
        consolidate_tool_sequences=False,  # Keep original for comparison
        remove_duplicate_content=False
    ))
    
    adapter_results = []
    
    for sample_file in sample_files:
        try:
            print(f"  Converting {sample_file.name}...")
            converted_session = adapter.convert_session_file(sample_file)
            
            # Test if we can create MessageNodes from converted format
            nodes = []
            for msg in converted_session.get("messages", []):
                # Create MessageNode compatible structure
                node = MessageNode(
                    uuid=msg.get("uuid", "unknown"),
                    session_id=converted_session.get("session_id", "unknown"),
                    parent_uuid=msg.get("parent_uuid"),
                    node_type=msg.get("type", "unknown"),
                    timestamp=msg.get("timestamp", ""),
                    content_hash="test_hash",
                    raw_content=msg
                )
                # Add tool data
                node.tool_calls = msg.get("tool_calls", [])
                node.tool_results = msg.get("tool_results", [])
                nodes.append(node)
            
            # Test analytics on converted data
            if nodes:
                conversation_flow = analytics_engine.conversation_analyzer.analyze_conversation(nodes)
                tool_usage = analytics_engine.tool_analyzer.analyze_tool_usage(nodes)
                file_operations = analytics_engine.file_analyzer.analyze_file_operations(nodes)
                
                adapter_results.append({
                    "file": sample_file.name,
                    "success": True,
                    "message_count": len(nodes),
                    "tool_count": sum(tool_usage.tool_counts.values()),
                    "conversion_stats": converted_session.get("conversion_stats", {})
                })
            else:
                adapter_results.append({
                    "file": sample_file.name,
                    "success": False,
                    "error": "No messages converted"
                })
                
        except Exception as e:
            adapter_results.append({
                "file": sample_file.name,
                "success": False,
                "error": str(e)
            })
    
    # Compare results
    print("\n📋 Results Comparison:")
    print("=" * 60)
    print(f"{'File':<25} {'Direct':<10} {'Adapter':<10} {'Issues':<15}")
    print("=" * 60)
    
    compatibility_issues = []
    
    for i, file_name in enumerate([f.name for f in sample_files]):
        direct = direct_results[i]
        adapter = adapter_results[i]
        
        direct_status = "✅ OK" if direct["success"] else "❌ FAIL"
        adapter_status = "✅ OK" if adapter["success"] else "❌ FAIL"
        
        issues = []
        if direct["success"] and adapter["success"]:
            # Compare metrics
            direct_msgs = direct["message_count"]
            adapter_msgs = adapter["message_count"]
            
            if abs(direct_msgs - adapter_msgs) > direct_msgs * 0.1:  # >10% difference
                issues.append("MSG_COUNT")
            
            direct_tools = direct["tool_count"]
            adapter_tools = adapter["tool_count"]
            
            if abs(direct_tools - adapter_tools) > direct_tools * 0.1:  # >10% difference
                issues.append("TOOL_COUNT")
                
        elif not direct["success"] and adapter["success"]:
            issues.append("ADAPTER_BETTER")
        elif direct["success"] and not adapter["success"]:
            issues.append("DIRECT_BETTER")
        elif not direct["success"] and not adapter["success"]:
            issues.append("BOTH_FAIL")
        
        issues_str = ",".join(issues) if issues else "NONE"
        print(f"{file_name:<25} {direct_status:<10} {adapter_status:<10} {issues_str:<15}")
        
        if issues:
            compatibility_issues.extend(issues)
    
    print("\n🔍 Compatibility Analysis:")
    if not compatibility_issues:
        print("✅ No major compatibility issues detected")
        return True
    else:
        print(f"⚠️  Found {len(set(compatibility_issues))} types of issues:")
        for issue in set(compatibility_issues):
            count = compatibility_issues.count(issue)
            print(f"   - {issue}: {count} files affected")
        return False

def test_message_node_conversion():
    """Test conversion from Claude format to MessageNode format"""
    print("\n🧪 Test 3: MessageNode conversion accuracy")
    
    # Test sample Claude record
    claude_record = {
        "type": "assistant",
        "uuid": "test-uuid-123",
        "parentUuid": "parent-uuid-456",
        "timestamp": "2025-09-09T04:25:35.126Z",
        "sessionId": "test-session",
        "message": {
            "content": [
                {"type": "text", "text": "I'll help you with that task."},
                {
                    "type": "tool_use",
                    "id": "tool-123",
                    "name": "Read",
                    "input": {"file_path": "/test/file.py"}
                }
            ]
        }
    }
    
    # Test LogParser parsing
    log_parser = LogParser()
    node = log_parser._parse_record(claude_record, "test-session")
    
    print(f"  Original type: {claude_record['type']}")
    print(f"  MessageNode type: {node.node_type}")
    print(f"  Tool calls extracted: {len(node.tool_calls)}")
    print(f"  UUID preserved: {node.uuid == claude_record['uuid']}")
    
    # Test ClaudeFormatAdapter parsing
    adapter = ClaudeFormatAdapter()
    converted = adapter._convert_claude_record(claude_record)
    
    print(f"  Adapter type: {converted['type']}")
    print(f"  Adapter tool calls: {len(converted.get('tool_calls', []))}")
    print(f"  Content extraction: {len(converted.get('content', ''))} chars")
    
    return True

if __name__ == "__main__":
    print("🚀 Testing Claude Format Adapter Integration")
    print("=" * 50)
    
    success = True
    
    try:
        success &= test_claude_format_compatibility()
        success &= test_message_node_conversion()
        
        print("\n" + "=" * 50)
        if success:
            print("✅ Integration tests PASSED - Adapter is compatible")
        else:
            print("⚠️  Integration tests found issues - Enhancement needed")
            
    except Exception as e:
        print(f"❌ Test execution failed: {e}")
        import traceback
        traceback.print_exc()