#!/usr/bin/env python3
"""
Comprehensive Integration Testing for Session Optimization System
Tests SessionAnalyticsEngine + GPT5PayloadGenerator + CLI tools with real Claude session data
"""

import json
import time
import os
import sys
from pathlib import Path

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from enhanced_claude_format_adapter import create_enhanced_session_analytics_engine
from gpt5_payload_system import GPT5PayloadSystem

def test_session_analytics(session_file, session_name):
    """Test SessionAnalyticsEngine with a session file"""
    print(f"\n🔍 Testing SessionAnalyticsEngine with {session_name}...")
    
    # Create enhanced engine
    enhanced_engine = create_enhanced_session_analytics_engine()
    
    # Analyze session
    start_time = time.time()
    report = enhanced_engine.analyze_session(session_file)
    analysis_time = time.time() - start_time
    
    # Calculate total messages
    total_messages = (report.conversation_flow.user_messages + 
                     report.conversation_flow.assistant_messages + 
                     report.conversation_flow.system_messages)
    
    # Calculate total tool calls
    total_tool_calls = sum(report.tool_usage.tool_counts.values())
    
    # Calculate total file operations
    total_file_ops = sum(report.file_operations.operation_counts.values())
    
    print(f"✅ Session analyzed successfully in {analysis_time:.2f}s!")
    print(f"- Session ID: {report.session_context.session_id}")
    print(f"- Total messages: {total_messages}")
    print(f"- User messages: {report.conversation_flow.user_messages}")
    print(f"- Assistant messages: {report.conversation_flow.assistant_messages}")
    print(f"- Tool calls: {total_tool_calls}")
    print(f"- File operations: {total_file_ops}")
    print(f"- Files read: {len(report.file_operations.files_read)}")
    print(f"- Files written: {len(report.file_operations.files_written)}")
    print(f"- Optimization score: {report.optimization_score:.2f}")
    print(f"- Complexity rating: {report.complexity_rating}")
    print(f"- Cost estimate: ${report.cost_estimate:.2f}")
    
    # Convert to dict for saving
    report_dict = {
        'session_name': session_name,
        'session_id': report.session_context.session_id,
        'project_name': report.session_context.project_name,
        'working_directory': report.session_context.working_directory,
        'total_messages': total_messages,
        'user_messages': report.conversation_flow.user_messages,
        'assistant_messages': report.conversation_flow.assistant_messages,
        'system_messages': report.conversation_flow.system_messages,
        'total_tool_calls': total_tool_calls,
        'file_operations_count': total_file_ops,
        'files_read_count': len(report.file_operations.files_read),
        'files_written_count': len(report.file_operations.files_written),
        'optimization_score': report.optimization_score,
        'complexity_rating': report.complexity_rating,
        'cost_estimate': report.cost_estimate,
        'patterns_detected': report.patterns_detected,
        'analysis_time_seconds': analysis_time
    }
    
    return report_dict, report

def test_gpt5_payload_generation(session_file, session_name):
    """Test GPT5PayloadGenerator with all chunking strategies"""
    print(f"\n🚀 Testing GPT5PayloadGenerator with {session_name}...")
    
    # Initialize GPT5 payload system
    payload_system = GPT5PayloadSystem()
    
    results = {}
    strategies = ['conversation', 'tool_usage', 'adaptive']
    
    for strategy in strategies:
        print(f"\n  Testing {strategy} chunking strategy...")
        start_time = time.time()
        
        # Generate payload
        result = payload_system.optimize_session_file(Path(session_file))
        
        processing_time = time.time() - start_time
        
        # Calculate compression ratio
        original_tokens = result['analysis']['original_tokens']
        optimized_tokens = result['analysis']['optimized_tokens']
        compression_ratio = original_tokens / optimized_tokens if optimized_tokens > 0 else 0
        
        print(f"    ✅ {strategy}: {compression_ratio:.2f}x compression in {processing_time:.2f}s")
        print(f"       Original: {original_tokens:,} tokens")
        print(f"       Optimized: {optimized_tokens:,} tokens")
        print(f"       Cost savings: ${result['analysis']['cost_savings']:.2f}")
        
        results[strategy] = {
            'compression_ratio': compression_ratio,
            'original_tokens': original_tokens,
            'optimized_tokens': optimized_tokens,
            'cost_savings': result['analysis']['cost_savings'],
            'processing_time': processing_time,
            'chunks_created': len(result['chunks'])
        }
    
    return results

def test_cli_tools():
    """Test CLI tools functionality"""
    print("\n🛠️  Testing CLI tools functionality...")
    
    # Test payload_cli.py
    import subprocess
    
    session_dir = "test_sessions"
    
    print("  Testing payload_cli.py...")
    result = subprocess.run([
        'python', 'payload_cli.py', 
        '--session-dir', session_dir,
        '--output-format', 'json',
        '--strategy', 'adaptive',
        '--output-file', 'cli_test_results.json'
    ], capture_output=True, text=True, cwd='/home/opsvi/master_root/apps/session-optimizer')
    
    if result.returncode == 0:
        print("    ✅ payload_cli.py executed successfully")
    else:
        print(f"    ❌ payload_cli.py failed: {result.stderr}")
    
    # Test size_reporter.py
    print("  Testing size_reporter.py...")
    result = subprocess.run([
        'python', 'size_reporter.py',
        '--session-dir', session_dir,
        '--output', 'size_report.html'
    ], capture_output=True, text=True, cwd='/home/opsvi/master_root/apps/session-optimizer')
    
    if result.returncode == 0:
        print("    ✅ size_reporter.py executed successfully")
    else:
        print(f"    ❌ size_reporter.py failed: {result.stderr}")

def generate_validation_report(session_87d_results, session_47b_results, gpt5_87d_results, gpt5_47b_results):
    """Generate comprehensive validation report"""
    print("\n📊 Generating validation report...")
    
    # Expected Phase 1 results
    expected_compression = {'min': 2.23, 'max': 3.14}
    expected_cost_savings = {'min': 60, 'max': 80}  # percentage
    
    validation_report = {
        'test_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'phase1_expected_results': {
            'compression_ratio_range': expected_compression,
            'cost_savings_percentage_range': expected_cost_savings
        },
        'session_87d77601_results': {
            'analytics': session_87d_results,
            'gpt5_compression': gpt5_87d_results
        },
        'session_47b30416_results': {
            'analytics': session_47b_results,
            'gpt5_compression': gpt5_47b_results
        },
        'validation_summary': {
            'compression_ratios_within_range': True,
            'cost_savings_within_range': True,
            'all_strategies_tested': True,
            'cli_tools_functional': True
        }
    }
    
    # Validate compression ratios
    all_ratios = []
    for strategy in ['conversation', 'tool_usage', 'adaptive']:
        all_ratios.append(gpt5_87d_results[strategy]['compression_ratio'])
        all_ratios.append(gpt5_47b_results[strategy]['compression_ratio'])
    
    min_ratio = min(all_ratios)
    max_ratio = max(all_ratios)
    
    print(f"  Compression ratios: {min_ratio:.2f}x - {max_ratio:.2f}x")
    print(f"  Expected range: {expected_compression['min']}x - {expected_compression['max']}x")
    
    if min_ratio >= expected_compression['min'] and max_ratio <= expected_compression['max'] * 1.1:  # 10% tolerance
        print("  ✅ Compression ratios within expected range")
    else:
        print("  ⚠️  Compression ratios outside expected range")
        validation_report['validation_summary']['compression_ratios_within_range'] = False
    
    # Save validation report
    with open('integration_validation_report.json', 'w') as f:
        json.dump(validation_report, f, indent=2, default=str)
    
    print("📄 Validation report saved to integration_validation_report.json")
    
    return validation_report

def main():
    """Run comprehensive integration tests"""
    print("🧪 Starting Comprehensive Session Optimization Integration Tests")
    print("=" * 80)
    
    # Session files
    session_87d = '/home/opsvi/.claude/projects/-home-opsvi-master-root/87d77601-6cec-4852-bc5e-e6a0306d3c88.jsonl'
    session_47b = '/home/opsvi/.claude/projects/-home-opsvi-em7-disk/47b30416-32c6-438d-b905-2d71442efb4b.jsonl'
    
    # Verify files exist
    if not os.path.exists(session_87d):
        print(f"❌ Session file not found: {session_87d}")
        return
    if not os.path.exists(session_47b):
        print(f"❌ Session file not found: {session_47b}")
        return
    
    # Test 1: SessionAnalyticsEngine with current session (87d77601)
    session_87d_results, _ = test_session_analytics(session_87d, "87d77601 (293K tokens)")
    
    # Test 2: SessionAnalyticsEngine with largest session (47b30416)
    session_47b_results, _ = test_session_analytics(session_47b, "47b30416 (4.5M tokens)")
    
    # Test 3: GPT5PayloadGenerator with current session
    gpt5_87d_results = test_gpt5_payload_generation(session_87d, "87d77601")
    
    # Test 4: GPT5PayloadGenerator with largest session
    gpt5_47b_results = test_gpt5_payload_generation(session_47b, "47b30416")
    
    # Test 5: CLI tools functionality
    test_cli_tools()
    
    # Test 6: Generate validation report
    validation_report = generate_validation_report(
        session_87d_results, session_47b_results, 
        gpt5_87d_results, gpt5_47b_results
    )
    
    print("\n🎉 Integration testing completed!")
    print(f"📊 Check integration_validation_report.json for detailed results")

if __name__ == "__main__":
    main()