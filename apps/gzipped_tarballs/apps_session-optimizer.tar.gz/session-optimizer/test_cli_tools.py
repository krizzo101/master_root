#!/usr/bin/env python3
"""
Test script for payload_cli.py and size_reporter.py
Validates integration with SessionAnalyticsEngine and GPT5PayloadGenerator
"""

import sys
import subprocess
import tempfile
import json
from pathlib import Path


def create_test_session_file():
    """Create a test .jsonl session file for testing"""
    test_data = [
        {
            "type": "user",
            "uuid": "test-user-1",
            "sessionId": "test-session-123",
            "timestamp": "2025-09-09T04:00:00Z",
            "message": {
                "content": [{"type": "text", "text": "Hello, can you help me write a Python function to calculate fibonacci numbers?"}]
            }
        },
        {
            "type": "assistant", 
            "uuid": "test-assistant-1",
            "sessionId": "test-session-123",
            "parentUuid": "test-user-1",
            "timestamp": "2025-09-09T04:00:05Z",
            "message": {
                "content": [
                    {"type": "text", "text": "I'll help you write a Python function to calculate Fibonacci numbers. Let me create both recursive and iterative versions."},
                    {
                        "type": "tool_use",
                        "id": "tool_1",
                        "name": "Write",
                        "input": {
                            "file_path": "/tmp/fibonacci.py",
                            "content": "def fibonacci_recursive(n):\n    if n <= 1:\n        return n\n    return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)\n\ndef fibonacci_iterative(n):\n    if n <= 1:\n        return n\n    a, b = 0, 1\n    for _ in range(2, n + 1):\n        a, b = b, a + b\n    return b\n\n# Test the functions\nfor i in range(10):\n    print(f\"Fib({i}) = {fibonacci_iterative(i)}\")"
                        }
                    }
                ]
            }
        },
        {
            "type": "assistant",
            "uuid": "test-tool-result-1", 
            "sessionId": "test-session-123",
            "parentUuid": "test-assistant-1",
            "timestamp": "2025-09-09T04:00:06Z",
            "message": {
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "tool_1",
                        "is_error": False,
                        "content": "File created successfully."
                    }
                ]
            }
        },
        {
            "type": "user",
            "uuid": "test-user-2",
            "sessionId": "test-session-123", 
            "parentUuid": "test-tool-result-1",
            "timestamp": "2025-09-09T04:00:10Z",
            "message": {
                "content": [{"type": "text", "text": "Great! Can you also show me how to optimize the recursive version with memoization?"}]
            }
        },
        {
            "type": "assistant",
            "uuid": "test-assistant-2",
            "sessionId": "test-session-123",
            "parentUuid": "test-user-2", 
            "timestamp": "2025-09-09T04:00:15Z",
            "message": {
                "content": [
                    {"type": "text", "text": "Absolutely! Memoization is a great optimization technique for recursive functions. Let me show you how to implement it."},
                    {
                        "type": "tool_use",
                        "id": "tool_2",
                        "name": "Edit",
                        "input": {
                            "file_path": "/tmp/fibonacci.py",
                            "old_string": "def fibonacci_recursive(n):\n    if n <= 1:\n        return n\n    return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)",
                            "new_string": "def fibonacci_recursive(n, memo={}):\n    if n in memo:\n        return memo[n]\n    if n <= 1:\n        return n\n    memo[n] = fibonacci_recursive(n-1, memo) + fibonacci_recursive(n-2, memo)\n    return memo[n]"
                        }
                    }
                ]
            }
        }
    ]
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
    for record in test_data:
        temp_file.write(json.dumps(record) + '\n')
    temp_file.close()
    
    return Path(temp_file.name)


def test_size_reporter():
    """Test size_reporter.py functionality"""
    print("🧪 Testing size_reporter.py...")
    
    # Create test session
    test_session = create_test_session_file()
    
    try:
        # Test basic analysis
        print("   Testing analyze command...")
        result = subprocess.run([
            sys.executable, "size_reporter.py", "analyze", str(test_session),
            "--format", "json", "--include-analytics"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Analyze command successful")
            # Parse and validate output
            try:
                output_lines = result.stdout.strip().split('\n')
                json_output = None
                for line in output_lines:
                    if line.startswith('{'):
                        json_output = json.loads(line)
                        break
                
                if json_output and "size_analysis" in json_output:
                    print(f"   📊 Detected {json_output['size_analysis']['total_tokens']} tokens")
                    print(f"   🎯 Optimization score: {json_output['optimization_analysis']['optimization_score']:.1f}/100")
                    print(f"   📁 Size category: {json_output['size_analysis']['size_category']}")
                else:
                    print("   ⚠️  Could not parse JSON output")
            except json.JSONDecodeError:
                print("   ⚠️  Output is not valid JSON, but command succeeded")
        else:
            print(f"   ❌ Analyze command failed: {result.stderr}")
            return False
        
        # Test summary command
        print("   Testing summary command...")
        temp_dir = Path(test_session).parent
        result = subprocess.run([
            sys.executable, "size_reporter.py", "summary", str(temp_dir),
            "--format", "json"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Summary command successful")
        else:
            print(f"   ❌ Summary command failed: {result.stderr}")
        
        return True
        
    finally:
        # Cleanup
        test_session.unlink()


def test_payload_cli():
    """Test payload_cli.py functionality"""
    print("🧪 Testing payload_cli.py...")
    
    # Create test session
    test_session = create_test_session_file()
    
    try:
        # Test generate command
        print("   Testing generate command...")
        result = subprocess.run([
            sys.executable, "payload_cli.py", "generate", str(test_session),
            "--strategy", "adaptive", "--format", "json"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Generate command successful")
            # Parse and validate output
            try:
                output_lines = result.stdout.strip().split('\n')
                json_output = None
                for line in output_lines:
                    if line.startswith('{'):
                        json_output = json.loads(line)
                        break
                
                if json_output and "optimization_metrics" in json_output:
                    metrics = json_output["optimization_metrics"]
                    print(f"   📊 Generated {json_output['payloads_generated']} payloads")
                    print(f"   🗜️  Compression ratio: {metrics['compression_ratio']:.2f}x")
                    print(f"   🎯 Optimization score: {metrics['optimization_score']:.1f}/100")
                else:
                    print("   ⚠️  Could not parse JSON output")
            except json.JSONDecodeError:
                print("   ⚠️  Output is not valid JSON, but command succeeded")
        else:
            print(f"   ❌ Generate command failed: {result.stderr}")
            return False
        
        # Test compare command  
        print("   Testing compare command...")
        result = subprocess.run([
            sys.executable, "payload_cli.py", "compare", str(test_session),
            "--all-strategies", "--format", "json"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Compare command successful")
        else:
            print(f"   ❌ Compare command failed: {result.stderr}")
        
        return True
        
    finally:
        # Cleanup
        test_session.unlink()


def test_integration():
    """Test integration between tools"""
    print("🧪 Testing tool integration...")
    
    # Create test session
    test_session = create_test_session_file()
    temp_dir = Path(test_session).parent
    
    try:
        # Test batch processing with size_reporter
        print("   Testing batch analysis...")
        result = subprocess.run([
            sys.executable, "size_reporter.py", "batch", str(temp_dir),
            "--output", str(temp_dir / "batch_report.json"),
            "--format", "json", "--include-analytics"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Batch analysis successful")
            
            # Check if output file was created
            batch_report = temp_dir / "batch_report.json"
            if batch_report.exists():
                with open(batch_report) as f:
                    report_data = json.load(f)
                    
                if "summary_statistics" in report_data:
                    stats = report_data["summary_statistics"]
                    print(f"   📊 Analyzed {stats['successful_analyses']} sessions")
                    print(f"   💰 Total potential savings: ${stats['total_potential_savings']:.4f}")
                
                batch_report.unlink()  # Cleanup
            else:
                print("   ⚠️  Batch report file not created")
        else:
            print(f"   ❌ Batch analysis failed: {result.stderr}")
            return False
        
        # Test payload batch processing
        print("   Testing payload batch processing...")
        result = subprocess.run([
            sys.executable, "payload_cli.py", "batch", str(temp_dir),
            "--output", str(temp_dir), "--format", "json"
        ], capture_output=True, text=True, cwd=Path(__file__).parent)
        
        if result.returncode == 0:
            print("   ✅ Payload batch processing successful")
            
            # Check if output file was created
            batch_results = temp_dir / "batch_results.json"
            if batch_results.exists():
                batch_results.unlink()  # Cleanup
        else:
            print(f"   ❌ Payload batch processing failed: {result.stderr}")
        
        return True
        
    finally:
        # Cleanup
        test_session.unlink()


def test_size_categories_and_scoring():
    """Test size categories and optimization scoring (0-100 scale)"""
    print("🧪 Testing size categories and optimization scoring...")
    
    # Create test sessions of different sizes
    test_sessions = []
    
    # Small session (< 10K tokens)
    small_session_data = [
        {
            "type": "user", "uuid": "u1", "sessionId": "small", "timestamp": "2025-09-09T04:00:00Z",
            "message": {"content": [{"type": "text", "text": "Hello world"}]}
        },
        {
            "type": "assistant", "uuid": "a1", "sessionId": "small", "timestamp": "2025-09-09T04:00:01Z",
            "message": {"content": [{"type": "text", "text": "Hello! How can I help you today?"}]}
        }
    ]
    
    # Medium session (10K-50K tokens) - simulate with longer content
    medium_content = "This is a longer conversation " * 200  # Simulate more content
    medium_session_data = [
        {
            "type": "user", "uuid": "u1", "sessionId": "medium", "timestamp": "2025-09-09T04:00:00Z",
            "message": {"content": [{"type": "text", "text": medium_content}]}
        },
        {
            "type": "assistant", "uuid": "a1", "sessionId": "medium", "timestamp": "2025-09-09T04:00:01Z",
            "message": {"content": [{"type": "text", "text": medium_content}]}
        }
    ]
    
    sessions_data = [
        ("small", small_session_data),
        ("medium", medium_session_data)
    ]
    
    try:
        for session_name, session_data in sessions_data:
            # Create test file
            temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
            for record in session_data:
                temp_file.write(json.dumps(record) + '\n')
            temp_file.close()
            test_sessions.append(Path(temp_file.name))
            
            # Test size categorization
            result = subprocess.run([
                sys.executable, "size_reporter.py", "analyze", str(temp_file.name),
                "--format", "json"
            ], capture_output=True, text=True, cwd=Path(__file__).parent)
            
            if result.returncode == 0:
                try:
                    output_lines = result.stdout.strip().split('\n')
                    json_output = None
                    for line in output_lines:
                        if line.startswith('{'):
                            json_output = json.loads(line)
                            break
                    
                    if json_output and "size_analysis" in json_output:
                        size_info = json_output["size_analysis"]
                        opt_info = json_output["optimization_analysis"]
                        
                        print(f"   📏 {session_name.upper()} session:")
                        print(f"      Tokens: {size_info['total_tokens']:,}")
                        print(f"      Category: {size_info['size_category']}")
                        print(f"      Optimization Score: {opt_info['optimization_score']:.1f}/100")
                        print(f"      Potential Savings: {opt_info['savings_percent']:.1f}%")
                        
                        # Validate scoring ranges
                        score = opt_info['optimization_score']
                        if 0 <= score <= 100:
                            print(f"      ✅ Score within valid range (0-100)")
                        else:
                            print(f"      ❌ Score outside valid range: {score}")
                            
                except json.JSONDecodeError:
                    print(f"   ❌ Could not parse output for {session_name} session")
            else:
                print(f"   ❌ Analysis failed for {session_name} session: {result.stderr}")
        
        print("   ✅ Size categories and scoring validation complete")
        return True
        
    finally:
        # Cleanup
        for session_file in test_sessions:
            session_file.unlink()


def main():
    """Run all tests"""
    print("🚀 Starting CLI tools integration tests...\n")
    
    # Check if we're in the right directory
    current_dir = Path.cwd()
    if not (current_dir / "size_reporter.py").exists():
        print("❌ Please run this test from the session-optimizer directory")
        return 1
    
    tests = [
        ("Size Reporter", test_size_reporter),
        ("Payload CLI", test_payload_cli), 
        ("Tool Integration", test_integration),
        ("Size Categories & Scoring", test_size_categories_and_scoring)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n{'='*50}")
        print(f"Running {test_name} Tests")
        print('='*50)
        
        try:
            if test_func():
                print(f"✅ {test_name} tests PASSED")
                passed += 1
            else:
                print(f"❌ {test_name} tests FAILED") 
                failed += 1
        except Exception as e:
            print(f"❌ {test_name} tests FAILED with exception: {e}")
            failed += 1
    
    print(f"\n{'='*50}")
    print(f"Test Results Summary")
    print('='*50)
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📊 Success Rate: {passed/(passed+failed)*100:.1f}%")
    
    if failed == 0:
        print("\n🎉 All tests passed! CLI tools are ready for use.")
        return 0
    else:
        print(f"\n⚠️  {failed} test suite(s) failed. Please check the errors above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())