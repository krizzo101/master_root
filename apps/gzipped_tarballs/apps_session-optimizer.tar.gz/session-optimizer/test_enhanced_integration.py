#!/usr/bin/env python3
"""
Test Enhanced Claude Format Adapter integration with SessionAnalyticsEngine
Validates the robust .jsonl parsing and full compatibility.
"""

import sys
import json
from pathlib import Path

# Add src to path for imports
sys.path.append(str(Path(__file__).parent / "src"))

from enhanced_claude_format_adapter import (
    EnhancedClaudeFormatAdapter, 
    AdapterConfig,
    create_enhanced_session_analytics_engine
)
from session_analytics_engine import SessionAnalyticsEngine

def test_enhanced_adapter_compatibility():
    """Test the enhanced adapter with SessionAnalyticsEngine"""
    
    print("🚀 Testing Enhanced Claude Format Adapter")
    print("=" * 50)
    
    # Find sample Claude .jsonl files
    claude_projects = Path("/home/opsvi/.claude/projects")
    sample_files = list(claude_projects.glob("**/*.jsonl"))[:3]
    
    if not sample_files:
        print("❌ No Claude session files found for testing")
        return False
    
    print(f"🔍 Testing with {len(sample_files)} sample files...")
    
    # Test 1: Enhanced adapter direct parsing
    print("\n📊 Test 1: Enhanced adapter MessageNode parsing")
    adapter = EnhancedClaudeFormatAdapter(AdapterConfig(preserve_all_metadata=True))
    
    adapter_results = []
    for sample_file in sample_files:
        try:
            print(f"  Parsing {sample_file.name}...")
            nodes = adapter.parse_session_file(sample_file)
            
            adapter_results.append({
                "file": sample_file.name,
                "success": True,
                "node_count": len(nodes),
                "tool_calls": sum(len(node.tool_calls) for node in nodes),
                "tool_results": sum(len(node.tool_results) for node in nodes),
                "node_types": list(set(node.node_type for node in nodes))
            })
            
        except Exception as e:
            adapter_results.append({
                "file": sample_file.name,
                "success": False,
                "error": str(e)
            })
    
    # Test 2: Enhanced SessionAnalyticsEngine integration
    print("\n🔧 Test 2: Enhanced SessionAnalyticsEngine integration")
    enhanced_engine = create_enhanced_session_analytics_engine(adapter)
    
    analytics_results = []
    for sample_file in sample_files:
        try:
            print(f"  Analyzing {sample_file.name} with enhanced engine...")
            report = enhanced_engine.analyze_session(sample_file)
            
            analytics_results.append({
                "file": sample_file.name,
                "success": True,
                "session_id": report.session_context.session_id,
                "conversation_length": report.conversation_flow.conversation_length,
                "tool_count": sum(report.tool_usage.tool_counts.values()),
                "complexity": report.complexity_rating,
                "optimization_score": report.optimization_score,
                "patterns": report.patterns_detected
            })
            
        except Exception as e:
            analytics_results.append({
                "file": sample_file.name,
                "success": False,
                "error": str(e)
            })
    
    # Test 3: Standard engine comparison
    print("\n🔍 Test 3: Comparison with standard SessionAnalyticsEngine")
    standard_engine = SessionAnalyticsEngine()
    
    standard_results = []
    for sample_file in sample_files:
        try:
            print(f"  Analyzing {sample_file.name} with standard engine...")
            report = standard_engine.analyze_session(sample_file)
            
            standard_results.append({
                "file": sample_file.name,
                "success": True,
                "conversation_length": report.conversation_flow.conversation_length,
                "tool_count": sum(report.tool_usage.tool_counts.values()),
                "complexity": report.complexity_rating
            })
            
        except Exception as e:
            standard_results.append({
                "file": sample_file.name,
                "success": False,
                "error": str(e)
            })
    
    # Results comparison
    print("\n📋 Results Analysis:")
    print("=" * 80)
    print(f"{'File':<25} {'Enhanced':<12} {'Standard':<12} {'Improvement':<15}")
    print("=" * 80)
    
    improvements = []
    for i, file_name in enumerate([f.name for f in sample_files]):
        enhanced = analytics_results[i]
        standard = standard_results[i]
        
        enhanced_status = "✅ SUCCESS" if enhanced["success"] else "❌ FAIL"
        standard_status = "✅ SUCCESS" if standard["success"] else "❌ FAIL"
        
        improvement = "NONE"
        if enhanced["success"] and not standard["success"]:
            improvement = "FIXED_PARSING"
        elif enhanced["success"] and standard["success"]:
            # Compare tool extraction
            enhanced_tools = enhanced["tool_count"]
            standard_tools = standard["tool_count"]
            if enhanced_tools > standard_tools:
                improvement = f"+{enhanced_tools - standard_tools} TOOLS"
            elif enhanced_tools == standard_tools:
                improvement = "EQUIVALENT"
        
        improvements.append(improvement)
        print(f"{file_name:<25} {enhanced_status:<12} {standard_status:<12} {improvement:<15}")
    
    # Summary statistics
    print("\n📈 Enhancement Summary:")
    enhanced_success = sum(1 for r in analytics_results if r["success"])
    standard_success = sum(1 for r in standard_results if r["success"])
    
    print(f"   Enhanced adapter success rate: {enhanced_success}/{len(sample_files)} ({enhanced_success/len(sample_files)*100:.1f}%)")
    print(f"   Standard engine success rate: {standard_success}/{len(sample_files)} ({standard_success/len(sample_files)*100:.1f}%)")
    
    if enhanced_success > standard_success:
        print("   ✅ Enhanced adapter improves compatibility!")
    elif enhanced_success == standard_success:
        print("   ⚖️ Enhanced adapter maintains compatibility")
    else:
        print("   ⚠️ Enhanced adapter needs improvement")
    
    # Tool extraction comparison
    if enhanced_success > 0:
        enhanced_avg_tools = sum(r["tool_count"] for r in analytics_results if r["success"]) / enhanced_success
        if standard_success > 0:
            standard_avg_tools = sum(r["tool_count"] for r in standard_results if r["success"]) / standard_success
            print(f"   Enhanced avg tools per session: {enhanced_avg_tools:.1f}")
            print(f"   Standard avg tools per session: {standard_avg_tools:.1f}")
            
            if enhanced_avg_tools > standard_avg_tools:
                print("   ✅ Enhanced adapter extracts more tool data!")
    
    return enhanced_success >= standard_success

def test_specific_claude_features():
    """Test specific Claude format features and edge cases"""
    
    print("\n🧪 Test 4: Claude-specific feature handling")
    adapter = EnhancedClaudeFormatAdapter()
    
    # Test various Claude record types
    test_records = [
        {
            "type": "summary",
            "summary": "Test session summary",
            "sessionId": "test-123"
        },
        {
            "type": "user",
            "uuid": "user-uuid",
            "timestamp": "2025-09-09T04:25:35.126Z",
            "message": {
                "role": "user",
                "content": "Hello, can you help me?"
            }
        },
        {
            "type": "assistant",
            "uuid": "asst-uuid",
            "parentUuid": "user-uuid",
            "timestamp": "2025-09-09T04:25:40.126Z",
            "message": {
                "content": [
                    {"type": "text", "text": "I'll help you with that."},
                    {
                        "type": "tool_use",
                        "id": "tool-123",
                        "name": "TodoWrite",
                        "input": {"todos": [{"content": "Help user", "status": "pending"}]}
                    }
                ]
            }
        },
        {
            "type": "user",
            "uuid": "user-result-uuid",
            "parentUuid": "asst-uuid",
            "toolUseResult": {
                "tool_use_id": "tool-123",
                "content": "Todos have been modified successfully"
            }
        }
    ]
    
    print("   Testing Claude record parsing:")
    success_count = 0
    
    for i, record in enumerate(test_records):
        try:
            node = adapter._parse_record_to_node(record, "test-session")
            if node:
                print(f"   ✅ Record {i+1} ({record['type']}): Parsed successfully")
                print(f"      Node type: {node.node_type}, Tool calls: {len(node.tool_calls)}")
                success_count += 1
            else:
                print(f"   ❌ Record {i+1} ({record['type']}): Returned None")
        except Exception as e:
            print(f"   ❌ Record {i+1} ({record['type']}): Error - {e}")
    
    print(f"\n   Claude feature parsing: {success_count}/{len(test_records)} successful")
    
    return success_count == len(test_records)

def test_streaming_performance():
    """Test streaming performance for large files"""
    
    print("\n⚡ Test 5: Streaming performance")
    adapter = EnhancedClaudeFormatAdapter()
    
    # Find largest available file for streaming test
    claude_projects = Path("/home/opsvi/.claude/projects")
    all_files = list(claude_projects.glob("**/*.jsonl"))
    
    if not all_files:
        print("   ⚠️ No files available for streaming test")
        return True
    
    # Sort by size and take largest
    largest_file = max(all_files, key=lambda f: f.stat().st_size)
    file_size_mb = largest_file.stat().st_size / (1024 * 1024)
    
    print(f"   Testing streaming with {largest_file.name} ({file_size_mb:.1f} MB)")
    
    try:
        node_count = 0
        for node in adapter.streaming_parse(largest_file):
            node_count += 1
            if node_count % 100 == 0:
                print(f"   Streamed {node_count} nodes...", end='\r')
        
        print(f"\n   ✅ Successfully streamed {node_count} nodes from {file_size_mb:.1f} MB file")
        return True
        
    except Exception as e:
        print(f"\n   ❌ Streaming failed: {e}")
        return False

if __name__ == "__main__":
    print("🧪 Enhanced Claude Format Adapter - Comprehensive Testing")
    print("=" * 60)
    
    all_tests_passed = True
    
    try:
        # Run all tests
        all_tests_passed &= test_enhanced_adapter_compatibility()
        all_tests_passed &= test_specific_claude_features()
        all_tests_passed &= test_streaming_performance()
        
        print("\n" + "=" * 60)
        if all_tests_passed:
            print("🎉 ALL TESTS PASSED - Enhanced adapter is production ready!")
            print("\n💡 Key improvements:")
            print("   ✅ Full SessionAnalyticsEngine compatibility")
            print("   ✅ Robust .jsonl parsing with error handling")
            print("   ✅ Complete tool call and result extraction")
            print("   ✅ Support for all Claude message types")
            print("   ✅ Streaming support for large files")
            print("   ✅ Enhanced metadata preservation")
            
        else:
            print("⚠️ Some tests failed - Review and fix issues")
            
    except Exception as e:
        print(f"❌ Test execution failed: {e}")
        import traceback
        traceback.print_exc()