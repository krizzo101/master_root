#!/usr/bin/env python3
"""
Test Suite for GPT-5 Payload Generation System
Tests memory-efficient streaming for 4.5M token sessions and validates Phase 1 results.
"""

import json
import time
import tempfile
from pathlib import Path
from typing import Dict, Any, List
import unittest
import os
import sys

# Add src directory to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from gpt5_payload_system import GPT5PayloadSystem, GPT5OptimizationConfig
from token_count_analyzer import TokenCountAnalyzer
from chunking_engine import ChunkingEngine
from payload_generator import PayloadGenerator
from size_analyzer import SizeAnalyzer
from claude_format_adapter import ClaudeFormatAdapter


class TestGPT5PayloadSystem(unittest.TestCase):
    """Test suite for GPT-5 payload generation system"""
    
    def setUp(self):
        """Set up test environment"""
        self.config = GPT5OptimizationConfig(
            enable_streaming=True,
            enable_parallel_processing=False,  # Disable for testing
            max_workers=1,
            memory_limit_mb=1024
        )
        self.system = GPT5PayloadSystem(self.config)
        self.test_data_dir = Path(__file__).parent / "test_data"
        self.test_data_dir.mkdir(exist_ok=True)
    
    def create_test_session_file(self, token_count: int, 
                               file_name: str = "test_session.jsonl") -> Path:
        """Create a test Claude .jsonl session file with specified token count"""
        test_file = self.test_data_dir / file_name
        
        # Calculate approximate number of messages needed
        # Rough estimate: 100 tokens per message
        message_count = max(1, token_count // 100)
        
        session_id = "test_session_001"
        timestamp = "2025-09-09T00:00:00Z"
        
        with open(test_file, 'w', encoding='utf-8') as f:
            # User message
            user_message = {
                "type": "user",
                "uuid": "user_001",
                "sessionId": session_id,
                "timestamp": timestamp,
                "message": {
                    "content": "Test user message " + "x" * (token_count // message_count)
                }
            }
            f.write(json.dumps(user_message) + "\n")
            
            # Assistant messages with tool usage
            for i in range(message_count - 1):
                if i % 3 == 0:  # Every third message has tools
                    assistant_message = {
                        "type": "assistant",
                        "uuid": f"assistant_{i:03d}",
                        "sessionId": session_id,
                        "timestamp": timestamp,
                        "message": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": f"Test assistant response {i} " + "content " * 50
                                },
                                {
                                    "type": "tool_use",
                                    "id": f"tool_{i}",
                                    "name": "Read",
                                    "input": {"file_path": f"/test/file_{i}.py"}
                                }
                            ]
                        }
                    }
                else:
                    assistant_message = {
                        "type": "assistant", 
                        "uuid": f"assistant_{i:03d}",
                        "sessionId": session_id,
                        "timestamp": timestamp,
                        "message": {
                            "content": f"Test assistant response {i} " + "content " * 100
                        }
                    }
                
                f.write(json.dumps(assistant_message) + "\n")
        
        return test_file
    
    def test_token_count_analyzer(self):
        """Test TokenCountAnalyzer with various input sizes"""
        print("\n=== Testing TokenCountAnalyzer ===")
        
        analyzer = TokenCountAnalyzer()
        
        # Test small session
        small_session = {"messages": [{"content": "Hello world"}]}
        result = analyzer.analyze_session_tokens(small_session)
        
        self.assertGreater(result.total_tokens, 0)
        self.assertEqual(result.size_category, "small")
        print(f"✓ Small session: {result.total_tokens} tokens, category: {result.size_category}")
        
        # Test chunking benefit estimation
        chunking_benefit = analyzer.estimate_chunking_benefit(100000, "adaptive")
        self.assertGreater(chunking_benefit["compression_ratio"], 1.0)
        self.assertGreater(chunking_benefit["cost_savings"], 0.0)
        print(f"✓ Chunking benefit: {chunking_benefit['compression_ratio']:.2f}x compression")
    
    def test_chunking_engine(self):
        """Test ChunkingEngine with different strategies"""
        print("\n=== Testing ChunkingEngine ===")
        
        engine = ChunkingEngine()
        
        # Create test session data
        large_session = {
            "session_id": "test_chunk",
            "messages": [
                {"type": "user", "content": "Test request " + "x" * 1000},
                {"type": "assistant", "content": "Test response " + "y" * 2000, 
                 "tool_calls": [{"name": "Read", "input": {"file_path": "/test.py"}}]},
                {"type": "user", "content": "Another request " + "z" * 1500},
                {"type": "assistant", "content": "Another response " + "w" * 1800}
            ]
        }
        
        # Test different strategies
        strategies = ["conversation", "tool_usage", "adaptive"]
        results = {}
        
        for strategy in strategies:
            result = engine.chunk_session(large_session, strategy)
            results[strategy] = result
            
            self.assertGreater(len(result.chunks), 0)
            self.assertEqual(result.strategy_used, strategy)
            print(f"✓ {strategy} strategy: {len(result.chunks)} chunks, "
                  f"{result.compression_ratio:.2f}x compression")
        
        # Compare strategies
        comparison = engine.compare_strategies(large_session)
        self.assertEqual(len(comparison), 3)
        print(f"✓ Strategy comparison: {list(comparison.keys())}")
    
    def test_payload_generator(self):
        """Test PayloadGenerator with different templates"""
        print("\n=== Testing PayloadGenerator ===")
        
        generator = PayloadGenerator()
        
        # Test conversational chunk
        conv_chunk = {
            "chunk_type": "conversation",
            "chunk_index": 0,
            "context_summary": "Test conversation about file operations",
            "messages": [
                {"type": "user", "content": "Please read the config file"},
                {"type": "assistant", "content": "I'll read the configuration file for you."}
            ]
        }
        
        payload = generator.generate_payload(conv_chunk)
        
        self.assertIn("messages", payload.payload)
        self.assertGreater(payload.estimated_tokens, 0)
        self.assertGreater(payload.quality_score, 0.0)
        print(f"✓ Conversational payload: {payload.estimated_tokens} tokens, "
              f"quality: {payload.quality_score:.2f}")
        
        # Test technical chunk  
        tech_chunk = {
            "chunk_type": "tool_workflow",
            "workflow_type": "file_ops",
            "tools_used": ["Read", "Write", "Edit"],
            "messages": [
                {"type": "assistant", "tool_calls": [{"name": "Read", "input": {"file_path": "/config.py"}}]}
            ]
        }
        
        tech_payload = generator.generate_payload(tech_chunk)
        self.assertEqual(tech_payload.payload_type, "technical")
        print(f"✓ Technical payload: {tech_payload.estimated_tokens} tokens")
    
    def test_size_analyzer(self):
        """Test SizeAnalyzer cost estimation and optimization analysis"""
        print("\n=== Testing SizeAnalyzer ===")
        
        analyzer = SizeAnalyzer()
        
        # Test cost analysis for different sizes
        test_sizes = [5000, 50000, 150000, 300000]
        
        for tokens in test_sizes:
            cost_breakdown = analyzer.analyze_session_cost(tokens)
            category = analyzer.categorize_session_size(tokens)
            
            self.assertGreater(cost_breakdown.total_cost, 0)
            self.assertIn(category, ["small", "medium", "large", "extra_large"])
            
            print(f"✓ {tokens:,} tokens: ${cost_breakdown.total_cost:.4f}, "
                  f"category: {category}, savings potential: "
                  f"{cost_breakdown.potential_savings_percent:.1f}%")
        
        # Test optimization analysis
        optimization = analyzer.analyze_optimization_potential(200000)
        self.assertGreater(optimization.optimization_score, 0)
        self.assertGreater(optimization.cost_savings, 0)
        print(f"✓ Optimization analysis: {optimization.optimization_score:.1f}/100 score, "
              f"${optimization.cost_savings:.2f} savings")
    
    def test_claude_format_adapter(self):
        """Test Claude format adapter with real .jsonl file"""
        print("\n=== Testing Claude Format Adapter ===")
        
        # Create test Claude session file
        test_file = self.create_test_session_file(10000, "claude_test.jsonl")
        
        adapter = ClaudeFormatAdapter()
        converted = adapter.convert_session_file(test_file)
        
        self.assertIn("session_id", converted)
        self.assertIn("messages", converted)
        self.assertGreater(len(converted["messages"]), 0)
        
        conversion_stats = converted.get("conversion_stats", {})
        print(f"✓ Converted Claude session: {conversion_stats.get('converted_messages', 0)} messages, "
              f"{conversion_stats.get('tool_calls_extracted', 0)} tool calls")
        
        # Test streaming conversion
        chunks = list(adapter.convert_streaming(test_file))
        self.assertGreater(len(chunks), 0)
        print(f"✓ Streaming conversion: {len(chunks)} chunks")
    
    def test_memory_efficient_streaming(self):
        """Test memory-efficient streaming for large sessions (4.5M+ tokens)"""
        print("\n=== Testing Memory-Efficient Streaming ===")
        
        # Create large test file (simulating 4.5M tokens)
        large_file = self.create_test_session_file(500000, "large_session.jsonl")  # Smaller for testing
        
        # Test streaming optimization
        chunks_processed = 0
        total_tokens = 0
        total_payloads = 0
        
        start_time = time.time()
        
        for chunk_result in self.system.optimize_session_streaming(large_file):
            chunks_processed += 1
            
            if not chunk_result.get("is_final", False):
                chunk_tokens = chunk_result.get("chunk_tokens", 0)
                payloads_count = chunk_result.get("payloads_generated", 0)
                
                total_tokens += chunk_tokens
                total_payloads += payloads_count
                
                print(f"  Chunk {chunks_processed}: {chunk_tokens} tokens, "
                      f"{payloads_count} payloads, "
                      f"compression: {chunk_result.get('chunk_compression', 1.0):.2f}x")
            else:
                # Final chunk with summary
                streaming_summary = chunk_result.get("streaming_summary", {})
                print(f"✓ Streaming complete: {streaming_summary}")
                break
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        self.assertGreater(chunks_processed, 1)
        self.assertGreater(total_tokens, 0)
        print(f"✓ Memory streaming test: {chunks_processed} chunks, "
              f"{total_tokens:,} tokens, {processing_time:.2f}s, "
              f"{total_payloads} payloads generated")
        
        # Verify memory efficiency
        tokens_per_second = total_tokens / processing_time if processing_time > 0 else 0
        print(f"✓ Performance: {tokens_per_second:,.0f} tokens/second")
        self.assertGreater(tokens_per_second, 1000)  # Should process at least 1K tokens/sec
    
    def test_end_to_end_optimization(self):
        """Test complete end-to-end optimization pipeline"""
        print("\n=== Testing End-to-End Optimization ===")
        
        # Create test session
        test_file = self.create_test_session_file(75000, "e2e_test.jsonl")
        
        # Run complete optimization
        start_time = time.time()
        result = self.system.optimize_session_file(test_file)
        end_time = time.time()
        
        self.assertTrue(result.success, f"Optimization failed: {result.error_message}")
        self.assertIsNotNone(result.token_analysis)
        self.assertIsNotNone(result.chunking_result)
        self.assertIsNotNone(result.optimization_analysis)
        self.assertGreater(len(result.generated_payloads), 0)
        
        stats = result.processing_stats
        print(f"✓ End-to-end optimization successful:")
        print(f"  Original tokens: {stats.get('original_tokens', 0):,}")
        print(f"  Optimized tokens: {stats.get('optimized_tokens', 0):,}")
        print(f"  Compression ratio: {stats.get('compression_ratio', 1.0):.2f}x")
        print(f"  Strategy used: {stats.get('strategy_used', 'unknown')}")
        print(f"  Cost savings: ${stats.get('cost_savings', 0.0):.4f}")
        print(f"  Processing time: {stats.get('processing_time_seconds', 0.0):.2f}s")
        print(f"  Payloads generated: {stats.get('payload_count', 0)}")
        
        # Validate Phase 1 targets
        compression_ratio = stats.get('compression_ratio', 1.0)
        self.assertGreaterEqual(compression_ratio, 1.5, "Should achieve meaningful compression")
        self.assertLessEqual(compression_ratio, 4.0, "Compression ratio should be realistic")
        
        cost_savings = stats.get('cost_savings', 0.0)
        self.assertGreater(cost_savings, 0, "Should achieve cost savings")
    
    def test_batch_optimization(self):
        """Test batch optimization of multiple sessions"""
        print("\n=== Testing Batch Optimization ===")
        
        # Create multiple test files
        test_files = []
        token_sizes = [15000, 45000, 85000, 120000]
        
        for i, tokens in enumerate(token_sizes):
            test_file = self.create_test_session_file(tokens, f"batch_test_{i}.jsonl")
            test_files.append(test_file)
        
        # Run batch optimization
        start_time = time.time()
        batch_summary = self.system.batch_optimize_sessions(test_files)
        end_time = time.time()
        
        summary = batch_summary["summary"]
        metrics = batch_summary["optimization_metrics"]
        
        self.assertEqual(summary["total_sessions"], len(test_files))
        self.assertGreater(summary["successful_optimizations"], 0)
        self.assertGreater(metrics["total_tokens_saved"], 0)
        
        print(f"✓ Batch optimization results:")
        print(f"  Sessions processed: {summary['total_sessions']}")
        print(f"  Success rate: {summary['success_rate']:.1f}%")
        print(f"  Average compression: {metrics['average_compression_ratio']:.2f}x")
        print(f"  Total cost savings: ${metrics['total_cost_savings']:.4f}")
        print(f"  Processing time: {summary['total_processing_time_seconds']:.2f}s")
        
        # Performance validation
        performance = batch_summary["performance_analysis"]
        tokens_per_second = performance["tokens_per_second"]
        self.assertGreater(tokens_per_second, 500, "Should process at least 500 tokens/second")
        print(f"  Performance: {tokens_per_second:,} tokens/second")
    
    def test_phase_1_validation(self):
        """Validate that system meets Phase 1 testing specifications"""
        print("\n=== Phase 1 Specification Validation ===")
        
        # Test compression ratios match Phase 1 results
        engine = ChunkingEngine()
        test_session = {
            "session_id": "phase1_validation",
            "messages": [
                {"type": "user", "content": "Test user message " * 100},
                {"type": "assistant", "content": "Test response " * 150,
                 "tool_calls": [{"name": "Read", "input": {"file_path": "/test.py"}}] * 5},
                {"type": "user", "content": "Another message " * 80},
                {"type": "assistant", "content": "Final response " * 120}
            ] * 10  # Repeat to get substantial content
        }
        
        # Test each strategy
        conversation_result = engine.chunk_session(test_session, "conversation")
        tool_result = engine.chunk_session(test_session, "tool_usage")
        adaptive_result = engine.chunk_session(test_session, "adaptive")
        
        print(f"✓ Compression ratios achieved:")
        print(f"  Conversation: {conversation_result.compression_ratio:.2f}x (target: 2.36x)")
        print(f"  Tool usage: {tool_result.compression_ratio:.2f}x (target: 3.14x)")
        print(f"  Adaptive: {adaptive_result.compression_ratio:.2f}x (target: 2.23x)")
        
        # Validate ranges (allow some variance from Phase 1 targets)
        self.assertGreater(conversation_result.compression_ratio, 1.5)
        self.assertGreater(tool_result.compression_ratio, 2.0)
        self.assertGreater(adaptive_result.compression_ratio, 1.5)
        
        # Test cost estimation accuracy
        analyzer = SizeAnalyzer()
        cost_breakdown = analyzer.analyze_session_cost(293755)  # Phase 1 current session size
        
        print(f"✓ Cost analysis for 293,755 tokens:")
        print(f"  Estimated cost: ${cost_breakdown.total_cost:.2f} (Phase 1: $7.34)")
        print(f"  Potential savings: {cost_breakdown.potential_savings_percent:.1f}%")
        
        # Should be within reasonable range of Phase 1 estimate
        self.assertGreater(cost_breakdown.total_cost, 5.0)
        self.assertLess(cost_breakdown.total_cost, 10.0)
        
        # Test large session handling (4.5M tokens from Phase 1)
        large_session_analysis = analyzer.analyze_optimization_potential(4576598)
        print(f"✓ Large session (4.5M tokens) analysis:")
        print(f"  Size category: {large_session_analysis.size_category}")
        print(f"  Optimization score: {large_session_analysis.optimization_score}/100")
        print(f"  Potential savings: ${large_session_analysis.cost_savings:.2f}")
        
        self.assertEqual(large_session_analysis.size_category, "extra_large")
        self.assertGreater(large_session_analysis.optimization_score, 80)
        self.assertGreater(large_session_analysis.cost_savings, 50.0)
    
    def test_system_status(self):
        """Test system status and component health"""
        print("\n=== Testing System Status ===")
        
        status = self.system.get_system_status()
        
        # Check all components loaded
        components = status["system_info"]["components_loaded"]
        for component, loaded in components.items():
            self.assertTrue(loaded, f"Component {component} not loaded")
            print(f"✓ {component}: loaded")
        
        # Check configuration
        config = status["system_info"]["configuration"]
        self.assertIn("gpt5_model", config)
        self.assertIn("max_chunk_tokens", config)
        print(f"✓ Configuration validated")
        
        # Check compression capabilities
        capabilities = status["compression_capabilities"]
        print(f"✓ Compression capabilities:")
        for strategy, ratio in capabilities.items():
            print(f"  {strategy}: {ratio}")
        
        # Check Phase 1 validation
        phase1 = status["phase_1_validation"]
        print(f"✓ Phase 1 validation status:")
        for key, value in phase1.items():
            print(f"  {key}: {value}")
    
    def tearDown(self):
        """Clean up test files"""
        # Remove test data directory
        import shutil
        if self.test_data_dir.exists():
            shutil.rmtree(self.test_data_dir)


def run_performance_benchmark():
    """Run performance benchmark for large sessions"""
    print("\n" + "="*60)
    print("PERFORMANCE BENCHMARK - Large Session Processing")
    print("="*60)
    
    config = GPT5OptimizationConfig(
        enable_streaming=True,
        memory_limit_mb=1024
    )
    system = GPT5PayloadSystem(config)
    
    # Create progressively larger test files
    test_sizes = [100000, 500000, 1000000, 2000000]  # Token counts
    
    for tokens in test_sizes:
        print(f"\nBenchmarking {tokens:,} token session...")
        
        # Create test file
        test_dir = Path("benchmark_test_data")
        test_dir.mkdir(exist_ok=True)
        
        # Simplified test file creation for benchmarking
        test_file = test_dir / f"benchmark_{tokens}.jsonl"
        message_count = tokens // 200  # ~200 tokens per message
        
        with open(test_file, 'w') as f:
            for i in range(message_count):
                message = {
                    "type": "assistant" if i % 2 else "user",
                    "uuid": f"msg_{i}",
                    "timestamp": "2025-09-09T00:00:00Z",
                    "message": {"content": "Test content " + "x" * 190}
                }
                f.write(json.dumps(message) + "\n")
        
        # Benchmark streaming analysis
        start_time = time.time()
        
        try:
            chunk_count = 0
            total_processed_tokens = 0
            
            for chunk_result in system.optimize_session_streaming(test_file):
                chunk_count += 1
                if not chunk_result.get("is_final", False):
                    total_processed_tokens += chunk_result.get("chunk_tokens", 0)
            
            end_time = time.time()
            processing_time = end_time - start_time
            
            tokens_per_second = total_processed_tokens / processing_time if processing_time > 0 else 0
            memory_per_token = 1024 / total_processed_tokens if total_processed_tokens > 0 else 0
            
            print(f"  ✓ Processed: {total_processed_tokens:,} tokens")
            print(f"  ✓ Chunks: {chunk_count}")
            print(f"  ✓ Time: {processing_time:.2f}s")
            print(f"  ✓ Speed: {tokens_per_second:,.0f} tokens/second")
            print(f"  ✓ Memory efficiency: {memory_per_token:.6f} MB/token")
            
            # Validate performance targets
            if tokens >= 1000000:  # 1M+ tokens
                assert tokens_per_second > 5000, f"Large session processing too slow: {tokens_per_second:,.0f} tokens/sec"
                print(f"  ✓ Performance target met for {tokens:,} tokens")
        
        except Exception as e:
            print(f"  ✗ Benchmark failed: {e}")
        
        finally:
            # Cleanup
            if test_file.exists():
                test_file.unlink()
    
    # Cleanup benchmark directory
    import shutil
    if Path("benchmark_test_data").exists():
        shutil.rmtree("benchmark_test_data")


if __name__ == "__main__":
    print("GPT-5 Payload Generation System Test Suite")
    print("==========================================")
    
    # Run unit tests
    unittest.main(argv=[''], exit=False, verbosity=2)
    
    # Run performance benchmark
    try:
        run_performance_benchmark()
    except Exception as e:
        print(f"Benchmark failed: {e}")
    
    print("\n" + "="*60)
    print("TEST SUITE COMPLETED")
    print("="*60)