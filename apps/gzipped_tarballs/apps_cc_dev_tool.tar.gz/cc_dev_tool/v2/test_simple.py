#!/usr/bin/env python3
"""
Simple test of TITAN V2 token pool without Claude CLI
"""

import os
import sys
from pathlib import Path

# Force unset ANTHROPIC_API_KEY
os.environ.pop('ANTHROPIC_API_KEY', None)
os.environ['ANTHROPIC_API_KEY'] = ''

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent))

# Import titan components
from titan import TokenPool, TitanOrchestrator

def test_token_pool():
    """Test token pool initialization and management."""
    print("\n=== Testing Token Pool ===")
    
    try:
        # Initialize pool
        pool = TokenPool("/home/opsvi/master_root/.secrets")
        print(f"✓ Token pool initialized with {pool.total_tokens()} tokens")
        
        # Test token acquisition
        token1 = pool.acquire("test_agent_1")
        print(f"✓ Acquired token for agent 1: token #{token1['index']}")
        
        token2 = pool.acquire("test_agent_2")
        print(f"✓ Acquired token for agent 2: token #{token2['index']}")
        
        # Check availability
        print(f"✓ Available tokens: {pool.available_count()}")
        print(f"✓ Tokens in use: {len(pool.in_use)}")
        
        # Release tokens
        pool.release(token1['index'])
        pool.release(token2['index'])
        print(f"✓ Released tokens, available now: {pool.available_count()}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_orchestrator_init():
    """Test orchestrator initialization."""
    print("\n=== Testing Orchestrator Init ===")
    
    try:
        # Initialize orchestrator
        orchestrator = TitanOrchestrator("/home/opsvi/master_root/.secrets")
        pool = orchestrator.initialize_tokens()
        print(f"✓ Orchestrator initialized")
        print(f"✓ Token pool ready with {pool.total_tokens()} tokens")
        
        # Check environment
        if os.environ.get('ANTHROPIC_API_KEY', '') == '':
            print(f"✓ ANTHROPIC_API_KEY is properly unset")
        else:
            print(f"✗ ANTHROPIC_API_KEY is not empty: {os.environ.get('ANTHROPIC_API_KEY')}")
            
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def main():
    """Run all tests."""
    print("="*60)
    print("TITAN V2 SIMPLE TEST SUITE")
    print("="*60)
    
    results = []
    
    # Run tests
    results.append(("Token Pool", test_token_pool()))
    results.append(("Orchestrator Init", test_orchestrator_init()))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    for name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{name}: {status}")
    
    all_passed = all(r[1] for r in results)
    
    if all_passed:
        print("\n✓ All tests passed!")
    else:
        print("\n✗ Some tests failed")
        sys.exit(1)

if __name__ == "__main__":
    main()