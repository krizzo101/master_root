#!/usr/bin/env python3
"""
Test real Claude CLI with simple command
"""

import subprocess
import os
import json
import tempfile
from pathlib import Path

# Force unset ANTHROPIC_API_KEY
os.environ.pop('ANTHROPIC_API_KEY', None)
os.environ['ANTHROPIC_API_KEY'] = ''

# Load a token
import sys
sys.path.insert(0, str(Path(__file__).parent))
from titan import TokenPool

def test_real_claude():
    """Test with real Claude CLI"""
    print("Testing real Claude CLI...")
    
    # Get one token
    pool = TokenPool("/home/opsvi/master_root/.secrets")
    print(f"Loaded {pool.total_tokens()} tokens")
    
    token_info = pool.acquire("test_agent")
    token = token_info['token']
    print(f"Using token #{token_info['index']}")
    
    # Create temp workspace
    with tempfile.TemporaryDirectory() as tmpdir:
        workspace = Path(tmpdir)
        
        # Create minimal MCP config
        mcp_config = workspace / "minimal_mcp.json"
        mcp_config.write_text('{"mcpServers": {}}')
        
        # Build command
        import uuid
        session_id = str(uuid.uuid4())
        
        cmd = [
            'claude',
            '-p',  # Print mode
            '--model', 'sonnet',
            '--output-format', 'json',
            '--session-id', session_id,
            '--permission-mode', 'bypassPermissions',
            '--strict-mcp-config',
            '--mcp-config', str(mcp_config),
            '--',
            'Say hello in exactly 5 words'
        ]
        
        # Prepare environment
        env = os.environ.copy()
        env.pop('ANTHROPIC_API_KEY', None)
        env['ANTHROPIC_API_KEY'] = ''
        env['CLAUDE_CODE_TOKEN'] = token
        
        print(f"Running command: {' '.join(cmd[:5])}...")
        
        try:
            # Run with timeout
            result = subprocess.run(
                cmd,
                env=env,
                cwd=str(workspace),
                capture_output=True,
                text=True,
                timeout=30
            )
            
            print(f"Return code: {result.returncode}")
            
            if result.stdout:
                try:
                    output = json.loads(result.stdout)
                    print(f"Success! Got response: {output.get('result', 'no result')[:100]}")
                except json.JSONDecodeError:
                    print(f"Raw output: {result.stdout[:500]}")
                    
            if result.stderr:
                print(f"Stderr: {result.stderr[:500]}")
                
            # Release token
            pool.release(token_info['index'])
            
            return result.returncode == 0
            
        except subprocess.TimeoutExpired:
            print("Command timed out after 30 seconds")
            pool.release(token_info['index'])
            return False
        except Exception as e:
            print(f"Error: {e}")
            pool.release(token_info['index'])
            return False

if __name__ == "__main__":
    success = test_real_claude()
    if success:
        print("\n✓ Test passed!")
    else:
        print("\n✗ Test failed")
        sys.exit(1)