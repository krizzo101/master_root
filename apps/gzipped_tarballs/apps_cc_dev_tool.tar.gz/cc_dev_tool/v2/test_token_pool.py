#!/usr/bin/env python3
"""
Test script for token pool functionality
"""

import asyncio
import sys
import time
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from token_pool import TokenPool


async def test_async_pool():
    """Test asynchronous token pool operations."""
    print("\n=== Testing Async Token Pool ===\n")
    
    # Initialize pool
    pool = TokenPool("/home/opsvi/master_root/.secrets")
    print(f"Pool initialized with {pool.total_tokens()} tokens")
    
    # Test concurrent acquisitions
    async def acquire_and_use(agent_id: str, duration: float):
        """Simulate an agent using a token."""
        async with pool.acquire_async(agent_id) as token_info:
            print(f"[{agent_id}] Acquired token #{token_info['index']}")
            await asyncio.sleep(duration)
            print(f"[{agent_id}] Releasing token #{token_info['index']}")
            return token_info['index']
    
    # Launch concurrent agents
    print("\nLaunching concurrent agents...")
    tasks = [
        acquire_and_use("agent_1", 2),
        acquire_and_use("agent_2", 1),
        acquire_and_use("agent_3", 3),
        acquire_and_use("agent_4", 1.5),
    ]
    
    results = await asyncio.gather(*tasks)
    print(f"\nAgents used tokens: {results}")
    
    # Test pool exhaustion
    print("\n=== Testing Pool Exhaustion ===\n")
    
    # Acquire all tokens
    acquired = []
    print("Acquiring all tokens...")
    for i in range(pool.total_tokens()):
        token_info = pool.acquire(f"exhaustion_test_{i}")
        acquired.append(token_info)
        print(f"  Acquired #{token_info['index']}")
    
    print(f"All {len(acquired)} tokens acquired")
    print(f"Available tokens: {pool.available_count()}")
    
    # Try to acquire one more (should wait or fail)
    print("\nTrying to acquire one more token (should wait)...")
    
    async def try_acquire_when_exhausted():
        try:
            # This should timeout since no tokens available
            async with asyncio.timeout(2):
                async with pool.acquire_async("waiting_agent") as token_info:
                    print(f"Unexpectedly acquired token #{token_info['index']}")
        except asyncio.TimeoutError:
            print("Correctly timed out waiting for token")
    
    await try_acquire_when_exhausted()
    
    # Release all tokens
    print("\nReleasing all tokens...")
    for token_info in acquired:
        pool.release(token_info['index'])
    
    print(f"Available tokens after release: {pool.available_count()}")


def test_sync_pool():
    """Test synchronous token pool operations."""
    print("\n=== Testing Sync Token Pool ===\n")
    
    # Initialize pool
    pool = TokenPool("/home/opsvi/master_root/.secrets")
    print(f"Pool initialized with {pool.total_tokens()} tokens")
    
    # Test basic acquire/release
    print("\nTesting basic acquire/release...")
    
    token1 = pool.acquire("sync_agent_1")
    print(f"Agent 1 acquired token #{token1['index']}")
    
    token2 = pool.acquire("sync_agent_2")
    print(f"Agent 2 acquired token #{token2['index']}")
    
    # Check status
    print(f"Available: {pool.available_count()}, In use: {len(pool.in_use)}")
    
    # Release
    pool.release(token1['index'])
    print(f"Released token #{token1['index']}")
    
    pool.release(token2['index'])
    print(f"Released token #{token2['index']}")
    
    print(f"Available after release: {pool.available_count()}")
    
    # Test context manager
    print("\nTesting context manager...")
    with pool.acquire_context("context_agent") as token_info:
        print(f"Context manager acquired token #{token_info['index']}")
        print(f"Token is automatically released on exit")
    
    print(f"Available after context exit: {pool.available_count()}")


def test_secrets_validation():
    """Test secrets file validation."""
    print("\n=== Testing Secrets Validation ===\n")
    
    secrets_dir = Path("/home/opsvi/master_root/.secrets")
    
    # Check files exist
    key_file = secrets_dir / ".key"
    enc_file = secrets_dir / "tokens.encrypted"
    
    print(f"Secrets directory: {secrets_dir}")
    print(f"Key file exists: {key_file.exists()}")
    print(f"Encrypted file exists: {enc_file.exists()}")
    
    if key_file.exists() and enc_file.exists():
        # Try to load tokens
        try:
            pool = TokenPool(str(secrets_dir))
            print(f"Successfully loaded {pool.total_tokens()} tokens")
            
            # Show token info (without exposing values)
            print("\nToken validation (SHA-256 prefixes):")
            for i in range(min(5, pool.total_tokens())):
                import hashlib
                token_hash = hashlib.sha256(pool.tokens[i].encode()).hexdigest()
                print(f"  Token #{i}: {token_hash[:8]}... (length: {len(pool.tokens[i])})")
                
        except Exception as e:
            print(f"Failed to load tokens: {e}")
    else:
        print("Secrets files not found!")


def main():
    """Main test runner."""
    # FORCE unset ANTHROPIC_API_KEY
    import os
    os.environ.pop('ANTHROPIC_API_KEY', None)
    os.environ['ANTHROPIC_API_KEY'] = ''
    
    print("="*60)
    print("TOKEN POOL TEST SUITE")
    print("="*60)
    
    # Test secrets validation
    test_secrets_validation()
    
    # Test sync operations
    test_sync_pool()
    
    # Test async operations
    asyncio.run(test_async_pool())
    
    print("\n" + "="*60)
    print("ALL TESTS COMPLETED")
    print("="*60)


if __name__ == "__main__":
    main()