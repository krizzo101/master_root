#!/usr/bin/env python3
"""
Integration test for TITAN V2 with mock Claude CLI
"""

import asyncio
import os
import sys
import tempfile
import shutil
from pathlib import Path

# Force unset ANTHROPIC_API_KEY
os.environ.pop('ANTHROPIC_API_KEY', None)
os.environ['ANTHROPIC_API_KEY'] = ''

# Use mock claude for testing
os.environ['CLAUDE_BIN'] = str(Path(__file__).parent / 'mock_claude.py')

# Add to path
sys.path.insert(0, str(Path(__file__).parent))

from titan import TitanOrchestrator

async def test_full_pipeline():
    """Test the full TITAN pipeline with mock Claude."""
    print("\n=== Testing Full Pipeline ===")
    
    # Create temporary repo
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_path = Path(tmpdir) / "test_repo"
        repo_path.mkdir()
        
        # Initialize git repo
        os.system(f"cd {repo_path} && git init -b main && echo '# Test' > README.md && git add . && git commit -m 'Initial'")
        
        # Create workspace
        workspace = Path(tmpdir) / "workspace"
        workspace.mkdir()
        
        # Initialize orchestrator
        orchestrator = TitanOrchestrator("/home/opsvi/master_root/.secrets")
        
        try:
            # Run a simple job
            result = await orchestrator.run_job(
                prompt="Create a simple hello world script",
                repo_path=str(repo_path),
                workspace=str(workspace)
            )
            
            print(f"✓ Job completed: {result['job_id']}")
            print(f"✓ Success: {result['success']}")
            
            if result['success']:
                print(f"✓ Manifest: {result['manifest']}")
                print(f"✓ Archive: {result['archive']}")
                
                # Check results
                total_agents = len(result['results'])
                successful = sum(1 for r in result['results'].values() if r.get('success', False))
                
                print(f"✓ Agents run: {total_agents}")
                print(f"✓ Successful: {successful}")
                
                # Show sample results
                for agent, res in list(result['results'].items())[:3]:
                    status = "✓" if res.get('success') else "✗"
                    token = res.get('token_index', 'N/A')
                    print(f"  {status} {agent}: token #{token}")
                    
                return True
            else:
                print(f"✗ Job failed: {result.get('error')}")
                return False
                
        except Exception as e:
            print(f"✗ Error: {e}")
            import traceback
            traceback.print_exc()
            return False

def main():
    """Run integration test."""
    print("="*60)
    print("TITAN V2 INTEGRATION TEST")
    print("="*60)
    
    # Check mock claude
    mock_path = Path(__file__).parent / 'mock_claude.py'
    if mock_path.exists():
        print(f"✓ Mock Claude found: {mock_path}")
    else:
        print(f"✗ Mock Claude not found")
        sys.exit(1)
    
    # Run async test
    success = asyncio.run(test_full_pipeline())
    
    print("\n" + "="*60)
    if success:
        print("✓ Integration test PASSED")
    else:
        print("✗ Integration test FAILED")
        sys.exit(1)

if __name__ == "__main__":
    main()