"""Tests for OPSVI Assistant application."""

import pytest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from pathlib import Path
import json
import sys

# Add the app to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent))

from opsvi_assistant.core import (
    Assistant, ConversationHistory, AssistantConfig
)
from opsvi_assistant.cli import main


class TestAssistant:
    """Test suite for Assistant class."""

    @pytest.fixture
    def mock_llm_provider(self):
        """Create a mock LLM provider."""
        provider = Mock()
        provider.chat = Mock(return_value=Mock(content="Test response"))
        provider.achat = AsyncMock(return_value=Mock(content="Async test response"))
        return provider

    @pytest.fixture
    def assistant_config(self):
        """Create test assistant configuration."""
        return AssistantConfig(
            provider="test",
            model="gpt-5-mini",  # 2025 approved model
            api_key="test-key",
            max_tokens=1000,
            temperature=0.7
        )

    @pytest.fixture
    def assistant(self, assistant_config, mock_llm_provider):
        """Create test assistant instance."""
        with patch('opsvi_assistant.core.get_provider', return_value=mock_llm_provider):
            return Assistant(assistant_config)

    def test_assistant_init(self, assistant_config, mock_llm_provider):
        """Test assistant initialization."""
        with patch('opsvi_assistant.core.get_provider', return_value=mock_llm_provider):
            assistant = Assistant(assistant_config)
            assert assistant.config == assistant_config
            assert assistant.provider == mock_llm_provider
            assert isinstance(assistant.history, ConversationHistory)

    def test_ask_simple_question(self, assistant, mock_llm_provider):
        """Test asking a simple question."""
        response = assistant.ask("What is Python?")
        
        assert response == "Test response"
        mock_llm_provider.chat.assert_called_once()
        
        # Check conversation history
        assert len(assistant.history.messages) == 2
        assert assistant.history.messages[0]["role"] == "user"
        assert assistant.history.messages[0]["content"] == "What is Python?"
        assert assistant.history.messages[1]["role"] == "assistant"
        assert assistant.history.messages[1]["content"] == "Test response"

    @pytest.mark.asyncio
    async def test_ask_async(self, assistant, mock_llm_provider):
        """Test async asking."""
        response = await assistant.aask("Explain async/await")
        
        assert response == "Async test response"
        mock_llm_provider.achat.assert_called_once()

    def test_code_generation(self, assistant, mock_llm_provider):
        """Test code generation."""
        mock_llm_provider.chat.return_value = Mock(
            content="```python\ndef hello():\n    print('Hello')\n```"
        )
        
        response = assistant.generate_code(
            "Write a hello function",
            language="python"
        )
        
        assert "def hello():" in response
        assert "print('Hello')" in response

    def test_code_analysis(self, assistant, mock_llm_provider):
        """Test code analysis."""
        code = """
        def calculate(x, y):
            return x + y
        """
        
        mock_llm_provider.chat.return_value = Mock(
            content="This function adds two numbers."
        )
        
        analysis = assistant.analyze_code(code)
        
        assert analysis == "This function adds two numbers."
        
        # Verify the prompt includes analysis instructions
        call_args = mock_llm_provider.chat.call_args
        request = call_args[0][0]
        assert "analyze" in request.messages[0].content.lower()

    def test_conversation_history(self, assistant):
        """Test conversation history management."""
        # Ask multiple questions
        assistant.ask("First question")
        assistant.ask("Second question")
        assistant.ask("Third question")
        
        # Check history
        assert len(assistant.history.messages) == 6  # 3 user + 3 assistant
        
        # Clear history
        assistant.clear_history()
        assert len(assistant.history.messages) == 0

    def test_save_and_load_history(self, assistant, tmp_path):
        """Test saving and loading conversation history."""
        # Create some history
        assistant.ask("Test question 1")
        assistant.ask("Test question 2")
        
        # Save history
        history_file = tmp_path / "history.json"
        assistant.save_history(str(history_file))
        
        assert history_file.exists()
        
        # Clear and reload
        assistant.clear_history()
        assert len(assistant.history.messages) == 0
        
        assistant.load_history(str(history_file))
        assert len(assistant.history.messages) == 4  # 2 user + 2 assistant

    def test_system_prompt(self, assistant, mock_llm_provider):
        """Test custom system prompt."""
        assistant.set_system_prompt("You are a Python expert")
        assistant.ask("What is a decorator?")
        
        call_args = mock_llm_provider.chat.call_args
        request = call_args[0][0]
        
        # Check that system prompt is included
        assert any(
            msg.role == "system" and "Python expert" in msg.content
            for msg in request.messages
        )

    def test_token_counting(self, assistant):
        """Test token counting."""
        assistant.ask("Short question")
        stats = assistant.get_stats()
        
        assert "total_messages" in stats
        assert "total_tokens" in stats
        assert stats["total_messages"] == 2  # 1 user + 1 assistant

    def test_streaming_response(self, assistant, mock_llm_provider):
        """Test streaming responses."""
        # Mock streaming
        chunks = [
            Mock(content="Hello "),
            Mock(content="world"),
            Mock(content="!")
        ]
        mock_llm_provider.chat_stream = Mock(return_value=iter(chunks))
        
        response_parts = []
        for chunk in assistant.ask_stream("Test"):
            response_parts.append(chunk)
        
        assert response_parts == ["Hello ", "world", "!"]

    def test_error_handling(self, assistant, mock_llm_provider):
        """Test error handling."""
        mock_llm_provider.chat.side_effect = Exception("API Error")
        
        with pytest.raises(Exception, match="API Error"):
            assistant.ask("Test question")

    def test_max_history_limit(self):
        """Test max history limit."""
        config = AssistantConfig(
            provider="test",
            model="gpt-5-mini",
            api_key="test-key",
            max_history=4  # Limit to 4 messages
        )
        
        with patch('opsvi_assistant.core.get_provider'):
            assistant = Assistant(config)
            
            # Add more than limit
            for i in range(5):
                assistant.history.add_message("user", f"Question {i}")
                assistant.history.add_message("assistant", f"Answer {i}")
            
            # Should keep only last 4 messages
            assert len(assistant.history.messages) <= 4


class TestConversationHistory:
    """Test suite for ConversationHistory class."""

    def test_add_message(self):
        """Test adding messages to history."""
        history = ConversationHistory()
        
        history.add_message("user", "Hello")
        history.add_message("assistant", "Hi there!")
        
        assert len(history.messages) == 2
        assert history.messages[0]["role"] == "user"
        assert history.messages[0]["content"] == "Hello"
        assert history.messages[1]["role"] == "assistant"
        assert history.messages[1]["content"] == "Hi there!"

    def test_clear_history(self):
        """Test clearing history."""
        history = ConversationHistory()
        
        history.add_message("user", "Test")
        history.add_message("assistant", "Response")
        assert len(history.messages) == 2
        
        history.clear()
        assert len(history.messages) == 0

    def test_get_messages(self):
        """Test getting messages."""
        history = ConversationHistory()
        
        history.add_message("user", "Question 1")
        history.add_message("assistant", "Answer 1")
        history.add_message("user", "Question 2")
        
        messages = history.get_messages()
        assert len(messages) == 3
        assert messages[2]["content"] == "Question 2"

    def test_to_dict(self):
        """Test converting to dictionary."""
        history = ConversationHistory()
        
        history.add_message("user", "Test")
        history.add_message("assistant", "Response")
        
        data = history.to_dict()
        assert "messages" in data
        assert len(data["messages"]) == 2

    def test_from_dict(self):
        """Test loading from dictionary."""
        data = {
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"}
            ]
        }
        
        history = ConversationHistory.from_dict(data)
        assert len(history.messages) == 2
        assert history.messages[0]["content"] == "Hello"


class TestCLICommands:
    """Test suite for CLI commands."""

    @pytest.fixture
    def cli_runner(self):
        """Create CLI test runner."""
        from click.testing import CliRunner
        return CliRunner()

    def test_ask_command(self, cli_runner):
        """Test ask command."""
        with patch('opsvi_assistant.cli.Assistant') as mock_assistant:
            mock_instance = Mock()
            mock_instance.ask.return_value = "Test answer"
            mock_assistant.return_value = mock_instance
            
            result = cli_runner.invoke(main, ['ask', 'What is Python?'])
            
            assert result.exit_code == 0
            assert "Test answer" in result.output

    def test_code_command(self, cli_runner):
        """Test code generation command."""
        with patch('opsvi_assistant.cli.Assistant') as mock_assistant:
            mock_instance = Mock()
            mock_instance.generate_code.return_value = "def test(): pass"
            mock_assistant.return_value = mock_instance
            
            result = cli_runner.invoke(
                main, 
                ['code', 'Write a test function', '--language', 'python']
            )
            
            assert result.exit_code == 0
            assert "def test():" in result.output

    def test_analyze_command(self, cli_runner, tmp_path):
        """Test analyze command."""
        # Create a test file
        test_file = tmp_path / "test.py"
        test_file.write_text("def hello(): print('Hello')")
        
        with patch('opsvi_assistant.cli.Assistant') as mock_assistant:
            mock_instance = Mock()
            mock_instance.analyze_code.return_value = "Simple hello function"
            mock_assistant.return_value = mock_instance
            
            result = cli_runner.invoke(
                main,
                ['analyze', str(test_file)]
            )
            
            assert result.exit_code == 0
            assert "Simple hello function" in result.output

    def test_chat_command(self, cli_runner):
        """Test interactive chat command."""
        with patch('opsvi_assistant.cli.Assistant') as mock_assistant:
            mock_instance = Mock()
            mock_assistant.return_value = mock_instance
            
            # Simulate chat interaction
            with patch('builtins.input', side_effect=['Hello', '/exit']):
                result = cli_runner.invoke(main, ['chat'])
                
                assert result.exit_code == 0

    def test_config_command(self, cli_runner):
        """Test config command."""
        result = cli_runner.invoke(main, ['config'])
        
        assert result.exit_code == 0
        assert "Configuration" in result.output or "config" in result.output.lower()

    def test_status_command(self, cli_runner):
        """Test status command."""
        with patch('opsvi_assistant.cli.Assistant') as mock_assistant:
            mock_instance = Mock()
            mock_instance.get_stats.return_value = {
                "total_messages": 10,
                "total_tokens": 500
            }
            mock_assistant.return_value = mock_instance
            
            result = cli_runner.invoke(main, ['status'])
            
            assert result.exit_code == 0
            assert "messages" in result.output.lower() or "tokens" in result.output.lower()