#!/usr/bin/env python3
"""
Test WBS Documenter with a small subset
"""

import asyncio
import sys
from pathlib import Path

# Add agent-orchestrator to path
sys.path.insert(0, str(Path(__file__).parent.parent / "agent-orchestrator" / "src"))

from generic_orchestrator import GenericOrchestrator, AgentTask


async def test_wbs_basic():
    """Test basic WBS functionality with 2 tasks"""
    
    print("\n" + "="*60)
    print("WBS DOCUMENTER - BASIC TEST")
    print("="*60)
    
    # Create orchestrator
    orchestrator = GenericOrchestrator(
        output_dir=Path("./test_output"),
        max_parallel=5,
        use_optimizations=True
    )
    
    print(f"✅ Orchestrator ready")
    print(f"📊 Tokens available: {orchestrator.token_pool.size()}")
    
    # Create simple WBS tasks
    tasks = [
        AgentTask(
            task_id="discover_stages",
            task_type="discovery",
            prompt="""Identify the 5 most critical stages for an auto-coding solution.
            Just list the stage names with a brief description."""
        ),
        AgentTask(
            task_id="detail_first_stage",
            task_type="documentation",
            prompt="""Document the first stage of an auto-coding solution in detail.
            Include objectives, deliverables, and success criteria.""",
            dependencies=["discover_stages"]
        )
    ]
    
    print(f"\n📋 Executing {len(tasks)} test tasks...")
    
    try:
        results = await orchestrator.execute_batch(tasks)
        
        completed = sum(1 for r in results if r.get('status') == 'completed')
        failed = sum(1 for r in results if r.get('status') == 'failed')
        
        print(f"\n✅ Test complete:")
        print(f"  Completed: {completed}/{len(tasks)}")
        print(f"  Failed: {failed}/{len(tasks)}")
        
        # Check if dependency worked
        for result in results:
            if result['task_id'] == 'detail_first_stage':
                if result['status'] == 'completed':
                    print(f"✅ Dependency chain worked correctly!")
                else:
                    print(f"❌ Dependent task failed: {result.get('error', 'Unknown error')}")
        
        return results
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return []


async def test_parallel_documentation():
    """Test parallel documentation of multiple stages"""
    
    print("\n" + "="*60)
    print("WBS DOCUMENTER - PARALLEL TEST")
    print("="*60)
    
    orchestrator = GenericOrchestrator(
        output_dir=Path("./test_parallel"),
        max_parallel=15,
        use_optimizations=True
    )
    
    print(f"📊 Tokens: {orchestrator.token_pool.size()}")
    
    # Create 5 independent stage documentation tasks
    stages = [
        "Requirements Analysis",
        "System Design",
        "Implementation",
        "Testing",
        "Deployment"
    ]
    
    tasks = []
    for i, stage in enumerate(stages, 1):
        tasks.append(AgentTask(
            task_id=f"stage_{i}",
            task_type="documentation",
            prompt=f"""Create a brief outline for Stage {i}: {stage}
            Include 3 main objectives and 3 key deliverables.
            Keep it concise - 5-10 lines total."""
        ))
    
    print(f"\n📋 Documenting {len(tasks)} stages in parallel...")
    
    import time
    start = time.time()
    
    results = await orchestrator.execute_batch(tasks)
    
    duration = time.time() - start
    completed = sum(1 for r in results if r.get('status') == 'completed')
    
    print(f"\n✅ Parallel test complete:")
    print(f"  Completed: {completed}/{len(tasks)}")
    print(f"  Duration: {duration:.2f}s")
    print(f"  Avg per task: {duration/len(tasks):.2f}s")
    
    if duration < len(tasks) * 10:  # Less than sequential time
        print(f"✅ Parallel execution confirmed!")
    
    return results


async def main():
    """Run all WBS tests"""
    
    print("\n🔬 WBS DOCUMENTER TEST SUITE")
    print("="*60)
    
    # Test 1: Basic functionality with dependencies
    await test_wbs_basic()
    
    # Test 2: Parallel documentation
    await test_parallel_documentation()
    
    print("\n" + "="*60)
    print("WBS TESTS COMPLETE")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())