#!/usr/bin/env python3
"""Test Claude CLI output format to understand the JSON structure."""

import subprocess
import json
import os
from token_pool import get_token_pool

def test_claude_output():
    """Test what Claude actually outputs in JSON format."""
    
    # Get a token
    pool = get_token_pool()
    
    with pool.token_context("test"):
        # Simple test command
        cmd = [
            "claude", "-p",
            "--output-format", "json",
            "--model", "haiku",
            "--max-turns", "1",
            "Write a simple greeting message"
        ]
        
        print(f"Running: {' '.join(cmd)}")
        print(f"CLAUDE_CODE_TOKEN set: {bool(os.environ.get('CLAUDE_CODE_TOKEN'))}")
        print(f"ANTHROPIC_API_KEY: {'set' if os.environ.get('ANTHROPIC_API_KEY') else 'unset'}")
        
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate(timeout=30)
        
        if proc.returncode != 0:
            print(f"Error (rc={proc.returncode}): {err}")
            return
            
        print("\n=== Raw output ===")
        print(out[:1000])  # First 1000 chars
        
        print("\n=== Parsing attempt ===")
        try:
            data = json.loads(out)
            print(f"Type: {type(data)}")
            
            if isinstance(data, dict):
                print(f"Keys: {list(data.keys())}")
                print(f"Result field: '{data.get('result', 'NO RESULT FIELD')}'")
                
                # Check for messages
                if 'messages' in data:
                    print(f"Messages count: {len(data['messages'])}")
                    for i, msg in enumerate(data['messages'][:3]):
                        print(f"  Message {i}: type={msg.get('type')}, content_type={type(msg.get('content'))}")
                        if msg.get('content'):
                            content = msg.get('content')
                            if isinstance(content, str):
                                print(f"    Content: {content[:100]}")
                            elif isinstance(content, list):
                                print(f"    Content is list with {len(content)} items")
                                
            elif isinstance(data, list):
                print(f"List with {len(data)} items")
                for i, item in enumerate(data[:3]):
                    print(f"  Item {i}: {type(item)}")
                    if isinstance(item, dict):
                        print(f"    Keys: {list(item.keys())[:5]}")
                        
        except json.JSONDecodeError as e:
            print(f"JSON parse error: {e}")
            print("Trying line-by-line parsing...")
            
            lines = out.strip().split('\n')
            for i, line in enumerate(lines[-5:]):  # Last 5 lines
                try:
                    item = json.loads(line)
                    print(f"  Line {i}: {list(item.keys()) if isinstance(item, dict) else type(item)}")
                except:
                    pass

if __name__ == "__main__":
    test_claude_output()