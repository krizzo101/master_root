#!/usr/bin/env python3
"""Test token pool functionality."""

import asyncio
import sys
import os
from pathlib import Path

# Add parent dir to path
sys.path.insert(0, str(Path(__file__).parent))

from token_pool import get_token_pool


async def test_agent(agent_name: str, pool, delay: float = 1.0):
    """Simulate an agent using a token."""
    print(f"[{agent_name}] Starting...")
    
    try:
        async with pool.async_token_context(agent_name):
            token = os.environ.get('CLAUDE_CODE_TOKEN', 'NOT_SET')
            anthropic = os.environ.get('ANTHROPIC_API_KEY', 'NOT_SET')
            print(f"[{agent_name}] Got token: {token[:10]}...")
            print(f"[{agent_name}] ANTHROPIC_API_KEY: {anthropic}")
            
            # Simulate work
            await asyncio.sleep(delay)
            print(f"[{agent_name}] Work complete")
            
    except Exception as e:
        print(f"[{agent_name}] ERROR: {e}")
        
    print(f"[{agent_name}] Finished")


async def main():
    """Test concurrent token acquisition."""
    print("Initializing token pool...")
    
    try:
        pool = get_token_pool()
        status = pool.status()
        print(f"Pool initialized: {status['total']} tokens available")
        
        # Test concurrent agents
        print("\nTesting concurrent agents...")
        agents = [
            test_agent("agent1", pool, 2.0),
            test_agent("agent2", pool, 1.5),
            test_agent("agent3", pool, 1.0),
            test_agent("agent4", pool, 0.5),
        ]
        
        await asyncio.gather(*agents)
        
        print(f"\nFinal pool status: {pool.status()}")
        
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())