#!/usr/bin/env python3
"""Test single real Claude agent execution"""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from core.swarm_executor import SwarmExecutor, AgentTask, AgentRole


async def test_single_agent():
    """Test with single agent to prove it works"""
    
    # Get token
    token = os.environ.get("CLAUDE_CODE_TOKEN")
    if not token:
        print("❌ No token found")
        return
    
    print(f"🔑 Using token: ...{token[-8:]}")
    
    # Create executor  
    repo_path = Path("/home/opsvi/master_root/apps/multi-agent-monitor")
    swarm = SwarmExecutor(repo_path, [token])
    
    # Single simple task
    task = AgentTask(
        role=AgentRole.DEVELOPER,
        description="Create a simple Python function that calculates factorial",
        timeout=60  # Just 60 seconds timeout
    )
    
    print("\n🚀 Executing single REAL Claude agent...")
    
    # Execute
    result = await swarm.execute_agent(task)
    
    # Show result
    if result.success:
        print(f"\n✅ SUCCESS! Agent completed in {result.duration:.1f}s")
        print(f"Output preview: {result.output[:500]}...")
        if result.files_created:
            print(f"Files created: {result.files_created}")
    else:
        print(f"\n❌ Failed: {result.error}")
    
    return result


if __name__ == "__main__":
    result = asyncio.run(test_single_agent())
    sys.exit(0 if result and result.success else 1)