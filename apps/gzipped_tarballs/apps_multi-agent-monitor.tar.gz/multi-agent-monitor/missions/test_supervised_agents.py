#!/usr/bin/env python3
"""
Test Supervised Agent Execution with Quality Control
Demonstrates agent action confirmation and output validation
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.orchestration.agent_supervisor import AgentSupervisor


async def main():
    """Run supervised agent test with quality control"""
    
    print("\n" + "="*60)
    print("AGENT QUALITY CONTROL TEST")
    print("Testing supervision, validation, and approval workflow")
    print("="*60)
    
    # Initialize supervisor
    supervisor = AgentSupervisor()
    
    # Define tasks with specific requirements
    agent_tasks = [
        # Requirements analyst - must create specific doc
        supervisor.define_agent_task(
            agent_type="requirements",
            task_description="Create requirements document for user authentication feature",
            required_files=["requirements.md"],
            content_checks=[
                {
                    "file_pattern": "requirements.md",
                    "must_contain": ["Functional Requirements", "Non-Functional Requirements"],
                    "must_not_contain": ["TODO", "FIXME"]
                }
            ],
            max_file_changes=2,
            auto_approve=True,  # Can auto-approve if quality is high
            critical=True  # Pipeline stops if this fails
        ),
        
        # Developer - must create implementation with tests
        supervisor.define_agent_task(
            agent_type="developer",
            task_description="Implement user authentication based on requirements",
            required_files=["implementation.py"],
            content_checks=[
                {
                    "file_pattern": "implementation.py",
                    "must_contain": ["def ", "validate", "error"],
                    "must_not_contain": ["eval(", "exec(", "password="]
                },
                {
                    "file_pattern": "test_",
                    "must_contain": ["test", "assert"],
                    "must_not_contain": []
                }
            ],
            max_file_changes=5,
            auto_approve=False,  # Requires review
            critical=False
        ),
        
        # Code reviewer - must create review report
        supervisor.define_agent_task(
            agent_type="reviewer",
            task_description="Review code quality and security",
            required_files=["review_report.md"],
            content_checks=[
                {
                    "file_pattern": "review_report.md",
                    "must_contain": ["Security Review", "Score"],
                    "must_not_contain": []
                }
            ],
            max_file_changes=2,
            auto_approve=True,
            critical=False
        )
    ]
    
    # Run agents with supervision
    print("\n📋 Task Definitions:")
    for task in agent_tasks:
        critical = "🔴 CRITICAL" if task.critical else "🔵 Normal"
        auto = "🤖 Auto-approve" if task.auto_approve else "👀 Manual review"
        print(f"   {task.agent_type:15} {critical} {auto}")
        print(f"      Required files: {task.requirements['required_files']}")
    
    print("\n🚀 Starting supervised execution...")
    
    # Execute with quality control
    report = await supervisor.run_supervised_agents(
        agent_tasks=agent_tasks,
        parallel=True,  # Run agents in parallel
        stop_on_failure=True  # Stop if critical task fails
    )
    
    # Display detailed results
    print("\n" + "="*60)
    print("QUALITY CONTROL RESULTS")
    print("="*60)
    
    print(f"\n📊 Overall Statistics:")
    print(f"   Total Agents:    {report['total_agents']}")
    print(f"   Approved:        {report['approved']}")
    print(f"   Needs Review:    {report['needs_review']}")
    print(f"   Failed:          {report['failed']}")
    print(f"   Merged:          {report['merged']}")
    
    # Show quality scores
    if "quality_summary" in report and "agents" in report["quality_summary"]:
        print(f"\n📈 Quality Scores:")
        for agent in report["quality_summary"]["agents"]:
            score = agent.get("quality_score", 0)
            status = agent.get("status", "unknown")
            
            # Score indicator
            if score >= 80:
                indicator = "🟢"
            elif score >= 60:
                indicator = "🟡"
            else:
                indicator = "🔴"
            
            print(f"   {agent['agent_id']:20} {indicator} {score:5.1f}/100  [{status}]")
    
    # Show average quality
    avg_quality = report["quality_summary"].get("average_quality", 0)
    print(f"\n   Average Quality: {avg_quality:.1f}/100")
    
    # Success determination
    success = report["approved"] > 0 and report["failed"] == 0
    
    print("\n" + "="*60)
    if success:
        print("✅ TEST PASSED: Quality control system working correctly")
        print("   - Agent outputs validated against requirements")
        print("   - Quality metrics calculated and enforced")
        print("   - Approval workflow functioning")
        print("   - Only quality work was merged")
    else:
        print("❌ TEST FAILED: Some agents didn't meet quality standards")
    print("="*60)
    
    # Show how to review the supervised branch
    print("\n💡 To inspect the supervised work:")
    print(f"   git checkout supervised/{supervisor.execution_id}")
    print(f"   git log --oneline")
    print(f"   cat agent_execution_report_{supervisor.execution_id}.json")
    
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)