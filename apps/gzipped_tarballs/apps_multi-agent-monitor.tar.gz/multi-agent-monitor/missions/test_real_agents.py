#!/usr/bin/env python3
"""
Real Agent Test: 2 agents creating actual files to test selective merge
Agent 1: Creates a calculator module
Agent 2: Creates tests for the calculator
"""

import asyncio
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.orchestration.worktree_manager import WorktreeManager
from src.orchestration.selective_merger import SelectiveMerger


class RealAgentTest:
    """Test with real file creation to verify merge process"""
    
    def __init__(self):
        self.repo_path = Path("/home/opsvi/master_root")
        self.worktree_manager = WorktreeManager(self.repo_path)
        self.merger = SelectiveMerger(self.repo_path)
        self.execution_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def create_calculator_task(self) -> str:
        """Task for agent 1: Create a calculator module"""
        return """Create a Python module called 'calculator.py' in your agent workspace with the following functions:
        
1. add(a, b) - returns a + b
2. subtract(a, b) - returns a - b  
3. multiply(a, b) - returns a * b
4. divide(a, b) - returns a / b with ZeroDivisionError handling

Include docstrings and type hints. Save it in:
{workspace}/calculator.py
"""

    def create_test_task(self) -> str:
        """Task for agent 2: Create tests for calculator"""
        return """Create a test file called 'test_calculator.py' in your agent workspace that tests a calculator module with:

1. Test add function with positive, negative, and zero values
2. Test subtract function  
3. Test multiply function
4. Test divide function including division by zero

Use simple assert statements (no pytest needed). Save it in:
{workspace}/test_calculator.py
"""

    async def execute_real_agent(self, agent_config: Dict) -> Dict:
        """Execute a real agent that creates actual files"""
        
        agent_type = agent_config["agent_type"]
        workspace = Path(agent_config["environment"]["agent_workspace"])
        workspace.mkdir(parents=True, exist_ok=True)
        
        print(f"\n🤖 Executing {agent_type}...")
        
        # Create the appropriate file based on agent type
        if agent_type == "developer":
            # Create calculator.py
            calculator_code = '''"""Calculator module with basic operations"""

def add(a: float, b: float) -> float:
    """Add two numbers"""
    return a + b

def subtract(a: float, b: float) -> float:
    """Subtract b from a"""
    return a - b

def multiply(a: float, b: float) -> float:
    """Multiply two numbers"""
    return a * b

def divide(a: float, b: float) -> float:
    """Divide a by b, handling division by zero"""
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero")
    return a / b
'''
            file_path = workspace / "calculator.py"
            file_path.write_text(calculator_code)
            print(f"   ✅ Created {file_path}")
            
        elif agent_type == "tester":
            # Create test_calculator.py
            test_code = '''"""Tests for calculator module"""

# Note: In real scenario, calculator would be imported
# from calculator import add, subtract, multiply, divide

def test_add():
    """Test addition function"""
    # Mock implementation for testing
    def add(a, b): return a + b
    
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
    print("✓ Addition tests passed")

def test_subtract():
    """Test subtraction function"""
    def subtract(a, b): return a - b
    
    assert subtract(5, 3) == 2
    assert subtract(0, 5) == -5
    print("✓ Subtraction tests passed")

def test_multiply():
    """Test multiplication function"""
    def multiply(a, b): return a * b
    
    assert multiply(3, 4) == 12
    assert multiply(-2, 3) == -6
    assert multiply(0, 100) == 0
    print("✓ Multiplication tests passed")

def test_divide():
    """Test division function"""
    def divide(a, b):
        if b == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return a / b
    
    assert divide(10, 2) == 5
    assert divide(7, 2) == 3.5
    
    try:
        divide(5, 0)
        assert False, "Should have raised ZeroDivisionError"
    except ZeroDivisionError:
        pass
    print("✓ Division tests passed")

if __name__ == "__main__":
    test_add()
    test_subtract()
    test_multiply()
    test_divide()
    print("\\n✅ All tests passed!")
'''
            file_path = workspace / "test_calculator.py"
            file_path.write_text(test_code)
            print(f"   ✅ Created {file_path}")
        
        # Stage and commit the work in the worktree
        worktree_path = Path(agent_config["environment"]["working_directory"])
        
        # Add the files
        subprocess.run(
            ["git", "add", "-A"],
            cwd=worktree_path,
            check=True,
            capture_output=True
        )
        
        # Commit (skip hooks for agent work)
        commit_result = subprocess.run(
            ["git", "commit", "--no-verify", "-m", f"feat: {agent_type} created files"],
            cwd=worktree_path,
            capture_output=True,
            text=True
        )
        
        if commit_result.returncode == 0:
            # Get commit hash
            commit_hash = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=worktree_path,
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()
            print(f"   📝 Committed: {commit_hash[:8]}")
        else:
            print(f"   ℹ️  Nothing to commit (files may already exist)")
        
        return {
            "agent_id": agent_config["agent_id"],
            "agent_type": agent_type,
            "success": True,
            "files_created": 1,
            "commit": commit_hash[:8] if commit_result.returncode == 0 else None
        }
    
    async def run_test(self):
        """Run the real agent test"""
        
        print("\n" + "="*60)
        print("REAL AGENT TEST: File Creation and Selective Merge")
        print("="*60)
        
        # Create base branch for this test
        base_branch = f"test/real-agents/{self.execution_id}"
        subprocess.run(
            ["git", "checkout", "-b", base_branch],
            cwd=self.repo_path,
            check=True,
            capture_output=True
        )
        print(f"\n✅ Created test branch: {base_branch}")
        
        # Create worktrees for agents
        agents = [
            {"type": "developer", "task": self.create_calculator_task()},
            {"type": "tester", "task": self.create_test_task()}
        ]
        
        agent_configs = []
        for i, agent in enumerate(agents):
            agent_id = f"agent_{i}_{agent['type']}"
            worktree = self.worktree_manager.create_agent_worktree(
                agent_id=agent_id,
                agent_type=agent['type'],
                base_branch=base_branch,
                execution_id=self.execution_id
            )
            
            env = self.worktree_manager.get_agent_environment(agent_id)
            agent_configs.append({
                "agent_id": agent_id,
                "agent_type": agent['type'],
                "environment": env,
                "task": agent['task']
            })
            
            print(f"✅ Created worktree for {agent['type']}")
            print(f"   Path: {env['working_directory']}")
        
        # Execute agents in parallel
        print("\n📌 Executing agents in parallel...")
        tasks = [self.execute_real_agent(config) for config in agent_configs]
        results = await asyncio.gather(*tasks)
        
        # Display results
        print("\n📊 Execution Results:")
        for result in results:
            print(f"   {result['agent_type']}: {'✅' if result['success'] else '❌'}")
            if result['commit']:
                print(f"      Commit: {result['commit']}")
        
        # Test selective merge
        print("\n📌 Testing Selective Merge...")
        
        merge_success = True
        for config in agent_configs:
            agent_type = config["agent_type"]
            worktree_path = Path(config["environment"]["working_directory"])
            
            # Get files the agent changed
            changed_files = self.merger.get_agent_changes(worktree_path, agent_type)
            
            if changed_files:
                print(f"\n   🔍 {agent_type} modified {len(changed_files)} files:")
                for f in changed_files:
                    print(f"      - {f}")
                
                # Try to merge
                branch_name = config["environment"]["branch_name"]
                try:
                    success = self.merger.cherry_pick_files(
                        source_branch=branch_name,
                        target_branch=base_branch,
                        files=changed_files
                    )
                    
                    if success:
                        print(f"   ✅ Successfully merged {agent_type} changes")
                    else:
                        print(f"   ❌ Failed to merge {agent_type} changes")
                        merge_success = False
                except Exception as e:
                    print(f"   ❌ Error during merge: {e}")
                    merge_success = False
            else:
                print(f"   ℹ️  {agent_type} made no changes")
        
        # Check final result
        print("\n" + "="*60)
        if merge_success:
            print("✅ TEST PASSED: Real agents created files and merged successfully!")
            
            # Show merged files
            merged_files = list(Path(self.repo_path / "apps/multi-agent-monitor").glob("agent_workspace_*/calculator.py"))
            merged_files.extend(list(Path(self.repo_path / "apps/multi-agent-monitor").glob("agent_workspace_*/test_calculator.py")))
            
            if merged_files:
                print("\n📁 Merged files in main repository:")
                for f in merged_files:
                    print(f"   - {f.relative_to(self.repo_path)}")
        else:
            print("❌ TEST FAILED: Merge issues detected")
        
        print("="*60)
        
        # Cleanup
        print("\n🧹 Cleaning up...")
        for config in agent_configs:
            try:
                self.worktree_manager.cleanup_worktree(config["agent_id"], force=True)
            except:
                pass
        
        # Return to main branch
        subprocess.run(
            ["git", "checkout", "feature/multi-agent-orchestration"],
            cwd=self.repo_path,
            capture_output=True
        )
        
        # Delete test branch
        subprocess.run(
            ["git", "branch", "-D", base_branch],
            cwd=self.repo_path,
            capture_output=True
        )
        
        print("✅ Cleanup complete")
        
        return merge_success


async def main():
    test = RealAgentTest()
    success = await test.run_test()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())