#!/usr/bin/env python3
"""
5-Agent Coordination Test: Testing scalability of selective merge
Agent 1: Requirements Analyst - Creates feature spec
Agent 2: Developer - Creates implementation
Agent 3: Tester - Creates test suite  
Agent 4: Documentation - Creates docs
Agent 5: Integration - Creates integration config
"""

import asyncio
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.orchestration.worktree_manager import WorktreeManager
from src.orchestration.selective_merger import SelectiveMerger


class FiveAgentTest:
    """Test with 5 agents creating interdependent files"""
    
    def __init__(self):
        self.repo_path = Path("/home/opsvi/master_root")
        self.worktree_manager = WorktreeManager(self.repo_path)
        self.merger = SelectiveMerger(self.repo_path)
        self.execution_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    async def execute_agent(self, agent_config: Dict) -> Dict:
        """Execute an agent that creates specific files"""
        
        agent_type = agent_config["agent_type"]
        workspace = Path(agent_config["environment"]["agent_workspace"])
        workspace.mkdir(parents=True, exist_ok=True)
        
        print(f"\n🤖 Executing {agent_type}...")
        
        # Create files based on agent type
        if agent_type == "requirements":
            # Requirements spec
            spec_content = """# Feature Specification
## User Authentication System

### Requirements:
- User registration with email
- Password hashing with bcrypt
- JWT token generation
- Session management
- Password reset functionality

### API Endpoints:
- POST /auth/register
- POST /auth/login
- POST /auth/logout
- POST /auth/reset-password
"""
            file_path = workspace / "auth_spec.md"
            file_path.write_text(spec_content)
            print(f"   ✅ Created {file_path.name}")
            
        elif agent_type == "developer":
            # Implementation
            code_content = '''"""Authentication module implementation"""
import hashlib
import secrets
from typing import Dict, Optional

class AuthService:
    """Handle user authentication"""
    
    def __init__(self):
        self.users = {}
        self.sessions = {}
    
    def register(self, email: str, password: str) -> Dict:
        """Register new user"""
        if email in self.users:
            return {"error": "User already exists"}
        
        # Hash password (simplified for demo)
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        self.users[email] = {
            "email": email,
            "password_hash": password_hash
        }
        return {"status": "success", "email": email}
    
    def login(self, email: str, password: str) -> Optional[str]:
        """Login user and create session"""
        if email not in self.users:
            return None
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        if self.users[email]["password_hash"] != password_hash:
            return None
        
        # Create session token
        token = secrets.token_hex(16)
        self.sessions[token] = email
        return token
    
    def logout(self, token: str) -> bool:
        """Logout user"""
        if token in self.sessions:
            del self.sessions[token]
            return True
        return False
'''
            file_path = workspace / "auth_service.py"
            file_path.write_text(code_content)
            print(f"   ✅ Created {file_path.name}")
            
        elif agent_type == "tester":
            # Test suite
            test_content = '''"""Tests for authentication service"""
import unittest

# Mock AuthService for testing
class AuthService:
    def __init__(self):
        self.users = {}
        self.sessions = {}
    
    def register(self, email, password):
        if email in self.users:
            return {"error": "User already exists"}
        self.users[email] = password
        return {"status": "success", "email": email}
    
    def login(self, email, password):
        if email in self.users and self.users[email] == password:
            return "test_token_123"
        return None

class TestAuthService(unittest.TestCase):
    """Test authentication functionality"""
    
    def setUp(self):
        self.auth = AuthService()
    
    def test_register_success(self):
        """Test successful registration"""
        result = self.auth.register("test@example.com", "password123")
        self.assertEqual(result["status"], "success")
    
    def test_register_duplicate(self):
        """Test duplicate registration"""
        self.auth.register("test@example.com", "password123")
        result = self.auth.register("test@example.com", "password456")
        self.assertIn("error", result)
    
    def test_login_success(self):
        """Test successful login"""
        self.auth.register("test@example.com", "password123")
        token = self.auth.login("test@example.com", "password123")
        self.assertIsNotNone(token)
    
    def test_login_fail(self):
        """Test failed login"""
        token = self.auth.login("nonexistent@example.com", "password")
        self.assertIsNone(token)

if __name__ == "__main__":
    unittest.main()
'''
            file_path = workspace / "test_auth.py"
            file_path.write_text(test_content)
            print(f"   ✅ Created {file_path.name}")
            
        elif agent_type == "documentation":
            # API documentation
            doc_content = """# Authentication API Documentation

## Overview
RESTful authentication service with JWT tokens.

## Endpoints

### Register User
**POST** `/auth/register`

Request:
```json
{
  "email": "user@example.com",
  "password": "securePassword123"
}
```

Response:
```json
{
  "status": "success",
  "user_id": "uuid-here",
  "email": "user@example.com"
}
```

### Login
**POST** `/auth/login`

Request:
```json
{
  "email": "user@example.com",
  "password": "securePassword123"
}
```

Response:
```json
{
  "token": "jwt-token-here",
  "expires_in": 3600
}
```

### Logout
**POST** `/auth/logout`

Headers:
- Authorization: Bearer {token}

Response:
```json
{
  "status": "success"
}
```

## Error Codes
- 400: Bad Request
- 401: Unauthorized
- 409: Conflict (user exists)
- 500: Internal Server Error
"""
            file_path = workspace / "api_docs.md"
            file_path.write_text(doc_content)
            print(f"   ✅ Created {file_path.name}")
            
        elif agent_type == "integration":
            # Integration config
            config_content = """# Integration Configuration

## Docker Compose Setup
```yaml
version: '3.8'
services:
  auth-service:
    build: .
    ports:
      - "8080:8080"
    environment:
      - JWT_SECRET=${JWT_SECRET}
      - DB_CONNECTION=${DB_CONNECTION}
    depends_on:
      - postgres
      - redis
  
  postgres:
    image: postgres:14
    environment:
      - POSTGRES_DB=auth_db
      - POSTGRES_USER=auth_user
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - auth_data:/var/lib/postgresql/data
  
  redis:
    image: redis:7
    ports:
      - "6379:6379"

volumes:
  auth_data:
```

## Environment Variables
- JWT_SECRET: Secret key for JWT signing
- DB_CONNECTION: PostgreSQL connection string
- REDIS_URL: Redis connection URL
- LOG_LEVEL: debug|info|warning|error

## CI/CD Pipeline
1. Run tests
2. Build Docker image
3. Push to registry
4. Deploy to staging
5. Run integration tests
6. Deploy to production
"""
            file_path = workspace / "integration.md"
            file_path.write_text(config_content)
            print(f"   ✅ Created {file_path.name}")
        
        # Stage and commit in worktree
        worktree_path = Path(agent_config["environment"]["working_directory"])
        
        subprocess.run(
            ["git", "add", "-A"],
            cwd=worktree_path,
            check=True,
            capture_output=True
        )
        
        commit_result = subprocess.run(
            ["git", "commit", "--no-verify", "-m", f"feat: {agent_type} created authentication files"],
            cwd=worktree_path,
            capture_output=True,
            text=True
        )
        
        commit_hash = None
        if commit_result.returncode == 0:
            commit_hash = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=worktree_path,
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()[:8]
            print(f"   📝 Committed: {commit_hash}")
        
        return {
            "agent_id": agent_config["agent_id"],
            "agent_type": agent_type,
            "success": True,
            "files_created": 1,
            "commit": commit_hash
        }
    
    async def run_test(self):
        """Run the 5-agent coordination test"""
        
        print("\n" + "="*60)
        print("5-AGENT COORDINATION TEST")
        print("="*60)
        
        # Create base branch
        base_branch = f"test/5-agents/{self.execution_id}"
        subprocess.run(
            ["git", "checkout", "-b", base_branch],
            cwd=self.repo_path,
            check=True,
            capture_output=True
        )
        print(f"\n✅ Created test branch: {base_branch}")
        
        # Define 5 agents
        agents = [
            {"type": "requirements", "role": "Requirements Analyst"},
            {"type": "developer", "role": "Developer"},
            {"type": "tester", "role": "QA Engineer"},
            {"type": "documentation", "role": "Technical Writer"},
            {"type": "integration", "role": "DevOps Engineer"}
        ]
        
        # Create worktrees for all agents
        agent_configs = []
        for i, agent in enumerate(agents):
            agent_id = f"agent_{i}_{agent['type']}"
            worktree = self.worktree_manager.create_agent_worktree(
                agent_id=agent_id,
                agent_type=agent['type'],
                base_branch=base_branch,
                execution_id=self.execution_id
            )
            
            env = self.worktree_manager.get_agent_environment(agent_id)
            agent_configs.append({
                "agent_id": agent_id,
                "agent_type": agent['type'],
                "agent_role": agent['role'],
                "environment": env
            })
            
            print(f"✅ Created worktree for {agent['role']}")
        
        # Execute agents in parallel
        print(f"\n📌 Executing {len(agents)} agents in parallel...")
        tasks = [self.execute_agent(config) for config in agent_configs]
        results = await asyncio.gather(*tasks)
        
        # Display results
        print("\n📊 Execution Results:")
        for result in results:
            status = '✅' if result['success'] else '❌'
            print(f"   {result['agent_type']:15} {status} Commit: {result['commit'] or 'none'}")
        
        # Selective merge from each agent
        print("\n📌 Performing Selective Merge...")
        
        merge_results = []
        for config in agent_configs:
            agent_type = config["agent_type"]
            worktree_path = Path(config["environment"]["working_directory"])
            
            # Get files changed by this agent
            changed_files = self.merger.get_agent_changes(worktree_path, agent_type)
            
            if changed_files:
                print(f"\n   🔍 {config['agent_role']} modified:")
                for f in changed_files:
                    print(f"      - {f}")
                
                # Merge this agent's work
                branch_name = config["environment"]["branch_name"]
                success = self.merger.cherry_pick_files(
                    source_branch=branch_name,
                    target_branch=base_branch,
                    files=changed_files
                )
                
                merge_results.append({
                    "agent": agent_type,
                    "success": success,
                    "files": len(changed_files)
                })
                
                if success:
                    print(f"   ✅ Merged {agent_type} changes")
                else:
                    print(f"   ❌ Failed to merge {agent_type}")
            else:
                print(f"   ℹ️  {agent_type} made no changes")
                merge_results.append({
                    "agent": agent_type,
                    "success": True,
                    "files": 0
                })
        
        # Check final results
        print("\n" + "="*60)
        
        all_success = all(r["success"] for r in merge_results)
        total_files = sum(r["files"] for r in merge_results)
        
        if all_success:
            print(f"✅ TEST PASSED: {len(agents)} agents coordinated successfully!")
            print(f"   Total files merged: {total_files}")
            
            # List all merged files
            for agent_type in [a["type"] for a in agents]:
                workspace = self.repo_path / "apps/multi-agent-monitor" / f"agent_workspace_{agent_type}"
                if workspace.exists():
                    files = list(workspace.glob("*.*"))
                    if files:
                        print(f"\n   {agent_type} workspace:")
                        for f in files:
                            print(f"      - {f.name}")
        else:
            print("❌ TEST FAILED: Some merges failed")
            for r in merge_results:
                status = "✅" if r["success"] else "❌"
                print(f"   {r['agent']:15} {status} ({r['files']} files)")
        
        print("="*60)
        
        # Cleanup
        print("\n🧹 Cleaning up...")
        for config in agent_configs:
            try:
                self.worktree_manager.cleanup_worktree(config["agent_id"], force=True)
            except:
                pass
        
        # Return to main branch
        subprocess.run(
            ["git", "checkout", "feature/multi-agent-orchestration"],
            cwd=self.repo_path,
            capture_output=True
        )
        
        # Delete test branch
        subprocess.run(
            ["git", "branch", "-D", base_branch],
            cwd=self.repo_path,
            capture_output=True
        )
        
        print("✅ Cleanup complete")
        
        return all_success


async def main():
    test = FiveAgentTest()
    success = await test.run_test()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())