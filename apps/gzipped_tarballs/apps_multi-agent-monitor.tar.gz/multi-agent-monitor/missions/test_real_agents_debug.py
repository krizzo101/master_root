#!/usr/bin/env python3
"""
Debug version: Real Agent Test that doesn't clean up for inspection
"""

import asyncio
import subprocess
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.orchestration.worktree_manager import WorktreeManager
from src.orchestration.selective_merger import SelectiveMerger


async def main():
    repo_path = Path("/home/opsvi/master_root")
    worktree_manager = WorktreeManager(repo_path)
    merger = SelectiveMerger(repo_path)
    execution_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    print("\n" + "="*60)
    print("DEBUG: Real Agent Test")
    print("="*60)
    
    # Create base branch
    base_branch = f"test/debug/{execution_id}"
    subprocess.run(["git", "checkout", "-b", base_branch], cwd=repo_path, check=True, capture_output=True)
    print(f"✅ Created branch: {base_branch}")
    
    # Create one worktree
    agent_id = f"debug_agent_{execution_id}"
    worktree = worktree_manager.create_agent_worktree(
        agent_id=agent_id,
        agent_type="developer",
        base_branch=base_branch,
        execution_id=execution_id
    )
    
    env = worktree_manager.get_agent_environment(agent_id)
    worktree_path = Path(env["working_directory"])
    workspace = Path(env["agent_workspace"])
    
    print(f"✅ Worktree: {worktree_path}")
    print(f"✅ Workspace: {workspace}")
    
    # Create a file
    workspace.mkdir(parents=True, exist_ok=True)
    test_file = workspace / "test.py"
    test_file.write_text("# Test file\nprint('Hello')\n")
    print(f"✅ Created: {test_file}")
    
    # Git add and commit in worktree
    subprocess.run(["git", "add", "-A"], cwd=worktree_path, check=True)
    subprocess.run(["git", "commit", "-m", "test commit"], cwd=worktree_path, check=True)
    print("✅ Committed in worktree")
    
    # Get the branch name from environment
    branch_name = env["branch_name"]
    print(f"Branch: {branch_name}")
    
    # Check what files changed
    changed_files = merger.get_agent_changes(worktree_path, "developer")
    print(f"\n📊 Changed files: {changed_files}")
    
    # Try to merge
    print(f"\nAttempting merge from {branch_name} to {base_branch}...")
    
    # First, let's see what branches exist
    result = subprocess.run(["git", "branch", "-a"], cwd=repo_path, capture_output=True, text=True)
    print("Available branches:")
    for line in result.stdout.split('\n')[:10]:
        if branch_name in line or base_branch in line:
            print(f"  {line}")
    
    # Check current branch
    result = subprocess.run(["git", "branch", "--show-current"], cwd=repo_path, capture_output=True, text=True)
    print(f"\nCurrent branch: {result.stdout.strip()}")
    
    # Try the merge
    success = merger.cherry_pick_files(
        source_branch=branch_name,
        target_branch=base_branch,
        files=changed_files
    )
    
    print(f"\nMerge result: {'✅ Success' if success else '❌ Failed'}")
    
    print("\n⚠️  NOT CLEANING UP - Inspect manually:")
    print(f"  Worktree: {worktree_path}")
    print(f"  Branch: {branch_name}")
    print(f"  Base: {base_branch}")
    print("\nTo clean up manually:")
    print(f"  git worktree remove {worktree_path}")
    print(f"  git branch -D {branch_name} {base_branch}")


if __name__ == "__main__":
    asyncio.run(main())