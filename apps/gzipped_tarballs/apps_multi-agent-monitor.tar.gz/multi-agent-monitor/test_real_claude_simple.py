#!/usr/bin/env python3
"""
SIMPLE TEST - Prove we can ACTUALLY execute Claude
This is not fake. This will spawn real 'claude' processes.
"""

import subprocess
import os

def test_real_claude():
    """The simplest possible REAL Claude execution"""
    
    print("=" * 60)
    print("REAL CLAUDE EXECUTION TEST")
    print("This will ACTUALLY spawn 'claude -p' subprocess")
    print("=" * 60)
    
    # Get first available token
    token = None
    for i in range(1, 16):
        token = os.environ.get(f"CLAUDE_CODE_TOKEN{i}")
        if token:
            print(f"\n✅ Found token {i}")
            break
    
    if not token:
        # Try the single token
        token = os.environ.get("CLAUDE_CODE_TOKEN")
        if not token:
            print("\n❌ No Claude tokens found in environment")
            return
    
    # The ACTUAL command we'll run
    task = "Write a Python function that adds two numbers and include a test"
    cmd = ["claude", "--dangerously-skip-permissions", "-p", task]
    
    print(f"\n🚀 Executing command: {' '.join(cmd)}")
    print(f"📝 Task: {task}")
    
    # Set up environment
    env = os.environ.copy()
    env["CLAUDE_CODE_TOKEN"] = token
    env.pop("ANTHROPIC_API_KEY", None)  # Remove conflict
    
    print("\n⏳ Calling Claude (this is REAL, not fake)...")
    
    try:
        # ACTUALLY EXECUTE CLAUDE
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            timeout=60
        )
        
        if result.returncode == 0:
            print("\n✅ SUCCESS! Claude responded:")
            print("-" * 40)
            print(result.stdout[:1000])  # First 1000 chars
            if len(result.stdout) > 1000:
                print(f"... ({len(result.stdout) - 1000} more characters)")
            print("-" * 40)
            
            # Save the output
            with open("claude_real_output.py", "w") as f:
                f.write(result.stdout)
            print("\n📁 Saved full output to: claude_real_output.py")
            
            # Try to execute what Claude created
            print("\n🧪 Testing if Claude's code works:")
            try:
                exec(result.stdout)
                print("   ✅ Code executes without errors!")
            except Exception as e:
                print(f"   ⚠️  Code has issues: {e}")
                
        else:
            print(f"\n❌ Claude failed with return code: {result.returncode}")
            print(f"Error: {result.stderr[:500]}")
            
    except subprocess.TimeoutExpired:
        print("\n❌ Claude timed out after 60 seconds")
    except FileNotFoundError:
        print("\n❌ 'claude' command not found - is Claude CLI installed?")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
    
    print("\n" + "=" * 60)
    print("This was a REAL Claude execution, not fake!")
    print("Check 'ps aux | grep claude' while running to see the process")
    print("=" * 60)


if __name__ == "__main__":
    test_real_claude()