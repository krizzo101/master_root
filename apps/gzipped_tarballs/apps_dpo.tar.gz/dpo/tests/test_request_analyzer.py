#!/usr/bin/env python3
"""
Unit tests for Request Analyzer component
"""

import json
import sys
import unittest
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from request_analyzer import (
    RequestAnalyzer, 
    ProjectType, 
    ComplexityLevel,
    TechnologyStack,
    RequestAnalysis
)


class TestRequestAnalyzer(unittest.TestCase):
    """Test suite for Request Analyzer"""
    
    def setUp(self):
        """Initialize analyzer for each test"""
        self.analyzer = RequestAnalyzer()
    
    def test_simple_api_request(self):
        """Test analysis of a simple API request"""
        request = "Build a REST API for user management with JWT authentication"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.BACKEND_API)
        self.assertIn("jwt", analysis.tech_stack.tools)
        self.assertIn("api_design", analysis.focus_areas)
        self.assertGreaterEqual(analysis.estimated_agents, 5)
        self.assertLessEqual(analysis.estimated_agents, 15)
    
    def test_complex_fullstack_request(self):
        """Test analysis of a complex full-stack request"""
        request = """Build a complete web application with React frontend and Python FastAPI backend,
                    including user authentication, real-time chat, PostgreSQL database,
                    Redis caching, and Docker deployment"""
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.FULL_STACK)
        self.assertIn(analysis.complexity, [ComplexityLevel.COMPLEX, ComplexityLevel.ENTERPRISE])
        self.assertIn("react", analysis.tech_stack.frameworks)
        self.assertIn("fastapi", analysis.tech_stack.frameworks)
        self.assertIn("postgresql", analysis.tech_stack.databases)
        self.assertIn("redis", analysis.tech_stack.databases)
        self.assertIn("docker", analysis.tech_stack.tools)
        self.assertGreaterEqual(analysis.estimated_agents, 15)
    
    def test_cli_tool_request(self):
        """Test analysis of CLI tool request"""
        request = "Create a command-line tool for file organization and batch renaming"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.CLI_TOOL)
        self.assertEqual(analysis.complexity, ComplexityLevel.SIMPLE)
        self.assertIn("Command-line argument parsing", analysis.implicit_requirements)
    
    def test_library_request(self):
        """Test analysis of library development request"""
        request = "Develop a Python library for advanced data validation with type hints"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.LIBRARY)
        self.assertIn("python", analysis.tech_stack.languages)
        self.assertIn("Type hints and docstrings", analysis.implicit_requirements)
    
    def test_integration_request(self):
        """Test analysis of integration request"""
        request = "Build an integration connector between Slack and our internal API"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.INTEGRATION)
        self.assertIn("api_design", analysis.focus_areas)
    
    def test_data_pipeline_request(self):
        """Test analysis of data pipeline request"""
        request = "Create a data pipeline for processing streaming analytics with Kafka"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.DATA_PIPELINE)
        self.assertIn("kafka", analysis.tech_stack.tools)
        self.assertIn("data_modeling", analysis.phases)
    
    def test_microservice_request(self):
        """Test analysis of microservice request"""
        request = "Build a microservice for payment processing with Docker and Kubernetes"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.MICROSERVICE)
        self.assertIn("docker", analysis.tech_stack.tools)
        self.assertIn("kubernetes", analysis.tech_stack.tools)
        self.assertIn("containerization", analysis.phases)
    
    def test_automation_request(self):
        """Test analysis of automation request"""
        request = "Create an automation workflow for scheduled data backups"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.AUTOMATION)
        self.assertIn("requirements", analysis.phases)
    
    def test_unknown_project_type(self):
        """Test handling of ambiguous requests"""
        request = "Build something cool"
        analysis = self.analyzer.analyze(request)
        
        self.assertEqual(analysis.project_type, ProjectType.UNKNOWN)
        self.assertLess(analysis.confidence_score, 0.61)
    
    def test_complexity_assessment(self):
        """Test complexity level assessment"""
        # Simple project
        simple_request = "Create a basic calculator app"
        simple_analysis = self.analyzer.analyze(simple_request)
        self.assertEqual(simple_analysis.complexity, ComplexityLevel.SIMPLE)
        
        # Complex project
        complex_request = """Build an enterprise-grade distributed system with 
                           microservices, message queues, caching, monitoring,
                           and advanced security features"""
        complex_analysis = self.analyzer.analyze(complex_request)
        self.assertIn(complex_analysis.complexity, 
                     [ComplexityLevel.COMPLEX, ComplexityLevel.ENTERPRISE])
    
    def test_technology_extraction(self):
        """Test technology stack extraction"""
        request = """Build a web app using React, Node.js, Express, MongoDB,
                    with Redis caching and JWT authentication"""
        analysis = self.analyzer.analyze(request)
        
        tech_stack = analysis.tech_stack
        self.assertIn("javascript", tech_stack.languages)
        self.assertIn("react", tech_stack.frameworks)
        self.assertIn("express", tech_stack.frameworks)
        self.assertIn("mongodb", tech_stack.databases)
        self.assertIn("redis", tech_stack.databases)
        self.assertIn("jwt", tech_stack.tools)
    
    def test_phases_determination(self):
        """Test SDLC phases determination"""
        # Simple project phases
        simple_request = "Build a simple API"
        simple_analysis = self.analyzer.analyze(simple_request)
        self.assertIn("requirements", simple_analysis.phases)
        self.assertIn("implementation", simple_analysis.phases)
        self.assertIn("testing", simple_analysis.phases)
        
        # Complex project phases
        complex_request = "Build a complex enterprise application with full deployment"
        complex_analysis = self.analyzer.analyze(complex_request)
        self.assertIn("deployment", complex_analysis.phases)
        self.assertGreaterEqual(len(complex_analysis.phases), len(simple_analysis.phases))
    
    def test_focus_areas_identification(self):
        """Test focus areas identification"""
        request = """Build a high-performance API with strong security,
                    excellent documentation, and comprehensive testing"""
        analysis = self.analyzer.analyze(request)
        
        self.assertIn("performance", analysis.focus_areas)
        self.assertIn("security", analysis.focus_areas)
        self.assertIn("documentation", analysis.focus_areas)
        self.assertIn("testing", analysis.focus_areas)
    
    def test_requirements_extraction(self):
        """Test requirements extraction"""
        request = """The system must support user authentication, should enable real-time updates,
                    needs to handle file uploads, and requires data validation"""
        analysis = self.analyzer.analyze(request)
        
        self.assertTrue(len(analysis.requirements["functional"]) > 0)
        self.assertTrue(any("authentication" in req for req in analysis.requirements["functional"]))
    
    def test_constraints_identification(self):
        """Test constraints identification"""
        request = "Build an API without using any external libraries, limited to 100MB memory"
        analysis = self.analyzer.analyze(request)
        
        self.assertTrue(len(analysis.constraints) > 0)
        self.assertTrue(any("exclusion" in constraint for constraint in analysis.constraints))
    
    def test_ecosystem_context_generation(self):
        """Test ecosystem context generation"""
        request = "Build a monitoring dashboard"
        analysis = self.analyzer.analyze(request)
        
        context = analysis.ecosystem_context
        self.assertEqual(context["environment"], "master_root ecosystem")
        self.assertEqual(context["optimization_focus"], "solo developer efficiency")
        self.assertTrue(len(context["available_tools"]) > 0)
        self.assertIn("agent-orchestrator", context["available_tools"])
    
    def test_confidence_scoring(self):
        """Test confidence score calculation"""
        # High confidence request
        detailed_request = """Build a Python FastAPI REST API for user management 
                            with PostgreSQL database and JWT authentication"""
        detailed_analysis = self.analyzer.analyze(detailed_request)
        self.assertGreater(detailed_analysis.confidence_score, 0.7)
        
        # Low confidence request
        vague_request = "Make something"
        vague_analysis = self.analyzer.analyze(vague_request)
        self.assertLess(vague_analysis.confidence_score, 0.61)
    
    def test_analysis_validation(self):
        """Test analysis validation"""
        request = "Build a REST API"
        analysis = self.analyzer.analyze(request)
        
        is_valid, issues = self.analyzer.validate_analysis(analysis)
        self.assertTrue(is_valid)
        self.assertEqual(len(issues), 0)
        
        # Test invalid analysis
        invalid_analysis = RequestAnalysis(
            original_request="",
            project_type=ProjectType.UNKNOWN,
            complexity=ComplexityLevel.SIMPLE,
            tech_stack=TechnologyStack(),
            phases=[],
            estimated_agents=2,
            focus_areas=[],
            requirements={},
            constraints=[],
            implicit_requirements=[],
            ecosystem_context={},
            confidence_score=0.3
        )
        
        is_valid, issues = self.analyzer.validate_analysis(invalid_analysis)
        self.assertFalse(is_valid)
        self.assertGreater(len(issues), 0)
    
    def test_json_serialization(self):
        """Test JSON serialization of analysis results"""
        request = "Build a simple REST API"
        analysis = self.analyzer.analyze(request)
        
        # Convert to dictionary
        analysis_dict = analysis.to_dict()
        
        # Ensure it's JSON serializable
        json_str = json.dumps(analysis_dict)
        self.assertIsInstance(json_str, str)
        
        # Verify key fields are present
        parsed = json.loads(json_str)
        self.assertIn("project_type", parsed)
        self.assertIn("complexity", parsed)
        self.assertIn("tech_stack", parsed)
        self.assertIn("estimated_agents", parsed)


class TestTechnologyStack(unittest.TestCase):
    """Test TechnologyStack functionality"""
    
    def test_empty_stack(self):
        """Test empty technology stack"""
        stack = TechnologyStack()
        self.assertEqual(len(stack.languages), 0)
        self.assertEqual(len(stack.frameworks), 0)
        self.assertEqual(len(stack.databases), 0)
        
    def test_stack_to_dict(self):
        """Test technology stack dictionary conversion"""
        stack = TechnologyStack(
            languages=["python", "javascript"],
            frameworks=["fastapi", "react"],
            databases=["postgresql"],
            tools=["docker", "jwt"]
        )
        
        stack_dict = stack.to_dict()
        self.assertEqual(stack_dict["languages"], ["python", "javascript"])
        self.assertEqual(stack_dict["frameworks"], ["fastapi", "react"])
        self.assertEqual(stack_dict["databases"], ["postgresql"])
        self.assertEqual(stack_dict["tools"], ["docker", "jwt"])


if __name__ == "__main__":
    unittest.main()