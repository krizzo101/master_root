#!/usr/bin/env python3
"""
Deployment validation tests for the DPO system.

This test suite verifies that the DPO system is properly installed,
configured, and integrated with the master_root ecosystem.
"""

import json
import os
import sys
import subprocess
import unittest
from pathlib import Path
from typing import Dict, Any, List

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

class TestDPODeployment(unittest.TestCase):
    """Test suite for DPO deployment validation."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        cls.dpo_home = Path.home() / ".dpo"
        cls.dpo_root = Path(__file__).parent.parent
        cls.orchestrator_path = Path("/home/opsvi/master_root/apps/agent-orchestrator")
    
    def test_directory_structure(self):
        """Test that all required directories exist."""
        required_dirs = [
            "src",
            "templates",
            "config",
            "tests",
            "docs",
            "bin",
            "scripts"
        ]
        
        for dir_name in required_dirs:
            dir_path = self.dpo_root / dir_name
            self.assertTrue(
                dir_path.exists(),
                f"Required directory {dir_name} does not exist"
            )
    
    def test_core_files(self):
        """Test that core files are present."""
        core_files = [
            "setup.py",
            "requirements.txt",
            "install.sh",
            "bin/dpo",
            "src/__init__.py",
            "src/dpo_main_controller.py",
            "src/dpo_orchestrator_integration.py",
            "src/dpo_intelligence_integration.py"
        ]
        
        for file_path in core_files:
            full_path = self.dpo_root / file_path
            self.assertTrue(
                full_path.exists(),
                f"Core file {file_path} does not exist"
            )
    
    def test_templates(self):
        """Test that template files are valid JSON."""
        template_dir = self.dpo_root / "templates"
        
        if not template_dir.exists():
            self.skipTest("Templates directory not found")
        
        for template_file in template_dir.glob("*.json"):
            with open(template_file) as f:
                try:
                    template = json.load(f)
                    self.assertIn("name", template)
                    self.assertIn("workflow", template)
                    self.assertIn("structure", template)
                except json.JSONDecodeError as e:
                    self.fail(f"Invalid JSON in template {template_file.name}: {e}")
    
    def test_configuration(self):
        """Test configuration file validity."""
        config_file = self.dpo_root / "config/default_config.json"
        
        if not config_file.exists():
            self.skipTest("Default configuration not found")
        
        with open(config_file) as f:
            try:
                config = json.load(f)
                
                # Check required sections
                required_sections = [
                    "system",
                    "orchestration",
                    "communication",
                    "intelligence",
                    "templates",
                    "monitoring"
                ]
                
                for section in required_sections:
                    self.assertIn(
                        section, config,
                        f"Configuration missing required section: {section}"
                    )
            except json.JSONDecodeError as e:
                self.fail(f"Invalid configuration JSON: {e}")
    
    def test_python_imports(self):
        """Test that Python modules can be imported."""
        try:
            from src import (
                DPOMainController,
                DPOConfiguration,
                DPORequest,
                DPOOrchestrator
            )
            
            # Test instantiation
            config = DPOConfiguration()
            self.assertIsNotNone(config)
            
        except ImportError as e:
            self.fail(f"Failed to import DPO modules: {e}")
    
    def test_cli_executable(self):
        """Test that CLI is executable."""
        cli_path = self.dpo_root / "bin/dpo"
        
        if not cli_path.exists():
            self.skipTest("CLI not found")
        
        # Check if file is executable
        self.assertTrue(
            os.access(cli_path, os.X_OK),
            "CLI script is not executable"
        )
        
        # Try to run help command
        try:
            result = subprocess.run(
                [sys.executable, str(cli_path), "--help"],
                capture_output=True,
                text=True,
                timeout=5
            )
            self.assertEqual(result.returncode, 0, "CLI help command failed")
            self.assertIn("Development Process Orchestrator", result.stdout)
        except subprocess.TimeoutExpired:
            self.fail("CLI command timed out")
    
    def test_orchestrator_integration(self):
        """Test integration with agent-orchestrator."""
        if not self.orchestrator_path.exists():
            self.skipTest("Agent-orchestrator not found")
        
        # Check for integration files
        integration_script = self.dpo_root / "scripts/integrate_orchestrator.py"
        self.assertTrue(
            integration_script.exists(),
            "Integration script not found"
        )
        
        # Try to import orchestrator modules
        try:
            sys.path.insert(0, str(self.orchestrator_path / "src"))
            from generic_orchestrator import GenericOrchestrator
            self.assertTrue(True, "Successfully imported orchestrator")
        except ImportError:
            self.fail("Failed to import orchestrator modules")
    
    def test_dependencies(self):
        """Test that required dependencies are specified."""
        requirements_file = self.dpo_root / "requirements.txt"
        
        if not requirements_file.exists():
            self.skipTest("Requirements file not found")
        
        with open(requirements_file) as f:
            requirements = f.read()
        
        # Check for essential dependencies
        essential_deps = [
            "aiohttp",
            "asyncio",
            "click",
            "pydantic",
            "websockets"
        ]
        
        for dep in essential_deps:
            self.assertIn(
                dep, requirements,
                f"Essential dependency {dep} not in requirements"
            )
    
    def test_installation_script(self):
        """Test that installation script is valid."""
        install_script = self.dpo_root / "install.sh"
        
        if not install_script.exists():
            self.skipTest("Installation script not found")
        
        # Check script is executable
        self.assertTrue(
            os.access(install_script, os.X_OK),
            "Installation script is not executable"
        )
        
        # Basic syntax check
        result = subprocess.run(
            ["bash", "-n", str(install_script)],
            capture_output=True,
            text=True
        )
        self.assertEqual(
            result.returncode, 0,
            f"Installation script has syntax errors: {result.stderr}"
        )

class TestDPOFunctionality(unittest.TestCase):
    """Test suite for DPO functionality."""
    
    def test_template_validation(self):
        """Test template validation functionality."""
        try:
            from src.sdlc_template_system import SDLCTemplateSystem
            
            system = SDLCTemplateSystem()
            
            # Test with valid template structure
            valid_template = {
                "name": "test-template",
                "category": "test",
                "workflow": {
                    "phases": [
                        {
                            "name": "test_phase",
                            "agents": ["test_agent"],
                            "deliverables": ["test.md"]
                        }
                    ]
                }
            }
            
            # This should not raise an exception
            system.validate_template(valid_template)
            
        except ImportError:
            self.skipTest("SDLCTemplateSystem not available")
        except Exception as e:
            self.fail(f"Template validation failed: {e}")
    
    def test_configuration_loading(self):
        """Test configuration loading and validation."""
        try:
            from src.dpo_main_controller import DPOConfiguration
            
            # Test default configuration
            config = DPOConfiguration()
            self.assertIsNotNone(config.output_base_dir)
            self.assertIsInstance(config.max_parallel_agents, int)
            self.assertGreater(config.max_parallel_agents, 0)
            
            # Test configuration from dict
            custom_config = {
                "output_base_dir": "/tmp/test",
                "max_parallel_agents": 5
            }
            config = DPOConfiguration(**custom_config)
            self.assertEqual(config.output_base_dir, "/tmp/test")
            self.assertEqual(config.max_parallel_agents, 5)
            
        except ImportError:
            self.skipTest("DPOConfiguration not available")
    
    def test_request_creation(self):
        """Test DPO request creation and validation."""
        try:
            from src.dpo_intelligence_integration import DPORequest
            
            # Create a request
            request = DPORequest(
                request_text="Create a simple web application",
                project_type="web-app",
                technologies=["python", "flask"],
                priority="medium"
            )
            
            self.assertEqual(request.request_text, "Create a simple web application")
            self.assertEqual(request.project_type, "web-app")
            self.assertIn("python", request.technologies)
            
        except ImportError:
            self.skipTest("DPORequest not available")

class TestDPOIntegration(unittest.TestCase):
    """Test suite for ecosystem integration."""
    
    def test_mcp_availability(self):
        """Test MCP tools availability."""
        mcp_config = Path.home() / ".mcp.json"
        
        if not mcp_config.exists():
            self.skipTest("MCP configuration not found")
        
        with open(mcp_config) as f:
            config = json.load(f)
        
        servers = config.get("servers", {})
        
        # Check for important servers
        important_servers = ["knowledge", "shell_exec"]
        for server in important_servers:
            if server in servers:
                self.assertTrue(True, f"MCP server {server} available")
    
    def test_knowledge_base_integration(self):
        """Test knowledge base system integration."""
        kb_path = Path.home() / ".claude/knowledge"
        
        if kb_path.exists():
            self.assertTrue(True, "Knowledge base directory exists")
            
            # Check for key knowledge files
            docs_path = kb_path / "docs"
            if docs_path.exists():
                self.assertTrue(True, "Knowledge docs directory exists")
    
    def test_session_optimizer_integration(self):
        """Test session optimizer integration."""
        optimizer_path = Path("/home/opsvi/master_root/apps/session-optimizer")
        
        if optimizer_path.exists():
            self.assertTrue(True, "Session optimizer found")
            
            # Check for key files
            key_files = ["session_analytics_engine.py", "gpt5_cli.py"]
            for file in key_files:
                if (optimizer_path / file).exists():
                    self.assertTrue(True, f"Session optimizer file {file} exists")

def run_deployment_tests():
    """Run all deployment tests and generate report."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestDPODeployment))
    suite.addTests(loader.loadTestsFromTestCase(TestDPOFunctionality))
    suite.addTests(loader.loadTestsFromTestCase(TestDPOIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Generate report
    report = {
        "total_tests": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "success_rate": (result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100 if result.testsRun > 0 else 0
    }
    
    # Save report
    report_path = Path.home() / ".dpo/deployment_test_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📊 Test Report saved to: {report_path}")
    print(f"   Success Rate: {report['success_rate']:.1f}%")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_deployment_tests()
    sys.exit(0 if success else 1)