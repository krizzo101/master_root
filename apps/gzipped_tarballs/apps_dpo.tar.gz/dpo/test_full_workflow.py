#!/usr/bin/env python3
"""Test DPO Full Workflow Generation"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

async def test_full_workflow():
    """Test DPO's complete workflow generation process"""
    
    from src.dpo_main_controller import (
        DPOConfiguration, 
        DevelopmentProcessOrchestrator
    )
    
    # Configure DPO
    config = DPOConfiguration()
    config.enable_websocket = False
    config.enable_intelligence = True
    
    controller = DevelopmentProcessOrchestrator(config)
    
    print("=" * 70)
    print("DPO FULL WORKFLOW TEST")
    print("=" * 70)
    
    # Simple API request
    request = "Create a REST API for managing a todo list with CRUD operations"
    print(f"\nRequest: {request}")
    print("-" * 60)
    
    try:
        # Process the development request (this is the main entry point)
        result = await controller.process_development_request(request)
        
        print(f"\n✓ Workflow Created!")
        print(f"  - Workflow ID: {result['workflow_id']}")
        print(f"  - Status: {result['status']}")
        print(f"  - Output Directory: {result.get('output_dir', 'N/A')}")
        
        if 'workflow' in result:
            workflow = result['workflow']
            print(f"\n  Workflow Details:")
            print(f"  - Name: {workflow.get('name', 'unnamed')}")
            print(f"  - Total Tasks: {len(workflow.get('tasks', []))}")
            
            print(f"\n  Tasks Generated:")
            for i, task in enumerate(workflow.get('tasks', []), 1):
                task_id = task.get('task_id', 'unknown')
                task_type = task.get('task_type', 'unknown')
                dependencies = task.get('dependencies', [])
                
                deps_str = f" (depends on: {', '.join(dependencies)})" if dependencies else ""
                print(f"    {i}. [{task_type}] {task_id}{deps_str}")
                
                # Show prompt preview
                prompt = task.get('prompt', '')
                if prompt:
                    preview = prompt[:100] + "..." if len(prompt) > 100 else prompt
                    print(f"       → {preview}")
        
        # Show the generated files
        output_dir = Path(result.get('output_dir', 'output/dpo_workflows'))
        if output_dir.exists():
            print(f"\n  Generated Files:")
            workflow_files = list(output_dir.glob("*.json"))
            for file in workflow_files[:5]:  # Show first 5 files
                print(f"    - {file.name}")
                
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 70)

if __name__ == "__main__":
    asyncio.run(test_full_workflow())