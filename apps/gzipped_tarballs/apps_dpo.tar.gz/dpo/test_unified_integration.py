#!/usr/bin/env python3
"""
Test DPO integration with UnifiedOrchestrator's execution planning
"""

import asyncio
import sys
from pathlib import Path

# Add paths
sys.path.insert(0, "/home/opsvi/master_root/apps/dpo/src")
sys.path.insert(0, "/home/opsvi/master_root/apps/agent-orchestrator/src")

async def test_dpo_unified():
    """Test DPO with unified orchestrator features"""
    
    from dpo_main_controller import DPOMainController
    from unified.unified_orchestrator import create_standard_orchestrator
    from unified.enhanced_agent_task import EnhancedAgentTask
    
    # Create DPO controller
    dpo = DPOMainController({
        "output_base_dir": "/tmp/dpo_unified_test",
        "enable_intelligence_review": True
    })
    
    # Create unified orchestrator with execution planning
    orchestrator = create_standard_orchestrator(
        output_dir=Path("/tmp/unified_test"),
        max_parallel=5
    )
    
    # Test request
    request = "Build a simple REST API for user management"
    
    print(f"Testing DPO with request: {request}")
    print("This should generate SDLC phases with execution planning...")
    
    # Process through DPO
    enhanced_workflow = await dpo.process_request(request)
    
    print(f"\nDPO generated {len(enhanced_workflow.tasks)} tasks")
    print(f"Phases detected: {set(t.get('phase') for t in enhanced_workflow.tasks if t.get('phase'))}")
    
    # Convert to EnhancedAgentTasks for unified orchestrator
    enhanced_tasks = []
    for task in enhanced_workflow.tasks:
        etask = EnhancedAgentTask(
            task_id=task['task_id'],
            task_type=task['task_type'],
            prompt=task['prompt'],
            phase=task.get('phase', 'execution'),
            priority=task.get('priority', 0),
            validation_required=True
        )
        enhanced_tasks.append(etask)
    
    print(f"\nReady to execute with UnifiedOrchestrator")
    print(f"Features enabled: {orchestrator.config.enabled_features}")
    
    return enhanced_tasks

if __name__ == "__main__":
    asyncio.run(test_dpo_unified())