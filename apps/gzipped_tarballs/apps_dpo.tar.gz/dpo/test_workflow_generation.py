#!/usr/bin/env python3
"""Test DPO Workflow Generation - See what DPO creates"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

async def test_workflow_generation():
    """Test what workflows DPO generates for different requests"""
    
    from src.dpo_main_controller import (
        DPOConfiguration, 
        DevelopmentProcessOrchestrator
    )
    
    # Configure DPO
    config = DPOConfiguration()
    config.enable_websocket = False
    config.enable_intelligence = True  # Enable to see intelligent enhancements
    
    controller = DevelopmentProcessOrchestrator(config)
    
    # Test requests
    test_requests = [
        "Create a simple REST API for user management",
        "Build a React dashboard with authentication",
        "Implement a data pipeline for log processing",
        "Create a CLI tool for file synchronization"
    ]
    
    print("=" * 70)
    print("DPO WORKFLOW GENERATION TEST")
    print("=" * 70)
    
    for i, request in enumerate(test_requests, 1):
        print(f"\n{i}. REQUEST: {request}")
        print("-" * 60)
        
        # Analyze request
        analysis = controller.request_analyzer.analyze(request)
        print(f"   Analysis:")
        print(f"   - Type: {analysis.request_type}")
        print(f"   - Complexity: {analysis.complexity}")
        print(f"   - Project Type: {analysis.project_type}")
        print(f"   - Technologies: {', '.join(analysis.suggested_technologies)}")
        print(f"   - Estimated Effort: {analysis.estimated_effort}")
        print(f"   - Confidence: {analysis.confidence_score:.2f}")
        
        # Generate workflow (internal method, not via API)
        try:
            # This would normally be done internally by process_development_request
            workflow = await controller._generate_workflow(request, analysis)
            
            print(f"\n   Generated Workflow:")
            print(f"   - Total Tasks: {len(workflow.tasks)}")
            print(f"   - Workflow Name: {workflow.name}")
            
            # Show task breakdown
            print(f"\n   Task Breakdown:")
            for j, task in enumerate(workflow.tasks, 1):
                deps = f" <- {task.dependencies}" if task.dependencies else ""
                print(f"     {j}. [{task.task_type}] {task.task_id}{deps}")
                print(f"        Prompt: {task.prompt[:80]}...")
                
        except Exception as e:
            print(f"   Workflow generation failed: {e}")
    
    print("\n" + "=" * 70)
    print("✓ DPO WORKFLOW GENERATION TEST COMPLETE")
    print("=" * 70)

if __name__ == "__main__":
    asyncio.run(test_workflow_generation())