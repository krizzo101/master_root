#!/usr/bin/env python3
"""Test DPO Standalone - No Integration"""

import sys
import json
from pathlib import Path

# Only use DPO's own code
sys.path.insert(0, str(Path(__file__).parent))

def test_dpo_basic():
    """Test basic DPO functionality without orchestrator"""
    print("=" * 60)
    print("DPO STANDALONE TEST - No Integration")
    print("=" * 60)
    
    # Test imports
    print("\n1. Testing imports...")
    try:
        from src.dpo_main_controller import (
            DPOConfiguration, 
            DevelopmentProcessOrchestrator,
            RequestAnalyzer
        )
        print("✓ Imports successful")
    except Exception as e:
        print(f"✗ Import failed: {e}")
        return False
    
    # Test configuration
    print("\n2. Testing configuration...")
    try:
        config = DPOConfiguration()
        config.enable_websocket = False  # Disable for testing
        config.enable_intelligence = False  # Disable to avoid complexity
        print(f"✓ Config created: output_base_dir={config.output_base_dir}")
    except Exception as e:
        print(f"✗ Config failed: {e}")
        return False
    
    # Test request analyzer (simple component)
    print("\n3. Testing request analyzer...")
    try:
        analyzer = RequestAnalyzer()
        request = "Create a simple REST API"
        analysis = analyzer.analyze(request)
        print(f"✓ Analysis completed:")
        print(f"  - Type: {analysis.request_type}")
        print(f"  - Complexity: {analysis.complexity}")
        print(f"  - Confidence: {analysis.confidence_score:.2f}")
    except Exception as e:
        print(f"✗ Analyzer failed: {e}")
        return False
    
    # Test controller initialization (without full orchestration)
    print("\n4. Testing controller initialization...")
    try:
        controller = DevelopmentProcessOrchestrator(config)
        print(f"✓ Controller initialized")
        print(f"  - Orchestrator: {controller.orchestrator is not None}")
        print(f"  - Template system: {controller.template_system is not None}")
        print(f"  - Metrics: {controller.metrics is not None}")
    except Exception as e:
        print(f"✗ Controller init failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print("\n" + "=" * 60)
    print("✓ DPO STANDALONE TEST PASSED")
    print("=" * 60)
    return True

if __name__ == "__main__":
    success = test_dpo_basic()
    sys.exit(0 if success else 1)