#!/usr/bin/env python3
"""
Test script for DPO integration flow
Tests the complete chain from request to workflow submission
"""

import asyncio
import json
import logging
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from dpo_main_controller import DevelopmentProcessOrchestrator, DPOConfiguration

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def test_basic_flow():
    """Test basic request processing flow"""
    logger.info("Starting basic flow test...")
    
    # Create config with intelligence disabled for initial test
    config = DPOConfiguration(
        output_base_dir="output/test_integration",
        max_parallel_agents=3,
        enable_intelligence=False,  # Start with disabled
        enable_context_injection=False,  # Start with disabled
        enable_websocket=False,
        enable_dashboard=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    try:
        # Test simple request
        result = await dpo.process_development_request(
            request="Build a simple hello world API",
            project_type="api",
            complexity="simple",
            context={"framework": "FastAPI"}
        )
        
        logger.info(f"Basic flow result: {json.dumps(result, indent=2)}")
        
        if result["success"]:
            logger.info("✅ Basic flow test passed!")
            return True
        else:
            logger.error(f"❌ Basic flow test failed: {result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Basic flow test failed with exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await dpo.shutdown()


async def test_intelligence_flow():
    """Test flow with intelligence enabled"""
    logger.info("Starting intelligence flow test...")
    
    config = DPOConfiguration(
        output_base_dir="output/test_integration_intelligence",
        max_parallel_agents=3,
        enable_intelligence=True,  # Enable intelligence
        enable_context_injection=False,  # Still disabled
        enable_websocket=False,
        enable_dashboard=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    try:
        result = await dpo.process_development_request(
            request="Build a task management API with authentication",
            project_type="api",
            complexity="moderate",
            context={"framework": "FastAPI"},
            enhancement_prefs={"prioritize_quality": True}
        )
        
        logger.info(f"Intelligence flow result: {json.dumps(result, indent=2)}")
        
        if result["success"]:
            logger.info("✅ Intelligence flow test passed!")
            return True
        else:
            logger.error(f"❌ Intelligence flow test failed: {result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Intelligence flow test failed with exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await dpo.shutdown()


async def test_context_flow():
    """Test flow with context injection enabled"""
    logger.info("Starting context injection flow test...")
    
    config = DPOConfiguration(
        output_base_dir="output/test_integration_context",
        max_parallel_agents=3,
        enable_intelligence=False,  # Disabled for this test
        enable_context_injection=True,  # Enable context
        enable_websocket=False,
        enable_dashboard=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    try:
        result = await dpo.process_development_request(
            request="Build a CLI tool for file management",
            project_type="cli",
            complexity="simple",
            context={"language": "Python"}
        )
        
        logger.info(f"Context flow result: {json.dumps(result, indent=2)}")
        
        if result["success"]:
            logger.info("✅ Context flow test passed!")
            return True
        else:
            logger.error(f"❌ Context flow test failed: {result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Context flow test failed with exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await dpo.shutdown()


async def test_full_flow():
    """Test complete flow with all features enabled"""
    logger.info("Starting full integration flow test...")
    
    config = DPOConfiguration(
        output_base_dir="output/test_integration_full",
        max_parallel_agents=5,
        enable_intelligence=True,  # All enabled
        enable_context_injection=True,  # All enabled
        enable_websocket=False,  # Keep websocket disabled for testing
        enable_dashboard=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    try:
        result = await dpo.process_development_request(
            request="Build a modern web application with user authentication, dashboard, and real-time notifications",
            project_type="web_app",
            complexity="complex",
            context={
                "framework": "React",
                "backend": "Node.js",
                "database": "PostgreSQL"
            },
            enhancement_prefs={
                "prioritize_quality": True,
                "prioritize_innovation": True,
                "prioritize_performance": True
            }
        )
        
        logger.info(f"Full flow result: {json.dumps(result, indent=2)}")
        
        if result["success"]:
            logger.info("✅ Full integration flow test passed!")
            logger.info(f"Workflow ID: {result['workflow_id']}")
            logger.info(f"Enhancements applied: {result['enhancements_count']}")
            logger.info(f"Phases created: {result['phases_count']}")
            logger.info(f"Processing time: {result['processing_time']:.2f}s")
            return True
        else:
            logger.error(f"❌ Full flow test failed: {result.get('error')}")
            if "traceback" in result:
                logger.error(f"Traceback:\n{result['traceback']}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Full flow test failed with exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await dpo.shutdown()


async def main():
    """Run all integration tests"""
    logger.info("=" * 60)
    logger.info("DPO Integration Flow Test Suite")
    logger.info("=" * 60)
    
    results = []
    
    # Test 1: Basic flow (no intelligence, no context)
    logger.info("\n" + "=" * 40)
    logger.info("Test 1: Basic Flow")
    logger.info("=" * 40)
    results.append(await test_basic_flow())
    
    # Test 2: Intelligence flow
    logger.info("\n" + "=" * 40)
    logger.info("Test 2: Intelligence Flow")
    logger.info("=" * 40)
    results.append(await test_intelligence_flow())
    
    # Test 3: Context flow
    logger.info("\n" + "=" * 40)
    logger.info("Test 3: Context Injection Flow")
    logger.info("=" * 40)
    results.append(await test_context_flow())
    
    # Test 4: Full integration
    logger.info("\n" + "=" * 40)
    logger.info("Test 4: Full Integration Flow")
    logger.info("=" * 40)
    results.append(await test_full_flow())
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("Test Summary")
    logger.info("=" * 60)
    
    test_names = ["Basic Flow", "Intelligence Flow", "Context Flow", "Full Integration"]
    for i, (name, passed) in enumerate(zip(test_names, results)):
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info(f"{i+1}. {name}: {status}")
    
    total_passed = sum(results)
    total_tests = len(results)
    
    logger.info(f"\nTotal: {total_passed}/{total_tests} tests passed")
    
    if total_passed == total_tests:
        logger.info("\n🎉 All integration tests passed!")
        return 0
    else:
        logger.error(f"\n⚠️  {total_tests - total_passed} test(s) failed")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)