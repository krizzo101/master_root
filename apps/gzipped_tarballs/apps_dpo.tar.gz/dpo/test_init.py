#!/usr/bin/env python3
"""Test DPO initialization issues"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test all imports work"""
    try:
        from src.dpo_main_controller import DPOConfiguration, DevelopmentProcessOrchestrator
        print("✓ Main controller imports")
    except Exception as e:
        print(f"✗ Main controller import failed: {e}")
        return False
    
    try:
        from src.dpo_orchestrator_integration import DPOOrchestrator
        print("✓ Orchestrator integration imports")
    except Exception as e:
        print(f"✗ Orchestrator integration import failed: {e}")
        return False
    
    try:
        from src.intelligence_review_engine_enhanced import EnhancementIntelligenceEngine
        print("✓ Intelligence engine imports")
    except Exception as e:
        print(f"✗ Intelligence engine import failed: {e}")
        return False
    
    return True

def test_config():
    """Test configuration creation"""
    from src.dpo_main_controller import DPOConfiguration
    
    try:
        config = DPOConfiguration()
        print(f"✓ Configuration created")
        
        # Check attributes
        attrs = ['output_base_dir', 'max_parallel_agents', 'enable_websocket', 
                 'enable_intelligence', 'enable_context_injection']
        for attr in attrs:
            if hasattr(config, attr):
                print(f"  ✓ config.{attr} = {getattr(config, attr)}")
            else:
                print(f"  ✗ config.{attr} missing")
        
        # Test save method (will fail if not dataclass)
        try:
            # Don't actually save, just test if it would work
            import json
            from dataclasses import asdict
            data = asdict(config)
            print(f"  ✗ DPOConfiguration is not a dataclass but uses asdict()")
        except:
            print(f"  ✗ DPOConfiguration.save() will fail - not a dataclass")
            
    except Exception as e:
        print(f"✗ Configuration creation failed: {e}")
        return False
    
    return True

def test_controller_init():
    """Test controller initialization"""
    from src.dpo_main_controller import DPOConfiguration, DevelopmentProcessOrchestrator
    
    try:
        config = DPOConfiguration()
        controller = DevelopmentProcessOrchestrator(config)
        print("✓ Controller initialized")
    except Exception as e:
        print(f"✗ Controller initialization failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    print("Testing DPO Initialization Chain")
    print("=" * 40)
    
    if test_imports():
        print("\n" + "=" * 40)
        test_config()
        print("\n" + "=" * 40)
        test_controller_init()