#!/usr/bin/env python3
"""
End-to-End Demonstration of Dynamic Instructions and Hierarchical Scoping
This demonstrates how an agent queries for instructions on startup and uses
the hierarchical scoping system for project isolation.
"""

import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from neo4j import GraphDatabase
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from sentence_transformers import SentenceTransformer
import numpy as np

class DynamicInstructionSystem:
    """Complete system for dynamic instructions and hierarchical scoping"""
    
    def __init__(self):
        # Neo4j connection
        self.driver = GraphDatabase.driver(
            "bolt://localhost:7687",
            auth=("neo4j", "password")
        )
        
        # Qdrant connection
        self.qdrant = QdrantClient(host="localhost", port=6333)
        
        # Embedding model
        self.embedder = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
        
        # Ensure collections exist
        self._ensure_collections()
    
    def _ensure_collections(self):
        """Ensure Qdrant collections exist"""
        collections = [col.name for col in self.qdrant.get_collections().collections]
        
        if "instructions" not in collections:
            self.qdrant.create_collection(
                collection_name="instructions",
                vectors_config=VectorParams(size=384, distance=Distance.COSINE)
            )
    
    def setup_project_hierarchy(self):
        """Setup the project hierarchy with proper scoping"""
        print("\n=== Setting up Project Hierarchy ===")
        
        with self.driver.session() as session:
            # Create master_root project
            session.run("""
                MERGE (p:Project {path: '/home/opsvi/master_root'})
                SET p.name = 'master_root',
                    p.type = 'root',
                    p.created_at = datetime(),
                    p.updated_at = datetime()
                RETURN p
            """)
            
            # Create ACCF app project
            session.run("""
                MERGE (p:Project {path: '/home/opsvi/master_root/apps/ACCF'})
                SET p.name = 'ACCF',
                    p.type = 'app',
                    p.parent_path = '/home/opsvi/master_root',
                    p.created_at = datetime(),
                    p.updated_at = datetime()
                RETURN p
            """)
            
            # Create project-intelligence app
            session.run("""
                MERGE (p:Project {path: '/home/opsvi/master_root/apps/project-intelligence'})
                SET p.name = 'project-intelligence',
                    p.type = 'app',
                    p.parent_path = '/home/opsvi/master_root',
                    p.created_at = datetime(),
                    p.updated_at = datetime()
                RETURN p
            """)
            
            # Create monitoring project (separate from master_root)
            session.run("""
                MERGE (p:Project {path: '/home/opsvi/monitoring'})
                SET p.name = 'monitoring',
                    p.type = 'standalone',
                    p.created_at = datetime(),
                    p.updated_at = datetime()
                RETURN p
            """)
            
            print("✓ Created project hierarchy")
    
    def store_instructions(self):
        """Store different levels of instructions in the KB"""
        print("\n=== Storing Instructions ===")
        
        instructions = [
            {
                "type": "GLOBAL_INSTRUCTIONS",
                "scope": "global",
                "content": """# Global Instructions for All Agents
                
## Core Principles
1. Always think before acting (use mcp__thinking__sequentialthinking)
2. Use parallel execution for multiple operations (Task tool)
3. Store discoveries in knowledge base immediately
4. Create TodoWrite for tasks with 3+ steps

## Quality Standards
- Test all code changes before committing
- Document complex logic with clear comments
- Follow project-specific conventions
- Never expose secrets or credentials

## Error Handling
- Capture and log all errors
- Provide helpful error messages
- Implement proper fallback mechanisms
- Store error solutions in KB for future reference""",
                "project_path": None
            },
            {
                "type": "PROJECT_INSTRUCTIONS",
                "scope": "project",
                "content": """# Master Root Project Instructions

## Project Structure
- apps/: Application-specific code
- libs/: Shared libraries and utilities
- scripts/: Utility and maintenance scripts
- docs/: Project documentation

## Development Workflow
1. Create feature branch from main
2. Implement changes with tests
3. Run linting and type checking
4. Submit PR with clear description

## Naming Conventions
- Apps: lowercase with hyphens (e.g., project-intelligence)
- Libraries: lowercase with underscores (e.g., opsvi_common)
- Classes: PascalCase
- Functions/methods: snake_case
- Constants: UPPER_SNAKE_CASE""",
                "project_path": "/home/opsvi/master_root"
            },
            {
                "type": "APP_INSTRUCTIONS",
                "scope": "app",
                "content": """# ACCF Application Instructions

## Purpose
ACCF (Automated Consulting and Code Framework) provides intelligent
consulting services with context-aware file selection and analysis.

## Key Components
- Consult Suite: Main consulting interface
- Gatekeeper: Intelligent file selection using KB
- Critics: Quality assurance and validation
- RequestCard: Structured request definition

## Usage Guidelines
1. Always use KB gatekeeper for file selection
2. Validate all consult requests through critics
3. Store consult results in .consult/ directory
4. Generate embeddings for new knowledge entries

## Testing
- Unit tests: pytest tests/
- Integration tests: pytest tests/integration/
- Coverage requirement: 80% minimum""",
                "project_path": "/home/opsvi/master_root/apps/ACCF"
            },
            {
                "type": "APP_INSTRUCTIONS", 
                "scope": "app",
                "content": """# Project Intelligence Instructions

## Purpose
Analyzes codebases to extract structure, complexity metrics,
dependencies, and architectural patterns. Integrates with KB
for persistent storage and retrieval.

## Analysis Capabilities
- File structure and organization
- Code complexity metrics
- Dependency mapping
- Pattern detection
- Architecture visualization

## KB Integration
1. Store all analysis results with project scoping
2. Generate embeddings for semantic search
3. Update existing entries on re-analysis
4. Maintain version history

## Output Formats
- JSON Lines (.jsonl) for streaming
- Markdown reports for human review
- Graph structures for Neo4j storage""",
                "project_path": "/home/opsvi/master_root/apps/project-intelligence"
            }
        ]
        
        with self.driver.session() as session:
            for inst in instructions:
                # Store instruction
                result = session.run("""
                    CREATE (k:Knowledge {
                        id: randomUUID(),
                        knowledge_type: $type,
                        content: $content,
                        scope: $scope,
                        project_path: $project_path,
                        created_at: datetime(),
                        updated_at: datetime()
                    })
                    RETURN k.id as id
                """, type=inst["type"], content=inst["content"], 
                    scope=inst["scope"], project_path=inst["project_path"])
                
                knowledge_id = result.single()["id"]
                
                # Link to project if applicable
                if inst["project_path"]:
                    session.run("""
                        MATCH (p:Project {path: $project_path})
                        MATCH (k:Knowledge {id: $knowledge_id})
                        MERGE (p)-[:HAS_INSTRUCTION]->(k)
                    """, project_path=inst["project_path"], knowledge_id=knowledge_id)
                
                # Generate and store embedding
                embedding = self.embedder.encode(inst["content"]).tolist()
                
                # Store in Qdrant
                self.qdrant.upsert(
                    collection_name="instructions",
                    points=[
                        PointStruct(
                            id=knowledge_id,
                            vector=embedding,
                            payload={
                                "type": inst["type"],
                                "scope": inst["scope"],
                                "project_path": inst["project_path"] or "global",
                                "content": inst["content"][:500]  # Preview
                            }
                        )
                    ]
                )
                
                print(f"✓ Stored {inst['type']} for {inst.get('project_path', 'global')}")
    
    def agent_startup_query(self, working_dir: str = "/home/opsvi/master_root/apps/ACCF"):
        """Demonstrate how an agent queries for instructions on startup"""
        print(f"\n=== Agent Startup in {working_dir} ===")
        
        with self.driver.session() as session:
            # 1. Get global instructions
            global_inst = session.run("""
                MATCH (k:Knowledge {knowledge_type: 'GLOBAL_INSTRUCTIONS'})
                RETURN k.content as content
                LIMIT 1
            """).single()
            
            if global_inst:
                print("\n[1] Global Instructions loaded:")
                print(global_inst["content"][:200] + "...")
            
            # 2. Get project instructions based on working directory
            project_inst = session.run("""
                MATCH (k:Knowledge {knowledge_type: 'PROJECT_INSTRUCTIONS'})
                WHERE k.project_path = $project_path
                   OR $working_dir STARTS WITH k.project_path
                RETURN k.content as content, k.project_path as path
                ORDER BY SIZE(k.project_path) DESC
                LIMIT 1
            """, project_path=working_dir, working_dir=working_dir).single()
            
            if project_inst:
                print(f"\n[2] Project Instructions for {project_inst['path']}:")
                print(project_inst["content"][:200] + "...")
            
            # 3. Get app-specific instructions
            app_inst = session.run("""
                MATCH (k:Knowledge {knowledge_type: 'APP_INSTRUCTIONS'})
                WHERE k.project_path = $working_dir
                   OR $working_dir STARTS WITH k.project_path
                RETURN k.content as content, k.project_path as path
                ORDER BY SIZE(k.project_path) DESC
                LIMIT 1
            """, working_dir=working_dir).single()
            
            if app_inst:
                print(f"\n[3] App Instructions for {app_inst['path']}:")
                print(app_inst["content"][:200] + "...")
            
            # 4. Search for relevant context based on current task
            print("\n[4] Searching for relevant context...")
            query_embedding = self.embedder.encode("gatekeeper file selection consulting").tolist()
            
            search_results = self.qdrant.search(
                collection_name="instructions",
                query_vector=query_embedding,
                limit=3
            )
            
            if search_results:
                print("Found relevant instructions:")
                for result in search_results:
                    print(f"  - {result.payload.get('type', 'Unknown')} "
                          f"(score: {result.score:.3f})")
    
    def demonstrate_scoped_search(self):
        """Demonstrate project-scoped searches"""
        print("\n=== Demonstrating Scoped Search ===")
        
        test_queries = [
            ("Find ACCF gatekeeper implementation", "/home/opsvi/master_root/apps/ACCF"),
            ("Find project analysis functions", "/home/opsvi/master_root/apps/project-intelligence"),
            ("Find monitoring dashboard", "/home/opsvi/monitoring")
        ]
        
        with self.driver.session() as session:
            for query, scope in test_queries:
                print(f"\nQuery: '{query}' in scope: {scope}")
                
                # Generate embedding for query
                query_embedding = self.embedder.encode(query).tolist()
                
                # Search in Qdrant with proper filter
                from qdrant_client.models import Filter, FieldCondition, MatchValue
                
                results = self.qdrant.search(
                    collection_name="instructions",
                    query_vector=query_embedding,
                    limit=3,
                    query_filter=Filter(
                        should=[
                            FieldCondition(key="project_path", match=MatchValue(value=scope)),
                            FieldCondition(key="project_path", match=MatchValue(value="global"))
                        ]
                    )
                )
                
                if results:
                    for r in results:
                        print(f"  ✓ {r.payload.get('type')} - Score: {r.score:.3f}")
                else:
                    print("  ✗ No results found")
    
    def cleanup(self):
        """Close connections"""
        self.driver.close()

def main():
    """Run the complete demonstration"""
    print("=" * 60)
    print("Dynamic Instructions & Hierarchical Scoping Demonstration")
    print("=" * 60)
    
    demo = DynamicInstructionSystem()
    
    try:
        # Setup hierarchy
        demo.setup_project_hierarchy()
        
        # Store instructions
        demo.store_instructions()
        
        # Demonstrate agent startup
        demo.agent_startup_query("/home/opsvi/master_root/apps/ACCF")
        demo.agent_startup_query("/home/opsvi/master_root/apps/project-intelligence")
        demo.agent_startup_query("/home/opsvi/monitoring")
        
        # Demonstrate scoped search
        demo.demonstrate_scoped_search()
        
        print("\n" + "=" * 60)
        print("✓ Demonstration Complete!")
        print("=" * 60)
        
    finally:
        demo.cleanup()

if __name__ == "__main__":
    main()