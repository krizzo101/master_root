#!/usr/bin/env python3
"""
Comprehensive Documentation Workflow System Tests

This test suite validates all aspects of the documentation workflow system
including configuration, templates, checkpoint/resume, error handling, and integration.
"""

import asyncio
import json
import logging
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

# Add src to Python path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DocumentationWorkflowTestSuite:
    """Comprehensive test suite for documentation workflow system"""
    
    def __init__(self):
        self.test_results = []
        self.temp_dirs = []
        
    async def run_all_tests(self):
        """Run all test categories"""
        logger.info("Starting Comprehensive Documentation Workflow Test Suite")
        
        test_categories = [
            ("Component Tests", self._run_component_tests),
            ("Configuration Tests", self._run_configuration_tests), 
            ("Template Tests", self._run_template_tests),
            ("File Structure Tests", self._run_file_structure_tests),
            ("Error Handling Tests", self._run_error_handling_tests),
            ("Performance Tests", self._run_performance_tests),
            ("Resume Capability Tests", self._run_resume_tests)
        ]
        
        for category_name, test_method in test_categories:
            logger.info(f"\n{'='*20} {category_name} {'='*20}")
            try:
                results = await test_method()
                self.test_results.extend(results)
            except Exception as e:
                logger.error(f"Test category {category_name} failed: {e}")
                self.test_results.append({
                    "category": category_name,
                    "test": "category_execution",
                    "status": "ERROR",
                    "error": str(e)
                })
        
        self._cleanup_temp_dirs()
        self.print_comprehensive_summary()
        return self.test_results
    
    async def _run_component_tests(self) -> List[Dict]:
        """Test individual component functionality"""
        results = []
        
        # Test 1: Configuration creation and validation
        try:
            from pathlib import Path
            from src.workflows.documentation_workflow import DocumentationConfig
            
            config = DocumentationConfig(
                app_name="component-test",
                app_root=Path("/home/opsvi/master_root/apps/agent-orchestrator"),
                output_dir=Path("/tmp/component-test-docs"),
                detail_level="comprehensive",
                include_api_docs=True,
                include_architecture=True,
                include_deployment=True,
                include_user_guide=True
            )
            
            results.append({
                "category": "Component Tests",
                "test": "config_creation",
                "status": "PASS",
                "details": {
                    "app_name": config.app_name,
                    "detail_level": config.detail_level,
                    "features": {
                        "api_docs": config.include_api_docs,
                        "architecture": config.include_architecture,
                        "deployment": config.include_deployment,
                        "user_guide": config.include_user_guide
                    }
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Component Tests",
                "test": "config_creation", 
                "status": "FAIL",
                "error": str(e)
            })
        
        # Test 2: Execution plan template loading
        try:
            from src.workflows.execution_plans import ExecutionPlanTemplates
            
            comprehensive_plan = ExecutionPlanTemplates.system_documentation_comprehensive("test-app", "/tmp/test", "/tmp/docs")
            
            results.append({
                "category": "Component Tests",
                "test": "execution_plan_templates",
                "status": "PASS",
                "details": {
                    "template_loaded": True,
                    "plan_id": comprehensive_plan.plan_id,
                    "phase_count": len(comprehensive_plan.phases),
                    "has_checkpoints": any(phase.get("checkpoint", False) for phase in comprehensive_plan.phases)
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Component Tests",
                "test": "execution_plan_templates",
                "status": "FAIL", 
                "error": str(e)
            })
        
        return results
    
    async def _run_configuration_tests(self) -> List[Dict]:
        """Test configuration options and validation"""
        results = []
        
        # Test different detail levels
        detail_levels = ["minimal", "standard", "comprehensive"]
        
        for level in detail_levels:
            try:
                from pathlib import Path
                from src.workflows.documentation_workflow import DocumentationConfig
                
                config = DocumentationConfig(
                    app_name=f"config-test-{level}",
                    app_root=Path("/tmp/test"),
                    output_dir=Path(f"/tmp/test-{level}"),
                    detail_level=level
                )
                
                results.append({
                    "category": "Configuration Tests",
                    "test": f"detail_level_{level}",
                    "status": "PASS",
                    "details": {"detail_level": config.detail_level}
                })
                
            except Exception as e:
                results.append({
                    "category": "Configuration Tests", 
                    "test": f"detail_level_{level}",
                    "status": "FAIL",
                    "error": str(e)
                })
        
        # Test feature toggles
        feature_combinations = [
            {"include_api_docs": True, "include_architecture": False},
            {"include_deployment": True, "include_user_guide": False},
            {"include_api_docs": False, "include_architecture": False}
        ]
        
        for i, features in enumerate(feature_combinations):
            try:
                from pathlib import Path
                from src.workflows.documentation_workflow import DocumentationConfig
                
                config = DocumentationConfig(
                    app_name=f"feature-test-{i}",
                    app_root=Path("/tmp/test"),
                    output_dir=Path(f"/tmp/feature-test-{i}"),
                    **features
                )
                
                results.append({
                    "category": "Configuration Tests",
                    "test": f"feature_combination_{i}",
                    "status": "PASS", 
                    "details": features
                })
                
            except Exception as e:
                results.append({
                    "category": "Configuration Tests",
                    "test": f"feature_combination_{i}",
                    "status": "FAIL",
                    "error": str(e)
                })
        
        return results
    
    async def _run_template_tests(self) -> List[Dict]:
        """Test template system functionality"""
        results = []
        
        try:
            from src.workflows.execution_plans import ExecutionPlanTemplates
            
            template_methods = [
                ("comprehensive", ExecutionPlanTemplates.system_documentation_comprehensive),
                ("standard", ExecutionPlanTemplates.system_documentation_standard),
                ("minimal", ExecutionPlanTemplates.system_documentation_minimal)
            ]
            
            for template_name, template_method in template_methods:
                try:
                    plan = template_method("test-app", "/tmp/test", "/tmp/docs")
                    
                    results.append({
                        "category": "Template Tests",
                        "test": f"template_{template_name}",
                        "status": "PASS",
                        "details": {
                            "plan_id": plan.plan_id,
                            "phase_count": len(plan.phases),
                            "workflow_type": plan.workflow_type,
                            "has_app_config": hasattr(plan, "app_config")
                        }
                    })
                    
                except Exception as e:
                    results.append({
                        "category": "Template Tests",
                        "test": f"template_{template_name}",
                        "status": "FAIL",
                        "error": str(e)
                    })
        
        except Exception as e:
            results.append({
                "category": "Template Tests",
                "test": "template_system_initialization",
                "status": "FAIL",
                "error": str(e)
            })
        
        return results
    
    async def _run_file_structure_tests(self) -> List[Dict]:
        """Test file structure analysis capabilities"""
        results = []
        
        # Test with real orchestrator directory
        test_dir = Path("/home/opsvi/master_root/apps/agent-orchestrator")
        
        if test_dir.exists():
            try:
                # Analyze file types
                file_analysis = {
                    "python_files": len(list(test_dir.glob("**/*.py"))),
                    "json_files": len(list(test_dir.glob("**/*.json"))),
                    "md_files": len(list(test_dir.glob("**/*.md"))),
                    "yaml_files": len(list(test_dir.glob("**/*.yaml"))) + len(list(test_dir.glob("**/*.yml"))),
                    "directories": len([d for d in test_dir.rglob("*") if d.is_dir()]),
                    "total_files": len(list(test_dir.rglob("*.*")))
                }
                
                # Check for key structure elements
                key_files = {
                    "main_py": (test_dir / "main.py").exists(),
                    "src_dir": (test_dir / "src").exists(), 
                    "requirements": (test_dir / "requirements.txt").exists(),
                    "readme": (test_dir / "README.md").exists()
                }
                
                results.append({
                    "category": "File Structure Tests",
                    "test": "orchestrator_structure_analysis",
                    "status": "PASS",
                    "details": {
                        "file_analysis": file_analysis,
                        "key_files": key_files,
                        "suitable_for_docs": file_analysis["python_files"] > 10
                    }
                })
                
            except Exception as e:
                results.append({
                    "category": "File Structure Tests",
                    "test": "orchestrator_structure_analysis", 
                    "status": "FAIL",
                    "error": str(e)
                })
        
        # Test with various project structures
        temp_dir = self._create_temp_dir("structure_test")
        
        try:
            # Create mock project structure
            (temp_dir / "src").mkdir()
            (temp_dir / "src" / "__init__.py").touch()
            (temp_dir / "src" / "main.py").write_text("# Mock main file")
            (temp_dir / "tests").mkdir()
            (temp_dir / "README.md").write_text("# Mock Project")
            (temp_dir / "requirements.txt").write_text("requests==2.28.0")
            
            # Analyze structure
            structure_valid = all([
                (temp_dir / "src").exists(),
                (temp_dir / "README.md").exists(),
                len(list(temp_dir.glob("**/*.py"))) > 0
            ])
            
            results.append({
                "category": "File Structure Tests", 
                "test": "mock_project_structure",
                "status": "PASS" if structure_valid else "FAIL",
                "details": {
                    "structure_created": True,
                    "structure_valid": structure_valid,
                    "python_files": len(list(temp_dir.glob("**/*.py")))
                }
            })
            
        except Exception as e:
            results.append({
                "category": "File Structure Tests",
                "test": "mock_project_structure",
                "status": "FAIL", 
                "error": str(e)
            })
        
        return results
    
    async def _run_error_handling_tests(self) -> List[Dict]:
        """Test error handling and edge cases"""
        results = []
        
        # Test 1: Invalid paths
        try:
            from pathlib import Path
            from src.workflows.documentation_workflow import DocumentationConfig
            
            # This should work - we're just testing the config creation
            config = DocumentationConfig(
                app_name="error-test",
                app_root=Path("/non/existent/path"),  
                output_dir=Path("/tmp/error-test")
            )
            
            results.append({
                "category": "Error Handling Tests",
                "test": "invalid_path_config",
                "status": "PASS",  # Config creation should succeed
                "details": {"config_created": True}
            })
            
        except Exception as e:
            results.append({
                "category": "Error Handling Tests",
                "test": "invalid_path_config",
                "status": "FAIL",
                "error": str(e)
            })
        
        # Test 2: Invalid detail level
        try:
            from pathlib import Path
            from src.workflows.documentation_workflow import DocumentationConfig
            
            config = DocumentationConfig(
                app_name="detail-test",
                app_root=Path("/tmp"),
                output_dir=Path("/tmp/test"),
                detail_level="invalid_level"  # This might be accepted
            )
            
            results.append({
                "category": "Error Handling Tests",
                "test": "invalid_detail_level",
                "status": "PASS",  # No validation might be implemented yet
                "details": {"detail_level_accepted": True}
            })
            
        except Exception as e:
            results.append({
                "category": "Error Handling Tests", 
                "test": "invalid_detail_level",
                "status": "PASS",  # Expected to fail validation
                "details": {"validation_working": True}
            })
        
        return results
    
    async def _run_performance_tests(self) -> List[Dict]:
        """Test performance characteristics"""
        results = []
        
        # Test configuration creation performance
        try:
            start_time = time.time()
            
            from pathlib import Path
            from src.workflows.documentation_workflow import DocumentationConfig
            
            # Create multiple configs to test performance
            for i in range(100):
                config = DocumentationConfig(
                    app_name=f"perf-test-{i}",
                    app_root=Path(f"/tmp/perf-{i}"),
                    output_dir=Path(f"/tmp/perf-out-{i}")
                )
            
            creation_time = time.time() - start_time
            
            results.append({
                "category": "Performance Tests",
                "test": "config_creation_performance",
                "status": "PASS",
                "details": {
                    "configs_created": 100,
                    "total_time_seconds": round(creation_time, 4),
                    "average_time_ms": round((creation_time / 100) * 1000, 2),
                    "acceptable_performance": creation_time < 1.0
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Performance Tests",
                "test": "config_creation_performance",
                "status": "FAIL",
                "error": str(e)
            })
        
        # Test template loading performance
        try:
            start_time = time.time()
            
            from src.workflows.execution_plans import ExecutionPlanTemplates
            
            # Load templates multiple times
            for i in range(10):
                comprehensive = ExecutionPlanTemplates.system_documentation_comprehensive(f"app-{i}", "/tmp", "/tmp/out")
                standard = ExecutionPlanTemplates.system_documentation_standard(f"app-{i}", "/tmp", "/tmp/out")
                minimal = ExecutionPlanTemplates.system_documentation_minimal(f"app-{i}", "/tmp", "/tmp/out")
            
            template_time = time.time() - start_time
            
            results.append({
                "category": "Performance Tests",
                "test": "template_loading_performance", 
                "status": "PASS",
                "details": {
                    "templates_loaded": 30,
                    "total_time_seconds": round(template_time, 4),
                    "average_time_ms": round((template_time / 30) * 1000, 2),
                    "acceptable_performance": template_time < 2.0
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Performance Tests",
                "test": "template_loading_performance",
                "status": "FAIL",
                "error": str(e)
            })
        
        return results
    
    async def _run_resume_tests(self) -> List[Dict]:
        """Test checkpoint and resume capabilities"""
        results = []
        
        # Test checkpoint file structure
        try:
            temp_dir = self._create_temp_dir("resume_test")
            checkpoint_dir = temp_dir / "checkpoints"
            checkpoint_dir.mkdir()
            
            # Create mock checkpoint file
            checkpoint_data = {
                "checkpoint_id": "test_checkpoint_123",
                "workflow_type": "system-documentation", 
                "app_name": "test-app",
                "timestamp": datetime.now().isoformat(),
                "completed_tasks": ["task1", "task2"],
                "failed_tasks": [],
                "pending_tasks": ["task3", "task4"],
                "app_config": {
                    "app_name": "test-app",
                    "app_root": "/tmp/test"
                }
            }
            
            checkpoint_file = checkpoint_dir / "checkpoint_test_123.json"
            checkpoint_file.write_text(json.dumps(checkpoint_data, indent=2))
            
            # Verify checkpoint file can be loaded
            loaded_data = json.loads(checkpoint_file.read_text())
            
            results.append({
                "category": "Resume Capability Tests",
                "test": "checkpoint_file_structure",
                "status": "PASS",
                "details": {
                    "checkpoint_created": True,
                    "checkpoint_loadable": True,
                    "has_required_fields": all(field in loaded_data for field in 
                        ["checkpoint_id", "workflow_type", "app_name", "completed_tasks"])
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Resume Capability Tests",
                "test": "checkpoint_file_structure",
                "status": "FAIL",
                "error": str(e)
            })
        
        # Test checkpoint manager functionality
        try:
            from src.workflows.execution_plans import CheckpointManager, ExecutionCheckpoint
            
            temp_dir = self._create_temp_dir("checkpoint_manager_test")
            manager = CheckpointManager(temp_dir)
            
            # Test checkpoint creation
            test_checkpoint = ExecutionCheckpoint(
                checkpoint_id="manager_test_456",
                timestamp=datetime.now().isoformat(),
                workflow_type="system-documentation",
                app_name="manager-test-app",
                completed_tasks=[],
                failed_tasks=[],
                pending_tasks=["task1", "task2"]
            )
            
            saved_path = manager.save_checkpoint(test_checkpoint)
            
            results.append({
                "category": "Resume Capability Tests", 
                "test": "checkpoint_manager_functionality",
                "status": "PASS",
                "details": {
                    "checkpoint_saved": saved_path.exists(),
                    "manager_initialized": True,
                    "checkpoint_id": test_checkpoint.checkpoint_id
                }
            })
            
        except Exception as e:
            results.append({
                "category": "Resume Capability Tests",
                "test": "checkpoint_manager_functionality",
                "status": "FAIL",
                "error": str(e)
            })
        
        return results
    
    def _create_temp_dir(self, prefix: str) -> Path:
        """Create temporary directory for testing"""
        temp_dir = Path(tempfile.mkdtemp(prefix=f"{prefix}_"))
        self.temp_dirs.append(temp_dir)
        return temp_dir
    
    def _cleanup_temp_dirs(self):
        """Clean up temporary directories"""
        for temp_dir in self.temp_dirs:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
        self.temp_dirs.clear()
    
    def print_comprehensive_summary(self):
        """Print detailed test results summary"""
        
        # Organize results by category
        by_category = {}
        for result in self.test_results:
            category = result.get("category", "Unknown")
            if category not in by_category:
                by_category[category] = []
            by_category[category].append(result)
        
        # Print overall summary
        total_tests = len(self.test_results)
        passed = sum(1 for r in self.test_results if r["status"] == "PASS")
        failed = sum(1 for r in self.test_results if r["status"] == "FAIL") 
        errors = sum(1 for r in self.test_results if r["status"] == "ERROR")
        
        print(f"\n{'='*80}")
        print("COMPREHENSIVE DOCUMENTATION WORKFLOW TEST RESULTS")
        print(f"{'='*80}")
        print(f"Total Tests: {total_tests}")
        print(f"✓ Passed: {passed}")
        print(f"✗ Failed: {failed}")
        print(f"⚠ Errors: {errors}")
        print(f"Success Rate: {(passed/total_tests)*100:.1f}%")
        print()
        
        # Print results by category
        for category, results in by_category.items():
            category_passed = sum(1 for r in results if r["status"] == "PASS")
            category_total = len(results)
            
            print(f"{category} ({category_passed}/{category_total} passed)")
            print("-" * (len(category) + 20))
            
            for result in results:
                status_symbol = {"PASS": "✓", "FAIL": "✗", "ERROR": "⚠"}[result["status"]]
                print(f"  {status_symbol} {result['test']}: {result['status']}")
                
                if result.get("details") and result["status"] == "PASS":
                    print(f"    Details: {json.dumps(result['details'], indent=6)}")
                elif result.get("error"):
                    print(f"    Error: {result['error']}")
            print()


async def main():
    """Main test runner entry point"""
    test_suite = DocumentationWorkflowTestSuite()
    results = await test_suite.run_all_tests()
    
    # Return appropriate exit code
    failed_count = sum(1 for r in results if r["status"] in ["FAIL", "ERROR"])
    return 1 if failed_count > 0 else 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)