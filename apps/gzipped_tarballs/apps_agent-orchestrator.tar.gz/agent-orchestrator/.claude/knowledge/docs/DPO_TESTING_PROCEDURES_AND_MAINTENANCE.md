# DPO Testing Procedures and Maintenance Guide

## Overview

This document provides comprehensive guidance for maintaining and executing the DPO testing suite, including procedures for different testing scenarios, maintenance tasks, and continuous improvement practices.

## Testing Infrastructure

### Test Organization
```
tests/
├── unit/                    # Unit tests for individual components
├── integration/            # Integration tests for component interactions  
├── system/                 # End-to-end system tests
├── performance/            # Performance benchmarks and load tests
├── fixtures/               # Test fixtures and mock services
│   ├── mock_orchestrator.py
│   └── sample_data.py
├── conftest.py            # PyTest configuration and shared fixtures
└── run_all_tests.py       # Comprehensive test runner
```

### Key Components
- **Unit Tests**: Test individual components in isolation
- **Integration Tests**: Test component interactions and data flow
- **System Tests**: Test complete workflows and user scenarios
- **Performance Tests**: Load testing, stress testing, and benchmarking
- **Mock Services**: MockOrchestratorServer for testing without external dependencies
- **Sample Data**: Comprehensive test data generation for various scenarios

## Daily Testing Procedures

### Development Testing
**When**: Before committing code changes
**Command**: `python tests/run_all_tests.py --quick`
**Duration**: ~2-5 minutes
**Coverage**: Unit tests only

```bash
# Quick unit test run
cd /path/to/agent-orchestrator
python tests/run_all_tests.py --quick --verbose

# Unit tests with coverage
python tests/run_all_tests.py --types unit --verbose
```

### Pre-Commit Testing
**When**: Before pushing to version control
**Command**: `python tests/run_all_tests.py --types unit integration`
**Duration**: ~10-15 minutes
**Coverage**: Unit and integration tests

```bash
# Comprehensive pre-commit testing
python tests/run_all_tests.py --types unit integration --verbose

# Check specific components
pytest tests/unit/test_dpo_main_controller.py -v
pytest tests/integration/test_dpo_complete_integration.py -v
```

### Integration Testing
**When**: Before merging pull requests
**Command**: `python tests/run_all_tests.py`
**Duration**: ~30-45 minutes
**Coverage**: All test suites except performance

```bash
# Full integration testing
python tests/run_all_tests.py --no-performance --verbose

# With detailed reporting
python tests/run_all_tests.py --verbose > test-results.log 2>&1
```

## Weekly Testing Procedures

### Comprehensive Testing
**When**: Weekly automated runs
**Command**: `python tests/run_all_tests.py`
**Duration**: ~60-90 minutes
**Coverage**: All test suites including performance

```bash
# Complete test suite
python tests/run_all_tests.py --verbose

# Generate comprehensive reports
python tests/run_all_tests.py --verbose --types unit integration system performance
```

### Performance Regression Testing
**When**: Weekly performance validation
**Focus**: Detect performance regressions and validate SLA compliance

```bash
# Performance-only testing
python tests/run_all_tests.py --types performance --verbose

# Specific performance tests
pytest tests/performance/test_dpo_performance_benchmarks.py::TestDPOPerformanceBenchmarks::test_sla_compliance -v
```

## Test Execution Procedures

### Running Individual Test Suites

#### Unit Tests
```bash
# All unit tests
pytest tests/unit/ -v

# Specific component tests
pytest tests/unit/test_dpo_main_controller.py -v
pytest tests/unit/test_intelligence_review_engine_enhanced.py -v
pytest tests/unit/test_sdlc_template_system.py -v

# With coverage
pytest tests/unit/ --cov=src --cov-report=html --cov-report=term-missing -v
```

#### Integration Tests
```bash
# All integration tests
pytest tests/integration/ -v

# Component integration
pytest tests/integration/test_dpo_complete_integration.py -v

# With mock orchestrator
pytest tests/integration/ --mock-orchestrator -v
```

#### System Tests
```bash
# End-to-end system tests
pytest tests/system/ -v

# Specific workflow tests
pytest tests/system/test_dpo_end_to_end.py::TestDPOEndToEndWorkflows::test_simple_api_development_workflow -v

# CLI interface tests
pytest tests/system/test_dpo_end_to_end.py::TestDPOCLIInterface -v
```

#### Performance Tests
```bash
# Performance benchmarks
pytest tests/performance/ -v --benchmark-only

# Specific performance tests
pytest tests/performance/test_dpo_performance_benchmarks.py::TestDPOPerformanceBenchmarks::test_load_performance -v

# SLA validation
pytest tests/performance/test_dpo_performance_benchmarks.py::TestDPOPerformanceValidation::test_sla_compliance -v
```

### Test Filtering and Selection

#### By Markers
```bash
# Run tests by marker
pytest -m unit -v              # Unit tests only
pytest -m integration -v       # Integration tests only  
pytest -m system -v            # System tests only
pytest -m performance -v       # Performance tests only
pytest -m "not slow" -v        # Skip slow tests
```

#### By Keywords
```bash
# Run tests matching keywords
pytest -k "test_dpo_main" -v              # Tests with "dpo_main" in name
pytest -k "intelligence" -v               # Intelligence-related tests
pytest -k "performance and not stress" -v # Performance tests excluding stress tests
```

#### By Test Patterns
```bash
# Specific test patterns
pytest tests/unit/test_*_controller.py -v     # All controller tests
pytest tests/*/test_dpo_*.py -v               # All DPO-related tests
pytest -v --collect-only                      # List all tests without running
```

## Test Environment Management

### Environment Setup
```bash
# Install test dependencies
pip install -r requirements.txt
pip install pytest pytest-asyncio pytest-cov pytest-benchmark

# Setup test environment variables
export DPO_TEST_MODE=true
export DPO_LOG_LEVEL=DEBUG
export DPO_OUTPUT_DIR=/tmp/dpo_test_output
```

### Mock Services Management
```bash
# Start mock orchestrator server (for integration tests)
python -c "
import asyncio
from tests.fixtures.mock_orchestrator import MockOrchestratorServer
server = MockOrchestratorServer(port=8080)
asyncio.run(server.start())
print('Mock server running on port 8080')
input('Press Enter to stop...')
asyncio.run(server.stop())
"
```

### Test Data Management
```bash
# Generate fresh test data
python -c "
from tests.fixtures.sample_data import SampleRequestGenerator
gen = SampleRequestGenerator()
# Generate and save test scenarios
import json
scenarios = {
    'api': gen.get_api_request('medium'),
    'webapp': gen.get_webapp_request('complex'),
    'cli': gen.get_cli_request('simple')
}
with open('test_scenarios.json', 'w') as f:
    json.dump(scenarios, f, indent=2)
print('Test scenarios saved to test_scenarios.json')
"
```

## Continuous Integration Procedures

### CI Pipeline Configuration

#### GitHub Actions Example
```yaml
name: DPO Test Suite
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.9, 3.10, 3.11]
    
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v3
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        pip install pytest pytest-asyncio pytest-cov
    
    - name: Run unit tests
      run: python tests/run_all_tests.py --types unit --verbose
    
    - name: Run integration tests  
      run: python tests/run_all_tests.py --types integration --verbose
    
    - name: Upload coverage reports
      uses: codecov/codecov-action@v3
```

#### Pre-commit Hooks
```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: dpo-unit-tests
        name: Run DPO unit tests
        entry: python tests/run_all_tests.py --quick
        language: system
        pass_filenames: false
        always_run: true
```

## Test Maintenance Procedures

### Weekly Maintenance

#### Test Data Refresh
```bash
# Update sample request data
python -c "
from tests.fixtures.sample_data import SampleRequestGenerator
gen = SampleRequestGenerator()
# Verify all generators work correctly
for complexity in ['simple', 'medium', 'complex']:
    api_req = gen.get_api_request(complexity)
    print(f'{complexity} API request: {api_req.description}')
"

# Verify mock services
python tests/fixtures/mock_orchestrator.py --test-mode
```

#### Coverage Analysis
```bash
# Generate detailed coverage reports
pytest tests/ --cov=src --cov-report=html --cov-report=term-missing --cov-branch

# Identify uncovered code
coverage report --show-missing --skip-covered

# Coverage threshold checking
coverage report --fail-under=90
```

#### Performance Baseline Updates
```bash
# Update performance baselines
python -c "
import json
from tests.performance.test_dpo_performance_benchmarks import DPOPerformanceTester
from src.dpo_main_controller import DPOConfiguration

# Run baseline performance tests
config = DPOConfiguration(enable_websocket=False)
# ... (performance baseline collection logic)
"
```

### Monthly Maintenance

#### Test Suite Health Check
```bash
# Comprehensive test analysis
python tests/run_all_tests.py --verbose > monthly_test_report.txt 2>&1

# Check for flaky tests
for i in {1..5}; do
    echo "Run $i:"
    python tests/run_all_tests.py --quick | grep -E "(FAILED|ERROR|passed|failed)"
done

# Performance trend analysis
pytest tests/performance/ --benchmark-json=monthly_benchmark.json
```

#### Dependency Updates
```bash
# Check for outdated test dependencies
pip list --outdated | grep -E "(pytest|mock|coverage)"

# Update test dependencies
pip install -U pytest pytest-asyncio pytest-cov pytest-benchmark

# Verify tests still pass with updates
python tests/run_all_tests.py --verbose
```

## Troubleshooting Common Issues

### Test Failures

#### Import Errors
```bash
# Fix Python path issues
export PYTHONPATH=/path/to/agent-orchestrator:$PYTHONPATH

# Verify module imports
python -c "from src.dpo_main_controller import DevelopmentProcessOrchestrator; print('OK')"
```

#### Mock Service Issues
```bash
# Reset mock orchestrator
pkill -f "MockOrchestratorServer"
python tests/fixtures/mock_orchestrator.py --reset

# Check port availability
netstat -tulnp | grep 8080
```

#### Performance Test Issues
```bash
# Increase timeout for slow systems
pytest tests/performance/ -v --timeout=3600

# Reduce load for resource-constrained systems  
pytest tests/performance/ -v -k "not stress"

# Skip memory-intensive tests
pytest tests/performance/ -v -k "not memory_leak"
```

### Coverage Issues

#### Low Coverage
```bash
# Identify untested code
coverage report --show-missing | grep "0%"

# Generate detailed HTML report
coverage html --directory=coverage_html
open coverage_html/index.html  # View in browser
```

#### Coverage Calculation Issues
```bash
# Reset coverage data
coverage erase

# Run tests with fresh coverage
pytest tests/unit/ --cov=src --cov-report=term-missing --cov-append
```

## Performance Monitoring

### Performance Metrics Collection
```bash
# Collect baseline metrics
python -c "
from tests.performance.test_dpo_performance_benchmarks import DPOPerformanceTester
# Run performance collection
"

# Monitor system resources during tests
iostat -x 1 &  # Disk I/O
top -p $(pgrep -f pytest) &  # CPU/Memory
python tests/run_all_tests.py --types performance
```

### Performance Regression Detection
```bash
# Compare with historical performance
python -c "
import json
import statistics

# Load historical benchmark data
with open('benchmark_history.json', 'r') as f:
    history = json.load(f)

# Compare current vs historical performance
current_avg = 15.2  # Current average response time
historical_avg = statistics.mean(history['response_times'])

if current_avg > historical_avg * 1.2:  # 20% regression threshold
    print('Performance regression detected!')
    print(f'Current: {current_avg}s, Historical: {historical_avg}s')
"
```

## Quality Gates and Validation

### Quality Gate Criteria
- **Unit Test Coverage**: ≥95%
- **Integration Test Success**: 100%
- **Performance SLA Compliance**: All metrics within bounds
- **Code Quality**: No critical issues
- **Documentation**: All new features documented

### Validation Procedures
```bash
# Quality gate validation
python -c "
import subprocess
import sys

# Run quality checks
checks = {
    'unit_coverage': 'pytest tests/unit/ --cov=src --cov-fail-under=95',
    'integration_tests': 'pytest tests/integration/ --maxfail=1',
    'performance_sla': 'pytest tests/performance/ -k test_sla_compliance',
    'code_quality': 'flake8 src/ --count --select=E9,F63,F7,F82 --show-source --statistics'
}

failed_checks = []
for check_name, command in checks.items():
    result = subprocess.run(command.split(), capture_output=True)
    if result.returncode != 0:
        failed_checks.append(check_name)
        print(f'❌ {check_name} failed')
    else:
        print(f'✅ {check_name} passed')

if failed_checks:
    print(f'Quality gate failed: {failed_checks}')
    sys.exit(1)
else:
    print('✅ All quality gates passed')
"
```

## Automated Reporting

### Daily Reports
```bash
# Generate daily test summary
python tests/run_all_tests.py --types unit integration > daily_test_report.txt 2>&1

# Email report (if configured)
# mail -s "DPO Daily Test Report" team@company.com < daily_test_report.txt
```

### Weekly Reports
```bash
# Comprehensive weekly report
python tests/run_all_tests.py --verbose > weekly_test_report.txt 2>&1

# Generate trend analysis
python -c "
import json
from datetime import datetime, timedelta

# Collect test metrics over time
# Generate trend graphs and analysis
print('Weekly test trends generated')
"
```

## Best Practices

### Test Development
1. **Write tests first** (TDD approach)
2. **Test one thing at a time** (focused unit tests)
3. **Use descriptive test names** (explains what is being tested)
4. **Mock external dependencies** (isolated testing)
5. **Clean up test artifacts** (no side effects)

### Test Maintenance
1. **Run tests frequently** (catch issues early)
2. **Update tests with code changes** (maintain test relevance)
3. **Monitor test performance** (prevent slow test suite)
4. **Review test failures promptly** (don't ignore failures)
5. **Refactor tests when needed** (keep tests maintainable)

### Performance Testing
1. **Establish baselines** (know normal performance)
2. **Test realistic scenarios** (use production-like data)
3. **Monitor resource usage** (CPU, memory, I/O)
4. **Set clear SLA targets** (define acceptable performance)
5. **Automate performance validation** (continuous monitoring)

This testing framework ensures the DPO system maintains high quality, performance, and reliability through comprehensive validation at all levels.