#!/usr/bin/env python3
"""
Documentation Workflow Test Runner

Simplified test runner for testing documentation workflow components
without full orchestrator complexity.
"""

import asyncio
import json
import logging
import sys
import tempfile
from datetime import datetime
from pathlib import Path

# Add src to Python path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from src.workflows.documentation_workflow import DocumentationWorkflow, DocumentationConfig

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DocumentationWorkflowTester:
    """Test runner for documentation workflow components"""
    
    def __init__(self):
        self.test_results = []
        
    async def run_all_tests(self):
        """Run all test cases"""
        logger.info("Starting Documentation Workflow Test Suite")
        
        test_methods = [
            self.test_config_creation,
            self.test_template_selection,
            self.test_task_generation,
            self.test_file_structure_analysis,
        ]
        
        for test_method in test_methods:
            try:
                logger.info(f"Running {test_method.__name__}")
                result = await test_method()
                self.test_results.append({
                    "test": test_method.__name__,
                    "status": "PASS" if result else "FAIL",
                    "details": result if isinstance(result, dict) else None
                })
                logger.info(f"✓ {test_method.__name__} {'PASSED' if result else 'FAILED'}")
            except Exception as e:
                logger.error(f"✗ {test_method.__name__} ERROR: {e}")
                self.test_results.append({
                    "test": test_method.__name__,
                    "status": "ERROR",
                    "error": str(e)
                })
        
        self.print_summary()
        return self.test_results
        
    async def test_config_creation(self):
        """Test 1: Documentation configuration creation"""
        try:
            from pathlib import Path
            config = DocumentationConfig(
                app_name="test-app",
                app_root=Path("/tmp/test-app"),
                output_dir=Path("/tmp/test-docs"),
                detail_level="comprehensive"
            )
            
            return {
                "app_name": config.app_name,
                "detail_level": config.detail_level,
                "include_api_docs": config.include_api_docs,
                "include_architecture": config.include_architecture
            }
        except Exception as e:
            logger.error(f"Config creation failed: {e}")
            return False
            
    async def test_template_selection(self):
        """Test 2: Detail level selection and validation"""
        detail_levels = ["comprehensive", "standard", "minimal"]
        results = {}
        
        for detail_level in detail_levels:
            try:
                from pathlib import Path
                config = DocumentationConfig(
                    app_name="template-test",
                    app_root=Path("/tmp/test"),
                    output_dir=Path("/tmp/test-docs"),
                    detail_level=detail_level
                )
                results[detail_level] = True
            except Exception as e:
                results[detail_level] = f"Error: {e}"
                
        return results
        
    async def test_task_generation(self):
        """Test 3: Task generation from templates"""
        try:
            from pathlib import Path
            config = DocumentationConfig(
                app_name="task-gen-test",
                app_root=Path("/home/opsvi/master_root/apps/agent-orchestrator"),
                output_dir=Path("/tmp/test-docs"),
                detail_level="comprehensive"
            )
            
            workflow = DocumentationWorkflow()
            tasks = workflow.create_documentation_tasks(config)
            
            task_types = [task.task_type for task in tasks]
            task_ids = [task.task_id for task in tasks]
            
            return {
                "task_count": len(tasks),
                "task_types": task_types,
                "task_ids": task_ids,
                "has_dependencies": any(task.dependencies for task in tasks)
            }
        except Exception as e:
            logger.error(f"Task generation failed: {e}")
            return False
            
    async def test_file_structure_analysis(self):
        """Test 4: File structure analysis"""
        try:
            test_dir = Path("/home/opsvi/master_root/apps/agent-orchestrator")
            
            if not test_dir.exists():
                return {"error": "Test directory doesn't exist"}
                
            # Count different file types
            python_files = list(test_dir.glob("**/*.py"))
            json_files = list(test_dir.glob("**/*.json"))
            md_files = list(test_dir.glob("**/*.md"))
            
            return {
                "directory_exists": True,
                "python_files": len(python_files),
                "json_files": len(json_files),
                "md_files": len(md_files),
                "sample_files": [f.name for f in python_files[:5]]
            }
        except Exception as e:
            logger.error(f"File structure analysis failed: {e}")
            return False
            
    def print_summary(self):
        """Print test results summary"""
        total_tests = len(self.test_results)
        passed = sum(1 for r in self.test_results if r["status"] == "PASS")
        failed = sum(1 for r in self.test_results if r["status"] == "FAIL")
        errors = sum(1 for r in self.test_results if r["status"] == "ERROR")
        
        print("\n" + "="*60)
        print("DOCUMENTATION WORKFLOW TEST RESULTS")
        print("="*60)
        print(f"Total Tests: {total_tests}")
        print(f"✓ Passed: {passed}")
        print(f"✗ Failed: {failed}")
        print(f"⚠ Errors: {errors}")
        print(f"Success Rate: {(passed/total_tests)*100:.1f}%")
        print()
        
        for result in self.test_results:
            status_symbol = {"PASS": "✓", "FAIL": "✗", "ERROR": "⚠"}[result["status"]]
            print(f"{status_symbol} {result['test']}: {result['status']}")
            if result.get("details"):
                print(f"   Details: {json.dumps(result['details'], indent=2)}")
            if result.get("error"):
                print(f"   Error: {result['error']}")
        print()


async def main():
    """Main test runner entry point"""
    tester = DocumentationWorkflowTester()
    results = await tester.run_all_tests()
    
    # Return appropriate exit code
    failed_count = sum(1 for r in results if r["status"] in ["FAIL", "ERROR"])
    return 1 if failed_count > 0 else 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)