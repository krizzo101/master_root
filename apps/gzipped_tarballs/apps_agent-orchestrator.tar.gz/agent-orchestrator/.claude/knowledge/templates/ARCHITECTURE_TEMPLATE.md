# {{PROJECT_NAME}} - System Architecture

## Architecture Overview

{{ARCHITECTURE_OVERVIEW}}

### Design Principles

{{#DESIGN_PRINCIPLES}}
- **{{PRINCIPLE_NAME}}**: {{PRINCIPLE_DESCRIPTION}}
{{/DESIGN_PRINCIPLES}}

### Architecture Patterns

{{#ARCHITECTURE_PATTERNS}}
- **{{PATTERN_NAME}}**: {{PATTERN_DESCRIPTION}}
  - **Rationale**: {{PATTERN_RATIONALE}}
  - **Implementation**: {{PATTERN_IMPLEMENTATION}}
{{/ARCHITECTURE_PATTERNS}}

## System Components

### High-Level Architecture

```
{{ARCHITECTURE_DIAGRAM_ASCII}}
```

### Component Breakdown

{{#SYSTEM_COMPONENTS}}
#### {{COMPONENT_NAME}}

**Purpose**: {{COMPONENT_PURPOSE}}

**Responsibilities**:
{{#COMPONENT_RESPONSIBILITIES}}
- {{RESPONSIBILITY}}
{{/COMPONENT_RESPONSIBILITIES}}

**Key Interfaces**:
{{#COMPONENT_INTERFACES}}
- {{INTERFACE_NAME}} (`{{INTERFACE_TYPE}}`): {{INTERFACE_DESCRIPTION}}
{{/COMPONENT_INTERFACES}}

**Dependencies**:
{{#COMPONENT_DEPENDENCIES}}
- {{DEPENDENCY_NAME}}: {{DEPENDENCY_RELATIONSHIP}}
{{/COMPONENT_DEPENDENCIES}}

**Configuration**:
```{{CONFIG_FORMAT}}
{{COMPONENT_CONFIGURATION}}
```

{{/SYSTEM_COMPONENTS}}

## Data Flow

### Primary Data Flow

```
{{DATA_FLOW_DIAGRAM}}
```

{{#DATA_FLOWS}}
#### {{FLOW_NAME}}

{{FLOW_DESCRIPTION}}

**Steps**:
{{#FLOW_STEPS}}
{{STEP_NUMBER}}. {{STEP_DESCRIPTION}}
   - **Input**: {{STEP_INPUT}}
   - **Processing**: {{STEP_PROCESSING}}
   - **Output**: {{STEP_OUTPUT}}
{{/FLOW_STEPS}}

{{/DATA_FLOWS}}

## Data Models

### Core Entities

{{#CORE_ENTITIES}}
#### {{ENTITY_NAME}}

{{ENTITY_DESCRIPTION}}

**Attributes**:
{{#ENTITY_ATTRIBUTES}}
- `{{ATTRIBUTE_NAME}}` ({{ATTRIBUTE_TYPE}}): {{ATTRIBUTE_DESCRIPTION}}
{{/ENTITY_ATTRIBUTES}}

**Relationships**:
{{#ENTITY_RELATIONSHIPS}}
- {{RELATIONSHIP_TYPE}} {{RELATED_ENTITY}}: {{RELATIONSHIP_DESCRIPTION}}
{{/ENTITY_RELATIONSHIPS}}

```{{SCHEMA_FORMAT}}
{{ENTITY_SCHEMA}}
```

{{/CORE_ENTITIES}}

## Integration Architecture

### External Integrations

{{#EXTERNAL_INTEGRATIONS}}
#### {{INTEGRATION_NAME}}

**Type**: {{INTEGRATION_TYPE}}  
**Purpose**: {{INTEGRATION_PURPOSE}}

**Configuration**:
```{{CONFIG_FORMAT}}
{{INTEGRATION_CONFIGURATION}}
```

**Error Handling**: {{INTEGRATION_ERROR_HANDLING}}

{{/EXTERNAL_INTEGRATIONS}}

### Internal Service Communication

{{#INTERNAL_COMMUNICATIONS}}
#### {{COMMUNICATION_TYPE}}

**Pattern**: {{COMMUNICATION_PATTERN}}  
**Protocol**: {{COMMUNICATION_PROTOCOL}}  
**Format**: {{MESSAGE_FORMAT}}

**Message Types**:
{{#MESSAGE_TYPES}}
- `{{MESSAGE_TYPE}}`: {{MESSAGE_DESCRIPTION}}
{{/MESSAGE_TYPES}}

{{/INTERNAL_COMMUNICATIONS}}

## Security Architecture

### Security Model

{{SECURITY_MODEL_DESCRIPTION}}

### Authentication & Authorization

{{#AUTH_MECHANISMS}}
#### {{AUTH_TYPE}}

**Implementation**: {{AUTH_IMPLEMENTATION}}  
**Scope**: {{AUTH_SCOPE}}  
**Configuration**: 

```{{CONFIG_FORMAT}}
{{AUTH_CONFIGURATION}}
```

{{/AUTH_MECHANISMS}}

### Data Protection

{{#DATA_PROTECTION_MEASURES}}
- **{{PROTECTION_TYPE}}**: {{PROTECTION_DESCRIPTION}}
{{/DATA_PROTECTION_MEASURES}}

## Scalability & Performance

### Scaling Strategy

{{SCALING_STRATEGY_DESCRIPTION}}

### Performance Characteristics

{{#PERFORMANCE_METRICS}}
- **{{METRIC_NAME}}**: {{METRIC_VALUE}} ({{METRIC_CONDITIONS}})
{{/PERFORMANCE_METRICS}}

### Bottlenecks & Optimization

{{#BOTTLENECKS}}
#### {{BOTTLENECK_COMPONENT}}

**Issue**: {{BOTTLENECK_DESCRIPTION}}  
**Mitigation**: {{BOTTLENECK_SOLUTION}}  
**Monitoring**: {{BOTTLENECK_MONITORING}}

{{/BOTTLENECKS}}

## Deployment Architecture

### Infrastructure Requirements

{{#INFRASTRUCTURE_REQUIREMENTS}}
- **{{REQUIREMENT_TYPE}}**: {{REQUIREMENT_DETAILS}}
{{/INFRASTRUCTURE_REQUIREMENTS}}

### Deployment Topology

```
{{DEPLOYMENT_TOPOLOGY_DIAGRAM}}
```

{{#DEPLOYMENT_ENVIRONMENTS}}
#### {{ENVIRONMENT_NAME}}

**Purpose**: {{ENVIRONMENT_PURPOSE}}  
**Configuration**: {{ENVIRONMENT_CONFIGURATION}}  
**Resources**: {{ENVIRONMENT_RESOURCES}}

{{/DEPLOYMENT_ENVIRONMENTS}}

## Monitoring & Observability

### Monitoring Strategy

{{MONITORING_STRATEGY}}

### Key Metrics

{{#KEY_METRICS}}
- **{{METRIC_NAME}}** ({{METRIC_TYPE}}): {{METRIC_DESCRIPTION}}
  - **Normal Range**: {{METRIC_NORMAL_RANGE}}
  - **Alert Threshold**: {{METRIC_ALERT_THRESHOLD}}
{{/KEY_METRICS}}

### Logging Architecture

{{LOGGING_ARCHITECTURE_DESCRIPTION}}

**Log Levels**:
{{#LOG_LEVELS}}
- **{{LOG_LEVEL}}**: {{LOG_LEVEL_USAGE}}
{{/LOG_LEVELS}}

## Quality Attributes

### Non-Functional Requirements

{{#QUALITY_ATTRIBUTES}}
#### {{ATTRIBUTE_NAME}}

**Requirement**: {{ATTRIBUTE_REQUIREMENT}}  
**Implementation Strategy**: {{ATTRIBUTE_IMPLEMENTATION}}  
**Measurement**: {{ATTRIBUTE_MEASUREMENT}}

{{/QUALITY_ATTRIBUTES}}

## Design Decisions

### Architectural Decision Records (ADRs)

{{#DESIGN_DECISIONS}}
#### ADR-{{DECISION_NUMBER}}: {{DECISION_TITLE}}

**Status**: {{DECISION_STATUS}}  
**Date**: {{DECISION_DATE}}

**Context**: {{DECISION_CONTEXT}}

**Decision**: {{DECISION_DESCRIPTION}}

**Consequences**: 
{{#DECISION_CONSEQUENCES}}
- {{CONSEQUENCE_TYPE}}: {{CONSEQUENCE_DESCRIPTION}}
{{/DECISION_CONSEQUENCES}}

{{/DESIGN_DECISIONS}}

## Future Considerations

### Planned Enhancements

{{#FUTURE_ENHANCEMENTS}}
- **{{ENHANCEMENT_NAME}}**: {{ENHANCEMENT_DESCRIPTION}}
  - **Priority**: {{ENHANCEMENT_PRIORITY}}
  - **Timeline**: {{ENHANCEMENT_TIMELINE}}
  - **Impact**: {{ENHANCEMENT_IMPACT}}
{{/FUTURE_ENHANCEMENTS}}

### Technical Debt

{{#TECHNICAL_DEBT}}
- **{{DEBT_AREA}}**: {{DEBT_DESCRIPTION}}
  - **Impact**: {{DEBT_IMPACT}}
  - **Remediation**: {{DEBT_REMEDIATION}}
{{/TECHNICAL_DEBT}}

---

**Document Version**: {{DOCUMENT_VERSION}}  
**Last Updated**: {{LAST_UPDATED}}  
**Reviewed By**: {{REVIEWED_BY}}