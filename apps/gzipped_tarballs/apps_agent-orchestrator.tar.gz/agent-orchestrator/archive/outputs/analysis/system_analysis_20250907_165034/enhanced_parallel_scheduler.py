#!/usr/bin/env python3
"""
Enhanced Parallel Execution Scheduler
Intelligent task scheduling with dependency analysis, load balancing, and dynamic scaling
"""

import asyncio
import heapq
import json
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class TaskPriority(Enum):
    """Task execution priority levels"""
    CRITICAL = 0  # Execute immediately
    HIGH = 1  # Execute in first batch
    NORMAL = 2  # Execute normally
    LOW = 3  # Execute when resources available
    BACKGROUND = 4  # Execute only when idle


@dataclass
class ScheduledTask:
    """Enhanced task with scheduling metadata"""
    task_id: str
    priority: TaskPriority
    dependencies: List[str]
    estimated_tokens: int
    estimated_duration: float
    complexity: str  # lightweight, normal, heavyweight
    retry_count: int = 0
    max_retries: int = 3
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    status: str = "pending"  # pending, running, completed, failed
    assigned_worker: Optional[str] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    
    def __lt__(self, other):
        """Enable priority queue sorting"""
        return self.priority.value < other.priority.value


class DependencyGraph:
    """
    Manages task dependencies and critical path analysis
    """
    
    def __init__(self):
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.edges: Dict[str, Set[str]] = defaultdict(set)  # task -> dependents
        self.reverse_edges: Dict[str, Set[str]] = defaultdict(set)  # task -> dependencies
        self.critical_path: List[str] = []
        self.topological_order: List[str] = []
        
    def add_task(self, task: ScheduledTask):
        """Add task to dependency graph"""
        self.nodes[task.task_id] = {
            'task': task,
            'level': 0,
            'earliest_start': 0,
            'latest_start': float('inf'),
            'slack': float('inf'),
            'on_critical_path': False
        }
        
        # Add edges
        for dep in task.dependencies:
            self.edges[dep].add(task.task_id)
            self.reverse_edges[task.task_id].add(dep)
            
    def calculate_critical_path(self):
        """
        Calculate critical path using CPM algorithm
        """
        if not self.nodes:
            return
            
        # Topological sort
        self._topological_sort()
        
        # Forward pass - calculate earliest start times
        for task_id in self.topological_order:
            node = self.nodes[task_id]
            task = node['task']
            
            # Find maximum earliest finish of dependencies
            max_earliest_finish = 0
            for dep_id in self.reverse_edges[task_id]:
                if dep_id in self.nodes:
                    dep_node = self.nodes[dep_id]
                    dep_task = dep_node['task']
                    dep_finish = dep_node['earliest_start'] + dep_task.estimated_duration
                    max_earliest_finish = max(max_earliest_finish, dep_finish)
                    
            node['earliest_start'] = max_earliest_finish
            
        # Find project completion time
        project_completion = max(
            node['earliest_start'] + node['task'].estimated_duration
            for node in self.nodes.values()
        )
        
        # Backward pass - calculate latest start times
        for task_id in reversed(self.topological_order):
            node = self.nodes[task_id]
            task = node['task']
            
            # Find minimum latest start of dependents
            if task_id not in self.edges or not self.edges[task_id]:
                # No dependents - use project completion
                node['latest_start'] = project_completion - task.estimated_duration
            else:
                min_latest_start = float('inf')
                for dep_id in self.edges[task_id]:
                    if dep_id in self.nodes:
                        dep_node = self.nodes[dep_id]
                        min_latest_start = min(min_latest_start, dep_node['latest_start'])
                node['latest_start'] = min_latest_start - task.estimated_duration
                
        # Calculate slack and identify critical path
        self.critical_path = []
        for task_id, node in self.nodes.items():
            node['slack'] = node['latest_start'] - node['earliest_start']
            node['on_critical_path'] = abs(node['slack']) < 0.001  # Float comparison tolerance
            
            if node['on_critical_path']:
                self.critical_path.append(task_id)
                
    def _topological_sort(self):
        """Perform topological sort on the graph"""
        in_degree = defaultdict(int)
        
        # Calculate in-degrees
        for task_id in self.nodes:
            in_degree[task_id] = len(self.reverse_edges[task_id])
            
        # Find nodes with no dependencies
        queue = deque([
            task_id for task_id in self.nodes
            if in_degree[task_id] == 0
        ])
        
        self.topological_order = []
        
        while queue:
            task_id = queue.popleft()
            self.topological_order.append(task_id)
            
            # Reduce in-degree of dependents
            for dep_id in self.edges[task_id]:
                in_degree[dep_id] -= 1
                if in_degree[dep_id] == 0:
                    queue.append(dep_id)
                    
    def get_ready_tasks(self, completed_tasks: Set[str]) -> List[str]:
        """Get tasks that are ready to execute"""
        ready = []
        
        for task_id, node in self.nodes.items():
            task = node['task']
            
            # Skip if not pending
            if task.status != 'pending':
                continue
                
            # Check if all dependencies are completed
            deps_satisfied = all(
                dep in completed_tasks
                for dep in self.reverse_edges[task_id]
            )
            
            if deps_satisfied:
                ready.append(task_id)
                
        return ready
        
    def get_blocking_score(self, task_id: str) -> int:
        """
        Calculate how many tasks this task is blocking
        Used for prioritization
        """
        visited = set()
        
        def count_dependents(tid):
            if tid in visited:
                return 0
            visited.add(tid)
            
            count = len(self.edges[tid])
            for dep in self.edges[tid]:
                count += count_dependents(dep)
            return count
            
        return count_dependents(task_id)


class LoadBalancer:
    """
    Intelligent load balancing across worker pools
    """
    
    def __init__(self, num_workers: int = 10):
        self.num_workers = num_workers
        
        # Worker pools by specialization
        self.worker_pools = {
            'lightweight': [],
            'normal': [],
            'heavyweight': []
        }
        
        # Worker statistics
        self.worker_stats = defaultdict(lambda: {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_duration': 0,
            'current_task': None,
            'idle_since': time.time()
        })
        
        # Task queues by complexity
        self.task_queues = {
            'lightweight': asyncio.PriorityQueue(),
            'normal': asyncio.PriorityQueue(),
            'heavyweight': asyncio.PriorityQueue()
        }
        
        self._setup_workers()
        
    def _setup_workers(self):
        """Initialize worker pools"""
        # Distribute workers: 30% lightweight, 50% normal, 20% heavyweight
        distributions = {
            'lightweight': int(self.num_workers * 0.3),
            'normal': int(self.num_workers * 0.5),
            'heavyweight': int(self.num_workers * 0.2)
        }
        
        # Ensure at least one worker per type
        for pool_type in distributions:
            distributions[pool_type] = max(1, distributions[pool_type])
            
        # Adjust for rounding
        total = sum(distributions.values())
        if total < self.num_workers:
            distributions['normal'] += self.num_workers - total
            
        # Create worker IDs
        for pool_type, count in distributions.items():
            for i in range(count):
                worker_id = f"{pool_type}_{i}"
                self.worker_pools[pool_type].append(worker_id)
                
    async def assign_task(self, task: ScheduledTask) -> str:
        """
        Assign task to appropriate queue and return assigned worker type
        """
        # Determine queue based on complexity
        queue = self.task_queues[task.complexity]
        
        # Add to priority queue (priority, task)
        await queue.put((task.priority.value, task))
        
        return task.complexity
        
    async def get_next_task(self, worker_id: str) -> Optional[ScheduledTask]:
        """
        Get next task for a worker based on its specialization
        """
        # Determine worker type
        worker_type = worker_id.split('_')[0]
        
        # Try to get task from specialized queue
        primary_queue = self.task_queues[worker_type]
        
        try:
            priority, task = await asyncio.wait_for(
                primary_queue.get(),
                timeout=0.1
            )
            return task
        except asyncio.TimeoutError:
            pass
            
        # Try other queues if specialized queue is empty (work stealing)
        for queue_type, queue in self.task_queues.items():
            if queue_type != worker_type:
                try:
                    priority, task = await asyncio.wait_for(
                        queue.get(),
                        timeout=0.01
                    )
                    logger.debug(f"Worker {worker_id} stealing task from {queue_type} queue")
                    return task
                except asyncio.TimeoutError:
                    continue
                    
        return None
        
    def update_worker_stats(
        self,
        worker_id: str,
        task: ScheduledTask,
        success: bool,
        duration: float
    ):
        """Update worker statistics after task completion"""
        stats = self.worker_stats[worker_id]
        
        if success:
            stats['tasks_completed'] += 1
        else:
            stats['tasks_failed'] += 1
            
        stats['total_duration'] += duration
        stats['current_task'] = None
        stats['idle_since'] = time.time()
        
    def get_load_distribution(self) -> Dict[str, Any]:
        """Get current load distribution across workers"""
        distribution = {}
        
        for pool_type, workers in self.worker_pools.items():
            pool_stats = {
                'total_workers': len(workers),
                'busy_workers': 0,
                'queue_size': self.task_queues[pool_type].qsize(),
                'completed_tasks': 0,
                'failed_tasks': 0
            }
            
            for worker_id in workers:
                stats = self.worker_stats[worker_id]
                if stats['current_task']:
                    pool_stats['busy_workers'] += 1
                pool_stats['completed_tasks'] += stats['tasks_completed']
                pool_stats['failed_tasks'] += stats['tasks_failed']
                
            distribution[pool_type] = pool_stats
            
        return distribution


class DynamicScaler:
    """
    Dynamically adjust parallelism based on system performance
    """
    
    def __init__(
        self,
        min_parallel: int = 2,
        max_parallel: int = 10,
        adjustment_interval: int = 30
    ):
        self.min_parallel = min_parallel
        self.max_parallel = max_parallel
        self.current_parallel = min_parallel
        self.adjustment_interval = adjustment_interval
        
        # Performance tracking
        self.performance_window = deque(maxlen=100)
        self.last_adjustment = time.time()
        
        # Scaling thresholds
        self.scale_up_threshold = {
            'error_rate': 0.05,  # < 5% errors
            'throughput': 0.8,  # > 80% efficiency
            'latency': 10  # < 10s average
        }
        
        self.scale_down_threshold = {
            'error_rate': 0.15,  # > 15% errors
            'throughput': 0.4,  # < 40% efficiency
            'latency': 30  # > 30s average
        }
        
    def record_metrics(
        self,
        completed_tasks: int,
        failed_tasks: int,
        average_latency: float,
        token_utilization: float
    ):
        """Record performance metrics"""
        total_tasks = completed_tasks + failed_tasks
        error_rate = failed_tasks / total_tasks if total_tasks > 0 else 0
        
        metric = {
            'timestamp': time.time(),
            'error_rate': error_rate,
            'throughput': token_utilization,
            'latency': average_latency,
            'completed': completed_tasks,
            'failed': failed_tasks
        }
        
        self.performance_window.append(metric)
        
    def should_adjust(self) -> bool:
        """Check if we should adjust parallelism"""
        # Don't adjust too frequently
        if time.time() - self.last_adjustment < self.adjustment_interval:
            return False
            
        # Need enough data
        if len(self.performance_window) < 10:
            return False
            
        return True
        
    def calculate_adjustment(self) -> int:
        """
        Calculate parallelism adjustment
        
        Returns:
            Adjustment delta (-1, 0, or 1)
        """
        if not self.should_adjust():
            return 0
            
        # Calculate recent averages
        recent = list(self.performance_window)[-20:]
        
        avg_error = sum(m['error_rate'] for m in recent) / len(recent)
        avg_throughput = sum(m['throughput'] for m in recent) / len(recent)
        avg_latency = sum(m['latency'] for m in recent) / len(recent)
        
        # Decision logic
        should_scale_up = (
            avg_error < self.scale_up_threshold['error_rate'] and
            avg_throughput > self.scale_up_threshold['throughput'] and
            avg_latency < self.scale_up_threshold['latency'] and
            self.current_parallel < self.max_parallel
        )
        
        should_scale_down = (
            avg_error > self.scale_down_threshold['error_rate'] or
            avg_throughput < self.scale_down_threshold['throughput'] or
            avg_latency > self.scale_down_threshold['latency']
        ) and self.current_parallel > self.min_parallel
        
        if should_scale_up:
            adjustment = 1
        elif should_scale_down:
            adjustment = -1
        else:
            adjustment = 0
            
        if adjustment != 0:
            self.last_adjustment = time.time()
            logger.info(
                f"Scaling parallelism: {self.current_parallel} -> {self.current_parallel + adjustment} "
                f"(error: {avg_error:.2%}, throughput: {avg_throughput:.2%}, latency: {avg_latency:.1f}s)"
            )
            
        return adjustment
        
    def apply_adjustment(self, delta: int) -> int:
        """
        Apply adjustment and return new parallelism level
        """
        self.current_parallel = max(
            self.min_parallel,
            min(self.max_parallel, self.current_parallel + delta)
        )
        return self.current_parallel
        
    def get_scaling_metrics(self) -> Dict[str, Any]:
        """Get scaling metrics and recommendations"""
        if len(self.performance_window) < 10:
            return {
                'current_parallel': self.current_parallel,
                'recommendation': 'insufficient_data',
                'metrics': {}
            }
            
        recent = list(self.performance_window)[-20:]
        
        metrics = {
            'avg_error_rate': sum(m['error_rate'] for m in recent) / len(recent),
            'avg_throughput': sum(m['throughput'] for m in recent) / len(recent),
            'avg_latency': sum(m['latency'] for m in recent) / len(recent)
        }
        
        # Recommendation
        adjustment = self.calculate_adjustment()
        if adjustment > 0:
            recommendation = 'scale_up'
        elif adjustment < 0:
            recommendation = 'scale_down'
        else:
            recommendation = 'maintain'
            
        return {
            'current_parallel': self.current_parallel,
            'min_parallel': self.min_parallel,
            'max_parallel': self.max_parallel,
            'recommendation': recommendation,
            'metrics': metrics,
            'can_adjust': self.should_adjust()
        }


class EnhancedParallelScheduler:
    """
    Main scheduler combining all optimization strategies
    """
    
    def __init__(
        self,
        max_parallel: int = 10,
        enable_critical_path: bool = True,
        enable_load_balancing: bool = True,
        enable_dynamic_scaling: bool = True
    ):
        self.max_parallel = max_parallel
        self.enable_critical_path = enable_critical_path
        self.enable_load_balancing = enable_load_balancing
        self.enable_dynamic_scaling = enable_dynamic_scaling
        
        # Components
        self.dependency_graph = DependencyGraph()
        self.load_balancer = LoadBalancer(max_parallel)
        self.dynamic_scaler = DynamicScaler(
            min_parallel=2,
            max_parallel=max_parallel
        )
        
        # Task tracking
        self.all_tasks: Dict[str, ScheduledTask] = {}
        self.completed_tasks: Set[str] = set()
        self.running_tasks: Set[str] = set()
        self.failed_tasks: Set[str] = set()
        
        # Metrics
        self.metrics = {
            'total_scheduled': 0,
            'total_completed': 0,
            'total_failed': 0,
            'total_duration': 0,
            'critical_path_length': 0
        }
        
        logger.info(f"EnhancedParallelScheduler initialized (max_parallel: {max_parallel})")
        
    def add_task(self, task: ScheduledTask):
        """Add task to scheduler"""
        self.all_tasks[task.task_id] = task
        self.dependency_graph.add_task(task)
        self.metrics['total_scheduled'] += 1
        
    def analyze_schedule(self):
        """Analyze schedule and calculate critical path"""
        if self.enable_critical_path:
            self.dependency_graph.calculate_critical_path()
            self.metrics['critical_path_length'] = len(
                self.dependency_graph.critical_path
            )
            logger.info(
                f"Critical path calculated: {self.metrics['critical_path_length']} tasks"
            )
            
    async def get_next_batch(self) -> List[ScheduledTask]:
        """
        Get next batch of tasks to execute
        
        Returns:
            List of tasks ready for execution
        """
        # Get ready tasks from dependency graph
        ready_task_ids = self.dependency_graph.get_ready_tasks(self.completed_tasks)
        
        if not ready_task_ids:
            return []
            
        # Sort by priority and critical path
        ready_tasks = []
        for task_id in ready_task_ids:
            task = self.all_tasks[task_id]
            node = self.dependency_graph.nodes[task_id]
            
            # Calculate sort key
            sort_key = (
                task.priority.value,  # Primary: priority
                -node.get('blocking_score', 0),  # Secondary: how many tasks blocked
                not node.get('on_critical_path', False),  # Tertiary: critical path
                task.created_at  # Quaternary: FIFO
            )
            
            ready_tasks.append((sort_key, task))
            
        # Sort and extract tasks
        ready_tasks.sort()
        
        # Determine batch size
        if self.enable_dynamic_scaling:
            batch_size = self.dynamic_scaler.current_parallel
        else:
            batch_size = self.max_parallel
            
        # Consider current running tasks
        available_slots = batch_size - len(self.running_tasks)
        
        batch = []
        for _, task in ready_tasks[:available_slots]:
            batch.append(task)
            task.status = 'running'
            task.started_at = time.time()
            self.running_tasks.add(task.task_id)
            
        return batch
        
    def complete_task(
        self,
        task_id: str,
        success: bool = True,
        result: Any = None,
        error: Optional[str] = None
    ):
        """Mark task as completed"""
        if task_id not in self.all_tasks:
            return
            
        task = self.all_tasks[task_id]
        task.completed_at = time.time()
        task.result = result
        task.error = error
        
        self.running_tasks.discard(task_id)
        
        if success:
            task.status = 'completed'
            self.completed_tasks.add(task_id)
            self.metrics['total_completed'] += 1
        else:
            task.status = 'failed'
            self.failed_tasks.add(task_id)
            self.metrics['total_failed'] += 1
            
        # Update duration
        if task.started_at:
            duration = task.completed_at - task.started_at
            self.metrics['total_duration'] += duration
            
        # Update dynamic scaler
        if self.enable_dynamic_scaling:
            self.dynamic_scaler.record_metrics(
                completed_tasks=self.metrics['total_completed'],
                failed_tasks=self.metrics['total_failed'],
                average_latency=self.metrics['total_duration'] / max(1, self.metrics['total_completed']),
                token_utilization=len(self.running_tasks) / self.max_parallel
            )
            
            # Apply scaling adjustment
            adjustment = self.dynamic_scaler.calculate_adjustment()
            if adjustment != 0:
                self.dynamic_scaler.apply_adjustment(adjustment)
                
    def get_schedule_status(self) -> Dict[str, Any]:
        """Get current schedule status"""
        return {
            'total_tasks': len(self.all_tasks),
            'completed': len(self.completed_tasks),
            'running': len(self.running_tasks),
            'failed': len(self.failed_tasks),
            'pending': len(self.all_tasks) - len(self.completed_tasks) - len(self.running_tasks) - len(self.failed_tasks),
            'critical_path_length': self.metrics['critical_path_length'],
            'load_distribution': self.load_balancer.get_load_distribution() if self.enable_load_balancing else {},
            'scaling_metrics': self.dynamic_scaler.get_scaling_metrics() if self.enable_dynamic_scaling else {},
            'average_duration': self.metrics['total_duration'] / max(1, self.metrics['total_completed'])
        }


# Example usage
if __name__ == "__main__":
    async def test_scheduler():
        """Test the enhanced parallel scheduler"""
        
        scheduler = EnhancedParallelScheduler(
            max_parallel=5,
            enable_critical_path=True,
            enable_load_balancing=True,
            enable_dynamic_scaling=True
        )
        
        # Create test tasks
        tasks = [
            ScheduledTask(
                task_id="task_1",
                priority=TaskPriority.HIGH,
                dependencies=[],
                estimated_tokens=100,
                estimated_duration=1.0,
                complexity='lightweight'
            ),
            ScheduledTask(
                task_id="task_2",
                priority=TaskPriority.NORMAL,
                dependencies=["task_1"],
                estimated_tokens=200,
                estimated_duration=2.0,
                complexity='normal'
            ),
            ScheduledTask(
                task_id="task_3",
                priority=TaskPriority.CRITICAL,
                dependencies=[],
                estimated_tokens=500,
                estimated_duration=3.0,
                complexity='heavyweight'
            ),
            ScheduledTask(
                task_id="task_4",
                priority=TaskPriority.LOW,
                dependencies=["task_2", "task_3"],
                estimated_tokens=150,
                estimated_duration=1.5,
                complexity='normal'
            )
        ]
        
        # Add tasks to scheduler
        for task in tasks:
            scheduler.add_task(task)
            
        # Analyze schedule
        scheduler.analyze_schedule()
        
        # Simulate execution
        while len(scheduler.completed_tasks) < len(tasks):
            # Get next batch
            batch = await scheduler.get_next_batch()
            
            if not batch:
                await asyncio.sleep(0.1)
                continue
                
            print(f"Executing batch: {[t.task_id for t in batch]}")
            
            # Simulate execution
            for task in batch:
                await asyncio.sleep(0.5)  # Simulate work
                scheduler.complete_task(task.task_id, success=True)
                
        # Final status
        status = scheduler.get_schedule_status()
        print(f"\nFinal status: {json.dumps(status, indent=2)}")
        
    asyncio.run(test_scheduler())