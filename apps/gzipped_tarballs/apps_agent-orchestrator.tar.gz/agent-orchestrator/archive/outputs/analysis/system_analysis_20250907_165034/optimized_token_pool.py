#!/usr/bin/env python3
"""
Optimized Token Pool Implementation
Adaptive token distribution with health tracking and intelligent selection
"""

import asyncio
import json
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class TokenProvider(Enum):
    """Token provider types"""
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    LOCAL = "local"
    UNKNOWN = "unknown"


@dataclass
class TokenHealth:
    """Health metrics for individual tokens"""
    token_idx: int
    provider: TokenProvider
    available_capacity: float = 1.0  # 0-1 score
    last_used: float = 0
    last_error: Optional[float] = None
    error_count: int = 0
    success_count: int = 0
    total_latency: float = 0
    request_count: int = 0
    rate_limit_reset: Optional[float] = None
    
    @property
    def average_latency(self) -> float:
        """Calculate average request latency"""
        if self.request_count == 0:
            return 0
        return self.total_latency / self.request_count
    
    @property
    def error_rate(self) -> float:
        """Calculate error rate"""
        total = self.error_count + self.success_count
        if total == 0:
            return 0
        return self.error_count / total
    
    @property
    def health_score(self) -> float:
        """Calculate overall health score (0-1)"""
        score = self.available_capacity
        
        # Penalize for errors
        score *= (1.0 - min(0.5, self.error_rate))
        
        # Consider rate limit status
        if self.rate_limit_reset and self.rate_limit_reset > time.time():
            score *= 0.1  # Heavily penalize rate-limited tokens
        
        # Consider recent usage (cooldown)
        time_since_use = time.time() - self.last_used
        if time_since_use < 1:  # Used in last second
            score *= 0.5
        elif time_since_use < 5:  # Used in last 5 seconds
            score *= 0.8
            
        return max(0, min(1, score))


class TaskComplexity(Enum):
    """Task complexity levels"""
    LIGHTWEIGHT = "lightweight"  # < 500 tokens
    NORMAL = "normal"  # 500-2000 tokens
    HEAVYWEIGHT = "heavyweight"  # > 2000 tokens
    CRITICAL = "critical"  # High priority regardless of size


class AdaptiveTokenPool:
    """
    Enhanced token pool with adaptive distribution and health tracking
    """
    
    def __init__(
        self,
        tokens: List[str] = None,
        output_dir: Path = None,
        enable_prediction: bool = True,
        enable_provider_detection: bool = True
    ):
        self.output_dir = output_dir or Path.cwd()
        self.enable_prediction = enable_prediction
        self.enable_provider_detection = enable_provider_detection
        
        # Initialize tokens
        if tokens:
            self.tokens = tokens
        else:
            self._load_tokens()
            
        # Initialize health tracking
        self.token_health: Dict[int, TokenHealth] = {}
        for idx, token in enumerate(self.tokens):
            provider = self._detect_provider(token) if enable_provider_detection else TokenProvider.UNKNOWN
            self.token_health[idx] = TokenHealth(
                token_idx=idx,
                provider=provider
            )
        
        # Usage prediction
        self.task_history = deque(maxlen=1000)
        self.provider_capacity = {
            TokenProvider.ANTHROPIC: {
                'rpm': 50,  # Requests per minute
                'tpm': 400000,  # Tokens per minute
                'reset_window': 60  # Reset window in seconds
            },
            TokenProvider.OPENAI: {
                'rpm': 60,
                'tpm': 90000,
                'reset_window': 60
            },
            TokenProvider.LOCAL: {
                'rpm': 1000,
                'tpm': 1000000,
                'reset_window': 1
            }
        }
        
        # Tracking
        self.lock = asyncio.Lock()
        self.acquisition_queue = asyncio.Queue()
        self.metrics = {
            'total_acquisitions': 0,
            'total_releases': 0,
            'provider_switches': 0,
            'rate_limit_hits': 0
        }
        
        logger.info(f"AdaptiveTokenPool initialized with {len(self.tokens)} tokens")
        
    def _load_tokens(self):
        """Load tokens from token loader"""
        try:
            from token_loader import load_tokens
            self.tokens = load_tokens()
            if not self.tokens:
                raise RuntimeError("No tokens available from TokenLoader")
        except ImportError:
            raise RuntimeError("TokenLoader not available and no tokens provided")
            
    def _detect_provider(self, token: str) -> TokenProvider:
        """Detect provider from token format"""
        if not token:
            return TokenProvider.UNKNOWN
            
        # Simple heuristic - can be improved with actual token patterns
        if token.startswith("sk-ant-"):
            return TokenProvider.ANTHROPIC
        elif token.startswith("sk-"):
            return TokenProvider.OPENAI
        elif token.startswith("local-"):
            return TokenProvider.LOCAL
        else:
            # Try to determine from length or other patterns
            if len(token) > 100:
                return TokenProvider.ANTHROPIC
            elif len(token) > 50:
                return TokenProvider.OPENAI
            else:
                return TokenProvider.UNKNOWN
                
    def estimate_task_complexity(self, prompt: str) -> TaskComplexity:
        """Estimate task complexity from prompt"""
        prompt_length = len(prompt)
        
        # Check for critical keywords
        critical_keywords = ['urgent', 'critical', 'important', 'asap', 'priority']
        if any(keyword in prompt.lower() for keyword in critical_keywords):
            return TaskComplexity.CRITICAL
            
        # Classify by length
        if prompt_length < 500:
            return TaskComplexity.LIGHTWEIGHT
        elif prompt_length < 2000:
            return TaskComplexity.NORMAL
        else:
            return TaskComplexity.HEAVYWEIGHT
            
    def predict_token_usage(self, task_type: str, prompt_length: int) -> int:
        """Predict token usage for a task"""
        if not self.enable_prediction:
            return prompt_length * 3  # Simple fallback
            
        # Find similar tasks in history
        similar_tasks = [
            t for t in self.task_history
            if t.get('task_type') == task_type
        ]
        
        if len(similar_tasks) >= 5:
            # Use historical average with buffer
            total_tokens = sum(t.get('tokens_used', 0) for t in similar_tasks)
            avg_tokens = total_tokens / len(similar_tasks)
            return int(avg_tokens * 1.2)  # 20% buffer
        
        # Estimation based on task type
        multipliers = {
            'research': 4,
            'analysis': 3.5,
            'code_generation': 3,
            'summarization': 2,
            'default': 3
        }
        
        multiplier = multipliers.get(task_type, multipliers['default'])
        return int(prompt_length * multiplier)
        
    async def acquire_best_token(
        self,
        task_complexity: TaskComplexity = TaskComplexity.NORMAL,
        preferred_provider: Optional[TokenProvider] = None,
        task_type: str = "default"
    ) -> Tuple[str, int]:
        """
        Acquire the best available token for the task
        
        Returns:
            Tuple of (token, token_index)
        """
        async with self.lock:
            # Calculate scores for all tokens
            token_scores = []
            
            for idx, health in self.token_health.items():
                # Skip if rate limited
                if health.rate_limit_reset and health.rate_limit_reset > time.time():
                    continue
                    
                # Calculate base score
                score = health.health_score
                
                # Adjust for task complexity
                if task_complexity == TaskComplexity.CRITICAL:
                    # Prefer high-capacity providers for critical tasks
                    if health.provider == TokenProvider.ANTHROPIC:
                        score *= 1.5
                elif task_complexity == TaskComplexity.LIGHTWEIGHT:
                    # Can use any provider for lightweight
                    score *= 1.2
                    
                # Apply provider preference
                if preferred_provider and health.provider == preferred_provider:
                    score *= 1.3
                    
                # Consider provider diversity (avoid overusing one provider)
                provider_usage = self._get_recent_provider_usage()
                if health.provider in provider_usage:
                    usage_rate = provider_usage[health.provider]
                    if usage_rate > 0.7:  # Over 70% usage
                        score *= 0.7
                        
                token_scores.append((score, idx))
                
            if not token_scores:
                # All tokens exhausted - wait for cooldown
                wait_time = self._calculate_minimum_wait()
                logger.warning(f"All tokens exhausted, waiting {wait_time}s")
                await asyncio.sleep(wait_time)
                return await self.acquire_best_token(task_complexity, preferred_provider, task_type)
                
            # Sort by score and select best
            token_scores.sort(reverse=True)
            best_idx = token_scores[0][1]
            
            # Update health metrics
            health = self.token_health[best_idx]
            health.last_used = time.time()
            health.request_count += 1
            
            # Update global metrics
            self.metrics['total_acquisitions'] += 1
            
            # Record acquisition
            self._record_acquisition(best_idx, task_type, task_complexity)
            
            logger.debug(f"Acquired token {best_idx} (provider: {health.provider}, score: {token_scores[0][0]:.2f})")
            
            return self.tokens[best_idx], best_idx
            
    def release_token(
        self,
        token_idx: int,
        success: bool = True,
        latency: float = 0,
        tokens_used: int = 0,
        error: Optional[str] = None
    ):
        """Release token and update health metrics"""
        if token_idx not in self.token_health:
            return
            
        health = self.token_health[token_idx]
        
        # Update metrics
        if success:
            health.success_count += 1
            health.error_count = max(0, health.error_count - 1)  # Decay errors
            health.available_capacity = min(1.0, health.available_capacity * 1.1)
        else:
            health.error_count += 1
            health.last_error = time.time()
            health.available_capacity *= 0.8
            
            # Check for rate limit error
            if error and 'rate' in error.lower():
                health.rate_limit_reset = time.time() + 60  # Assume 60s cooldown
                self.metrics['rate_limit_hits'] += 1
                
        # Update latency tracking
        if latency > 0:
            health.total_latency += latency
            
        # Record token usage
        if tokens_used > 0:
            self.task_history.append({
                'timestamp': time.time(),
                'token_idx': token_idx,
                'tokens_used': tokens_used,
                'success': success
            })
            
        self.metrics['total_releases'] += 1
        
        logger.debug(f"Released token {token_idx} (success: {success}, capacity: {health.available_capacity:.2f})")
        
    def _get_recent_provider_usage(self, window_seconds: int = 60) -> Dict[TokenProvider, float]:
        """Calculate recent provider usage rates"""
        cutoff = time.time() - window_seconds
        recent_tasks = [t for t in self.task_history if t.get('timestamp', 0) > cutoff]
        
        if not recent_tasks:
            return {}
            
        provider_counts = defaultdict(int)
        for task in recent_tasks:
            token_idx = task.get('token_idx')
            if token_idx in self.token_health:
                provider = self.token_health[token_idx].provider
                provider_counts[provider] += 1
                
        total = sum(provider_counts.values())
        return {
            provider: count / total
            for provider, count in provider_counts.items()
        }
        
    def _calculate_minimum_wait(self) -> float:
        """Calculate minimum wait time until a token is available"""
        min_wait = float('inf')
        current_time = time.time()
        
        for health in self.token_health.values():
            if health.rate_limit_reset and health.rate_limit_reset > current_time:
                wait = health.rate_limit_reset - current_time
                min_wait = min(min_wait, wait)
            else:
                # Token is available
                return 0
                
        return max(1, min(min_wait, 60))  # Cap at 60 seconds
        
    def _record_acquisition(self, token_idx: int, task_type: str, complexity: TaskComplexity):
        """Record token acquisition for analysis"""
        record = {
            'timestamp': time.time(),
            'token_idx': token_idx,
            'task_type': task_type,
            'complexity': complexity.value,
            'provider': self.token_health[token_idx].provider.value
        }
        
        # Save to file for analysis
        if self.output_dir:
            log_file = self.output_dir / "token_acquisitions.jsonl"
            with open(log_file, 'a') as f:
                f.write(json.dumps(record) + '\n')
                
    def get_pool_status(self) -> Dict[str, Any]:
        """Get current pool status and health metrics"""
        healthy_tokens = sum(
            1 for h in self.token_health.values()
            if h.health_score > 0.5
        )
        
        provider_stats = defaultdict(lambda: {'count': 0, 'healthy': 0})
        for health in self.token_health.values():
            stats = provider_stats[health.provider.value]
            stats['count'] += 1
            if health.health_score > 0.5:
                stats['healthy'] += 1
                
        return {
            'total_tokens': len(self.tokens),
            'healthy_tokens': healthy_tokens,
            'provider_stats': dict(provider_stats),
            'metrics': self.metrics,
            'average_health': sum(h.health_score for h in self.token_health.values()) / len(self.token_health)
        }
        
    async def rebalance_pool(self):
        """Rebalance token pool based on performance"""
        logger.info("Rebalancing token pool...")
        
        # Reset tokens with consistent errors
        for health in self.token_health.values():
            if health.error_rate > 0.5 and health.request_count > 10:
                logger.warning(f"Resetting unhealthy token {health.token_idx}")
                health.available_capacity = 0.5
                health.error_count = 0
                health.success_count = 0
                
        # Clear expired rate limits
        current_time = time.time()
        for health in self.token_health.values():
            if health.rate_limit_reset and health.rate_limit_reset < current_time:
                health.rate_limit_reset = None
                health.available_capacity = min(1.0, health.available_capacity * 1.2)
                
        logger.info("Token pool rebalanced")


# Example usage
if __name__ == "__main__":
    async def test_adaptive_pool():
        """Test the adaptive token pool"""
        
        # Create pool with test tokens
        test_tokens = [
            "sk-ant-test1" * 10,  # Anthropic-like
            "sk-test2" * 5,  # OpenAI-like
            "local-test3"  # Local
        ]
        
        pool = AdaptiveTokenPool(tokens=test_tokens)
        
        # Test acquisitions with different complexities
        for i in range(5):
            complexity = [
                TaskComplexity.LIGHTWEIGHT,
                TaskComplexity.NORMAL,
                TaskComplexity.HEAVYWEIGHT,
                TaskComplexity.CRITICAL,
                TaskComplexity.NORMAL
            ][i]
            
            token, idx = await pool.acquire_best_token(
                task_complexity=complexity,
                task_type="test"
            )
            
            print(f"Acquired token {idx} for {complexity.value} task")
            
            # Simulate work
            await asyncio.sleep(0.1)
            
            # Release with results
            pool.release_token(
                idx,
                success=(i % 2 == 0),
                latency=0.1 + i * 0.05,
                tokens_used=100 * (i + 1)
            )
            
        # Check pool status
        status = pool.get_pool_status()
        print(f"\nPool Status: {json.dumps(status, indent=2)}")
        
    asyncio.run(test_adaptive_pool())