#!/usr/bin/env python3
"""
Resilience and Recovery System for Agent Orchestration
Provides checkpointing, state persistence, and rapid recovery capabilities
"""

import asyncio
import json
import logging
import pickle
import shutil
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class RecoveryPriority(Enum):
    """Task recovery priority levels"""
    CRITICAL = 1  # Recover immediately
    HIGH = 2  # Recover in first batch
    NORMAL = 3  # Recover in normal order
    LOW = 4  # Recover when resources available


@dataclass
class Checkpoint:
    """Task checkpoint data"""
    task_id: str
    timestamp: float
    state: Dict[str, Any]
    partial_result: Optional[Dict] = None
    tokens_used: int = 0
    progress_percentage: float = 0
    dependencies_completed: List[str] = field(default_factory=list)
    error_count: int = 0
    last_error: Optional[str] = None
    recovery_priority: RecoveryPriority = RecoveryPriority.NORMAL
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        data = asdict(self)
        data['recovery_priority'] = self.recovery_priority.value
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Checkpoint':
        """Create from dictionary"""
        data['recovery_priority'] = RecoveryPriority(data.get('recovery_priority', 3))
        return cls(**data)


class CheckpointManager:
    """
    Manages task checkpoints for recovery
    Provides atomic writes and efficient storage
    """
    
    def __init__(
        self,
        checkpoint_dir: Path,
        max_checkpoints: int = 1000,
        compression: bool = True
    ):
        self.checkpoint_dir = checkpoint_dir
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.max_checkpoints = max_checkpoints
        self.compression = compression
        
        # Create subdirectories
        self.active_dir = self.checkpoint_dir / "active"
        self.archive_dir = self.checkpoint_dir / "archive"
        self.active_dir.mkdir(exist_ok=True)
        self.archive_dir.mkdir(exist_ok=True)
        
        # In-memory cache for fast access
        self._cache: Dict[str, Checkpoint] = {}
        self._load_cache()
        
        logger.info(f"CheckpointManager initialized at {checkpoint_dir}")
        
    def _load_cache(self):
        """Load existing checkpoints into cache"""
        for checkpoint_file in self.active_dir.glob("*.checkpoint"):
            try:
                with open(checkpoint_file, 'rb') as f:
                    data = pickle.load(f) if checkpoint_file.suffix == '.pickle' else json.load(f)
                checkpoint = Checkpoint.from_dict(data) if isinstance(data, dict) else data
                self._cache[checkpoint.task_id] = checkpoint
            except Exception as e:
                logger.warning(f"Failed to load checkpoint {checkpoint_file}: {e}")
                
    async def save_checkpoint(
        self,
        task_id: str,
        state: Dict[str, Any],
        partial_result: Optional[Dict] = None,
        tokens_used: int = 0,
        progress: float = 0,
        priority: RecoveryPriority = RecoveryPriority.NORMAL
    ) -> bool:
        """
        Save task checkpoint atomically
        
        Returns:
            True if checkpoint saved successfully
        """
        checkpoint = Checkpoint(
            task_id=task_id,
            timestamp=time.time(),
            state=state,
            partial_result=partial_result,
            tokens_used=tokens_used,
            progress_percentage=progress,
            recovery_priority=priority
        )
        
        # Update cache
        self._cache[task_id] = checkpoint
        
        # Write to disk atomically
        checkpoint_file = self.active_dir / f"{task_id}.checkpoint"
        temp_file = checkpoint_file.with_suffix('.tmp')
        
        try:
            # Write to temporary file
            if self.compression:
                with open(temp_file, 'wb') as f:
                    pickle.dump(checkpoint.to_dict(), f, protocol=pickle.HIGHEST_PROTOCOL)
            else:
                with open(temp_file, 'w') as f:
                    json.dump(checkpoint.to_dict(), f, indent=2)
            
            # Atomic rename
            temp_file.rename(checkpoint_file)
            
            logger.debug(f"Checkpoint saved for task {task_id} (progress: {progress:.1f}%)")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save checkpoint for {task_id}: {e}")
            if temp_file.exists():
                temp_file.unlink()
            return False
            
    async def load_checkpoint(self, task_id: str) -> Optional[Checkpoint]:
        """Load checkpoint for a task"""
        # Check cache first
        if task_id in self._cache:
            return self._cache[task_id]
            
        # Load from disk
        checkpoint_file = self.active_dir / f"{task_id}.checkpoint"
        if not checkpoint_file.exists():
            checkpoint_file = self.archive_dir / f"{task_id}.checkpoint"
            
        if checkpoint_file.exists():
            try:
                with open(checkpoint_file, 'rb') as f:
                    data = pickle.load(f) if self.compression else json.load(f)
                checkpoint = Checkpoint.from_dict(data) if isinstance(data, dict) else data
                self._cache[task_id] = checkpoint
                return checkpoint
            except Exception as e:
                logger.error(f"Failed to load checkpoint for {task_id}: {e}")
                
        return None
        
    async def delete_checkpoint(self, task_id: str) -> bool:
        """Delete checkpoint after successful completion"""
        # Remove from cache
        self._cache.pop(task_id, None)
        
        # Remove from disk
        checkpoint_file = self.active_dir / f"{task_id}.checkpoint"
        if checkpoint_file.exists():
            try:
                # Archive instead of delete
                archive_file = self.archive_dir / f"{task_id}_{int(time.time())}.checkpoint"
                checkpoint_file.rename(archive_file)
                logger.debug(f"Checkpoint archived for task {task_id}")
                return True
            except Exception as e:
                logger.error(f"Failed to archive checkpoint for {task_id}: {e}")
                
        return False
        
    async def get_all_checkpoints(self) -> List[Checkpoint]:
        """Get all active checkpoints"""
        return list(self._cache.values())
        
    async def cleanup_old_checkpoints(self, max_age_hours: int = 24):
        """Clean up old checkpoints"""
        cutoff_time = time.time() - (max_age_hours * 3600)
        removed = 0
        
        for checkpoint_file in self.archive_dir.glob("*.checkpoint"):
            if checkpoint_file.stat().st_mtime < cutoff_time:
                checkpoint_file.unlink()
                removed += 1
                
        if removed > 0:
            logger.info(f"Cleaned up {removed} old checkpoints")
            
    def get_recovery_stats(self) -> Dict[str, Any]:
        """Get checkpoint statistics"""
        total = len(self._cache)
        by_priority = {}
        total_progress = 0
        
        for checkpoint in self._cache.values():
            priority_name = checkpoint.recovery_priority.name
            by_priority[priority_name] = by_priority.get(priority_name, 0) + 1
            total_progress += checkpoint.progress_percentage
            
        return {
            'total_checkpoints': total,
            'by_priority': by_priority,
            'average_progress': total_progress / total if total > 0 else 0,
            'disk_usage_mb': sum(
                f.stat().st_size for f in self.checkpoint_dir.rglob("*.checkpoint")
            ) / (1024 * 1024)
        }


class StatePersistence:
    """
    Persist complete orchestrator state for crash recovery
    """
    
    def __init__(self, state_dir: Path):
        self.state_dir = state_dir
        self.state_dir.mkdir(parents=True, exist_ok=True)
        
        self.state_file = self.state_dir / "orchestrator_state.json"
        self.backup_file = self.state_dir / "orchestrator_state.backup"
        self.lock_file = self.state_dir / "state.lock"
        
        logger.info(f"StatePersistence initialized at {state_dir}")
        
    async def save_state(
        self,
        tasks: Dict[str, Any],
        metrics: Dict[str, Any],
        token_state: Dict[str, Any],
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Save complete orchestrator state atomically
        
        Returns:
            True if state saved successfully
        """
        state = {
            'version': '1.0',
            'timestamp': time.time(),
            'datetime': datetime.now().isoformat(),
            'tasks': tasks,
            'metrics': metrics,
            'token_state': token_state,
            'metadata': metadata or {}
        }
        
        # Create backup of existing state
        if self.state_file.exists():
            shutil.copy2(self.state_file, self.backup_file)
            
        # Write new state atomically
        temp_file = self.state_file.with_suffix('.tmp')
        
        try:
            with open(temp_file, 'w') as f:
                json.dump(state, f, indent=2, default=str)
                
            # Atomic rename
            temp_file.rename(self.state_file)
            
            logger.debug(f"Orchestrator state saved ({len(tasks)} tasks)")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save orchestrator state: {e}")
            
            # Restore backup if save failed
            if self.backup_file.exists():
                shutil.copy2(self.backup_file, self.state_file)
                
            if temp_file.exists():
                temp_file.unlink()
                
            return False
            
    async def load_state(self) -> Optional[Dict[str, Any]]:
        """Load orchestrator state"""
        if not self.state_file.exists():
            return None
            
        try:
            with open(self.state_file) as f:
                state = json.load(f)
                
            # Validate state
            required_keys = {'version', 'timestamp', 'tasks', 'metrics', 'token_state'}
            if not all(key in state for key in required_keys):
                logger.warning("Invalid state file format")
                return None
                
            logger.info(f"Loaded orchestrator state from {state['datetime']}")
            return state
            
        except Exception as e:
            logger.error(f"Failed to load orchestrator state: {e}")
            
            # Try backup
            if self.backup_file.exists():
                try:
                    with open(self.backup_file) as f:
                        return json.load(f)
                except:
                    pass
                    
        return None
        
    async def clear_state(self):
        """Clear saved state"""
        for file in [self.state_file, self.backup_file, self.lock_file]:
            if file.exists():
                file.unlink()
                
    def get_state_info(self) -> Dict[str, Any]:
        """Get information about saved state"""
        info = {
            'state_exists': self.state_file.exists(),
            'backup_exists': self.backup_file.exists()
        }
        
        if self.state_file.exists():
            stat = self.state_file.stat()
            info['state_size_kb'] = stat.st_size / 1024
            info['state_modified'] = datetime.fromtimestamp(stat.st_mtime).isoformat()
            
        return info


class RecoveryOrchestrator:
    """
    Orchestrate recovery after failures or token resets
    """
    
    def __init__(
        self,
        checkpoint_manager: CheckpointManager,
        state_persistence: StatePersistence,
        max_parallel_recovery: int = 5
    ):
        self.checkpoint_manager = checkpoint_manager
        self.state_persistence = state_persistence
        self.max_parallel_recovery = max_parallel_recovery
        
        self.recovery_queue = asyncio.PriorityQueue()
        self.recovery_stats = {
            'total_recovered': 0,
            'failed_recoveries': 0,
            'recovery_time': 0
        }
        
        logger.info("RecoveryOrchestrator initialized")
        
    async def prepare_recovery(self) -> int:
        """
        Prepare for recovery by loading and prioritizing checkpoints
        
        Returns:
            Number of tasks queued for recovery
        """
        start_time = time.time()
        
        # Load all checkpoints
        checkpoints = await self.checkpoint_manager.get_all_checkpoints()
        
        if not checkpoints:
            logger.info("No checkpoints to recover")
            return 0
            
        # Sort and queue by priority
        for checkpoint in checkpoints:
            priority = self._calculate_recovery_priority(checkpoint)
            await self.recovery_queue.put((priority, checkpoint))
            
        queue_size = self.recovery_queue.qsize()
        logger.info(f"Queued {queue_size} tasks for recovery in {time.time() - start_time:.2f}s")
        
        return queue_size
        
    def _calculate_recovery_priority(self, checkpoint: Checkpoint) -> float:
        """
        Calculate recovery priority score (lower = higher priority)
        
        Factors:
        - Recovery priority level (1-4)
        - Progress made (prefer nearly complete)
        - Time waiting (older = higher priority)
        - Error count (fewer errors = higher priority)
        """
        score = checkpoint.recovery_priority.value * 1000
        
        # Bonus for high progress (negative score = higher priority)
        score -= checkpoint.progress_percentage * 5
        
        # Penalty for errors
        score += checkpoint.error_count * 100
        
        # Consider age (older = higher priority)
        age_hours = (time.time() - checkpoint.timestamp) / 3600
        score -= min(age_hours * 10, 100)  # Cap age bonus
        
        return score
        
    async def execute_recovery(
        self,
        task_executor,
        token_pool,
        progress_callback=None
    ) -> Dict[str, Any]:
        """
        Execute recovery of checkpointed tasks
        
        Args:
            task_executor: Function to execute recovered tasks
            token_pool: Token pool for execution
            progress_callback: Optional callback for progress updates
            
        Returns:
            Recovery statistics
        """
        start_time = time.time()
        recovered = []
        failed = []
        
        total_tasks = self.recovery_queue.qsize()
        completed = 0
        
        while not self.recovery_queue.empty():
            # Get batch of tasks
            batch = []
            for _ in range(min(self.max_parallel_recovery, token_pool.available)):
                if not self.recovery_queue.empty():
                    priority, checkpoint = await self.recovery_queue.get()
                    batch.append(checkpoint)
                    
            if not batch:
                # No tasks or no tokens available
                await asyncio.sleep(1)
                continue
                
            # Execute batch
            logger.info(f"Recovering batch of {len(batch)} tasks")
            
            results = await asyncio.gather(*[
                self._recover_single_task(checkpoint, task_executor, token_pool)
                for checkpoint in batch
            ], return_exceptions=True)
            
            # Process results
            for checkpoint, result in zip(batch, results):
                completed += 1
                
                if isinstance(result, Exception):
                    failed.append(checkpoint.task_id)
                    logger.error(f"Failed to recover {checkpoint.task_id}: {result}")
                else:
                    recovered.append(checkpoint.task_id)
                    await self.checkpoint_manager.delete_checkpoint(checkpoint.task_id)
                    
                # Progress callback
                if progress_callback:
                    await progress_callback({
                        'completed': completed,
                        'total': total_tasks,
                        'percentage': (completed / total_tasks) * 100
                    })
                    
        # Update stats
        self.recovery_stats['total_recovered'] += len(recovered)
        self.recovery_stats['failed_recoveries'] += len(failed)
        self.recovery_stats['recovery_time'] += time.time() - start_time
        
        return {
            'recovered': recovered,
            'failed': failed,
            'duration': time.time() - start_time,
            'success_rate': len(recovered) / (len(recovered) + len(failed)) if recovered or failed else 0
        }
        
    async def _recover_single_task(
        self,
        checkpoint: Checkpoint,
        task_executor,
        token_pool
    ):
        """Recover a single task from checkpoint"""
        logger.info(f"Recovering task {checkpoint.task_id} (progress: {checkpoint.progress_percentage:.1f}%)")
        
        # Reconstruct task from checkpoint
        task = {
            'task_id': checkpoint.task_id,
            'state': checkpoint.state,
            'partial_result': checkpoint.partial_result,
            'resume_from_checkpoint': True
        }
        
        # Execute with recovery context
        result = await task_executor(task, token_pool)
        
        return result
        
    def get_recovery_stats(self) -> Dict[str, Any]:
        """Get recovery statistics"""
        return {
            **self.recovery_stats,
            'checkpoint_stats': self.checkpoint_manager.get_recovery_stats(),
            'state_info': self.state_persistence.get_state_info()
        }


class ResilienceMonitor:
    """
    Monitor system resilience and trigger recovery actions
    """
    
    def __init__(
        self,
        checkpoint_manager: CheckpointManager,
        recovery_orchestrator: RecoveryOrchestrator,
        health_check_interval: int = 30
    ):
        self.checkpoint_manager = checkpoint_manager
        self.recovery_orchestrator = recovery_orchestrator
        self.health_check_interval = health_check_interval
        
        self.health_metrics = {
            'last_checkpoint': time.time(),
            'checkpoint_frequency': deque(maxlen=100),
            'recovery_triggers': 0,
            'system_crashes': 0
        }
        
        self._monitoring = False
        self._monitor_task = None
        
    async def start_monitoring(self):
        """Start resilience monitoring"""
        if self._monitoring:
            return
            
        self._monitoring = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("Resilience monitoring started")
        
    async def stop_monitoring(self):
        """Stop resilience monitoring"""
        self._monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
                
        logger.info("Resilience monitoring stopped")
        
    async def _monitor_loop(self):
        """Main monitoring loop"""
        while self._monitoring:
            try:
                # Check system health
                health = await self._check_system_health()
                
                # Trigger recovery if needed
                if health.get('needs_recovery', False):
                    logger.warning("System health check triggered recovery")
                    self.health_metrics['recovery_triggers'] += 1
                    await self.recovery_orchestrator.prepare_recovery()
                    
                # Clean up old checkpoints
                await self.checkpoint_manager.cleanup_old_checkpoints()
                
                await asyncio.sleep(self.health_check_interval)
                
            except Exception as e:
                logger.error(f"Error in resilience monitor: {e}")
                await asyncio.sleep(5)
                
    async def _check_system_health(self) -> Dict[str, Any]:
        """Check system health indicators"""
        checkpoints = await self.checkpoint_manager.get_all_checkpoints()
        
        # Check for stale checkpoints (no progress in 5 minutes)
        stale_threshold = time.time() - 300
        stale_checkpoints = [
            cp for cp in checkpoints
            if cp.timestamp < stale_threshold
        ]
        
        return {
            'healthy': len(stale_checkpoints) == 0,
            'needs_recovery': len(stale_checkpoints) > 5,
            'total_checkpoints': len(checkpoints),
            'stale_checkpoints': len(stale_checkpoints)
        }


# Example usage
if __name__ == "__main__":
    async def test_resilience_system():
        """Test the resilience and recovery system"""
        
        # Setup
        work_dir = Path("/tmp/resilience_test")
        work_dir.mkdir(exist_ok=True)
        
        checkpoint_mgr = CheckpointManager(work_dir / "checkpoints")
        state_persist = StatePersistence(work_dir / "state")
        recovery_orch = RecoveryOrchestrator(checkpoint_mgr, state_persist)
        monitor = ResilienceMonitor(checkpoint_mgr, recovery_orch)
        
        # Test checkpoint saving
        for i in range(5):
            await checkpoint_mgr.save_checkpoint(
                task_id=f"task_{i}",
                state={'step': i, 'data': f"data_{i}"},
                progress=i * 20,
                priority=RecoveryPriority.HIGH if i < 2 else RecoveryPriority.NORMAL
            )
            
        # Test state persistence
        await state_persist.save_state(
            tasks={'task_1': {}, 'task_2': {}},
            metrics={'completed': 10, 'failed': 2},
            token_state={'tokens': 5, 'available': 3}
        )
        
        # Test recovery preparation
        queued = await recovery_orch.prepare_recovery()
        print(f"Queued {queued} tasks for recovery")
        
        # Get stats
        print(f"Recovery stats: {json.dumps(recovery_orch.get_recovery_stats(), indent=2)}")
        
        # Cleanup
        shutil.rmtree(work_dir)
        
    asyncio.run(test_resilience_system())