#!/usr/bin/env python3
"""
UI Performance Test
Tests dashboard frontend responsiveness under various load conditions
"""
import asyncio
import json
import time
import sys
import subprocess
from pathlib import Path
import aiohttp
from typing import Dict, List

class UIPerformanceTester:
    """Tests UI performance and responsiveness"""
    
    def __init__(self, dashboard_url: str = "http://localhost:8765"):
        self.dashboard_url = dashboard_url
        self.session = None
    
    async def setup(self):
        """Setup HTTP session"""
        self.session = aiohttp.ClientSession()
    
    async def cleanup(self):
        """Cleanup HTTP session"""
        if self.session:
            await self.session.close()
    
    async def test_static_resource_loading(self) -> Dict:
        """Test loading of static resources (CSS, JS)"""
        resources = [
            "/",
            "/css/dashboard.css",
            "/css/responsive.css", 
            "/js/dashboard.js",
            "/static/favicon.ico"
        ]
        
        results = {}
        print("🔍 Testing static resource loading...")
        
        for resource in resources:
            url = f"{self.dashboard_url}{resource}"
            start_time = time.time()
            
            try:
                async with self.session.get(url) as response:
                    content_length = response.headers.get('Content-Length', 0)
                    load_time = time.time() - start_time
                    
                    results[resource] = {
                        'status': response.status,
                        'load_time': load_time,
                        'size': int(content_length) if content_length else len(await response.read()),
                        'success': response.status == 200
                    }
                    
                    status = "✅" if response.status == 200 else "❌"
                    print(f"  {status} {resource}: {response.status} ({load_time*1000:.1f}ms, {results[resource]['size']:,} bytes)")
                    
            except Exception as e:
                results[resource] = {
                    'status': 0,
                    'load_time': time.time() - start_time,
                    'size': 0,
                    'success': False,
                    'error': str(e)
                }
                print(f"  ❌ {resource}: Error - {e}")
        
        return results
    
    async def test_api_response_times(self) -> Dict:
        """Test API endpoint response times under load"""
        endpoints = [
            "/health",
            "/api/summary",
            "/api/metrics", 
            "/api/active-tasks",
            "/api/active-agents"
        ]
        
        results = {}
        print("\n🚀 Testing API response times (10 requests each)...")
        
        for endpoint in endpoints:
            url = f"{self.dashboard_url}{endpoint}"
            times = []
            errors = 0
            
            # Make 10 requests to each endpoint
            for i in range(10):
                start_time = time.time()
                try:
                    async with self.session.get(url) as response:
                        await response.read()  # Ensure full response is received
                        load_time = time.time() - start_time
                        times.append(load_time)
                except Exception:
                    errors += 1
            
            if times:
                avg_time = sum(times) / len(times)
                min_time = min(times)
                max_time = max(times)
                
                results[endpoint] = {
                    'avg_ms': avg_time * 1000,
                    'min_ms': min_time * 1000,
                    'max_ms': max_time * 1000,
                    'success_rate': (10 - errors) / 10 * 100,
                    'errors': errors
                }
                
                print(f"  📊 {endpoint}: avg={avg_time*1000:.1f}ms, min={min_time*1000:.1f}ms, max={max_time*1000:.1f}ms ({10-errors}/10 success)")
            else:
                results[endpoint] = {'error': 'All requests failed', 'errors': errors}
                print(f"  ❌ {endpoint}: All requests failed")
        
        return results
    
    async def test_concurrent_api_load(self, concurrent_requests: int = 50) -> Dict:
        """Test API performance under concurrent load"""
        print(f"\n🔥 Testing concurrent API load ({concurrent_requests} requests)...")
        
        async def make_request(endpoint: str):
            """Make a single request and measure time"""
            url = f"{self.dashboard_url}{endpoint}"
            start_time = time.time()
            
            try:
                async with self.session.get(url) as response:
                    await response.read()
                    return {
                        'endpoint': endpoint,
                        'time': time.time() - start_time,
                        'status': response.status,
                        'success': response.status == 200
                    }
            except Exception as e:
                return {
                    'endpoint': endpoint,
                    'time': time.time() - start_time,
                    'status': 0,
                    'success': False,
                    'error': str(e)
                }
        
        # Create concurrent requests to different endpoints
        endpoints = ["/api/summary", "/api/metrics", "/api/active-tasks", "/api/active-agents"]
        tasks = []
        
        for i in range(concurrent_requests):
            endpoint = endpoints[i % len(endpoints)]
            task = asyncio.create_task(make_request(endpoint))
            tasks.append(task)
        
        start_time = time.time()
        results = await asyncio.gather(*tasks)
        total_time = time.time() - start_time
        
        # Analyze results
        successful = [r for r in results if r['success']]
        failed = [r for r in results if not r['success']]
        
        if successful:
            avg_response_time = sum(r['time'] for r in successful) / len(successful)
            max_response_time = max(r['time'] for r in successful)
            min_response_time = min(r['time'] for r in successful)
        else:
            avg_response_time = max_response_time = min_response_time = 0
        
        concurrent_results = {
            'total_requests': concurrent_requests,
            'successful_requests': len(successful),
            'failed_requests': len(failed),
            'total_time': total_time,
            'requests_per_second': concurrent_requests / total_time if total_time > 0 else 0,
            'avg_response_time_ms': avg_response_time * 1000,
            'max_response_time_ms': max_response_time * 1000,
            'min_response_time_ms': min_response_time * 1000,
            'success_rate': len(successful) / concurrent_requests * 100
        }
        
        print(f"  📈 Results: {len(successful)}/{concurrent_requests} successful")
        print(f"  ⚡ {concurrent_results['requests_per_second']:.1f} req/s")
        print(f"  ⏱️  Response time: avg={avg_response_time*1000:.1f}ms, max={max_response_time*1000:.1f}ms")
        print(f"  ✅ Success rate: {concurrent_results['success_rate']:.1f}%")
        
        return concurrent_results
    
    async def test_websocket_performance(self) -> Dict:
        """Test WebSocket connection and message throughput"""
        print("\n🌐 Testing WebSocket performance...")
        
        import websockets
        
        messages_sent = 0
        messages_received = 0
        start_time = time.time()
        test_duration = 10  # seconds
        
        try:
            uri = f"ws://localhost:8765/ws"
            async with websockets.connect(uri) as websocket:
                print("  ✅ WebSocket connected")
                
                end_time = start_time + test_duration
                last_ping = 0
                
                while time.time() < end_time:
                    # Send ping every 0.5 seconds
                    if time.time() - last_ping >= 0.5:
                        ping_msg = {"type": "ping", "timestamp": time.time()}
                        await websocket.send(json.dumps(ping_msg))
                        messages_sent += 1
                        last_ping = time.time()
                    
                    # Try to receive messages
                    try:
                        await asyncio.wait_for(websocket.recv(), timeout=0.1)
                        messages_received += 1
                    except asyncio.TimeoutError:
                        continue
                
                actual_duration = time.time() - start_time
                
                ws_results = {
                    'connection_successful': True,
                    'messages_sent': messages_sent,
                    'messages_received': messages_received,
                    'test_duration': actual_duration,
                    'send_rate': messages_sent / actual_duration,
                    'receive_rate': messages_received / actual_duration,
                    'message_success_rate': messages_received / max(messages_sent, 1) * 100
                }
                
                print(f"  📊 Sent: {messages_sent}, Received: {messages_received}")
                print(f"  📈 Rates: {ws_results['send_rate']:.1f} sent/s, {ws_results['receive_rate']:.1f} received/s")
                print(f"  ✅ Success rate: {ws_results['message_success_rate']:.1f}%")
                
                return ws_results
                
        except Exception as e:
            print(f"  ❌ WebSocket test failed: {e}")
            return {'connection_successful': False, 'error': str(e)}
    
    def print_summary(self, static_results: Dict, api_results: Dict, concurrent_results: Dict, ws_results: Dict):
        """Print comprehensive test summary"""
        print("\n" + "="*70)
        print("🏁 UI PERFORMANCE TEST SUMMARY")
        print("="*70)
        
        # Static resources
        static_success = sum(1 for r in static_results.values() if r.get('success', False))
        print(f"Static Resources: {static_success}/{len(static_results)} loaded successfully")
        
        total_static_size = sum(r.get('size', 0) for r in static_results.values())
        avg_static_time = sum(r.get('load_time', 0) for r in static_resources.values()) / len(static_results)
        print(f"Static Load Time: {avg_static_time*1000:.1f}ms average, {total_static_size:,} bytes total")
        
        # API performance
        api_success_rate = sum(r.get('success_rate', 0) for r in api_results.values()) / len(api_results)
        avg_api_response = sum(r.get('avg_ms', 0) for r in api_results.values()) / len(api_results)
        print(f"API Performance: {api_success_rate:.1f}% success rate, {avg_api_response:.1f}ms average response")
        
        # Concurrent performance
        print(f"Concurrent Load: {concurrent_results['success_rate']:.1f}% success, {concurrent_results['requests_per_second']:.1f} req/s")
        
        # WebSocket performance
        if ws_results.get('connection_successful'):
            print(f"WebSocket: {ws_results['message_success_rate']:.1f}% message success, {ws_results['receive_rate']:.1f} msg/s")
        else:
            print(f"WebSocket: ❌ Connection failed")
        
        # Overall assessment
        overall_score = (
            (static_success / len(static_results)) * 25 +
            (api_success_rate / 100) * 25 +
            (concurrent_results['success_rate'] / 100) * 25 +
            (ws_results.get('message_success_rate', 0) / 100) * 25
        )
        
        print(f"\n🎯 Overall Performance Score: {overall_score:.1f}/100")
        
        if overall_score >= 90:
            print("🏆 EXCELLENT: Dashboard is performing exceptionally well under all test conditions")
        elif overall_score >= 75:
            print("✅ GOOD: Dashboard performance is solid with minor areas for improvement") 
        elif overall_score >= 60:
            print("⚠️ FAIR: Dashboard has some performance issues that should be addressed")
        else:
            print("❌ POOR: Dashboard has significant performance problems requiring attention")

async def main():
    """Run complete UI performance test suite"""
    tester = UIPerformanceTester()
    
    try:
        await tester.setup()
        
        print("🎯 Dashboard UI Performance Test Suite")
        print("="*50)
        
        # Run all tests
        static_results = await tester.test_static_resource_loading()
        api_results = await tester.test_api_response_times() 
        concurrent_results = await tester.test_concurrent_api_load(concurrent_requests=30)
        ws_results = await tester.test_websocket_performance()
        
        # Print comprehensive summary
        tester.print_summary(static_results, api_results, concurrent_results, ws_results)
        
    finally:
        await tester.cleanup()

if __name__ == "__main__":
    asyncio.run(main())