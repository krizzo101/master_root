#!/usr/bin/env python3
"""
WebSocket Load Test
Tests WebSocket connections and real-time streaming under load
"""
import asyncio
import json
import sys
import time
import websockets
from typing import List, Dict

async def websocket_client(client_id: int, duration: int = 30):
    """Single WebSocket client that monitors for duration"""
    uri = "ws://localhost:8765/ws"
    messages_received = 0
    start_time = time.time()
    
    try:
        async with websockets.connect(uri) as websocket:
            print(f"Client {client_id}: Connected")
            
            # Send ping periodically and listen for messages
            end_time = start_time + duration
            last_ping = 0
            
            while time.time() < end_time:
                try:
                    # Send ping every 5 seconds
                    if time.time() - last_ping > 5:
                        ping_msg = {"type": "ping", "timestamp": time.time()}
                        await websocket.send(json.dumps(ping_msg))
                        last_ping = time.time()
                    
                    # Listen for messages with short timeout
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=1.0)
                        messages_received += 1
                        
                        # Parse and analyze message
                        try:
                            data = json.loads(message)
                            msg_type = data.get('type', 'unknown')
                            if messages_received % 10 == 0:
                                print(f"Client {client_id}: Received {messages_received} messages (last: {msg_type})")
                        except json.JSONDecodeError:
                            pass
                            
                    except asyncio.TimeoutError:
                        # No message received, continue
                        pass
                        
                except websockets.exceptions.ConnectionClosed:
                    print(f"Client {client_id}: Connection closed")
                    break
                    
    except Exception as e:
        print(f"Client {client_id}: Error - {e}")
    
    duration_actual = time.time() - start_time
    print(f"Client {client_id}: Completed. {messages_received} messages in {duration_actual:.1f}s ({messages_received/duration_actual:.1f} msg/s)")
    
    return {
        'client_id': client_id,
        'messages': messages_received,
        'duration': duration_actual,
        'rate': messages_received/duration_actual if duration_actual > 0 else 0
    }

async def concurrent_websocket_test(num_clients: int = 10, duration: int = 30):
    """Test multiple concurrent WebSocket connections"""
    print(f"🚀 Starting WebSocket load test: {num_clients} clients for {duration}s")
    
    # Start all clients concurrently
    tasks = []
    for i in range(num_clients):
        task = asyncio.create_task(websocket_client(i+1, duration))
        tasks.append(task)
        # Stagger client connections slightly
        await asyncio.sleep(0.1)
    
    # Wait for all clients to complete
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Analyze results
    successful_results = [r for r in results if isinstance(r, dict)]
    failed_count = len([r for r in results if isinstance(r, Exception)])
    
    if successful_results:
        total_messages = sum(r['messages'] for r in successful_results)
        avg_rate = sum(r['rate'] for r in successful_results) / len(successful_results)
        max_rate = max(r['rate'] for r in successful_results)
        min_rate = min(r['rate'] for r in successful_results)
        
        print(f"\n📊 WebSocket Load Test Results:")
        print(f"  Successful clients: {len(successful_results)}/{num_clients}")
        print(f"  Failed clients: {failed_count}")
        print(f"  Total messages: {total_messages}")
        print(f"  Average rate: {avg_rate:.1f} msg/s per client")
        print(f"  Max rate: {max_rate:.1f} msg/s")
        print(f"  Min rate: {min_rate:.1f} msg/s")
        print(f"  Aggregate rate: {total_messages/duration:.1f} msg/s")
    else:
        print("❌ All WebSocket connections failed")

async def test_websocket_message_types():
    """Test different WebSocket message types"""
    uri = "ws://localhost:8765/ws"
    
    print("🔍 Testing WebSocket message types...")
    
    try:
        async with websockets.connect(uri) as websocket:
            print("✅ Connected to WebSocket")
            
            # Test different message requests
            test_messages = [
                {"type": "get_summary"},
                {"type": "get_metrics", "seconds": 60},
                {"type": "ping", "timestamp": time.time()}
            ]
            
            for msg in test_messages:
                await websocket.send(json.dumps(msg))
                
                # Wait for response
                try:
                    response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                    data = json.loads(response)
                    print(f"✅ {msg['type']} -> {data.get('type', 'unknown')} ({len(response)} bytes)")
                except asyncio.TimeoutError:
                    print(f"⏰ {msg['type']} -> Timeout")
                except Exception as e:
                    print(f"❌ {msg['type']} -> Error: {e}")
                    
    except Exception as e:
        print(f"❌ WebSocket test failed: {e}")

async def main():
    """Main test runner"""
    print("🌐 Dashboard WebSocket Load Testing")
    print("=" * 50)
    
    # Test basic message types first
    await test_websocket_message_types()
    print()
    
    # Test concurrent load
    await concurrent_websocket_test(num_clients=5, duration=15)

if __name__ == "__main__":
    asyncio.run(main())