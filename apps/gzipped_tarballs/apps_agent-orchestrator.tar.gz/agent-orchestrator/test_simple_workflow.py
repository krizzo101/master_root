#!/usr/bin/env python3
"""
Simplified test to verify the workflow generation fixes work.
"""

import asyncio
import json
import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, '/home/opsvi/master_root/apps/dpo/src')
sys.path.insert(0, '/home/opsvi/master_root/apps/agent-orchestrator/src')

async def test_enhancement_engine():
    """Test just the EnhancementIntelligenceEngine.process_request method"""
    print("Testing EnhancementIntelligenceEngine.process_request()...")
    
    # Import here to avoid issues
    from intelligence_review_engine_enhanced import EnhancementIntelligenceEngine
    
    # Create a mock orchestrator to avoid the real one
    class MockOrchestrator:
        async def execute_batch(self, tasks):
            """Mock execution - return dummy results"""
            results = []
            for task in tasks:
                results.append({
                    "task_id": task.task_id,
                    "status": "completed",
                    "result": {
                        "enhancements": [
                            {
                                "title": f"Enhancement from {task.task_type}",
                                "description": "A mock enhancement",
                                "category": "performance",
                                "impact": "High impact improvement"
                            }
                        ]
                    }
                })
            return results
    
    # Create engine with mock orchestrator
    engine = EnhancementIntelligenceEngine(
        orchestrator=MockOrchestrator(),
        parallel_agents=2,
        output_dir="/tmp/test_enhancements"
    )
    
    # Test request
    test_request = {
        "request": "Build a simple web app",
        "project_type": "web_app",
        "complexity": "simple",
        "key_requirements": ["User login", "Dashboard"],
        "suggested_technologies": ["React", "FastAPI"],
        "context": {},
        "focus_areas": ["performance"]
    }
    
    try:
        result = await engine.process_request(test_request)
        print("✅ process_request() succeeded!")
        print(f"Result has 'enhancements' key: {'enhancements' in result}")
        if 'enhancements' in result:
            print(f"Number of enhancements: {len(result['enhancements'])}")
        return True
    except Exception as e:
        print(f"❌ process_request() failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_template_system():
    """Test the SDLCTemplateSystem.generate_workflow method"""
    print("\nTesting SDLCTemplateSystem.generate_workflow()...")
    
    from sdlc_template_system import SDLCTemplateSystem
    
    template_system = SDLCTemplateSystem()
    
    # Test data
    enhancements = {
        "enhancements": [
            {"id": "1", "title": "Add caching", "description": "Redis cache", "category": "performance", "priority": 0.8}
        ]
    }
    
    specifications = {
        "requirements": ["User auth", "Dashboard"],
        "technologies": ["React", "FastAPI"],
        "enhancements": enhancements.get("enhancements", []),
        "context": {}
    }
    
    try:
        workflow = template_system.generate_workflow(
            project_name="test_project",
            project_type="web_app",
            complexity="moderate",
            specifications=specifications
        )
        
        print("✅ generate_workflow() succeeded!")
        print(f"Workflow has 'phases' key: {'phases' in workflow}")
        if 'phases' in workflow:
            print(f"Number of phases: {len(workflow['phases'])}")
        
        # Save for inspection
        output_file = Path("/home/opsvi/master_root/apps/agent-orchestrator/test_workflow_output.json")
        with open(output_file, "w") as f:
            json.dump(workflow, f, indent=2, default=str)
        print(f"Workflow saved to: {output_file}")
        
        return True
    except Exception as e:
        print(f"❌ generate_workflow() failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def main():
    """Run tests"""
    print("=" * 60)
    print("SIMPLIFIED WORKFLOW GENERATION TEST")
    print("=" * 60)
    
    test1 = await test_enhancement_engine()
    test2 = await test_template_system()
    
    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    print(f"Enhancement Engine: {'✅ PASSED' if test1 else '❌ FAILED'}")
    print(f"Template System: {'✅ PASSED' if test2 else '❌ FAILED'}")
    
    if test1 and test2:
        print("\n🎉 SUCCESS! The workflow generation pipeline is working.")
        print("\nThe following methods are now implemented:")
        print("1. EnhancementIntelligenceEngine.process_request()")
        print("2. SDLCTemplateSystem.generate_workflow() - already existed")
        print("3. DPOMainController._generate_workflow() - already existed")
        print("\nThe workflow generation pipeline should now work end-to-end.")
    else:
        print("\n⚠️ Some components still have issues.")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())