#!/usr/bin/env python3
"""Test UnifiedOrchestrator with execution planning"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, "/home/opsvi/master_root/apps/agent-orchestrator/src")

async def test_unified_execution_plan():
    """Test UnifiedOrchestrator's execution planning capabilities"""
    
    from unified.unified_orchestrator import create_advanced_orchestrator
    from unified.enhanced_agent_task import EnhancedAgentTask
    
    print("=" * 70)
    print("UNIFIED ORCHESTRATOR EXECUTION PLAN TEST")
    print("=" * 70)
    
    # Create unified orchestrator with execution planning
    try:
        orchestrator = create_advanced_orchestrator(
            output_dir=Path("/tmp/unified_test"),
            max_parallel=3
        )
        print(f"✓ UnifiedOrchestrator created successfully")
        print(f"  Features enabled: {orchestrator.config.enabled_features}")
    except Exception as e:
        print(f"✗ Failed to create orchestrator: {e}")
        return False
    
    # Create tasks with SDLC phases
    tasks = [
        EnhancedAgentTask(
            task_id="analyze_requirements",
            task_type="requirements-analyst",
            prompt="Analyze requirements for a simple todo API",
            phase_id="discovery"
        ),
        EnhancedAgentTask(
            task_id="design_architecture",
            task_type="solution-architect",
            prompt="Design architecture for todo API",
            phase_id="design",
            dependencies=["analyze_requirements"]
        ),
        EnhancedAgentTask(
            task_id="implement_api",
            task_type="development-specialist",
            prompt="Implement the todo API endpoints",
            phase_id="development",
            dependencies=["design_architecture"]
        ),
        EnhancedAgentTask(
            task_id="write_tests",
            task_type="qa-testing-guru",
            prompt="Write comprehensive tests for API",
            phase_id="testing",
            dependencies=["implement_api"]
        )
    ]
    
    print(f"\n✓ Created {len(tasks)} tasks with SDLC phases:")
    for task in tasks:
        print(f"  - {task.task_id} [{task.phase_id}]")
    
    # Ensure modules are loaded
    try:
        await orchestrator._ensure_modules_loaded()
        print(f"\n✓ Modules loaded successfully")
    except Exception as e:
        print(f"\n✗ Failed to load modules: {e}")
        return False
    
    # Test execution plan generation
    try:
        if hasattr(orchestrator.module_registry, 'get_module'):
            plan_module = orchestrator.module_registry.get_module('execution_plan')
            if plan_module:
                execution_plan = plan_module.create_execution_plan(tasks)
                
                print(f"\n✓ Execution plan generated:")
                print(f"  Total phases: {len(execution_plan.phases)}")
                for phase in execution_plan.phases:
                    print(f"  - {phase.name}: {len(phase.tasks)} tasks")
            else:
                print("\n✗ Execution plan module not found")
        else:
            print("\n⚠ Module registry not accessible")
    except Exception as e:
        print(f"\n✗ Failed to generate execution plan: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print("\n" + "=" * 70)
    print("✓ UNIFIED ORCHESTRATOR TEST COMPLETE")
    print("=" * 70)
    return True

if __name__ == "__main__":
    asyncio.run(test_unified_execution_plan())