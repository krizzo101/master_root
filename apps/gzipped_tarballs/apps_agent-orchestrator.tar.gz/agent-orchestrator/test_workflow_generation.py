#!/usr/bin/env python3
"""
Test script to verify the workflow generation pipeline works correctly.
Tests the integration between EnhancementIntelligenceEngine, DPOMainController,
and the workflow generation process.
"""

import asyncio
import json
import sys
from pathlib import Path

# Add parent directories to path for imports
sys.path.insert(0, '/home/opsvi/master_root/apps/dpo/src')
sys.path.insert(0, '/home/opsvi/master_root/apps/agent-orchestrator/src')

from intelligence_review_engine_enhanced import EnhancementIntelligenceEngine

async def test_process_request():
    """Test the new process_request method"""
    print("Testing EnhancementIntelligenceEngine.process_request()...")
    
    # Create engine instance
    engine = EnhancementIntelligenceEngine()
    
    # Create test request (similar to what DPOMainController would send)
    test_request = {
        "request": "Build a web application for managing tasks",
        "project_type": "web_app",
        "complexity": "moderate",
        "key_requirements": [
            "User authentication",
            "Task CRUD operations",
            "Dashboard view"
        ],
        "suggested_technologies": [
            "React",
            "FastAPI",
            "PostgreSQL"
        ],
        "context": {
            "team_size": 3,
            "timeline": "4 weeks"
        },
        "focus_areas": ["quality", "performance"]
    }
    
    try:
        # Process the request
        result = await engine.process_request(test_request)
        
        # Check result structure
        print("\n✅ Process request successful!")
        print(f"Result keys: {list(result.keys())}")
        
        if "enhancements" in result:
            print(f"Number of enhancements: {len(result['enhancements'])}")
            if result['enhancements']:
                print(f"First enhancement: {result['enhancements'][0]}")
        
        if "metadata" in result:
            print(f"Metadata: {result['metadata']}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Process request failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

async def test_workflow_generation():
    """Test the complete workflow generation pipeline"""
    print("\n\nTesting complete workflow generation pipeline...")
    
    from sdlc_template_system import SDLCTemplateSystem
    from dpo_main_controller import RequestAnalysis, RequestType
    
    # Create test analysis result
    analysis = RequestAnalysis(
        request_type=RequestType.BUILD,
        project_type="web_app",
        complexity="moderate",
        key_requirements=["User auth", "Task management"],
        suggested_technologies=["React", "FastAPI"],
        risk_factors=["Timeline constraints"],
        estimated_effort="4 weeks",
        confidence_score=0.85
    )
    
    # Create enhancements dict (as would come from process_request)
    enhancements = {
        "enhancements": [
            {
                "id": "enh_001",
                "title": "Add caching layer",
                "description": "Implement Redis caching for improved performance",
                "category": "performance",
                "priority": 0.8
            },
            {
                "id": "enh_002", 
                "title": "Add monitoring",
                "description": "Implement application monitoring with Prometheus",
                "category": "observability",
                "priority": 0.7
            }
        ],
        "metadata": {
            "enhancements_selected": 2,
            "processing_time": 1.5
        }
    }
    
    # Create template system
    template_system = SDLCTemplateSystem()
    
    try:
        # Generate workflow
        project_name = "test_project_20250909"
        specifications = {
            "requirements": analysis.key_requirements,
            "technologies": analysis.suggested_technologies,
            "enhancements": enhancements.get("enhancements", []),
            "context": {}
        }
        
        workflow = template_system.generate_workflow(
            project_name=project_name,
            project_type=analysis.project_type,
            complexity=analysis.complexity,
            specifications=specifications
        )
        
        print("\n✅ Workflow generation successful!")
        print(f"Workflow keys: {list(workflow.keys())}")
        
        if "phases" in workflow:
            print(f"Number of phases: {len(workflow['phases'])}")
            if workflow['phases']:
                print(f"First phase: {workflow['phases'][0].get('name', 'Unknown')}")
        
        if "metadata" in workflow:
            print(f"Workflow metadata: {workflow['metadata']}")
        
        # Save workflow for inspection
        output_file = Path("/home/opsvi/master_root/apps/agent-orchestrator/test_generated_workflow.json")
        with open(output_file, "w") as f:
            json.dump(workflow, f, indent=2, default=str)
        print(f"\nWorkflow saved to: {output_file}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Workflow generation failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

async def main():
    """Run all tests"""
    print("=" * 60)
    print("WORKFLOW GENERATION PIPELINE TEST")
    print("=" * 60)
    
    # Test 1: Process request method
    test1_passed = await test_process_request()
    
    # Test 2: Workflow generation
    test2_passed = await test_workflow_generation()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    print(f"Process request test: {'✅ PASSED' if test1_passed else '❌ FAILED'}")
    print(f"Workflow generation test: {'✅ PASSED' if test2_passed else '❌ FAILED'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 All tests passed! The workflow generation pipeline is working.")
    else:
        print("\n⚠️ Some tests failed. Please check the error messages above.")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())