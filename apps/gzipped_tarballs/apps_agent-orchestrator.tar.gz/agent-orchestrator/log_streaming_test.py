#!/usr/bin/env python3
"""
Log Streaming Performance Test
Tests the ability to stream and process large log files in real-time
"""
import asyncio
import json
import time
import sys
from pathlib import Path
from typing import Dict, List, AsyncGenerator
import aiofiles

class LogStreamingTester:
    """Tests log streaming performance under various conditions"""
    
    def __init__(self):
        self.test_results = {}
    
    async def stream_log_file(self, file_path: str, chunk_size: int = 8192) -> AsyncGenerator[str, None]:
        """Stream a log file asynchronously"""
        async with aiofiles.open(file_path, 'r') as f:
            buffer = ""
            while True:
                chunk = await f.read(chunk_size)
                if not chunk:
                    if buffer:
                        yield buffer
                    break
                
                buffer += chunk
                lines = buffer.split('\n')
                buffer = lines[-1]  # Keep incomplete line in buffer
                
                for line in lines[:-1]:
                    if line.strip():
                        yield line
    
    async def parse_log_lines(self, lines: AsyncGenerator[str, None]) -> Dict:
        """Parse log lines and extract metrics"""
        total_lines = 0
        parsed_lines = 0
        error_lines = 0
        workflows = set()
        agents = set()
        log_levels = {}
        start_time = time.time()
        
        async for line in lines:
            total_lines += 1
            
            try:
                data = json.loads(line)
                parsed_lines += 1
                
                # Extract metrics
                if 'workflow' in data:
                    workflows.add(data['workflow'])
                if 'agent' in data:
                    agents.add(data['agent'])
                if 'level' in data:
                    level = data['level']
                    log_levels[level] = log_levels.get(level, 0) + 1
                    
            except json.JSONDecodeError:
                error_lines += 1
                
            # Progress indicator for large files
            if total_lines % 1000 == 0:
                elapsed = time.time() - start_time
                rate = total_lines / elapsed if elapsed > 0 else 0
                print(f"  📊 Processed {total_lines} lines ({rate:.0f} lines/s)")
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        return {
            'total_lines': total_lines,
            'parsed_lines': parsed_lines,
            'error_lines': error_lines,
            'unique_workflows': len(workflows),
            'unique_agents': len(agents),
            'log_levels': log_levels,
            'processing_time': processing_time,
            'lines_per_second': total_lines / processing_time if processing_time > 0 else 0
        }
    
    async def test_single_file(self, file_path: str, chunk_size: int = 8192) -> Dict:
        """Test streaming performance for a single file"""
        print(f"🔄 Testing file: {file_path} (chunk_size: {chunk_size})")
        
        file_size = Path(file_path).stat().st_size
        print(f"  📁 File size: {file_size:,} bytes ({file_size/1024/1024:.1f} MB)")
        
        start_time = time.time()
        
        # Stream and parse the file
        line_stream = self.stream_log_file(file_path, chunk_size)
        results = await self.parse_log_lines(line_stream)
        
        results.update({
            'file_path': file_path,
            'file_size_bytes': file_size,
            'file_size_mb': file_size / 1024 / 1024,
            'chunk_size': chunk_size,
            'mb_per_second': (file_size / 1024 / 1024) / results['processing_time'] if results['processing_time'] > 0 else 0
        })
        
        return results
    
    async def test_multiple_files_concurrent(self, file_paths: List[str]) -> List[Dict]:
        """Test streaming multiple files concurrently"""
        print(f"🚀 Testing {len(file_paths)} files concurrently...")
        
        tasks = []
        for file_path in file_paths:
            task = asyncio.create_task(self.test_single_file(file_path))
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        return results
    
    async def test_different_chunk_sizes(self, file_path: str) -> Dict:
        """Test performance with different chunk sizes"""
        chunk_sizes = [1024, 4096, 8192, 16384, 32768]
        results = {}
        
        print(f"🔍 Testing different chunk sizes on {file_path}")
        
        for chunk_size in chunk_sizes:
            result = await self.test_single_file(file_path, chunk_size)
            results[chunk_size] = result
            print(f"  ✅ {chunk_size:>5} bytes: {result['lines_per_second']:.0f} lines/s, {result['mb_per_second']:.1f} MB/s")
        
        return results
    
    def print_results(self, results: Dict):
        """Print detailed test results"""
        print("\n" + "="*60)
        print("📈 LOG STREAMING PERFORMANCE RESULTS")
        print("="*60)
        
        if isinstance(results, list):
            # Multiple file results
            total_lines = sum(r['total_lines'] for r in results)
            total_size = sum(r['file_size_mb'] for r in results)
            avg_rate = sum(r['lines_per_second'] for r in results) / len(results)
            
            print(f"Files processed: {len(results)}")
            print(f"Total lines: {total_lines:,}")
            print(f"Total size: {total_size:.1f} MB")
            print(f"Average rate: {avg_rate:.0f} lines/s")
            print()
            
            for i, result in enumerate(results, 1):
                print(f"File {i}: {result['lines_per_second']:.0f} lines/s, {result['mb_per_second']:.1f} MB/s")
        
        elif isinstance(results, dict) and 'file_path' in results:
            # Single file result
            r = results
            print(f"File: {r['file_path']}")
            print(f"Size: {r['file_size_mb']:.1f} MB ({r['total_lines']:,} lines)")
            print(f"Performance: {r['lines_per_second']:.0f} lines/s, {r['mb_per_second']:.1f} MB/s")
            print(f"Parsed: {r['parsed_lines']:,}/{r['total_lines']:,} lines ({100*r['parsed_lines']/r['total_lines']:.1f}%)")
            print(f"Errors: {r['error_lines']} lines")
            print(f"Workflows: {r['unique_workflows']}")
            print(f"Agents: {r['unique_agents']}")
            print(f"Log levels: {r['log_levels']}")

async def main():
    """Main test runner"""
    tester = LogStreamingTester()
    
    # Test files
    large_log = "test_logs/large_test.log"
    real_logs = [
        "outputs/apps_audit/audit_20250908_003231/logs/orchestrator_20250908_003231.log",
        "outputs/live_chat_test/logs/orchestrator_20250907_200947.log"
    ]
    
    # Filter for existing files
    test_files = [f for f in [large_log] + real_logs if Path(f).exists()]
    
    print("📊 Log Streaming Performance Test Suite")
    print(f"Testing {len(test_files)} log files")
    print()
    
    # Test 1: Large synthetic file performance
    if Path(large_log).exists():
        print("🚀 Test 1: Large file performance")
        result = await tester.test_single_file(large_log)
        tester.print_results(result)
        print()
        
        # Test different chunk sizes
        print("🚀 Test 2: Chunk size optimization")
        chunk_results = await tester.test_different_chunk_sizes(large_log)
        print()
    
    # Test 3: Multiple files concurrently
    if len(test_files) > 1:
        print("🚀 Test 3: Concurrent file processing")
        concurrent_results = await tester.test_multiple_files_concurrent(test_files[:3])
        tester.print_results(concurrent_results)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")