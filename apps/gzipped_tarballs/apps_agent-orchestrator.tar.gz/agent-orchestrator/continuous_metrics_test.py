#!/usr/bin/env python3
"""
Continuous metrics feeding for dashboard load testing
"""
import sys
import time
import random
import threading
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from monitoring.metrics_collector import get_global_collector, MetricType, Metric

def continuous_metrics_feed():
    """Generate continuous metrics feed"""
    collector = get_global_collector()
    
    workflows = [
        'dashboard_build_20250908_123000',
        'system_documentation_20250908_130547', 
        'analysis_20250907_174810',
        'apps_audit_20250908_003231',
        'live_chat_test'
    ]
    
    counter = 0
    print("🔄 Starting continuous metrics feed...")
    
    try:
        while True:
            for i, wf in enumerate(workflows):
                agent_id = f'{wf}_agent_{i+1}'
                task_id = f'{wf}_task_{counter}_{i+1}'
                
                # Random task events
                if random.random() < 0.3:  # 30% chance
                    collector.record_task_started(task_id, agent_id=agent_id, metadata={'workflow': wf})
                    
                if random.random() < 0.2:  # 20% chance  
                    if random.random() < 0.8:  # 80% success
                        collector.record_task_completed(
                            task_id,
                            agent_id=agent_id,
                            execution_time=random.uniform(1.0, 30.0),
                            metadata={'workflow': wf}
                        )
                    else:  # 20% failure
                        collector.record_task_failed(
                            task_id,
                            agent_id=agent_id,
                            error=random.choice(['Timeout', 'API Error', 'Memory Error']),
                            metadata={'workflow': wf}
                        )
                
                # Token usage
                if random.random() < 0.4:  # 40% chance
                    collector.record_token_usage(
                        agent_id=agent_id,
                        input_tokens=random.randint(1000, 8000),
                        output_tokens=random.randint(200, 2000),
                        metadata={'workflow': wf, 'model': 'claude-3.5-sonnet'}
                    )
                
                # Memory metrics
                if random.random() < 0.1:  # 10% chance
                    memory_metric = Metric(
                        metric_type=MetricType.MEMORY_USAGE,
                        value=random.uniform(50, 500),
                        agent_id=agent_id,
                        metadata={'workflow': wf}
                    )
                    collector.record_metric(memory_metric)
            
            counter += 1
            
            # Print summary every 10 iterations
            if counter % 10 == 0:
                summary = collector.get_summary()
                print(f"📊 Cycle {counter}: {summary.total_tasks} tasks, {summary.active_agents} agents, {summary.error_rate:.1%} error rate")
            
            time.sleep(1)  # 1 second intervals
            
    except KeyboardInterrupt:
        print("\n🛑 Stopping metrics feed")

if __name__ == "__main__":
    continuous_metrics_feed()