#!/usr/bin/env python3
"""
Dashboard Backend Server
FastAPI application with WebSocket endpoints for real-time orchestrator monitoring

Implements:
- Real-time workflow monitoring for 10+ concurrent processes
- WebSocket hub for event broadcasting
- REST API endpoints for workflow data and task status
- File system watchers for log and deliverable tracking
- Non-intrusive integration with GenericOrchestrator
"""

import asyncio
import json
import logging
import os
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.websockets import WebSocketState
from pydantic import BaseModel, Field
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
class Settings:
    """Dashboard server configuration"""
    HOST = "0.0.0.0"
    PORT = 8888
    WEBSOCKET_PORT = 8765
    MAX_WORKFLOWS = 50
    LOG_DIRECTORIES = ["outputs", "output", "wbs_output", "logs"]
    ORCHESTRATOR_OUTPUT_BASE = "/home/opsvi/master_root/apps/agent-orchestrator"
    FILE_WATCH_RECURSIVE = True
    WEBSOCKET_MAX_CONNECTIONS = 100
    EVENT_QUEUE_SIZE = 10000

settings = Settings()

# Data Models
class WorkflowStatus(BaseModel):
    """Workflow status information"""
    workflow_id: str
    name: str
    task_type: str
    status: str = "pending"  # pending, running, completed, failed, cancelled
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress_percent: int = 0
    estimated_completion: Optional[datetime] = None
    process_id: Optional[int] = None
    config: Dict = Field(default_factory=dict)
    log_file: Optional[str] = None

class TaskStatus(BaseModel):
    """Individual task status within a workflow"""
    task_id: str
    workflow_id: str
    name: str
    status: str = "pending"
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    dependencies: List[str] = Field(default_factory=list)
    error_message: Optional[str] = None
    output_summary: Optional[str] = None

class LogEntry(BaseModel):
    """Log entry for real-time streaming"""
    workflow_id: str
    task_id: Optional[str] = None
    level: str = "INFO"
    message: str
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict = Field(default_factory=dict)

class Deliverable(BaseModel):
    """File deliverable information"""
    workflow_id: str
    task_id: Optional[str] = None
    filename: str
    file_path: str
    file_size: Optional[int] = None
    content_type: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.now)

class WebSocketMessage(BaseModel):
    """WebSocket message format"""
    event_type: str
    workflow_id: Optional[str] = None
    task_id: Optional[str] = None
    data: Dict = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)
    sequence_id: int = 0

# Global state management
class DashboardState:
    """Central state management for dashboard"""
    
    def __init__(self):
        self.workflows: Dict[str, WorkflowStatus] = {}
        self.tasks: Dict[str, TaskStatus] = {}
        self.recent_logs: List[LogEntry] = []
        self.deliverables: Dict[str, List[Deliverable]] = {}
        self.sequence_counter = 0
        self.start_time = datetime.now()
        
    def get_next_sequence_id(self) -> int:
        self.sequence_counter += 1
        return self.sequence_counter
        
    def add_workflow(self, workflow: WorkflowStatus):
        self.workflows[workflow.workflow_id] = workflow
        if workflow.workflow_id not in self.deliverables:
            self.deliverables[workflow.workflow_id] = []
            
    def update_workflow(self, workflow_id: str, **updates):
        if workflow_id in self.workflows:
            for key, value in updates.items():
                if hasattr(self.workflows[workflow_id], key):
                    setattr(self.workflows[workflow_id], key, value)
                    
    def add_log_entry(self, entry: LogEntry):
        self.recent_logs.append(entry)
        # Keep only last 1000 log entries
        if len(self.recent_logs) > 1000:
            self.recent_logs = self.recent_logs[-1000:]
            
    def get_workflow_logs(self, workflow_id: str, limit: int = 100) -> List[LogEntry]:
        workflow_logs = [log for log in self.recent_logs if log.workflow_id == workflow_id]
        return workflow_logs[-limit:]

# Global state instance
dashboard_state = DashboardState()

# WebSocket Connection Manager
class WebSocketHub:
    """Manages WebSocket connections and event broadcasting"""
    
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.subscriptions: Dict[str, Set[str]] = {}  # workflow_id -> session_ids
        self.session_workflows: Dict[str, Set[str]] = {}  # session_id -> workflow_ids
        
    async def connect(self, websocket: WebSocket, session_id: str):
        """Handle new WebSocket connection"""
        await websocket.accept()
        self.connections[session_id] = websocket
        self.session_workflows[session_id] = set()
        
        # Send connection confirmation
        await self.send_to_session(session_id, {
            "event_type": "connection_established",
            "session_id": session_id,
            "timestamp": datetime.now().isoformat()
        })
        
    async def disconnect(self, session_id: str):
        """Handle WebSocket disconnection"""
        # Remove from all subscriptions
        if session_id in self.session_workflows:
            for workflow_id in self.session_workflows[session_id]:
                if workflow_id in self.subscriptions:
                    self.subscriptions[workflow_id].discard(session_id)
                    
                    # Clean up empty subscriptions
                    if not self.subscriptions[workflow_id]:
                        del self.subscriptions[workflow_id]
        
        # Clean up session data
        self.connections.pop(session_id, None)
        self.session_workflows.pop(session_id, None)
        
    async def subscribe_to_workflow(self, session_id: str, workflow_id: str):
        """Subscribe session to workflow events"""
        if workflow_id not in self.subscriptions:
            self.subscriptions[workflow_id] = set()
        
        self.subscriptions[workflow_id].add(session_id)
        self.session_workflows[session_id].add(workflow_id)
        
        # Send current workflow state
        workflow = dashboard_state.workflows.get(workflow_id)
        if workflow:
            await self.send_to_session(session_id, {
                "event_type": "workflow_state",
                "workflow_id": workflow_id,
                "data": workflow.dict(),
                "timestamp": datetime.now().isoformat()
            })
            
    async def broadcast_to_workflow(self, workflow_id: str, message: Dict):
        """Send message to all sessions subscribed to workflow"""
        if workflow_id not in self.subscriptions:
            return
        
        message_json = json.dumps(message, default=str)
        
        # Send to all subscribed sessions
        dead_sessions = []
        for session_id in self.subscriptions[workflow_id]:
            try:
                websocket = self.connections.get(session_id)
                if websocket and websocket.client_state == WebSocketState.CONNECTED:
                    await websocket.send_text(message_json)
            except Exception as e:
                logger.warning(f"Failed to send message to session {session_id}: {e}")
                dead_sessions.append(session_id)
        
        # Clean up dead sessions
        for session_id in dead_sessions:
            await self.disconnect(session_id)
            
    async def send_to_session(self, session_id: str, message: Dict):
        """Send message to specific session"""
        websocket = self.connections.get(session_id)
        if websocket and websocket.client_state == WebSocketState.CONNECTED:
            try:
                await websocket.send_text(json.dumps(message, default=str))
            except Exception as e:
                logger.warning(f"Failed to send message to session {session_id}: {e}")
                await self.disconnect(session_id)
                
    async def broadcast_to_all(self, message: Dict):
        """Broadcast message to all connected clients"""
        message_json = json.dumps(message, default=str)
        dead_sessions = []
        
        for session_id, websocket in self.connections.items():
            try:
                if websocket.client_state == WebSocketState.CONNECTED:
                    await websocket.send_text(message_json)
            except Exception as e:
                logger.warning(f"Failed to broadcast to session {session_id}: {e}")
                dead_sessions.append(session_id)
                
        # Clean up dead sessions
        for session_id in dead_sessions:
            await self.disconnect(session_id)

# Global WebSocket hub
websocket_hub = WebSocketHub()

# Event Broadcasting System
class EventBroadcaster:
    """Handles event broadcasting to WebSocket clients"""
    
    def __init__(self):
        self.event_queue = asyncio.Queue(maxsize=settings.EVENT_QUEUE_SIZE)
        
    async def emit_workflow_event(self, workflow_id: str, event_type: str, 
                                 data: Dict, task_id: Optional[str] = None):
        """Emit workflow-related event"""
        message = {
            "event_type": event_type,
            "workflow_id": workflow_id,
            "task_id": task_id,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "sequence_id": dashboard_state.get_next_sequence_id()
        }
        
        # Queue for processing
        try:
            await self.event_queue.put(message)
        except asyncio.QueueFull:
            logger.warning("Event queue full, dropping message")
            
    async def process_events(self):
        """Background task to process event queue"""
        while True:
            try:
                message = await self.event_queue.get()
                
                # Broadcast via WebSocket
                workflow_id = message.get("workflow_id")
                if workflow_id:
                    await websocket_hub.broadcast_to_workflow(workflow_id, message)
                else:
                    await websocket_hub.broadcast_to_all(message)
                    
            except Exception as e:
                logger.error(f"Event processing error: {e}")
                continue

# Global event broadcaster
event_broadcaster = EventBroadcaster()

# FastAPI Application
app = FastAPI(
    title="Agent Orchestrator Dashboard API",
    description="Real-time monitoring dashboard for agent orchestrator workflows",
    version="1.0.0"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# REST API Endpoints

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": (datetime.now() - dashboard_state.start_time).total_seconds()
    }

@app.get("/dashboard/status")
async def get_dashboard_status():
    """Get overall dashboard status and metrics"""
    active_workflows = [w for w in dashboard_state.workflows.values() if w.status == "running"]
    completed_workflows = [w for w in dashboard_state.workflows.values() if w.status == "completed"]
    failed_workflows = [w for w in dashboard_state.workflows.values() if w.status == "failed"]
    
    return {
        "total_workflows": len(dashboard_state.workflows),
        "active_workflows": len(active_workflows),
        "completed_workflows": len(completed_workflows),
        "failed_workflows": len(failed_workflows),
        "total_tasks": len(dashboard_state.tasks),
        "websocket_connections": len(websocket_hub.connections),
        "recent_log_entries": len(dashboard_state.recent_logs),
        "uptime_seconds": (datetime.now() - dashboard_state.start_time).total_seconds(),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/workflows")
async def list_workflows(status: Optional[str] = None, limit: int = 100, offset: int = 0):
    """List all workflows with optional filtering"""
    workflows = list(dashboard_state.workflows.values())
    
    # Filter by status if provided
    if status:
        workflows = [w for w in workflows if w.status == status]
    
    # Apply pagination
    total = len(workflows)
    workflows = workflows[offset:offset + limit]
    
    return {
        "workflows": [w.dict() for w in workflows],
        "total": total,
        "limit": limit,
        "offset": offset
    }

@app.get("/workflows/{workflow_id}")
async def get_workflow(workflow_id: str):
    """Get detailed workflow information"""
    workflow = dashboard_state.workflows.get(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    # Get related tasks
    workflow_tasks = [t for t in dashboard_state.tasks.values() if t.workflow_id == workflow_id]
    
    # Get recent logs
    recent_logs = dashboard_state.get_workflow_logs(workflow_id, limit=50)
    
    # Get deliverables
    deliverables = dashboard_state.deliverables.get(workflow_id, [])
    
    return {
        "workflow": workflow.dict(),
        "tasks": [t.dict() for t in workflow_tasks],
        "recent_logs": [log.dict() for log in recent_logs],
        "deliverables": [d.dict() for d in deliverables]
    }

@app.get("/workflows/{workflow_id}/logs")
async def get_workflow_logs(workflow_id: str, limit: int = 100, level: Optional[str] = None):
    """Get logs for a specific workflow"""
    if workflow_id not in dashboard_state.workflows:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    logs = dashboard_state.get_workflow_logs(workflow_id, limit)
    
    # Filter by level if provided
    if level:
        logs = [log for log in logs if log.level == level.upper()]
    
    return {
        "logs": [log.dict() for log in logs],
        "workflow_id": workflow_id,
        "count": len(logs)
    }

@app.get("/tasks")
async def list_tasks(
    workflow_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
):
    """List all tasks with optional filtering"""
    tasks = list(dashboard_state.tasks.values())
    
    # Filter by workflow_id if provided
    if workflow_id:
        tasks = [t for t in tasks if t.workflow_id == workflow_id]
    
    # Filter by status if provided
    if status:
        tasks = [t for t in tasks if t.status == status]
    
    # Apply pagination
    total = len(tasks)
    tasks = tasks[offset:offset + limit]
    
    return {
        "tasks": [t.dict() for t in tasks],
        "total": total,
        "limit": limit,
        "offset": offset
    }

@app.get("/tasks/{task_id}")
async def get_task(task_id: str):
    """Get detailed task information"""
    task = dashboard_state.tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return task.dict()

@app.post("/workflows/{workflow_id}/subscribe")
async def subscribe_to_workflow(workflow_id: str, session_id: str):
    """Subscribe to workflow events (for REST clients)"""
    if workflow_id not in dashboard_state.workflows:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    # This endpoint is primarily for documentation
    # Actual subscription happens via WebSocket
    return {"message": f"Use WebSocket connection to subscribe to workflow {workflow_id}"}

# WebSocket Endpoint
@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """WebSocket endpoint for real-time updates"""
    await websocket_hub.connect(websocket, session_id)
    logger.info(f"WebSocket connected: {session_id}")
    
    try:
        while True:
            # Receive messages from client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types
            message_type = message.get("type", "")
            
            if message_type == "subscribe":
                # Subscribe to specific workflows
                workflow_ids = message.get("workflow_ids", [])
                for workflow_id in workflow_ids:
                    await websocket_hub.subscribe_to_workflow(session_id, workflow_id)
                    
            elif message_type == "ping":
                # Respond to ping with pong
                await websocket_hub.send_to_session(session_id, {
                    "type": "pong",
                    "timestamp": datetime.now().isoformat()
                })
                
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {session_id}")
    except Exception as e:
        logger.error(f"WebSocket error for {session_id}: {e}")
    finally:
        await websocket_hub.disconnect(session_id)

# Background Tasks
@app.on_event("startup")
async def startup_event():
    """Initialize background tasks on startup"""
    # Start event processing
    asyncio.create_task(event_broadcaster.process_events())
    
    # Start workflow monitoring
    asyncio.create_task(monitor_workflows())
    
    logger.info("Dashboard server started successfully")

async def monitor_workflows():
    """Background task to monitor workflow processes"""
    while True:
        try:
            # This would be implemented to discover and monitor
            # running orchestrator processes
            await asyncio.sleep(5)  # Check every 5 seconds
            
        except Exception as e:
            logger.error(f"Workflow monitoring error: {e}")
            await asyncio.sleep(10)  # Wait longer on error

if __name__ == "__main__":
    # Run the server
    uvicorn.run(
        "dashboard_server:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=True,
        log_level="info"
    )