#!/usr/bin/env python3
"""
Deliverable Tracker
File system watchers for tracking orchestrator workflow deliverables

Features:
- Real-time monitoring of output directories
- Automatic deliverable discovery and classification
- File metadata extraction and indexing
- Integration with dashboard state management
- Support for multiple output directory patterns
- Content type detection and preview generation
"""

import asyncio
import hashlib
import json
import logging
import mimetypes
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Callable

from watchdog.events import FileSystemEventHandler, FileCreatedEvent, FileModifiedEvent, FileDeletedEvent
from watchdog.observers import Observer

logger = logging.getLogger(__name__)

class DeliverableInfo:
    """Information about a workflow deliverable file"""
    
    def __init__(self, file_path: Path, workflow_id: str, task_id: Optional[str] = None):
        self.file_path = file_path
        self.workflow_id = workflow_id
        self.task_id = task_id
        self.filename = file_path.name
        self.created_at = datetime.now()
        self.file_size = 0
        self.content_type = None
        self.checksum = None
        self.metadata = {}
        
        # Update file information
        self._update_file_info()
        
    def _update_file_info(self):
        """Update file information from filesystem"""
        try:
            if self.file_path.exists():
                stat = self.file_path.stat()
                self.file_size = stat.st_size
                self.created_at = datetime.fromtimestamp(stat.st_mtime)
                
                # Detect content type
                self.content_type, _ = mimetypes.guess_type(str(self.file_path))
                if not self.content_type:
                    self.content_type = "application/octet-stream"
                    
                # Calculate checksum for small files
                if self.file_size < 10 * 1024 * 1024:  # 10MB limit
                    self.checksum = self._calculate_checksum()
                    
        except Exception as e:
            logger.debug(f"Error updating file info for {self.file_path}: {e}")
            
    def _calculate_checksum(self) -> Optional[str]:
        """Calculate SHA256 checksum of the file"""
        try:
            hasher = hashlib.sha256()
            with open(self.file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception as e:
            logger.debug(f"Error calculating checksum for {self.file_path}: {e}")
            return None
            
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "workflow_id": self.workflow_id,
            "task_id": self.task_id,
            "filename": self.filename,
            "file_path": str(self.file_path),
            "file_size": self.file_size,
            "content_type": self.content_type,
            "checksum": self.checksum,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata
        }
        
    def get_preview_content(self, max_size: int = 1024) -> Optional[str]:
        """Get preview content for text-based files"""
        if not self.is_text_file():
            return None
            
        try:
            with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read(max_size)
                if len(content) == max_size:
                    content += "..."
                return content
        except Exception as e:
            logger.debug(f"Error reading preview for {self.file_path}: {e}")
            return None
            
    def is_text_file(self) -> bool:
        """Check if file is a text file suitable for preview"""
        text_types = [
            'text/plain',
            'text/markdown',
            'application/json',
            'text/html',
            'text/css',
            'text/javascript',
            'application/x-python'
        ]
        
        return (self.content_type and 
                any(self.content_type.startswith(t) for t in text_types))
                
    def is_image_file(self) -> bool:
        """Check if file is an image"""
        return self.content_type and self.content_type.startswith('image/')
        
    def is_document_file(self) -> bool:
        """Check if file is a document"""
        document_types = [
            'application/pdf',
            'application/vnd.openxmlformats-officedocument',
            'application/msword',
            'text/markdown'
        ]
        
        return (self.content_type and 
                any(self.content_type.startswith(t) for t in document_types))

class DeliverableClassifier:
    """Classifies deliverables based on file patterns and content"""
    
    def __init__(self):
        self.classification_rules = {
            'documentation': {
                'patterns': [r'.*\.md$', r'.*README.*', r'.*GUIDE.*', r'.*\.rst$'],
                'directories': ['docs', 'documentation', 'guides'],
                'keywords': ['readme', 'guide', 'manual', 'doc']
            },
            'code': {
                'patterns': [r'.*\.py$', r'.*\.js$', r'.*\.ts$', r'.*\.java$', r'.*\.cpp$'],
                'directories': ['src', 'code', 'source'],
                'keywords': ['source', 'code', 'script']
            },
            'configuration': {
                'patterns': [r'.*\.json$', r'.*\.yaml$', r'.*\.yml$', r'.*\.ini$', r'.*\.conf$'],
                'directories': ['config', 'configs', 'configuration'],
                'keywords': ['config', 'settings', 'params']
            },
            'analysis': {
                'patterns': [r'.*analysis.*', r'.*report.*', r'.*summary.*'],
                'directories': ['analysis', 'reports', 'results'],
                'keywords': ['analysis', 'report', 'summary', 'result']
            },
            'logs': {
                'patterns': [r'.*\.log$', r'.*\.out$', r'.*trace.*'],
                'directories': ['logs', 'log', 'traces'],
                'keywords': ['log', 'trace', 'debug', 'output']
            },
            'data': {
                'patterns': [r'.*\.csv$', r'.*\.xlsx?$', r'.*\.db$', r'.*\.sqlite'],
                'directories': ['data', 'datasets', 'output'],
                'keywords': ['data', 'dataset', 'export']
            }
        }
        
    def classify_file(self, file_path: Path) -> List[str]:
        """Classify a file based on its path and name"""
        classifications = []
        file_str = str(file_path).lower()
        
        for category, rules in self.classification_rules.items():
            # Check patterns
            import re
            if any(re.match(pattern, file_str) for pattern in rules['patterns']):
                classifications.append(category)
                continue
                
            # Check directory names
            if any(dir_name in file_path.parts for dir_name in rules['directories']):
                classifications.append(category)
                continue
                
            # Check keywords in filename
            if any(keyword in file_path.name.lower() for keyword in rules['keywords']):
                classifications.append(category)
                
        return classifications or ['other']

class OutputDirectoryHandler(FileSystemEventHandler):
    """File system event handler for output directories"""
    
    def __init__(self, deliverable_tracker: 'DeliverableTracker'):
        self.tracker = deliverable_tracker
        
    def on_created(self, event):
        """Handle file creation events"""
        if not event.is_directory:
            asyncio.create_task(
                self.tracker._handle_file_created(Path(event.src_path))
            )
            
    def on_modified(self, event):
        """Handle file modification events"""
        if not event.is_directory:
            asyncio.create_task(
                self.tracker._handle_file_modified(Path(event.src_path))
            )
            
    def on_deleted(self, event):
        """Handle file deletion events"""
        if not event.is_directory:
            asyncio.create_task(
                self.tracker._handle_file_deleted(Path(event.src_path))
            )

class DeliverableTracker:
    """
    Main deliverable tracking service
    
    Capabilities:
    - Monitor multiple output directories for new files
    - Classify and index deliverable files
    - Extract metadata and generate previews
    - Track file changes and deletions
    - Integration with dashboard state management
    """
    
    def __init__(self, 
                 output_directories: Optional[List[Path]] = None,
                 on_deliverable_created: Optional[Callable[[DeliverableInfo], None]] = None,
                 on_deliverable_updated: Optional[Callable[[DeliverableInfo], None]] = None,
                 on_deliverable_deleted: Optional[Callable[[str], None]] = None):
        
        self.output_directories = output_directories or [
            Path("/home/opsvi/master_root/apps/agent-orchestrator/outputs"),
            Path("/home/opsvi/master_root/apps/agent-orchestrator/output"),
            Path("/home/opsvi/master_root/apps/agent-orchestrator/wbs_output")
        ]
        
        self.on_deliverable_created = on_deliverable_created
        self.on_deliverable_updated = on_deliverable_updated
        self.on_deliverable_deleted = on_deliverable_deleted
        
        # State
        self.tracked_files: Dict[str, DeliverableInfo] = {}  # file_path -> DeliverableInfo
        self.workflow_deliverables: Dict[str, List[DeliverableInfo]] = {}  # workflow_id -> deliverables
        self.observers: List[Observer] = []
        self.classifier = DeliverableClassifier()
        self.tracking = False
        
        # Ignore patterns
        self.ignore_patterns = [
            r'.*\.tmp$',
            r'.*\.temp$',
            r'.*\.lock$',
            r'.*~$',
            r'.*\.swp$',
            r'.*\.DS_Store$',
            r'.*/__pycache__/.*'
        ]
        
    async def start_tracking(self):
        """Start deliverable tracking service"""
        logger.info("Starting deliverable tracking service")
        self.tracking = True
        
        # Discover existing files
        await self._discover_existing_deliverables()
        
        # Start directory watchers
        self._start_directory_watchers()
        
        logger.info(f"Deliverable tracking started, monitoring {len(self.output_directories)} directories")
        
    async def stop_tracking(self):
        """Stop deliverable tracking service"""
        logger.info("Stopping deliverable tracking service")
        self.tracking = False
        
        # Stop directory observers
        for observer in self.observers:
            observer.stop()
            observer.join()
        self.observers.clear()
        
    def get_workflow_deliverables(self, workflow_id: str) -> List[DeliverableInfo]:
        """Get deliverables for a specific workflow"""
        return self.workflow_deliverables.get(workflow_id, [])
        
    def get_all_deliverables(self) -> List[DeliverableInfo]:
        """Get all tracked deliverables"""
        return list(self.tracked_files.values())
        
    def get_deliverable_by_path(self, file_path: str) -> Optional[DeliverableInfo]:
        """Get deliverable info by file path"""
        return self.tracked_files.get(file_path)
        
    def get_deliverables_by_type(self, content_type: str) -> List[DeliverableInfo]:
        """Get deliverables filtered by content type"""
        return [
            deliverable for deliverable in self.tracked_files.values()
            if deliverable.content_type and deliverable.content_type.startswith(content_type)
        ]
        
    def get_recent_deliverables(self, hours: int = 24) -> List[DeliverableInfo]:
        """Get deliverables created in the last N hours"""
        cutoff_time = datetime.now().timestamp() - (hours * 3600)
        
        return [
            deliverable for deliverable in self.tracked_files.values()
            if deliverable.created_at.timestamp() > cutoff_time
        ]
        
    async def _discover_existing_deliverables(self):
        """Discover existing deliverable files"""
        for output_dir in self.output_directories:
            if output_dir.exists():
                await self._scan_directory(output_dir)
                
    async def _scan_directory(self, directory: Path):
        """Scan directory for deliverable files"""
        try:
            for item in directory.rglob("*"):
                if item.is_file() and not self._should_ignore_file(item):
                    await self._process_existing_file(item)
                    # Yield control to prevent blocking
                    await asyncio.sleep(0.001)
        except Exception as e:
            logger.error(f"Error scanning directory {directory}: {e}")
            
    async def _process_existing_file(self, file_path: Path):
        """Process an existing file as a potential deliverable"""
        try:
            # Skip very old files (older than 7 days)
            if time.time() - file_path.stat().st_mtime > 7 * 24 * 3600:
                return
                
            # Derive workflow and task IDs
            workflow_id, task_id = self._derive_ids_from_path(file_path)
            
            # Create deliverable info
            deliverable = DeliverableInfo(file_path, workflow_id, task_id)
            deliverable.metadata['classifications'] = self.classifier.classify_file(file_path)
            
            # Add to tracking
            self._add_deliverable(deliverable)
            
        except Exception as e:
            logger.debug(f"Error processing existing file {file_path}: {e}")
            
    def _derive_ids_from_path(self, file_path: Path) -> tuple[str, Optional[str]]:
        """Derive workflow and task IDs from file path"""
        path_parts = file_path.parts
        
        # Look for timestamp patterns in path
        for part in path_parts:
            if re.match(r'\d{8}_\d{6}', part):
                return f"timestamped_{part}", None
                
        # Look for task type patterns
        for part in path_parts:
            lower_part = part.lower()
            if any(task_type in lower_part for task_type in ['analysis', 'documentation', 'code', 'research']):
                # Try to extract task ID from part
                task_id_match = re.search(r'task_(\w+)', lower_part)
                task_id = task_id_match.group(1) if task_id_match else None
                return f"task_{part}", task_id
                
        # Look for app name patterns
        for part in path_parts:
            if 'app_' in part.lower():
                return part, None
                
        # Fallback to directory-based ID
        if len(path_parts) > 1:
            return f"output_{path_parts[-2]}", None
        else:
            return "unknown_workflow", None
            
    def _start_directory_watchers(self):
        """Start file system watchers for output directories"""
        handler = OutputDirectoryHandler(self)
        
        for output_dir in self.output_directories:
            if output_dir.exists():
                observer = Observer()
                observer.schedule(handler, str(output_dir), recursive=True)
                observer.start()
                self.observers.append(observer)
                logger.info(f"Started watching directory: {output_dir}")
                
    def _should_ignore_file(self, file_path: Path) -> bool:
        """Check if a file should be ignored"""
        file_str = str(file_path)
        
        import re
        return any(re.match(pattern, file_str) for pattern in self.ignore_patterns)
        
    async def _handle_file_created(self, file_path: Path):
        """Handle file creation event"""
        if self._should_ignore_file(file_path):
            return
            
        try:
            # Wait a moment for file to be fully written
            await asyncio.sleep(0.5)
            
            if not file_path.exists():
                return
                
            # Derive workflow and task IDs
            workflow_id, task_id = self._derive_ids_from_path(file_path)
            
            # Create deliverable info
            deliverable = DeliverableInfo(file_path, workflow_id, task_id)
            deliverable.metadata['classifications'] = self.classifier.classify_file(file_path)
            
            # Add to tracking
            self._add_deliverable(deliverable)
            
            # Emit event
            if self.on_deliverable_created:
                self.on_deliverable_created(deliverable)
                
            logger.info(f"New deliverable created: {file_path} (workflow: {workflow_id})")
            
        except Exception as e:
            logger.error(f"Error handling file creation {file_path}: {e}")
            
    async def _handle_file_modified(self, file_path: Path):
        """Handle file modification event"""
        file_key = str(file_path)
        
        if file_key in self.tracked_files:
            try:
                # Update file information
                deliverable = self.tracked_files[file_key]
                deliverable._update_file_info()
                
                # Emit event
                if self.on_deliverable_updated:
                    self.on_deliverable_updated(deliverable)
                    
            except Exception as e:
                logger.error(f"Error handling file modification {file_path}: {e}")
                
    async def _handle_file_deleted(self, file_path: Path):
        """Handle file deletion event"""
        file_key = str(file_path)
        
        if file_key in self.tracked_files:
            try:
                deliverable = self.tracked_files[file_key]
                workflow_id = deliverable.workflow_id
                
                # Remove from tracking
                del self.tracked_files[file_key]
                
                # Remove from workflow deliverables
                if workflow_id in self.workflow_deliverables:
                    self.workflow_deliverables[workflow_id] = [
                        d for d in self.workflow_deliverables[workflow_id]
                        if str(d.file_path) != file_key
                    ]
                    
                # Emit event
                if self.on_deliverable_deleted:
                    self.on_deliverable_deleted(file_key)
                    
                logger.info(f"Deliverable deleted: {file_path}")
                
            except Exception as e:
                logger.error(f"Error handling file deletion {file_path}: {e}")
                
    def _add_deliverable(self, deliverable: DeliverableInfo):
        """Add a deliverable to tracking"""
        file_key = str(deliverable.file_path)
        
        # Add to main tracking
        self.tracked_files[file_key] = deliverable
        
        # Add to workflow deliverables
        workflow_id = deliverable.workflow_id
        if workflow_id not in self.workflow_deliverables:
            self.workflow_deliverables[workflow_id] = []
        self.workflow_deliverables[workflow_id].append(deliverable)

# Integration function for dashboard
async def create_deliverable_tracker(dashboard_state, event_broadcaster):
    """Create and configure deliverable tracker for dashboard integration"""
    
    async def on_created(deliverable: DeliverableInfo):
        """Handle deliverable creation"""
        # Add to dashboard state
        if deliverable.workflow_id not in dashboard_state.deliverables:
            dashboard_state.deliverables[deliverable.workflow_id] = []
        dashboard_state.deliverables[deliverable.workflow_id].append(deliverable.to_dict())
        
        # Emit event
        await event_broadcaster.emit_workflow_event(
            deliverable.workflow_id,
            "deliverable_created",
            deliverable.to_dict()
        )
        
    async def on_updated(deliverable: DeliverableInfo):
        """Handle deliverable update"""
        # Update in dashboard state
        if deliverable.workflow_id in dashboard_state.deliverables:
            deliverables = dashboard_state.deliverables[deliverable.workflow_id]
            for i, d in enumerate(deliverables):
                if d['file_path'] == str(deliverable.file_path):
                    deliverables[i] = deliverable.to_dict()
                    break
                    
        # Emit event
        await event_broadcaster.emit_workflow_event(
            deliverable.workflow_id,
            "deliverable_updated",
            deliverable.to_dict()
        )
        
    async def on_deleted(file_path: str):
        """Handle deliverable deletion"""
        # Remove from dashboard state
        for workflow_id, deliverables in dashboard_state.deliverables.items():
            dashboard_state.deliverables[workflow_id] = [
                d for d in deliverables if d['file_path'] != file_path
            ]
            
    # Create tracker
    tracker = DeliverableTracker(
        on_deliverable_created=on_created,
        on_deliverable_updated=on_updated,
        on_deliverable_deleted=on_deleted
    )
    
    await tracker.start_tracking()
    return tracker

if __name__ == "__main__":
    import asyncio
    
    async def main():
        def on_created(deliverable):
            print(f"Created: {deliverable.filename} ({deliverable.workflow_id})")
            
        tracker = DeliverableTracker(on_deliverable_created=on_created)
        await tracker.start_tracking()
        
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            await tracker.stop_tracking()
            
    asyncio.run(main())