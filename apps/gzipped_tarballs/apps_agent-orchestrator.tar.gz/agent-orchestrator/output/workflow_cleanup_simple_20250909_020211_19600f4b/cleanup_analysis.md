# Agent-Orchestrator Cleanup Analysis
Date: 2025-09-09

## Summary
The agent-orchestrator directory contains recent workflow outputs, test files, logs, and task definitions. All output directories are from the last 24 hours (2025-09-08 and 2025-09-09), so no archival based on age is needed yet.

## DIRECTORIES TO ARCHIVE (None - all recent)
All workflow outputs in `/output/` are from the last 24 hours. No archival needed at this time.

## FILES TO DELETE (Temporary/Obsolete)

### Old Log Files (17 files)
```
orchestrator_20250908_121637.log
orchestrator_20250908_121932.log
orchestrator_20250908_122028.log
orchestrator_20250908_125406.log
orchestrator_20250908_130457.log
orchestrator_20250908_130547.log
orchestrator_20250908_133238.log
orchestrator_20250908_133244.log
orchestrator_20250908_133251.log
orchestrator_20250908_140458.log
orchestrator_20250908_145849.log
orchestrator_20250908_214056.log
orchestrator_20250908_214305.log
orchestrator_20250909_004256.log
orchestrator_20250909_004306.log
orchestrator_20250909_004704.log
mcp-shell.log
```

### Temporary/Experimental Files
```
temp_orchestrator_output_spec.md
test_report.html
```

### Broken/Original Files
```
system_analysis_tasks.broken.json
system_analysis_tasks.json.original
```

## FILES TO REORGANIZE

### Test Files → /tests/ directory (19 files)
Move all test files to appropriate subdirectories in `/tests/`:

**Unit Tests → /tests/unit/**
```
test_claude_sessions.py
test_task_organization.py
test_enhanced_task_validation.py
test_context_injection.py
test_intelligence_review_engine.py
test_dpo_integration.py
test_dpo_main_controller.py
test_dpo_simple.py
test_demo_system.py
test_session_analytics.py
test_multi_provider.py
```

**Performance Tests → /tests/performance/**
```
continuous_metrics_test.py
realistic_load_test.py
websocket_load_test.py
log_streaming_test.py
ui_performance_test.py
final_dashboard_test.py
stress_test_websockets.py
load_test_metrics_feeder.py
```

### Demo Files → /demos/ directory (create new)
```
comprehensive_demo.py
demo_monitoring.py
simple_chat_demo.py
demo_task_examples.json
simple_demo_workflow.json
openai_demo_workflow.json
DEMO_INDEX.md
DEMO_README.md
DEMO_SUMMARY.md
```

### Task Definition Files → /task_definitions/ directory (create new)
```
apps_audit_tasks.json
chat_interface.py
chat_log_analysis_task.json
chat_parsing_analysis_task.json
chat_parsing_architecture_documentation_task.json
cleanup_simple.json
create_documentation_workflow_task.json
current_session_analysis.json
dashboard_specs_task.json
directory_cleanup_sonnet.json
directory_cleanup_tasks.json
dpo_comprehensive_documentation_task.json
dpo_final_tasks.json
dpo_implementation_request.json
dpo_resume_tasks.json
example_enhanced_task.json
gpt5_payload_generation_task.json
gpt5_payload_system_tasks.json
large_session_analysis.json
largest_session_analysis.json
orchestrator_analysis_tasks.json
orchestrator_dashboard_build_tasks.json
orchestrator_self_fix_tasks.json
parallel_doc_update_tasks.json
phase1_documentation_task.json
session_optimization_phase1_5_tasks.json
session_optimization_phase1_5b_tasks.json
session_optimization_phase1_tasks.json
small_session_analysis.json
system_analysis_tasks.json
test_adaptive_chunks.json
test_comprehensive_workflow.json
test_conversation_chunks.json
test_directory_fix.json
test_payload.json
test_sample_session.json
test_tool_usage_chunks.json
validation_suite.json
```

### Run Scripts → /scripts/ directory (create new)
```
run_all_demos.py
run_apps_audit.py
run_directory_cleanup.py
run_dpo_build.py
run_orchestrator_analysis.py
run_orchestrator_task.py
run_parallel_doc_update.py
run_system_analysis.py
run_with_live_chat.py
```

### Deployment/Config Files (Keep in root)
```
.env.production
.gitignore
Dockerfile
docker-compose.yml
requirements.txt
setup.py
production_config.json
dashboard.service
dashboard_startup.sh
logging_config.json
policy.autotune.json
master_mcp_registry.json
```

## PRESERVED FILES (Important/Active)

### Core Application Files
```
main.py
orchestrator_api.py
orchestrator_with_dashboard.py
production_dashboard.py
resume_orchestrator.py
simple_resume.py
run.py
__init__.py
```

### DPO System Files
```
dpo_cli.py
```

### Documentation (in /docs/)
All files in `/docs/` directory are preserved

### Output Directory
All workflow outputs in `/output/` are preserved (all recent)

### Source Code (in /src/)
All files in `/src/` directory are preserved

### Tests (in /tests/)
Existing test structure is preserved

## RECOMMENDATIONS

1. **Immediate Actions:**
   - Delete old log files (17 files)
   - Delete temporary/broken files (4 files)
   - Total space to be freed: ~500KB

2. **Organization Actions:**
   - Create `/demos/` directory for demo files
   - Create `/task_definitions/` directory for task JSON files
   - Create `/scripts/` directory for run scripts
   - Move test files to appropriate `/tests/` subdirectories

3. **Future Maintenance:**
   - Set up automated cleanup for:
     - Log files older than 7 days
     - Output directories older than 30 days
   - Consider implementing log rotation

4. **Conservative Approach:**
   - All core functionality preserved
   - No deletion of any potentially important code or config
   - Only removing clearly temporary/obsolete files