# Testing Instructions

This document provides comprehensive testing procedures for the factorial calculator, including manual testing, automated testing approaches, and validation methods.

## Quick Start Testing

### 1. Basic Functionality Test
```bash
# Run the built-in demonstration
python factorial_calculator.py
```

**Expected Output:**
```
Factorial Calculator
--------------------
1! = 1
2! = 2
3! = 6
4! = 24
5! = 120

Error handling examples:
Error calculating -1!: Factorial is not defined for negative numbers
Error calculating 0.5!: Input must be an integer
Error calculating abc!: Input must be an integer
```

### 2. Interactive Testing
```bash
python3 -i factorial_calculator.py
```

Then test individual function calls:
```python
>>> factorial(5)
120
>>> factorial(0)
1
>>> factorial(-1)  # Should raise ValueError
```

## Comprehensive Test Cases

### Valid Input Tests

| Input | Expected Output | Mathematical Verification |
|-------|----------------|--------------------------|
| `0` | `1` | 0! = 1 (by definition) |
| `1` | `1` | 1! = 1 |
| `2` | `2` | 2! = 2×1 = 2 |
| `3` | `6` | 3! = 3×2×1 = 6 |
| `4` | `24` | 4! = 4×3×2×1 = 24 |
| `5` | `120` | 5! = 5×4×3×2×1 = 120 |
| `10` | `3628800` | 10! = 3,628,800 |

### Error Handling Tests

| Input | Expected Exception | Expected Message |
|-------|-------------------|------------------|
| `-1` | `ValueError` | "Factorial is not defined for negative numbers" |
| `-5` | `ValueError` | "Factorial is not defined for negative numbers" |
| `3.14` | `TypeError` | "Input must be an integer" |
| `"5"` | `TypeError` | "Input must be an integer" |
| `[5]` | `TypeError` | "Input must be an integer" |
| `None` | `TypeError` | "Input must be an integer" |

## Manual Testing Procedures

### Test Script 1: Valid Inputs
Create and run this test:

```python
# test_valid_inputs.py
from factorial_calculator import factorial

test_cases = [
    (0, 1),
    (1, 1),
    (2, 2),
    (3, 6),
    (4, 24),
    (5, 120),
    (6, 720),
    (7, 5040),
    (10, 3628800)
]

print("Testing valid inputs:")
for input_val, expected in test_cases:
    result = factorial(input_val)
    status = "PASS" if result == expected else "FAIL"
    print(f"{input_val}! = {result} (expected {expected}) - {status}")
```

### Test Script 2: Error Handling
```python
# test_error_handling.py
from factorial_calculator import factorial

error_test_cases = [
    (-1, ValueError),
    (-5, ValueError),
    (3.5, TypeError),
    ("hello", TypeError),
    ([1, 2, 3], TypeError),
    (None, TypeError),
]

print("Testing error handling:")
for input_val, expected_exception in error_test_cases:
    try:
        result = factorial(input_val)
        print(f"{input_val} - FAIL: Should have raised {expected_exception.__name__}")
    except expected_exception as e:
        print(f"{input_val} - PASS: Correctly raised {type(e).__name__}: {e}")
    except Exception as e:
        print(f"{input_val} - FAIL: Wrong exception type {type(e).__name__}: {e}")
```

## Automated Testing with unittest

Create a comprehensive test suite:

```python
# test_factorial_calculator.py
import unittest
from factorial_calculator import factorial

class TestFactorialCalculator(unittest.TestCase):
    
    def test_valid_small_numbers(self):
        """Test factorial calculation for small valid numbers"""
        test_cases = [
            (0, 1),
            (1, 1),
            (2, 2),
            (3, 6),
            (4, 24),
            (5, 120)
        ]
        
        for input_val, expected in test_cases:
            with self.subTest(input_val=input_val):
                self.assertEqual(factorial(input_val), expected)
    
    def test_larger_numbers(self):
        """Test factorial calculation for larger numbers"""
        self.assertEqual(factorial(10), 3628800)
        self.assertEqual(factorial(12), 479001600)
    
    def test_negative_numbers_raise_value_error(self):
        """Test that negative numbers raise ValueError"""
        with self.assertRaises(ValueError) as context:
            factorial(-1)
        self.assertIn("negative numbers", str(context.exception))
        
        with self.assertRaises(ValueError):
            factorial(-10)
    
    def test_non_integer_types_raise_type_error(self):
        """Test that non-integer inputs raise TypeError"""
        invalid_inputs = [3.14, "5", [1, 2, 3], None, {"n": 5}]
        
        for invalid_input in invalid_inputs:
            with self.subTest(input_val=invalid_input):
                with self.assertRaises(TypeError) as context:
                    factorial(invalid_input)
                self.assertIn("integer", str(context.exception))

if __name__ == '__main__':
    unittest.main()
```

### Running the unittest
```bash
python test_factorial_calculator.py
```

**Expected Output:**
```
....
----------------------------------------------------------------------
Ran 4 tests in 0.001s

OK
```

## Performance Testing

### Test Script 3: Performance Validation
```python
# test_performance.py
import time
from factorial_calculator import factorial

def time_factorial(n, iterations=1000):
    """Time the factorial function"""
    start_time = time.time()
    for _ in range(iterations):
        factorial(n)
    end_time = time.time()
    
    avg_time = (end_time - start_time) / iterations
    return avg_time

print("Performance testing:")
test_values = [5, 10, 20, 50, 100]

for n in test_values:
    avg_time = time_factorial(n, 100)
    print(f"factorial({n}): {avg_time:.6f} seconds average")
```

## Memory Testing

### Test Script 4: Memory Usage
```python
# test_memory.py
import tracemalloc
from factorial_calculator import factorial

def test_memory_usage(n):
    """Test memory usage of factorial calculation"""
    tracemalloc.start()
    
    result = factorial(n)
    
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    return current, peak, result

print("Memory usage testing:")
for n in [10, 50, 100]:
    current, peak, result = test_memory_usage(n)
    print(f"factorial({n}) = {result}")
    print(f"  Memory: current={current/1024:.1f} KB, peak={peak/1024:.1f} KB")
```

## Integration Testing

### Test Script 5: Integration with Other Functions
```python
# test_integration.py
from factorial_calculator import factorial

def combination(n, r):
    """Calculate nCr using factorial function"""
    return factorial(n) // (factorial(r) * factorial(n - r))

def permutation(n, r):
    """Calculate nPr using factorial function"""
    return factorial(n) // factorial(n - r)

# Test mathematical relationships
print("Integration testing:")
print(f"C(5,2) = {combination(5, 2)}")  # Should be 10
print(f"P(5,2) = {permutation(5, 2)}")  # Should be 20
print(f"5! / 4! = {factorial(5) // factorial(4)}")  # Should be 5
```

## Continuous Integration Testing

For automated CI/CD environments, create a test runner:

```bash
#!/bin/bash
# run_tests.sh

echo "Running factorial calculator tests..."

# Run the main program to check basic functionality
echo "1. Basic functionality test:"
python factorial_calculator.py

# Run unit tests
echo -e "\n2. Unit tests:"
python -m unittest test_factorial_calculator.py -v

# Run performance tests
echo -e "\n3. Performance tests:"
python test_performance.py

echo -e "\nAll tests completed!"
```

Make executable and run:
```bash
chmod +x run_tests.sh
./run_tests.sh
```

## Test Coverage Analysis

To measure test coverage (requires `coverage` package):

```bash
# Install coverage tool
pip install coverage

# Run tests with coverage
coverage run test_factorial_calculator.py

# Generate coverage report
coverage report -m

# Generate HTML coverage report
coverage html
```

## Validation Checklist

### Pre-Release Testing Checklist

- [ ] All valid inputs (0-10) produce correct results
- [ ] Negative inputs raise `ValueError` with appropriate message
- [ ] Non-integer inputs raise `TypeError` with appropriate message
- [ ] Performance is acceptable for reasonable inputs (n < 1000)
- [ ] Memory usage is constant (O(1) space complexity)
- [ ] Function works correctly when imported as module
- [ ] Demo script runs without errors
- [ ] All error messages are clear and helpful

### Regression Testing

When making changes to the code:

1. Run all existing test suites
2. Verify output hasn't changed for known inputs
3. Ensure error messages remain consistent
4. Check that performance hasn't degraded
5. Validate that the API contract remains the same

## Troubleshooting Test Issues

### Common Test Failures

**Issue**: `ImportError: No module named 'factorial_calculator'`
**Solution**: Ensure `factorial_calculator.py` is in the same directory as test files

**Issue**: Tests pass individually but fail when run together
**Solution**: Check for shared state or side effects between tests

**Issue**: Performance tests give inconsistent results
**Solution**: Run multiple iterations and average results; consider system load

### Debug Mode Testing

Enable debug output by modifying the factorial function temporarily:

```python
def factorial(n, debug=False):
    """Calculate factorial with optional debug output"""
    if debug:
        print(f"Computing factorial of {n}")
    
    # ... rest of function with debug prints ...
    
    if debug:
        print(f"Result: {result}")
    return result
```

This helps verify the algorithm steps for complex debugging scenarios.