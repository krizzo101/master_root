# Changelog

All notable changes to the Factorial Calculator project will be documented in this file.

## [1.0.0] - 2025-09-08

### Added
- Initial release of factorial calculator
- Core factorial function with iterative implementation
- Input validation for type checking (integers only)
- Error handling for negative numbers
- Support for edge cases (0! = 1, 1! = 1)
- Comprehensive error handling with descriptive messages
- Test suite demonstrating calculations for numbers 1-5
- Error handling demonstration with invalid inputs

### Features
- **Type Safety**: Validates input is an integer before calculation
- **Range Validation**: Prevents calculation of factorial for negative numbers
- **Edge Case Handling**: Correctly handles 0! and 1! = 1
- **Error Messaging**: Clear error messages for invalid inputs
- **Test Coverage**: Built-in testing for valid and invalid inputs

### Technical Details
- Implementation: Iterative approach for efficiency
- Language: Python 3
- Error Types: TypeError for non-integers, ValueError for negative numbers
- Time Complexity: O(n)
- Space Complexity: O(1)

## Future Improvements

### Planned for v1.1.0
- Add command-line argument support for custom input
- Implement recursive factorial option
- Add performance benchmarking
- Support for large number calculations

### Planned for v1.2.0
- Add factorial approximation using Stirling's formula
- Implement caching/memoization for repeated calculations
- Add unit test framework integration
- Export results to file functionality

### Planned for v2.0.0
- GUI interface using tkinter or similar
- Support for factorial of complex numbers
- Multi-language support
- REST API endpoint for factorial calculations