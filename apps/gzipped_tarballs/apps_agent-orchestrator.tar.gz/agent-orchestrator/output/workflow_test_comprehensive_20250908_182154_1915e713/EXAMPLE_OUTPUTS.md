# Example Outputs

This document shows the actual output when running the factorial calculator, demonstrating both successful calculations and error handling scenarios.

## Running the Script

Execute the script with:
```bash
python factorial_calculator.py
```

## Complete Output

```
Factorial Calculator
--------------------
1! = 1
2! = 2
3! = 6
4! = 24
5! = 120

Error handling examples:
Error calculating -1!: Factorial is not defined for negative numbers
Error calculating 0.5!: Input must be an integer
Error calculating abc!: Input must be an integer
```

## Output Analysis

### Successful Calculations Section

```
1! = 1
2! = 2
3! = 6
4! = 24
5! = 120
```

- **1!**: Base case, factorial of 1 equals 1
- **2!**: 2 × 1 = 2
- **3!**: 3 × 2 × 1 = 6
- **4!**: 4 × 3 × 2 × 1 = 24
- **5!**: 5 × 4 × 3 × 2 × 1 = 120

### Error Handling Section

```
Error calculating -1!: Factorial is not defined for negative numbers
Error calculating 0.5!: Input must be an integer
Error calculating abc!: Input must be an integer
```

#### Error Case 1: Negative Number
- **Input**: `-1`
- **Error Type**: `ValueError`
- **Message**: "Factorial is not defined for negative numbers"
- **Reason**: Mathematical constraint - factorial is undefined for negative integers

#### Error Case 2: Float Input
- **Input**: `0.5`
- **Error Type**: `TypeError`
- **Message**: "Input must be an integer"
- **Reason**: Function expects integer input, not floating-point numbers

#### Error Case 3: String Input
- **Input**: `"abc"`
- **Error Type**: `TypeError`
- **Message**: "Input must be an integer"
- **Reason**: Function expects numeric input, not string data

## Interactive Usage Examples

### Successful Function Calls

```python
>>> from factorial_calculator import factorial
>>> factorial(0)
1
>>> factorial(1)
1
>>> factorial(3)
6
>>> factorial(7)
5040
>>> factorial(10)
3628800
```

### Error Handling in Interactive Mode

```python
>>> factorial(-5)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "factorial_calculator.py", line 7, in factorial
    raise ValueError("Factorial is not defined for negative numbers")
ValueError: Factorial is not defined for negative numbers

>>> factorial(2.5)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "factorial_calculator.py", line 4, in factorial
    raise TypeError("Input must be an integer")
TypeError: Input must be an integer

>>> factorial("hello")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "factorial_calculator.py", line 4, in factorial
    raise TypeError("Input must be an integer")
TypeError: Input must be an integer
```

## Additional Test Cases

### Large Numbers
```python
>>> factorial(12)
479001600
>>> factorial(15)
1307674368000
```

### Edge Cases
```python
>>> factorial(0)  # Mathematical convention: 0! = 1
1
>>> factorial(1)  # Base case: 1! = 1
1
```

## Performance Characteristics

For reference, here are some timing characteristics:

- **Small numbers (n < 10)**: Nearly instantaneous
- **Medium numbers (n = 50)**: Still very fast due to O(n) complexity
- **Large numbers (n = 100+)**: Limited by integer size and multiplication cost

Note: Python handles arbitrarily large integers, so the main limitation is computational time for very large factorials.

## Usage in Code

### Basic Integration
```python
from factorial_calculator import factorial

def calculate_combinations(n, r):
    """Calculate nCr = n! / (r! * (n-r)!)"""
    return factorial(n) // (factorial(r) * factorial(n - r))

# Example usage
combinations = calculate_combinations(10, 3)  # Result: 120
```

### Error Handling Integration
```python
def safe_factorial(n):
    """Wrapper with additional validation and user-friendly messages"""
    try:
        return factorial(n)
    except TypeError:
        return f"Error: Please provide an integer, not {type(n).__name__}"
    except ValueError:
        return f"Error: Factorial is not defined for negative numbers ({n})"

# Usage examples
print(safe_factorial(5))     # Output: 120
print(safe_factorial(-3))    # Output: Error: Factorial is not defined for negative numbers (-3)
print(safe_factorial(2.5))   # Output: Error: Please provide an integer, not float
```