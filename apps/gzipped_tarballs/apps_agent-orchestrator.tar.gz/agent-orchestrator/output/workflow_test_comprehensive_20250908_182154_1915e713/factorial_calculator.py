def factorial(n):
    """Calculate the factorial of a non-negative integer."""
    if not isinstance(n, int):
        raise TypeError("Input must be an integer")
    
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    
    if n == 0 or n == 1:
        return 1
    
    result = 1
    for i in range(2, n + 1):
        result *= i
    
    return result


def main():
    """Test the factorial function with numbers 1-5."""
    print("Factorial Calculator")
    print("-" * 20)
    
    for num in range(1, 6):
        try:
            result = factorial(num)
            print(f"{num}! = {result}")
        except (TypeError, ValueError) as e:
            print(f"Error calculating {num}!: {e}")
    
    # Additional error handling demonstration
    print("\nError handling examples:")
    test_cases = [-1, 0.5, "abc"]
    
    for test in test_cases:
        try:
            result = factorial(test)
            print(f"{test}! = {result}")
        except (TypeError, ValueError) as e:
            print(f"Error calculating {test}!: {e}")


if __name__ == "__main__":
    main()