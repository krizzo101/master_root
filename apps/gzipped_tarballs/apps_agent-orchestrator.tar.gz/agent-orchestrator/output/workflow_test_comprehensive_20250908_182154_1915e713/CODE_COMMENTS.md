# Code Comments and Implementation Details

This document provides a detailed explanation of the factorial calculator implementation, breaking down each section of code with comprehensive comments.

## Function: `factorial(n)`

### Line-by-Line Breakdown

#### Function Definition and Docstring
```python
def factorial(n):
    """Calculate the factorial of a non-negative integer."""
```
- **Line 1-2**: Function signature with descriptive docstring
- **Purpose**: Clear documentation of function intent
- **Best Practice**: Docstring follows PEP 257 conventions

#### Input Type Validation
```python
if not isinstance(n, int):
    raise TypeError("Input must be an integer")
```
- **Lines 3-4**: Type checking using `isinstance()`
- **Purpose**: Ensures input is an integer, not float, string, or other type
- **Error Handling**: Raises `TypeError` with descriptive message
- **Why This Matters**: Prevents unexpected behavior with non-integer inputs like `factorial(5.0)`

#### Input Range Validation
```python
if n < 0:
    raise ValueError("Factorial is not defined for negative numbers")
```
- **Lines 6-7**: Mathematical constraint enforcement
- **Purpose**: Factorial is mathematically undefined for negative integers
- **Error Handling**: Raises `ValueError` (different from `TypeError`) to distinguish between type and value errors
- **Mathematical Accuracy**: Maintains mathematical correctness of the factorial function

#### Base Case Handling
```python
if n == 0 or n == 1:
    return 1
```
- **Lines 9-10**: Special cases for 0! and 1!
- **Mathematical Basis**: 
  - `0! = 1` by mathematical convention
  - `1! = 1` by definition
- **Efficiency**: Early return avoids unnecessary computation
- **Algorithm Correctness**: Handles edge cases that would otherwise require special logic

#### Iterative Calculation
```python
result = 1
for i in range(2, n + 1):
    result *= i

return result
```
- **Line 12**: Initialize accumulator variable to 1 (multiplicative identity)
- **Line 13**: Loop from 2 to n (inclusive) using `range(2, n + 1)`
  - **Why start at 2**: We already handled 0! and 1! cases
  - **Why n + 1**: `range()` is exclusive of the end value
- **Line 14**: Multiply accumulator by each number in sequence
  - **In-place multiplication** (`*=`) for efficiency
- **Line 16**: Return the final computed result

### Algorithm Analysis

**Time Complexity**: O(n)
- Single loop that runs (n-1) times for input n
- Each iteration performs constant-time multiplication

**Space Complexity**: O(1)
- Uses only a fixed amount of extra space regardless of input size
- No recursive calls or dynamic data structures

**Alternative Approaches Not Used**:
- **Recursive**: Would use O(n) stack space
- **Built-in math.factorial()**: Less educational, no custom validation
- **Lookup table**: Would limit range and use more memory

## Function: `main()`

### Demonstration Logic

#### Test Loop for Valid Cases
```python
for num in range(1, 6):
    try:
        result = factorial(num)
        print(f"{num}! = {result}")
    except (TypeError, ValueError) as e:
        print(f"Error calculating {num}!: {e}")
```
- **Purpose**: Demonstrates normal operation with known-good inputs
- **Range Choice**: 1-5 provides meaningful examples without excessive output
- **Exception Handling**: Even in "safe" cases, proper error handling is demonstrated
- **F-string Usage**: Modern Python string formatting for clean output

#### Error Handling Demonstration
```python
test_cases = [-1, 0.5, "abc"]

for test in test_cases:
    try:
        result = factorial(test)
        print(f"{test}! = {result}")
    except (TypeError, ValueError) as e:
        print(f"Error calculating {test}!: {e}")
```
- **Test Case Selection**:
  - `-1`: Negative integer (ValueError)
  - `0.5`: Float (TypeError) 
  - `"abc"`: String (TypeError)
- **Educational Value**: Shows how different invalid inputs are handled
- **Exception Catching**: Catches both exception types that `factorial()` can raise

### Design Patterns Used

#### Guard Clauses
- Early validation and return for edge cases
- Reduces nesting and improves readability
- Fails fast with clear error messages

#### Exception-Based Error Handling
- Uses Python's exception system rather than returning error codes
- Distinguishes between different types of errors (Type vs Value)
- Provides descriptive error messages for debugging

#### Separation of Concerns
- `factorial()`: Pure mathematical calculation
- `main()`: User interface and demonstration
- Clear separation makes code more maintainable and testable

## Best Practices Demonstrated

1. **Input Validation**: Check both type and value constraints
2. **Clear Error Messages**: Help users understand what went wrong
3. **Mathematical Correctness**: Handle edge cases properly (0! = 1)
4. **Efficient Algorithm**: Iterative approach with O(1) space complexity
5. **Comprehensive Testing**: Demo shows both success and failure cases
6. **Code Documentation**: Docstrings and meaningful variable names
7. **Exception Specificity**: Different exception types for different error conditions