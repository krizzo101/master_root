import unittest
import math


def factorial(n):
    """Calculate factorial of n."""
    if not isinstance(n, int):
        raise TypeError("Input must be an integer")
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)


class TestFactorial(unittest.TestCase):
    
    def test_valid_positive_integers(self):
        """Test factorial with valid positive integers."""
        self.assertEqual(factorial(5), 120)
        self.assertEqual(factorial(3), 6)
        self.assertEqual(factorial(4), 24)
        self.assertEqual(factorial(6), 720)
    
    def test_edge_cases(self):
        """Test factorial with edge cases (0 and 1)."""
        self.assertEqual(factorial(0), 1)
        self.assertEqual(factorial(1), 1)
    
    def test_error_handling_negative_numbers(self):
        """Test error handling for negative numbers."""
        with self.assertRaises(ValueError):
            factorial(-1)
        with self.assertRaises(ValueError):
            factorial(-5)
        with self.assertRaises(ValueError):
            factorial(-10)
    
    def test_type_error_handling(self):
        """Test error handling for non-integer inputs."""
        with self.assertRaises(TypeError):
            factorial(5.5)
        with self.assertRaises(TypeError):
            factorial("5")
        with self.assertRaises(TypeError):
            factorial(None)


if __name__ == '__main__':
    unittest.main()