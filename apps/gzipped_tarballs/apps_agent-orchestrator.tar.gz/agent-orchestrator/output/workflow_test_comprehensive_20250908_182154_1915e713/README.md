# Factorial Calculator

A simple, robust Python implementation for calculating factorials of non-negative integers with comprehensive error handling.

## Overview

The factorial of a non-negative integer `n` is the product of all positive integers less than or equal to `n`. It is denoted as `n!` and defined as:

- `0! = 1` (by definition)
- `n! = n × (n-1) × (n-2) × ... × 2 × 1` for `n > 0`

## Features

- **Input Validation**: Ensures input is a non-negative integer
- **Error Handling**: Provides clear error messages for invalid inputs
- **Type Safety**: Checks for proper data types
- **Iterative Implementation**: Efficient O(n) time complexity
- **Demonstration Mode**: Includes test cases showing both valid calculations and error handling

## Usage

### Basic Usage

```python
from factorial_calculator import factorial

# Calculate factorial of 5
result = factorial(5)
print(result)  # Output: 120
```

### Running the Script

Execute the script directly to see demonstrations:

```bash
python factorial_calculator.py
```

This will display:
- Factorial calculations for numbers 1-5
- Error handling examples with invalid inputs

### Function Signature

```python
def factorial(n: int) -> int
```

**Parameters:**
- `n`: A non-negative integer

**Returns:**
- The factorial of `n` as an integer

**Raises:**
- `TypeError`: If input is not an integer
- `ValueError`: If input is negative

## Installation

No external dependencies required. Simply ensure you have Python 3.6+ installed.

## Examples

### Valid Inputs

```python
factorial(0)   # Returns: 1
factorial(1)   # Returns: 1
factorial(5)   # Returns: 120
factorial(10)  # Returns: 3628800
```

### Error Cases

```python
factorial(-1)    # Raises: ValueError
factorial(3.5)   # Raises: TypeError  
factorial("5")   # Raises: TypeError
```

## Algorithm

The implementation uses an iterative approach:

1. **Input validation**: Check type and sign
2. **Base cases**: Handle 0! and 1! directly
3. **Iterative calculation**: Multiply numbers from 2 to n

**Time Complexity**: O(n)
**Space Complexity**: O(1)

## Testing

The script includes built-in test cases that demonstrate:
- Normal factorial calculations (1! through 5!)
- Error handling for negative numbers, floats, and strings
- Edge cases (0! = 1)

Run tests by executing the script:

```bash
python factorial_calculator.py
```

## Code Structure

- `factorial(n)`: Main function that calculates factorial
- `main()`: Demonstration function with test cases
- Input validation with appropriate exception raising
- Clear error messages for debugging

## Mathematical Properties

- `0! = 1` (mathematical convention)
- `n! = n × (n-1)!` (recursive definition)
- Factorial grows very rapidly: 10! = 3,628,800

## License

This is a simple educational implementation - feel free to use and modify as needed.