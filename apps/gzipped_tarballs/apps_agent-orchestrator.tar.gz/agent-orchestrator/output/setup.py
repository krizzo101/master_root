#!/usr/bin/env python3
"""
Setup script for Agent Orchestrator Dashboard Backend

Usage:
    python setup.py install    # Install dependencies and setup
    python setup.py test       # Run tests
    python setup.py dev        # Setup development environment
"""

import asyncio
import os
import subprocess
import sys
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"Running: {description}")
    print(f"Command: {command}")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✓ {description} completed successfully")
        if result.stdout:
            print(f"Output: {result.stdout}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ {description} failed")
        print(f"Error: {e.stderr}")
        return False

def install_dependencies():
    """Install required dependencies"""
    requirements_file = Path(__file__).parent / "requirements.txt"
    
    if not requirements_file.exists():
        print("requirements.txt not found")
        return False
        
    return run_command(
        f"pip install -r {requirements_file}",
        "Installing dependencies"
    )

def setup_directories():
    """Create necessary directories"""
    directories = [
        "logs",
        "static",
        "templates",
        "tests",
        "config"
    ]
    
    base_dir = Path(__file__).parent
    
    for directory in directories:
        dir_path = base_dir / directory
        dir_path.mkdir(exist_ok=True)
        print(f"✓ Created directory: {directory}")
    
    return True

def create_config_files():
    """Create default configuration files"""
    base_dir = Path(__file__).parent
    
    # Create .env file if it doesn't exist
    env_file = base_dir / ".env"
    if not env_file.exists():
        env_content = """# Agent Orchestrator Dashboard Configuration

# Server settings
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=8888

# Orchestrator settings
ORCHESTRATOR_BASE_DIR=/home/opsvi/master_root/apps/agent-orchestrator

# Monitoring settings
LOG_LEVEL=INFO
MAX_LOG_ENTRIES=1000
FILE_WATCH_RECURSIVE=true

# WebSocket settings
WEBSOCKET_MAX_CONNECTIONS=100
EVENT_QUEUE_SIZE=10000

# Development settings
DEBUG=false
RELOAD=false
"""
        with open(env_file, 'w') as f:
            f.write(env_content)
        print("✓ Created .env configuration file")
    
    # Create logging configuration
    log_config = base_dir / "config" / "logging.json"
    if not log_config.exists():
        log_config_content = """{
  "version": 1,
  "disable_existing_loggers": false,
  "formatters": {
    "standard": {
      "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    },
    "detailed": {
      "format": "%(asctime)s - %(name)s - %(levelname)s - %(module)s - %(funcName)s - %(lineno)d - %(message)s"
    }
  },
  "handlers": {
    "console": {
      "class": "logging.StreamHandler",
      "level": "INFO",
      "formatter": "standard",
      "stream": "ext://sys.stdout"
    },
    "file": {
      "class": "logging.handlers.RotatingFileHandler",
      "level": "DEBUG",
      "formatter": "detailed",
      "filename": "logs/dashboard.log",
      "maxBytes": 10485760,
      "backupCount": 5
    }
  },
  "loggers": {
    "": {
      "level": "INFO",
      "handlers": ["console", "file"],
      "propagate": false
    },
    "uvicorn": {
      "level": "INFO",
      "handlers": ["console", "file"],
      "propagate": false
    },
    "fastapi": {
      "level": "INFO", 
      "handlers": ["console", "file"],
      "propagate": false
    }
  }
}"""
        with open(log_config, 'w') as f:
            f.write(log_config_content)
        print("✓ Created logging configuration")
    
    return True

def create_systemd_service():
    """Create systemd service file"""
    base_dir = Path(__file__).parent
    service_file = base_dir / "orchestrator-dashboard.service"
    
    service_content = f"""[Unit]
Description=Agent Orchestrator Dashboard
After=network.target

[Service]
Type=simple
User=opsvi
Group=opsvi
WorkingDirectory={base_dir}
Environment=PATH={sys.executable}
ExecStart={sys.executable} main_dashboard.py --host 0.0.0.0 --port 8888
Restart=always
RestartSec=10

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths={base_dir}

[Install]
WantedBy=multi-user.target
"""
    
    with open(service_file, 'w') as f:
        f.write(service_content)
    print("✓ Created systemd service file")
    print(f"  To install: sudo cp {service_file} /etc/systemd/system/")
    print("  To enable: sudo systemctl enable orchestrator-dashboard")
    print("  To start: sudo systemctl start orchestrator-dashboard")
    
    return True

def run_tests():
    """Run test suite"""
    test_files = list(Path(__file__).parent.glob("test_*.py"))
    
    if not test_files:
        print("No test files found (test_*.py)")
        return True
        
    return run_command(
        "python -m pytest tests/ -v",
        "Running test suite"
    )

def setup_development():
    """Setup development environment"""
    dev_packages = [
        "black",           # Code formatter
        "isort",           # Import sorter
        "flake8",          # Linting
        "mypy",            # Type checking
        "pre-commit",      # Git hooks
    ]
    
    for package in dev_packages:
        if not run_command(f"pip install {package}", f"Installing {package}"):
            return False
            
    # Setup pre-commit hooks
    pre_commit_config = Path(__file__).parent / ".pre-commit-config.yaml"
    if not pre_commit_config.exists():
        config_content = """repos:
  - repo: https://github.com/psf/black
    rev: 23.12.1
    hooks:
      - id: black
        language_version: python3.9

  - repo: https://github.com/pycqa/isort
    rev: 5.13.2
    hooks:
      - id: isort

  - repo: https://github.com/pycqa/flake8
    rev: 7.0.0
    hooks:
      - id: flake8
        args: [--max-line-length=88, --extend-ignore=E203]

  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.8.0
    hooks:
      - id: mypy
        additional_dependencies: [types-all]
"""
        with open(pre_commit_config, 'w') as f:
            f.write(config_content)
            
    return run_command("pre-commit install", "Setting up pre-commit hooks")

def main():
    """Main setup function"""
    if len(sys.argv) < 2:
        print("Usage: python setup.py [install|test|dev|service]")
        sys.exit(1)
        
    command = sys.argv[1]
    
    if command == "install":
        print("🚀 Setting up Agent Orchestrator Dashboard Backend")
        
        success = True
        success &= install_dependencies()
        success &= setup_directories()
        success &= create_config_files()
        
        if success:
            print("\n✅ Installation completed successfully!")
            print("\nNext steps:")
            print("1. Review configuration in .env file")
            print("2. Run the dashboard: python main_dashboard.py")
            print("3. Access dashboard at http://localhost:8888")
        else:
            print("\n❌ Installation failed")
            sys.exit(1)
            
    elif command == "test":
        print("🧪 Running test suite")
        if not run_tests():
            sys.exit(1)
            
    elif command == "dev":
        print("🛠️ Setting up development environment")
        success = True
        success &= install_dependencies()
        success &= setup_development()
        
        if success:
            print("\n✅ Development environment ready!")
        else:
            print("\n❌ Development setup failed")
            sys.exit(1)
            
    elif command == "service":
        print("⚙️ Creating systemd service")
        if create_systemd_service():
            print("✅ Service file created")
        else:
            print("❌ Service creation failed")
            sys.exit(1)
            
    else:
        print(f"Unknown command: {command}")
        print("Available commands: install, test, dev, service")
        sys.exit(1)

if __name__ == "__main__":
    main()