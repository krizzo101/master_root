#!/usr/bin/env python3
"""
LogStreamer Class
Real-time log tailing with filtering for orchestrator workflows

Features:
- Real-time log file monitoring and streaming
- Multi-workflow log separation and correlation
- Log level filtering and search capabilities
- Non-blocking file watching with asyncio
- Integration with WebSocket broadcasting
- Structured log parsing and metadata extraction
"""

import asyncio
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Callable, AsyncGenerator

from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent
from watchdog.observers import Observer

logger = logging.getLogger(__name__)

class LogEntry:
    """Structured log entry with metadata"""
    
    def __init__(self, 
                 workflow_id: str,
                 raw_line: str,
                 timestamp: Optional[datetime] = None,
                 level: str = "INFO",
                 message: str = "",
                 task_id: Optional[str] = None,
                 metadata: Optional[Dict] = None):
        self.workflow_id = workflow_id
        self.raw_line = raw_line
        self.timestamp = timestamp or datetime.now()
        self.level = level
        self.message = message or raw_line
        self.task_id = task_id
        self.metadata = metadata or {}
        
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "workflow_id": self.workflow_id,
            "raw_line": self.raw_line,
            "timestamp": self.timestamp.isoformat(),
            "level": self.level,
            "message": self.message,
            "task_id": self.task_id,
            "metadata": self.metadata
        }
        
    def matches_filter(self, level_filter: Optional[str] = None, 
                      search_term: Optional[str] = None) -> bool:
        """Check if this log entry matches the given filters"""
        
        # Level filter
        if level_filter and self.level != level_filter.upper():
            return False
            
        # Search term filter
        if search_term and search_term.lower() not in self.message.lower():
            return False
            
        return True

class LogParser:
    """Parses log lines and extracts structured information"""
    
    def __init__(self):
        # Common log patterns
        self.patterns = {
            # Standard Python logging format
            'python_logging': re.compile(
                r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2},\d{3})\s+'
                r'(?P<level>\w+)\s+'
                r'(?P<logger>[\w.]+)\s+'
                r'(?P<message>.+)'
            ),
            
            # Orchestrator specific patterns
            'orchestrator': re.compile(
                r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+'
                r'\[(?P<level>\w+)\]\s+'
                r'(?:\[(?P<task_id>\w+)\])?\s*'
                r'(?P<message>.+)'
            ),
            
            # Task execution patterns
            'task_execution': re.compile(
                r'Task\s+(?P<task_id>\w+)\s+'
                r'(?P<status>started|completed|failed)\s*'
                r'(?P<message>.*)'
            ),
            
            # Generic timestamp pattern
            'generic_timestamp': re.compile(
                r'(?P<timestamp>\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2})'
                r'(?P<rest>.*)'
            )
        }
        
        # Log level mapping
        self.level_keywords = {
            'DEBUG': ['DEBUG', 'TRACE'],
            'INFO': ['INFO', 'INFORMATION'],
            'WARNING': ['WARNING', 'WARN'],
            'ERROR': ['ERROR', 'ERR'],
            'CRITICAL': ['CRITICAL', 'FATAL', 'CRIT']
        }
        
    def parse_log_line(self, line: str, workflow_id: str) -> LogEntry:
        """Parse a single log line into a structured LogEntry"""
        line = line.strip()
        if not line:
            return LogEntry(workflow_id, line)
        
        # Try each pattern
        for pattern_name, pattern in self.patterns.items():
            match = pattern.match(line)
            if match:
                return self._create_log_entry_from_match(workflow_id, line, match, pattern_name)
        
        # Fallback: create basic entry
        level = self._extract_log_level(line)
        return LogEntry(
            workflow_id=workflow_id,
            raw_line=line,
            level=level,
            message=line
        )
        
    def _create_log_entry_from_match(self, workflow_id: str, raw_line: str, 
                                   match: re.Match, pattern_name: str) -> LogEntry:
        """Create LogEntry from regex match"""
        groups = match.groupdict()
        
        # Parse timestamp
        timestamp = None
        if 'timestamp' in groups and groups['timestamp']:
            timestamp = self._parse_timestamp(groups['timestamp'])
        
        # Extract level
        level = groups.get('level', 'INFO').upper()
        if level not in ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']:
            level = 'INFO'
        
        # Extract message
        message = groups.get('message', raw_line)
        
        # Extract task ID
        task_id = groups.get('task_id')
        
        # Create metadata
        metadata = {
            'pattern': pattern_name,
            'logger': groups.get('logger'),
            'status': groups.get('status')
        }
        
        # Clean up metadata (remove None values)
        metadata = {k: v for k, v in metadata.items() if v is not None}
        
        return LogEntry(
            workflow_id=workflow_id,
            raw_line=raw_line,
            timestamp=timestamp,
            level=level,
            message=message,
            task_id=task_id,
            metadata=metadata
        )
        
    def _parse_timestamp(self, timestamp_str: str) -> Optional[datetime]:
        """Parse timestamp from string"""
        timestamp_formats = [
            "%Y-%m-%d %H:%M:%S,%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f"
        ]
        
        for fmt in timestamp_formats:
            try:
                return datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
                
        return None
        
    def _extract_log_level(self, line: str) -> str:
        """Extract log level from line using keyword matching"""
        line_upper = line.upper()
        
        for level, keywords in self.level_keywords.items():
            if any(keyword in line_upper for keyword in keywords):
                return level
                
        return 'INFO'

class LogFileWatcher:
    """Watches individual log files for changes"""
    
    def __init__(self, file_path: Path, workflow_id: str, 
                 on_new_line: Callable[[LogEntry], None]):
        self.file_path = file_path
        self.workflow_id = workflow_id
        self.on_new_line = on_new_line
        self.parser = LogParser()
        self.last_position = 0
        self.watching = False
        
    async def start_watching(self):
        """Start watching the log file"""
        if not self.file_path.exists():
            logger.warning(f"Log file does not exist: {self.file_path}")
            return
            
        self.watching = True
        
        # Get initial file size
        try:
            self.last_position = self.file_path.stat().st_size
        except OSError:
            self.last_position = 0
            
        # Start watching loop
        while self.watching:
            await self._check_for_changes()
            await asyncio.sleep(0.5)  # Check every 500ms
            
    async def stop_watching(self):
        """Stop watching the log file"""
        self.watching = False
        
    async def _check_for_changes(self):
        """Check for new content in the log file"""
        try:
            if not self.file_path.exists():
                return
                
            current_size = self.file_path.stat().st_size
            
            # File was truncated
            if current_size < self.last_position:
                self.last_position = 0
                
            # No new content
            if current_size == self.last_position:
                return
                
            # Read new content
            with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                f.seek(self.last_position)
                new_content = f.read()
                self.last_position = current_size
                
            # Process new lines
            if new_content:
                lines = new_content.split('\n')
                for line in lines:
                    if line.strip():
                        log_entry = self.parser.parse_log_line(line, self.workflow_id)
                        self.on_new_line(log_entry)
                        
        except Exception as e:
            logger.error(f"Error reading log file {self.file_path}: {e}")

class LogDirectoryWatcher(FileSystemEventHandler):
    """Watches directories for new log files"""
    
    def __init__(self, log_streamer: 'LogStreamer'):
        self.log_streamer = log_streamer
        
    def on_created(self, event):
        """Handle file creation events"""
        if not event.is_directory and self._is_log_file(event.src_path):
            asyncio.create_task(
                self.log_streamer._add_log_file(Path(event.src_path))
            )
            
    def on_modified(self, event):
        """Handle file modification events"""
        if not event.is_directory and self._is_log_file(event.src_path):
            # File watchers handle modifications
            pass
            
    def _is_log_file(self, file_path: str) -> bool:
        """Check if a file is a log file"""
        log_extensions = ['.log', '.txt', '.out']
        log_keywords = ['log', 'output', 'trace']
        
        path = Path(file_path)
        
        # Check extension
        if path.suffix.lower() in log_extensions:
            return True
            
        # Check filename keywords
        if any(keyword in path.name.lower() for keyword in log_keywords):
            return True
            
        return False

class LogStreamer:
    """
    Main log streaming service for orchestrator workflows
    
    Capabilities:
    - Monitor multiple log files simultaneously
    - Real-time parsing and streaming of log entries
    - Workflow-specific log separation
    - Filtering by log level and search terms
    - WebSocket integration for real-time updates
    """
    
    def __init__(self, base_directories: Optional[List[Path]] = None,
                 on_log_entry: Optional[Callable[[LogEntry], None]] = None):
        self.base_directories = base_directories or [
            Path("/home/opsvi/master_root/apps/agent-orchestrator/outputs"),
            Path("/home/opsvi/master_root/apps/agent-orchestrator/output"),
            Path("/home/opsvi/master_root/apps/agent-orchestrator/logs")
        ]
        self.on_log_entry = on_log_entry
        
        # Active watchers
        self.file_watchers: Dict[str, LogFileWatcher] = {}
        self.directory_observers: List[Observer] = []
        
        # Log history
        self.log_history: Dict[str, List[LogEntry]] = {}
        self.max_history_per_workflow = 1000
        
        self.streaming = False
        
    async def start_streaming(self):
        """Start log streaming service"""
        logger.info("Starting log streaming service")
        self.streaming = True
        
        # Discover existing log files
        await self._discover_existing_logs()
        
        # Start directory watchers
        self._start_directory_watchers()
        
        logger.info(f"Log streaming started, monitoring {len(self.file_watchers)} files")
        
    async def stop_streaming(self):
        """Stop log streaming service"""
        logger.info("Stopping log streaming service")
        self.streaming = False
        
        # Stop file watchers
        for watcher in self.file_watchers.values():
            await watcher.stop_watching()
        self.file_watchers.clear()
        
        # Stop directory observers
        for observer in self.directory_observers:
            observer.stop()
            observer.join()
        self.directory_observers.clear()
        
    async def add_workflow_logs(self, workflow_id: str, log_files: List[Path]):
        """Add log files for a specific workflow"""
        for log_file in log_files:
            await self._add_log_file(log_file, workflow_id)
            
    async def get_workflow_logs(self, workflow_id: str, 
                              level_filter: Optional[str] = None,
                              search_term: Optional[str] = None,
                              limit: int = 100) -> List[LogEntry]:
        """Get historical logs for a workflow with filtering"""
        if workflow_id not in self.log_history:
            return []
            
        logs = self.log_history[workflow_id]
        
        # Apply filters
        if level_filter or search_term:
            logs = [
                log for log in logs 
                if log.matches_filter(level_filter, search_term)
            ]
            
        # Apply limit
        return logs[-limit:]
        
    def get_active_workflows(self) -> List[str]:
        """Get list of workflows with active log streams"""
        return list(set(
            watcher.workflow_id 
            for watcher in self.file_watchers.values()
        ))
        
    async def _discover_existing_logs(self):
        """Discover existing log files in base directories"""
        for base_dir in self.base_directories:
            if base_dir.exists():
                async for log_file in self._scan_directory(base_dir):
                    await self._add_log_file(log_file)
                    
    async def _scan_directory(self, directory: Path) -> AsyncGenerator[Path, None]:
        """Asynchronously scan directory for log files"""
        try:
            for item in directory.rglob("*"):
                if item.is_file() and self._is_log_file(item):
                    yield item
                    # Yield control to prevent blocking
                    await asyncio.sleep(0)
        except Exception as e:
            logger.error(f"Error scanning directory {directory}: {e}")
            
    def _is_log_file(self, file_path: Path) -> bool:
        """Check if a file is a log file"""
        log_extensions = ['.log', '.txt', '.out']
        log_keywords = ['log', 'output', 'trace', 'orchestrator']
        
        # Check extension
        if file_path.suffix.lower() in log_extensions:
            return True
            
        # Check filename keywords
        if any(keyword in file_path.name.lower() for keyword in log_keywords):
            return True
            
        return False
        
    def _derive_workflow_id(self, log_file: Path) -> str:
        """Derive workflow ID from log file path"""
        # Try to extract from directory structure
        parts = log_file.parts
        
        # Look for timestamp patterns
        for part in parts:
            if re.match(r'\d{8}_\d{6}', part):
                return f"timestamped_{part}"
                
        # Look for task type patterns
        for part in parts:
            if any(task_type in part.lower() for task_type in ['analysis', 'documentation', 'code']):
                return f"task_{part}"
                
        # Fallback to file-based ID
        return f"file_{log_file.stem}"
        
    async def _add_log_file(self, log_file: Path, workflow_id: Optional[str] = None):
        """Add a log file to monitoring"""
        if not log_file.exists():
            return
            
        # Derive workflow ID if not provided
        if not workflow_id:
            workflow_id = self._derive_workflow_id(log_file)
            
        # Avoid duplicate watchers
        watcher_key = f"{workflow_id}_{log_file}"
        if watcher_key in self.file_watchers:
            return
            
        # Create file watcher
        watcher = LogFileWatcher(
            log_file, 
            workflow_id, 
            lambda entry: self._handle_new_log_entry(entry)
        )
        
        self.file_watchers[watcher_key] = watcher
        
        # Initialize log history for workflow
        if workflow_id not in self.log_history:
            self.log_history[workflow_id] = []
            
        # Start watching
        asyncio.create_task(watcher.start_watching())
        
        logger.info(f"Started watching log file: {log_file} for workflow: {workflow_id}")
        
    def _start_directory_watchers(self):
        """Start file system watchers for directories"""
        handler = LogDirectoryWatcher(self)
        
        for base_dir in self.base_directories:
            if base_dir.exists():
                observer = Observer()
                observer.schedule(handler, str(base_dir), recursive=True)
                observer.start()
                self.directory_observers.append(observer)
                
    def _handle_new_log_entry(self, entry: LogEntry):
        """Handle a new log entry"""
        # Add to history
        if entry.workflow_id not in self.log_history:
            self.log_history[entry.workflow_id] = []
            
        self.log_history[entry.workflow_id].append(entry)
        
        # Limit history size
        if len(self.log_history[entry.workflow_id]) > self.max_history_per_workflow:
            self.log_history[entry.workflow_id] = \
                self.log_history[entry.workflow_id][-self.max_history_per_workflow:]
                
        # Call external handler
        if self.on_log_entry:
            try:
                self.on_log_entry(entry)
            except Exception as e:
                logger.error(f"Error in log entry handler: {e}")

async def main():
    """Test the log streaming functionality"""
    
    def on_log(entry: LogEntry):
        print(f"[{entry.timestamp}] {entry.level} - {entry.workflow_id}: {entry.message}")
    
    streamer = LogStreamer(on_log_entry=on_log)
    await streamer.start_streaming()
    
    try:
        # Keep running
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        await streamer.stop_streaming()

if __name__ == "__main__":
    asyncio.run(main())