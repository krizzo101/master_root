#!/usr/bin/env python3
"""
Phase 3: Reorganize Directory Structure
Implements new organized structure with proper categorization
"""

import os
import sys
import shutil
import re
import json
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('reorganize_phase.log'),
        logging.StreamHandler()
    ]
)

BASE_DIR = Path("/home/opsvi/master_root/apps/agent-orchestrator")

class StructureReorganizer:
    def __init__(self):
        self.stats = {
            "directories_created": 0,
            "files_moved": 0,
            "imports_updated": 0,
            "empty_dirs_removed": 0,
            "errors": []
        }
        
        # Import mappings for updates
        self.import_mappings = {
            r"from run_": "from scripts.runners.run_",
            r"import run_": "import scripts.runners.run_",
            r"from utils_": "from scripts.utilities.utils_",
            r"import utils_": "import scripts.utilities.utils_",
            r"from analyze_": "from scripts.analysis.analyze_",
            r"import analyze_": "import scripts.analysis.analyze_"
        }
    
    def consolidate_outputs(self):
        """Merge outputs/ into output/ directory"""
        logging.info("Consolidating output directories...")
        
        outputs_dir = BASE_DIR / "outputs"
        output_dir = BASE_DIR / "output"
        
        if outputs_dir.exists() and outputs_dir.is_dir():
            # Ensure output directory exists
            output_dir.mkdir(exist_ok=True)
            
            # Move contents from outputs to output
            for item in outputs_dir.iterdir():
                try:
                    target = output_dir / item.name
                    if target.exists():
                        # Handle conflicts
                        logging.warning(f"Conflict: {item.name} exists in both directories")
                        target = output_dir / f"{item.name}_from_outputs"
                    
                    shutil.move(str(item), str(target))
                    logging.info(f"Moved: {item.name} to output/")
                    self.stats["files_moved"] += 1
                    
                except Exception as e:
                    logging.error(f"Failed to move {item}: {e}")
                    self.stats["errors"].append(str(e))
            
            # Remove empty outputs directory
            try:
                outputs_dir.rmdir()
                logging.info("Removed empty outputs/ directory")
                self.stats["empty_dirs_removed"] += 1
            except OSError:
                logging.warning("outputs/ directory not empty after move")
        
        # Standardize output subdirectory structure
        if output_dir.exists():
            for subdir in output_dir.iterdir():
                if subdir.is_dir():
                    self._ensure_standard_subdirs(subdir)
    
    def _ensure_standard_subdirs(self, workflow_dir):
        """Ensure standard subdirectories exist in workflow output"""
        standard_dirs = ["logs", "checkpoints", "agents"]
        
        for dirname in standard_dirs:
            subdir = workflow_dir / dirname
            if not subdir.exists():
                subdir.mkdir(exist_ok=True)
                self.stats["directories_created"] += 1
    
    def organize_scripts(self):
        """Organize script files into categorized directories"""
        logging.info("Organizing script files...")
        
        # Create script directory structure
        script_dirs = {
            "runners": BASE_DIR / "scripts" / "runners",
            "utilities": BASE_DIR / "scripts" / "utilities",
            "analysis": BASE_DIR / "scripts" / "analysis"
        }
        
        for dir_path in script_dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
            self.stats["directories_created"] += 1
        
        # Define patterns and destinations
        patterns = {
            "run_*.py": script_dirs["runners"],
            "resume_*.py": script_dirs["runners"],
            "utils_*.py": script_dirs["utilities"],
            "*_helper.py": script_dirs["utilities"],
            "*_utility.py": script_dirs["utilities"],
            "analyze_*.py": script_dirs["analysis"],
            "*_analysis.py": script_dirs["analysis"]
        }
        
        for pattern, destination in patterns.items():
            for script_file in BASE_DIR.glob(pattern):
                if script_file.is_file():
                    try:
                        target = destination / script_file.name
                        if not target.exists():
                            shutil.move(str(script_file), str(target))
                            logging.info(f"Moved {script_file.name} to {destination.name}")
                            self.stats["files_moved"] += 1
                    except Exception as e:
                        logging.error(f"Failed to move {script_file}: {e}")
                        self.stats["errors"].append(str(e))
    
    def organize_configs(self):
        """Organize configuration files"""
        logging.info("Organizing configuration files...")
        
        # Create config directory structure
        config_dirs = {
            "templates": BASE_DIR / "configs" / "templates",
            "workflows": BASE_DIR / "configs" / "workflows",
            "agents": BASE_DIR / "configs" / "agents"
        }
        
        for dir_path in config_dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
            self.stats["directories_created"] += 1
        
        # Move configuration files
        patterns = {
            "*.template": config_dirs["templates"],
            "*_config.json": config_dirs["workflows"],
            "*_workflow.json": config_dirs["workflows"],
            "agent_*.json": config_dirs["agents"],
            "*_agent.json": config_dirs["agents"]
        }
        
        for pattern, destination in patterns.items():
            for config_file in BASE_DIR.glob(pattern):
                if config_file.is_file():
                    try:
                        target = destination / config_file.name
                        if not target.exists():
                            shutil.move(str(config_file), str(target))
                            logging.info(f"Moved config: {config_file.name}")
                            self.stats["files_moved"] += 1
                    except Exception as e:
                        logging.error(f"Failed to move {config_file}: {e}")
                        self.stats["errors"].append(str(e))
    
    def update_imports(self):
        """Update Python imports after reorganization"""
        logging.info("Updating Python imports...")
        
        # Find all Python files
        python_files = list(BASE_DIR.rglob("*.py"))
        
        for py_file in python_files:
            # Skip files in archive
            if "archive" in str(py_file):
                continue
            
            try:
                content = py_file.read_text()
                original_content = content
                
                # Apply import mappings
                for pattern, replacement in self.import_mappings.items():
                    content = re.sub(pattern, replacement, content)
                
                # Only write if changed
                if content != original_content:
                    py_file.write_text(content)
                    logging.info(f"Updated imports in: {py_file.relative_to(BASE_DIR)}")
                    self.stats["imports_updated"] += 1
                    
            except Exception as e:
                logging.error(f"Failed to update imports in {py_file}: {e}")
                self.stats["errors"].append(str(e))
    
    def clean_empty_directories(self):
        """Remove empty directories and temporary files"""
        logging.info("Cleaning empty directories and temporary files...")
        
        # Remove temporary files
        temp_patterns = ["*.pyc", ".DS_Store", "*.swp", "*~", "Thumbs.db"]
        
        for pattern in temp_patterns:
            for temp_file in BASE_DIR.rglob(pattern):
                try:
                    temp_file.unlink()
                    logging.debug(f"Removed temp file: {temp_file.name}")
                except Exception as e:
                    logging.error(f"Failed to remove {temp_file}: {e}")
        
        # Remove __pycache__ directories
        for pycache in BASE_DIR.rglob("__pycache__"):
            if pycache.is_dir():
                try:
                    shutil.rmtree(pycache)
                    logging.debug(f"Removed __pycache__: {pycache}")
                    self.stats["empty_dirs_removed"] += 1
                except Exception as e:
                    logging.error(f"Failed to remove {pycache}: {e}")
        
        # Remove empty directories (bottom-up)
        for root, dirs, files in os.walk(BASE_DIR, topdown=False):
            if not dirs and not files:
                try:
                    os.rmdir(root)
                    logging.info(f"Removed empty directory: {root}")
                    self.stats["empty_dirs_removed"] += 1
                except Exception as e:
                    logging.error(f"Failed to remove empty dir {root}: {e}")
    
    def create_directory_map(self):
        """Create a map of the new directory structure"""
        logging.info("Creating directory structure map...")
        
        structure = {}
        
        for root, dirs, files in os.walk(BASE_DIR):
            # Skip archive and hidden directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'archive']
            
            level = root.replace(str(BASE_DIR), '').count(os.sep)
            indent = ' ' * 2 * level
            rel_path = os.path.relpath(root, BASE_DIR)
            
            if level == 0:
                structure["root"] = {
                    "directories": dirs,
                    "file_count": len(files)
                }
            else:
                structure[rel_path] = {
                    "level": level,
                    "directories": dirs,
                    "file_count": len(files)
                }
        
        # Save structure map
        map_file = BASE_DIR / "STRUCTURE_MAP.json"
        with open(map_file, 'w') as f:
            json.dump(structure, f, indent=2)
        
        logging.info(f"Structure map saved: {map_file}")
        return structure
    
    def run_reorganization_phase(self):
        """Execute complete reorganization phase"""
        logging.info("="*50)
        logging.info("PHASE 3: REORGANIZATION - Starting")
        logging.info("="*50)
        
        # Execute reorganization tasks
        self.consolidate_outputs()
        self.organize_scripts()
        self.organize_configs()
        self.update_imports()
        self.clean_empty_directories()
        
        # Create structure map
        structure = self.create_directory_map()
        
        # Report results
        logging.info("="*50)
        logging.info("REORGANIZATION PHASE COMPLETE")
        logging.info("="*50)
        logging.info(f"Directories created: {self.stats['directories_created']}")
        logging.info(f"Files moved: {self.stats['files_moved']}")
        logging.info(f"Imports updated: {self.stats['imports_updated']}")
        logging.info(f"Empty directories removed: {self.stats['empty_dirs_removed']}")
        
        if self.stats['errors']:
            logging.warning(f"Errors encountered: {len(self.stats['errors'])}")
            for error in self.stats['errors'][:5]:
                logging.warning(f"  - {error}")
        
        # Save phase completion flag
        flag_file = BASE_DIR / "phase3_complete.flag"
        with open(flag_file, 'w') as f:
            f.write(f"PHASE_3_COMPLETE\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write(f"Files moved: {self.stats['files_moved']}\n")
            f.write(f"Imports updated: {self.stats['imports_updated']}\n")
        
        return self.stats

def main():
    """Main execution"""
    from datetime import datetime
    
    reorganizer = StructureReorganizer()
    
    try:
        stats = reorganizer.run_reorganization_phase()
        
        # Exit with appropriate code
        if stats['errors']:
            sys.exit(1)  # Partial success
        else:
            sys.exit(0)  # Complete success
            
    except Exception as e:
        logging.error(f"Reorganization phase failed: {e}")
        sys.exit(2)  # Complete failure

if __name__ == "__main__":
    main()