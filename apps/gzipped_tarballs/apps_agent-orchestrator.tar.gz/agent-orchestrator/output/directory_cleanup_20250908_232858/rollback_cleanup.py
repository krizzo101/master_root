#!/usr/bin/env python3
"""
Rollback Script for Directory Cleanup
Restores from backup if cleanup fails or causes issues
"""

import os
import sys
import tarfile
import shutil
import json
from pathlib import Path
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def verify_backup(backup_path):
    """Verify backup file exists and is valid"""
    backup_file = Path(backup_path)
    
    if not backup_file.exists():
        logging.error(f"Backup file not found: {backup_path}")
        return False
    
    if not backup_file.suffix == '.gz':
        logging.error(f"Invalid backup file format (expected .tar.gz): {backup_path}")
        return False
    
    try:
        # Test if we can open the archive
        with tarfile.open(backup_path, 'r:gz') as tar:
            members = tar.getmembers()
            logging.info(f"Backup contains {len(members)} files")
            return True
    except Exception as e:
        logging.error(f"Failed to read backup file: {e}")
        return False

def create_pre_rollback_snapshot(target_dir):
    """Create a snapshot of current state before rollback"""
    snapshot_dir = Path(f"/tmp/pre_rollback_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    
    try:
        # Create file listing
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        # Save current file list
        file_list = []
        if Path(target_dir).exists():
            for root, dirs, files in os.walk(target_dir):
                for file in files:
                    file_list.append(os.path.relpath(os.path.join(root, file), target_dir))
        
        with open(snapshot_dir / "file_list.json", 'w') as f:
            json.dump(file_list, f, indent=2)
        
        logging.info(f"Pre-rollback snapshot saved: {snapshot_dir}")
        return snapshot_dir
        
    except Exception as e:
        logging.warning(f"Failed to create pre-rollback snapshot: {e}")
        return None

def rollback(backup_path, force=False):
    """
    Restore from backup
    
    Args:
        backup_path: Path to the backup tar.gz file
        force: If True, skip confirmation prompt
    """
    target_dir = "/home/opsvi/master_root/apps/agent-orchestrator"
    
    # Verify backup
    logging.info("="*50)
    logging.info("ROLLBACK PROCEDURE INITIATED")
    logging.info("="*50)
    
    if not verify_backup(backup_path):
        logging.error("Backup verification failed. Aborting rollback.")
        return False
    
    # Confirmation prompt
    if not force:
        print(f"\n⚠️  WARNING: This will replace the current directory with the backup.")
        print(f"Target directory: {target_dir}")
        print(f"Backup file: {backup_path}")
        response = input("\nAre you sure you want to proceed? (yes/no): ")
        
        if response.lower() != 'yes':
            logging.info("Rollback cancelled by user")
            return False
    
    # Create pre-rollback snapshot
    logging.info("Creating pre-rollback snapshot...")
    snapshot_dir = create_pre_rollback_snapshot(target_dir)
    
    try:
        # Step 1: Remove current directory
        if os.path.exists(target_dir):
            logging.info(f"Removing current directory: {target_dir}")
            
            # Save any critical files that might have been created post-cleanup
            critical_saves = []
            critical_patterns = [
                "*.log",
                "VALIDATION_REPORT.json",
                "phase*_complete.flag"
            ]
            
            save_dir = Path(f"/tmp/rollback_saves_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            save_dir.mkdir(parents=True, exist_ok=True)
            
            for pattern in critical_patterns:
                for file in Path(target_dir).glob(pattern):
                    try:
                        shutil.copy2(file, save_dir)
                        critical_saves.append(file.name)
                    except:
                        pass
            
            if critical_saves:
                logging.info(f"Saved {len(critical_saves)} critical files to {save_dir}")
            
            # Remove directory
            shutil.rmtree(target_dir)
            logging.info("Current directory removed")
        
        # Step 2: Extract backup
        logging.info(f"Extracting backup from: {backup_path}")
        
        extract_dir = "/home/opsvi/master_root/apps"
        with tarfile.open(backup_path, 'r:gz') as tar:
            # Extract with progress
            members = tar.getmembers()
            total = len(members)
            
            for i, member in enumerate(members):
                if i % 100 == 0:
                    progress = (i / total) * 100
                    print(f"Progress: {progress:.1f}% ({i}/{total} files)", end='\r')
                tar.extract(member, extract_dir)
            
            print(f"Progress: 100.0% ({total}/{total} files)")
        
        logging.info("Backup extraction complete")
        
        # Step 3: Verify restoration
        if not os.path.exists(target_dir):
            logging.error("Target directory not created after extraction")
            return False
        
        # Count restored files
        restored_count = sum(1 for _ in Path(target_dir).rglob('*') if _.is_file())
        logging.info(f"Restored {restored_count} files")
        
        # Step 4: Post-rollback verification
        logging.info("Verifying restored files...")
        
        critical_files = [
            "main.py",
            "src/generic_orchestrator.py",
            "README.md"
        ]
        
        missing = []
        for file in critical_files:
            if not (Path(target_dir) / file).exists():
                missing.append(file)
        
        if missing:
            logging.warning(f"Critical files missing after rollback: {missing}")
        else:
            logging.info("✓ All critical files restored")
        
        # Create rollback report
        report = {
            "rollback_date": datetime.now().isoformat(),
            "backup_used": backup_path,
            "files_restored": restored_count,
            "snapshot_location": str(snapshot_dir) if snapshot_dir else None,
            "critical_saves": str(save_dir) if critical_saves else None,
            "status": "SUCCESS" if not missing else "PARTIAL_SUCCESS"
        }
        
        report_file = Path(target_dir) / "ROLLBACK_REPORT.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        logging.info("="*50)
        logging.info("ROLLBACK COMPLETE")
        logging.info("="*50)
        logging.info(f"✅ Successfully restored from: {backup_path}")
        logging.info(f"📁 Files restored: {restored_count}")
        
        if snapshot_dir:
            logging.info(f"📸 Pre-rollback snapshot: {snapshot_dir}")
        
        if critical_saves:
            logging.info(f"💾 Saved files from cleanup: {save_dir}")
        
        print("\nNext steps:")
        print("1. Verify application functionality")
        print("2. Check git status for any uncommitted changes")
        print("3. Review ROLLBACK_REPORT.json for details")
        
        return True
        
    except Exception as e:
        logging.error(f"Rollback failed: {e}")
        logging.error("Manual intervention may be required")
        
        # Try to provide recovery information
        print("\n🚨 ROLLBACK FAILED - Manual Recovery Steps:")
        print(f"1. Manually extract backup: tar -xzf {backup_path} -C /home/opsvi/master_root/apps/")
        print(f"2. Check snapshot if available: {snapshot_dir}")
        print("3. Contact system administrator if needed")
        
        return False

def find_latest_backup():
    """Find the most recent backup file"""
    backup_root = Path("/home/opsvi/master_root/backups")
    
    if not backup_root.exists():
        return None
    
    # Find all backup files
    backups = list(backup_root.glob("agent-orchestrator-*/agent-orchestrator-complete.tar.gz"))
    
    if not backups:
        return None
    
    # Sort by modification time
    backups.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    return backups[0]

def main():
    """Main execution"""
    
    if len(sys.argv) < 2:
        # Try to find latest backup
        latest_backup = find_latest_backup()
        
        if latest_backup:
            print(f"Found latest backup: {latest_backup}")
            print("\nUsage:")
            print(f"  python {sys.argv[0]} {latest_backup}")
            print("\nOr specify a backup file:")
            print(f"  python {sys.argv[0]} <backup_path>")
            print("\nOptions:")
            print(f"  python {sys.argv[0]} <backup_path> --force  # Skip confirmation")
        else:
            print("No backups found in /home/opsvi/master_root/backups/")
            print("\nUsage:")
            print(f"  python {sys.argv[0]} <backup_path>")
            print("\nOptions:")
            print(f"  python {sys.argv[0]} <backup_path> --force  # Skip confirmation")
        
        sys.exit(1)
    
    backup_path = sys.argv[1]
    force = "--force" in sys.argv
    
    # Run rollback
    success = rollback(backup_path, force)
    
    if success:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()