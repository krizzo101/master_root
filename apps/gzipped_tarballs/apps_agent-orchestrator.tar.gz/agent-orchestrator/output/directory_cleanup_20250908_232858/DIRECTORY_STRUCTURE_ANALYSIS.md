# Agent-Orchestrator Directory Structure Analysis

**Analysis Date:** 2025-09-09  
**Total Files:** 1,036  
**Total Directories:** 313  
**Analysis Scope:** Complete inventory with organizational assessment

## Executive Summary

The agent-orchestrator directory contains a mature but organizationally complex application with significant accumulation of experimental files, test scripts, and workflow outputs. The codebase shows signs of rapid development with multiple overlapping systems and incomplete cleanup from various iterations.

## File Type Distribution

- **Python Files:** 177 (17%)
- **JSON Files:** 622 (60%)
- **Markdown Files:** 111 (11%)
- **Log Files:** 80 (8%)
- **Other Files:** 46 (4%)

## Directory Structure Overview

### Core Application Structure
```
/agent-orchestrator/
├── src/                    # Core source code (91 Python files)
├── docs/                   # Documentation (recently updated)
├── web/                    # Web interface components
├── tests/                  # Test suites
├── archive/                # Archived workflows and outputs
├── output/                 # Active workflow outputs
├── outputs/                # Alternative output directory
└── temp_docs_cleanup/      # Temporary cleanup directory
```

## Critical Issues Identified

### 1. **Duplicate Output Directories**
- `output/` - Active, contains 12 subdirectories with recent workflows
- `outputs/` - Partially used, contains only analysis subdirectory
- **Recommendation:** Consolidate to single `outputs/` directory

### 2. **Test Files in Root Directory** (27 files)
- Multiple test scripts mixed with production code
- Test files scattered: `*_test.py`, `test_*.py`, `*demo.py`
- **Recommendation:** Move all test files to `tests/` directory

### 3. **Excessive JSON Task Files** (622 total)
- Many appear to be workflow definitions and task configurations
- Significant duplication across different workflow runs
- **Recommendation:** Archive completed workflow JSONs, maintain only templates

### 4. **Log File Accumulation** (80 files)
- Logs scattered across multiple directories
- No apparent rotation or archival strategy
- **Recommendation:** Implement log rotation, archive old logs

### 5. **Experimental/Development Files in Root**
- `simple_chat_demo.py`
- `stress_test_websockets.py`
- `load_test_metrics_feeder.py`
- Various other test utilities
- **Recommendation:** Move to `tests/` or `experiments/` directory

## File Categories and Disposition

### CORE SYSTEM FILES (Keep in Place)
```
Priority: HIGH | Count: ~50 files
Location: Root and src/
```
- `main.py` - Main application entry
- `orchestrator_api.py` - Core API
- `src/generic_orchestrator.py` - Primary orchestrator
- `src/enhanced_orchestrator.py` - Enhanced version
- `src/collaborative_orchestrator.py` - Multi-agent coordination
- Configuration files (`.env.production`, `.gitignore`)

### DOCUMENTATION (Organize)
```
Priority: MEDIUM | Count: 111 files
Current: Scattered across root and subdirectories
```
- Move all `*.md` files to appropriate `docs/` subdirectories
- Exception: Keep `README.md` in root
- Archive outdated documentation guides

### TEST FILES (Relocate)
```
Priority: HIGH | Count: ~40 files
Current: Root directory
Target: tests/
```
Files to move:
- All `*_test.py` files
- All `test_*.py` files
- All `*_demo.py` files
- Load testing scripts
- UI performance tests

### WORKFLOW OUTPUTS (Archive)
```
Priority: HIGH | Count: ~400 files
Current: output/ and outputs/
```
- Archive completed workflows older than 7 days
- Maintain only active/recent workflows
- Create `archive/workflows/YYYY-MM/` structure

### TEMPORARY FILES (Delete)
```
Priority: HIGH | Count: ~20 files/directories
```
- `temp_docs_cleanup/`
- `temp_orchestrator_output_spec.md`
- Any `*.tmp` or `*.temp` files
- Old checkpoint files

### RUN SCRIPTS (Organize)
```
Priority: MEDIUM | Count: 9 files
Current: Root directory
```
Scripts like:
- `run_orchestrator_analysis.py`
- `run_directory_cleanup.py`
- `run_dpo_build.py`

**Recommendation:** Move to `scripts/` directory

## Recommended Directory Structure

```
/agent-orchestrator/
├── src/                    # Core application code
│   ├── core/              # Core orchestrator modules
│   ├── agents/            # Agent implementations
│   ├── utils/             # Utility modules
│   └── web/               # Web interface code
├── scripts/               # Run scripts and utilities
├── tests/                 # All test files
│   ├── unit/
│   ├── integration/
│   └── performance/
├── docs/                  # Documentation
│   ├── guides/
│   ├── api/
│   └── architecture/
├── configs/               # Configuration files
├── templates/             # Task and workflow templates
├── outputs/               # Active workflow outputs (single directory)
│   └── {workflow_type}_{timestamp}/
├── archive/               # Historical data
│   ├── workflows/
│   ├── logs/
│   └── experiments/
└── .benchmarks/           # Performance benchmarks
```

## Implementation Priority

### Phase 1: Critical Cleanup (Immediate)
1. Delete temporary files and directories
2. Consolidate output directories
3. Move test files to tests/
4. Archive old workflow outputs

### Phase 2: Organization (This Week)
1. Create scripts/ directory and relocate run scripts
2. Organize src/ subdirectories
3. Consolidate documentation
4. Implement log rotation

### Phase 3: Optimization (Next Sprint)
1. Review and deduplicate JSON task files
2. Create template library
3. Implement automated archival
4. Set up CI/CD cleanup hooks

## Metrics Impact

### Current State
- Directory navigation time: HIGH (too many files in root)
- Build time impact: MEDIUM (unnecessary files in build path)
- Storage usage: 850MB+ (including archives)
- File discovery complexity: HIGH

### After Cleanup
- Expected storage reduction: 40-50%
- Improved navigation and discovery
- Faster build and deployment times
- Clearer separation of concerns

## Risk Assessment

### Low Risk Actions
- Moving test files
- Deleting temporary files
- Archiving old outputs

### Medium Risk Actions
- Consolidating output directories (update references)
- Reorganizing src/ structure (import path updates)

### High Risk Actions
- None identified - all changes are organizational

## Automation Opportunities

1. **Automated Archival Script**
   - Run daily to archive outputs > 7 days old
   - Compress and move to archive/

2. **Log Rotation**
   - Implement logrotate configuration
   - Automatic compression of old logs

3. **Test Discovery**
   - Configure test runners to find tests in tests/
   - Update CI/CD pipelines

## Conclusion

The agent-orchestrator directory structure shows a mature application that has grown organically without consistent organizational standards. The proposed cleanup will:

1. Reduce clutter by ~50%
2. Improve code organization and discoverability
3. Establish clear boundaries between code, tests, and outputs
4. Create sustainable patterns for future growth

The cleanup can be implemented incrementally with minimal risk to the running system.