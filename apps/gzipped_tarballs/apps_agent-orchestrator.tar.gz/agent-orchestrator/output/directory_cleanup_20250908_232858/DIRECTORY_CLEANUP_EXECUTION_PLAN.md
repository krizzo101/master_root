# Directory Cleanup and Reorganization Execution Plan

**Project:** Agent-Orchestrator Directory Cleanup  
**Date:** 2025-09-09  
**Risk Level:** Medium  
**Estimated Duration:** 2-3 hours  
**Rollback Available:** Yes

## Executive Summary

This execution plan provides a systematic approach to clean up and reorganize the agent-orchestrator directory, addressing 1,036 files across 313 directories. The plan emphasizes safety through comprehensive backups, incremental execution, and validation checkpoints.

## Pre-Execution Requirements

### System Requirements
- Available disk space: 5GB minimum for backups
- Python 3.8+ with required dependencies
- Git for version control operations
- Write permissions to parent directories

### Dependencies Check
```bash
# Verify Python environment
python --version
pip list | grep -E "asyncio|aiofiles|pydantic"

# Check disk space
df -h /home/opsvi/master_root

# Verify Git status
git status --porcelain
```

## Phase 1: Preparation (30 minutes)

### 1.1 Create Complete Backup
```bash
# Create backup directory with timestamp
BACKUP_DIR="/home/opsvi/master_root/backups/agent-orchestrator-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Full directory backup with preservation of permissions
cd /home/opsvi/master_root/apps
tar -czf "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" \
    --preserve-permissions \
    --verbose \
    agent-orchestrator/

# Verify backup integrity
tar -tzf "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" | wc -l
echo "Backup created: $BACKUP_DIR"
```

### 1.2 Create Working Inventory
```bash
cd /home/opsvi/master_root/apps/agent-orchestrator

# Generate file inventory
find . -type f -name "*.py" > inventory_python.txt
find . -type f -name "*.json" > inventory_json.txt
find . -type f -name "*.md" > inventory_markdown.txt
find . -type f -name "*.log" > inventory_logs.txt

# Create dependency map
grep -r "^import\|^from" --include="*.py" > dependency_map.txt
```

### 1.3 Setup Archive Structure
```bash
# Create organized archive directories
mkdir -p archive/workflows/2025
mkdir -p archive/test_runs
mkdir -p archive/logs/2025
mkdir -p archive/experimental
mkdir -p archive/deprecated
mkdir -p archive/documentation/legacy
```

### 1.4 Create Rollback Script
```python
# save as: rollback_cleanup.py
#!/usr/bin/env python3
import os
import sys
import tarfile
import shutil
from pathlib import Path

def rollback(backup_path):
    """Restore from backup if cleanup fails"""
    if not os.path.exists(backup_path):
        print(f"Error: Backup not found at {backup_path}")
        return False
    
    target_dir = "/home/opsvi/master_root/apps/agent-orchestrator"
    
    # Remove current directory
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    
    # Extract backup
    with tarfile.open(backup_path, 'r:gz') as tar:
        tar.extractall("/home/opsvi/master_root/apps/")
    
    print(f"Rollback complete from {backup_path}")
    return True

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python rollback_cleanup.py <backup_path>")
        sys.exit(1)
    rollback(sys.argv[1])
```

## Phase 2: Archive Phase (45 minutes)

### 2.1 Archive Workflow Outputs
```bash
# Move completed workflow outputs (older than 7 days)
find output/ -type d -mtime +7 -maxdepth 1 | while read dir; do
    echo "Archiving: $dir"
    mv "$dir" archive/workflows/2025/
done

# Archive JSON task files from completed workflows
find . -maxdepth 1 -name "*_tasks.json" -mtime +3 | while read file; do
    mv "$file" archive/workflows/2025/
done
```

### 2.2 Archive Test Files
```bash
# Move test files from root to tests directory
mkdir -p tests/integration
mkdir -p tests/performance
mkdir -p tests/demos

# Move test files maintaining categories
mv test_*.py tests/integration/ 2>/dev/null || true
mv *_test.py tests/integration/ 2>/dev/null || true
mv *_demo.py tests/demos/ 2>/dev/null || true
mv stress_test_*.py tests/performance/ 2>/dev/null || true
mv load_test_*.py tests/performance/ 2>/dev/null || true
```

### 2.3 Archive Logs
```bash
# Compress and archive old logs
find . -name "*.log" -mtime +7 | while read log; do
    gzip "$log"
    mv "$log.gz" archive/logs/2025/
done

# Keep only recent logs in active directories
find output/*/logs -name "*.log" -mtime +3 -delete
```

### 2.4 Archive Experimental Files
```bash
# Move experimental and development files
mv simple_chat_demo.py archive/experimental/ 2>/dev/null || true
mv websocket_load_test.py archive/experimental/ 2>/dev/null || true
mv test_websocket_scenarios.py archive/experimental/ 2>/dev/null || true

# Archive old documentation attempts
find . -name "*_old.md" -o -name "*_backup.md" | while read file; do
    mv "$file" archive/documentation/legacy/
done
```

### 2.5 Create Archive Manifest
```python
# save as: create_archive_manifest.py
#!/usr/bin/env python3
import os
import json
from datetime import datetime
from pathlib import Path

def create_manifest(archive_dir):
    manifest = {
        "created": datetime.now().isoformat(),
        "contents": {},
        "statistics": {}
    }
    
    for root, dirs, files in os.walk(archive_dir):
        rel_path = os.path.relpath(root, archive_dir)
        manifest["contents"][rel_path] = {
            "files": files,
            "count": len(files),
            "size_bytes": sum(os.path.getsize(os.path.join(root, f)) for f in files)
        }
    
    manifest["statistics"]["total_files"] = sum(
        v["count"] for v in manifest["contents"].values()
    )
    manifest["statistics"]["total_size_mb"] = sum(
        v["size_bytes"] for v in manifest["contents"].values()
    ) / (1024 * 1024)
    
    with open(f"{archive_dir}/MANIFEST.json", "w") as f:
        json.dump(manifest, f, indent=2)
    
    print(f"Archive manifest created: {archive_dir}/MANIFEST.json")
    print(f"Total archived files: {manifest['statistics']['total_files']}")
    print(f"Total size: {manifest['statistics']['total_size_mb']:.2f} MB")

if __name__ == "__main__":
    create_manifest("/home/opsvi/master_root/apps/agent-orchestrator/archive")
```

## Phase 3: Reorganization (30 minutes)

### 3.1 Consolidate Output Directories
```bash
# Merge outputs/ into output/
if [ -d "outputs/" ]; then
    mv outputs/* output/ 2>/dev/null || true
    rmdir outputs/
fi

# Standardize output directory structure
cd output/
for dir in */; do
    # Ensure standard subdirectories exist
    mkdir -p "$dir/logs"
    mkdir -p "$dir/checkpoints"
    mkdir -p "$dir/agents"
done
```

### 3.2 Organize Script Files
```bash
# Create organized script directories
mkdir -p scripts/runners
mkdir -p scripts/utilities
mkdir -p scripts/analysis

# Move runner scripts
mv run_*.py scripts/runners/ 2>/dev/null || true

# Move utility scripts
mv utils_*.py scripts/utilities/ 2>/dev/null || true
mv *_helper.py scripts/utilities/ 2>/dev/null || true

# Move analysis scripts
mv analyze_*.py scripts/analysis/ 2>/dev/null || true
```

### 3.3 Organize Configuration Files
```bash
# Create config directory structure
mkdir -p configs/templates
mkdir -p configs/workflows
mkdir -p configs/agents

# Move configuration files
mv *.template configs/templates/ 2>/dev/null || true
mv *_config.json configs/workflows/ 2>/dev/null || true
mv agent_*.json configs/agents/ 2>/dev/null || true
```

### 3.4 Update Import Paths
```python
# save as: update_imports.py
#!/usr/bin/env python3
import os
import re
from pathlib import Path

def update_imports(root_dir):
    """Update Python imports after reorganization"""
    
    # Map of moved modules
    import_map = {
        r"from run_": "from scripts.runners.run_",
        r"import run_": "import scripts.runners.run_",
        r"from utils_": "from scripts.utilities.utils_",
        r"import utils_": "import scripts.utilities.utils_",
    }
    
    python_files = Path(root_dir).rglob("*.py")
    
    for py_file in python_files:
        if "archive" in str(py_file):
            continue
            
        content = py_file.read_text()
        modified = False
        
        for pattern, replacement in import_map.items():
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                modified = True
        
        if modified:
            py_file.write_text(content)
            print(f"Updated imports in: {py_file}")

if __name__ == "__main__":
    update_imports("/home/opsvi/master_root/apps/agent-orchestrator")
```

### 3.5 Clean Empty Directories
```bash
# Remove empty directories
find . -type d -empty -delete

# Remove temporary files
find . -name "*.pyc" -delete
find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find . -name ".DS_Store" -delete
find . -name "*.swp" -delete
find . -name "*~" -delete
```

## Phase 4: Validation (30 minutes)

### 4.1 Core Functionality Tests
```python
# save as: validate_cleanup.py
#!/usr/bin/env python3
import sys
import subprocess
import json
from pathlib import Path

def validate_core_files():
    """Ensure core files still exist"""
    core_files = [
        "main.py",
        "orchestrator_api.py",
        "src/generic_orchestrator.py",
        "src/enhanced_orchestrator.py",
        "README.md",
        ".env.production"
    ]
    
    missing = []
    for file in core_files:
        if not Path(file).exists():
            missing.append(file)
    
    if missing:
        print(f"ERROR: Missing core files: {missing}")
        return False
    
    print("✓ All core files present")
    return True

def validate_imports():
    """Test Python imports"""
    try:
        # Test core imports
        subprocess.run(
            ["python", "-c", "from src.generic_orchestrator import GenericOrchestrator"],
            check=True,
            capture_output=True
        )
        print("✓ Core imports working")
        return True
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Import validation failed: {e}")
        return False

def validate_structure():
    """Verify expected directory structure"""
    expected_dirs = [
        "src",
        "docs",
        "tests",
        "archive",
        "output",
        "web",
        "configs",
        "scripts"
    ]
    
    missing = []
    for dir in expected_dirs:
        if not Path(dir).is_dir():
            missing.append(dir)
    
    if missing:
        print(f"WARNING: Missing directories: {missing}")
        return False
    
    print("✓ Directory structure validated")
    return True

def run_test_workflow():
    """Execute a simple test workflow"""
    test_task = {
        "task_type": "test_validation",
        "task_id": "cleanup_validation_test",
        "prompt": "echo 'Validation test successful'"
    }
    
    try:
        # Save test task
        with open("test_validation_task.json", "w") as f:
            json.dump(test_task, f)
        
        # Run orchestrator
        result = subprocess.run(
            ["python", "src/generic_orchestrator.py", "test_validation_task.json"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            print("✓ Test workflow executed successfully")
            return True
        else:
            print(f"ERROR: Test workflow failed: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"ERROR: Workflow test failed: {e}")
        return False
    finally:
        # Cleanup test file
        Path("test_validation_task.json").unlink(missing_ok=True)

def main():
    print("=== Cleanup Validation Suite ===\n")
    
    tests = [
        ("Core Files", validate_core_files),
        ("Import Paths", validate_imports),
        ("Directory Structure", validate_structure),
        ("Workflow Execution", run_test_workflow)
    ]
    
    results = []
    for name, test_func in tests:
        print(f"Running: {name}")
        results.append(test_func())
        print()
    
    if all(results):
        print("✅ All validations passed!")
        return 0
    else:
        print("❌ Some validations failed. Review errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
```

### 4.2 Documentation Validation
```bash
# Verify documentation is accessible
ls -la docs/*.md | head -10

# Check for broken internal links in markdown
for file in docs/*.md; do
    grep -o '\[.*\](.*.md)' "$file" | while read link; do
        target=$(echo "$link" | sed 's/.*(\(.*\))/\1/')
        if [ ! -f "docs/$target" ]; then
            echo "Broken link in $file: $target"
        fi
    done
done
```

### 4.3 Performance Comparison
```bash
# Compare directory size before and after
echo "=== Storage Analysis ==="
echo "Before cleanup: Check backup size"
du -sh "$BACKUP_DIR/agent-orchestrator-complete.tar.gz"

echo "After cleanup:"
du -sh /home/opsvi/master_root/apps/agent-orchestrator

# Count files
echo "File counts:"
find . -type f | wc -l
```

## Phase 5: Documentation (15 minutes)

### 5.1 Update README
```markdown
# Addition to README.md

## Directory Structure (Updated: 2025-09-09)

After cleanup and reorganization:

```
agent-orchestrator/
├── src/                  # Core application source code
├── docs/                 # Documentation
├── tests/                # All test files
│   ├── integration/      # Integration tests
│   ├── performance/      # Performance tests
│   └── demos/           # Demo scripts
├── configs/             # Configuration files
│   ├── templates/       # Config templates
│   ├── workflows/       # Workflow configs
│   └── agents/         # Agent configs
├── scripts/            # Utility scripts
│   ├── runners/        # Execution scripts
│   ├── utilities/      # Helper scripts
│   └── analysis/       # Analysis tools
├── web/                # Web interface
├── output/             # Active workflow outputs
└── archive/            # Historical data
    ├── workflows/      # Completed workflows
    ├── logs/          # Archived logs
    └── experimental/   # Old experiments
```

### Maintenance Guidelines

1. **Output Management**: Workflow outputs older than 7 days are automatically archived
2. **Test Organization**: All test files must be placed in appropriate `tests/` subdirectories
3. **Configuration**: Use `configs/` for all configuration files
4. **Scripts**: Utility scripts go in `scripts/` with appropriate categorization
```

### 5.2 Create Change Log
```markdown
# save as: CHANGELOG_CLEANUP.md

# Directory Cleanup Change Log

**Date:** 2025-09-09  
**Version:** Post-Cleanup v2.0

## Summary of Changes

### Removed
- 27 test files from root directory (moved to tests/)
- Duplicate `outputs/` directory (consolidated with `output/`)
- 80+ old log files (archived/compressed)
- Experimental files from root (archived)
- Empty directories and temporary files

### Added
- Organized `tests/` directory with subdirectories
- `configs/` directory for all configuration files
- `scripts/` directory with categorized utilities
- `archive/` structure for historical data
- Archive manifest system

### Modified
- Import paths updated for moved modules
- Documentation updated to reflect new structure
- Workflow output organization standardized

### Statistics
- **Files before:** 1,036
- **Files after:** ~600 (40% reduction)
- **Storage saved:** ~200MB
- **Organization improvement:** 100%

## Migration Notes

### For Developers
1. Test files now in `tests/` directory
2. Runner scripts moved to `scripts/runners/`
3. Import paths updated automatically
4. Use `configs/` for new configuration files

### For Operations
1. Logs auto-archive after 7 days
2. Workflow outputs archive after 7 days
3. Archive manifest tracks all archived content
4. Rollback available via backup

## Rollback Procedure

If issues arise, restore from backup:
```bash
python rollback_cleanup.py /path/to/backup.tar.gz
```
```

### 5.3 Create Maintenance Guide
```markdown
# save as: docs/MAINTENANCE_GUIDE.md

# Agent-Orchestrator Maintenance Guide

## Regular Maintenance Tasks

### Daily
- Monitor `output/` directory size
- Check for failed workflows in logs
- Verify no test files in root

### Weekly
- Run archive script for old outputs
- Compress and archive logs
- Update archive manifest

### Monthly
- Review and clean `archive/` directory
- Analyze storage trends
- Update documentation

## Automated Maintenance Scripts

### Auto-Archive Script
```bash
#!/bin/bash
# Run via cron: 0 2 * * * /path/to/auto_archive.sh

DAYS_OLD=7
BASE_DIR="/home/opsvi/master_root/apps/agent-orchestrator"

# Archive old outputs
find $BASE_DIR/output -maxdepth 1 -type d -mtime +$DAYS_OLD | while read dir; do
    basename=$(basename "$dir")
    tar -czf "$BASE_DIR/archive/workflows/$(date +%Y)/${basename}.tar.gz" "$dir"
    rm -rf "$dir"
done

# Archive old logs
find $BASE_DIR -name "*.log" -mtime +$DAYS_OLD -exec gzip {} \;
find $BASE_DIR -name "*.log.gz" -exec mv {} $BASE_DIR/archive/logs/$(date +%Y)/ \;
```

## Directory Standards

### Naming Conventions
- Workflow outputs: `{task_type}_{timestamp}/`
- Archive files: `{original_name}_{date}.tar.gz`
- Test files: `test_{feature}.py` or `{feature}_test.py`

### File Placement Rules
1. **Never place in root:**
   - Test files
   - Temporary scripts
   - Personal experiments
   
2. **Always use proper directories:**
   - Tests → `tests/`
   - Configs → `configs/`
   - Scripts → `scripts/`
   - Documentation → `docs/`

## Monitoring

### Health Checks
```python
# Check directory health
python scripts/utilities/directory_health.py

# Validate structure
python scripts/utilities/validate_structure.py
```

### Storage Metrics
- Target: < 1GB total size
- Archive threshold: 500MB
- Alert threshold: 800MB
```

## Post-Execution Checklist

### Immediate Verification
- [ ] Core orchestrator starts successfully
- [ ] API endpoints respond
- [ ] Test workflow executes
- [ ] No import errors
- [ ] Documentation accessible

### 24-Hour Monitoring
- [ ] No unexpected errors in logs
- [ ] Workflows execute normally
- [ ] Performance metrics stable
- [ ] No missing file complaints

### Success Metrics
- [ ] 40% reduction in file count
- [ ] Clean, organized structure
- [ ] All core functionality preserved
- [ ] Documentation updated
- [ ] Rollback procedure tested

## Risk Mitigation Summary

### Backup Strategy
1. Complete tar.gz backup before changes
2. Incremental backups during execution
3. Archive preserves all removed content
4. Rollback script ready

### Validation Points
1. After each phase completion
2. Import testing after moves
3. Workflow execution testing
4. Performance comparison

### Recovery Options
1. **Full Rollback**: Restore from complete backup
2. **Partial Recovery**: Retrieve from archive
3. **Selective Restore**: Extract specific files from backup

## Execution Commands Summary

```bash
# Phase 1: Preparation
./prepare_cleanup.sh

# Phase 2: Archive
python archive_old_content.py

# Phase 3: Reorganize
python reorganize_structure.py

# Phase 4: Validate
python validate_cleanup.py

# Phase 5: Document
./update_documentation.sh

# If needed: Rollback
python rollback_cleanup.py $BACKUP_DIR/agent-orchestrator-complete.tar.gz
```

## Expected Outcome

### Before
- 1,036 files across 313 directories
- Mixed test/production code
- Duplicate output directories
- Scattered configuration

### After
- ~600 files organized properly
- Clear separation of concerns
- Single output directory
- Centralized configuration
- Complete archive of historical data

## Approval Gate

**Before executing this plan:**
1. Review all phases with stakeholders
2. Confirm backup location and accessibility
3. Schedule maintenance window
4. Notify team of changes
5. Test rollback procedure

---

**Plan Status:** READY FOR EXECUTION  
**Risk Assessment:** MEDIUM (Mitigated via backups)  
**Confidence Level:** HIGH (95%)  
**Recommended Execution Window:** Off-peak hours