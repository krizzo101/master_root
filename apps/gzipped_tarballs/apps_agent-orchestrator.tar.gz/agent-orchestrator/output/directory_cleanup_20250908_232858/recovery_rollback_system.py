#!/usr/bin/env python3
"""
Recovery and Rollback System for Safe Cleanup Operations
Provides comprehensive recovery mechanisms and rollback capabilities
"""

import os
import json
import shutil
import subprocess
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import tarfile
import zipfile
import tempfile

class RecoveryRollbackSystem:
    """Complete recovery and rollback system for cleanup operations"""
    
    def __init__(self, project_root: str, backup_root: str = None):
        self.project_root = Path(project_root).resolve()
        self.backup_root = Path(backup_root or f"/tmp/cleanup_recovery_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.rollback_history = []
        self.recovery_points = []
        self.current_state = None
        
        # Initialize backup structure
        self._initialize_backup_structure()
        
    def _initialize_backup_structure(self):
        """Initialize the backup directory structure"""
        self.backup_root.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        (self.backup_root / "full_backups").mkdir(exist_ok=True)
        (self.backup_root / "incremental").mkdir(exist_ok=True)
        (self.backup_root / "rollback_points").mkdir(exist_ok=True)
        (self.backup_root / "recovery_logs").mkdir(exist_ok=True)
        (self.backup_root / "state_snapshots").mkdir(exist_ok=True)
        
        # Initialize recovery manifest
        self.recovery_manifest = self.backup_root / "recovery_manifest.json"
        if not self.recovery_manifest.exists():
            manifest = {
                "created": datetime.now().isoformat(),
                "project_root": str(self.project_root),
                "backup_root": str(self.backup_root),
                "recovery_points": [],
                "rollback_history": []
            }
            with open(self.recovery_manifest, 'w') as f:
                json.dump(manifest, f, indent=2)
                
    def create_recovery_point(self, 
                            point_name: str, 
                            description: str,
                            backup_type: str = "incremental") -> Dict:
        """Create a recovery point with specified backup type"""
        print(f"\n🔄 Creating recovery point: {point_name}")
        
        recovery_id = f"{point_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        recovery_info = {
            "id": recovery_id,
            "name": point_name,
            "description": description,
            "timestamp": datetime.now().isoformat(),
            "backup_type": backup_type,
            "backup_location": None,
            "state_snapshot": None,
            "file_count": 0,
            "size_bytes": 0,
            "checksum": None,
            "status": "creating"
        }
        
        try:
            if backup_type == "full":
                backup_path = self._create_full_backup(recovery_id)
            elif backup_type == "incremental":
                backup_path = self._create_incremental_backup(recovery_id)
            elif backup_type == "snapshot":
                backup_path = self._create_state_snapshot(recovery_id)
            else:
                raise ValueError(f"Unknown backup type: {backup_type}")
                
            recovery_info["backup_location"] = str(backup_path)
            recovery_info["size_bytes"] = backup_path.stat().st_size
            recovery_info["checksum"] = self._calculate_checksum(backup_path)
            recovery_info["status"] = "completed"
            
            # Count files in backup
            if backup_path.suffix in ['.tar', '.gz', '.tgz']:
                recovery_info["file_count"] = self._count_tar_files(backup_path)
            elif backup_path.suffix == '.zip':
                recovery_info["file_count"] = self._count_zip_files(backup_path)
                
            # Save state snapshot
            state_snapshot = self._capture_state_snapshot()
            snapshot_path = self.backup_root / "state_snapshots" / f"{recovery_id}_state.json"
            with open(snapshot_path, 'w') as f:
                json.dump(state_snapshot, f, indent=2)
            recovery_info["state_snapshot"] = str(snapshot_path)
            
            # Update recovery manifest
            self._update_manifest(recovery_info)
            self.recovery_points.append(recovery_info)
            
            print(f"✅ Recovery point created: {recovery_id}")
            print(f"   - Type: {backup_type}")
            print(f"   - Files: {recovery_info['file_count']}")
            print(f"   - Size: {recovery_info['size_bytes'] / (1024*1024):.2f} MB")
            
        except Exception as e:
            recovery_info["status"] = "failed"
            recovery_info["error"] = str(e)
            print(f"❌ Failed to create recovery point: {e}")
            
        return recovery_info
    
    def _create_full_backup(self, recovery_id: str) -> Path:
        """Create a full backup of the project"""
        backup_path = self.backup_root / "full_backups" / f"{recovery_id}.tar.gz"
        
        # Create tar archive
        with tarfile.open(backup_path, "w:gz") as tar:
            tar.add(self.project_root, arcname=self.project_root.name)
            
        return backup_path
    
    def _create_incremental_backup(self, recovery_id: str) -> Path:
        """Create an incremental backup of changed files"""
        backup_path = self.backup_root / "incremental" / f"{recovery_id}.tar.gz"
        
        # Get list of changed files (simplified - in practice, compare with last backup)
        changed_files = self._get_changed_files()
        
        # Create tar archive with only changed files
        with tarfile.open(backup_path, "w:gz") as tar:
            for file_path in changed_files:
                if file_path.exists():
                    tar.add(file_path, arcname=file_path.relative_to(self.project_root.parent))
                    
        return backup_path
    
    def _create_state_snapshot(self, recovery_id: str) -> Path:
        """Create a lightweight state snapshot"""
        snapshot_path = self.backup_root / "state_snapshots" / f"{recovery_id}_snapshot.json"
        
        snapshot = self._capture_state_snapshot()
        
        with open(snapshot_path, 'w') as f:
            json.dump(snapshot, f, indent=2)
            
        return snapshot_path
    
    def _capture_state_snapshot(self) -> Dict:
        """Capture current state snapshot"""
        snapshot = {
            "timestamp": datetime.now().isoformat(),
            "files": {},
            "directories": [],
            "permissions": {},
            "git_status": None
        }
        
        # Capture file information
        for root, dirs, files in os.walk(self.project_root):
            # Skip .git directory
            if '.git' in root:
                continue
                
            rel_root = Path(root).relative_to(self.project_root)
            snapshot["directories"].append(str(rel_root))
            
            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(self.project_root)
                
                try:
                    stat = file_path.stat()
                    snapshot["files"][str(rel_path)] = {
                        "size": stat.st_size,
                        "mtime": stat.st_mtime,
                        "mode": oct(stat.st_mode),
                        "checksum": self._calculate_file_checksum(file_path) if stat.st_size < 1024*1024 else None
                    }
                except:
                    pass
                    
        # Capture git status if available
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                snapshot["git_status"] = result.stdout
        except:
            pass
            
        return snapshot
    
    def _get_changed_files(self) -> List[Path]:
        """Get list of changed files since last backup"""
        changed_files = []
        
        # If we have a previous snapshot, compare with it
        if self.recovery_points:
            last_point = self.recovery_points[-1]
            if last_point.get("state_snapshot"):
                try:
                    with open(last_point["state_snapshot"], 'r') as f:
                        last_snapshot = json.load(f)
                        
                    current_snapshot = self._capture_state_snapshot()
                    
                    # Find changed files
                    for file_path, file_info in current_snapshot["files"].items():
                        last_info = last_snapshot["files"].get(file_path)
                        if not last_info or last_info["checksum"] != file_info.get("checksum"):
                            changed_files.append(self.project_root / file_path)
                            
                except:
                    # If comparison fails, backup everything
                    changed_files = list(self.project_root.glob("**/*"))
        else:
            # First backup - include everything
            changed_files = list(self.project_root.glob("**/*"))
            
        return [f for f in changed_files if f.is_file()]
    
    def execute_rollback(self, 
                        recovery_point_id: str = None,
                        force: bool = False) -> Tuple[bool, str]:
        """Execute rollback to specified recovery point"""
        print(f"\n🔄 Executing rollback{f' to {recovery_point_id}' if recovery_point_id else ' to latest point'}...")
        
        # Find recovery point
        if recovery_point_id:
            recovery_point = self._find_recovery_point(recovery_point_id)
        else:
            # Use latest recovery point
            if not self.recovery_points:
                return False, "No recovery points available"
            recovery_point = self.recovery_points[-1]
            
        if not recovery_point:
            return False, f"Recovery point not found: {recovery_point_id}"
            
        # Verify backup integrity
        if not self._verify_backup_integrity(recovery_point):
            if not force:
                return False, "Backup integrity verification failed"
            print("⚠️ Forcing rollback despite integrity check failure")
            
        # Create pre-rollback backup
        pre_rollback = self.create_recovery_point(
            "pre_rollback",
            f"Automatic backup before rollback to {recovery_point['id']}",
            backup_type="snapshot"
        )
        
        try:
            # Execute the rollback
            success = self._perform_rollback(recovery_point)
            
            if success:
                # Record rollback in history
                rollback_record = {
                    "timestamp": datetime.now().isoformat(),
                    "from_point": pre_rollback["id"],
                    "to_point": recovery_point["id"],
                    "status": "success"
                }
                self.rollback_history.append(rollback_record)
                self._update_manifest(rollback_record, record_type="rollback")
                
                print(f"✅ Rollback completed successfully to: {recovery_point['id']}")
                return True, f"Rollback successful to {recovery_point['id']}"
            else:
                print("❌ Rollback failed")
                return False, "Rollback execution failed"
                
        except Exception as e:
            print(f"❌ Rollback error: {e}")
            
            # Attempt to restore pre-rollback state
            print("🔄 Attempting to restore pre-rollback state...")
            self._perform_rollback(pre_rollback)
            
            return False, f"Rollback failed: {e}"
    
    def _perform_rollback(self, recovery_point: Dict) -> bool:
        """Perform the actual rollback operation"""
        backup_path = Path(recovery_point["backup_location"])
        
        if not backup_path.exists():
            print(f"❌ Backup file not found: {backup_path}")
            return False
            
        try:
            if recovery_point["backup_type"] in ["full", "incremental"]:
                # Extract tar backup
                if backup_path.suffix in ['.tar', '.gz', '.tgz']:
                    # Clear existing directory (dangerous - only in controlled environment)
                    if recovery_point["backup_type"] == "full":
                        # Create temporary backup of current state
                        temp_backup = tempfile.mkdtemp(prefix="rollback_temp_")
                        shutil.copytree(self.project_root, temp_backup, dirs_exist_ok=True)
                        
                        try:
                            # Extract backup
                            with tarfile.open(backup_path, "r:*") as tar:
                                tar.extractall(self.project_root.parent)
                            
                            # Remove temporary backup on success
                            shutil.rmtree(temp_backup)
                            
                        except Exception as e:
                            # Restore from temporary backup on failure
                            shutil.copytree(temp_backup, self.project_root, dirs_exist_ok=True)
                            shutil.rmtree(temp_backup)
                            raise e
                            
                    else:
                        # Incremental - just extract over existing
                        with tarfile.open(backup_path, "r:*") as tar:
                            tar.extractall(self.project_root.parent)
                            
            elif recovery_point["backup_type"] == "snapshot":
                # For snapshot, we need to restore from another backup
                # This is more complex and would require file-by-file restoration
                print("⚠️ Snapshot rollback requires manual intervention")
                return False
                
            return True
            
        except Exception as e:
            print(f"❌ Rollback extraction failed: {e}")
            return False
    
    def selective_restore(self, 
                         recovery_point_id: str,
                         file_patterns: List[str]) -> Tuple[bool, List[str]]:
        """Selectively restore specific files from a recovery point"""
        print(f"\n📁 Selective restore from: {recovery_point_id}")
        print(f"   Patterns: {file_patterns}")
        
        recovery_point = self._find_recovery_point(recovery_point_id)
        if not recovery_point:
            return False, [f"Recovery point not found: {recovery_point_id}"]
            
        backup_path = Path(recovery_point["backup_location"])
        if not backup_path.exists():
            return False, [f"Backup file not found: {backup_path}"]
            
        restored_files = []
        errors = []
        
        try:
            with tarfile.open(backup_path, "r:*") as tar:
                members = tar.getmembers()
                
                for pattern in file_patterns:
                    matching_members = [m for m in members if pattern in m.name]
                    
                    for member in matching_members:
                        try:
                            tar.extract(member, self.project_root.parent)
                            restored_files.append(member.name)
                            print(f"  ✅ Restored: {member.name}")
                        except Exception as e:
                            errors.append(f"Failed to restore {member.name}: {e}")
                            
        except Exception as e:
            errors.append(f"Archive error: {e}")
            
        if restored_files:
            print(f"\n✅ Restored {len(restored_files)} files")
            
        if errors:
            print(f"\n⚠️ {len(errors)} errors during restoration")
            for error in errors:
                print(f"  - {error}")
                
        return len(restored_files) > 0, restored_files if restored_files else errors
    
    def verify_recovery_integrity(self) -> Dict:
        """Verify integrity of all recovery points"""
        print("\n🔍 Verifying recovery point integrity...")
        
        verification_report = {
            "timestamp": datetime.now().isoformat(),
            "total_points": len(self.recovery_points),
            "valid_points": 0,
            "corrupted_points": 0,
            "missing_points": 0,
            "details": []
        }
        
        for recovery_point in self.recovery_points:
            point_status = {
                "id": recovery_point["id"],
                "name": recovery_point["name"],
                "status": "unknown",
                "issues": []
            }
            
            # Check if backup file exists
            backup_path = Path(recovery_point["backup_location"])
            if not backup_path.exists():
                point_status["status"] = "missing"
                point_status["issues"].append("Backup file not found")
                verification_report["missing_points"] += 1
            else:
                # Verify checksum
                current_checksum = self._calculate_checksum(backup_path)
                if current_checksum != recovery_point.get("checksum"):
                    point_status["status"] = "corrupted"
                    point_status["issues"].append("Checksum mismatch")
                    verification_report["corrupted_points"] += 1
                else:
                    # Try to read the archive
                    if self._verify_archive_readable(backup_path):
                        point_status["status"] = "valid"
                        verification_report["valid_points"] += 1
                    else:
                        point_status["status"] = "corrupted"
                        point_status["issues"].append("Archive not readable")
                        verification_report["corrupted_points"] += 1
                        
            verification_report["details"].append(point_status)
            
        # Print summary
        print(f"\n📊 Verification Summary:")
        print(f"  Total Points: {verification_report['total_points']}")
        print(f"  ✅ Valid: {verification_report['valid_points']}")
        print(f"  ❌ Corrupted: {verification_report['corrupted_points']}")
        print(f"  ⚠️ Missing: {verification_report['missing_points']}")
        
        return verification_report
    
    def _find_recovery_point(self, recovery_id: str) -> Optional[Dict]:
        """Find a recovery point by ID or name"""
        for point in self.recovery_points:
            if point["id"] == recovery_id or point["name"] == recovery_id:
                return point
        return None
    
    def _verify_backup_integrity(self, recovery_point: Dict) -> bool:
        """Verify backup file integrity"""
        backup_path = Path(recovery_point["backup_location"])
        
        if not backup_path.exists():
            return False
            
        # Verify checksum
        current_checksum = self._calculate_checksum(backup_path)
        if current_checksum != recovery_point.get("checksum"):
            print(f"⚠️ Checksum mismatch for {recovery_point['id']}")
            return False
            
        # Verify archive is readable
        return self._verify_archive_readable(backup_path)
    
    def _verify_archive_readable(self, archive_path: Path) -> bool:
        """Verify that an archive can be read"""
        try:
            if archive_path.suffix in ['.tar', '.gz', '.tgz']:
                with tarfile.open(archive_path, "r:*") as tar:
                    tar.getmembers()
            elif archive_path.suffix == '.zip':
                with zipfile.ZipFile(archive_path, 'r') as zip_file:
                    zip_file.namelist()
            else:
                # For JSON snapshots
                if archive_path.suffix == '.json':
                    with open(archive_path, 'r') as f:
                        json.load(f)
                        
            return True
        except:
            return False
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA256 checksum of a file"""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _calculate_file_checksum(self, file_path: Path) -> str:
        """Calculate checksum for a small file"""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except:
            return ""
    
    def _count_tar_files(self, tar_path: Path) -> int:
        """Count files in a tar archive"""
        try:
            with tarfile.open(tar_path, "r:*") as tar:
                return len([m for m in tar.getmembers() if m.isfile()])
        except:
            return 0
    
    def _count_zip_files(self, zip_path: Path) -> int:
        """Count files in a zip archive"""
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_file:
                return len(zip_file.namelist())
        except:
            return 0
    
    def _update_manifest(self, data: Dict, record_type: str = "recovery_point"):
        """Update the recovery manifest"""
        try:
            with open(self.recovery_manifest, 'r') as f:
                manifest = json.load(f)
                
            if record_type == "recovery_point":
                manifest["recovery_points"].append(data)
            elif record_type == "rollback":
                manifest["rollback_history"].append(data)
                
            manifest["last_updated"] = datetime.now().isoformat()
            
            with open(self.recovery_manifest, 'w') as f:
                json.dump(manifest, f, indent=2, default=str)
        except Exception as e:
            print(f"⚠️ Failed to update manifest: {e}")
    
    def generate_recovery_report(self) -> Path:
        """Generate comprehensive recovery report"""
        report_path = self.backup_root / "recovery_report.md"
        
        report_content = f"""# Recovery and Rollback System Report

Generated: {datetime.now().isoformat()}

## System Configuration
- Project Root: `{self.project_root}`
- Backup Root: `{self.backup_root}`
- Recovery Manifest: `{self.recovery_manifest}`

## Recovery Points ({len(self.recovery_points)})

| ID | Name | Type | Size (MB) | Files | Status | Created |
|----|------|------|-----------|-------|---------|---------|
"""
        
        for point in self.recovery_points:
            size_mb = point.get("size_bytes", 0) / (1024*1024)
            report_content += f"| {point['id']} | {point['name']} | {point['backup_type']} | "
            report_content += f"{size_mb:.2f} | {point.get('file_count', 0)} | "
            report_content += f"{point.get('status', 'unknown')} | {point['timestamp']} |\n"
            
        report_content += f"""

## Rollback History ({len(self.rollback_history)})

"""
        
        if self.rollback_history:
            report_content += "| Timestamp | From Point | To Point | Status |\n"
            report_content += "|-----------|------------|----------|--------|\n"
            
            for rollback in self.rollback_history:
                report_content += f"| {rollback['timestamp']} | {rollback['from_point']} | "
                report_content += f"{rollback['to_point']} | {rollback['status']} |\n"
        else:
            report_content += "No rollbacks performed.\n"
            
        report_content += """

## Recovery Procedures

### Full Rollback
```bash
python recovery_rollback_system.py --rollback <recovery_point_id>
```

### Selective Restore
```bash
python recovery_rollback_system.py --selective-restore <recovery_point_id> --patterns "*.py" "*.json"
```

### Verify Integrity
```bash
python recovery_rollback_system.py --verify
```

## Emergency Recovery

If automated recovery fails:

1. Locate backup files in: `{}`
2. Extract manually: `tar -xzf <backup_file> -C {}`
3. Verify restoration: Run functionality tests
4. Update manifest manually if needed

""".format(self.backup_root / "full_backups", self.project_root.parent)
        
        with open(report_path, 'w') as f:
            f.write(report_content)
            
        print(f"\n📄 Recovery report generated: {report_path}")
        return report_path


def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Recovery and Rollback System")
    parser.add_argument("--project-root", default="../..", help="Project root directory")
    parser.add_argument("--backup-root", help="Backup root directory")
    parser.add_argument("--create-point", help="Create recovery point with name")
    parser.add_argument("--description", help="Recovery point description")
    parser.add_argument("--backup-type", choices=["full", "incremental", "snapshot"], 
                       default="incremental", help="Backup type")
    parser.add_argument("--rollback", help="Rollback to recovery point")
    parser.add_argument("--selective-restore", help="Selective restore from point")
    parser.add_argument("--patterns", nargs="+", help="File patterns for selective restore")
    parser.add_argument("--verify", action="store_true", help="Verify all recovery points")
    parser.add_argument("--report", action="store_true", help="Generate recovery report")
    parser.add_argument("--force", action="store_true", help="Force operation despite warnings")
    
    args = parser.parse_args()
    
    # Initialize recovery system
    recovery_system = RecoveryRollbackSystem(
        project_root=args.project_root,
        backup_root=args.backup_root
    )
    
    # Load existing recovery points from manifest
    if recovery_system.recovery_manifest.exists():
        with open(recovery_system.recovery_manifest, 'r') as f:
            manifest = json.load(f)
            recovery_system.recovery_points = manifest.get("recovery_points", [])
            recovery_system.rollback_history = manifest.get("rollback_history", [])
    
    # Execute requested operation
    if args.create_point:
        recovery_system.create_recovery_point(
            point_name=args.create_point,
            description=args.description or f"Recovery point: {args.create_point}",
            backup_type=args.backup_type
        )
        
    elif args.rollback:
        success, message = recovery_system.execute_rollback(
            recovery_point_id=args.rollback,
            force=args.force
        )
        print(f"\n{message}")
        return 0 if success else 1
        
    elif args.selective_restore and args.patterns:
        success, results = recovery_system.selective_restore(
            recovery_point_id=args.selective_restore,
            file_patterns=args.patterns
        )
        return 0 if success else 1
        
    elif args.verify:
        verification = recovery_system.verify_recovery_integrity()
        return 0 if verification["valid_points"] == verification["total_points"] else 1
        
    elif args.report:
        recovery_system.generate_recovery_report()
        
    else:
        parser.print_help()
        
    return 0


if __name__ == "__main__":
    exit(main())