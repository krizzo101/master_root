#!/usr/bin/env python3
"""
Phase 4: Validation
Comprehensive validation of cleanup and reorganization
"""

import sys
import subprocess
import json
import os
from pathlib import Path
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('validation_phase.log'),
        logging.StreamHandler()
    ]
)

BASE_DIR = Path("/home/opsvi/master_root/apps/agent-orchestrator")

class CleanupValidator:
    def __init__(self):
        self.results = {
            "core_files": {"status": "pending", "details": []},
            "imports": {"status": "pending", "details": []},
            "structure": {"status": "pending", "details": []},
            "workflows": {"status": "pending", "details": []},
            "documentation": {"status": "pending", "details": []},
            "performance": {"status": "pending", "details": {}}
        }
        self.critical_errors = []
        
    def validate_core_files(self):
        """Ensure all core files still exist and are accessible"""
        logging.info("Validating core files...")
        
        core_files = [
            "main.py",
            "orchestrator_api.py",
            "src/generic_orchestrator.py",
            "src/enhanced_orchestrator.py",
            "src/collaborative_orchestrator.py",
            "README.md",
            ".gitignore"
        ]
        
        missing_files = []
        accessible_files = []
        
        for file_path in core_files:
            full_path = BASE_DIR / file_path
            if full_path.exists():
                if os.access(full_path, os.R_OK):
                    accessible_files.append(file_path)
                else:
                    missing_files.append(f"{file_path} (not readable)")
            else:
                missing_files.append(file_path)
        
        if missing_files:
            self.results["core_files"]["status"] = "FAILED"
            self.results["core_files"]["details"] = missing_files
            self.critical_errors.append(f"Missing core files: {missing_files}")
            logging.error(f"Missing core files: {missing_files}")
            return False
        else:
            self.results["core_files"]["status"] = "PASSED"
            self.results["core_files"]["details"] = accessible_files
            logging.info("✓ All core files present and accessible")
            return True
    
    def validate_imports(self):
        """Test that Python imports work correctly"""
        logging.info("Validating Python imports...")
        
        test_imports = [
            "from src.generic_orchestrator import GenericOrchestrator",
            "from src.enhanced_orchestrator import EnhancedOrchestrator",
            "import asyncio",
            "import json"
        ]
        
        failed_imports = []
        
        for import_statement in test_imports:
            try:
                result = subprocess.run(
                    ["python", "-c", import_statement],
                    cwd=BASE_DIR,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode != 0:
                    failed_imports.append({
                        "import": import_statement,
                        "error": result.stderr.strip()
                    })
                    
            except subprocess.TimeoutExpired:
                failed_imports.append({
                    "import": import_statement,
                    "error": "Timeout"
                })
            except Exception as e:
                failed_imports.append({
                    "import": import_statement,
                    "error": str(e)
                })
        
        if failed_imports:
            self.results["imports"]["status"] = "FAILED"
            self.results["imports"]["details"] = failed_imports
            self.critical_errors.append(f"Import failures: {len(failed_imports)}")
            logging.error(f"Failed imports: {failed_imports}")
            return False
        else:
            self.results["imports"]["status"] = "PASSED"
            self.results["imports"]["details"] = test_imports
            logging.info("✓ All imports working correctly")
            return True
    
    def validate_structure(self):
        """Verify the expected directory structure exists"""
        logging.info("Validating directory structure...")
        
        expected_dirs = {
            "src": "Core source code",
            "docs": "Documentation",
            "tests": "Test files",
            "archive": "Archived content",
            "output": "Workflow outputs",
            "web": "Web interface"
        }
        
        optional_dirs = {
            "configs": "Configuration files",
            "scripts": "Utility scripts"
        }
        
        missing_required = []
        missing_optional = []
        present_dirs = []
        
        for dir_name, description in expected_dirs.items():
            dir_path = BASE_DIR / dir_name
            if dir_path.exists() and dir_path.is_dir():
                present_dirs.append(f"{dir_name}: {description}")
            else:
                missing_required.append(f"{dir_name}: {description}")
        
        for dir_name, description in optional_dirs.items():
            dir_path = BASE_DIR / dir_name
            if not (dir_path.exists() and dir_path.is_dir()):
                missing_optional.append(f"{dir_name}: {description}")
            else:
                present_dirs.append(f"{dir_name}: {description}")
        
        if missing_required:
            self.results["structure"]["status"] = "FAILED"
            self.results["structure"]["details"] = {
                "missing_required": missing_required,
                "missing_optional": missing_optional,
                "present": present_dirs
            }
            self.critical_errors.append(f"Missing required directories: {missing_required}")
            logging.error(f"Missing required directories: {missing_required}")
            return False
        else:
            self.results["structure"]["status"] = "PASSED"
            self.results["structure"]["details"] = {
                "present": present_dirs,
                "missing_optional": missing_optional
            }
            if missing_optional:
                logging.warning(f"Missing optional directories: {missing_optional}")
            logging.info(f"✓ Directory structure validated ({len(present_dirs)} directories)")
            return True
    
    def validate_workflow_execution(self):
        """Test that a simple workflow can execute"""
        logging.info("Testing workflow execution...")
        
        # Create a simple test task
        test_task = {
            "task_type": "validation_test",
            "task_id": f"cleanup_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "prompt": "echo 'Cleanup validation test successful'",
            "context": {
                "test": True,
                "validation_phase": 4
            }
        }
        
        test_file = BASE_DIR / "validation_test_task.json"
        
        try:
            # Save test task
            with open(test_file, 'w') as f:
                json.dump(test_task, f, indent=2)
            
            # Try to run with generic orchestrator
            result = subprocess.run(
                ["python", "src/generic_orchestrator.py", str(test_file)],
                cwd=BASE_DIR,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.results["workflows"]["status"] = "PASSED"
                self.results["workflows"]["details"] = {
                    "test_task": test_task["task_id"],
                    "output": result.stdout[:200] if result.stdout else "Success"
                }
                logging.info("✓ Workflow execution test passed")
                return True
            else:
                self.results["workflows"]["status"] = "FAILED"
                self.results["workflows"]["details"] = {
                    "error": result.stderr[:500] if result.stderr else "Unknown error",
                    "return_code": result.returncode
                }
                logging.error(f"Workflow test failed: {result.stderr[:200]}")
                return False
                
        except subprocess.TimeoutExpired:
            self.results["workflows"]["status"] = "FAILED"
            self.results["workflows"]["details"] = {"error": "Timeout after 30 seconds"}
            logging.error("Workflow test timed out")
            return False
            
        except Exception as e:
            self.results["workflows"]["status"] = "FAILED"
            self.results["workflows"]["details"] = {"error": str(e)}
            logging.error(f"Workflow test exception: {e}")
            return False
            
        finally:
            # Cleanup test file
            if test_file.exists():
                test_file.unlink()
    
    def validate_documentation(self):
        """Check documentation integrity"""
        logging.info("Validating documentation...")
        
        required_docs = [
            "README.md",
            "docs/ARCHITECTURE.md",
            "docs/API_REFERENCE.md"
        ]
        
        missing_docs = []
        broken_links = []
        doc_stats = {}
        
        for doc_path in required_docs:
            full_path = BASE_DIR / doc_path
            if full_path.exists():
                # Check file size
                size = full_path.stat().st_size
                doc_stats[doc_path] = f"{size} bytes"
                
                # Check for broken internal links
                if doc_path.endswith('.md'):
                    content = full_path.read_text()
                    # Find markdown links
                    import re
                    links = re.findall(r'\[.*?\]\((.*?\.md)\)', content)
                    
                    for link in links:
                        # Resolve relative links
                        if not link.startswith('/'):
                            link_path = (full_path.parent / link).resolve()
                        else:
                            link_path = BASE_DIR / link.lstrip('/')
                        
                        if not link_path.exists():
                            broken_links.append(f"{doc_path} -> {link}")
            else:
                missing_docs.append(doc_path)
        
        if missing_docs:
            self.results["documentation"]["status"] = "FAILED"
            self.results["documentation"]["details"] = {
                "missing": missing_docs,
                "broken_links": broken_links
            }
            logging.error(f"Missing documentation: {missing_docs}")
            return False
        else:
            self.results["documentation"]["status"] = "PASSED"
            self.results["documentation"]["details"] = {
                "stats": doc_stats,
                "broken_links": broken_links
            }
            if broken_links:
                logging.warning(f"Broken links found: {broken_links}")
            logging.info("✓ Documentation validated")
            return True
    
    def calculate_performance_metrics(self):
        """Calculate storage and performance metrics"""
        logging.info("Calculating performance metrics...")
        
        # Count files and directories
        file_count = 0
        dir_count = 0
        total_size = 0
        
        for root, dirs, files in os.walk(BASE_DIR):
            # Skip archive in metrics
            if 'archive' not in root:
                dir_count += len(dirs)
                file_count += len(files)
                
                for file in files:
                    file_path = Path(root) / file
                    try:
                        total_size += file_path.stat().st_size
                    except:
                        pass
        
        # File type distribution
        file_types = {}
        for file_path in BASE_DIR.rglob('*'):
            if file_path.is_file() and 'archive' not in str(file_path):
                ext = file_path.suffix or 'no_extension'
                file_types[ext] = file_types.get(ext, 0) + 1
        
        self.results["performance"]["status"] = "COMPLETED"
        self.results["performance"]["details"] = {
            "total_files": file_count,
            "total_directories": dir_count,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "file_types": dict(sorted(file_types.items(), key=lambda x: x[1], reverse=True)[:10])
        }
        
        logging.info(f"Performance metrics calculated:")
        logging.info(f"  Files: {file_count}")
        logging.info(f"  Directories: {dir_count}")
        logging.info(f"  Total size: {self.results['performance']['details']['total_size_mb']} MB")
        
        return True
    
    def generate_validation_report(self):
        """Generate comprehensive validation report"""
        report = {
            "validation_date": datetime.now().isoformat(),
            "overall_status": "PASSED" if not self.critical_errors else "FAILED",
            "critical_errors": self.critical_errors,
            "results": self.results,
            "recommendations": []
        }
        
        # Add recommendations based on results
        if self.results["imports"]["status"] == "FAILED":
            report["recommendations"].append("Fix import paths before proceeding")
        
        if self.results["workflows"]["status"] == "FAILED":
            report["recommendations"].append("Debug workflow execution issues")
        
        if self.results["performance"]["details"]:
            metrics = self.results["performance"]["details"]
            if metrics["total_files"] > 800:
                report["recommendations"].append("Consider additional archiving")
            if metrics["total_size_mb"] > 1000:
                report["recommendations"].append("Storage optimization recommended")
        
        # Save report
        report_file = BASE_DIR / "VALIDATION_REPORT.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        logging.info(f"Validation report saved: {report_file}")
        return report
    
    def run_validation_phase(self):
        """Execute complete validation phase"""
        logging.info("="*50)
        logging.info("PHASE 4: VALIDATION - Starting")
        logging.info("="*50)
        
        # Run all validations
        tests = [
            ("Core Files", self.validate_core_files),
            ("Import Paths", self.validate_imports),
            ("Directory Structure", self.validate_structure),
            ("Workflow Execution", self.validate_workflow_execution),
            ("Documentation", self.validate_documentation),
            ("Performance Metrics", self.calculate_performance_metrics)
        ]
        
        all_passed = True
        for test_name, test_func in tests:
            logging.info(f"\nRunning: {test_name}")
            passed = test_func()
            if not passed and test_name != "Performance Metrics":
                all_passed = False
        
        # Generate report
        report = self.generate_validation_report()
        
        # Summary
        logging.info("="*50)
        logging.info("VALIDATION PHASE COMPLETE")
        logging.info("="*50)
        
        if all_passed:
            logging.info("✅ All validations PASSED!")
        else:
            logging.error(f"❌ Validation FAILED with {len(self.critical_errors)} critical errors")
            for error in self.critical_errors:
                logging.error(f"  - {error}")
        
        # Save completion flag
        flag_file = BASE_DIR / "phase4_complete.flag"
        with open(flag_file, 'w') as f:
            f.write(f"PHASE_4_COMPLETE\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write(f"Status: {'PASSED' if all_passed else 'FAILED'}\n")
            f.write(f"Critical Errors: {len(self.critical_errors)}\n")
        
        return all_passed

def main():
    """Main execution"""
    validator = CleanupValidator()
    
    try:
        all_passed = validator.run_validation_phase()
        
        if all_passed:
            print("\n✅ CLEANUP VALIDATION SUCCESSFUL")
            print("The directory has been successfully cleaned and reorganized.")
            print("All core functionality has been preserved.")
            sys.exit(0)
        else:
            print("\n❌ CLEANUP VALIDATION FAILED")
            print(f"Critical errors detected: {len(validator.critical_errors)}")
            print("Review VALIDATION_REPORT.json for details.")
            print("Consider running rollback if necessary.")
            sys.exit(1)
            
    except Exception as e:
        logging.error(f"Validation phase crashed: {e}")
        print(f"\n💥 VALIDATION CRASHED: {e}")
        sys.exit(2)

if __name__ == "__main__":
    main()