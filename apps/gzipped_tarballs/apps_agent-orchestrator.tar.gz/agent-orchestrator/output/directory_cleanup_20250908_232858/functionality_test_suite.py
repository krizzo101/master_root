#!/usr/bin/env python3
"""
Comprehensive Functionality Testing Suite for Cleanup Validation
Ensures all critical system functions work before and after cleanup
"""

import os
import sys
import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import importlib.util
import traceback

class FunctionalityTestSuite:
    """Complete testing suite for system functionality validation"""
    
    def __init__(self, project_root: str):
        self.project_root = Path(project_root).resolve()
        self.test_results = {
            "timestamp": datetime.now().isoformat(),
            "total_tests": 0,
            "passed": 0,
            "failed": 0,
            "skipped": 0,
            "critical_failures": [],
            "test_details": []
        }
        self.temp_dir = None
        
    def run_all_tests(self) -> Dict:
        """Run complete test suite"""
        print("=" * 80)
        print("FUNCTIONALITY TEST SUITE")
        print("=" * 80)
        
        test_categories = [
            ("Core Orchestrator", self._test_core_orchestrator),
            ("Python Modules", self._test_python_modules),
            ("API Endpoints", self._test_api_endpoints),
            ("Configuration Loading", self._test_configuration_loading),
            ("File Operations", self._test_file_operations),
            ("Workflow Execution", self._test_workflow_execution),
            ("Agent System", self._test_agent_system),
            ("Integration Points", self._test_integration_points),
            ("Database Connectivity", self._test_database_connectivity),
            ("External Dependencies", self._test_external_dependencies)
        ]
        
        for category_name, test_func in test_categories:
            print(f"\n📋 Testing: {category_name}")
            print("-" * 40)
            
            try:
                category_results = test_func()
                self._update_results(category_results)
            except Exception as e:
                print(f"  ❌ Category test failed: {e}")
                self.test_results["critical_failures"].append({
                    "category": category_name,
                    "error": str(e),
                    "traceback": traceback.format_exc()
                })
                
        # Calculate final status
        self.test_results["success_rate"] = (
            self.test_results["passed"] / self.test_results["total_tests"] * 100
            if self.test_results["total_tests"] > 0 else 0
        )
        
        self._print_summary()
        return self.test_results
    
    def _test_core_orchestrator(self) -> Dict:
        """Test core orchestrator functionality"""
        results = {
            "category": "core_orchestrator",
            "tests": []
        }
        
        # Test 1: Check orchestrator files exist
        orchestrator_files = [
            "src/generic_orchestrator.py",
            "src/dpo_main_controller.py",
            "src/dpo_orchestrator_integration.py"
        ]
        
        for file_path in orchestrator_files:
            full_path = self.project_root / file_path
            test_result = {
                "name": f"File exists: {file_path}",
                "passed": full_path.exists(),
                "error": None if full_path.exists() else "File not found"
            }
            results["tests"].append(test_result)
            print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
            
        # Test 2: Check if orchestrator can be imported
        orchestrator_path = self.project_root / "src" / "generic_orchestrator.py"
        if orchestrator_path.exists():
            test_result = {
                "name": "Import generic_orchestrator",
                "passed": False,
                "error": None
            }
            
            try:
                spec = importlib.util.spec_from_file_location("generic_orchestrator", orchestrator_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                test_result["passed"] = True
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
            
        # Test 3: Check orchestrator help command
        run_script = self.project_root / "run_orchestrator_task.py"
        if run_script.exists():
            test_result = {
                "name": "Orchestrator help command",
                "passed": False,
                "error": None
            }
            
            try:
                result = subprocess.run(
                    [sys.executable, str(run_script), "--help"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                test_result["passed"] = result.returncode == 0
                if not test_result["passed"]:
                    test_result["error"] = result.stderr
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
            
        return results
    
    def _test_python_modules(self) -> Dict:
        """Test Python module integrity"""
        results = {
            "category": "python_modules",
            "tests": []
        }
        
        # Find all Python files
        python_files = list(self.project_root.glob("**/*.py"))[:10]  # Test first 10 files
        
        for py_file in python_files:
            if "__pycache__" in str(py_file):
                continue
                
            test_result = {
                "name": f"Syntax check: {py_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(py_file)],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                test_result["passed"] = result.returncode == 0
                if not test_result["passed"]:
                    test_result["error"] = result.stderr
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        # Print summary
        passed = sum(1 for t in results["tests"] if t["passed"])
        print(f"  ✅ {passed}/{len(results['tests'])} Python files valid")
        
        return results
    
    def _test_api_endpoints(self) -> Dict:
        """Test API endpoint availability"""
        results = {
            "category": "api_endpoints",
            "tests": []
        }
        
        # Check for API definition files
        api_files = list(self.project_root.glob("**/api*.py"))
        api_files.extend(self.project_root.glob("**/routes*.py"))
        
        for api_file in api_files[:5]:  # Test first 5 API files
            test_result = {
                "name": f"API file parseable: {api_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                with open(api_file, 'r') as f:
                    content = f.read()
                    # Check for route definitions
                    if "@app.route" in content or "@router." in content or "@api." in content:
                        test_result["passed"] = True
                    else:
                        test_result["error"] = "No route definitions found"
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        if results["tests"]:
            passed = sum(1 for t in results["tests"] if t["passed"])
            print(f"  ✅ {passed}/{len(results['tests'])} API files valid")
        else:
            print("  ⚠️ No API files found to test")
            
        return results
    
    def _test_configuration_loading(self) -> Dict:
        """Test configuration file loading"""
        results = {
            "category": "configuration",
            "tests": []
        }
        
        # Test JSON files
        json_files = list(self.project_root.glob("**/*.json"))[:5]
        for json_file in json_files:
            if "node_modules" in str(json_file):
                continue
                
            test_result = {
                "name": f"JSON valid: {json_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                with open(json_file, 'r') as f:
                    json.load(f)
                test_result["passed"] = True
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        # Test requirements.txt
        req_files = list(self.project_root.glob("**/requirements*.txt"))
        for req_file in req_files:
            test_result = {
                "name": f"Requirements file valid: {req_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                with open(req_file, 'r') as f:
                    lines = f.readlines()
                    # Basic validation
                    test_result["passed"] = all(
                        line.strip() == "" or not line.startswith("#") or "==" in line or ">" in line
                        for line in lines
                    )
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        if results["tests"]:
            passed = sum(1 for t in results["tests"] if t["passed"])
            print(f"  ✅ {passed}/{len(results['tests'])} configuration files valid")
        else:
            print("  ⚠️ No configuration files found")
            
        return results
    
    def _test_file_operations(self) -> Dict:
        """Test file system operations"""
        results = {
            "category": "file_operations",
            "tests": []
        }
        
        # Create temp directory for testing
        self.temp_dir = Path(tempfile.mkdtemp(prefix="cleanup_test_"))
        
        # Test 1: Write operation
        test_file = self.temp_dir / "test_write.txt"
        test_result = {
            "name": "File write operation",
            "passed": False,
            "error": None
        }
        
        try:
            test_file.write_text("Test content")
            test_result["passed"] = test_file.exists() and test_file.read_text() == "Test content"
        except Exception as e:
            test_result["error"] = str(e)
            
        results["tests"].append(test_result)
        print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
        
        # Test 2: Directory creation
        test_dir = self.temp_dir / "test_dir"
        test_result = {
            "name": "Directory creation",
            "passed": False,
            "error": None
        }
        
        try:
            test_dir.mkdir(parents=True)
            test_result["passed"] = test_dir.exists() and test_dir.is_dir()
        except Exception as e:
            test_result["error"] = str(e)
            
        results["tests"].append(test_result)
        print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
        
        # Cleanup
        if self.temp_dir and self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            
        return results
    
    def _test_workflow_execution(self) -> Dict:
        """Test workflow execution capabilities"""
        results = {
            "category": "workflow_execution",
            "tests": []
        }
        
        # Check for workflow definition files
        workflow_files = list(self.project_root.glob("**/*workflow*.json"))
        workflow_files.extend(self.project_root.glob("**/*tasks*.json"))
        
        for workflow_file in workflow_files[:3]:  # Test first 3 workflows
            test_result = {
                "name": f"Workflow parseable: {workflow_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                with open(workflow_file, 'r') as f:
                    workflow_data = json.load(f)
                    # Basic validation
                    if isinstance(workflow_data, (dict, list)):
                        test_result["passed"] = True
                    else:
                        test_result["error"] = "Invalid workflow structure"
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        if results["tests"]:
            passed = sum(1 for t in results["tests"] if t["passed"])
            print(f"  ✅ {passed}/{len(results['tests'])} workflow files valid")
        else:
            print("  ⚠️ No workflow files found")
            
        return results
    
    def _test_agent_system(self) -> Dict:
        """Test agent system components"""
        results = {
            "category": "agent_system",
            "tests": []
        }
        
        # Check for agent definition files
        agent_files = [
            "src/specialist_agent_templates.py",
            "src/intelligence_review_engine.py"
        ]
        
        for file_path in agent_files:
            full_path = self.project_root / file_path
            test_result = {
                "name": f"Agent file exists: {file_path}",
                "passed": full_path.exists(),
                "error": None if full_path.exists() else "File not found"
            }
            results["tests"].append(test_result)
            print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
            
        return results
    
    def _test_integration_points(self) -> Dict:
        """Test system integration points"""
        results = {
            "category": "integration_points",
            "tests": []
        }
        
        # Check for integration files
        integration_files = list(self.project_root.glob("**/*integration*.py"))
        
        for int_file in integration_files[:3]:
            test_result = {
                "name": f"Integration module: {int_file.name}",
                "passed": False,
                "error": None
            }
            
            try:
                # Just check if file can be compiled
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(int_file)],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                test_result["passed"] = result.returncode == 0
            except Exception as e:
                test_result["error"] = str(e)
                
            results["tests"].append(test_result)
            
        if results["tests"]:
            passed = sum(1 for t in results["tests"] if t["passed"])
            print(f"  ✅ {passed}/{len(results['tests'])} integration points valid")
        else:
            print("  ⚠️ No integration files found")
            
        return results
    
    def _test_database_connectivity(self) -> Dict:
        """Test database connectivity if applicable"""
        results = {
            "category": "database",
            "tests": []
        }
        
        # Check for database files
        db_files = list(self.project_root.glob("**/*.db"))
        db_files.extend(self.project_root.glob("**/*.sqlite*"))
        
        if db_files:
            test_result = {
                "name": "Database files present",
                "passed": True,
                "error": None
            }
            results["tests"].append(test_result)
            print(f"  ✅ Found {len(db_files)} database files")
        else:
            print("  ℹ️ No database files found")
            
        return results
    
    def _test_external_dependencies(self) -> Dict:
        """Test external dependencies"""
        results = {
            "category": "external_dependencies",
            "tests": []
        }
        
        # Check Python version
        test_result = {
            "name": "Python version >= 3.6",
            "passed": sys.version_info >= (3, 6),
            "error": None if sys.version_info >= (3, 6) else f"Python {sys.version}"
        }
        results["tests"].append(test_result)
        print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
        
        # Check for git
        test_result = {
            "name": "Git available",
            "passed": False,
            "error": None
        }
        
        try:
            result = subprocess.run(["git", "--version"], capture_output=True, timeout=5)
            test_result["passed"] = result.returncode == 0
        except Exception as e:
            test_result["error"] = str(e)
            
        results["tests"].append(test_result)
        print(f"  {'✅' if test_result['passed'] else '❌'} {test_result['name']}")
        
        return results
    
    def _update_results(self, category_results: Dict):
        """Update overall test results"""
        for test in category_results.get("tests", []):
            self.test_results["total_tests"] += 1
            if test["passed"]:
                self.test_results["passed"] += 1
            else:
                self.test_results["failed"] += 1
                if "orchestrator" in test["name"].lower() or "core" in test["name"].lower():
                    self.test_results["critical_failures"].append(test)
                    
            self.test_results["test_details"].append({
                "category": category_results.get("category", "unknown"),
                **test
            })
            
    def _print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        print(f"\n📊 Results:")
        print(f"  Total Tests: {self.test_results['total_tests']}")
        print(f"  ✅ Passed: {self.test_results['passed']}")
        print(f"  ❌ Failed: {self.test_results['failed']}")
        print(f"  ⏭️ Skipped: {self.test_results['skipped']}")
        print(f"  Success Rate: {self.test_results['success_rate']:.1f}%")
        
        if self.test_results["critical_failures"]:
            print(f"\n⚠️ Critical Failures ({len(self.test_results['critical_failures'])}):")
            for failure in self.test_results["critical_failures"]:
                print(f"  - {failure.get('name', failure.get('category', 'Unknown'))}")
                if failure.get("error"):
                    print(f"    Error: {failure['error'][:100]}")
                    
    def export_results(self, output_path: Path):
        """Export test results to file"""
        with open(output_path, 'w') as f:
            json.dump(self.test_results, f, indent=2, default=str)
        print(f"\n📄 Test results exported to: {output_path}")
        
    def run_baseline_comparison(self, baseline_path: Path) -> Dict:
        """Compare current results with baseline"""
        if not baseline_path.exists():
            print("⚠️ No baseline found for comparison")
            return {}
            
        with open(baseline_path, 'r') as f:
            baseline = json.load(f)
            
        comparison = {
            "baseline_tests": baseline.get("total_tests", 0),
            "current_tests": self.test_results["total_tests"],
            "baseline_passed": baseline.get("passed", 0),
            "current_passed": self.test_results["passed"],
            "regression": False,
            "improvements": [],
            "regressions": []
        }
        
        # Check for regressions
        baseline_details = {t["name"]: t for t in baseline.get("test_details", [])}
        current_details = {t["name"]: t for t in self.test_results["test_details"]}
        
        for test_name, baseline_test in baseline_details.items():
            current_test = current_details.get(test_name)
            if current_test:
                if baseline_test["passed"] and not current_test["passed"]:
                    comparison["regressions"].append(test_name)
                    comparison["regression"] = True
                elif not baseline_test["passed"] and current_test["passed"]:
                    comparison["improvements"].append(test_name)
                    
        return comparison


def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Functionality Test Suite")
    parser.add_argument("--project-root", default="../..", help="Project root directory")
    parser.add_argument("--output", help="Output path for test results")
    parser.add_argument("--baseline", help="Baseline results for comparison")
    parser.add_argument("--category", help="Run specific test category only")
    
    args = parser.parse_args()
    
    # Initialize test suite
    test_suite = FunctionalityTestSuite(project_root=args.project_root)
    
    # Run tests
    results = test_suite.run_all_tests()
    
    # Export results
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = Path(f"test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        
    test_suite.export_results(output_path)
    
    # Compare with baseline if provided
    if args.baseline:
        baseline_path = Path(args.baseline)
        comparison = test_suite.run_baseline_comparison(baseline_path)
        
        if comparison:
            print("\n📊 Baseline Comparison:")
            print(f"  Improvements: {len(comparison['improvements'])}")
            print(f"  Regressions: {len(comparison['regressions'])}")
            
            if comparison["regression"]:
                print("\n⚠️ REGRESSION DETECTED!")
                for regression in comparison["regressions"]:
                    print(f"  - {regression}")
                return 1
                
    # Return exit code based on critical failures
    if results["critical_failures"]:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())