#!/usr/bin/env python3
"""
Comprehensive Safety and Validation Framework for Directory Cleanup
Ensures no valuable content is lost during cleanup operations
"""

import os
import json
import shutil
import hashlib
import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
import subprocess
import sys
import time
import re

class SafetyValidationFramework:
    """Complete safety framework for directory cleanup operations"""
    
    def __init__(self, target_root: str, backup_dir: str = None):
        self.target_root = Path(target_root).resolve()
        self.backup_dir = Path(backup_dir or f"/tmp/cleanup_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.validation_log = []
        self.critical_patterns = []
        self.protected_files = set()
        self.validation_results = {}
        self.rollback_points = []
        
        # Initialize critical patterns
        self._initialize_critical_patterns()
        
    def _initialize_critical_patterns(self):
        """Define patterns for critical files that must be protected"""
        self.critical_patterns = [
            # Core orchestrator files
            r".*orchestrator.*\.py$",
            r".*main_controller.*\.py$",
            r".*generic_orchestrator.*\.py$",
            
            # Configuration files
            r".*\.json$",
            r".*\.yaml$",
            r".*\.yml$",
            r".*\.toml$",
            r".*\.ini$",
            r".*requirements.*\.txt$",
            
            # Documentation (only critical ones)
            r".*/README\.md$",
            r".*/API_REFERENCE\.md$",
            r".*/ARCHITECTURE\.md$",
            
            # Test files
            r".*test.*\.py$",
            r".*spec\.py$",
            
            # Git files
            r".*\.git/.*",
            r".*\.gitignore$",
            
            # Environment files
            r".*\.env.*",
            r".*\.venv/.*",
            r".*venv/.*",
            
            # License and legal
            r".*LICENSE.*",
            r".*NOTICE.*",
            
            # Package files
            r".*setup\.py$",
            r".*pyproject\.toml$",
            r".*package\.json$",
            
            # Database files
            r".*\.db$",
            r".*\.sqlite.*",
            
            # Security files
            r".*\.pem$",
            r".*\.key$",
            r".*\.crt$",
        ]
    
    def pre_cleanup_validation(self) -> Dict:
        """Complete pre-cleanup validation and inventory"""
        print("=" * 80)
        print("PRE-CLEANUP VALIDATION STARTING")
        print("=" * 80)
        
        validation_report = {
            "timestamp": datetime.datetime.now().isoformat(),
            "target_root": str(self.target_root),
            "backup_dir": str(self.backup_dir),
            "inventory": {},
            "critical_files": [],
            "dependencies": [],
            "baseline_tests": {},
            "backup_status": None,
            "validation_passed": False
        }
        
        try:
            # Step 1: Create complete inventory
            print("\n[1/6] Creating complete inventory...")
            validation_report["inventory"] = self._create_inventory()
            
            # Step 2: Identify critical files
            print("\n[2/6] Identifying critical files...")
            validation_report["critical_files"] = self._identify_critical_files()
            
            # Step 3: Check dependencies
            print("\n[3/6] Checking dependencies...")
            validation_report["dependencies"] = self._check_dependencies()
            
            # Step 4: Run baseline tests
            print("\n[4/6] Running baseline functionality tests...")
            validation_report["baseline_tests"] = self._run_baseline_tests()
            
            # Step 5: Create backup
            print("\n[5/6] Creating backup...")
            validation_report["backup_status"] = self._create_backup()
            
            # Step 6: Verify backup integrity
            print("\n[6/6] Verifying backup integrity...")
            if self._verify_backup_integrity():
                validation_report["validation_passed"] = True
                print("\n✅ PRE-CLEANUP VALIDATION PASSED")
            else:
                print("\n❌ PRE-CLEANUP VALIDATION FAILED")
                
        except Exception as e:
            print(f"\n❌ Validation failed with error: {e}")
            validation_report["error"] = str(e)
            
        # Save validation report
        report_path = self.backup_dir / "pre_cleanup_validation.json"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        with open(report_path, 'w') as f:
            json.dump(validation_report, f, indent=2, default=str)
            
        print(f"\nValidation report saved to: {report_path}")
        return validation_report
    
    def _create_inventory(self) -> Dict:
        """Create complete inventory of current state"""
        inventory = {
            "total_files": 0,
            "total_dirs": 0,
            "file_types": {},
            "size_bytes": 0,
            "files_by_category": {
                "python": [],
                "config": [],
                "documentation": [],
                "data": [],
                "other": []
            },
            "file_hashes": {}
        }
        
        for root, dirs, files in os.walk(self.target_root):
            # Skip .git directory
            if '.git' in root:
                continue
                
            inventory["total_dirs"] += len(dirs)
            
            for file in files:
                file_path = Path(root) / file
                relative_path = file_path.relative_to(self.target_root)
                
                inventory["total_files"] += 1
                
                # Get file extension
                ext = file_path.suffix.lower()
                inventory["file_types"][ext] = inventory["file_types"].get(ext, 0) + 1
                
                # Get file size
                try:
                    size = file_path.stat().st_size
                    inventory["size_bytes"] += size
                    
                    # Calculate hash for important files
                    if size < 10 * 1024 * 1024:  # Only hash files < 10MB
                        with open(file_path, 'rb') as f:
                            file_hash = hashlib.sha256(f.read()).hexdigest()
                            inventory["file_hashes"][str(relative_path)] = file_hash
                except:
                    pass
                
                # Categorize file
                if ext == '.py':
                    inventory["files_by_category"]["python"].append(str(relative_path))
                elif ext in ['.json', '.yaml', '.yml', '.toml', '.ini', '.env']:
                    inventory["files_by_category"]["config"].append(str(relative_path))
                elif ext in ['.md', '.rst', '.txt']:
                    inventory["files_by_category"]["documentation"].append(str(relative_path))
                elif ext in ['.db', '.sqlite', '.csv', '.parquet']:
                    inventory["files_by_category"]["data"].append(str(relative_path))
                else:
                    inventory["files_by_category"]["other"].append(str(relative_path))
                    
        print(f"  - Total files: {inventory['total_files']}")
        print(f"  - Total directories: {inventory['total_dirs']}")
        print(f"  - Total size: {inventory['size_bytes'] / (1024*1024):.2f} MB")
        
        return inventory
    
    def _identify_critical_files(self) -> List[str]:
        """Identify critical files that must be preserved"""
        critical_files = []
        
        for root, dirs, files in os.walk(self.target_root):
            for file in files:
                file_path = Path(root) / file
                relative_path = str(file_path.relative_to(self.target_root))
                
                # Check against critical patterns
                for pattern in self.critical_patterns:
                    if re.match(pattern, relative_path):
                        critical_files.append(relative_path)
                        self.protected_files.add(file_path)
                        break
                        
        print(f"  - Identified {len(critical_files)} critical files")
        return critical_files
    
    def _check_dependencies(self) -> List[Dict]:
        """Check system dependencies and imports"""
        dependencies = []
        
        # Check Python dependencies
        python_files = list(self.target_root.glob("**/*.py"))
        imports = set()
        
        for py_file in python_files:
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                    # Find imports
                    import_matches = re.findall(r'^(?:from|import)\s+(\S+)', content, re.MULTILINE)
                    imports.update(import_matches)
            except:
                pass
                
        # Check if requirements.txt exists
        req_files = list(self.target_root.glob("**/requirements*.txt"))
        for req_file in req_files:
            dependencies.append({
                "type": "requirements",
                "file": str(req_file.relative_to(self.target_root)),
                "exists": req_file.exists()
            })
            
        # Check package.json
        package_files = list(self.target_root.glob("**/package.json"))
        for package_file in package_files:
            dependencies.append({
                "type": "package.json",
                "file": str(package_file.relative_to(self.target_root)),
                "exists": package_file.exists()
            })
            
        print(f"  - Found {len(imports)} Python imports")
        print(f"  - Found {len(dependencies)} dependency files")
        
        return dependencies
    
    def _run_baseline_tests(self) -> Dict:
        """Run baseline functionality tests"""
        test_results = {
            "timestamp": datetime.datetime.now().isoformat(),
            "tests_run": 0,
            "tests_passed": 0,
            "tests_failed": 0,
            "details": []
        }
        
        # Test 1: Check if main orchestrator files exist
        orchestrator_files = [
            "src/generic_orchestrator.py",
            "src/dpo_main_controller.py",
            "run_orchestrator_task.py"
        ]
        
        for file in orchestrator_files:
            file_path = self.target_root.parent.parent / file
            test_results["tests_run"] += 1
            if file_path.exists():
                test_results["tests_passed"] += 1
                test_results["details"].append({
                    "test": f"File exists: {file}",
                    "passed": True
                })
            else:
                test_results["tests_failed"] += 1
                test_results["details"].append({
                    "test": f"File exists: {file}",
                    "passed": False,
                    "error": "File not found"
                })
                
        # Test 2: Check Python syntax
        for py_file in self.target_root.glob("**/*.py"):
            test_results["tests_run"] += 1
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(py_file)],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    test_results["tests_passed"] += 1
                else:
                    test_results["tests_failed"] += 1
                    test_results["details"].append({
                        "test": f"Python syntax: {py_file.name}",
                        "passed": False,
                        "error": result.stderr
                    })
            except Exception as e:
                test_results["tests_failed"] += 1
                test_results["details"].append({
                    "test": f"Python syntax: {py_file.name}",
                    "passed": False,
                    "error": str(e)
                })
                
        print(f"  - Tests run: {test_results['tests_run']}")
        print(f"  - Tests passed: {test_results['tests_passed']}")
        print(f"  - Tests failed: {test_results['tests_failed']}")
        
        return test_results
    
    def _create_backup(self) -> Dict:
        """Create comprehensive backup"""
        backup_status = {
            "backup_dir": str(self.backup_dir),
            "timestamp": datetime.datetime.now().isoformat(),
            "files_backed_up": 0,
            "total_size": 0,
            "errors": []
        }
        
        try:
            # Create backup directory
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            
            # Create tar archive
            archive_path = self.backup_dir / "full_backup.tar.gz"
            
            result = subprocess.run(
                ["tar", "-czf", str(archive_path), "-C", str(self.target_root.parent), self.target_root.name],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                backup_status["files_backed_up"] = len(list(self.target_root.glob("**/*")))
                backup_status["total_size"] = archive_path.stat().st_size
                print(f"  - Backup created: {archive_path}")
                print(f"  - Backup size: {backup_status['total_size'] / (1024*1024):.2f} MB")
            else:
                backup_status["errors"].append(f"Tar failed: {result.stderr}")
                
        except Exception as e:
            backup_status["errors"].append(str(e))
            
        return backup_status
    
    def _verify_backup_integrity(self) -> bool:
        """Verify backup integrity"""
        try:
            archive_path = self.backup_dir / "full_backup.tar.gz"
            
            if not archive_path.exists():
                print("  ❌ Backup archive not found")
                return False
                
            # Test archive integrity
            result = subprocess.run(
                ["tar", "-tzf", str(archive_path)],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                file_count = len(result.stdout.strip().split('\n'))
                print(f"  ✅ Backup verified: {file_count} files")
                return True
            else:
                print(f"  ❌ Backup verification failed: {result.stderr}")
                return False
                
        except Exception as e:
            print(f"  ❌ Backup verification error: {e}")
            return False
    
    def content_preservation_check(self, file_path: Path) -> Tuple[bool, str]:
        """Check if file contains valuable content that should be preserved"""
        relative_path = str(file_path.relative_to(self.target_root))
        
        # Check if file is in protected list
        if file_path in self.protected_files:
            return True, "Protected critical file"
            
        # Check against critical patterns
        for pattern in self.critical_patterns:
            if re.match(pattern, relative_path):
                return True, f"Matches critical pattern: {pattern}"
                
        # Check file content for important markers
        if file_path.suffix == '.py':
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                    
                # Check for important code patterns
                important_markers = [
                    r'class\s+\w+Orchestrator',
                    r'class\s+\w+Controller',
                    r'def\s+main\s*\(',
                    r'if\s+__name__\s*==\s*["\']__main__["\']',
                    r'@app\.route',
                    r'@api\.',
                    r'async\s+def\s+',
                ]
                
                for marker in important_markers:
                    if re.search(marker, content):
                        return True, f"Contains important code pattern: {marker}"
                        
            except:
                pass
                
        # Check if file is referenced by other files
        if self._is_file_referenced(file_path):
            return True, "File is referenced by other files"
            
        return False, "No preservation criteria met"
    
    def _is_file_referenced(self, file_path: Path) -> bool:
        """Check if file is referenced by other Python files"""
        file_name = file_path.stem
        
        for py_file in self.target_root.glob("**/*.py"):
            if py_file == file_path:
                continue
                
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                    if file_name in content:
                        return True
            except:
                pass
                
        return False
    
    def create_rollback_point(self, description: str) -> str:
        """Create a rollback point for recovery"""
        rollback_id = f"rollback_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        rollback_dir = self.backup_dir / "rollbacks" / rollback_id
        rollback_dir.mkdir(parents=True, exist_ok=True)
        
        rollback_info = {
            "id": rollback_id,
            "description": description,
            "timestamp": datetime.datetime.now().isoformat(),
            "current_state": self._create_inventory()
        }
        
        # Save rollback info
        with open(rollback_dir / "rollback_info.json", 'w') as f:
            json.dump(rollback_info, f, indent=2, default=str)
            
        self.rollback_points.append(rollback_id)
        print(f"✅ Created rollback point: {rollback_id}")
        
        return rollback_id
    
    def validate_cleanup_step(self, step_name: str, changes: List[Dict]) -> bool:
        """Validate a cleanup step before applying"""
        print(f"\n🔍 Validating cleanup step: {step_name}")
        
        validation_passed = True
        issues = []
        
        for change in changes:
            if change.get("action") == "delete":
                file_path = Path(change["path"])
                should_preserve, reason = self.content_preservation_check(file_path)
                
                if should_preserve:
                    issues.append(f"Cannot delete {file_path}: {reason}")
                    validation_passed = False
                    
            elif change.get("action") == "move":
                source = Path(change["source"])
                should_preserve, reason = self.content_preservation_check(source)
                
                if should_preserve and not change.get("force"):
                    issues.append(f"Warning: Moving protected file {source}: {reason}")
                    
        if issues:
            print("⚠️ Validation issues found:")
            for issue in issues:
                print(f"  - {issue}")
                
        return validation_passed
    
    def post_cleanup_validation(self) -> Dict:
        """Comprehensive post-cleanup validation"""
        print("\n" + "=" * 80)
        print("POST-CLEANUP VALIDATION")
        print("=" * 80)
        
        validation_report = {
            "timestamp": datetime.datetime.now().isoformat(),
            "functionality_tests": {},
            "integrity_checks": {},
            "comparison_with_baseline": {},
            "issues_found": [],
            "validation_passed": False
        }
        
        # Run functionality tests
        print("\n[1/3] Running functionality tests...")
        validation_report["functionality_tests"] = self._run_functionality_tests()
        
        # Check integrity
        print("\n[2/3] Checking system integrity...")
        validation_report["integrity_checks"] = self._check_system_integrity()
        
        # Compare with baseline
        print("\n[3/3] Comparing with baseline...")
        validation_report["comparison_with_baseline"] = self._compare_with_baseline()
        
        # Determine overall status
        if (validation_report["functionality_tests"].get("passed", False) and
            validation_report["integrity_checks"].get("passed", False)):
            validation_report["validation_passed"] = True
            print("\n✅ POST-CLEANUP VALIDATION PASSED")
        else:
            print("\n❌ POST-CLEANUP VALIDATION FAILED")
            
        return validation_report
    
    def _run_functionality_tests(self) -> Dict:
        """Run comprehensive functionality tests"""
        test_results = {
            "tests_run": 0,
            "tests_passed": 0,
            "tests_failed": 0,
            "critical_failures": [],
            "passed": False
        }
        
        # Test core orchestrator functionality
        orchestrator_path = self.target_root.parent.parent / "src" / "generic_orchestrator.py"
        if orchestrator_path.exists():
            test_results["tests_run"] += 1
            try:
                result = subprocess.run(
                    [sys.executable, str(orchestrator_path), "--help"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    test_results["tests_passed"] += 1
                else:
                    test_results["tests_failed"] += 1
                    test_results["critical_failures"].append("Orchestrator help failed")
            except Exception as e:
                test_results["tests_failed"] += 1
                test_results["critical_failures"].append(f"Orchestrator test error: {e}")
                
        test_results["passed"] = test_results["tests_failed"] == 0
        
        return test_results
    
    def _check_system_integrity(self) -> Dict:
        """Check overall system integrity"""
        integrity_report = {
            "critical_files_present": True,
            "no_broken_imports": True,
            "configuration_valid": True,
            "passed": False
        }
        
        # Check critical files
        for pattern in self.critical_patterns[:5]:  # Check first 5 critical patterns
            files = list(self.target_root.glob(f"**/{pattern.replace('.*', '*').replace('$', '')}"))
            if not files and "test" not in pattern:
                integrity_report["critical_files_present"] = False
                break
                
        integrity_report["passed"] = all([
            integrity_report["critical_files_present"],
            integrity_report["no_broken_imports"],
            integrity_report["configuration_valid"]
        ])
        
        return integrity_report
    
    def _compare_with_baseline(self) -> Dict:
        """Compare current state with baseline"""
        comparison = {
            "files_removed": 0,
            "files_added": 0,
            "critical_files_intact": True,
            "unexpected_changes": []
        }
        
        # Load pre-cleanup validation if exists
        pre_validation_path = self.backup_dir / "pre_cleanup_validation.json"
        if pre_validation_path.exists():
            with open(pre_validation_path, 'r') as f:
                pre_validation = json.load(f)
                
            # Compare file counts
            current_inventory = self._create_inventory()
            comparison["files_removed"] = pre_validation["inventory"]["total_files"] - current_inventory["total_files"]
            
            # Check critical files
            for critical_file in pre_validation.get("critical_files", []):
                if not (self.target_root / critical_file).exists():
                    comparison["critical_files_intact"] = False
                    comparison["unexpected_changes"].append(f"Critical file missing: {critical_file}")
                    
        return comparison
    
    def execute_rollback(self, rollback_id: str = None) -> bool:
        """Execute rollback to previous state"""
        print(f"\n🔄 Executing rollback{f' to {rollback_id}' if rollback_id else ''}...")
        
        try:
            # Use latest rollback point if not specified
            if not rollback_id and self.rollback_points:
                rollback_id = self.rollback_points[-1]
                
            if not rollback_id:
                # Use main backup
                archive_path = self.backup_dir / "full_backup.tar.gz"
                if archive_path.exists():
                    # Extract backup
                    result = subprocess.run(
                        ["tar", "-xzf", str(archive_path), "-C", str(self.target_root.parent)],
                        capture_output=True,
                        text=True
                    )
                    
                    if result.returncode == 0:
                        print("✅ Rollback completed successfully")
                        return True
                    else:
                        print(f"❌ Rollback failed: {result.stderr}")
                        return False
                        
            print("❌ No rollback point available")
            return False
            
        except Exception as e:
            print(f"❌ Rollback error: {e}")
            return False
    
    def generate_safety_report(self) -> str:
        """Generate comprehensive safety report"""
        report_path = self.backup_dir / "safety_validation_report.md"
        
        report_content = f"""# Safety Validation Report

Generated: {datetime.datetime.now().isoformat()}

## Pre-Cleanup Validation
- Backup Location: {self.backup_dir}
- Critical Files Identified: {len(self.protected_files)}
- Rollback Points Created: {len(self.rollback_points)}

## Protection Mechanisms
1. **Critical Pattern Matching**: {len(self.critical_patterns)} patterns defined
2. **Content Preservation**: Active scanning for valuable content
3. **Reference Checking**: Cross-file dependency validation
4. **Incremental Rollback**: {len(self.rollback_points)} rollback points available

## Validation Results
{json.dumps(self.validation_results, indent=2, default=str)}

## Recovery Procedures
1. **Automatic Rollback**: `framework.execute_rollback()`
2. **Manual Recovery**: Extract from `{self.backup_dir}/full_backup.tar.gz`
3. **Selective Restore**: Use rollback points in `{self.backup_dir}/rollbacks/`

## Recommendations
- Always run pre-cleanup validation before any cleanup operations
- Create rollback points at each major step
- Verify functionality after each cleanup phase
- Keep backups for at least 30 days
"""
        
        with open(report_path, 'w') as f:
            f.write(report_content)
            
        print(f"\n📄 Safety report generated: {report_path}")
        return str(report_path)


def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Safety Validation Framework for Directory Cleanup")
    parser.add_argument("--target", default=".", help="Target directory for cleanup")
    parser.add_argument("--backup-dir", help="Backup directory location")
    parser.add_argument("--validate-only", action="store_true", help="Only run validation, no cleanup")
    parser.add_argument("--rollback", help="Rollback to specific point or latest")
    
    args = parser.parse_args()
    
    # Initialize framework
    framework = SafetyValidationFramework(
        target_root=args.target,
        backup_dir=args.backup_dir
    )
    
    if args.rollback:
        # Execute rollback
        success = framework.execute_rollback(args.rollback if args.rollback != "latest" else None)
        sys.exit(0 if success else 1)
    
    # Run pre-cleanup validation
    validation_report = framework.pre_cleanup_validation()
    
    if not validation_report["validation_passed"]:
        print("\n⚠️ Pre-cleanup validation failed. Cleanup should not proceed.")
        sys.exit(1)
        
    if args.validate_only:
        print("\n✅ Validation completed successfully.")
        framework.generate_safety_report()
        sys.exit(0)
        
    print("\n✅ System ready for cleanup operations.")
    print(f"Backup available at: {framework.backup_dir}")
    framework.generate_safety_report()


if __name__ == "__main__":
    main()