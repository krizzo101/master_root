#!/usr/bin/env python3
"""
Advanced Content Preservation Scanner
Identifies and protects valuable content during cleanup operations
"""

import os
import re
import ast
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
import hashlib
from datetime import datetime

class ContentPreservationScanner:
    """Advanced scanner for identifying valuable content"""
    
    def __init__(self, target_root: str):
        self.target_root = Path(target_root).resolve()
        self.valuable_content = {}
        self.scan_results = {
            "timestamp": datetime.now().isoformat(),
            "scanned_files": 0,
            "valuable_files": [],
            "patterns_found": {},
            "dependencies": {},
            "api_endpoints": [],
            "database_schemas": [],
            "configuration_files": [],
            "test_coverage": {},
            "documentation_index": []
        }
        
    def scan_for_valuable_content(self) -> Dict:
        """Comprehensive scan for valuable content"""
        print("🔍 Starting Content Preservation Scan...")
        
        # Scan Python files
        self._scan_python_files()
        
        # Scan configuration files
        self._scan_configuration_files()
        
        # Scan documentation
        self._scan_documentation()
        
        # Scan for API definitions
        self._scan_api_definitions()
        
        # Scan for database schemas
        self._scan_database_schemas()
        
        # Scan for test files
        self._scan_test_files()
        
        # Analyze cross-references
        self._analyze_cross_references()
        
        # Generate preservation priority
        self._calculate_preservation_priority()
        
        print(f"✅ Scan completed: {self.scan_results['scanned_files']} files analyzed")
        print(f"   Found {len(self.scan_results['valuable_files'])} valuable files")
        
        return self.scan_results
    
    def _scan_python_files(self):
        """Scan Python files for valuable patterns"""
        python_files = list(self.target_root.glob("**/*.py"))
        
        valuable_patterns = {
            "orchestrator_core": r"class\s+\w*Orchestrator",
            "controller_core": r"class\s+\w*Controller",
            "agent_definitions": r"class\s+\w*Agent",
            "api_endpoints": r"@(app|api|router)\.(route|get|post|put|delete)",
            "async_handlers": r"async\s+def\s+\w+",
            "database_models": r"class\s+\w+\(.*Model.*\)",
            "configuration": r"class\s+\w*Config",
            "main_entry": r"if\s+__name__\s*==\s*['\"]__main__['\"]",
            "cli_commands": r"@(click|typer)\.(command|group)",
            "decorators": r"@\w+\.?\w*\s*\(",
            "error_handlers": r"except\s+\w*Exception",
            "logging_setup": r"logging\.(getLogger|basicConfig)",
            "threading": r"(Thread|Process|async|await)",
            "ml_models": r"(model\.|nn\.|torch\.|tensorflow\.|sklearn\.)",
            "data_processing": r"(pandas|numpy|scipy)\.",
            "security": r"(encrypt|decrypt|hash|token|auth|password)",
            "external_apis": r"(requests\.|urllib\.|httpx\.|aiohttp\.)",
        }
        
        for py_file in python_files:
            self.scan_results["scanned_files"] += 1
            file_valuable = False
            file_patterns = []
            
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                # Check for valuable patterns
                for pattern_name, pattern_regex in valuable_patterns.items():
                    if re.search(pattern_regex, content):
                        file_patterns.append(pattern_name)
                        file_valuable = True
                        
                        if pattern_name not in self.scan_results["patterns_found"]:
                            self.scan_results["patterns_found"][pattern_name] = []
                        self.scan_results["patterns_found"][pattern_name].append(
                            str(py_file.relative_to(self.target_root))
                        )
                
                # Parse AST for deeper analysis
                try:
                    tree = ast.parse(content)
                    
                    # Find imports
                    imports = []
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                imports.append(alias.name)
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:
                                imports.append(node.module)
                                
                    if imports:
                        relative_path = str(py_file.relative_to(self.target_root))
                        self.scan_results["dependencies"][relative_path] = imports
                        
                    # Find class definitions
                    classes = [node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
                    if classes:
                        file_valuable = True
                        
                    # Find function definitions
                    functions = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
                    if any(func.startswith("test_") for func in functions):
                        if "test_files" not in self.scan_results:
                            self.scan_results["test_files"] = []
                        self.scan_results["test_files"].append(str(py_file.relative_to(self.target_root)))
                        
                except:
                    pass  # AST parsing failed, continue with regex patterns
                    
                if file_valuable:
                    self.scan_results["valuable_files"].append({
                        "path": str(py_file.relative_to(self.target_root)),
                        "type": "python",
                        "patterns": file_patterns,
                        "size": py_file.stat().st_size,
                        "priority": self._calculate_file_priority(file_patterns)
                    })
                    
            except Exception as e:
                print(f"  Warning: Could not scan {py_file}: {e}")
                
    def _scan_configuration_files(self):
        """Scan configuration files"""
        config_patterns = {
            "**/*.json": "json",
            "**/*.yaml": "yaml",
            "**/*.yml": "yaml",
            "**/*.toml": "toml",
            "**/*.ini": "ini",
            "**/*.env*": "env",
            "**/requirements*.txt": "requirements",
            "**/package.json": "npm",
            "**/Dockerfile*": "docker",
            "**/docker-compose*.yml": "docker-compose",
            "**/.gitlab-ci.yml": "ci",
            "**/.github/workflows/*.yml": "ci",
            "**/Makefile": "make",
            "**/setup.py": "setup",
            "**/pyproject.toml": "pyproject",
        }
        
        for pattern, config_type in config_patterns.items():
            for config_file in self.target_root.glob(pattern):
                self.scan_results["scanned_files"] += 1
                
                self.scan_results["configuration_files"].append({
                    "path": str(config_file.relative_to(self.target_root)),
                    "type": config_type,
                    "size": config_file.stat().st_size
                })
                
                self.scan_results["valuable_files"].append({
                    "path": str(config_file.relative_to(self.target_root)),
                    "type": "configuration",
                    "subtype": config_type,
                    "priority": "HIGH"  # Config files are always high priority
                })
                
    def _scan_documentation(self):
        """Scan documentation files"""
        doc_patterns = ["**/*.md", "**/*.rst", "**/*.txt"]
        
        important_docs = [
            "README", "ARCHITECTURE", "API", "DEPLOYMENT",
            "GUIDE", "MANUAL", "DOCUMENTATION", "CHANGELOG",
            "LICENSE", "CONTRIBUTING", "SECURITY"
        ]
        
        for pattern in doc_patterns:
            for doc_file in self.target_root.glob(pattern):
                self.scan_results["scanned_files"] += 1
                
                doc_name = doc_file.stem.upper()
                is_important = any(keyword in doc_name for keyword in important_docs)
                
                doc_info = {
                    "path": str(doc_file.relative_to(self.target_root)),
                    "type": "documentation",
                    "important": is_important,
                    "size": doc_file.stat().st_size
                }
                
                self.scan_results["documentation_index"].append(doc_info)
                
                if is_important:
                    self.scan_results["valuable_files"].append({
                        "path": str(doc_file.relative_to(self.target_root)),
                        "type": "documentation",
                        "priority": "HIGH" if "README" in doc_name or "LICENSE" in doc_name else "MEDIUM"
                    })
                    
    def _scan_api_definitions(self):
        """Scan for API endpoint definitions"""
        api_files = []
        
        # Look for OpenAPI/Swagger files
        for pattern in ["**/swagger*.json", "**/openapi*.json", "**/api*.yaml"]:
            api_files.extend(self.target_root.glob(pattern))
            
        # Scan Python files for API routes
        for py_file in self.target_root.glob("**/*.py"):
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                    
                # Find Flask/FastAPI routes
                route_patterns = [
                    r"@app\.route\(['\"]([^'\"]+)['\"]",
                    r"@router\.(get|post|put|delete|patch)\(['\"]([^'\"]+)['\"]",
                    r"@api\.(route|resource)\(['\"]([^'\"]+)['\"]",
                ]
                
                for pattern in route_patterns:
                    matches = re.findall(pattern, content)
                    if matches:
                        for match in matches:
                            endpoint = match[1] if isinstance(match, tuple) else match
                            self.scan_results["api_endpoints"].append({
                                "file": str(py_file.relative_to(self.target_root)),
                                "endpoint": endpoint,
                                "type": "rest_api"
                            })
                            
            except:
                pass
                
    def _scan_database_schemas(self):
        """Scan for database schema definitions"""
        # Look for SQL files
        for sql_file in self.target_root.glob("**/*.sql"):
            self.scan_results["database_schemas"].append({
                "path": str(sql_file.relative_to(self.target_root)),
                "type": "sql"
            })
            
        # Look for migration files
        for migration in self.target_root.glob("**/migrations/**/*.py"):
            self.scan_results["database_schemas"].append({
                "path": str(migration.relative_to(self.target_root)),
                "type": "migration"
            })
            
        # Look for ORM models
        model_files = []
        for py_file in self.target_root.glob("**/models*.py"):
            model_files.append(py_file)
        for py_file in self.target_root.glob("**/schema*.py"):
            model_files.append(py_file)
            
        for model_file in model_files:
            self.scan_results["database_schemas"].append({
                "path": str(model_file.relative_to(self.target_root)),
                "type": "orm_model"
            })
            
    def _scan_test_files(self):
        """Scan for test files and coverage"""
        test_patterns = [
            "**/test_*.py",
            "**/*_test.py",
            "**/tests/**/*.py",
            "**/spec/**/*.py",
            "**/*_spec.py",
        ]
        
        test_files = []
        for pattern in test_patterns:
            test_files.extend(self.target_root.glob(pattern))
            
        for test_file in test_files:
            self.scan_results["test_coverage"][str(test_file.relative_to(self.target_root))] = {
                "type": "unit_test",
                "size": test_file.stat().st_size
            }
            
            # Test files are valuable
            self.scan_results["valuable_files"].append({
                "path": str(test_file.relative_to(self.target_root)),
                "type": "test",
                "priority": "MEDIUM"
            })
            
    def _analyze_cross_references(self):
        """Analyze cross-references between files"""
        cross_refs = {}
        
        for py_file in self.target_root.glob("**/*.py"):
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                    
                # Find imports from local modules
                local_imports = re.findall(r'from\s+\.+(\w+)', content)
                local_imports.extend(re.findall(r'import\s+(\w+)', content))
                
                if local_imports:
                    file_path = str(py_file.relative_to(self.target_root))
                    cross_refs[file_path] = list(set(local_imports))
                    
            except:
                pass
                
        # Files with many cross-references are more valuable
        for file_path, refs in cross_refs.items():
            if len(refs) > 5:  # Arbitrary threshold
                for valuable_file in self.scan_results["valuable_files"]:
                    if valuable_file["path"] == file_path:
                        valuable_file["cross_references"] = len(refs)
                        if valuable_file.get("priority") == "MEDIUM":
                            valuable_file["priority"] = "HIGH"
                            
    def _calculate_file_priority(self, patterns: List[str]) -> str:
        """Calculate preservation priority based on patterns found"""
        high_priority_patterns = [
            "orchestrator_core", "controller_core", "main_entry",
            "api_endpoints", "database_models", "configuration"
        ]
        
        medium_priority_patterns = [
            "agent_definitions", "async_handlers", "cli_commands",
            "error_handlers", "logging_setup", "security"
        ]
        
        for pattern in patterns:
            if pattern in high_priority_patterns:
                return "HIGH"
                
        for pattern in patterns:
            if pattern in medium_priority_patterns:
                return "MEDIUM"
                
        return "LOW"
        
    def _calculate_preservation_priority(self):
        """Calculate overall preservation priority for all files"""
        priority_scores = {}
        
        for valuable_file in self.scan_results["valuable_files"]:
            path = valuable_file["path"]
            score = 0
            
            # Base score by priority
            if valuable_file.get("priority") == "HIGH":
                score += 100
            elif valuable_file.get("priority") == "MEDIUM":
                score += 50
            else:
                score += 10
                
            # Bonus for cross-references
            score += valuable_file.get("cross_references", 0) * 5
            
            # Bonus for being in critical directories
            if "src" in path or "core" in path:
                score += 20
            if "test" in path:
                score += 15
            if "config" in path:
                score += 25
                
            priority_scores[path] = score
            
        # Sort files by priority score
        self.scan_results["preservation_priority"] = sorted(
            priority_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
    def generate_preservation_manifest(self, output_path: Path) -> None:
        """Generate a manifest of files to preserve"""
        manifest = {
            "generated": datetime.now().isoformat(),
            "total_valuable_files": len(self.scan_results["valuable_files"]),
            "high_priority": [],
            "medium_priority": [],
            "low_priority": [],
            "always_preserve": [],
            "safe_to_cleanup": []
        }
        
        for valuable_file in self.scan_results["valuable_files"]:
            priority = valuable_file.get("priority", "LOW")
            entry = {
                "path": valuable_file["path"],
                "type": valuable_file["type"],
                "reason": valuable_file.get("patterns", [])
            }
            
            if priority == "HIGH":
                manifest["high_priority"].append(entry)
            elif priority == "MEDIUM":
                manifest["medium_priority"].append(entry)
            else:
                manifest["low_priority"].append(entry)
                
        # Add configuration files to always preserve
        for config_file in self.scan_results["configuration_files"]:
            manifest["always_preserve"].append({
                "path": config_file["path"],
                "type": "configuration",
                "reason": f"Configuration file ({config_file['type']})"
            })
            
        # Identify safe to cleanup files
        all_files = set(str(f.relative_to(self.target_root)) 
                       for f in self.target_root.glob("**/*") if f.is_file())
        valuable_files = set(f["path"] for f in self.scan_results["valuable_files"])
        config_files = set(f["path"] for f in self.scan_results["configuration_files"])
        
        protected_files = valuable_files | config_files
        safe_files = all_files - protected_files
        
        # Filter for truly safe files (caches, logs, temp files)
        for file_path in safe_files:
            if any(pattern in file_path for pattern in [
                "__pycache__", ".pyc", ".pyo", ".tmp", ".log",
                ".cache", "node_modules", ".pytest_cache", ".coverage"
            ]):
                manifest["safe_to_cleanup"].append(file_path)
                
        # Save manifest
        with open(output_path, 'w') as f:
            json.dump(manifest, f, indent=2)
            
        print(f"📋 Preservation manifest saved to: {output_path}")
        print(f"   - High priority: {len(manifest['high_priority'])} files")
        print(f"   - Medium priority: {len(manifest['medium_priority'])} files")
        print(f"   - Low priority: {len(manifest['low_priority'])} files")
        print(f"   - Always preserve: {len(manifest['always_preserve'])} files")
        print(f"   - Safe to cleanup: {len(manifest['safe_to_cleanup'])} files")


def main():
    """Main execution function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Content Preservation Scanner")
    parser.add_argument("--target", default=".", help="Target directory to scan")
    parser.add_argument("--output", help="Output path for preservation manifest")
    parser.add_argument("--format", choices=["json", "yaml", "markdown"], default="json",
                       help="Output format for the manifest")
    
    args = parser.parse_args()
    
    # Initialize scanner
    scanner = ContentPreservationScanner(target_root=args.target)
    
    # Run scan
    results = scanner.scan_for_valuable_content()
    
    # Generate manifest
    output_path = Path(args.output or "preservation_manifest.json")
    scanner.generate_preservation_manifest(output_path)
    
    # Print summary
    print("\n📊 Scan Summary:")
    print(f"   Total files scanned: {results['scanned_files']}")
    print(f"   Valuable files found: {len(results['valuable_files'])}")
    print(f"   Configuration files: {len(results['configuration_files'])}")
    print(f"   API endpoints: {len(results['api_endpoints'])}")
    print(f"   Test files: {len(results['test_coverage'])}")
    print(f"   Documentation files: {len(results['documentation_index'])}")
    
    return 0


if __name__ == "__main__":
    exit(main())