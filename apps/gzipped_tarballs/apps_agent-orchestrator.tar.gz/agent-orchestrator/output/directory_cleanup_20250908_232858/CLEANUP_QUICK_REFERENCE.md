# Directory Cleanup Quick Reference Guide

## 🚀 Quick Start

```bash
cd /home/opsvi/master_root/apps/agent-orchestrator/output/directory_cleanup_20250908_232858
chmod +x *.sh
./execute_cleanup.sh
```

## 📋 Pre-Execution Checklist

- [ ] Review `DIRECTORY_CLEANUP_EXECUTION_PLAN.md` 
- [ ] Ensure 5GB free disk space
- [ ] No critical workflows running
- [ ] Team notified of maintenance
- [ ] Git status checked and clean

## 🔧 Individual Phase Execution

### Phase 1: Preparation (Safe - Creates Backup Only)
```bash
bash prepare_cleanup.sh
# Creates backup at: /home/opsvi/master_root/backups/agent-orchestrator-{timestamp}/
```

### Phase 2: Archive (Moves Old Content)
```bash
python3 archive_old_content.py
# Archives to: /home/opsvi/master_root/apps/agent-orchestrator/archive/
```

### Phase 3: Reorganization (Restructures Directory)
```bash
python3 reorganize_structure.py
# Creates new structure with scripts/, configs/, etc.
```

### Phase 4: Validation (Tests Everything)
```bash
python3 validate_cleanup.py
# Creates: VALIDATION_REPORT.json
```

## 🔄 Rollback Procedures

### Automatic Rollback (Finds Latest Backup)
```bash
python3 rollback_cleanup.py
```

### Manual Rollback (Specific Backup)
```bash
python3 rollback_cleanup.py /path/to/backup.tar.gz
```

### Force Rollback (No Confirmation)
```bash
python3 rollback_cleanup.py /path/to/backup.tar.gz --force
```

## 📊 Expected Results

### Before Cleanup
- **Files:** 1,036
- **Directories:** 313
- **Issues:** Mixed test/production, duplicate outputs, scattered configs

### After Cleanup
- **Files:** ~600 (40% reduction)
- **Directories:** Organized structure
- **Benefits:** Clear separation, archived history, maintainable

## 🚨 Emergency Recovery

If something goes wrong:

1. **Find backup:**
   ```bash
   ls -la /home/opsvi/master_root/backups/agent-orchestrator-*/
   ```

2. **Manual extraction:**
   ```bash
   cd /home/opsvi/master_root/apps
   rm -rf agent-orchestrator  # Remove broken directory
   tar -xzf /path/to/backup.tar.gz
   ```

3. **Check logs:**
   ```bash
   # Main execution log
   cat cleanup_execution.log
   
   # Phase-specific logs
   cat archive_phase.log
   cat reorganize_phase.log
   cat validation_phase.log
   ```

## 📁 New Directory Structure

```
agent-orchestrator/
├── src/                 # Core source code
├── docs/                # Documentation
├── tests/               # All test files
│   ├── integration/
│   ├── performance/
│   └── demos/
├── configs/             # Configuration files
│   ├── templates/
│   ├── workflows/
│   └── agents/
├── scripts/             # Utility scripts
│   ├── runners/
│   ├── utilities/
│   └── analysis/
├── web/                 # Web interface
├── output/              # Active workflow outputs
└── archive/             # Historical data
    ├── workflows/
    ├── logs/
    └── experimental/
```

## ✅ Post-Cleanup Verification

1. **Test core functionality:**
   ```bash
   python3 src/generic_orchestrator.py test_task.json
   ```

2. **Check imports:**
   ```bash
   python3 -c "from src.generic_orchestrator import GenericOrchestrator"
   ```

3. **Verify structure:**
   ```bash
   ls -la src/ docs/ tests/ configs/ scripts/
   ```

4. **Review changes:**
   ```bash
   git status
   git diff
   ```

## 📝 Important Files Created

- `DIRECTORY_CLEANUP_EXECUTION_PLAN.md` - Full execution plan
- `DIRECTORY_STRUCTURE_ANALYSIS.md` - Initial analysis
- `VALIDATION_REPORT.json` - Validation results
- `STRUCTURE_MAP.json` - New directory map
- `archive/MANIFEST.json` - Archive inventory

## 🔍 Monitoring

After cleanup, monitor for:
- Import errors in logs
- Missing file complaints
- Workflow execution failures
- Performance degradation

## 💡 Tips

1. **Run during off-hours** to minimize disruption
2. **Keep backup for 30 days** before deletion
3. **Document any custom changes** made post-cleanup
4. **Update CI/CD paths** if necessary
5. **Notify team** of new structure

## 📞 Support

If issues arise:
1. Check this guide first
2. Review execution logs
3. Attempt rollback if critical
4. Document issue for future reference

---

**Generated:** 2025-09-09  
**Version:** 1.0  
**Status:** READY FOR EXECUTION