#!/bin/bash
# Phase 1: Preparation Script for Directory Cleanup
# Safe, comprehensive backup and preparation

set -e  # Exit on error
set -u  # Exit on undefined variable

echo "======================================"
echo "PHASE 1: PREPARATION"
echo "======================================"
echo "Starting at: $(date)"
echo ""

# Configuration
BASE_DIR="/home/opsvi/master_root/apps/agent-orchestrator"
BACKUP_ROOT="/home/opsvi/master_root/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="${BACKUP_ROOT}/agent-orchestrator-${TIMESTAMP}"

# Create backup directory
echo "Creating backup directory: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# Check available disk space
echo ""
echo "Checking disk space..."
AVAILABLE=$(df /home/opsvi/master_root | tail -1 | awk '{print $4}')
echo "Available space: ${AVAILABLE}K"

if [ "$AVAILABLE" -lt 5000000 ]; then
    echo "ERROR: Insufficient disk space (need at least 5GB)"
    exit 1
fi

# Create full backup
echo ""
echo "Creating complete backup..."
cd /home/opsvi/master_root/apps

tar -czf "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" \
    --preserve-permissions \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    agent-orchestrator/ 2>&1 | tee "$BACKUP_DIR/backup.log"

# Verify backup
echo ""
echo "Verifying backup integrity..."
FILE_COUNT=$(tar -tzf "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" | wc -l)
BACKUP_SIZE=$(du -sh "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" | cut -f1)

echo "Backup contains $FILE_COUNT files"
echo "Backup size: $BACKUP_SIZE"

# Create file inventories
echo ""
echo "Creating file inventories..."
cd "$BASE_DIR"

find . -type f -name "*.py" | sort > "$BACKUP_DIR/inventory_python.txt"
find . -type f -name "*.json" | sort > "$BACKUP_DIR/inventory_json.txt"
find . -type f -name "*.md" | sort > "$BACKUP_DIR/inventory_markdown.txt"
find . -type f -name "*.log" | sort > "$BACKUP_DIR/inventory_logs.txt"

# Count files by type
echo ""
echo "File statistics:"
echo "Python files: $(wc -l < "$BACKUP_DIR/inventory_python.txt")"
echo "JSON files: $(wc -l < "$BACKUP_DIR/inventory_json.txt")"
echo "Markdown files: $(wc -l < "$BACKUP_DIR/inventory_markdown.txt")"
echo "Log files: $(wc -l < "$BACKUP_DIR/inventory_logs.txt")"

# Create dependency map
echo ""
echo "Creating dependency map..."
grep -r "^import\|^from" --include="*.py" > "$BACKUP_DIR/dependency_map.txt" 2>/dev/null || true

# Setup archive structure
echo ""
echo "Setting up archive directories..."
mkdir -p "$BASE_DIR/archive/workflows/2025"
mkdir -p "$BASE_DIR/archive/test_runs"
mkdir -p "$BASE_DIR/archive/logs/2025"
mkdir -p "$BASE_DIR/archive/experimental"
mkdir -p "$BASE_DIR/archive/deprecated"
mkdir -p "$BASE_DIR/archive/documentation/legacy"

# Create rollback information
echo ""
echo "Creating rollback information..."
cat > "$BACKUP_DIR/rollback_info.json" <<EOF
{
    "backup_date": "$(date -Iseconds)",
    "backup_location": "$BACKUP_DIR/agent-orchestrator-complete.tar.gz",
    "original_location": "$BASE_DIR",
    "file_count": $FILE_COUNT,
    "backup_size": "$BACKUP_SIZE",
    "rollback_command": "python rollback_cleanup.py $BACKUP_DIR/agent-orchestrator-complete.tar.gz"
}
EOF

# Save current git status
echo ""
echo "Saving git status..."
cd "$BASE_DIR"
git status --porcelain > "$BACKUP_DIR/git_status_before.txt" 2>/dev/null || echo "Not a git repository" > "$BACKUP_DIR/git_status_before.txt"

# Final preparation summary
echo ""
echo "======================================"
echo "PREPARATION COMPLETE"
echo "======================================"
echo "Backup location: $BACKUP_DIR"
echo "Backup size: $BACKUP_SIZE"
echo "Files backed up: $FILE_COUNT"
echo "Archive structure: Ready"
echo ""
echo "To rollback if needed:"
echo "python rollback_cleanup.py $BACKUP_DIR/agent-orchestrator-complete.tar.gz"
echo ""
echo "Ready to proceed with Phase 2: Archive"
echo "======================================"

# Save preparation results
cat > "$BACKUP_DIR/phase1_complete.flag" <<EOF
PHASE_1_COMPLETE
Timestamp: $(date)
Backup: $BACKUP_DIR/agent-orchestrator-complete.tar.gz
Files: $FILE_COUNT
EOF

echo "Phase 1 flag created: $BACKUP_DIR/phase1_complete.flag"
echo ""
echo "BACKUP_DIR=$BACKUP_DIR" > /tmp/cleanup_env.sh
echo "Export this for next phases: source /tmp/cleanup_env.sh"