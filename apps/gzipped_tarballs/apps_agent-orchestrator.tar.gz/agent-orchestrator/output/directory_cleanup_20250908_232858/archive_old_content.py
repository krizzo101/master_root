#!/usr/bin/env python3
"""
Phase 2: Archive Old Content
Safely archives outdated files while preserving structure
"""

import os
import sys
import shutil
import json
import gzip
from datetime import datetime, timedelta
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('archive_phase.log'),
        logging.StreamHandler()
    ]
)

BASE_DIR = Path("/home/opsvi/master_root/apps/agent-orchestrator")
ARCHIVE_DIR = BASE_DIR / "archive"

class ContentArchiver:
    def __init__(self):
        self.stats = {
            "files_archived": 0,
            "files_deleted": 0,
            "space_freed": 0,
            "errors": []
        }
        
    def archive_workflow_outputs(self, days_old=7):
        """Archive workflow outputs older than specified days"""
        logging.info(f"Archiving workflow outputs older than {days_old} days...")
        
        output_dir = BASE_DIR / "output"
        if not output_dir.exists():
            logging.warning("Output directory not found")
            return
            
        cutoff_date = datetime.now() - timedelta(days=days_old)
        archive_target = ARCHIVE_DIR / "workflows" / "2025"
        archive_target.mkdir(parents=True, exist_ok=True)
        
        for item in output_dir.iterdir():
            if item.is_dir():
                # Check modification time
                mtime = datetime.fromtimestamp(item.stat().st_mtime)
                if mtime < cutoff_date:
                    try:
                        # Create tar.gz archive
                        archive_name = archive_target / f"{item.name}.tar.gz"
                        logging.info(f"Archiving: {item.name}")
                        
                        import tarfile
                        with tarfile.open(archive_name, 'w:gz') as tar:
                            tar.add(item, arcname=item.name)
                        
                        # Remove original after successful archive
                        shutil.rmtree(item)
                        self.stats["files_archived"] += 1
                        self.stats["space_freed"] += self._get_dir_size(item)
                        
                    except Exception as e:
                        logging.error(f"Failed to archive {item}: {e}")
                        self.stats["errors"].append(str(e))
    
    def archive_json_tasks(self, days_old=3):
        """Archive JSON task files from completed workflows"""
        logging.info(f"Archiving JSON task files older than {days_old} days...")
        
        cutoff_date = datetime.now() - timedelta(days=days_old)
        archive_target = ARCHIVE_DIR / "workflows" / "2025"
        archive_target.mkdir(parents=True, exist_ok=True)
        
        # Find JSON task files in root
        for json_file in BASE_DIR.glob("*_tasks.json"):
            mtime = datetime.fromtimestamp(json_file.stat().st_mtime)
            if mtime < cutoff_date:
                try:
                    target = archive_target / json_file.name
                    shutil.move(str(json_file), str(target))
                    logging.info(f"Archived: {json_file.name}")
                    self.stats["files_archived"] += 1
                except Exception as e:
                    logging.error(f"Failed to archive {json_file}: {e}")
                    self.stats["errors"].append(str(e))
    
    def archive_test_files(self):
        """Move test files from root to organized test directory"""
        logging.info("Organizing test files...")
        
        # Create test subdirectories
        test_dirs = {
            "integration": BASE_DIR / "tests" / "integration",
            "performance": BASE_DIR / "tests" / "performance",
            "demos": BASE_DIR / "tests" / "demos"
        }
        
        for dir_path in test_dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Define patterns and their destinations
        patterns = {
            "test_*.py": test_dirs["integration"],
            "*_test.py": test_dirs["integration"],
            "*_demo.py": test_dirs["demos"],
            "stress_test_*.py": test_dirs["performance"],
            "load_test_*.py": test_dirs["performance"],
            "*_performance*.py": test_dirs["performance"]
        }
        
        for pattern, destination in patterns.items():
            for test_file in BASE_DIR.glob(pattern):
                if test_file.is_file():
                    try:
                        target = destination / test_file.name
                        shutil.move(str(test_file), str(target))
                        logging.info(f"Moved {test_file.name} to {destination.name}")
                        self.stats["files_archived"] += 1
                    except Exception as e:
                        logging.error(f"Failed to move {test_file}: {e}")
                        self.stats["errors"].append(str(e))
    
    def archive_logs(self, days_old=7):
        """Compress and archive old log files"""
        logging.info(f"Archiving log files older than {days_old} days...")
        
        cutoff_date = datetime.now() - timedelta(days=days_old)
        log_archive = ARCHIVE_DIR / "logs" / "2025"
        log_archive.mkdir(parents=True, exist_ok=True)
        
        # Find all log files
        for log_file in BASE_DIR.rglob("*.log"):
            if "archive" in str(log_file):
                continue
                
            mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
            if mtime < cutoff_date:
                try:
                    # Compress log file
                    gz_file = log_archive / f"{log_file.name}.gz"
                    with open(log_file, 'rb') as f_in:
                        with gzip.open(gz_file, 'wb') as f_out:
                            f_out.writelines(f_in)
                    
                    # Remove original
                    log_file.unlink()
                    logging.info(f"Archived log: {log_file.name}")
                    self.stats["files_archived"] += 1
                    
                except Exception as e:
                    logging.error(f"Failed to archive {log_file}: {e}")
                    self.stats["errors"].append(str(e))
    
    def archive_experimental(self):
        """Archive experimental and development files"""
        logging.info("Archiving experimental files...")
        
        experimental_dir = ARCHIVE_DIR / "experimental"
        experimental_dir.mkdir(parents=True, exist_ok=True)
        
        # List of experimental files to archive
        experimental_files = [
            "simple_chat_demo.py",
            "websocket_load_test.py",
            "test_websocket_scenarios.py",
            "ui_performance_test.py",
            "stress_test_websockets.py",
            "load_test_metrics_feeder.py"
        ]
        
        for filename in experimental_files:
            file_path = BASE_DIR / filename
            if file_path.exists():
                try:
                    target = experimental_dir / filename
                    shutil.move(str(file_path), str(target))
                    logging.info(f"Archived experimental: {filename}")
                    self.stats["files_archived"] += 1
                except Exception as e:
                    logging.error(f"Failed to archive {filename}: {e}")
                    self.stats["errors"].append(str(e))
        
        # Archive old documentation
        legacy_docs = ARCHIVE_DIR / "documentation" / "legacy"
        legacy_docs.mkdir(parents=True, exist_ok=True)
        
        for old_doc in BASE_DIR.rglob("*_old.md"):
            try:
                target = legacy_docs / old_doc.name
                shutil.move(str(old_doc), str(target))
                logging.info(f"Archived legacy doc: {old_doc.name}")
                self.stats["files_archived"] += 1
            except Exception as e:
                logging.error(f"Failed to archive {old_doc}: {e}")
                self.stats["errors"].append(str(e))
    
    def create_manifest(self):
        """Create a manifest of all archived content"""
        logging.info("Creating archive manifest...")
        
        manifest = {
            "created": datetime.now().isoformat(),
            "archive_phase": "Phase 2",
            "contents": {},
            "statistics": self.stats
        }
        
        # Scan archive directory
        for root, dirs, files in os.walk(ARCHIVE_DIR):
            rel_path = os.path.relpath(root, ARCHIVE_DIR)
            if files:
                manifest["contents"][rel_path] = {
                    "files": files,
                    "count": len(files)
                }
        
        # Calculate totals
        manifest["statistics"]["total_archived_files"] = sum(
            v["count"] for v in manifest["contents"].values()
        )
        
        # Save manifest
        manifest_path = ARCHIVE_DIR / "MANIFEST.json"
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        logging.info(f"Manifest created: {manifest_path}")
        return manifest
    
    def _get_dir_size(self, path):
        """Calculate directory size in bytes"""
        total = 0
        try:
            for entry in path.rglob('*'):
                if entry.is_file():
                    total += entry.stat().st_size
        except Exception:
            pass
        return total
    
    def run_archive_phase(self):
        """Execute complete archive phase"""
        logging.info("="*50)
        logging.info("PHASE 2: ARCHIVE - Starting")
        logging.info("="*50)
        
        # Execute archival tasks in order
        self.archive_workflow_outputs()
        self.archive_json_tasks()
        self.archive_test_files()
        self.archive_logs()
        self.archive_experimental()
        
        # Create manifest
        manifest = self.create_manifest()
        
        # Report results
        logging.info("="*50)
        logging.info("ARCHIVE PHASE COMPLETE")
        logging.info("="*50)
        logging.info(f"Files archived: {self.stats['files_archived']}")
        logging.info(f"Files deleted: {self.stats['files_deleted']}")
        logging.info(f"Space freed: {self.stats['space_freed'] / (1024*1024):.2f} MB")
        
        if self.stats['errors']:
            logging.warning(f"Errors encountered: {len(self.stats['errors'])}")
            for error in self.stats['errors'][:5]:  # Show first 5 errors
                logging.warning(f"  - {error}")
        
        # Save phase completion flag
        flag_file = BASE_DIR / "archive" / "phase2_complete.flag"
        with open(flag_file, 'w') as f:
            f.write(f"PHASE_2_COMPLETE\n")
            f.write(f"Timestamp: {datetime.now()}\n")
            f.write(f"Files archived: {self.stats['files_archived']}\n")
        
        return self.stats

def main():
    """Main execution"""
    archiver = ContentArchiver()
    
    try:
        stats = archiver.run_archive_phase()
        
        # Exit with appropriate code
        if stats['errors']:
            sys.exit(1)  # Partial success
        else:
            sys.exit(0)  # Complete success
            
    except Exception as e:
        logging.error(f"Archive phase failed: {e}")
        sys.exit(2)  # Complete failure

if __name__ == "__main__":
    main()