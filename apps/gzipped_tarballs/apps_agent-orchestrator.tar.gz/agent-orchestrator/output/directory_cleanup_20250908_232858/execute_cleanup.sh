#!/bin/bash
# Master Execution Script for Directory Cleanup
# Orchestrates all phases with safety checks

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/home/opsvi/master_root/apps/agent-orchestrator"
LOG_FILE="$SCRIPT_DIR/cleanup_execution.log"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1" | tee -a "$LOG_FILE"
}

print_error() {
    echo -e "${RED}✗${NC} $1" | tee -a "$LOG_FILE"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1" | tee -a "$LOG_FILE"
}

# Function to check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check Python version
    if ! python3 --version &> /dev/null; then
        print_error "Python 3 is not installed"
        return 1
    fi
    
    # Check disk space (need at least 5GB)
    AVAILABLE=$(df /home/opsvi | tail -1 | awk '{print $4}')
    if [ "$AVAILABLE" -lt 5000000 ]; then
        print_error "Insufficient disk space (need at least 5GB)"
        return 1
    fi
    
    # Check if we're in the right directory
    if [ ! -d "$BASE_DIR" ]; then
        print_error "Target directory not found: $BASE_DIR"
        return 1
    fi
    
    # Check script permissions
    for script in prepare_cleanup.sh archive_old_content.py reorganize_structure.py validate_cleanup.py rollback_cleanup.py; do
        if [ ! -f "$SCRIPT_DIR/$script" ]; then
            print_error "Required script not found: $script"
            return 1
        fi
    done
    
    print_success "All prerequisites met"
    return 0
}

# Function to run a phase with error handling
run_phase() {
    local phase_name=$1
    local phase_script=$2
    local phase_type=$3  # "bash" or "python"
    
    print_status "="
    print_status "Starting $phase_name"
    print_status "="
    
    if [ "$phase_type" = "bash" ]; then
        if bash "$SCRIPT_DIR/$phase_script" 2>&1 | tee -a "$LOG_FILE"; then
            print_success "$phase_name completed successfully"
            return 0
        else
            print_error "$phase_name failed"
            return 1
        fi
    else
        if python3 "$SCRIPT_DIR/$phase_script" 2>&1 | tee -a "$LOG_FILE"; then
            print_success "$phase_name completed successfully"
            return 0
        else
            print_error "$phase_name failed"
            return 1
        fi
    fi
}

# Function to prompt for confirmation
confirm_execution() {
    echo ""
    echo -e "${YELLOW}⚠️  DIRECTORY CLEANUP EXECUTION PLAN${NC}"
    echo "=================================="
    echo "This script will:"
    echo "1. Create a complete backup"
    echo "2. Archive old content"
    echo "3. Reorganize directory structure"
    echo "4. Validate all changes"
    echo ""
    echo "Target: $BASE_DIR"
    echo "Backup will be saved to: /home/opsvi/master_root/backups/"
    echo ""
    read -p "Do you want to proceed? (yes/no): " response
    
    if [ "$response" != "yes" ]; then
        print_warning "Execution cancelled by user"
        exit 0
    fi
}

# Function to handle phase failure
handle_failure() {
    local phase=$1
    
    print_error "="
    print_error "CLEANUP FAILED AT: $phase"
    print_error "="
    
    echo ""
    echo "Options:"
    echo "1. Review the log file: $LOG_FILE"
    echo "2. Check phase-specific logs in $SCRIPT_DIR/"
    echo "3. Rollback to backup (if Phase 1 completed)"
    echo ""
    
    # Check if backup exists
    if [ -f "/tmp/cleanup_env.sh" ]; then
        source /tmp/cleanup_env.sh
        if [ -n "$BACKUP_DIR" ] && [ -f "$BACKUP_DIR/agent-orchestrator-complete.tar.gz" ]; then
            read -p "Do you want to rollback to backup? (yes/no): " rollback_response
            if [ "$rollback_response" = "yes" ]; then
                print_status "Initiating rollback..."
                python3 "$SCRIPT_DIR/rollback_cleanup.py" "$BACKUP_DIR/agent-orchestrator-complete.tar.gz"
            fi
        fi
    fi
    
    exit 1
}

# Main execution
main() {
    echo ""
    echo "======================================"
    echo "AGENT-ORCHESTRATOR DIRECTORY CLEANUP"
    echo "======================================"
    echo "Execution started: $(date)"
    echo ""
    
    # Initialize log
    echo "Cleanup Execution Log - $(date)" > "$LOG_FILE"
    echo "================================" >> "$LOG_FILE"
    
    # Check prerequisites
    if ! check_prerequisites; then
        print_error "Prerequisites check failed. Aborting."
        exit 1
    fi
    
    # Confirm execution
    confirm_execution
    
    # Phase 1: Preparation
    if ! run_phase "PHASE 1: PREPARATION" "prepare_cleanup.sh" "bash"; then
        handle_failure "Phase 1: Preparation"
    fi
    
    # Load backup information
    if [ -f "/tmp/cleanup_env.sh" ]; then
        source /tmp/cleanup_env.sh
        print_status "Backup location: $BACKUP_DIR"
    fi
    
    # Checkpoint
    read -p "Phase 1 complete. Continue with archiving? (yes/no): " continue_response
    if [ "$continue_response" != "yes" ]; then
        print_warning "Execution paused after Phase 1"
        exit 0
    fi
    
    # Phase 2: Archive
    if ! run_phase "PHASE 2: ARCHIVE" "archive_old_content.py" "python"; then
        handle_failure "Phase 2: Archive"
    fi
    
    # Checkpoint
    read -p "Phase 2 complete. Continue with reorganization? (yes/no): " continue_response
    if [ "$continue_response" != "yes" ]; then
        print_warning "Execution paused after Phase 2"
        exit 0
    fi
    
    # Phase 3: Reorganization
    if ! run_phase "PHASE 3: REORGANIZATION" "reorganize_structure.py" "python"; then
        handle_failure "Phase 3: Reorganization"
    fi
    
    # Phase 4: Validation
    if ! run_phase "PHASE 4: VALIDATION" "validate_cleanup.py" "python"; then
        print_warning "Validation detected issues"
        
        # Check if it's critical
        if [ -f "$BASE_DIR/VALIDATION_REPORT.json" ]; then
            print_status "Review VALIDATION_REPORT.json for details"
            
            read -p "Do you want to rollback due to validation failures? (yes/no): " rollback_response
            if [ "$rollback_response" = "yes" ]; then
                handle_failure "Phase 4: Validation"
            fi
        fi
    fi
    
    # Success summary
    echo ""
    print_success "======================================"
    print_success "CLEANUP COMPLETED SUCCESSFULLY"
    print_success "======================================"
    echo ""
    
    # Display statistics
    if [ -f "$BASE_DIR/VALIDATION_REPORT.json" ]; then
        python3 -c "
import json
with open('$BASE_DIR/VALIDATION_REPORT.json') as f:
    report = json.load(f)
    if 'results' in report and 'performance' in report['results']:
        perf = report['results']['performance']['details']
        print(f'Final Statistics:')
        print(f'  Total Files: {perf.get(\"total_files\", \"N/A\")}')
        print(f'  Total Directories: {perf.get(\"total_directories\", \"N/A\")}')
        print(f'  Total Size: {perf.get(\"total_size_mb\", \"N/A\")} MB')
"
    fi
    
    echo ""
    echo "Next Steps:"
    echo "1. Test core functionality"
    echo "2. Review changes with: git status"
    echo "3. Commit changes if satisfied"
    echo "4. Monitor for any issues over next 24 hours"
    echo ""
    echo "Backup location: $BACKUP_DIR"
    echo "Rollback command: python3 $SCRIPT_DIR/rollback_cleanup.py $BACKUP_DIR/agent-orchestrator-complete.tar.gz"
    echo ""
    print_success "Cleanup execution completed at: $(date)"
}

# Run main function
main "$@"