#!/usr/bin/env python3
"""
WorkflowMonitor Class
Tracks active workflows from running orchestrator processes

Features:
- Process discovery and monitoring
- State file parsing and workflow metadata extraction
- Non-intrusive monitoring via file system observation
- Real-time process status tracking
- Integration with dashboard state management
"""

import asyncio
import json
import logging
import os
import psutil
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

class ProcessInfo:
    """Information about a running orchestrator process"""
    
    def __init__(self, pid: int, process: psutil.Process):
        self.pid = pid
        self.process = process
        self.workflow_id: Optional[str] = None
        self.task_file: Optional[str] = None
        self.output_dir: Optional[str] = None
        self.started_at = datetime.now()
        self.last_activity = datetime.now()
        self.status = "running"
        
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "pid": self.pid,
            "workflow_id": self.workflow_id,
            "task_file": self.task_file,
            "output_dir": self.output_dir,
            "started_at": self.started_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
            "status": self.status,
            "cpu_percent": self.get_cpu_percent(),
            "memory_mb": self.get_memory_mb()
        }
        
    def get_cpu_percent(self) -> float:
        """Get CPU usage percentage for this process"""
        try:
            return self.process.cpu_percent()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return 0.0
            
    def get_memory_mb(self) -> float:
        """Get memory usage in MB for this process"""
        try:
            return self.process.memory_info().rss / 1024 / 1024
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return 0.0
            
    def is_alive(self) -> bool:
        """Check if the process is still running"""
        try:
            return self.process.is_running()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False

class WorkflowMonitor:
    """
    Monitors active orchestrator workflows by tracking processes and state files
    
    Capabilities:
    - Automatic discovery of running orchestrator processes
    - Parsing of orchestrator state files and task configurations
    - Non-intrusive monitoring without modifying existing processes
    - Real-time tracking of workflow progress and status
    - Integration with dashboard event system
    """
    
    def __init__(self, orchestrator_base_dir: str = "/home/opsvi/master_root/apps/agent-orchestrator"):
        self.orchestrator_base_dir = Path(orchestrator_base_dir)
        self.monitored_processes: Dict[int, ProcessInfo] = {}
        self.workflow_states: Dict[str, Dict] = {}
        self.output_directories: Set[Path] = set()
        self.monitoring_active = False
        
        # Patterns for identifying orchestrator processes
        self.process_patterns = [
            r"python.*main\.py",
            r"python.*generic_orchestrator\.py",
            r"python.*run_orchestrator_task\.py",
            r"python.*run_system_analysis\.py"
        ]
        
        # Known output directory patterns
        self.output_dir_patterns = [
            "outputs",
            "output", 
            "wbs_output"
        ]
        
    async def start_monitoring(self):
        """Start the workflow monitoring system"""
        logger.info("Starting workflow monitor")
        self.monitoring_active = True
        
        # Start monitoring tasks
        asyncio.create_task(self._monitor_processes())
        asyncio.create_task(self._monitor_state_files())
        asyncio.create_task(self._monitor_output_directories())
        
    async def stop_monitoring(self):
        """Stop the workflow monitoring system"""
        logger.info("Stopping workflow monitor")
        self.monitoring_active = False
        
    def discover_running_processes(self) -> List[ProcessInfo]:
        """Discover currently running orchestrator processes"""
        discovered_processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
            try:
                cmdline = ' '.join(proc.info['cmdline'] or [])
                
                # Check if this matches any of our orchestrator patterns
                for pattern in self.process_patterns:
                    if re.search(pattern, cmdline, re.IGNORECASE):
                        process_info = ProcessInfo(proc.info['pid'], proc)
                        self._extract_process_metadata(process_info, cmdline)
                        discovered_processes.append(process_info)
                        break
                        
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
                
        return discovered_processes
        
    def _extract_process_metadata(self, process_info: ProcessInfo, cmdline: str):
        """Extract workflow metadata from process command line"""
        
        # Extract task file if specified
        task_file_match = re.search(r'--task[s]?[-_]?file[s]?\s+([^\s]+)', cmdline)
        if task_file_match:
            process_info.task_file = task_file_match.group(1)
            
        # Extract app name or target
        app_name_match = re.search(r'--app[-_]?name\s+([^\s]+)', cmdline)
        if app_name_match:
            process_info.workflow_id = f"app_{app_name_match.group(1)}_{process_info.pid}"
        
        target_match = re.search(r'--target\s+([^\s]+)', cmdline)
        if target_match:
            process_info.workflow_id = f"analysis_{Path(target_match.group(1)).name}_{process_info.pid}"
            
        # Generate workflow ID if not found
        if not process_info.workflow_id:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            process_info.workflow_id = f"orchestrator_{timestamp}_{process_info.pid}"
            
    async def _monitor_processes(self):
        """Background task to continuously monitor processes"""
        while self.monitoring_active:
            try:
                # Discover new processes
                current_processes = self.discover_running_processes()
                current_pids = {p.pid for p in current_processes}
                
                # Add new processes
                for process_info in current_processes:
                    if process_info.pid not in self.monitored_processes:
                        self.monitored_processes[process_info.pid] = process_info
                        logger.info(f"Discovered new workflow process: {process_info.workflow_id} (PID: {process_info.pid})")
                        
                        # Emit workflow started event
                        await self._emit_workflow_event(
                            process_info.workflow_id,
                            "workflow_started",
                            process_info.to_dict()
                        )
                
                # Remove completed/dead processes
                dead_pids = []
                for pid, process_info in self.monitored_processes.items():
                    if pid not in current_pids or not process_info.is_alive():
                        dead_pids.append(pid)
                        logger.info(f"Workflow process ended: {process_info.workflow_id} (PID: {pid})")
                        
                        # Emit workflow completed/failed event
                        await self._emit_workflow_event(
                            process_info.workflow_id,
                            "workflow_completed" if process_info.status == "completed" else "workflow_failed",
                            process_info.to_dict()
                        )
                
                # Clean up dead processes
                for pid in dead_pids:
                    del self.monitored_processes[pid]
                
                # Update process metrics
                for process_info in self.monitored_processes.values():
                    process_info.last_activity = datetime.now()
                    
                await asyncio.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                logger.error(f"Process monitoring error: {e}")
                await asyncio.sleep(10)
                
    async def _monitor_state_files(self):
        """Monitor orchestrator state files for workflow updates"""
        while self.monitoring_active:
            try:
                # Look for state files in common locations
                state_files = list(self.orchestrator_base_dir.rglob("*orchestrator_state*.json"))
                state_files.extend(list(self.orchestrator_base_dir.rglob("current_*.json")))
                
                for state_file in state_files:
                    try:
                        if state_file.stat().st_mtime > time.time() - 10:  # Modified in last 10 seconds
                            await self._parse_state_file(state_file)
                    except Exception as e:
                        logger.debug(f"Error checking state file {state_file}: {e}")
                        
                await asyncio.sleep(2)  # Check every 2 seconds
                
            except Exception as e:
                logger.error(f"State file monitoring error: {e}")
                await asyncio.sleep(5)
                
    async def _parse_state_file(self, state_file: Path):
        """Parse an orchestrator state file and extract workflow information"""
        try:
            with open(state_file, 'r') as f:
                state_data = json.load(f)
                
            # Extract workflow information
            workflow_id = self._derive_workflow_id_from_state(state_data, state_file)
            
            if workflow_id and workflow_id not in self.workflow_states:
                self.workflow_states[workflow_id] = state_data
                
                # Emit state update event
                await self._emit_workflow_event(
                    workflow_id,
                    "workflow_state_updated",
                    {
                        "state_file": str(state_file),
                        "state_data": state_data
                    }
                )
                
        except (json.JSONDecodeError, IOError) as e:
            logger.debug(f"Could not parse state file {state_file}: {e}")
            
    def _derive_workflow_id_from_state(self, state_data: Dict, state_file: Path) -> Optional[str]:
        """Derive workflow ID from state file data"""
        
        # Try to extract from state data
        if 'analysis_dir' in state_data:
            return f"analysis_{Path(state_data['analysis_dir']).name}"
            
        if 'app_name' in state_data:
            return f"app_{state_data['app_name']}"
            
        # Fallback to filename-based ID
        return f"state_{state_file.stem}"
        
    async def _monitor_output_directories(self):
        """Monitor output directories for new deliverables"""
        while self.monitoring_active:
            try:
                # Discover output directories
                for pattern in self.output_dir_patterns:
                    for output_dir in self.orchestrator_base_dir.rglob(pattern):
                        if output_dir.is_dir():
                            self.output_directories.add(output_dir)
                            
                # Monitor recent files in output directories
                for output_dir in self.output_directories:
                    await self._scan_output_directory(output_dir)
                    
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Output directory monitoring error: {e}")
                await asyncio.sleep(15)
                
    async def _scan_output_directory(self, output_dir: Path):
        """Scan an output directory for new deliverables"""
        try:
            # Look for recent files (modified in last 5 minutes)
            cutoff_time = time.time() - 300  # 5 minutes ago
            
            for file_path in output_dir.rglob("*"):
                if file_path.is_file() and file_path.stat().st_mtime > cutoff_time:
                    
                    # Try to derive workflow ID from path
                    workflow_id = self._derive_workflow_id_from_path(file_path, output_dir)
                    
                    if workflow_id:
                        # Emit deliverable created event
                        await self._emit_workflow_event(
                            workflow_id,
                            "deliverable_created",
                            {
                                "filename": file_path.name,
                                "file_path": str(file_path),
                                "file_size": file_path.stat().st_size,
                                "created_at": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
                            }
                        )
                        
        except Exception as e:
            logger.debug(f"Error scanning output directory {output_dir}: {e}")
            
    def _derive_workflow_id_from_path(self, file_path: Path, output_dir: Path) -> Optional[str]:
        """Derive workflow ID from file path structure"""
        
        # Extract from directory structure
        relative_path = file_path.relative_to(output_dir)
        path_parts = relative_path.parts
        
        # Common patterns: outputs/YYYYMMDD_HHMMSS/..., output/task_name/...
        if len(path_parts) > 0:
            first_part = path_parts[0]
            
            # Check for timestamp pattern
            if re.match(r'\d{8}_\d{6}', first_part):
                return f"timestamped_{first_part}"
                
            # Check for task type pattern
            if any(task_type in first_part.lower() for task_type in ['analysis', 'documentation', 'code', 'research']):
                return f"task_{first_part}"
                
        # Fallback to output directory name
        return f"output_{output_dir.name}"
        
    async def _emit_workflow_event(self, workflow_id: str, event_type: str, data: Dict):
        """Emit workflow event to the dashboard system"""
        try:
            # This would integrate with the dashboard's event broadcaster
            # For now, just log the event
            logger.info(f"Workflow event: {workflow_id} - {event_type}")
            logger.debug(f"Event data: {data}")
            
        except Exception as e:
            logger.error(f"Error emitting workflow event: {e}")
            
    def get_active_workflows(self) -> List[Dict]:
        """Get list of currently active workflows"""
        workflows = []
        
        for process_info in self.monitored_processes.values():
            workflow_data = process_info.to_dict()
            
            # Add state data if available
            if process_info.workflow_id in self.workflow_states:
                workflow_data['state'] = self.workflow_states[process_info.workflow_id]
                
            workflows.append(workflow_data)
            
        return workflows
        
    def get_workflow_info(self, workflow_id: str) -> Optional[Dict]:
        """Get detailed information about a specific workflow"""
        
        # Find by workflow ID in monitored processes
        for process_info in self.monitored_processes.values():
            if process_info.workflow_id == workflow_id:
                workflow_data = process_info.to_dict()
                
                # Add state data if available
                if workflow_id in self.workflow_states:
                    workflow_data['state'] = self.workflow_states[workflow_id]
                    
                return workflow_data
                
        # Check if we have state data only
        if workflow_id in self.workflow_states:
            return {
                "workflow_id": workflow_id,
                "state": self.workflow_states[workflow_id],
                "status": "unknown"
            }
            
        return None
        
    async def terminate_workflow(self, workflow_id: str, force: bool = False) -> bool:
        """Terminate a workflow by its ID"""
        
        # Find the process for this workflow
        for process_info in self.monitored_processes.values():
            if process_info.workflow_id == workflow_id:
                try:
                    if force:
                        process_info.process.kill()
                    else:
                        process_info.process.terminate()
                        
                    logger.info(f"{'Killed' if force else 'Terminated'} workflow {workflow_id} (PID: {process_info.pid})")
                    return True
                    
                except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                    logger.error(f"Could not terminate workflow {workflow_id}: {e}")
                    return False
                    
        logger.warning(f"Workflow {workflow_id} not found in active processes")
        return False