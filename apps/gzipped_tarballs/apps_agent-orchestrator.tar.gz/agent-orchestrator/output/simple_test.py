#!/usr/bin/env python3
"""
Simple Dashboard Backend Test
Basic functionality test without external dependencies
"""

import asyncio
import json
import tempfile
from datetime import datetime
from pathlib import Path

def test_basic_functionality():
    """Test basic dashboard functionality"""
    print("🧪 Testing Dashboard Backend Components")
    print("=" * 50)
    
    # Test 1: Import all components
    print("1. Testing imports...")
    try:
        import dashboard_server
        import workflow_monitor
        import log_streamer
        import deliverable_tracker
        import orchestrator_integration
        print("   ✓ All imports successful")
    except ImportError as e:
        print(f"   ✗ Import failed: {e}")
        return False
    
    # Test 2: Basic state management
    print("2. Testing state management...")
    try:
        from dashboard_server import DashboardState
        state = DashboardState()
        
        # Test sequence counter
        id1 = state.get_next_sequence_id()
        id2 = state.get_next_sequence_id()
        
        assert id1 == 1
        assert id2 == 2
        assert id2 > id1
        
        print("   ✓ State management working")
    except Exception as e:
        print(f"   ✗ State management failed: {e}")
        return False
    
    # Test 3: Log parsing
    print("3. Testing log parsing...")
    try:
        from log_streamer import LogParser
        parser = LogParser()
        
        # Test different log formats
        test_cases = [
            ("2025-09-08 13:06:41,123 INFO orchestrator.main Task completed", "INFO"),
            ("ERROR: Something went wrong", "ERROR"),
            ("WARNING: This is a warning", "WARNING"),
            ("Regular message", "INFO")
        ]
        
        for log_line, expected_level in test_cases:
            entry = parser.parse_log_line(log_line, "test_workflow")
            assert entry.level == expected_level
            assert entry.workflow_id == "test_workflow"
            
        print("   ✓ Log parsing working")
    except Exception as e:
        print(f"   ✗ Log parsing failed: {e}")
        return False
    
    # Test 4: File deliverable handling
    print("4. Testing deliverable handling...")
    try:
        from deliverable_tracker import DeliverableInfo
        
        # Create temporary test file
        temp_dir = Path(tempfile.mkdtemp())
        test_file = temp_dir / "test.md"
        test_file.write_text("# Test File\nContent here")
        
        deliverable = DeliverableInfo(test_file, "test_workflow", "task_001")
        
        assert deliverable.filename == "test.md"
        assert deliverable.workflow_id == "test_workflow"
        assert deliverable.task_id == "task_001"
        assert deliverable.file_size > 0
        
        # Test serialization
        data = deliverable.to_dict()
        assert "workflow_id" in data
        assert "filename" in data
        
        # Cleanup
        test_file.unlink()
        temp_dir.rmdir()
        
        print("   ✓ Deliverable handling working")
    except Exception as e:
        print(f"   ✗ Deliverable handling failed: {e}")
        return False
    
    # Test 5: WebSocket hub basics
    print("5. Testing WebSocket hub...")
    try:
        from dashboard_server import WebSocketHub
        hub = WebSocketHub()
        
        assert len(hub.connections) == 0
        assert len(hub.subscriptions) == 0
        
        print("   ✓ WebSocket hub initialized")
    except Exception as e:
        print(f"   ✗ WebSocket hub failed: {e}")
        return False
    
    # Test 6: Process monitoring basics
    print("6. Testing process monitoring...")
    try:
        from workflow_monitor import WorkflowMonitor
        monitor = WorkflowMonitor()
        
        assert len(monitor.monitored_processes) == 0
        assert monitor.monitoring_active == False
        
        # Test process pattern matching
        test_commands = [
            "python main.py --task-file test.json",
            "python generic_orchestrator.py",
            "python run_orchestrator_task.py"
        ]
        
        import re
        patterns = monitor.process_patterns
        
        for command in test_commands:
            matched = any(re.search(pattern, command, re.IGNORECASE) for pattern in patterns)
            assert matched, f"Command should match: {command}"
            
        print("   ✓ Process monitoring working")
    except Exception as e:
        print(f"   ✗ Process monitoring failed: {e}")
        return False
    
    print("\n" + "=" * 50)
    print("🎉 All basic tests passed!")
    return True

async def test_async_functionality():
    """Test async functionality"""
    print("\n🔄 Testing async functionality...")
    
    try:
        from dashboard_server import EventBroadcaster
        broadcaster = EventBroadcaster()
        
        # Test event emission
        await broadcaster.emit_workflow_event(
            "test_workflow",
            "test_event", 
            {"message": "test"}
        )
        
        # Check if event was queued
        assert not broadcaster.event_queue.empty()
        
        # Get the event
        event = await broadcaster.event_queue.get()
        assert event["workflow_id"] == "test_workflow"
        assert event["event_type"] == "test_event"
        
        print("   ✓ Async event broadcasting working")
        return True
        
    except Exception as e:
        print(f"   ✗ Async functionality failed: {e}")
        return False

def run_performance_test():
    """Basic performance test"""
    print("\n⚡ Running performance test...")
    
    try:
        from dashboard_server import DashboardState
        from log_streamer import LogParser
        
        # Test log parsing performance
        parser = LogParser()
        state = DashboardState()
        
        start_time = datetime.now()
        
        # Process 1000 log entries
        for i in range(1000):
            log_line = f"2025-09-08 13:06:41 [INFO] [task_{i:03d}] Processing task {i}"
            entry = parser.parse_log_line(log_line, f"workflow_{i % 10}")
            state.add_log_entry(entry)
            
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print(f"   ✓ Processed 1000 log entries in {duration:.3f} seconds")
        print(f"   ✓ Rate: {1000/duration:.0f} entries/second")
        
        # Test state management performance
        start_time = datetime.now()
        
        for i in range(1000):
            seq_id = state.get_next_sequence_id()
            
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print(f"   ✓ Generated 1000 sequence IDs in {duration:.3f} seconds")
        
        return True
        
    except Exception as e:
        print(f"   ✗ Performance test failed: {e}")
        return False

def test_dashboard_server_startup():
    """Test if dashboard server can be created"""
    print("\n🖥️  Testing dashboard server startup...")
    
    try:
        # Import main components
        from main_dashboard import DashboardApplication
        
        # Create app instance (don't start it)
        app = DashboardApplication(host="127.0.0.1", port=8889)
        
        # Check that FastAPI app was created
        assert app.app is not None
        assert app.dashboard_state is not None
        assert app.websocket_hub is not None
        
        print("   ✓ Dashboard application initialized successfully")
        return True
        
    except Exception as e:
        print(f"   ✗ Dashboard server startup failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Agent Orchestrator Dashboard Backend - Simple Test Suite")
    print("=" * 60)
    
    # Track test results
    tests_passed = 0
    total_tests = 5
    
    # Run basic functionality tests
    if test_basic_functionality():
        tests_passed += 1
        
    # Run async tests
    try:
        if asyncio.run(test_async_functionality()):
            tests_passed += 1
    except Exception as e:
        print(f"Async test failed: {e}")
        
    # Run performance test
    if run_performance_test():
        tests_passed += 1
        
    # Test dashboard server creation
    if test_dashboard_server_startup():
        tests_passed += 1
        
    # Configuration validation test
    print("\n⚙️  Testing configuration...")
    try:
        # Check that requirements.txt exists
        req_file = Path(__file__).parent / "requirements.txt"
        if req_file.exists():
            print("   ✓ Requirements file found")
            tests_passed += 1
        else:
            print("   ✗ Requirements file missing")
    except Exception as e:
        print(f"   ✗ Configuration test failed: {e}")
    
    # Summary
    print("\n" + "=" * 60)
    print(f"📊 Test Results: {tests_passed}/{total_tests} tests passed")
    
    if tests_passed == total_tests:
        print("🎉 All tests passed! Dashboard backend is ready to use.")
        print("\nNext steps:")
        print("1. Install dependencies: python setup.py install")
        print("2. Start dashboard: python main_dashboard.py")
        print("3. Access dashboard at: http://localhost:8888")
        return 0
    else:
        print("❌ Some tests failed. Please check the implementation.")
        return 1

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)