#!/usr/bin/env python3
"""
GenericOrchestrator Integration Hooks
Non-intrusive integration with existing GenericOrchestrator for dashboard monitoring

Features:
- Process discovery and monitoring without modifying existing code
- State file parsing and workflow metadata extraction  
- Configuration adapter for various orchestrator setups
- Event emission for dashboard updates
- Minimal performance overhead
"""

import asyncio
import json
import logging
import os
import psutil
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from workflow_monitor import WorkflowMonitor, ProcessInfo
from log_streamer import LogStreamer, LogEntry
from deliverable_tracker import DeliverableTracker, DeliverableInfo

logger = logging.getLogger(__name__)

class OrchestratorStateParser:
    """Parses orchestrator state files and configuration"""
    
    def __init__(self):
        # Known state file patterns
        self.state_file_patterns = [
            "*orchestrator_state*.json",
            "current_*.json",
            "execution_state*.json",
            "task_state*.json"
        ]
        
        # Known configuration file patterns
        self.config_file_patterns = [
            "*_tasks.json",
            "*_analysis_tasks.json", 
            "*.json"
        ]
        
    def find_state_files(self, base_dir: Path) -> List[Path]:
        """Find orchestrator state files in directory"""
        state_files = []
        
        for pattern in self.state_file_patterns:
            state_files.extend(base_dir.rglob(pattern))
            
        return state_files
        
    def find_config_files(self, base_dir: Path) -> List[Path]:
        """Find orchestrator configuration files"""
        config_files = []
        
        for pattern in self.config_file_patterns:
            config_files.extend(base_dir.rglob(pattern))
            
        return config_files
        
    def parse_state_file(self, state_file: Path) -> Optional[Dict]:
        """Parse an orchestrator state file"""
        try:
            with open(state_file, 'r') as f:
                data = json.load(f)
                
            # Validate and normalize state data
            return self._normalize_state_data(data, state_file)
            
        except (json.JSONDecodeError, IOError, KeyError) as e:
            logger.debug(f"Could not parse state file {state_file}: {e}")
            return None
            
    def parse_config_file(self, config_file: Path) -> Optional[Dict]:
        """Parse an orchestrator configuration file"""
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)
                
            # Check if this looks like an orchestrator config
            if self._is_orchestrator_config(data):
                return self._normalize_config_data(data, config_file)
                
            return None
            
        except (json.JSONDecodeError, IOError) as e:
            logger.debug(f"Could not parse config file {config_file}: {e}")
            return None
            
    def _normalize_state_data(self, data: Dict, state_file: Path) -> Dict:
        """Normalize state data to standard format"""
        normalized = {
            'source_file': str(state_file),
            'timestamp': datetime.now().isoformat(),
            'workflow_id': self._extract_workflow_id(data, state_file),
            'status': self._extract_status(data),
            'progress': self._extract_progress(data),
            'tasks': self._extract_tasks(data),
            'metadata': self._extract_metadata(data),
            'raw_data': data
        }
        
        return normalized
        
    def _normalize_config_data(self, data: Dict, config_file: Path) -> Dict:
        """Normalize configuration data to standard format"""
        normalized = {
            'source_file': str(config_file),
            'timestamp': datetime.now().isoformat(),
            'workflow_type': self._extract_workflow_type(data, config_file),
            'task_count': len(data) if isinstance(data, list) else len(data.get('tasks', [])),
            'tasks': self._extract_task_definitions(data),
            'config': self._extract_configuration(data),
            'raw_data': data
        }
        
        return normalized
        
    def _is_orchestrator_config(self, data: Dict) -> bool:
        """Check if data looks like an orchestrator configuration"""
        # Check for common orchestrator config patterns
        if isinstance(data, list):
            # List of tasks
            if data and isinstance(data[0], dict):
                first_task = data[0]
                return any(key in first_task for key in ['task_id', 'task_type', 'prompt'])
                
        elif isinstance(data, dict):
            # Task dictionary or config with tasks
            if 'tasks' in data and isinstance(data['tasks'], list):
                return True
            if any(key in data for key in ['task_id', 'task_type', 'prompt']):
                return True
                
        return False
        
    def _extract_workflow_id(self, data: Dict, source_file: Path) -> str:
        """Extract workflow ID from state data"""
        # Try various fields
        for field in ['workflow_id', 'analysis_dir', 'app_name', 'name']:
            if field in data and data[field]:
                return str(data[field])
                
        # Derive from filename
        return f"state_{source_file.stem}"
        
    def _extract_status(self, data: Dict) -> str:
        """Extract workflow status from state data"""
        # Try various status fields
        for field in ['status', 'state', 'execution_status']:
            if field in data:
                return str(data[field]).lower()
                
        # Check for completion indicators
        if 'completed_tasks' in data and 'total_tasks' in data:
            if data['completed_tasks'] >= data['total_tasks']:
                return 'completed'
            elif data['completed_tasks'] > 0:
                return 'running'
                
        return 'unknown'
        
    def _extract_progress(self, data: Dict) -> Dict:
        """Extract progress information from state data"""
        progress = {}
        
        # Extract task counts
        if 'total_tasks' in data:
            progress['total_tasks'] = data['total_tasks']
        if 'completed_tasks' in data:
            progress['completed_tasks'] = data['completed_tasks']
        if 'failed_tasks' in data:
            progress['failed_tasks'] = data['failed_tasks']
            
        # Calculate percentage
        if 'total_tasks' in progress and 'completed_tasks' in progress:
            if progress['total_tasks'] > 0:
                progress['percentage'] = int(
                    (progress['completed_tasks'] / progress['total_tasks']) * 100
                )
                
        # Extract timing information
        for field in ['start_time', 'end_time', 'duration']:
            if field in data:
                progress[field] = data[field]
                
        return progress
        
    def _extract_tasks(self, data: Dict) -> List[Dict]:
        """Extract task information from state data"""
        tasks = []
        
        # Look for task arrays
        if 'tasks' in data and isinstance(data['tasks'], list):
            tasks.extend(data['tasks'])
        elif 'task_results' in data and isinstance(data['task_results'], dict):
            for task_id, task_data in data['task_results'].items():
                task_info = {'task_id': task_id}
                task_info.update(task_data)
                tasks.append(task_info)
                
        return tasks
        
    def _extract_metadata(self, data: Dict) -> Dict:
        """Extract metadata from state data"""
        metadata = {}
        
        # Copy relevant metadata fields
        metadata_fields = [
            'timestamp', 'analysis_dir', 'app_name', 'app_root',
            'execution_mode', 'max_parallel', 'output_dir'
        ]
        
        for field in metadata_fields:
            if field in data:
                metadata[field] = data[field]
                
        return metadata
        
    def _extract_workflow_type(self, data: Dict, source_file: Path) -> str:
        """Extract workflow type from configuration"""
        # Check filename for type hints
        filename = source_file.name.lower()
        
        if 'analysis' in filename:
            return 'analysis'
        elif 'documentation' in filename:
            return 'documentation'
        elif 'code' in filename:
            return 'code'
        elif 'research' in filename:
            return 'research'
            
        # Check task types in data
        if isinstance(data, list) and data:
            first_task = data[0]
            if isinstance(first_task, dict) and 'task_type' in first_task:
                return first_task['task_type']
                
        return 'unknown'
        
    def _extract_task_definitions(self, data: Dict) -> List[Dict]:
        """Extract task definitions from configuration"""
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and 'tasks' in data:
            return data['tasks']
        else:
            return []
            
    def _extract_configuration(self, data: Dict) -> Dict:
        """Extract configuration parameters"""
        config = {}
        
        if isinstance(data, dict):
            # Copy non-task configuration
            for key, value in data.items():
                if key not in ['tasks'] and not key.startswith('task_'):
                    config[key] = value
                    
        return config

class ProcessIntegrator:
    """Integrates with running orchestrator processes"""
    
    def __init__(self, workflow_monitor: WorkflowMonitor):
        self.workflow_monitor = workflow_monitor
        self.state_parser = OrchestratorStateParser()
        self.monitored_processes: Dict[int, Dict] = {}  # pid -> process info
        
    async def discover_and_integrate(self) -> List[Dict]:
        """Discover running orchestrator processes and integrate monitoring"""
        discovered = []
        
        # Get current processes from workflow monitor
        current_processes = self.workflow_monitor.discover_running_processes()
        
        for process_info in current_processes:
            integration_data = await self._integrate_process(process_info)
            if integration_data:
                discovered.append(integration_data)
                
        return discovered
        
    async def _integrate_process(self, process_info: ProcessInfo) -> Optional[Dict]:
        """Integrate monitoring for a specific process"""
        try:
            # Skip if already integrated
            if process_info.pid in self.monitored_processes:
                return self.monitored_processes[process_info.pid]
                
            # Get process details
            process = process_info.process
            cmdline = ' '.join(process.cmdline())
            cwd = process.cwd()
            
            # Find related files
            state_files = self._find_process_state_files(cwd, cmdline)
            config_files = self._find_process_config_files(cwd, cmdline)
            log_files = self._find_process_log_files(cwd, cmdline)
            
            # Parse available data
            state_data = {}
            for state_file in state_files:
                parsed = self.state_parser.parse_state_file(state_file)
                if parsed:
                    state_data.update(parsed)
                    
            config_data = {}
            for config_file in config_files:
                parsed = self.state_parser.parse_config_file(config_file)
                if parsed:
                    config_data.update(parsed)
                    
            # Create integration data
            integration_data = {
                'process_info': process_info.to_dict(),
                'state_files': [str(f) for f in state_files],
                'config_files': [str(f) for f in config_files],
                'log_files': [str(f) for f in log_files],
                'state_data': state_data,
                'config_data': config_data,
                'working_directory': cwd,
                'command_line': cmdline,
                'integration_timestamp': datetime.now().isoformat()
            }
            
            # Store integration data
            self.monitored_processes[process_info.pid] = integration_data
            
            logger.info(f"Integrated process {process_info.pid}: {process_info.workflow_id}")
            return integration_data
            
        except Exception as e:
            logger.error(f"Error integrating process {process_info.pid}: {e}")
            return None
            
    def _find_process_state_files(self, cwd: str, cmdline: str) -> List[Path]:
        """Find state files related to a process"""
        state_files = []
        base_dir = Path(cwd)
        
        # Look in working directory and subdirectories
        for pattern in self.state_parser.state_file_patterns:
            state_files.extend(base_dir.rglob(pattern))
            
        # Look for files mentioned in command line
        file_matches = re.findall(r'([^\s]+\.json)', cmdline)
        for match in file_matches:
            file_path = Path(match)
            if not file_path.is_absolute():
                file_path = base_dir / file_path
            if file_path.exists():
                state_files.append(file_path)
                
        return list(set(state_files))  # Remove duplicates
        
    def _find_process_config_files(self, cwd: str, cmdline: str) -> List[Path]:
        """Find configuration files related to a process"""
        config_files = []
        base_dir = Path(cwd)
        
        # Look for task files in command line
        task_file_match = re.search(r'--task[s]?[-_]?file[s]?\s+([^\s]+)', cmdline)
        if task_file_match:
            task_file = Path(task_file_match.group(1))
            if not task_file.is_absolute():
                task_file = base_dir / task_file
            if task_file.exists():
                config_files.append(task_file)
                
        # Look for other configuration files
        for pattern in self.state_parser.config_file_patterns:
            found_files = base_dir.rglob(pattern)
            for file_path in found_files:
                # Check if it's likely an orchestrator config
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                    if self.state_parser._is_orchestrator_config(data):
                        config_files.append(file_path)
                except:
                    continue
                    
        return list(set(config_files))
        
    def _find_process_log_files(self, cwd: str, cmdline: str) -> List[Path]:
        """Find log files related to a process"""
        log_files = []
        base_dir = Path(cwd)
        
        # Common log file patterns
        log_patterns = [
            "*orchestrator*.log",
            "*orchestrator*.out",
            "logs/*",
            "output/logs/*",
            "outputs/*/logs/*"
        ]
        
        for pattern in log_patterns:
            log_files.extend(base_dir.rglob(pattern))
            
        return list(set(log_files))

class DashboardIntegration:
    """Main integration class for dashboard monitoring"""
    
    def __init__(self, 
                 orchestrator_base_dir: str = "/home/opsvi/master_root/apps/agent-orchestrator",
                 on_workflow_event: Optional[callable] = None):
        self.orchestrator_base_dir = Path(orchestrator_base_dir)
        self.on_workflow_event = on_workflow_event
        
        # Core components
        self.workflow_monitor = WorkflowMonitor(str(self.orchestrator_base_dir))
        self.process_integrator = ProcessIntegrator(self.workflow_monitor)
        self.log_streamer = None
        self.deliverable_tracker = None
        
        # State
        self.integrated_workflows: Dict[str, Dict] = {}
        self.monitoring_active = False
        
    async def start_integration(self):
        """Start the complete dashboard integration"""
        logger.info("Starting dashboard integration")
        self.monitoring_active = True
        
        # Start workflow monitor
        await self.workflow_monitor.start_monitoring()
        
        # Start log streamer
        self.log_streamer = LogStreamer(
            base_directories=[
                self.orchestrator_base_dir / "outputs",
                self.orchestrator_base_dir / "output", 
                self.orchestrator_base_dir / "logs"
            ],
            on_log_entry=self._handle_log_entry
        )
        await self.log_streamer.start_streaming()
        
        # Start deliverable tracker
        self.deliverable_tracker = DeliverableTracker(
            output_directories=[
                self.orchestrator_base_dir / "outputs",
                self.orchestrator_base_dir / "output",
                self.orchestrator_base_dir / "wbs_output"
            ],
            on_deliverable_created=self._handle_deliverable_created,
            on_deliverable_updated=self._handle_deliverable_updated,
            on_deliverable_deleted=self._handle_deliverable_deleted
        )
        await self.deliverable_tracker.start_tracking()
        
        # Start integration monitoring loop
        asyncio.create_task(self._integration_loop())
        
        logger.info("Dashboard integration started successfully")
        
    async def stop_integration(self):
        """Stop the dashboard integration"""
        logger.info("Stopping dashboard integration")
        self.monitoring_active = False
        
        # Stop components
        await self.workflow_monitor.stop_monitoring()
        if self.log_streamer:
            await self.log_streamer.stop_streaming()
        if self.deliverable_tracker:
            await self.deliverable_tracker.stop_tracking()
            
    async def _integration_loop(self):
        """Main integration monitoring loop"""
        while self.monitoring_active:
            try:
                # Discover and integrate new processes
                integrations = await self.process_integrator.discover_and_integrate()
                
                # Update integrated workflows
                for integration in integrations:
                    workflow_id = integration['process_info']['workflow_id']
                    
                    # Check if this is a new workflow
                    if workflow_id not in self.integrated_workflows:
                        self.integrated_workflows[workflow_id] = integration
                        await self._emit_workflow_event(
                            workflow_id, 
                            "workflow_discovered",
                            integration
                        )
                    else:
                        # Update existing workflow
                        self.integrated_workflows[workflow_id].update(integration)
                        
                # Check for completed workflows
                await self._check_completed_workflows()
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Integration loop error: {e}")
                await asyncio.sleep(15)
                
    async def _check_completed_workflows(self):
        """Check for workflows that have completed"""
        active_pids = {
            info.pid for info in self.workflow_monitor.monitored_processes.values()
        }
        
        completed_workflows = []
        for workflow_id, integration in self.integrated_workflows.items():
            process_pid = integration['process_info']['pid']
            if process_pid not in active_pids:
                completed_workflows.append(workflow_id)
                
        # Handle completed workflows
        for workflow_id in completed_workflows:
            await self._handle_workflow_completion(workflow_id)
            
    async def _handle_workflow_completion(self, workflow_id: str):
        """Handle completion of a workflow"""
        integration = self.integrated_workflows.get(workflow_id)
        if integration:
            # Update status
            integration['process_info']['status'] = 'completed'
            integration['completion_timestamp'] = datetime.now().isoformat()
            
            # Emit completion event
            await self._emit_workflow_event(
                workflow_id,
                "workflow_completed", 
                integration
            )
            
    async def _handle_log_entry(self, log_entry: LogEntry):
        """Handle new log entry from log streamer"""
        await self._emit_workflow_event(
            log_entry.workflow_id,
            "log_entry",
            log_entry.to_dict()
        )
        
    async def _handle_deliverable_created(self, deliverable: DeliverableInfo):
        """Handle new deliverable from deliverable tracker"""
        await self._emit_workflow_event(
            deliverable.workflow_id,
            "deliverable_created",
            deliverable.to_dict()
        )
        
    async def _handle_deliverable_updated(self, deliverable: DeliverableInfo):
        """Handle deliverable update"""
        await self._emit_workflow_event(
            deliverable.workflow_id, 
            "deliverable_updated",
            deliverable.to_dict()
        )
        
    async def _handle_deliverable_deleted(self, file_path: str):
        """Handle deliverable deletion"""
        # Find workflow ID for this file (simplified)
        for workflow_id in self.integrated_workflows:
            await self._emit_workflow_event(
                workflow_id,
                "deliverable_deleted", 
                {"file_path": file_path}
            )
            break
            
    async def _emit_workflow_event(self, workflow_id: str, event_type: str, data: Dict):
        """Emit workflow event to dashboard"""
        if self.on_workflow_event:
            try:
                await self.on_workflow_event(workflow_id, event_type, data)
            except Exception as e:
                logger.error(f"Error emitting workflow event: {e}")
                
        logger.debug(f"Workflow event: {workflow_id} - {event_type}")
        
    def get_workflow_overview(self) -> Dict:
        """Get overview of all integrated workflows"""
        return {
            'total_workflows': len(self.integrated_workflows),
            'active_workflows': len(self.workflow_monitor.monitored_processes),
            'workflows': list(self.integrated_workflows.values()),
            'monitoring_status': 'active' if self.monitoring_active else 'inactive'
        }
        
    def get_workflow_details(self, workflow_id: str) -> Optional[Dict]:
        """Get detailed information about a specific workflow"""
        integration = self.integrated_workflows.get(workflow_id)
        if not integration:
            return None
            
        # Add real-time information
        details = integration.copy()
        
        # Add log information
        if self.log_streamer:
            recent_logs = self.log_streamer.get_workflow_logs(workflow_id, limit=50)
            details['recent_logs'] = [log.to_dict() for log in recent_logs]
            
        # Add deliverable information 
        if self.deliverable_tracker:
            deliverables = self.deliverable_tracker.get_workflow_deliverables(workflow_id)
            details['deliverables'] = [d.to_dict() for d in deliverables]
            
        return details

# Factory function for dashboard server integration
async def create_dashboard_integration(dashboard_state, event_broadcaster):
    """Create dashboard integration with event broadcasting"""
    
    async def handle_workflow_event(workflow_id: str, event_type: str, data: Dict):
        """Handle workflow events and update dashboard state"""
        
        # Update dashboard state based on event type
        if event_type == "workflow_discovered":
            # Add new workflow to state
            workflow_info = data['process_info']
            dashboard_state.workflows[workflow_id] = {
                'workflow_id': workflow_id,
                'name': workflow_info.get('task_file', workflow_id),
                'task_type': 'orchestrator',
                'status': 'running',
                'started_at': workflow_info.get('started_at'),
                'process_id': workflow_info.get('pid'),
                'config': data.get('config_data', {}),
                'log_file': data.get('log_files', [None])[0]
            }
            
        elif event_type == "workflow_completed":
            # Update workflow status
            if workflow_id in dashboard_state.workflows:
                dashboard_state.workflows[workflow_id]['status'] = 'completed'
                dashboard_state.workflows[workflow_id]['completed_at'] = data.get('completion_timestamp')
                
        elif event_type == "log_entry":
            # Add log entry
            dashboard_state.add_log_entry(LogEntry(
                workflow_id=data['workflow_id'],
                raw_line=data['raw_line'],
                timestamp=datetime.fromisoformat(data['timestamp']),
                level=data['level'],
                message=data['message'],
                task_id=data.get('task_id'),
                metadata=data.get('metadata', {})
            ))
            
        # Broadcast event via WebSocket
        await event_broadcaster.emit_workflow_event(workflow_id, event_type, data)
        
    # Create integration
    integration = DashboardIntegration(
        on_workflow_event=handle_workflow_event
    )
    
    await integration.start_integration()
    return integration