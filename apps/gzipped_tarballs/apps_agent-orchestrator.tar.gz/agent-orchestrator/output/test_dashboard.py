#!/usr/bin/env python3
"""
Test Suite for Dashboard Backend
Tests core functionality and integration components

Usage:
    python test_dashboard.py
    python -m pytest test_dashboard.py -v
"""

import asyncio
import json
import tempfile
import time
from datetime import datetime
from pathlib import Path
import pytest
from unittest.mock import Mock, patch, AsyncMock

# Import dashboard components
from dashboard_server import DashboardState, WebSocketHub, EventBroadcaster
from workflow_monitor import WorkflowMonitor, ProcessInfo
from log_streamer import LogStreamer, LogEntry, LogParser
from deliverable_tracker import DeliverableTracker, DeliverableInfo

class TestDashboardState:
    """Test dashboard state management"""
    
    def setup_method(self):
        self.state = DashboardState()
        
    def test_initialization(self):
        """Test dashboard state initialization"""
        assert len(self.state.workflows) == 0
        assert len(self.state.tasks) == 0
        assert len(self.state.recent_logs) == 0
        assert len(self.state.deliverables) == 0
        assert self.state.sequence_counter == 0
        
    def test_sequence_counter(self):
        """Test sequence ID generation"""
        id1 = self.state.get_next_sequence_id()
        id2 = self.state.get_next_sequence_id()
        
        assert id1 == 1
        assert id2 == 2
        assert id2 > id1
        
    def test_log_entry_management(self):
        """Test log entry storage and retrieval"""
        # Add log entries
        for i in range(5):
            entry = LogEntry(
                workflow_id="test_workflow",
                raw_line=f"Test log {i}",
                level="INFO",
                message=f"Test message {i}"
            )
            self.state.add_log_entry(entry)
        
        assert len(self.state.recent_logs) == 5
        
        # Test workflow-specific retrieval
        workflow_logs = self.state.get_workflow_logs("test_workflow", limit=3)
        assert len(workflow_logs) == 3
        
        # Test limit enforcement (max 1000 entries)
        for i in range(1000):
            entry = LogEntry(
                workflow_id="bulk_test",
                raw_line=f"Bulk log {i}",
                level="DEBUG"
            )
            self.state.add_log_entry(entry)
            
        assert len(self.state.recent_logs) <= 1000

class TestLogParser:
    """Test log parsing functionality"""
    
    def setup_method(self):
        self.parser = LogParser()
        
    def test_python_logging_pattern(self):
        """Test Python logging pattern parsing"""
        log_line = "2025-09-08 13:06:41,123 INFO orchestrator.main Task completed successfully"
        entry = self.parser.parse_log_line(log_line, "test_workflow")
        
        assert entry.level == "INFO"
        assert "Task completed successfully" in entry.message
        assert entry.workflow_id == "test_workflow"
        
    def test_orchestrator_pattern(self):
        """Test orchestrator-specific pattern parsing"""
        log_line = "2025-09-08 13:06:41 [INFO] [task_123] Starting analysis task"
        entry = self.parser.parse_log_line(log_line, "test_workflow")
        
        assert entry.level == "INFO"
        assert entry.task_id == "task_123"
        assert "Starting analysis task" in entry.message
        
    def test_task_execution_pattern(self):
        """Test task execution pattern parsing"""
        log_line = "Task analysis_001 completed successfully"
        entry = self.parser.parse_log_line(log_line, "test_workflow")
        
        assert "analysis_001" in entry.message
        assert entry.workflow_id == "test_workflow"
        
    def test_level_extraction(self):
        """Test log level extraction from various formats"""
        test_cases = [
            ("ERROR: Something went wrong", "ERROR"),
            ("WARNING: This is a warning", "WARNING"), 
            ("DEBUG: Debug information", "DEBUG"),
            ("CRITICAL: System failure", "CRITICAL"),
            ("Regular message", "INFO")  # Default level
        ]
        
        for log_line, expected_level in test_cases:
            entry = self.parser.parse_log_line(log_line, "test_workflow")
            assert entry.level == expected_level

class TestDeliverableInfo:
    """Test deliverable information handling"""
    
    def setup_method(self):
        # Create a temporary test file
        self.temp_dir = Path(tempfile.mkdtemp())
        self.test_file = self.temp_dir / "test_deliverable.md"
        self.test_file.write_text("# Test Deliverable\n\nThis is a test markdown file.")
        
    def teardown_method(self):
        # Clean up temporary files
        if self.test_file.exists():
            self.test_file.unlink()
        self.temp_dir.rmdir()
        
    def test_file_info_extraction(self):
        """Test file information extraction"""
        deliverable = DeliverableInfo(self.test_file, "test_workflow", "task_001")
        
        assert deliverable.filename == "test_deliverable.md"
        assert deliverable.workflow_id == "test_workflow"
        assert deliverable.task_id == "task_001"
        assert deliverable.file_size > 0
        assert deliverable.content_type == "text/markdown"
        
    def test_checksum_calculation(self):
        """Test file checksum calculation"""
        deliverable = DeliverableInfo(self.test_file, "test_workflow")
        
        assert deliverable.checksum is not None
        assert len(deliverable.checksum) == 64  # SHA256 hex length
        
    def test_preview_content(self):
        """Test preview content generation"""
        deliverable = DeliverableInfo(self.test_file, "test_workflow")
        
        preview = deliverable.get_preview_content(max_size=100)
        assert preview is not None
        assert "Test Deliverable" in preview
        
    def test_file_type_detection(self):
        """Test file type detection methods"""
        deliverable = DeliverableInfo(self.test_file, "test_workflow")
        
        assert deliverable.is_text_file() == True
        assert deliverable.is_image_file() == False
        assert deliverable.is_document_file() == True  # Markdown is considered a document
        
    def test_serialization(self):
        """Test dictionary serialization"""
        deliverable = DeliverableInfo(self.test_file, "test_workflow", "task_001")
        data = deliverable.to_dict()
        
        required_fields = [
            'workflow_id', 'task_id', 'filename', 'file_path',
            'file_size', 'content_type', 'created_at'
        ]
        
        for field in required_fields:
            assert field in data

@pytest.mark.asyncio
class TestWebSocketHub:
    """Test WebSocket connection management"""
    
    def setup_method(self):
        self.hub = WebSocketHub()
        
    async def test_connection_management(self):
        """Test WebSocket connection and disconnection"""
        # Mock WebSocket
        mock_websocket = Mock()
        mock_websocket.accept = AsyncMock()
        
        session_id = "test_session_001"
        
        # Test connection
        await self.hub.connect(mock_websocket, session_id)
        
        assert session_id in self.hub.connections
        assert session_id in self.hub.session_workflows
        mock_websocket.accept.assert_called_once()
        
        # Test disconnection
        await self.hub.disconnect(session_id)
        
        assert session_id not in self.hub.connections
        assert session_id not in self.hub.session_workflows
        
    async def test_workflow_subscription(self):
        """Test workflow subscription management"""
        # Mock WebSocket
        mock_websocket = Mock()
        mock_websocket.accept = AsyncMock()
        
        session_id = "test_session_002"
        workflow_id = "test_workflow_001"
        
        # Connect session
        await self.hub.connect(mock_websocket, session_id)
        
        # Subscribe to workflow
        await self.hub.subscribe_to_workflow(session_id, workflow_id)
        
        assert workflow_id in self.hub.subscriptions
        assert session_id in self.hub.subscriptions[workflow_id]
        assert workflow_id in self.hub.session_workflows[session_id]
        
    async def test_message_broadcasting(self):
        """Test message broadcasting to subscribed sessions"""
        # Mock WebSocket
        mock_websocket = Mock()
        mock_websocket.accept = AsyncMock()
        mock_websocket.send_text = AsyncMock()
        mock_websocket.client_state = 1  # WebSocketState.CONNECTED
        
        session_id = "test_session_003"
        workflow_id = "test_workflow_002"
        
        # Setup connection and subscription
        await self.hub.connect(mock_websocket, session_id)
        await self.hub.subscribe_to_workflow(session_id, workflow_id)
        
        # Broadcast message
        test_message = {
            "event_type": "test_event",
            "data": {"test": "data"}
        }
        
        await self.hub.broadcast_to_workflow(workflow_id, test_message)
        
        # Verify message was sent
        mock_websocket.send_text.assert_called()
        sent_data = mock_websocket.send_text.call_args[0][0]
        sent_message = json.loads(sent_data)
        
        assert sent_message["event_type"] == "test_event"
        assert sent_message["data"]["test"] == "data"

@pytest.mark.asyncio  
class TestEventBroadcaster:
    """Test event broadcasting system"""
    
    def setup_method(self):
        self.broadcaster = EventBroadcaster()
        
    async def test_event_emission(self):
        """Test event emission to queue"""
        workflow_id = "test_workflow"
        event_type = "test_event"
        test_data = {"message": "test"}
        
        # Emit event
        await self.broadcaster.emit_workflow_event(workflow_id, event_type, test_data)
        
        # Check if event was queued
        assert not self.broadcaster.event_queue.empty()
        
        # Process event
        event = await self.broadcaster.event_queue.get()
        
        assert event["workflow_id"] == workflow_id
        assert event["event_type"] == event_type
        assert event["data"] == test_data
        assert "timestamp" in event
        assert "sequence_id" in event

class TestWorkflowMonitor:
    """Test workflow monitoring functionality"""
    
    def setup_method(self):
        self.monitor = WorkflowMonitor()
        
    def test_initialization(self):
        """Test monitor initialization"""
        assert len(self.monitor.monitored_processes) == 0
        assert len(self.monitor.workflow_states) == 0
        assert self.monitor.monitoring_active == False
        
    def test_process_patterns(self):
        """Test process pattern matching"""
        test_patterns = self.monitor.process_patterns
        
        # Test command lines that should match
        matching_commands = [
            "python main.py --task-file analysis.json",
            "python generic_orchestrator.py",
            "python run_orchestrator_task.py --app-name test",
            "/usr/bin/python3 run_system_analysis.py --target /path"
        ]
        
        import re
        for command in matching_commands:
            matched = any(re.search(pattern, command, re.IGNORECASE) for pattern in test_patterns)
            assert matched, f"Command should match: {command}"
            
    def test_workflow_id_generation(self):
        """Test workflow ID generation from process info"""
        # Mock process for testing
        mock_process = Mock()
        mock_process.pid = 12345
        
        process_info = ProcessInfo(12345, mock_process)
        
        # Test with task file
        cmdline = "python main.py --task-file system_analysis.json"
        self.monitor._extract_process_metadata(process_info, cmdline)
        
        assert process_info.task_file == "system_analysis.json"
        assert process_info.workflow_id is not None
        
        # Test with app name
        process_info2 = ProcessInfo(67890, mock_process)
        cmdline2 = "python run_orchestrator_task.py --app-name test-app"
        self.monitor._extract_process_metadata(process_info2, cmdline2)
        
        assert "app_test-app" in process_info2.workflow_id

def run_integration_test():
    """Run integration test with real components"""
    print("🔄 Running integration test...")
    
    async def integration_test():
        # Create temporary test environment
        test_dir = Path(tempfile.mkdtemp())
        
        try:
            # Create test log file
            log_file = test_dir / "test_orchestrator.log"
            with open(log_file, 'w') as f:
                f.write("2025-09-08 13:06:41 [INFO] Starting orchestrator\n")
                f.write("2025-09-08 13:06:42 [INFO] [task_001] Task started\n")
                f.write("2025-09-08 13:06:45 [INFO] [task_001] Task completed\n")
                
            # Create test deliverable
            deliverable_file = test_dir / "output.md" 
            deliverable_file.write_text("# Test Output\n\nGenerated content")
            
            # Test log streamer
            log_entries = []
            
            def on_log_entry(entry):
                log_entries.append(entry)
                
            log_streamer = LogStreamer(
                base_directories=[test_dir],
                on_log_entry=on_log_entry
            )
            
            await log_streamer.start_streaming()
            
            # Wait for log discovery
            await asyncio.sleep(1)
            
            # Append to log file to trigger events
            with open(log_file, 'a') as f:
                f.write("2025-09-08 13:06:50 [INFO] New log entry\n")
                
            # Wait for processing
            await asyncio.sleep(1)
            
            await log_streamer.stop_streaming()
            
            # Test deliverable tracker
            deliverables = []
            
            def on_deliverable_created(deliverable):
                deliverables.append(deliverable)
                
            deliverable_tracker = DeliverableTracker(
                output_directories=[test_dir],
                on_deliverable_created=on_deliverable_created
            )
            
            await deliverable_tracker.start_tracking()
            
            # Create new deliverable
            new_file = test_dir / "new_output.json"
            new_file.write_text('{"result": "success"}')
            
            # Wait for processing
            await asyncio.sleep(2)
            
            await deliverable_tracker.stop_tracking()
            
            # Verify results
            print(f"✓ Log entries processed: {len(log_entries)}")
            print(f"✓ Deliverables tracked: {len(deliverables)}")
            
            assert len(log_entries) > 0, "No log entries were processed"
            
            success = True
            
        except Exception as e:
            print(f"✗ Integration test failed: {e}")
            success = False
            
        finally:
            # Cleanup
            import shutil
            shutil.rmtree(test_dir)
            
        return success
        
    # Run the async test
    result = asyncio.run(integration_test())
    
    if result:
        print("✅ Integration test passed")
    else:
        print("❌ Integration test failed")
        
    return result

def main():
    """Run all tests"""
    print("🧪 Agent Orchestrator Dashboard Backend Tests")
    print("=" * 50)
    
    # Run unit tests
    print("\n📋 Running unit tests...")
    
    try:
        # Run pytest if available, otherwise run individual test classes
        import pytest
        result = pytest.main([__file__, "-v"])
        unit_tests_passed = result == 0
    except ImportError:
        print("pytest not available, running tests manually...")
        unit_tests_passed = True
        
        # Manual test execution
        test_classes = [
            TestDashboardState,
            TestLogParser, 
            TestDeliverableInfo,
            TestWorkflowMonitor
        ]
        
        for test_class in test_classes:
            try:
                test_instance = test_class()
                test_instance.setup_method()
                
                # Run test methods
                for method_name in dir(test_instance):
                    if method_name.startswith('test_'):
                        print(f"  Running {test_class.__name__}.{method_name}")
                        getattr(test_instance, method_name)()
                        
                print(f"✓ {test_class.__name__} passed")
            except Exception as e:
                print(f"✗ {test_class.__name__} failed: {e}")
                unit_tests_passed = False
                
    # Run integration tests
    print("\n🔗 Running integration tests...")
    integration_tests_passed = run_integration_test()
    
    # Summary
    print("\n" + "=" * 50)
    if unit_tests_passed and integration_tests_passed:
        print("🎉 All tests passed!")
        return 0
    else:
        print("💥 Some tests failed!")
        return 1

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)