#!/usr/bin/env python3
"""
Main Dashboard Application
Complete orchestrator dashboard with real-time monitoring

Integrates:
- FastAPI server with WebSocket endpoints
- WorkflowMonitor for process tracking
- LogStreamer for real-time log tailing
- DeliverableTracker for file monitoring
- OrchestrationIntegration for seamless monitoring

Usage:
    python main_dashboard.py [--port 8888] [--host 0.0.0.0]
"""

import asyncio
import argparse
import logging
import signal
import sys
from datetime import datetime
from pathlib import Path

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

# Import our dashboard components
from dashboard_server import (
    DashboardState, WebSocketHub, EventBroadcaster, 
    WorkflowStatus, TaskStatus, LogEntry, Deliverable
)
from workflow_monitor import WorkflowMonitor
from log_streamer import LogStreamer
from deliverable_tracker import DeliverableTracker
from orchestrator_integration import create_dashboard_integration

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DashboardApplication:
    """Main dashboard application orchestrating all components"""
    
    def __init__(self, host: str = "0.0.0.0", port: int = 8888):
        self.host = host
        self.port = port
        self.app = FastAPI(
            title="Agent Orchestrator Dashboard",
            description="Real-time monitoring dashboard for agent orchestrator workflows",
            version="1.0.0"
        )
        
        # Core state and components
        self.dashboard_state = DashboardState()
        self.websocket_hub = WebSocketHub()
        self.event_broadcaster = EventBroadcaster()
        
        # Monitoring components
        self.workflow_monitor = None
        self.log_streamer = None
        self.deliverable_tracker = None
        self.integration = None
        
        # Application state
        self.running = False
        
        # Setup application
        self._setup_middleware()
        self._setup_routes()
        
    def _setup_middleware(self):
        """Setup FastAPI middleware"""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],  # Configure appropriately for production
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Add request logging middleware
        @self.app.middleware("http")
        async def log_requests(request: Request, call_next):
            start_time = datetime.now()
            response = await call_next(request)
            process_time = (datetime.now() - start_time).total_seconds()
            
            logger.debug(
                f"{request.method} {request.url.path} - "
                f"{response.status_code} - {process_time:.3f}s"
            )
            return response
            
    def _setup_routes(self):
        """Setup FastAPI routes"""
        
        # Serve dashboard HTML
        @self.app.get("/")
        async def dashboard_ui():
            dashboard_file = Path(__file__).parent / "dashboard.html"
            if dashboard_file.exists():
                return FileResponse(dashboard_file, media_type="text/html")
            else:
                return {"error": "Dashboard HTML not found"}
        
        # API status check
        @self.app.get("/api/status")
        async def api_status():
            return {
                "service": "Agent Orchestrator Dashboard",
                "version": "1.0.0",
                "status": "healthy" if self.running else "starting",
                "timestamp": datetime.now().isoformat(),
                "uptime_seconds": (datetime.now() - self.dashboard_state.start_time).total_seconds()
            }
            
        @self.app.get("/health")
        async def health_check():
            return {
                "status": "healthy" if self.running else "starting",
                "components": {
                    "workflow_monitor": self.workflow_monitor is not None,
                    "log_streamer": self.log_streamer is not None,
                    "deliverable_tracker": self.deliverable_tracker is not None,
                    "integration": self.integration is not None
                },
                "metrics": {
                    "active_workflows": len([w for w in self.dashboard_state.workflows.values() if w.status == "running"]),
                    "total_workflows": len(self.dashboard_state.workflows),
                    "websocket_connections": len(self.websocket_hub.connections),
                    "log_entries": len(self.dashboard_state.recent_logs)
                }
            }
            
        # Dashboard status and metrics
        @self.app.get("/dashboard/status")
        async def get_dashboard_status():
            active_workflows = [w for w in self.dashboard_state.workflows.values() if w.status == "running"]
            completed_workflows = [w for w in self.dashboard_state.workflows.values() if w.status == "completed"]
            failed_workflows = [w for w in self.dashboard_state.workflows.values() if w.status == "failed"]
            
            return {
                "total_workflows": len(self.dashboard_state.workflows),
                "active_workflows": len(active_workflows),
                "completed_workflows": len(completed_workflows),
                "failed_workflows": len(failed_workflows),
                "total_tasks": len(self.dashboard_state.tasks),
                "websocket_connections": len(self.websocket_hub.connections),
                "recent_log_entries": len(self.dashboard_state.recent_logs),
                "uptime_seconds": (datetime.now() - self.dashboard_state.start_time).total_seconds(),
                "timestamp": datetime.now().isoformat()
            }
            
        # Workflow management
        @self.app.get("/workflows")
        async def list_workflows(status: str = None, limit: int = 100, offset: int = 0):
            workflows = list(self.dashboard_state.workflows.values())
            
            # Filter by status if provided
            if status:
                workflows = [w for w in workflows if w.status == status]
            
            # Apply pagination
            total = len(workflows)
            workflows = workflows[offset:offset + limit]
            
            return {
                "workflows": [w.dict() if hasattr(w, 'dict') else w for w in workflows],
                "total": total,
                "limit": limit,
                "offset": offset
            }
            
        @self.app.get("/workflows/{workflow_id}")
        async def get_workflow(workflow_id: str):
            workflow = self.dashboard_state.workflows.get(workflow_id)
            if not workflow:
                raise HTTPException(status_code=404, detail="Workflow not found")
            
            # Get additional details from integration
            details = {}
            if self.integration:
                integration_details = self.integration.get_workflow_details(workflow_id)
                if integration_details:
                    details.update(integration_details)
            
            # Get related tasks
            workflow_tasks = [t for t in self.dashboard_state.tasks.values() if t.workflow_id == workflow_id]
            
            # Get recent logs
            recent_logs = self.dashboard_state.get_workflow_logs(workflow_id, limit=50)
            
            # Get deliverables
            deliverables = self.dashboard_state.deliverables.get(workflow_id, [])
            
            return {
                "workflow": workflow.dict() if hasattr(workflow, 'dict') else workflow,
                "tasks": [t.dict() if hasattr(t, 'dict') else t for t in workflow_tasks],
                "recent_logs": [log.dict() if hasattr(log, 'dict') else log for log in recent_logs],
                "deliverables": deliverables,
                "integration_details": details
            }
            
        @self.app.get("/workflows/{workflow_id}/logs")
        async def get_workflow_logs(workflow_id: str, limit: int = 100, level: str = None):
            if workflow_id not in self.dashboard_state.workflows:
                raise HTTPException(status_code=404, detail="Workflow not found")
            
            logs = self.dashboard_state.get_workflow_logs(workflow_id, limit)
            
            # Filter by level if provided
            if level:
                logs = [log for log in logs if log.level == level.upper()]
            
            return {
                "logs": [log.dict() if hasattr(log, 'dict') else log for log in logs],
                "workflow_id": workflow_id,
                "count": len(logs)
            }
            
        @self.app.get("/workflows/{workflow_id}/deliverables")
        async def get_workflow_deliverables(workflow_id: str):
            if workflow_id not in self.dashboard_state.workflows:
                raise HTTPException(status_code=404, detail="Workflow not found")
                
            deliverables = self.dashboard_state.deliverables.get(workflow_id, [])
            return {
                "deliverables": deliverables,
                "workflow_id": workflow_id,
                "count": len(deliverables)
            }
            
        # Task management
        @self.app.get("/tasks")
        async def list_tasks(
            workflow_id: str = None,
            status: str = None,
            limit: int = 100,
            offset: int = 0
        ):
            tasks = list(self.dashboard_state.tasks.values())
            
            # Filter by workflow_id if provided
            if workflow_id:
                tasks = [t for t in tasks if t.workflow_id == workflow_id]
            
            # Filter by status if provided
            if status:
                tasks = [t for t in tasks if t.status == status]
            
            # Apply pagination
            total = len(tasks)
            tasks = tasks[offset:offset + limit]
            
            return {
                "tasks": [t.dict() if hasattr(t, 'dict') else t for t in tasks],
                "total": total,
                "limit": limit,
                "offset": offset
            }
            
        @self.app.get("/tasks/{task_id}")
        async def get_task(task_id: str):
            task = self.dashboard_state.tasks.get(task_id)
            if not task:
                raise HTTPException(status_code=404, detail="Task not found")
            
            return task.dict() if hasattr(task, 'dict') else task
            
        # File serving for deliverables
        @self.app.get("/download/{workflow_id}/{filename}")
        async def download_file(workflow_id: str, filename: str):
            # Find the file in deliverables
            deliverables = self.dashboard_state.deliverables.get(workflow_id, [])
            
            target_file = None
            for deliverable in deliverables:
                if deliverable.get('filename') == filename:
                    target_file = deliverable.get('file_path')
                    break
                    
            if not target_file or not Path(target_file).exists():
                raise HTTPException(status_code=404, detail="File not found")
                
            return FileResponse(
                path=target_file,
                filename=filename,
                media_type='application/octet-stream'
            )
            
        # WebSocket endpoint
        @self.app.websocket("/ws/{session_id}")
        async def websocket_endpoint(websocket: WebSocket, session_id: str):
            await self.websocket_hub.connect(websocket, session_id)
            logger.info(f"WebSocket connected: {session_id}")
            
            try:
                while True:
                    # Receive messages from client
                    data = await websocket.receive_text()
                    await self._handle_websocket_message(session_id, data)
                    
            except WebSocketDisconnect:
                logger.info(f"WebSocket disconnected: {session_id}")
            except Exception as e:
                logger.error(f"WebSocket error for {session_id}: {e}")
            finally:
                await self.websocket_hub.disconnect(session_id)
                
    async def _handle_websocket_message(self, session_id: str, data: str):
        """Handle incoming WebSocket messages"""
        try:
            import json
            message = json.loads(data)
            message_type = message.get("type", "")
            
            if message_type == "subscribe":
                # Subscribe to specific workflows
                workflow_ids = message.get("workflow_ids", [])
                for workflow_id in workflow_ids:
                    await self.websocket_hub.subscribe_to_workflow(session_id, workflow_id)
                    
            elif message_type == "subscribe_all":
                # Subscribe to all workflows
                for workflow_id in self.dashboard_state.workflows.keys():
                    await self.websocket_hub.subscribe_to_workflow(session_id, workflow_id)
                    
            elif message_type == "ping":
                # Respond to ping with pong
                await self.websocket_hub.send_to_session(session_id, {
                    "type": "pong",
                    "timestamp": datetime.now().isoformat()
                })
                
        except Exception as e:
            logger.error(f"Error handling WebSocket message from {session_id}: {e}")
            
    async def start_application(self):
        """Start the complete dashboard application"""
        logger.info("Starting Agent Orchestrator Dashboard")
        
        try:
            # Initialize monitoring components with integration
            logger.info("Initializing dashboard integration...")
            self.integration = await create_dashboard_integration(
                self.dashboard_state,
                self.event_broadcaster
            )
            
            # Start event broadcaster
            logger.info("Starting event broadcaster...")
            asyncio.create_task(self.event_broadcaster.process_events())
            
            # Mark as running
            self.running = True
            logger.info("Dashboard application started successfully")
            
        except Exception as e:
            logger.error(f"Failed to start dashboard application: {e}")
            raise
            
    async def stop_application(self):
        """Stop the dashboard application"""
        logger.info("Stopping Agent Orchestrator Dashboard")
        self.running = False
        
        # Stop integration
        if self.integration:
            await self.integration.stop_integration()
            
        logger.info("Dashboard application stopped")
        
    def run(self):
        """Run the dashboard application"""
        
        # Setup signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, shutting down...")
            asyncio.create_task(self.stop_application())
            
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Create startup event handler
        @self.app.on_event("startup")
        async def startup_event():
            await self.start_application()
            
        @self.app.on_event("shutdown")
        async def shutdown_event():
            await self.stop_application()
            
        # Run the server
        logger.info(f"Starting server on {self.host}:{self.port}")
        uvicorn.run(
            self.app,
            host=self.host,
            port=self.port,
            log_level="info",
            access_log=True
        )

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Agent Orchestrator Dashboard")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8888, help="Port to bind to")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    
    args = parser.parse_args()
    
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        
    # Create and run dashboard
    dashboard = DashboardApplication(host=args.host, port=args.port)
    
    try:
        dashboard.run()
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"Dashboard failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()