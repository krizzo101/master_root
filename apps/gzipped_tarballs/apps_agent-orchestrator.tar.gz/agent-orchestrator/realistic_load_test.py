#!/usr/bin/env python3
"""
Realistic Load Test for Dashboard
Creates a realistic workload with long-running tasks and concurrent workflows
"""
import sys
import time
import random
import threading
from pathlib import Path
from typing import Dict, Set
import uuid

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from monitoring.metrics_collector import get_global_collector, MetricType, Metric

class RealisticWorkloadSimulator:
    """Simulates realistic orchestrator workload"""
    
    def __init__(self):
        self.collector = get_global_collector()
        self.running = False
        self.active_workflows = {
            'dashboard_build_20250908_123000': {'agents': 3, 'active_tasks': set()},
            'system_documentation_20250908_130547': {'agents': 2, 'active_tasks': set()}, 
            'analysis_20250907_174810': {'agents': 4, 'active_tasks': set()},
            'apps_audit_20250908_003231': {'agents': 2, 'active_tasks': set()},
            'live_chat_test': {'agents': 1, 'active_tasks': set()},
            'custom_analysis_20250908_140000': {'agents': 3, 'active_tasks': set()},
            'deployment_20250908_141000': {'agents': 2, 'active_tasks': set()},
            'testing_20250908_142000': {'agents': 1, 'active_tasks': set()},
            'integration_20250908_143000': {'agents': 2, 'active_tasks': set()},
            'monitoring_20250908_144000': {'agents': 1, 'active_tasks': set()},
        }
        self.task_counter = 0
        
    def start_long_running_tasks(self):
        """Start some long-running tasks that stay active"""
        print("🚀 Starting long-running tasks...")
        
        for workflow_id, info in self.active_workflows.items():
            for agent_idx in range(info['agents']):
                agent_id = f"{workflow_id}_agent_{agent_idx+1}"
                
                # Start 2-3 long-running tasks per agent
                for _ in range(random.randint(2, 3)):
                    task_id = f"{workflow_id}_task_{self.task_counter}"
                    self.task_counter += 1
                    
                    self.collector.record_task_started(
                        task_id, 
                        agent_id=agent_id, 
                        metadata={'workflow': workflow_id, 'type': 'long_running'}
                    )
                    
                    info['active_tasks'].add(task_id)
        
        print(f"✅ Started {sum(len(info['active_tasks']) for info in self.active_workflows.values())} long-running tasks")
    
    def simulate_ongoing_activity(self):
        """Simulate ongoing activity while keeping some tasks active"""
        self.running = True
        cycle = 0
        
        print("🔄 Starting ongoing activity simulation...")
        
        while self.running:
            cycle += 1
            
            for workflow_id, info in self.active_workflows.items():
                # Occasionally complete some tasks
                if info['active_tasks'] and random.random() < 0.1:  # 10% chance
                    completed_task = random.choice(list(info['active_tasks']))
                    info['active_tasks'].remove(completed_task)
                    
                    agent_id = f"{workflow_id}_agent_{random.randint(1, info['agents'])}"
                    self.collector.record_task_completed(
                        completed_task,
                        agent_id=agent_id,
                        execution_time=random.uniform(10.0, 180.0),
                        metadata={'workflow': workflow_id}
                    )
                
                # Start new tasks to replace completed ones
                if len(info['active_tasks']) < info['agents'] * 2 and random.random() < 0.15:
                    task_id = f"{workflow_id}_task_{self.task_counter}"
                    self.task_counter += 1
                    agent_id = f"{workflow_id}_agent_{random.randint(1, info['agents'])}"
                    
                    self.collector.record_task_started(
                        task_id,
                        agent_id=agent_id,
                        metadata={'workflow': workflow_id}
                    )
                    info['active_tasks'].add(task_id)
                
                # Generate token usage
                if random.random() < 0.3:  # 30% chance per workflow per cycle
                    agent_id = f"{workflow_id}_agent_{random.randint(1, info['agents'])}"
                    self.collector.record_token_usage(
                        agent_id=agent_id,
                        input_tokens=random.randint(1000, 8000),
                        output_tokens=random.randint(200, 2000),
                        metadata={'workflow': workflow_id, 'model': random.choice(['claude-3.5-sonnet', 'gpt-4', 'gpt-3.5-turbo'])}
                    )
                
                # Generate resource metrics
                if random.random() < 0.2:  # 20% chance
                    agent_id = f"{workflow_id}_agent_{random.randint(1, info['agents'])}"
                    
                    # Memory usage
                    memory_metric = Metric(
                        metric_type=MetricType.MEMORY_USAGE,
                        value=random.uniform(100, 800),
                        agent_id=agent_id,
                        metadata={'workflow': workflow_id}
                    )
                    self.collector.record_metric(memory_metric)
                    
                    # Queue depth
                    queue_metric = Metric(
                        metric_type=MetricType.QUEUE_DEPTH,
                        value=random.randint(0, 15),
                        agent_id=agent_id,
                        metadata={'workflow': workflow_id}
                    )
                    self.collector.record_metric(queue_metric)
                
                # Occasional failures
                if info['active_tasks'] and random.random() < 0.05:  # 5% chance
                    failed_task = random.choice(list(info['active_tasks']))
                    info['active_tasks'].remove(failed_task)
                    
                    agent_id = f"{workflow_id}_agent_{random.randint(1, info['agents'])}"
                    self.collector.record_task_failed(
                        failed_task,
                        agent_id=agent_id,
                        error=random.choice(['Timeout', 'API Rate Limit', 'Memory Error', 'Network Error']),
                        metadata={'workflow': workflow_id}
                    )
            
            # Print status every 10 cycles
            if cycle % 10 == 0:
                summary = self.collector.get_summary()
                active_tasks = sum(len(info['active_tasks']) for info in self.active_workflows.values())
                print(f"📊 Cycle {cycle}: {summary.total_tasks} total, {active_tasks} active, {summary.error_rate:.1%} error rate")
            
            time.sleep(2)  # 2 second intervals for realistic load
        
        print("🛑 Stopped activity simulation")
    
    def run_load_test(self, duration_seconds: int = 300):
        """Run the complete load test"""
        print(f"🚀 Starting realistic load test for {duration_seconds} seconds")
        
        # Start long-running tasks
        self.start_long_running_tasks()
        
        # Start activity simulation in background
        activity_thread = threading.Thread(target=self.simulate_ongoing_activity)
        activity_thread.daemon = True
        activity_thread.start()
        
        try:
            # Let it run for specified duration
            time.sleep(duration_seconds)
        except KeyboardInterrupt:
            print("\n🛑 Test interrupted by user")
        finally:
            self.running = False
            activity_thread.join(timeout=5)
        
        # Final summary
        summary = self.collector.get_summary()
        active_tasks = sum(len(info['active_tasks']) for info in self.active_workflows.values())
        
        print(f"\n📈 Final Results:")
        print(f"  Total tasks processed: {summary.total_tasks}")
        print(f"  Completed: {summary.completed_tasks}")
        print(f"  Failed: {summary.failed_tasks}")
        print(f"  Currently active: {active_tasks}")
        print(f"  Error rate: {summary.error_rate:.1%}")
        print(f"  Average execution time: {summary.average_execution_time:.1f}s")

def main():
    simulator = RealisticWorkloadSimulator()
    simulator.run_load_test(duration_seconds=60)  # 1 minute test

if __name__ == "__main__":
    main()