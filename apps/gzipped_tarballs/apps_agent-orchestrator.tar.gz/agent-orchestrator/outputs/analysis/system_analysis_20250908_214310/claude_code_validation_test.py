#!/usr/bin/env python3
"""Comprehensive validation test for Claude Code Clone."""

import asyncio
import os
import sys
import json
import time
from typing import Dict, Any, List
from dataclasses import dataclass, asdict
from pathlib import Path

# Add src to path
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-code-clone')
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-code-clone/src')

from claude_code import ClaudeCodeExecutor, ClaudeCodeConfig


@dataclass
class ValidationResult:
    """Validation test result."""
    category: str
    test_name: str
    passed: bool
    execution_time: float
    details: Dict[str, Any]
    error_message: str = ""
    
    def to_dict(self):
        return asdict(self)


class ClaudeCodeValidator:
    """Comprehensive validator for Claude Code Clone."""
    
    def __init__(self):
        self.results = []
        self.config = ClaudeCodeConfig(
            provider='openai',
            model='gpt-5-nano',
            api_key=os.getenv('OPENAI_API_KEY'),
            max_tokens=200,
            working_directory='.',
            enable_file_operations=True
        )
        self.executor = None
        
    async def setup(self):
        """Initialize executor."""
        self.executor = ClaudeCodeExecutor(self.config)
        
    async def teardown(self):
        """Cleanup executor."""
        if self.executor:
            await self.executor.close()
    
    async def test_basic_execution(self) -> ValidationResult:
        """Test basic prompt execution."""
        print("\n🔍 Testing basic execution...")
        start = time.time()
        
        try:
            result = await self.executor.execute_prompt(
                "What is the capital of France? Answer in one word."
            )
            
            passed = 'Paris' in str(result)
            
            return ValidationResult(
                category="Functionality",
                test_name="Basic Execution",
                passed=passed,
                execution_time=time.time() - start,
                details={
                    "response": str(result)[:100],
                    "response_type": type(result).__name__
                }
            )
        except Exception as e:
            return ValidationResult(
                category="Functionality",
                test_name="Basic Execution",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
    
    async def test_streaming_response(self) -> ValidationResult:
        """Test streaming response handling."""
        print("\n🔍 Testing streaming response...")
        start = time.time()
        
        try:
            chunks = []
            stream = await self.executor.execute_prompt(
                "Count from 1 to 5.",
                stream=True
            )
            
            async for chunk in stream:
                chunks.append(chunk)
            
            full_response = ''.join(chunks)
            passed = len(chunks) > 0 and len(full_response) > 0
            
            return ValidationResult(
                category="Functionality",
                test_name="Streaming Response",
                passed=passed,
                execution_time=time.time() - start,
                details={
                    "chunks_received": len(chunks),
                    "total_length": len(full_response),
                    "sample": full_response[:100]
                }
            )
        except Exception as e:
            return ValidationResult(
                category="Functionality",
                test_name="Streaming Response",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
    
    async def test_file_analysis(self) -> ValidationResult:
        """Test file analysis capability."""
        print("\n🔍 Testing file analysis...")
        start = time.time()
        
        # Create a test file
        test_file = Path("test_sample.py")
        test_code = """
def calculate_sum(a, b):
    return a + b

def main():
    result = calculate_sum(5, 3)
    print(f"Result: {result}")

if __name__ == "__main__":
    main()
"""
        
        try:
            test_file.write_text(test_code)
            
            analysis = await self.executor.analyze_file(
                str(test_file),
                analysis_type="general"
            )
            
            passed = len(analysis) > 0
            
            return ValidationResult(
                category="File Operations",
                test_name="File Analysis",
                passed=passed,
                execution_time=time.time() - start,
                details={
                    "file": str(test_file),
                    "analysis_length": len(analysis),
                    "sample": analysis[:200]
                }
            )
        except Exception as e:
            return ValidationResult(
                category="File Operations",
                test_name="File Analysis",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
        finally:
            if test_file.exists():
                test_file.unlink()
    
    async def test_code_generation(self) -> ValidationResult:
        """Test code generation capability."""
        print("\n🔍 Testing code generation...")
        start = time.time()
        
        test_file = Path("generated_code.py")
        
        try:
            code = await self.executor.generate_file(
                str(test_file),
                "Create a simple Python function to calculate factorial"
            )
            
            passed = test_file.exists() and 'def' in code
            
            return ValidationResult(
                category="File Operations",
                test_name="Code Generation",
                passed=passed,
                execution_time=time.time() - start,
                details={
                    "file": str(test_file),
                    "code_length": len(code),
                    "contains_function": 'def' in code,
                    "sample": code[:200]
                }
            )
        except Exception as e:
            return ValidationResult(
                category="File Operations",
                test_name="Code Generation",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
        finally:
            if test_file.exists():
                test_file.unlink()
    
    async def test_error_handling(self) -> ValidationResult:
        """Test error handling and recovery."""
        print("\n🔍 Testing error handling...")
        start = time.time()
        
        try:
            # Try to analyze non-existent file
            try:
                await self.executor.analyze_file("non_existent_file.py")
                error_handled = False
            except Exception as e:
                error_handled = "not found" in str(e).lower()
            
            return ValidationResult(
                category="Error Handling",
                test_name="Error Recovery",
                passed=error_handled,
                execution_time=time.time() - start,
                details={
                    "error_properly_caught": error_handled
                }
            )
        except Exception as e:
            return ValidationResult(
                category="Error Handling",
                test_name="Error Recovery",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
    
    async def test_openai_models(self) -> ValidationResult:
        """Test different OpenAI model access."""
        print("\n🔍 Testing OpenAI model access...")
        start = time.time()
        
        models_to_test = ["gpt-5-nano", "gpt-5-mini"]
        results = {}
        
        for model in models_to_test:
            try:
                # Update config for each model
                temp_config = ClaudeCodeConfig(
                    provider='openai',
                    model=model,
                    api_key=os.getenv('OPENAI_API_KEY'),
                    max_tokens=50
                )
                temp_executor = ClaudeCodeExecutor(temp_config)
                
                response = await temp_executor.execute_prompt("Say hello")
                results[model] = {
                    "success": True,
                    "response": str(response)[:50]
                }
                
                await temp_executor.close()
                
            except Exception as e:
                results[model] = {
                    "success": False,
                    "error": str(e)
                }
        
        passed = all(r["success"] for r in results.values())
        
        return ValidationResult(
            category="OpenAI Integration",
            test_name="Model Access",
            passed=passed,
            execution_time=time.time() - start,
            details=results
        )
    
    async def test_concurrent_execution(self) -> ValidationResult:
        """Test concurrent request handling."""
        print("\n🔍 Testing concurrent execution...")
        start = time.time()
        
        try:
            tasks = []
            for i in range(5):
                task = self.executor.execute_prompt(f"What is {i} + {i}?")
                tasks.append(task)
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            successful = sum(1 for r in results if not isinstance(r, Exception))
            
            return ValidationResult(
                category="Performance",
                test_name="Concurrent Execution",
                passed=successful == len(tasks),
                execution_time=time.time() - start,
                details={
                    "total_tasks": len(tasks),
                    "successful": successful,
                    "failed": len(tasks) - successful
                }
            )
        except Exception as e:
            return ValidationResult(
                category="Performance",
                test_name="Concurrent Execution",
                passed=False,
                execution_time=time.time() - start,
                details={},
                error_message=str(e)
            )
    
    async def run_all_tests(self) -> Dict[str, Any]:
        """Run all validation tests."""
        print("\n" + "="*60)
        print("🚀 CLAUDE CODE CLONE VALIDATION")
        print("="*60)
        
        await self.setup()
        
        # Run all tests
        tests = [
            self.test_basic_execution(),
            self.test_streaming_response(),
            self.test_file_analysis(),
            self.test_code_generation(),
            self.test_error_handling(),
            self.test_openai_models(),
            self.test_concurrent_execution()
        ]
        
        for test in tests:
            result = await test
            self.results.append(result)
            
            if result.passed:
                print(f"  ✅ {result.test_name}: PASSED ({result.execution_time:.2f}s)")
            else:
                print(f"  ❌ {result.test_name}: FAILED - {result.error_message}")
        
        await self.teardown()
        
        # Generate summary
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results if r.passed)
        
        # Category breakdown
        categories = {}
        for result in self.results:
            if result.category not in categories:
                categories[result.category] = {"total": 0, "passed": 0}
            categories[result.category]["total"] += 1
            if result.passed:
                categories[result.category]["passed"] += 1
        
        print("\n" + "="*60)
        print("📊 VALIDATION SUMMARY")
        print("="*60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {total_tests - passed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        print("\nCategory Breakdown:")
        for category, stats in categories.items():
            success_rate = (stats["passed"]/stats["total"])*100
            print(f"  {category}: {stats['passed']}/{stats['total']} ({success_rate:.0f}%)")
        
        # Production readiness assessment
        production_ready = passed_tests / total_tests >= 0.85  # 85% threshold
        
        return {
            "summary": {
                "total_tests": total_tests,
                "passed": passed_tests,
                "failed": total_tests - passed_tests,
                "success_rate": (passed_tests/total_tests)*100,
                "categories": categories
            },
            "results": [r.to_dict() for r in self.results],
            "production_ready": production_ready,
            "recommendation": self._generate_recommendation(production_ready, categories)
        }
    
    def _generate_recommendation(self, production_ready: bool, categories: Dict) -> Dict[str, Any]:
        """Generate detailed recommendation."""
        strengths = []
        weaknesses = []
        
        for category, stats in categories.items():
            success_rate = (stats["passed"]/stats["total"])*100
            if success_rate == 100:
                strengths.append(f"{category}: All tests passed")
            elif success_rate < 50:
                weaknesses.append(f"{category}: Only {success_rate:.0f}% passed")
        
        return {
            "go_no_go": "GO" if production_ready else "NO-GO",
            "production_ready": production_ready,
            "strengths": strengths,
            "weaknesses": weaknesses,
            "recommendations": [
                "Deploy to staging environment first" if production_ready else "Fix critical issues before deployment",
                "Monitor performance metrics closely",
                "Implement comprehensive logging",
                "Set up automated testing pipeline"
            ]
        }


async def main():
    """Main entry point."""
    validator = ClaudeCodeValidator()
    report = await validator.run_all_tests()
    
    # Save report
    report_file = Path("claude_code_validation_report.json")
    with open(report_file, "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📝 Full report saved to: {report_file}")
    
    # Final recommendation
    print("\n" + "="*60)
    print("🎯 FINAL RECOMMENDATION")
    print("="*60)
    
    rec = report["recommendation"]
    if rec["production_ready"]:
        print(f"✅ {rec['go_no_go']}: Claude Code Clone is PRODUCTION READY")
        print("\nStrengths:")
        for strength in rec["strengths"]:
            print(f"  • {strength}")
    else:
        print(f"❌ {rec['go_no_go']}: Claude Code Clone NEEDS IMPROVEMENTS")
        print("\nWeaknesses:")
        for weakness in rec["weaknesses"]:
            print(f"  • {weakness}")
    
    print("\nRecommendations:")
    for recommendation in rec["recommendations"]:
        print(f"  • {recommendation}")
    
    return report


if __name__ == "__main__":
    report = asyncio.run(main())
    sys.exit(0 if report["production_ready"] else 1)