#!/usr/bin/env python3
"""
Test script for Context Injection System
Demonstrates ecosystem discovery, context generation, and orchestrator integration
"""

import asyncio
import json
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from context_injection import (
    get_context_system,
    create_context_aware_orchestrator,
    OrchestratorContextInjector
)
from generic_orchestrator import GenericOrchestrator, AgentTask


def test_ecosystem_discovery():
    """Test ecosystem discovery capabilities"""
    print("\n=== Testing Ecosystem Discovery ===")
    
    context_system = get_context_system()
    
    # Scan ecosystem
    capabilities = context_system.discovery.scan_ecosystem()
    
    print(f"Discovered {len(capabilities)} capabilities:")
    for name, cap in list(capabilities.items())[:5]:  # Show first 5
        print(f"\n  {name}:")
        print(f"    Type: {cap.type}")
        print(f"    Path: {cap.path}")
        print(f"    Description: {cap.description[:50]}..." if len(cap.description) > 50 else f"    Description: {cap.description}")
        print(f"    Capabilities: {', '.join(cap.capabilities[:3])}")
        if cap.api_endpoints:
            print(f"    API Endpoints: {', '.join(cap.api_endpoints[:2])}")


def test_context_filtering():
    """Test context filtering for different agent types"""
    print("\n=== Testing Context Filtering ===")
    
    context_system = get_context_system()
    
    # Get all capabilities
    all_capabilities = context_system.discovery.scan_ecosystem()
    
    # Test different agent types
    test_cases = [
        ("documentation", "Generate comprehensive documentation for the orchestrator system"),
        ("development", "Implement a new API endpoint for health monitoring"),
        ("integration", "Integrate with existing MCP servers for enhanced capabilities"),
        ("analysis", "Analyze system performance and identify bottlenecks")
    ]
    
    for agent_type, task_desc in test_cases:
        print(f"\n  Agent Type: {agent_type}")
        print(f"  Task: {task_desc[:50]}...")
        
        relevant_tools = context_system.filter.filter_for_agent(
            agent_type,
            task_desc,
            all_capabilities,
            max_tools=3
        )
        
        print(f"  Relevant Tools ({len(relevant_tools)}):")
        for tool in relevant_tools:
            print(f"    - {tool.name} ({tool.type})")


def test_context_generation():
    """Test dynamic context generation"""
    print("\n=== Testing Context Generation ===")
    
    context_system = get_context_system()
    
    # Generate context for a documentation agent
    context = context_system.generator.generate_context(
        agent_type="documentation",
        task_description="Create user guide for the agent orchestrator system",
        additional_context={"project": "agent-orchestrator", "format": "markdown"}
    )
    
    print("Generated Context:")
    print(f"  Core Identity: {context.core_identity[:100]}...")
    print(f"  Available Tools: {len(context.available_tools)}")
    print(f"  Integration Opportunities: {len(context.integration_opportunities)}")
    print(f"  Performance Targets: {context.performance_targets}")
    print(f"  Best Practices: {context.best_practices[:2]}")
    
    # Test prompt enhancement
    enhanced = context.to_prompt_enhancement()
    print(f"\nPrompt Enhancement Preview ({len(enhanced)} chars):")
    print(enhanced[:500] + "..." if len(enhanced) > 500 else enhanced)


def test_orchestrator_integration():
    """Test integration with orchestrator"""
    print("\n=== Testing Orchestrator Integration ===")
    
    # Create a sample task
    task = AgentTask(
        task_id="test_001",
        task_type="documentation",
        prompt="Generate API documentation for the context injection system",
        context={
            "description": "Document all public APIs and usage examples",
            "format": "markdown",
            "target_audience": "developers"
        }
    )
    
    # Create context injector
    injector = OrchestratorContextInjector()
    
    # Enhance task
    enhanced_task = injector.enhance_agent_task(task)
    
    print(f"Original prompt length: {len(task.prompt)}")
    print(f"Enhanced prompt length: {len(enhanced_task.prompt)}")
    print(f"Context injected: {enhanced_task.context.get('context_injected')}")
    print(f"Agent type: {enhanced_task.context.get('agent_type')}")
    
    # Show enhancement preview
    print("\nEnhanced Prompt Preview:")
    print(enhanced_task.prompt[:500] + "...")


def test_context_file_generation():
    """Test context file generation"""
    print("\n=== Testing Context File Generation ===")
    
    context_system = get_context_system()
    
    # Generate context file
    context_json = context_system.get_context_file(
        agent_type="development",
        task_description="Build a real-time monitoring dashboard"
    )
    
    # Parse and display
    context_data = json.loads(context_json)
    
    print("Context File Structure:")
    print(f"  Generated at: {context_data['generated_at']}")
    print(f"  Agent type: {context_data['agent_type']}")
    print(f"  Available tools: {len(context_data['available_tools'])}")
    print(f"  Integration opportunities: {len(context_data['integration_opportunities'])}")
    print(f"  Performance targets: {context_data['performance_targets']}")
    
    # Show sample tool
    if context_data['available_tools']:
        tool = context_data['available_tools'][0]
        print(f"\n  Sample Tool:")
        print(f"    Name: {tool['name']}")
        print(f"    Type: {tool['type']}")
        print(f"    Capabilities: {tool['capabilities']}")


async def test_context_aware_orchestrator():
    """Test context-aware orchestrator wrapper"""
    print("\n=== Testing Context-Aware Orchestrator ===")
    
    # Create tasks
    tasks = [
        AgentTask(
            task_id="doc_001",
            task_type="documentation",
            prompt="Document the context injection system architecture"
        ),
        AgentTask(
            task_id="dev_001",
            task_type="development",
            prompt="Implement caching for context generation"
        )
    ]
    
    # Create context-aware orchestrator
    from pathlib import Path
    orchestrator = create_context_aware_orchestrator(
        GenericOrchestrator,
        Path("/tmp/test_context_injection"),
        max_parallel=2
    )
    
    print("Created context-aware orchestrator")
    print(f"  Output dir: {orchestrator.output_dir}")
    print(f"  Max agents: {orchestrator.max_parallel}")
    
    # Note: Actual execution would require valid API tokens
    print("\nTasks prepared with context injection:")
    for task in tasks:
        print(f"  - {task.task_id}: {task.task_type}")


def main():
    """Run all tests"""
    print("=" * 60)
    print("Context Injection System Test Suite")
    print("=" * 60)
    
    try:
        # Run synchronous tests
        test_ecosystem_discovery()
        test_context_filtering()
        test_context_generation()
        test_orchestrator_integration()
        test_context_file_generation()
        
        # Run async test
        asyncio.run(test_context_aware_orchestrator())
        
        print("\n" + "=" * 60)
        print("All tests completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nError during testing: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())