#!/usr/bin/env python3
"""
DPO Performance Benchmarking and Validation

Comprehensive performance testing including load testing, stress testing,
scalability validation, and performance regression detection.
"""

import asyncio
import json
import time
import statistics
import concurrent.futures
import pytest
import psutil
import logging
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass, asdict
from unittest.mock import Mock, AsyncMock, patch

import sys
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.dpo_main_controller import DevelopmentProcessOrchestrator, DPOConfiguration
from tests.fixtures.sample_data import SampleRequestGenerator
from tests.fixtures.mock_orchestrator import MockOrchestratorServer

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetrics:
    """Performance metrics for analysis"""
    operation: str
    duration: float
    memory_usage_mb: float
    cpu_percent: float
    success: bool
    error_message: str = ""
    timestamp: float = 0.0
    request_size: int = 0
    response_size: int = 0


@dataclass
class PerformanceBenchmark:
    """Performance benchmark results"""
    test_name: str
    total_requests: int
    successful_requests: int
    failed_requests: int
    avg_response_time: float
    min_response_time: float
    max_response_time: float
    p95_response_time: float
    p99_response_time: float
    throughput_rps: float
    avg_memory_usage: float
    max_memory_usage: float
    avg_cpu_usage: float
    max_cpu_usage: float
    error_rate: float
    start_time: float
    end_time: float


class DPOPerformanceTester:
    """DPO performance testing framework"""
    
    def __init__(self, config: DPOConfiguration):
        self.config = config
        self.sample_generator = SampleRequestGenerator()
        self.metrics: List[PerformanceMetrics] = []
        
    async def setup(self):
        """Setup performance testing environment"""
        self.dpo = DevelopmentProcessOrchestrator(self.config)
        await self.dpo.initialize()
        
        # Setup monitoring
        self.initial_memory = psutil.Process().memory_info().rss / 1024 / 1024
        self.initial_cpu = psutil.cpu_percent()
    
    async def cleanup(self):
        """Cleanup after performance tests"""
        # Clean up any resources
        if hasattr(self, 'dpo'):
            # Could add cleanup methods to DPO if needed
            pass
    
    async def measure_operation(self, operation_name: str, operation_func, *args, **kwargs) -> PerformanceMetrics:
        """Measure performance of a single operation"""
        process = psutil.Process()
        
        # Pre-operation measurements
        start_memory = process.memory_info().rss / 1024 / 1024
        start_cpu = psutil.cpu_percent(interval=None)
        start_time = time.time()
        
        try:
            # Execute operation
            result = await operation_func(*args, **kwargs)
            success = True
            error_message = ""
            
        except Exception as e:
            result = None
            success = False
            error_message = str(e)
            logger.error(f"Operation {operation_name} failed: {e}")
        
        # Post-operation measurements
        end_time = time.time()
        end_memory = process.memory_info().rss / 1024 / 1024
        end_cpu = psutil.cpu_percent(interval=None)
        
        metrics = PerformanceMetrics(
            operation=operation_name,
            duration=end_time - start_time,
            memory_usage_mb=end_memory,
            cpu_percent=end_cpu,
            success=success,
            error_message=error_message,
            timestamp=start_time,
            request_size=len(str(args)) + len(str(kwargs)) if args or kwargs else 0,
            response_size=len(str(result)) if result else 0
        )
        
        self.metrics.append(metrics)
        return metrics
    
    async def load_test(self, concurrent_users: int, requests_per_user: int, test_duration: int = 60) -> PerformanceBenchmark:
        """Execute load testing with multiple concurrent users"""
        logger.info(f"Starting load test: {concurrent_users} users, {requests_per_user} requests/user")
        
        start_time = time.time()
        end_time = start_time + test_duration
        
        async def user_simulation(user_id: int):
            """Simulate a single user's requests"""
            user_metrics = []
            requests_made = 0
            
            while time.time() < end_time and requests_made < requests_per_user:
                request_data = self.sample_generator.get_random_request()
                
                operation_name = f"load_test_user_{user_id}_request_{requests_made}"
                metrics = await self.measure_operation(
                    operation_name,
                    self.dpo.process_request,
                    request_data.request,
                    request_data.context
                )
                
                user_metrics.append(metrics)
                requests_made += 1
                
                # Brief delay between requests
                await asyncio.sleep(0.1)
            
            return user_metrics
        
        # Create concurrent user tasks
        tasks = []
        for user_id in range(concurrent_users):
            task = asyncio.create_task(user_simulation(user_id))
            tasks.append(task)
        
        # Wait for all users to complete
        all_user_metrics = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Flatten metrics from all users
        load_test_metrics = []
        for user_metrics in all_user_metrics:
            if isinstance(user_metrics, list):
                load_test_metrics.extend(user_metrics)
            else:
                logger.error(f"User simulation failed: {user_metrics}")
        
        actual_end_time = time.time()
        return self._calculate_benchmark(
            "load_test",
            load_test_metrics,
            start_time,
            actual_end_time
        )
    
    async def stress_test(self, max_concurrent: int, step_size: int = 5, step_duration: int = 30) -> List[PerformanceBenchmark]:
        """Execute stress testing with gradually increasing load"""
        logger.info(f"Starting stress test: up to {max_concurrent} concurrent users")
        
        stress_results = []
        
        for concurrent_users in range(step_size, max_concurrent + 1, step_size):
            logger.info(f"Stress test step: {concurrent_users} concurrent users")
            
            benchmark = await self.load_test(
                concurrent_users=concurrent_users,
                requests_per_user=5,  # Fewer requests per user for stress test
                test_duration=step_duration
            )
            
            benchmark.test_name = f"stress_test_{concurrent_users}_users"
            stress_results.append(benchmark)
            
            # Check if system is becoming unstable
            if benchmark.error_rate > 0.5 or benchmark.avg_response_time > 30:
                logger.warning(f"System unstable at {concurrent_users} users, stopping stress test")
                break
            
            # Brief recovery period between steps
            await asyncio.sleep(5)
        
        return stress_results
    
    async def scalability_test(self, request_sizes: List[int]) -> List[PerformanceBenchmark]:
        """Test scalability with different request complexities"""
        logger.info("Starting scalability test with varying request complexities")
        
        scalability_results = []
        
        complexity_levels = ["simple", "medium", "complex"]
        
        for i, complexity in enumerate(complexity_levels):
            logger.info(f"Testing {complexity} complexity requests")
            
            # Generate requests of specific complexity
            if complexity == "simple":
                requests = [self.sample_generator.get_api_request("simple") for _ in range(10)]
            elif complexity == "medium":
                requests = [self.sample_generator.get_webapp_request("simple") for _ in range(10)]
            else:  # complex
                requests = [self.sample_generator.get_integration_request("enterprise") for _ in range(5)]
            
            start_time = time.time()
            complexity_metrics = []
            
            for j, request_data in enumerate(requests):
                operation_name = f"scalability_{complexity}_{j}"
                metrics = await self.measure_operation(
                    operation_name,
                    self.dpo.process_request,
                    request_data.request,
                    request_data.context
                )
                complexity_metrics.append(metrics)
            
            end_time = time.time()
            
            benchmark = self._calculate_benchmark(
                f"scalability_{complexity}",
                complexity_metrics,
                start_time,
                end_time
            )
            
            scalability_results.append(benchmark)
        
        return scalability_results
    
    async def memory_leak_test(self, iterations: int = 100) -> List[PerformanceMetrics]:
        """Test for memory leaks over multiple iterations"""
        logger.info(f"Starting memory leak test with {iterations} iterations")
        
        memory_metrics = []
        baseline_memory = psutil.Process().memory_info().rss / 1024 / 1024
        
        for i in range(iterations):
            request_data = self.sample_generator.get_api_request("medium")
            
            metrics = await self.measure_operation(
                f"memory_test_{i}",
                self.dpo.process_request,
                request_data.request,
                request_data.context
            )
            
            memory_metrics.append(metrics)
            
            # Log memory usage every 10 iterations
            if i % 10 == 0:
                current_memory = metrics.memory_usage_mb
                memory_increase = current_memory - baseline_memory
                logger.info(f"Iteration {i}: Memory usage {current_memory:.2f}MB (+{memory_increase:.2f}MB)")
        
        return memory_metrics
    
    async def endurance_test(self, duration_minutes: int = 30) -> PerformanceBenchmark:
        """Execute long-running endurance test"""
        logger.info(f"Starting endurance test for {duration_minutes} minutes")
        
        start_time = time.time()
        end_time = start_time + (duration_minutes * 60)
        
        endurance_metrics = []
        iteration = 0
        
        while time.time() < end_time:
            request_data = self.sample_generator.get_random_request()
            
            metrics = await self.measure_operation(
                f"endurance_{iteration}",
                self.dpo.process_request,
                request_data.request,
                request_data.context
            )
            
            endurance_metrics.append(metrics)
            iteration += 1
            
            # Brief delay between requests
            await asyncio.sleep(1)
            
            # Log progress every 5 minutes
            if iteration % 300 == 0:
                logger.info(f"Endurance test progress: {iteration} requests completed")
        
        actual_end_time = time.time()
        return self._calculate_benchmark(
            "endurance_test",
            endurance_metrics,
            start_time,
            actual_end_time
        )
    
    def _calculate_benchmark(self, test_name: str, metrics: List[PerformanceMetrics], start_time: float, end_time: float) -> PerformanceBenchmark:
        """Calculate benchmark results from metrics"""
        if not metrics:
            return PerformanceBenchmark(
                test_name=test_name,
                total_requests=0,
                successful_requests=0,
                failed_requests=0,
                avg_response_time=0.0,
                min_response_time=0.0,
                max_response_time=0.0,
                p95_response_time=0.0,
                p99_response_time=0.0,
                throughput_rps=0.0,
                avg_memory_usage=0.0,
                max_memory_usage=0.0,
                avg_cpu_usage=0.0,
                max_cpu_usage=0.0,
                error_rate=1.0,
                start_time=start_time,
                end_time=end_time
            )
        
        successful_metrics = [m for m in metrics if m.success]
        failed_metrics = [m for m in metrics if not m.success]
        
        durations = [m.duration for m in successful_metrics]
        memory_usage = [m.memory_usage_mb for m in metrics]
        cpu_usage = [m.cpu_percent for m in metrics]
        
        # Calculate percentiles
        if durations:
            durations.sort()
            p95_idx = int(len(durations) * 0.95)
            p99_idx = int(len(durations) * 0.99)
            p95_response_time = durations[p95_idx] if p95_idx < len(durations) else durations[-1]
            p99_response_time = durations[p99_idx] if p99_idx < len(durations) else durations[-1]
        else:
            p95_response_time = p99_response_time = 0.0
        
        total_duration = end_time - start_time
        throughput = len(successful_metrics) / total_duration if total_duration > 0 else 0.0
        
        return PerformanceBenchmark(
            test_name=test_name,
            total_requests=len(metrics),
            successful_requests=len(successful_metrics),
            failed_requests=len(failed_metrics),
            avg_response_time=statistics.mean(durations) if durations else 0.0,
            min_response_time=min(durations) if durations else 0.0,
            max_response_time=max(durations) if durations else 0.0,
            p95_response_time=p95_response_time,
            p99_response_time=p99_response_time,
            throughput_rps=throughput,
            avg_memory_usage=statistics.mean(memory_usage) if memory_usage else 0.0,
            max_memory_usage=max(memory_usage) if memory_usage else 0.0,
            avg_cpu_usage=statistics.mean(cpu_usage) if cpu_usage else 0.0,
            max_cpu_usage=max(cpu_usage) if cpu_usage else 0.0,
            error_rate=len(failed_metrics) / len(metrics),
            start_time=start_time,
            end_time=end_time
        )


class TestDPOPerformanceBenchmarks:
    """DPO performance benchmark tests"""
    
    @pytest.fixture
    def performance_config(self):
        """Configuration optimized for performance testing"""
        return DPOConfiguration(
            output_base_dir="performance_test_output",
            max_parallel_agents=10,
            enable_websocket=False,  # Disable for cleaner testing
            enable_dashboard=False,
            enable_intelligence=True,
            enable_context_injection=True
        )
    
    @pytest.fixture
    async def performance_tester(self, performance_config):
        """Setup performance tester"""
        
        # Mock the orchestrator to avoid external dependencies
        with patch('src.dpo_main_controller.GenericOrchestrator') as mock_orch_class:
            mock_orch = AsyncMock()
            mock_orch.create_and_run_task.return_value = {
                "status": "completed",
                "outputs": {"enhancements": []}
            }
            mock_orch_class.return_value = mock_orch
            
            with patch('src.dpo_main_controller.SDLCTemplateSystem') as mock_template_class:
                mock_template = Mock()
                mock_template.generate_workflow.return_value = {
                    "workflow_id": "perf_test",
                    "phases": [{"phase_id": "test", "agents": []}]
                }
                mock_template_class.return_value = mock_template
                
                with patch('src.dpo_main_controller.get_context_system') as mock_context:
                    mock_context.return_value.prepare_contexts.return_value = {"agent_contexts": {}}
                    
                    with patch('src.dpo_main_controller.DPOOrchestrator') as mock_dpo_orch:
                        mock_dpo_orch.return_value.submit_workflow.return_value = {
                            "workflow_id": "submitted",
                            "status": "submitted"
                        }
                        
                        tester = DPOPerformanceTester(performance_config)
                        await tester.setup()
                        yield tester
                        await tester.cleanup()
    
    @pytest.mark.asyncio
    async def test_single_request_performance(self, performance_tester):
        """Test performance of single request processing"""
        
        request_data = performance_tester.sample_generator.get_api_request("simple")
        
        metrics = await performance_tester.measure_operation(
            "single_request_test",
            performance_tester.dpo.process_request,
            request_data.request,
            request_data.context
        )
        
        # Performance assertions
        assert metrics.success, f"Request failed: {metrics.error_message}"
        assert metrics.duration < 30, f"Request took {metrics.duration:.2f}s, exceeds 30s limit"
        assert metrics.memory_usage_mb < 1000, f"Memory usage {metrics.memory_usage_mb}MB too high"
        
        logger.info(f"Single request performance: {metrics.duration:.2f}s, {metrics.memory_usage_mb:.2f}MB")
    
    @pytest.mark.asyncio
    async def test_load_performance(self, performance_tester):
        """Test load handling performance"""
        
        benchmark = await performance_tester.load_test(
            concurrent_users=5,
            requests_per_user=3,
            test_duration=30
        )
        
        # Performance assertions
        assert benchmark.error_rate < 0.1, f"Error rate {benchmark.error_rate:.2%} too high"
        assert benchmark.avg_response_time < 25, f"Average response time {benchmark.avg_response_time:.2f}s too high"
        assert benchmark.throughput_rps > 0.1, f"Throughput {benchmark.throughput_rps:.2f} RPS too low"
        
        logger.info(f"Load test results: {benchmark.successful_requests}/{benchmark.total_requests} successful, "
                   f"{benchmark.avg_response_time:.2f}s avg, {benchmark.throughput_rps:.2f} RPS")
    
    @pytest.mark.asyncio
    async def test_stress_performance(self, performance_tester):
        """Test system behavior under stress"""
        
        stress_results = await performance_tester.stress_test(
            max_concurrent=10,
            step_size=2,
            step_duration=15
        )
        
        assert len(stress_results) > 0, "No stress test results"
        
        # Find breaking point
        breaking_point = None
        for result in stress_results:
            if result.error_rate > 0.2 or result.avg_response_time > 30:
                breaking_point = result
                break
        
        if breaking_point:
            logger.warning(f"System breaking point at {breaking_point.test_name}: "
                          f"{breaking_point.error_rate:.2%} error rate, "
                          f"{breaking_point.avg_response_time:.2f}s avg response time")
        else:
            logger.info("System remained stable throughout stress test")
        
        # Last result should still be reasonable
        last_result = stress_results[-1]
        assert last_result.error_rate < 0.5, "System completely failed under stress"
    
    @pytest.mark.asyncio
    async def test_scalability_performance(self, performance_tester):
        """Test performance scalability with different complexities"""
        
        scalability_results = await performance_tester.scalability_test([10, 50, 100])
        
        assert len(scalability_results) == 3, "Expected 3 scalability test results"
        
        # Verify performance degrades gracefully with complexity
        simple_result = scalability_results[0]
        medium_result = scalability_results[1]
        complex_result = scalability_results[2]
        
        # Simple requests should be fastest
        assert simple_result.avg_response_time < 20, "Simple requests too slow"
        
        # Complex requests can take longer but should still be reasonable
        assert complex_result.avg_response_time < 45, "Complex requests too slow"
        
        # Performance should degrade somewhat gracefully
        assert complex_result.avg_response_time > simple_result.avg_response_time, \
            "Complex requests should take longer than simple ones"
        
        logger.info(f"Scalability results: Simple={simple_result.avg_response_time:.2f}s, "
                   f"Medium={medium_result.avg_response_time:.2f}s, "
                   f"Complex={complex_result.avg_response_time:.2f}s")
    
    @pytest.mark.asyncio
    async def test_memory_stability(self, performance_tester):
        """Test memory usage stability over time"""
        
        memory_metrics = await performance_tester.memory_leak_test(iterations=20)  # Reduced for testing
        
        assert len(memory_metrics) == 20, "Expected 20 memory test iterations"
        
        # Check for memory leaks
        initial_memory = memory_metrics[0].memory_usage_mb
        final_memory = memory_metrics[-1].memory_usage_mb
        memory_growth = final_memory - initial_memory
        
        # Allow for some memory growth but not excessive
        assert memory_growth < 200, f"Memory grew by {memory_growth:.2f}MB, possible leak"
        
        # Check memory usage patterns
        memory_values = [m.memory_usage_mb for m in memory_metrics]
        max_memory = max(memory_values)
        avg_memory = statistics.mean(memory_values)
        
        assert max_memory < 2000, f"Peak memory usage {max_memory:.2f}MB too high"
        
        logger.info(f"Memory stability: Initial={initial_memory:.2f}MB, "
                   f"Final={final_memory:.2f}MB, Growth={memory_growth:.2f}MB, "
                   f"Peak={max_memory:.2f}MB")
    
    @pytest.mark.asyncio
    async def test_performance_regression(self, performance_tester):
        """Test for performance regression detection"""
        
        # Baseline performance test
        baseline_request = performance_tester.sample_generator.get_api_request("medium")
        baseline_metrics = await performance_tester.measure_operation(
            "baseline_test",
            performance_tester.dpo.process_request,
            baseline_request.request,
            baseline_request.context
        )
        
        # Multiple measurements for statistical significance
        test_metrics = []
        for i in range(5):
            test_request = performance_tester.sample_generator.get_api_request("medium")
            metrics = await performance_tester.measure_operation(
                f"regression_test_{i}",
                performance_tester.dpo.process_request,
                test_request.request,
                test_request.context
            )
            test_metrics.append(metrics)
        
        # Calculate average performance
        successful_metrics = [m for m in test_metrics if m.success]
        assert len(successful_metrics) >= 4, "Too many failed requests for regression testing"
        
        avg_response_time = statistics.mean([m.duration for m in successful_metrics])
        
        # Check for significant regression (>50% slower)
        regression_threshold = baseline_metrics.duration * 1.5
        assert avg_response_time < regression_threshold, \
            f"Performance regression detected: {avg_response_time:.2f}s vs baseline {baseline_metrics.duration:.2f}s"
        
        logger.info(f"Performance regression test: Baseline={baseline_metrics.duration:.2f}s, "
                   f"Average={avg_response_time:.2f}s, Threshold={regression_threshold:.2f}s")


class TestDPOPerformanceValidation:
    """Validate DPO performance against requirements"""
    
    @pytest.mark.asyncio
    async def test_sla_compliance(self, performance_tester):
        """Test SLA compliance for key performance metrics"""
        
        # SLA Requirements
        sla_requirements = {
            "request_processing_time": 30.0,  # seconds
            "throughput_minimum": 0.2,        # requests per second
            "error_rate_maximum": 0.05,       # 5%
            "memory_usage_maximum": 1500,     # MB
            "availability": 0.99               # 99%
        }
        
        # Run comprehensive test
        benchmark = await performance_tester.load_test(
            concurrent_users=3,
            requests_per_user=5,
            test_duration=30
        )
        
        # Validate SLA compliance
        assert benchmark.avg_response_time <= sla_requirements["request_processing_time"], \
            f"SLA violation: Response time {benchmark.avg_response_time:.2f}s > {sla_requirements['request_processing_time']}s"
        
        assert benchmark.throughput_rps >= sla_requirements["throughput_minimum"], \
            f"SLA violation: Throughput {benchmark.throughput_rps:.2f} RPS < {sla_requirements['throughput_minimum']} RPS"
        
        assert benchmark.error_rate <= sla_requirements["error_rate_maximum"], \
            f"SLA violation: Error rate {benchmark.error_rate:.2%} > {sla_requirements['error_rate_maximum']:.2%}"
        
        assert benchmark.max_memory_usage <= sla_requirements["memory_usage_maximum"], \
            f"SLA violation: Memory usage {benchmark.max_memory_usage:.2f}MB > {sla_requirements['memory_usage_maximum']}MB"
        
        availability = benchmark.successful_requests / benchmark.total_requests
        assert availability >= sla_requirements["availability"], \
            f"SLA violation: Availability {availability:.2%} < {sla_requirements['availability']:.2%}"
        
        logger.info(f"SLA compliance validated: All requirements met")


if __name__ == "__main__":
    pytest.main([__file__])