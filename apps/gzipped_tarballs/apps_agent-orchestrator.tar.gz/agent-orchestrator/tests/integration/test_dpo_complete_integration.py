#!/usr/bin/env python3
"""
Integration Tests for Complete DPO System

Tests the integration between all DPO components and their
data flow, communication patterns, and end-to-end functionality.
"""

import asyncio
import json
import pytest
import tempfile
import yaml
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch
from dataclasses import asdict
import time

import sys
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.dpo_main_controller import (
    DevelopmentProcessOrchestrator,
    DPOConfiguration,
    RequestType,
    RequestAnalysis
)
from src.dpo_intelligence_integration import DPORequest
from src.intelligence_review_engine_enhanced import EnhancementIntelligenceEngine
from src.sdlc_template_system import SDLCTemplateSystem
from src.context_injection import ContextInjectionSystem
from src.dpo_orchestrator_integration import DPOOrchestrator


class TestDPOComponentIntegration:
    """Test integration between DPO components"""
    
    @pytest.fixture
    def integration_config(self):
        """Create configuration for integration testing"""
        return DPOConfiguration(
            output_base_dir="integration_test_output",
            max_parallel_agents=3,
            enable_websocket=False,
            enable_intelligence=True,
            enable_context_injection=True,
            enable_dashboard=False
        )
    
    @pytest.fixture
    def sample_requests(self):
        """Sample development requests for testing"""
        return {
            "simple_api": {
                "request": "Build a simple REST API for user authentication",
                "context": {"framework": "FastAPI", "database": "SQLite"}
            },
            "complex_webapp": {
                "request": "Create a full-stack web application for project management with real-time updates",
                "context": {"frontend": "React", "backend": "Node.js", "database": "PostgreSQL", "realtime": "WebSocket"}
            },
            "cli_tool": {
                "request": "Develop a command-line tool for file processing and analysis",
                "context": {"language": "Python", "features": ["batch_processing", "reporting"]}
            },
            "integration_service": {
                "request": "Build a data integration service connecting multiple APIs",
                "context": {"apis": ["REST", "GraphQL"], "format": "JSON", "scale": "enterprise"}
            }
        }
    
    @pytest.mark.asyncio
    async def test_request_analysis_to_intelligence_flow(self, integration_config, sample_requests):
        """Test data flow from request analysis to intelligence enhancement"""
        
        # Mock orchestrator to avoid actual execution
        mock_orchestrator = AsyncMock()
        mock_orchestrator.create_and_run_task.return_value = {
            "status": "completed",
            "outputs": {
                "enhancements": [
                    {
                        "category": "PERFORMANCE",
                        "title": "Database indexing",
                        "description": "Add proper indexes",
                        "impact": "high",
                        "effort": "low"
                    }
                ]
            }
        }
        
        with patch('src.dpo_main_controller.GenericOrchestrator', return_value=mock_orchestrator):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            request_data = sample_requests["simple_api"]
            
            # Test request analysis
            analysis = await dpo._analyze_request(
                request_data["request"], 
                request_data["context"]
            )
            
            assert isinstance(analysis, RequestAnalysis)
            assert analysis.request_type == RequestType.BUILD
            assert "authentication" in " ".join(analysis.key_requirements).lower()
            
            # Test intelligence enhancement with analysis
            dpo_request = DPORequest(
                original_request=request_data["request"],
                context=request_data["context"],
                request_analysis=analysis
            )
            
            enhanced = await dpo._enhance_with_intelligence(dpo_request)
            
            assert 'enhancements' in enhanced
            assert 'analysis' in enhanced
            assert enhanced['analysis'] == analysis
    
    @pytest.mark.asyncio
    async def test_intelligence_to_template_flow(self, integration_config):
        """Test data flow from intelligence enhancement to template generation"""
        
        # Mock components
        mock_orchestrator = AsyncMock()
        mock_orchestrator.create_and_run_task.return_value = {
            "status": "completed",
            "outputs": {"enhancements": []}
        }
        
        mock_template_system = Mock()
        mock_workflow = {
            "workflow_id": "test_workflow",
            "phases": [
                {
                    "phase_id": "discovery",
                    "phase_name": "Requirements Discovery",
                    "agents": [{"role": "analyst", "task": "gather requirements"}]
                },
                {
                    "phase_id": "implementation", 
                    "phase_name": "Implementation",
                    "agents": [{"role": "developer", "task": "build API"}]
                }
            ],
            "metadata": {"total_agents": 2}
        }
        mock_template_system.generate_workflow.return_value = mock_workflow
        
        with patch('src.dpo_main_controller.GenericOrchestrator', return_value=mock_orchestrator):
            with patch('src.dpo_main_controller.SDLCTemplateSystem', return_value=mock_template_system):
                dpo = DevelopmentProcessOrchestrator(integration_config)
                await dpo.initialize()
                
                # Create enhanced request data
                enhanced_request = {
                    "original_request": "Build an API",
                    "analysis": RequestAnalysis(
                        request_type=RequestType.BUILD,
                        project_type="api",
                        complexity="medium",
                        key_requirements=["REST", "authentication"],
                        suggested_technologies=["FastAPI"],
                        risk_factors=["security"],
                        estimated_effort="1 week",
                        confidence_score=0.8
                    ),
                    "enhancements": [
                        {
                            "category": "SECURITY",
                            "title": "OAuth integration",
                            "priority": "high"
                        }
                    ]
                }
                
                workflow = await dpo._generate_workflow(enhanced_request)
                
                # Verify template system received enhanced data
                mock_template_system.generate_workflow.assert_called_once()
                call_args = mock_template_system.generate_workflow.call_args[0][0]
                
                assert 'analysis' in call_args
                assert 'enhancements' in call_args
                assert call_args['analysis'].request_type == RequestType.BUILD
                assert len(call_args['enhancements']) == 1
    
    @pytest.mark.asyncio
    async def test_template_to_context_injection_flow(self, integration_config):
        """Test data flow from template generation to context injection"""
        
        # Mock components
        mock_context_system = AsyncMock()
        mock_injected_context = {
            "agent_contexts": {
                "analyst": {
                    "domain_knowledge": ["API design patterns"],
                    "best_practices": ["REST conventions"]
                },
                "developer": {
                    "code_examples": ["FastAPI authentication"],
                    "libraries": ["fastapi", "sqlalchemy"]
                }
            },
            "global_context": {
                "project_type": "api",
                "technology_stack": ["FastAPI", "SQLite"]
            }
        }
        mock_context_system.prepare_contexts.return_value = mock_injected_context
        
        with patch('src.dpo_main_controller.get_context_system', return_value=mock_context_system):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            # Create workflow data
            workflow = {
                "workflow_id": "test_workflow",
                "phases": [
                    {
                        "phase_id": "discovery",
                        "agents": [
                            {"role": "analyst", "task": "requirements analysis"},
                            {"role": "architect", "task": "system design"}
                        ]
                    },
                    {
                        "phase_id": "implementation",
                        "agents": [
                            {"role": "developer", "task": "API implementation"}
                        ]
                    }
                ]
            }
            
            request_context = {"framework": "FastAPI", "database": "SQLite"}
            
            enriched_workflow = await dpo._inject_context(workflow, request_context)
            
            # Verify context injection received workflow and context
            mock_context_system.prepare_contexts.assert_called_once()
            call_args = mock_context_system.prepare_contexts.call_args
            
            # Verify workflow structure was passed
            assert 'phases' in call_args[0][0]  # workflow parameter
            assert 'framework' in call_args[0][1]  # context parameter
    
    @pytest.mark.asyncio
    async def test_context_injection_to_orchestrator_flow(self, integration_config):
        """Test data flow from context injection to orchestrator submission"""
        
        # Mock orchestrator integration
        mock_orchestrator_integration = AsyncMock()
        mock_submission_result = {
            "workflow_id": "submitted_workflow_123",
            "status": "submitted",
            "output_dir": "/test/output/submitted_workflow_123",
            "submission_time": time.time()
        }
        mock_orchestrator_integration.submit_workflow.return_value = mock_submission_result
        
        with patch('src.dpo_main_controller.DPOOrchestrator', return_value=mock_orchestrator_integration):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            # Create enriched workflow
            enriched_workflow = {
                "workflow_id": "test_enriched",
                "phases": [
                    {
                        "phase_id": "implementation",
                        "agents": [
                            {
                                "role": "developer",
                                "task": "build API",
                                "context": {
                                    "code_examples": ["FastAPI examples"],
                                    "best_practices": ["REST patterns"]
                                }
                            }
                        ]
                    }
                ],
                "global_context": {
                    "project_type": "api",
                    "technology_stack": ["FastAPI"]
                }
            }
            
            result = await dpo._submit_to_orchestrator(enriched_workflow)
            
            # Verify orchestrator received enriched workflow
            mock_orchestrator_integration.submit_workflow.assert_called_once_with(enriched_workflow)
            
            # Verify result format
            assert result["workflow_id"] == "submitted_workflow_123"
            assert result["status"] == "submitted"
            assert "output_dir" in result
    
    @pytest.mark.asyncio
    async def test_complete_integration_pipeline(self, integration_config, sample_requests):
        """Test complete integration pipeline from request to orchestrator submission"""
        
        # Setup all mocks for complete pipeline
        mock_orchestrator = AsyncMock()
        mock_orchestrator.create_and_run_task.return_value = {
            "status": "completed",
            "outputs": {
                "enhancements": [
                    {
                        "category": "PERFORMANCE",
                        "title": "Add caching",
                        "impact": "medium"
                    }
                ]
            }
        }
        
        mock_template_system = Mock()
        mock_template_system.generate_workflow.return_value = {
            "workflow_id": "pipeline_test",
            "phases": [{"phase_id": "test", "agents": []}],
            "metadata": {}
        }
        
        mock_context_system = AsyncMock()
        mock_context_system.prepare_contexts.return_value = {
            "agent_contexts": {},
            "global_context": {}
        }
        
        mock_orchestrator_integration = AsyncMock()
        mock_orchestrator_integration.submit_workflow.return_value = {
            "workflow_id": "final_submission",
            "status": "submitted",
            "output_dir": "/output/final_submission"
        }
        
        with patch.multiple(
            'src.dpo_main_controller',
            GenericOrchestrator=Mock(return_value=mock_orchestrator),
            SDLCTemplateSystem=Mock(return_value=mock_template_system),
            get_context_system=Mock(return_value=mock_context_system),
            DPOOrchestrator=Mock(return_value=mock_orchestrator_integration)
        ):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            # Process complete request
            request_data = sample_requests["simple_api"]
            result = await dpo.process_request(
                request_data["request"], 
                request_data["context"]
            )
            
            # Verify all components were called in sequence
            mock_orchestrator.create_and_run_task.assert_called()  # Intelligence enhancement
            mock_template_system.generate_workflow.assert_called_once()  # Template generation
            mock_context_system.prepare_contexts.assert_called_once()  # Context injection
            mock_orchestrator_integration.submit_workflow.assert_called_once()  # Final submission
            
            # Verify final result
            assert result.workflow_id == "final_submission"
            assert result.status == "submitted"
            assert result.output_dir == "/output/final_submission"
    
    @pytest.mark.asyncio
    async def test_error_propagation_between_components(self, integration_config):
        """Test error handling and propagation between components"""
        
        # Test intelligence engine failure
        mock_failed_orchestrator = AsyncMock()
        mock_failed_orchestrator.create_and_run_task.side_effect = Exception("Intelligence engine failed")
        
        with patch('src.dpo_main_controller.GenericOrchestrator', return_value=mock_failed_orchestrator):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            with pytest.raises(Exception) as exc_info:
                await dpo.process_request("Build an API", {})
            
            assert "Intelligence engine failed" in str(exc_info.value)
        
        # Test template system failure
        mock_orchestrator = AsyncMock()
        mock_orchestrator.create_and_run_task.return_value = {"status": "completed", "outputs": {"enhancements": []}}
        
        mock_failed_template = Mock()
        mock_failed_template.generate_workflow.side_effect = Exception("Template generation failed")
        
        with patch.multiple(
            'src.dpo_main_controller',
            GenericOrchestrator=Mock(return_value=mock_orchestrator),
            SDLCTemplateSystem=Mock(return_value=mock_failed_template)
        ):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            with pytest.raises(Exception) as exc_info:
                await dpo.process_request("Build an API", {})
            
            assert "Template generation failed" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_data_consistency_across_components(self, integration_config):
        """Test data consistency and integrity across component boundaries"""
        
        # Setup mocks that track data flow
        captured_data = {}
        
        def capture_intelligence_input(*args, **kwargs):
            captured_data['intelligence_input'] = args[0] if args else kwargs
            return {"status": "completed", "outputs": {"enhancements": []}}
        
        def capture_template_input(*args, **kwargs):
            captured_data['template_input'] = args[0] if args else kwargs
            return {"workflow_id": "test", "phases": []}
        
        def capture_context_input(*args, **kwargs):
            captured_data['context_input'] = args
            return {"agent_contexts": {}}
        
        def capture_orchestrator_input(*args, **kwargs):
            captured_data['orchestrator_input'] = args[0] if args else kwargs
            return {"workflow_id": "final", "status": "submitted"}
        
        mock_orchestrator = AsyncMock()
        mock_orchestrator.create_and_run_task.side_effect = capture_intelligence_input
        
        mock_template = Mock()
        mock_template.generate_workflow.side_effect = capture_template_input
        
        mock_context = AsyncMock()
        mock_context.prepare_contexts.side_effect = capture_context_input
        
        mock_integration = AsyncMock()
        mock_integration.submit_workflow.side_effect = capture_orchestrator_input
        
        with patch.multiple(
            'src.dpo_main_controller',
            GenericOrchestrator=Mock(return_value=mock_orchestrator),
            SDLCTemplateSystem=Mock(return_value=mock_template),
            get_context_system=Mock(return_value=mock_context),
            DPOOrchestrator=Mock(return_value=mock_integration)
        ):
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            await dpo.process_request("Build a user management API", {"framework": "FastAPI"})
            
            # Verify data consistency
            assert 'intelligence_input' in captured_data
            assert 'template_input' in captured_data
            assert 'context_input' in captured_data
            assert 'orchestrator_input' in captured_data
            
            # Verify original request is preserved
            intelligence_request = captured_data['intelligence_input']
            assert intelligence_request.original_request == "Build a user management API"
            assert intelligence_request.context["framework"] == "FastAPI"
            
            # Verify analysis is passed to template generation
            template_input = captured_data['template_input']
            assert 'analysis' in template_input
            assert template_input['original_request'] == "Build a user management API"
    
    @pytest.mark.asyncio
    async def test_configuration_propagation(self, integration_config):
        """Test configuration propagation to all components"""
        
        # Mock components that should receive configuration
        mock_orchestrator = AsyncMock()
        mock_template = Mock()
        mock_context = AsyncMock()
        mock_integration = AsyncMock()
        
        with patch.multiple(
            'src.dpo_main_controller',
            GenericOrchestrator=Mock(return_value=mock_orchestrator),
            SDLCTemplateSystem=Mock(return_value=mock_template),
            get_context_system=Mock(return_value=mock_context),
            DPOOrchestrator=Mock(return_value=mock_integration)
        ) as mocks:
            dpo = DevelopmentProcessOrchestrator(integration_config)
            await dpo.initialize()
            
            # Verify components received appropriate configuration
            # Template system should get template-related config
            template_constructor = mocks['SDLCTemplateSystem']
            template_call_args = template_constructor.call_args
            if template_call_args and template_call_args[1]:  # kwargs exist
                config_dict = template_call_args[1]
                if 'template_library_path' in integration_config.__dict__:
                    assert 'template_library_path' in str(config_dict)
            
            # Context system should get context-related config
            context_constructor = mocks['get_context_system']
            context_constructor.assert_called_once()


class TestDPOExternalIntegration:
    """Test DPO integration with external systems"""
    
    @pytest.mark.asyncio
    async def test_orchestrator_api_integration(self):
        """Test integration with actual orchestrator API (mocked)"""
        
        # Mock external orchestrator API responses
        mock_responses = {
            "/submit": {"workflow_id": "ext_123", "status": "submitted"},
            "/status/ext_123": {"status": "running", "progress": 0.4},
            "/results/ext_123": {"status": "completed", "artifacts": []},
            "/cancel/ext_123": {"status": "cancelled"}
        }
        
        config = DPOConfiguration(enable_websocket=False)
        
        with patch('src.dpo_orchestrator_integration.DPOOrchestrator') as mock_orch_class:
            mock_orch = AsyncMock()
            mock_orch.submit_workflow.return_value = mock_responses["/submit"]
            mock_orch.get_status.return_value = mock_responses["/status/ext_123"]
            mock_orch.get_results.return_value = mock_responses["/results/ext_123"]
            mock_orch.cancel_workflow.return_value = mock_responses["/cancel/ext_123"]
            mock_orch_class.return_value = mock_orch
            
            dpo = DevelopmentProcessOrchestrator(config)
            await dpo.initialize()
            
            # Test workflow submission
            workflow = {"workflow_id": "test", "phases": []}
            submit_result = await dpo._submit_to_orchestrator(workflow)
            assert submit_result["workflow_id"] == "ext_123"
            
            # Test status monitoring
            status = await dpo.get_workflow_status("ext_123")
            assert status["status"] == "running"
            assert status["progress"] == 0.4
            
            # Test results retrieval
            results = await dpo.get_workflow_results("ext_123")
            assert results["status"] == "completed"
            
            # Test workflow cancellation
            cancel_result = await dpo.cancel_workflow("ext_123")
            assert cancel_result["status"] == "cancelled"
    
    @pytest.mark.asyncio
    async def test_websocket_integration(self):
        """Test WebSocket integration for real-time updates"""
        
        config = DPOConfiguration(enable_websocket=True, websocket_port=8766)
        
        # Mock WebSocket server functionality
        with patch('src.dpo_main_controller.start_websocket_server') as mock_ws:
            mock_ws.return_value = AsyncMock()
            
            dpo = DevelopmentProcessOrchestrator(config)
            await dpo.initialize()
            
            # Verify WebSocket server was started with correct config
            mock_ws.assert_called_once()
            call_args = mock_ws.call_args
            assert config.websocket_port in str(call_args)
    
    def test_file_system_integration(self, integration_config):
        """Test file system operations and output management"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            integration_config.output_base_dir = temp_dir
            
            dpo = DevelopmentProcessOrchestrator(integration_config)
            
            # Test output directory creation
            output_path = Path(dpo._get_output_path("test_workflow"))
            
            # The path should be constructed correctly
            assert str(temp_dir) in str(output_path)
            assert "test_workflow" in str(output_path)


if __name__ == "__main__":
    pytest.main([__file__])