"""
Integration tests for DPO component communication and data flow.
"""

import unittest
import asyncio
import json
import tempfile
import os
from unittest.mock import Mock, patch, AsyncMock
from typing import Dict, Any, List
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tests.base_test import AsyncDPOTestBase, TestDataGenerator, TestValidator


class TestComponentIntegration(AsyncDPOTestBase):
    """Test integration between DPO components."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.test_data = TestDataGenerator()
        self.validator = TestValidator()
        self.components = self._create_integrated_components()
        
    def _create_integrated_components(self):
        """Create integrated mock components."""
        class IntegratedDPOSystem:
            def __init__(self):
                self.request_analyzer = self._create_request_analyzer()
                self.intelligence_engine = self._create_intelligence_engine()
                self.template_system = self._create_template_system()
                self.orchestrator_integration = self._create_orchestrator_integration()
                self.context_injection = self._create_context_injection()
                
            async def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
                """Process request through complete pipeline."""
                # Step 1: Analyze and classify request
                classification = await self.request_analyzer.classify(request)
                
                # Step 2: Generate enhancements
                enhancements = await self.intelligence_engine.enhance(request, classification)
                
                # Step 3: Generate workflow
                workflow = await self.template_system.generate(
                    classification,
                    request.get("requirements", []),
                    enhancements
                )
                
                # Step 4: Inject context
                enriched_workflow = await self.context_injection.inject(workflow, request)
                
                # Step 5: Submit to orchestrator
                result = await self.orchestrator_integration.submit(enriched_workflow)
                
                return {
                    "classification": classification,
                    "enhancements": enhancements,
                    "workflow": enriched_workflow,
                    "orchestrator_result": result
                }
                
            def _create_request_analyzer(self):
                """Create request analyzer component."""
                class RequestAnalyzer:
                    async def classify(self, request):
                        description = request.get("description", "").lower()
                        
                        if "api" in description or "rest" in description:
                            req_type = "api_development"
                        elif "fullstack" in description or "web app" in description:
                            req_type = "fullstack_application"
                        elif "cli" in description or "command" in description:
                            req_type = "cli_development"
                        elif "integration" in description or "connector" in description:
                            req_type = "integration_connector"
                        else:
                            req_type = "unknown"
                            
                        return {
                            "type": req_type,
                            "confidence": 0.85 if req_type != "unknown" else 0.2,
                            "complexity": "medium"
                        }
                        
                return RequestAnalyzer()
                
            def _create_intelligence_engine(self):
                """Create intelligence engine component."""
                class IntelligenceEngine:
                    async def enhance(self, request, classification):
                        enhancements = []
                        
                        if classification["type"] != "unknown":
                            enhancements.append({
                                "type": "performance",
                                "suggestion": "Add caching layer",
                                "priority": "high"
                            })
                            
                        if "user" in request.get("description", "").lower():
                            enhancements.append({
                                "type": "security",
                                "suggestion": "Implement authentication",
                                "priority": "critical"
                            })
                            
                        return enhancements
                        
                return IntelligenceEngine()
                
            def _create_template_system(self):
                """Create template system component."""
                class TemplateSystem:
                    async def generate(self, classification, requirements, enhancements):
                        agents = []
                        
                        # Add agents based on classification
                        if classification["type"] == "api_development":
                            agents.extend([
                                {"id": "architect", "type": "architect"},
                                {"id": "developer", "type": "api_developer"},
                                {"id": "tester", "type": "tester"}
                            ])
                        elif classification["type"] == "fullstack_application":
                            agents.extend([
                                {"id": "architect", "type": "architect"},
                                {"id": "frontend", "type": "frontend_dev"},
                                {"id": "backend", "type": "backend_dev"},
                                {"id": "tester", "type": "tester"}
                            ])
                        else:
                            agents.append({"id": "general", "type": "developer"})
                            
                        return {
                            "task_type": classification["type"],
                            "agents": agents,
                            "config": {
                                "parallel_execution": len(requirements) > 3,
                                "quality_gates_enabled": True
                            },
                            "enhancements_applied": len(enhancements)
                        }
                        
                return TemplateSystem()
                
            def _create_orchestrator_integration(self):
                """Create orchestrator integration component."""
                class OrchestratorIntegration:
                    async def submit(self, workflow):
                        return {
                            "workflow_id": f"wf_{workflow['task_type']}_123",
                            "status": "submitted",
                            "agents_count": len(workflow.get("agents", [])),
                            "estimated_time": 30
                        }
                        
                return OrchestratorIntegration()
                
            def _create_context_injection(self):
                """Create context injection component."""
                class ContextInjection:
                    async def inject(self, workflow, request):
                        workflow["context"] = {
                            "project_name": request.get("project_name", "default"),
                            "technology_stack": request.get("technology_stack", []),
                            "injected_at": "2024-09-09T00:00:00Z"
                        }
                        return workflow
                        
                return ContextInjection()
                
        return IntegratedDPOSystem()
        
    def test_end_to_end_api_request_processing(self):
        """Test complete processing of API development request."""
        request = self.test_data.generate_request(
            request_type="api_development",
            description="Create a REST API for user management",
            requirements=["CRUD operations", "Authentication", "Validation"],
            technology_stack=["Python", "FastAPI"]
        )
        
        result = self.run_async(self.components.process_request(request))
        
        # Verify classification
        self.assertEqual(result["classification"]["type"], "api_development")
        self.assertGreater(result["classification"]["confidence"], 0.7)
        
        # Verify enhancements were generated
        self.assertGreater(len(result["enhancements"]), 0)
        
        # Verify workflow was generated
        self.assertIn("agents", result["workflow"])
        self.assertGreater(len(result["workflow"]["agents"]), 0)
        
        # Verify context was injected
        self.assertIn("context", result["workflow"])
        self.assertIn("technology_stack", result["workflow"]["context"])
        
        # Verify orchestrator submission
        self.assertEqual(result["orchestrator_result"]["status"], "submitted")
        self.assertIn("workflow_id", result["orchestrator_result"])
        
    def test_end_to_end_fullstack_request_processing(self):
        """Test complete processing of full-stack application request."""
        request = self.test_data.generate_request(
            request_type="fullstack_application",
            description="Build a fullstack web app with user authentication",
            requirements=[f"Feature {i}" for i in range(5)],
            technology_stack=["React", "Node.js", "PostgreSQL"]
        )
        
        result = self.run_async(self.components.process_request(request))
        
        # Should classify as fullstack
        self.assertEqual(result["classification"]["type"], "fullstack_application")
        
        # Should have security enhancement due to "user" keyword
        security_enhancements = [
            e for e in result["enhancements"]
            if e["type"] == "security"
        ]
        self.assertGreater(len(security_enhancements), 0)
        
        # Should have frontend and backend agents
        agent_types = [agent["type"] for agent in result["workflow"]["agents"]]
        self.assertIn("frontend_dev", agent_types)
        self.assertIn("backend_dev", agent_types)
        
        # Should enable parallel execution for 5+ requirements
        self.assertTrue(result["workflow"]["config"]["parallel_execution"])
        
    def test_component_data_flow(self):
        """Test data flow between components."""
        request = self.test_data.generate_request()
        
        # Track data transformation through pipeline
        result = self.run_async(self.components.process_request(request))
        
        # Classification should influence workflow
        classification_type = result["classification"]["type"]
        workflow_type = result["workflow"]["task_type"]
        self.assertEqual(classification_type, workflow_type)
        
        # Enhancements should be reflected in workflow
        enhancement_count = len(result["enhancements"])
        self.assertEqual(
            result["workflow"]["enhancements_applied"],
            enhancement_count
        )
        
        # Context should contain request data
        self.assertEqual(
            result["workflow"]["context"]["technology_stack"],
            request.get("technology_stack", [])
        )
        
    def test_error_handling_in_pipeline(self):
        """Test error handling in component pipeline."""
        # Malformed request
        malformed_request = {
            "description": None,
            "requirements": "not a list"
        }
        
        # Should handle gracefully
        result = self.run_async(self.components.process_request(malformed_request))
        
        # Should classify as unknown
        self.assertEqual(result["classification"]["type"], "unknown")
        self.assertLess(result["classification"]["confidence"], 0.5)
        
        # Should still generate some workflow
        self.assertIn("agents", result["workflow"])
        self.assertGreater(len(result["workflow"]["agents"]), 0)
        
    def test_enhancement_integration(self):
        """Test enhancement integration in workflow generation."""
        request = self.test_data.generate_request(
            description="Create API with user data processing"
        )
        
        result = self.run_async(self.components.process_request(request))
        
        # Should have both performance and security enhancements
        enhancement_types = [e["type"] for e in result["enhancements"]]
        self.assertIn("performance", enhancement_types)
        self.assertIn("security", enhancement_types)
        
        # Enhancements should be counted in workflow
        self.assertEqual(
            result["workflow"]["enhancements_applied"],
            len(result["enhancements"])
        )
        
    def test_parallel_processing_decision(self):
        """Test parallel processing decision based on requirements."""
        # Few requirements - no parallel
        small_request = self.test_data.generate_request(
            requirements=["Feature1", "Feature2"]
        )
        
        small_result = self.run_async(self.components.process_request(small_request))
        self.assertFalse(small_result["workflow"]["config"]["parallel_execution"])
        
        # Many requirements - enable parallel
        large_request = self.test_data.generate_request(
            requirements=[f"Feature{i}" for i in range(10)]
        )
        
        large_result = self.run_async(self.components.process_request(large_request))
        self.assertTrue(large_result["workflow"]["config"]["parallel_execution"])
        
    def test_context_injection_completeness(self):
        """Test that context injection includes all necessary data."""
        request = {
            "description": "Build an API",
            "project_name": "TestProject",
            "technology_stack": ["Python", "FastAPI", "PostgreSQL"],
            "requirements": ["Auth", "CRUD"]
        }
        
        result = self.run_async(self.components.process_request(request))
        
        context = result["workflow"]["context"]
        
        # Should include project name
        self.assertEqual(context["project_name"], "TestProject")
        
        # Should include technology stack
        self.assertEqual(context["technology_stack"], request["technology_stack"])
        
        # Should include timestamp
        self.assertIn("injected_at", context)
        
    def test_orchestrator_submission_details(self):
        """Test orchestrator submission details."""
        request = self.test_data.generate_request(
            request_type="api_development"
        )
        
        result = self.run_async(self.components.process_request(request))
        
        orchestrator_result = result["orchestrator_result"]
        
        # Should have workflow ID with type
        self.assertIn("api_development", orchestrator_result["workflow_id"])
        
        # Should count agents correctly
        self.assertEqual(
            orchestrator_result["agents_count"],
            len(result["workflow"]["agents"])
        )
        
        # Should provide time estimate
        self.assertGreater(orchestrator_result["estimated_time"], 0)
        
    def test_unknown_request_handling(self):
        """Test handling of unknown request types."""
        request = {
            "description": "Do something vague",
            "requirements": []
        }
        
        result = self.run_async(self.components.process_request(request))
        
        # Should classify as unknown
        self.assertEqual(result["classification"]["type"], "unknown")
        
        # Should still generate minimal workflow
        self.assertIn("agents", result["workflow"])
        
        # Should have at least one general agent
        agent_types = [agent["type"] for agent in result["workflow"]["agents"]]
        self.assertIn("developer", agent_types)
        
    def test_classification_affects_agent_selection(self):
        """Test that classification directly affects agent selection."""
        test_cases = [
            ("Create REST API", "api_development", ["architect", "api_developer", "tester"]),
            ("Build web app", "fullstack_application", ["architect", "frontend_dev", "backend_dev", "tester"]),
            ("Make something", "unknown", ["developer"])
        ]
        
        for description, expected_type, expected_agents in test_cases:
            request = {"description": description, "requirements": ["Req1"]}
            result = self.run_async(self.components.process_request(request))
            
            self.assertEqual(result["classification"]["type"], expected_type)
            
            agent_types = [agent["type"] for agent in result["workflow"]["agents"]]
            for expected_agent in expected_agents:
                self.assertIn(
                    expected_agent, agent_types,
                    f"Expected {expected_agent} for {expected_type}"
                )


class TestComponentCommunication(AsyncDPOTestBase):
    """Test inter-component communication patterns."""
    
    def test_async_component_communication(self):
        """Test asynchronous communication between components."""
        async def component_a():
            await asyncio.sleep(0.1)
            return {"data": "from_a"}
            
        async def component_b(data_from_a):
            await asyncio.sleep(0.1)
            return {"data": data_from_a["data"] + "_processed_by_b"}
            
        async def pipeline():
            result_a = await component_a()
            result_b = await component_b(result_a)
            return result_b
            
        result = self.run_async(pipeline())
        
        self.assertEqual(result["data"], "from_a_processed_by_b")
        
    def test_parallel_component_execution(self):
        """Test parallel execution of independent components."""
        async def slow_component(name, delay):
            await asyncio.sleep(delay)
            return {"component": name, "delay": delay}
            
        async def parallel_pipeline():
            tasks = [
                slow_component("A", 0.1),
                slow_component("B", 0.1),
                slow_component("C", 0.1)
            ]
            
            results = await asyncio.gather(*tasks)
            return results
            
        import time
        start = time.time()
        results = self.run_async(parallel_pipeline())
        duration = time.time() - start
        
        # Should complete in ~0.1s (parallel) not ~0.3s (sequential)
        self.assertLess(duration, 0.2)
        
        # Should have all results
        self.assertEqual(len(results), 3)
        component_names = [r["component"] for r in results]
        self.assertEqual(set(component_names), {"A", "B", "C"})
        
    def test_component_retry_mechanism(self):
        """Test component retry on failure."""
        class RetryableComponent:
            def __init__(self):
                self.attempts = 0
                
            async def process(self):
                self.attempts += 1
                if self.attempts < 3:
                    raise Exception("Temporary failure")
                return {"status": "success", "attempts": self.attempts}
                
        async def retry_pipeline():
            component = RetryableComponent()
            max_retries = 3
            
            for attempt in range(max_retries):
                try:
                    return await component.process()
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    await asyncio.sleep(0.05)
                    
        result = self.run_async(retry_pipeline())
        
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["attempts"], 3)
        
    def test_component_timeout_handling(self):
        """Test component timeout handling."""
        async def slow_component():
            await asyncio.sleep(5)  # Very slow
            return {"status": "completed"}
            
        async def timeout_pipeline():
            try:
                result = await asyncio.wait_for(slow_component(), timeout=0.1)
                return result
            except asyncio.TimeoutError:
                return {"status": "timeout"}
                
        result = self.run_async(timeout_pipeline())
        
        self.assertEqual(result["status"], "timeout")


if __name__ == "__main__":
    unittest.main()