#!/usr/bin/env python3
"""
Test script for DPO Orchestrator Integration Layer

Validates the complete workflow from DPO request submission
through orchestrator execution to results harvesting.
"""

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import the integration layer
from src.dpo_orchestrator_integration import DPOOrchestrator


async def test_basic_workflow():
    """Test basic workflow submission and monitoring"""
    print("\n" + "="*80)
    print("TEST: Basic Workflow Submission")
    print("="*80)
    
    # Initialize orchestrator
    orchestrator = DPOOrchestrator(
        output_base_dir="output/dpo_integration_test",
        max_parallel_agents=3,
        enable_websocket=False  # Disable for testing
    )
    
    # Submit a simple workflow
    workflow_id = await orchestrator.submit_development_request(
        request="Create a simple REST API for managing user profiles with CRUD operations",
        project_type="api",
        complexity="simple",
        context={
            "framework": "FastAPI",
            "database": "SQLite",
            "features": ["user_crud", "validation", "error_handling"]
        }
    )
    
    print(f"✓ Workflow submitted: {workflow_id}")
    
    # Monitor progress
    print("\nMonitoring workflow progress...")
    max_checks = 30
    check_interval = 2
    
    for i in range(max_checks):
        await asyncio.sleep(check_interval)
        
        status = await orchestrator.get_workflow_status(workflow_id)
        
        print(f"\nCheck {i+1}/{max_checks}:")
        print(f"  Status: {status['status']}")
        
        if status.get('progress'):
            progress = status['progress']
            print(f"  Progress: {progress['completed_tasks']}/{progress['total_tasks']} tasks")
            print(f"  Percentage: {progress['progress_percentage']:.1f}%")
            
            if progress.get('running_tasks'):
                print(f"  Running: {', '.join(progress['running_tasks'][:3])}")
        
        # Check if completed
        if status['status'] in ['completed', 'failed', 'cancelled']:
            print(f"\n✓ Workflow finished with status: {status['status']}")
            break
    
    # Get results
    results = await orchestrator.get_workflow_results(workflow_id)
    
    if results:
        print("\n" + "-"*80)
        print("WORKFLOW RESULTS")
        print("-"*80)
        print(f"Status: {results.status.value}")
        print(f"Duration: {results.duration_seconds:.2f} seconds")
        print(f"Total tasks: {results.metrics['total_tasks']}")
        print(f"Completed tasks: {results.metrics['completed_tasks']}")
        print(f"Failed tasks: {results.metrics['failed_tasks']}")
        print(f"Success rate: {results.metrics['success_rate']:.1%}")
        print(f"Deliverables: {results.metrics['deliverables_count']}")
        print(f"Knowledge extracted: {results.metrics['knowledge_extracted']}")
        
        if results.errors:
            print(f"\nErrors ({len(results.errors)}):")
            for error in results.errors[:3]:
                print(f"  - {error}")
    
    await orchestrator.shutdown()
    return workflow_id


async def test_complex_workflow():
    """Test complex workflow with multiple phases"""
    print("\n" + "="*80)
    print("TEST: Complex Multi-Phase Workflow")
    print("="*80)
    
    orchestrator = DPOOrchestrator(
        output_base_dir="output/dpo_complex_test",
        max_parallel_agents=5,
        enable_websocket=False
    )
    
    # Submit complex workflow
    workflow_id = await orchestrator.submit_development_request(
        request="""Build a comprehensive e-commerce platform with:
        - Product catalog management
        - Shopping cart functionality
        - User authentication and profiles
        - Payment processing integration
        - Order management system
        - Admin dashboard
        - Real-time inventory tracking
        - Email notifications
        """,
        project_type="web_app",
        complexity="complex",
        context={
            "frontend": "React",
            "backend": "Node.js",
            "database": "PostgreSQL",
            "payment": "Stripe",
            "deployment": "AWS",
            "expected_users": "10000",
            "performance_requirements": "high"
        }
    )
    
    print(f"✓ Complex workflow submitted: {workflow_id}")
    
    # Quick status check
    await asyncio.sleep(5)
    status = await orchestrator.get_workflow_status(workflow_id)
    
    print(f"\nInitial Status: {status['status']}")
    if status.get('metadata'):
        print(f"Total phases: {status['metadata'].get('total_phases', 'N/A')}")
        print(f"Total tasks: {status['metadata'].get('total_tasks', 'N/A')}")
        print(f"Estimated duration: {status['metadata'].get('estimated_duration', 'N/A')}")
    
    await orchestrator.shutdown()
    return workflow_id


async def test_workflow_cancellation():
    """Test workflow cancellation"""
    print("\n" + "="*80)
    print("TEST: Workflow Cancellation")
    print("="*80)
    
    orchestrator = DPOOrchestrator(
        output_base_dir="output/dpo_cancel_test",
        max_parallel_agents=2,
        enable_websocket=False
    )
    
    # Submit workflow
    workflow_id = await orchestrator.submit_development_request(
        request="Build a CLI tool for file management",
        project_type="cli",
        complexity="simple"
    )
    
    print(f"✓ Workflow submitted: {workflow_id}")
    
    # Wait a bit then cancel
    await asyncio.sleep(3)
    
    print("\nAttempting to cancel workflow...")
    success = await orchestrator.cancel_workflow(workflow_id)
    
    if success:
        print("✓ Workflow cancelled successfully")
    else:
        print("✗ Failed to cancel workflow")
    
    # Check final status
    status = await orchestrator.get_workflow_status(workflow_id)
    print(f"Final status: {status['status']}")
    
    await orchestrator.shutdown()
    return success


async def test_api_integration():
    """Test REST API integration if FastAPI is available"""
    print("\n" + "="*80)
    print("TEST: REST API Integration")
    print("="*80)
    
    try:
        from src.dpo_orchestrator_integration import api
        
        if api:
            print("✓ FastAPI endpoints available")
            print("\nAvailable endpoints:")
            for route in api.routes:
                if hasattr(route, 'path') and hasattr(route, 'methods'):
                    print(f"  {', '.join(route.methods)}: {route.path}")
        else:
            print("✗ FastAPI not available - API endpoints disabled")
    except ImportError:
        print("✗ FastAPI module not installed")


async def run_all_tests():
    """Run all integration tests"""
    print("\n" + "="*80)
    print("DPO ORCHESTRATOR INTEGRATION LAYER TEST SUITE")
    print("="*80)
    print(f"Started: {datetime.now().isoformat()}")
    
    test_results = {}
    
    # Test 1: Basic workflow
    try:
        workflow_id = await test_basic_workflow()
        test_results['basic_workflow'] = 'PASSED'
    except Exception as e:
        test_results['basic_workflow'] = f'FAILED: {str(e)}'
        logger.error(f"Basic workflow test failed: {e}")
    
    # Test 2: Complex workflow
    try:
        workflow_id = await test_complex_workflow()
        test_results['complex_workflow'] = 'PASSED'
    except Exception as e:
        test_results['complex_workflow'] = f'FAILED: {str(e)}'
        logger.error(f"Complex workflow test failed: {e}")
    
    # Test 3: Workflow cancellation
    try:
        success = await test_workflow_cancellation()
        test_results['workflow_cancellation'] = 'PASSED' if success else 'PARTIAL'
    except Exception as e:
        test_results['workflow_cancellation'] = f'FAILED: {str(e)}'
        logger.error(f"Cancellation test failed: {e}")
    
    # Test 4: API integration
    try:
        await test_api_integration()
        test_results['api_integration'] = 'PASSED'
    except Exception as e:
        test_results['api_integration'] = f'FAILED: {str(e)}'
        logger.error(f"API integration test failed: {e}")
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    for test_name, result in test_results.items():
        status_symbol = "✓" if "PASSED" in result else "✗"
        print(f"{status_symbol} {test_name}: {result}")
    
    passed = sum(1 for r in test_results.values() if "PASSED" in r)
    total = len(test_results)
    
    print(f"\nTotal: {passed}/{total} tests passed")
    print(f"Completed: {datetime.now().isoformat()}")
    
    # Save test results
    results_file = Path("output/dpo_integration_test_results.json")
    results_file.parent.mkdir(exist_ok=True)
    with open(results_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'results': test_results,
            'summary': {
                'passed': passed,
                'total': total,
                'success_rate': passed / total if total > 0 else 0
            }
        }, f, indent=2)
    
    print(f"\nTest results saved to: {results_file}")


if __name__ == "__main__":
    # Run all tests
    asyncio.run(run_all_tests())