#!/usr/bin/env python3
"""
Test Script for SessionAnalyticsEngine - Claude Sessions
Tests specifically with Claude project session files (.jsonl)
"""

import sys
import logging
from pathlib import Path

# Add src directory to path
sys.path.append(str(Path(__file__).parent / "src"))

from session_analytics_engine import SessionAnalyticsEngine

def test_claude_sessions():
    """Test with actual Claude project session files"""
    print("Testing Claude Session Analytics")
    print("=" * 40)
    
    # Initialize engine with Claude project directory
    claude_project_root = "/home/opsvi/.claude/projects"
    engine = SessionAnalyticsEngine(claude_project_root)
    
    # Find actual Claude session files
    session_files = engine.session_parser.find_session_files(claude_project_root)
    
    if not session_files:
        print(f"No Claude session files found in {claude_project_root}")
        return
        
    print(f"Found {len(session_files)} Claude session files")
    
    # Test with first few session files
    test_files = session_files[:3]  # Test with first 3 files
    
    for i, session_file in enumerate(test_files, 1):
        print(f"\nTesting Session {i}: {session_file.name}")
        print("-" * 30)
        
        try:
            # Parse session data
            session_data = engine.session_parser.parse_session_file(session_file)
            if not session_data:
                print("  Failed to parse session data")
                continue
                
            print(f"  Session ID: {session_data['session_id']}")
            print(f"  Project Path: {session_data['project_path']}")
            print(f"  Total Records: {len(session_data['records'])}")
            
            # Test analytics components individually
            metrics, patterns, tools, files = engine.analyze_single_session(session_file)
            
            if metrics:
                print(f"  Duration: {metrics.duration_minutes:.2f} minutes")
                print(f"  Messages: {metrics.total_messages} total")
                print(f"    - User: {metrics.user_messages}")
                print(f"    - Assistant: {metrics.assistant_messages}")
                print(f"  Tool Calls: {metrics.total_tool_calls}")
                print(f"  Files Touched: {metrics.unique_files_touched}")
                if metrics.working_directory:
                    print(f"  Working Directory: {metrics.working_directory}")
                if metrics.git_branch:
                    print(f"  Git Branch: {metrics.git_branch}")
            
            if patterns:
                print(f"  Conversation Patterns:")
                for pattern in patterns:
                    print(f"    - {pattern.pattern_type}: {pattern.frequency} turns")
                    
            if tools:
                print(f"  Tool Usage:")
                for tool in tools[:3]:  # Show first 3
                    print(f"    - {tool.tool_name}: {tool.usage_count} calls, {tool.success_rate:.1%} success")
                    
            if files:
                print(f"  File Operations:")
                for file_op in files[:3]:  # Show first 3
                    print(f"    - {Path(file_op.file_path).name}: {file_op.total_operations} operations")
                    
        except Exception as e:
            print(f"  Error: {e}")


def test_comprehensive_claude_analysis():
    """Test comprehensive analysis of Claude sessions"""
    print("\n\nTesting Comprehensive Claude Analysis")
    print("=" * 40)
    
    # Initialize with Claude project directory
    engine = SessionAnalyticsEngine("/home/opsvi/.claude/projects")
    
    try:
        # Run analysis on all Claude sessions
        results = engine.analyze_all_sessions()
        
        if not results:
            print("No results returned from comprehensive analysis")
            return
            
        print("Comprehensive Analysis Results:")
        
        # Summary statistics
        summary = results.get('summary', {})
        if summary:
            print("\nSummary Statistics:")
            for key, value in summary.items():
                if isinstance(value, (int, float)):
                    if 'duration' in key.lower() or 'time' in key.lower():
                        print(f"  {key.replace('_', ' ').title()}: {value:.2f}")
                    else:
                        print(f"  {key.replace('_', ' ').title()}: {value}")
                else:
                    print(f"  {key.replace('_', ' ').title()}: {value}")
        
        # Component results
        session_metrics = results.get('session_metrics', [])
        patterns = results.get('conversation_patterns', [])
        tools = results.get('tool_usage_analytics', [])
        files = results.get('file_operation_analytics', [])
        
        print(f"\nDetailed Component Results:")
        print(f"  Sessions Analyzed: {len(session_metrics)}")
        print(f"  Conversation Patterns: {len(patterns)}")
        print(f"  Tool Usage Analytics: {len(tools)}")
        print(f"  File Operation Analytics: {len(files)}")
        
        # Cross-session insights
        insights = results.get('cross_session_insights', {})
        if insights:
            print(f"\nCross-Session Insights:")
            
            # Most popular tools
            if 'most_popular_tools' in insights:
                print(f"  Most Popular Tools:")
                for tool, count in insights['most_popular_tools'][:5]:
                    print(f"    {tool}: {count} uses")
            
            # File type distribution
            if 'file_type_distribution' in insights:
                print(f"  File Type Distribution:")
                for ext, count in insights['file_type_distribution'][:5]:
                    display_ext = ext if ext else 'no_extension'
                    print(f"    {display_ext}: {count} files")
            
            # Usage patterns
            if 'session_duration_patterns' in insights:
                patterns = insights['session_duration_patterns']
                print(f"  Session Duration Patterns:")
                print(f"    Short (<5min): {patterns.get('short_sessions_under_5min', 0)}")
                print(f"    Medium (5-30min): {patterns.get('medium_sessions_5_30min', 0)}")
                print(f"    Long (>30min): {patterns.get('long_sessions_over_30min', 0)}")
                
        # Export results
        output_path = "/home/opsvi/master_root/apps/agent-orchestrator/output/claude_session_analytics.json"
        if engine.export_analytics(results, output_path):
            print(f"\nResults exported to: {output_path}")
            
            # Show sample sessions
            if session_metrics:
                print(f"\nSample Session Details:")
                for i, session in enumerate(session_metrics[:2]):  # Show first 2 sessions
                    print(f"  Session {i+1}:")
                    print(f"    ID: {session.session_id}")
                    print(f"    Duration: {session.duration_minutes:.2f} minutes")
                    print(f"    Messages: {session.total_messages}")
                    print(f"    Tool Calls: {session.total_tool_calls}")
                    
    except Exception as e:
        print(f"Error in comprehensive analysis: {e}")
        import traceback
        traceback.print_exc()


def test_modular_components_claude():
    """Test individual analytics components with Claude data"""
    print("\n\nTesting Modular Components with Claude Data")
    print("=" * 40)
    
    from analytics_components import default_registry
    
    # Get a sample Claude session
    engine = SessionAnalyticsEngine("/home/opsvi/.claude/projects")
    session_files = engine.session_parser.find_session_files()
    
    if not session_files:
        print("No Claude session files found for component testing")
        return
        
    # Parse a sample session
    session_data = engine.session_parser.parse_session_file(session_files[0])
    if not session_data:
        print("Failed to parse sample Claude session")
        return
        
    print(f"Testing components with Claude session: {session_data['session_id']}")
    
    # Test each component
    for component_name in default_registry.list_components():
        try:
            print(f"\n{component_name.replace('_', ' ').title()} Analysis:")
            component = default_registry.get_component(component_name)
            results = component.analyze(session_data)
            
            # Print relevant results for each component type
            if component_name == 'session_metrics':
                print(f"  Duration: {results.get('duration_minutes', 0):.2f} minutes")
                print(f"  Total Records: {results.get('total_records', 0)}")
                print(f"  Working Directory: {results.get('working_directory', 'N/A')}")
                
            elif component_name == 'tool_usage':
                print(f"  Total Tool Calls: {results.get('total_tool_calls', 0)}")
                print(f"  Unique Tools: {results.get('unique_tools', 0)}")
                tool_stats = results.get('tool_statistics', {})
                if tool_stats:
                    print(f"  Tool Breakdown:")
                    for tool, stats in list(tool_stats.items())[:3]:
                        print(f"    {tool}: {stats['total_calls']} calls, {stats['success_rate']:.1%} success")
                        
            elif component_name == 'file_activity':
                print(f"  File Operations: {results.get('total_file_operations', 0)}")
                print(f"  Unique Files: {results.get('unique_files_accessed', 0)}")
                file_types = results.get('file_type_distribution', {})
                if file_types:
                    print(f"  File Types: {', '.join(list(file_types.keys())[:3])}")
                    
            elif component_name == 'url_access':
                print(f"  URL Accesses: {results.get('total_url_accesses', 0)}")
                print(f"  Unique URLs: {results.get('unique_urls', 0)}")
                purposes = results.get('purpose_distribution', {})
                if purposes:
                    print(f"  Access Purposes: {', '.join(purposes.keys())}")
                    
            elif component_name == 'conversation_flow':
                print(f"  Conversation Turns: {results.get('total_turns', 0)}")
                print(f"  User Messages: {results.get('user_messages', 0)}")
                print(f"  Assistant Messages: {results.get('assistant_messages', 0)}")
                print(f"  Topic Shifts: {len(results.get('topic_shifts', []))}")
                
        except Exception as e:
            print(f"  Error: {e}")


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("SessionAnalyticsEngine - Claude Session Test Suite")
    print("=" * 60)
    
    # Create output directory
    Path("/home/opsvi/master_root/apps/agent-orchestrator/output").mkdir(parents=True, exist_ok=True)
    
    # Run tests
    test_claude_sessions()
    test_comprehensive_claude_analysis()
    test_modular_components_claude()
    
    print("\n" + "=" * 60)
    print("Claude session analysis test suite completed!")