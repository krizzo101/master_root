#!/usr/bin/env python3
"""
Test Multi-Provider Orchestrator Setup
"""
import os
from pathlib import Path
from src.generic_orchestrator import GenericOrchestrator

def test_multi_provider():
    """Test multi-provider initialization"""
    
    # Set fake OpenAI key for testing
    os.environ['OPENAI_API_KEY'] = 'test-key-for-initialization'
    
    # Create test orchestrator
    output_dir = Path("./test_multi_provider_output")
    output_dir.mkdir(exist_ok=True)
    
    try:
        orchestrator = GenericOrchestrator(
            output_dir=output_dir,
            max_parallel=5
        )
        
        print("✅ Multi-provider orchestrator initialized")
        print(f"   Active provider: {orchestrator.active_provider}")
        print(f"   Available providers: {list(orchestrator.providers.keys())}")
        
        if 'openai' in orchestrator.providers:
            print("✅ OpenAI provider loaded")
            status = orchestrator.providers['openai'].get_status()
            print(f"   OpenAI capacity: {status['capacity']}")
        else:
            print("ℹ️  OpenAI provider not loaded (missing real API key)")
            
        # Test provider switching
        print("\nTesting provider switching:")
        switched = orchestrator._switch_provider()
        print(f"   Switch successful: {switched}")
        print(f"   New active provider: {orchestrator.active_provider}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    finally:
        # Cleanup
        if 'OPENAI_API_KEY' in os.environ:
            del os.environ['OPENAI_API_KEY']

if __name__ == "__main__":
    print("🧪 Testing Multi-Provider Orchestrator Setup")
    print("=" * 50)
    success = test_multi_provider()
    print("=" * 50)
    if success:
        print("🎉 Multi-provider system ready for Phase 1 deployment!")
    else:
        print("❌ Multi-provider setup needs fixes")