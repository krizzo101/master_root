#!/usr/bin/env python3
"""
Test script to validate backward compatibility and new project organization features
in the enhanced AgentTask class.
"""

import json
import sys
from pathlib import Path

# Add the src directory to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import AgentTask, GenericOrchestrator


def test_backward_compatibility():
    """Test that existing task definitions still work without new fields."""
    print("Testing backward compatibility...")
    
    # Create a task using the old format (without new fields)
    old_task = AgentTask(
        task_id="test_old_task",
        task_type="analysis",
        prompt="Analyze the system",
        context={"test": "value"},
        dependencies=["dep1"],
        status="pending"
    )
    
    # Check that task can be serialized/deserialized
    try:
        task_dict = old_task.to_dict()
        print(f"✓ Old task serialization: {task_dict['task_id']}")
        
        # Verify new fields are not present or have default values
        if hasattr(old_task, 'project_location'):
            assert old_task.project_location is None, "project_location should be None by default"
        if hasattr(old_task, 'deliverable_structure'):
            assert old_task.deliverable_structure == {}, "deliverable_structure should be empty by default"
        if hasattr(old_task, 'directory_permissions'):
            assert old_task.directory_permissions == [], "directory_permissions should be empty by default"
        if hasattr(old_task, 'output_validation'):
            assert old_task.output_validation == {}, "output_validation should be empty by default"
        
        print("✓ All new fields have correct default values")
        
    except Exception as e:
        print(f"✗ Backward compatibility test failed: {e}")
        return False
    
    return True


def test_new_fields():
    """Test that new project organization fields work correctly."""
    print("Testing new project organization fields...")
    
    # Create a task with new fields
    new_task = AgentTask(
        task_id="test_new_task",
        task_type="development",
        prompt="Create a new project called awesome-app",
        project_location="/home/opsvi/master_root/apps/awesome-app/",
        deliverable_structure={
            "main": "/home/opsvi/master_root/apps/awesome-app/",
            "docs": "/home/opsvi/master_root/apps/awesome-app/docs/",
            "src": "/home/opsvi/master_root/apps/awesome-app/src/"
        },
        directory_permissions=[
            "/home/opsvi/master_root/apps/awesome-app/",
            "/home/opsvi/master_root/apps/"
        ],
        output_validation={
            "required_structure": True,
            "validate_paths": True,
            "check_project_standards": True
        }
    )
    
    try:
        task_dict = new_task.to_dict()
        print(f"✓ New task serialization: {task_dict['task_id']}")
        
        # Verify new fields are present
        assert new_task.project_location == "/home/opsvi/master_root/apps/awesome-app/"
        assert "main" in new_task.deliverable_structure
        assert len(new_task.directory_permissions) == 2
        assert new_task.output_validation["required_structure"] is True
        
        print("✓ All new fields are correctly set and accessible")
        
    except Exception as e:
        print(f"✗ New fields test failed: {e}")
        return False
    
    return True


def test_task_loading_from_json():
    """Test loading tasks from existing JSON files to ensure compatibility."""
    print("Testing task loading from existing JSON files...")
    
    # Test with an existing task file
    test_task_file = Path(__file__).parent / "orchestrator_self_fix_tasks.json"
    
    if not test_task_file.exists():
        print("✓ Test task file not found, skipping JSON compatibility test")
        return True
    
    try:
        with open(test_task_file) as f:
            task_data = json.load(f)
        
        # Try to create AgentTask objects from existing task definitions
        if "tasks" in task_data:
            for task_def in task_data["tasks"][:2]:  # Test first 2 tasks
                task = AgentTask(
                    task_id=task_def["task_id"],
                    task_type=task_def["task_type"],
                    prompt=task_def["prompt"],
                    context=task_def.get("context", {}),
                    dependencies=task_def.get("dependencies", [])
                )
                
                # Verify the task was created successfully
                assert task.task_id == task_def["task_id"]
                print(f"✓ Successfully loaded task: {task.task_id}")
        
        print("✓ Existing JSON task definitions are compatible")
        
    except Exception as e:
        print(f"✗ JSON compatibility test failed: {e}")
        return False
    
    return True


def test_orchestrator_validation():
    """Test that orchestrator validation methods work correctly."""
    print("Testing orchestrator validation methods...")
    
    # Create a temporary orchestrator instance to test validation
    try:
        import tempfile
        temp_dir = Path(tempfile.mkdtemp(prefix="orchestrator_test_"))
        
        orchestrator = GenericOrchestrator(
            output_dir=temp_dir,
            max_parallel=1
        )
        
        # Test validation methods
        test_task = AgentTask(
            task_id="validation_test",
            task_type="development",
            prompt="Create a new project called my-awesome-project",
        )
        
        # Test project organization validation
        validation_result = orchestrator._validate_task_project_organization(test_task)
        print(f"✓ Validation result: {len(validation_result['warnings'])} warnings, {len(validation_result['suggestions'])} suggestions")
        
        # Test task enhancement
        enhanced_task = orchestrator._enhance_task_with_project_organization(test_task)
        if hasattr(enhanced_task, 'project_location') and enhanced_task.project_location:
            print(f"✓ Task enhanced with project_location: {enhanced_task.project_location}")
        else:
            print("✓ Task enhancement completed (no project creation detected)")
        
        # Cleanup
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)
        
    except Exception as e:
        print(f"✗ Orchestrator validation test failed: {e}")
        return False
    
    return True


def main():
    """Run all tests."""
    print("Running AgentTask Project Organization Tests")
    print("=" * 50)
    
    tests = [
        test_backward_compatibility,
        test_new_fields,
        test_task_loading_from_json,
        test_orchestrator_validation
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
                print(f"✓ {test.__name__} PASSED")
            else:
                failed += 1
                print(f"✗ {test.__name__} FAILED")
        except Exception as e:
            failed += 1
            print(f"✗ {test.__name__} FAILED with exception: {e}")
        
        print()
    
    print("=" * 50)
    print(f"Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All tests passed! Project organization features are working correctly.")
        return 0
    else:
        print("❌ Some tests failed. Please review the implementation.")
        return 1


if __name__ == "__main__":
    sys.exit(main())