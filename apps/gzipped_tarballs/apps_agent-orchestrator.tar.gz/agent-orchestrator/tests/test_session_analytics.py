#!/usr/bin/env python3
"""
Test Script for SessionAnalyticsEngine
Demonstrates usage and validates functionality with sample session logs.
"""

import sys
import logging
from pathlib import Path

# Add src directory to path
sys.path.append(str(Path(__file__).parent / "src"))

from session_analytics_engine import SessionAnalyticsEngine
from analytics_components import default_registry

def test_single_session():
    """Test analysis of a single session file"""
    print("Testing Single Session Analysis")
    print("=" * 40)
    
    # Initialize engine
    engine = SessionAnalyticsEngine()
    
    # Find sample session files
    session_files = engine.session_parser.find_session_files()
    
    if not session_files:
        print("No session files found for testing")
        return
        
    # Test with first file
    test_file = session_files[0]
    print(f"Testing with file: {test_file}")
    
    try:
        metrics, patterns, tools, files = engine.analyze_single_session(test_file)
        
        if metrics:
            print(f"\nSession Metrics:")
            print(f"  Session ID: {metrics.session_id}")
            print(f"  Duration: {metrics.duration_minutes:.2f} minutes")
            print(f"  Total Messages: {metrics.total_messages}")
            print(f"  Tool Calls: {metrics.total_tool_calls}")
            print(f"  Files Touched: {metrics.unique_files_touched}")
            print(f"  Working Directory: {metrics.working_directory}")
            
        if patterns:
            print(f"\nConversation Patterns: {len(patterns)}")
            for pattern in patterns:
                print(f"  Type: {pattern.pattern_type}, Turns: {pattern.frequency}")
                
        if tools:
            print(f"\nTool Usage Analytics: {len(tools)}")
            for tool in tools[:3]:  # Show first 3
                print(f"  {tool.tool_name}: {tool.usage_count} calls, {tool.success_rate:.2%} success")
                
        if files:
            print(f"\nFile Operations: {len(files)}")
            for file_op in files[:3]:  # Show first 3
                print(f"  {Path(file_op.file_path).name}: {file_op.total_operations} ops")
                
    except Exception as e:
        print(f"Error testing single session: {e}")
        import traceback
        traceback.print_exc()


def test_modular_components():
    """Test individual analytics components"""
    print("\n\nTesting Modular Components")
    print("=" * 40)
    
    # Initialize engine to get sample data
    engine = SessionAnalyticsEngine()
    session_files = engine.session_parser.find_session_files()
    
    if not session_files:
        print("No session files found for component testing")
        return
        
    # Parse a sample session
    session_data = engine.session_parser.parse_session_file(session_files[0])
    if not session_data:
        print("Failed to parse sample session")
        return
        
    print(f"Testing components with session: {session_data['session_id']}")
    
    # Test each component
    for component_name in default_registry.list_components():
        try:
            print(f"\nTesting {component_name}:")
            component = default_registry.get_component(component_name)
            results = component.analyze(session_data)
            
            # Print key results
            if component_name == 'session_metrics':
                print(f"  Duration: {results.get('duration_minutes', 0):.2f} min")
                print(f"  Total Records: {results.get('total_records', 0)}")
                
            elif component_name == 'tool_usage':
                print(f"  Total Tool Calls: {results.get('total_tool_calls', 0)}")
                print(f"  Unique Tools: {results.get('unique_tools', 0)}")
                
            elif component_name == 'file_activity':
                print(f"  File Operations: {results.get('total_file_operations', 0)}")
                print(f"  Unique Files: {results.get('unique_files_accessed', 0)}")
                
            elif component_name == 'url_access':
                print(f"  URL Accesses: {results.get('total_url_accesses', 0)}")
                print(f"  Unique URLs: {results.get('unique_urls', 0)}")
                
            elif component_name == 'conversation_flow':
                print(f"  Conversation Turns: {results.get('total_turns', 0)}")
                print(f"  Topic Shifts: {len(results.get('topic_shifts', []))}")
                
        except Exception as e:
            print(f"  Error: {e}")


def test_comprehensive_analysis():
    """Test comprehensive analysis of all sessions"""
    print("\n\nTesting Comprehensive Analysis")
    print("=" * 40)
    
    try:
        engine = SessionAnalyticsEngine()
        results = engine.analyze_all_sessions()
        
        if not results:
            print("No analysis results returned")
            return
            
        # Print summary
        summary = results.get('summary', {})
        if summary:
            print("Analysis Summary:")
            for key, value in summary.items():
                print(f"  {key.replace('_', ' ').title()}: {value}")
                
        # Print component counts
        print(f"\nDetailed Results:")
        print(f"  Sessions Analyzed: {len(results.get('session_metrics', []))}")
        print(f"  Conversation Patterns: {len(results.get('conversation_patterns', []))}")
        print(f"  Tool Analytics: {len(results.get('tool_usage_analytics', []))}")
        print(f"  File Analytics: {len(results.get('file_operation_analytics', []))}")
        
        # Show cross-session insights
        insights = results.get('cross_session_insights', {})
        if insights:
            print(f"\nCross-Session Insights:")
            
            if 'most_popular_tools' in insights:
                print(f"  Most Popular Tools:")
                for tool, count in insights['most_popular_tools'][:3]:
                    print(f"    {tool}: {count} uses")
                    
            if 'file_type_distribution' in insights:
                print(f"  File Types Accessed:")
                for ext, count in insights['file_type_distribution'][:3]:
                    print(f"    {ext or 'no_ext'}: {count} files")
                    
            if 'peak_usage_hours' in insights:
                print(f"  Peak Usage Hours:")
                for hour, count in insights['peak_usage_hours'][:3]:
                    print(f"    {hour}:00: {count} sessions")
                    
        # Test export functionality
        output_path = "/home/opsvi/master_root/apps/agent-orchestrator/output/test_analytics_results.json"
        if engine.export_analytics(results, output_path):
            print(f"\nResults exported to: {output_path}")
        else:
            print("\nFailed to export results")
            
    except Exception as e:
        print(f"Error in comprehensive analysis: {e}")
        import traceback
        traceback.print_exc()


def test_performance_metrics():
    """Test performance and validate data quality"""
    print("\n\nTesting Performance & Data Quality")
    print("=" * 40)
    
    import time
    
    engine = SessionAnalyticsEngine()
    session_files = engine.session_parser.find_session_files()
    
    if len(session_files) == 0:
        print("No session files available for performance testing")
        return
        
    # Test parsing performance
    start_time = time.time()
    parsed_count = 0
    
    for session_file in session_files[:5]:  # Test first 5 files
        try:
            session_data = engine.session_parser.parse_session_file(session_file)
            if session_data:
                parsed_count += 1
        except Exception as e:
            print(f"Parse error for {session_file}: {e}")
            
    parse_time = time.time() - start_time
    
    print(f"Parsing Performance:")
    print(f"  Files parsed: {parsed_count}")
    print(f"  Total time: {parse_time:.2f} seconds")
    print(f"  Average per file: {parse_time/max(parsed_count,1):.2f} seconds")
    
    # Test analysis performance
    if parsed_count > 0:
        start_time = time.time()
        results = engine.analyze_all_sessions()
        analysis_time = time.time() - start_time
        
        print(f"\nAnalysis Performance:")
        print(f"  Total analysis time: {analysis_time:.2f} seconds")
        print(f"  Sessions analyzed: {len(results.get('session_metrics', []))}")
        
        # Validate data quality
        print(f"\nData Quality Validation:")
        metrics = results.get('session_metrics', [])
        if metrics:
            valid_durations = [m for m in metrics if m.duration_minutes >= 0]
            valid_messages = [m for m in metrics if m.total_messages > 0]
            
            print(f"  Valid duration metrics: {len(valid_durations)}/{len(metrics)}")
            print(f"  Sessions with messages: {len(valid_messages)}/{len(metrics)}")
            
            if valid_durations:
                avg_duration = sum(m.duration_minutes for m in valid_durations) / len(valid_durations)
                print(f"  Average session duration: {avg_duration:.2f} minutes")


def demonstrate_extension():
    """Demonstrate how to extend the system with custom components"""
    print("\n\nDemonstrating System Extension")
    print("=" * 40)
    
    from analytics_components import AnalyticsComponent, default_registry
    
    class CustomAnalyticsComponent(AnalyticsComponent):
        """Example custom analytics component"""
        
        def __init__(self):
            super().__init__("CustomExample")
            
        def analyze(self, session_data):
            """Custom analysis logic"""
            records = session_data.get('records', [])
            
            # Example: Count thinking blocks
            thinking_blocks = 0
            for record in records:
                if record.get('type') == 'assistant':
                    content = record.get('message', {}).get('content', [])
                    if isinstance(content, list):
                        for item in content:
                            if item.get('type') == 'thinking':
                                thinking_blocks += 1
                                
            return {
                'thinking_blocks_found': thinking_blocks,
                'session_id': session_data.get('session_id', 'unknown'),
                'analysis_timestamp': '2025-09-08T16:42:08Z'
            }
            
        def get_schema(self):
            return {
                'type': 'object',
                'properties': {
                    'thinking_blocks_found': {'type': 'integer'},
                    'session_id': {'type': 'string'},
                    'analysis_timestamp': {'type': 'string'}
                }
            }
    
    # Register custom component
    default_registry.register_component('custom_thinking_analysis', CustomAnalyticsComponent)
    
    print("Registered custom component: custom_thinking_analysis")
    print(f"Available components: {default_registry.list_components()}")
    
    # Test custom component
    engine = SessionAnalyticsEngine()
    session_files = engine.session_parser.find_session_files()
    
    if session_files:
        session_data = engine.session_parser.parse_session_file(session_files[0])
        if session_data:
            custom_component = default_registry.get_component('custom_thinking_analysis')
            results = custom_component.analyze(session_data)
            print(f"Custom analysis results: {results}")


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("SessionAnalyticsEngine Test Suite")
    print("=" * 50)
    
    # Create output directory
    Path("/home/opsvi/master_root/apps/agent-orchestrator/output").mkdir(parents=True, exist_ok=True)
    
    # Run all tests
    test_single_session()
    test_modular_components()
    test_comprehensive_analysis()
    test_performance_metrics()
    demonstrate_extension()
    
    print("\n" + "=" * 50)
    print("Test suite completed!")