"""
Base test class and utilities for DPO testing.
"""

import unittest
import asyncio
import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
import tempfile
import os


class DPOTestBase(unittest.TestCase):
    """Base class for all DPO tests with common utilities."""
    
    @classmethod
    def setUpClass(cls):
        """Set up class-level test fixtures."""
        cls.logger = logging.getLogger(cls.__name__)
        cls.test_start_time = datetime.now()
        cls.test_results = []
        
    @classmethod
    def tearDownClass(cls):
        """Clean up class-level test fixtures."""
        duration = (datetime.now() - cls.test_start_time).total_seconds()
        cls.logger.info(f"Test class {cls.__name__} completed in {duration:.2f} seconds")
        
    def setUp(self):
        """Set up test-level fixtures."""
        self.test_name = self._testMethodName
        self.start_time = datetime.now()
        self.temp_files = []
        
    def tearDown(self):
        """Clean up test-level fixtures."""
        duration = (datetime.now() - self.start_time).total_seconds()
        self.logger.info(f"Test {self.test_name} completed in {duration:.2f} seconds")
        
        # Clean up temporary files
        for temp_file in self.temp_files:
            if os.path.exists(temp_file):
                os.remove(temp_file)
                
    def create_temp_file(self, content: str = "", suffix: str = ".json") -> str:
        """Create a temporary file for testing."""
        fd, path = tempfile.mkstemp(suffix=suffix)
        os.write(fd, content.encode())
        os.close(fd)
        self.temp_files.append(path)
        return path
        
    def assert_json_equal(self, actual: Dict, expected: Dict, ignore_keys: List[str] = None):
        """Assert two JSON objects are equal, optionally ignoring certain keys."""
        if ignore_keys:
            actual = {k: v for k, v in actual.items() if k not in ignore_keys}
            expected = {k: v for k, v in expected.items() if k not in ignore_keys}
        
        self.assertEqual(
            json.dumps(actual, sort_keys=True),
            json.dumps(expected, sort_keys=True),
            f"JSON objects do not match.\nActual: {actual}\nExpected: {expected}"
        )
        
    def assert_contains_all(self, container: Any, items: List[Any]):
        """Assert that container contains all specified items."""
        for item in items:
            self.assertIn(item, container, f"Item {item} not found in container")
            
    def assert_performance(self, duration: float, max_duration: float):
        """Assert that an operation completed within performance bounds."""
        self.assertLessEqual(
            duration, max_duration,
            f"Operation took {duration:.2f}s, exceeding limit of {max_duration:.2f}s"
        )
        
    def assert_success_rate(self, successes: int, total: int, min_rate: float):
        """Assert that success rate meets minimum threshold."""
        rate = (successes / total) * 100 if total > 0 else 0
        self.assertGreaterEqual(
            rate, min_rate,
            f"Success rate {rate:.1f}% below minimum {min_rate:.1f}%"
        )


class AsyncDPOTestBase(DPOTestBase):
    """Base class for asynchronous DPO tests."""
    
    def setUp(self):
        """Set up async test fixtures."""
        super().setUp()
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
    def tearDown(self):
        """Clean up async test fixtures."""
        self.loop.close()
        super().tearDown()
        
    def run_async(self, coro):
        """Helper to run async coroutines in tests."""
        return self.loop.run_until_complete(coro)
        
    async def assert_async_raises(self, exception_class, coro):
        """Assert that an async operation raises a specific exception."""
        with self.assertRaises(exception_class):
            await coro
            
    async def wait_for_condition(self, condition_func, timeout: float = 5.0, interval: float = 0.1):
        """Wait for a condition to become true."""
        start = datetime.now()
        while (datetime.now() - start).total_seconds() < timeout:
            if await condition_func():
                return True
            await asyncio.sleep(interval)
        return False


class TestDataGenerator:
    """Generate test data for various scenarios."""
    
    @staticmethod
    def generate_request(request_type: str = "api_development", **kwargs) -> Dict[str, Any]:
        """Generate a test request."""
        templates = {
            "api_development": {
                "type": "api_development",
                "description": "Create a REST API",
                "requirements": ["CRUD operations", "Authentication"],
                "technology_stack": ["Python", "FastAPI"]
            },
            "fullstack_application": {
                "type": "fullstack_application",
                "description": "Build a web application",
                "requirements": ["Frontend", "Backend", "Database"],
                "technology_stack": ["React", "Node.js", "PostgreSQL"]
            },
            "cli_development": {
                "type": "cli_development",
                "description": "Develop a CLI tool",
                "requirements": ["Command parsing", "File operations"],
                "technology_stack": ["Python", "Click"]
            }
        }
        
        base = templates.get(request_type, templates["api_development"])
        base.update(kwargs)
        return base
        
    @staticmethod
    def generate_workflow(num_agents: int = 3, **kwargs) -> Dict[str, Any]:
        """Generate a test workflow."""
        workflow = {
            "task_type": "development",
            "agents": [
                {
                    "id": f"agent_{i}",
                    "type": ["architect", "developer", "tester"][i % 3],
                    "config": {}
                }
                for i in range(num_agents)
            ],
            "config": {
                "parallel_execution": True,
                "quality_gates_enabled": True
            }
        }
        workflow.update(kwargs)
        return workflow
        
    @staticmethod
    def generate_enhancement(enhancement_type: str = "performance") -> Dict[str, Any]:
        """Generate a test enhancement."""
        return {
            "type": enhancement_type,
            "suggestion": f"Implement {enhancement_type} optimization",
            "priority": "high",
            "rationale": f"This will improve {enhancement_type}",
            "implementation_hints": [
                f"Consider {enhancement_type} best practices",
                "Review current implementation",
                "Apply optimizations"
            ]
        }


class MockComponent:
    """Base class for mock components."""
    
    def __init__(self, name: str):
        self.name = name
        self.call_log = []
        self.response_queue = []
        
    def add_response(self, response: Any):
        """Add a response to the queue."""
        self.response_queue.append(response)
        
    def get_next_response(self):
        """Get the next queued response."""
        if self.response_queue:
            return self.response_queue.pop(0)
        return {"status": "success"}
        
    def log_call(self, method: str, *args, **kwargs):
        """Log a method call."""
        self.call_log.append({
            "method": method,
            "args": args,
            "kwargs": kwargs,
            "timestamp": datetime.now()
        })
        
    def reset(self):
        """Reset the mock component."""
        self.call_log = []
        self.response_queue = []
        
    def get_call_count(self, method: str = None) -> int:
        """Get the number of calls to a specific method."""
        if method:
            return len([c for c in self.call_log if c["method"] == method])
        return len(self.call_log)


class TestValidator:
    """Validate test results against expected criteria."""
    
    @staticmethod
    def validate_request_classification(classification: Dict[str, Any]) -> bool:
        """Validate request classification structure and content."""
        required_fields = ["type", "confidence", "complexity"]
        
        # Check required fields
        if not all(field in classification for field in required_fields):
            return False
            
        # Validate type
        valid_types = [
            "api_development",
            "fullstack_application",
            "cli_development",
            "integration_connector"
        ]
        if classification["type"] not in valid_types:
            return False
            
        # Validate confidence
        if not 0 <= classification["confidence"] <= 1:
            return False
            
        # Validate complexity
        valid_complexities = ["simple", "medium", "complex"]
        if classification["complexity"] not in valid_complexities:
            return False
            
        return True
        
    @staticmethod
    def validate_workflow_structure(workflow: Dict[str, Any]) -> bool:
        """Validate workflow JSON structure."""
        required_fields = ["task_type", "agents", "config"]
        
        # Check required fields
        if not all(field in workflow for field in required_fields):
            return False
            
        # Validate agents
        if not isinstance(workflow["agents"], list) or len(workflow["agents"]) == 0:
            return False
            
        for agent in workflow["agents"]:
            if not all(field in agent for field in ["id", "type"]):
                return False
                
        return True
        
    @staticmethod
    def validate_enhancement_structure(enhancement: Dict[str, Any]) -> bool:
        """Validate enhancement structure."""
        required_fields = ["type", "suggestion", "priority"]
        
        # Check required fields
        if not all(field in enhancement for field in required_fields):
            return False
            
        # Validate priority
        valid_priorities = ["low", "medium", "high", "critical"]
        if enhancement["priority"] not in valid_priorities:
            return False
            
        return True
        
    @staticmethod
    def validate_performance_metrics(metrics: Dict[str, Any]) -> bool:
        """Validate performance metrics."""
        required_metrics = ["execution_time", "memory_usage", "success_rate"]
        
        # Check required metrics
        if not all(metric in metrics for metric in required_metrics):
            return False
            
        # Validate metric values
        if metrics["execution_time"] < 0:
            return False
            
        if metrics["memory_usage"] < 0:
            return False
            
        if not 0 <= metrics["success_rate"] <= 100:
            return False
            
        return True