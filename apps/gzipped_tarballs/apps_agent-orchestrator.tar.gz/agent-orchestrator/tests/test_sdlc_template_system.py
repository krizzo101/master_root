#!/usr/bin/env python3
"""
Test suite for SDLC Template System
"""

import json
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from sdlc_template_system import (
    SDLCTemplateSystem,
    BackendAPITemplate,
    FrontendApplicationTemplate,
    FullStackApplicationTemplate,
    CLIToolTemplate,
    LibraryPackageTemplate,
    IntegrationConnectorTemplate,
    DataPipelineTemplate,
    WorkflowPhase
)


def test_backend_api_template():
    """Test backend API template generation"""
    print("\n🔧 Testing Backend API Template...")
    
    template = BackendAPITemplate("test-api", "high")
    phases = template.build_workflow()
    
    assert len(phases) > 0, "Should generate phases"
    assert any(p.phase_id == "discovery" for p in phases), "Should have discovery phase"
    assert any(p.phase_id == "design" for p in phases), "Should have design phase"
    assert any("implementation" in p.phase_id for p in phases), "Should have implementation phases"
    
    workflow = template.to_orchestrator_format()
    assert "tasks" in workflow, "Should generate tasks"
    assert len(workflow["tasks"]) > 0, "Should have tasks"
    
    print(f"✅ Backend API: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_frontend_template():
    """Test frontend application template"""
    print("\n🎨 Testing Frontend Application Template...")
    
    template = FrontendApplicationTemplate("test-frontend", "medium")
    phases = template.build_workflow()
    
    assert any("components" in p.phase_id for p in phases), "Should have component implementation"
    assert any(p.phase_type == "design" for p in phases), "Should have design phase"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ Frontend: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_fullstack_template():
    """Test full-stack application template"""
    print("\n🌐 Testing Full-Stack Application Template...")
    
    template = FullStackApplicationTemplate("test-fullstack", "enterprise")
    phases = template.build_workflow()
    
    # Check for both backend and frontend phases
    backend_phases = [p for p in phases if "backend" in p.phase_id]
    frontend_phases = [p for p in phases if "frontend" in p.phase_id]
    
    assert len(backend_phases) > 0, "Should have backend phases"
    assert len(frontend_phases) > 0, "Should have frontend phases"
    assert any(p.phase_id == "integration" for p in phases), "Should have integration phase"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ Full-Stack: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_cli_tool_template():
    """Test CLI tool template"""
    print("\n⌨️ Testing CLI Tool Template...")
    
    template = CLIToolTemplate("test-cli", "low")
    phases = template.build_workflow()
    
    assert any(p.phase_id == "cli_design" for p in phases), "Should have CLI design phase"
    assert any(p.phase_id == "packaging" for p in phases), "Should have packaging phase"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ CLI Tool: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_library_template():
    """Test library/package template"""
    print("\n📦 Testing Library Package Template...")
    
    template = LibraryPackageTemplate("test-library", "high")
    phases = template.build_workflow()
    
    assert any(p.phase_id == "api_design" for p in phases), "Should have API design phase"
    assert any(p.phase_id == "publishing" for p in phases), "Should have publishing phase"
    
    # Check for high test coverage requirement
    testing_phase = next((p for p in phases if p.phase_id == "testing"), None)
    assert testing_phase is not None, "Should have testing phase"
    assert testing_phase.validation_rules.get("test_coverage") == 90, "Should require 90% coverage"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ Library: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_integration_template():
    """Test integration connector template"""
    print("\n🔌 Testing Integration Connector Template...")
    
    template = IntegrationConnectorTemplate("test-connector", "medium")
    phases = template.build_workflow()
    
    assert any(p.phase_id == "connector_design" for p in phases), "Should have connector design"
    assert any(p.phase_id == "integration_testing" for p in phases), "Should have integration testing"
    assert any(p.phase_id == "monitoring" for p in phases), "Should have monitoring setup"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ Integration: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_data_pipeline_template():
    """Test data pipeline template"""
    print("\n📊 Testing Data Pipeline Template...")
    
    template = DataPipelineTemplate("test-pipeline", "high")
    phases = template.build_workflow()
    
    assert any(p.phase_id == "pipeline_design" for p in phases), "Should have pipeline design"
    assert any(p.phase_id == "data_quality" for p in phases), "Should have data quality phase"
    assert any(p.phase_id == "optimization" for p in phases), "Should have optimization phase"
    
    workflow = template.to_orchestrator_format()
    print(f"✅ Data Pipeline: {len(phases)} phases, {len(workflow['tasks'])} tasks")
    return True


def test_template_selection():
    """Test intelligent template selection"""
    print("\n🧠 Testing Template Selection...")
    
    system = SDLCTemplateSystem()
    
    # Test direct matches
    assert system.select_template("backend_api", {}) == "backend_api"
    assert system.select_template("frontend_app", {}) == "frontend_app"
    
    # Test intelligent selection
    specs1 = {"description": "REST API for user management"}
    assert system.select_template("unknown", specs1) == "backend_api"
    
    specs2 = {"description": "React dashboard application", "technology_stack": "React TypeScript"}
    assert system.select_template("unknown", specs2) == "frontend_app"
    
    specs3 = {"description": "ETL pipeline for data processing"}
    assert system.select_template("unknown", specs3) == "data_pipeline"
    
    print("✅ Template selection working correctly")
    return True


def test_workflow_generation():
    """Test complete workflow generation"""
    print("\n🏗️ Testing Workflow Generation...")
    
    system = SDLCTemplateSystem()
    
    workflow = system.generate_workflow(
        project_name="test-project",
        project_type="backend_api",
        complexity="high",
        specifications={
            "technology_stack": "Python FastAPI",
            "requirements": ["auth", "crud"],
            "integrations": ["payment"]
        },
        customizations={
            "agent_scaling_factor": 1.5,
            "additional_quality_gates": ["custom_check"]
        }
    )
    
    # Validate structure
    assert "workflow_id" in workflow
    assert "metadata" in workflow
    assert "phases" in workflow
    assert "tasks" in workflow
    assert "execution_config" in workflow
    
    # Check customizations applied
    assert workflow["metadata"]["customizations"]["agent_scaling_factor"] == 1.5
    
    # Validate workflow
    is_valid, issues = system.validate_workflow(workflow)
    assert is_valid, f"Workflow validation failed: {issues}"
    
    print(f"✅ Generated workflow: {workflow['workflow_id']}")
    print(f"   - Phases: {len(workflow['phases'])}")
    print(f"   - Tasks: {len(workflow['tasks'])}")
    
    return True


def test_complexity_scaling():
    """Test agent scaling based on complexity"""
    print("\n📈 Testing Complexity Scaling...")
    
    complexities = ["low", "medium", "high", "enterprise"]
    
    for complexity in complexities:
        template = BackendAPITemplate("test", complexity)
        template.build_workflow()
        workflow = template.to_orchestrator_format()
        
        task_count = len(workflow["tasks"])
        print(f"  {complexity}: {task_count} tasks")
    
    print("✅ Complexity scaling verified")
    return True


def test_workflow_validation():
    """Test workflow validation"""
    print("\n✔️ Testing Workflow Validation...")
    
    system = SDLCTemplateSystem()
    
    # Valid workflow
    valid_workflow = {
        "workflow_id": "test_123",
        "metadata": {},
        "phases": [
            {"phase_id": "p1", "dependencies": []},
            {"phase_id": "p2", "dependencies": ["p1"]}
        ],
        "tasks": [
            {"task_id": "t1"},
            {"task_id": "t2"}
        ],
        "execution_config": {"max_parallel_agents": 10}
    }
    
    is_valid, issues = system.validate_workflow(valid_workflow)
    assert is_valid, "Valid workflow should pass"
    
    # Invalid workflow - duplicate task
    invalid_workflow = {
        "workflow_id": "test_456",
        "metadata": {},
        "phases": [],
        "tasks": [
            {"task_id": "t1"},
            {"task_id": "t1"}  # Duplicate
        ]
    }
    
    is_valid, issues = system.validate_workflow(invalid_workflow)
    assert not is_valid, "Invalid workflow should fail"
    assert any("Duplicate task ID" in issue for issue in issues)
    
    print("✅ Workflow validation working correctly")
    return True


def test_custom_phase_addition():
    """Test adding custom phases through customizations"""
    print("\n➕ Testing Custom Phase Addition...")
    
    system = SDLCTemplateSystem()
    
    customizations = {
        "additional_phases": [
            {
                "phase_id": "custom_security",
                "phase_name": "Security Audit",
                "phase_type": "qa",
                "agents": [{"type": "security-auditor", "count": 2}],
                "dependencies": ["qa"],
                "quality_gates": ["security_scan_pass"]
            }
        ]
    }
    
    workflow = system.generate_workflow(
        project_name="secure-app",
        project_type="backend_api",
        complexity="high",
        customizations=customizations
    )
    
    # Check custom phase was added
    custom_phase = next((p for p in workflow["phases"] if p["phase_id"] == "custom_security"), None)
    assert custom_phase is not None, "Custom phase should be added"
    assert custom_phase["phase_name"] == "Security Audit"
    
    print("✅ Custom phase addition working")
    return True


def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("🧪 SDLC Template System Test Suite")
    print("=" * 60)
    
    tests = [
        test_backend_api_template,
        test_frontend_template,
        test_fullstack_template,
        test_cli_tool_template,
        test_library_template,
        test_integration_template,
        test_data_pipeline_template,
        test_template_selection,
        test_workflow_generation,
        test_complexity_scaling,
        test_workflow_validation,
        test_custom_phase_addition
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
                print(f"❌ {test.__name__} failed")
        except Exception as e:
            failed += 1
            print(f"❌ {test.__name__} failed with error: {e}")
    
    print("\n" + "=" * 60)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)