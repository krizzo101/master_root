#!/usr/bin/env python3
"""
Test Suite for Intelligence Review Engine

Validates the functionality of the Intelligence Review Engine including:
- Basic enhancement generation
- Advanced intelligence algorithms
- DPO integration
- Specialist agent coordination

Author: Agent Orchestrator Team
Date: September 2025
"""

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import components to test
from src.intelligence_review_engine import IntelligenceReviewEngine
from src.intelligence_review_engine_enhanced import EnhancementIntelligenceEngine
from src.dpo_intelligence_integration import DPOIntelligenceIntegration, DPORequest
from src.specialist_agent_templates import SpecialistAgentTemplates

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class IntelligenceReviewEngineTests:
    """Test suite for Intelligence Review Engine"""
    
    def __init__(self):
        self.test_results = []
        self.output_dir = Path('output/test_intelligence_review')
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    async def run_all_tests(self):
        """Run all test cases"""
        print("\n" + "="*80)
        print("INTELLIGENCE REVIEW ENGINE TEST SUITE")
        print("="*80)
        
        tests = [
            self.test_basic_enhancement,
            self.test_specialist_templates,
            self.test_advanced_intelligence,
            self.test_constraint_optimization,
            self.test_dpo_integration,
            self.test_error_handling,
            self.test_performance
        ]
        
        for test in tests:
            try:
                await test()
                self.test_results.append({
                    'test': test.__name__,
                    'status': 'PASSED',
                    'timestamp': datetime.now().isoformat()
                })
                print(f"✓ {test.__name__}: PASSED")
            except Exception as e:
                self.test_results.append({
                    'test': test.__name__,
                    'status': 'FAILED',
                    'error': str(e),
                    'timestamp': datetime.now().isoformat()
                })
                print(f"✗ {test.__name__}: FAILED - {e}")
                logger.error(f"Test {test.__name__} failed", exc_info=True)
        
        self._print_summary()
        self._save_results()
    
    async def test_basic_enhancement(self):
        """Test basic enhancement functionality"""
        print("\n--- Test: Basic Enhancement ---")
        
        engine = IntelligenceReviewEngine(
            parallel_agents=3,
            output_dir=str(self.output_dir / 'basic_enhancement')
        )
        
        request = "Build a simple TODO application with user authentication"
        
        result = await engine.enhance_request(
            original_request=request,
            project_context={
                'framework': 'React',
                'backend': 'Node.js',
                'database': 'PostgreSQL'
            }
        )
        
        # Validate result structure
        assert result.original_request == request
        assert result.enhanced_specification
        assert result.enhancement_analysis
        assert result.justification
        assert result.metadata
        
        # Check for enhancements
        assert len(result.enhancement_analysis) > 0
        
        print(f"  Generated {result.get_summary()}")
        print("  ✓ Basic enhancement test passed")
    
    async def test_specialist_templates(self):
        """Test specialist agent templates"""
        print("\n--- Test: Specialist Templates ---")
        
        templates = SpecialistAgentTemplates.get_all_templates()
        
        # Verify all templates exist
        expected_templates = [
            'performance-optimizer',
            'solution-architect',
            'integration-specialist',
            'innovation-analyst',
            'development-accelerator',
            'research-genius'
        ]
        
        for template_name in expected_templates:
            assert template_name in templates
            template = templates[template_name]
            
            # Validate template structure
            assert template.agent_type == template_name
            assert template.name
            assert template.description
            assert len(template.expertise_areas) > 0
            assert template.prompt_template
            assert len(template.analysis_categories) > 0
            
            print(f"  ✓ {template.name} template valid")
        
        print("  ✓ All specialist templates validated")
    
    async def test_advanced_intelligence(self):
        """Test advanced intelligence features"""
        print("\n--- Test: Advanced Intelligence ---")
        
        engine = EnhancementIntelligenceEngine(
            parallel_agents=4,
            output_dir=str(self.output_dir / 'advanced_intelligence')
        )
        
        request = "Create a high-performance data analytics platform"
        
        result = await engine.enhance_with_intelligence(
            original_request=request,
            project_context={
                'data_volume': '1TB daily',
                'users': '1000 analysts',
                'deployment': 'Kubernetes'
            },
            optimization_goals=['maximize_performance', 'ensure_scalability'],
            constraints={
                'budget_units': 50,
                'timeline': 'normal',
                'max_enhancements': 10
            }
        )
        
        # Validate advanced features
        assert 'enhancement_plan' in result
        assert 'implementation_roadmap' in result
        assert 'metrics' in result
        assert 'quick_wins' in result
        assert 'innovation_highlights' in result
        assert 'risk_analysis' in result
        assert 'cost_benefit_analysis' in result
        
        # Check metrics
        metrics = result['metrics']
        assert metrics['enhancement_count'] > 0
        assert 0 <= metrics['average_impact_score'] <= 1
        
        # Check roadmap
        roadmap = result['implementation_roadmap']
        assert len(roadmap['phases']) > 0
        
        print(f"  Selected {result['metadata']['enhancements_selected']} enhancements")
        print(f"  Impact score: {result['metadata']['estimated_impact_score']:.2%}")
        print("  ✓ Advanced intelligence test passed")
    
    async def test_constraint_optimization(self):
        """Test constraint-based optimization"""
        print("\n--- Test: Constraint Optimization ---")
        
        engine = EnhancementIntelligenceEngine(
            parallel_agents=3,
            output_dir=str(self.output_dir / 'constraint_optimization')
        )
        
        # Test with tight constraints
        result = await engine.enhance_with_intelligence(
            original_request="Build a mobile app for food delivery",
            constraints={
                'budget_units': 20,  # Very limited budget
                'timeline': 'aggressive',
                'max_enhancements': 5  # Few enhancements allowed
            }
        )
        
        # Verify constraints are respected
        assert result['metadata']['enhancements_selected'] <= 5
        
        # Check that quick wins are prioritized
        quick_wins = result['quick_wins']
        assert len(quick_wins) > 0
        
        # Verify cost-benefit analysis
        cba = result['cost_benefit_analysis']
        assert cba['estimated_total_cost_units'] <= 20
        assert cba['roi_ratio'] > 0
        
        print(f"  Budget used: {cba['estimated_total_cost_units']:.1f}/20 units")
        print(f"  ROI ratio: {cba['roi_ratio']:.2f}x")
        print("  ✓ Constraint optimization test passed")
    
    async def test_dpo_integration(self):
        """Test DPO integration"""
        print("\n--- Test: DPO Integration ---")
        
        integration = DPOIntelligenceIntegration(
            output_dir=str(self.output_dir / 'dpo_integration')
        )
        
        request = DPORequest(
            request_id="TEST_001",
            user_request="Build a project management tool with Gantt charts",
            project_type="web_app",
            complexity_level="moderate",
            project_context={
                'features': ['task_management', 'gantt_charts', 'collaboration'],
                'team_size': 4
            },
            constraints={
                'timeline': 'normal',
                'budget': 'moderate'
            }
        )
        
        workflow = await integration.process_dpo_request(request)
        
        # Validate workflow structure
        assert workflow.workflow_id
        assert workflow.original_request.request_id == "TEST_001"
        assert len(workflow.workflow_phases) > 0
        assert len(workflow.agent_assignments) > 0
        assert len(workflow.quality_gates) > 0
        assert workflow.estimated_timeline
        
        # Check phases
        for phase in workflow.workflow_phases:
            assert phase['phase_id']
            assert phase['name']
            assert 'agents' in phase
            assert 'deliverables' in phase
        
        # Check quality gates
        for gate in workflow.quality_gates:
            assert gate['gate_id']
            assert gate['criteria']
        
        print(f"  Generated workflow: {workflow.workflow_id}")
        print(f"  Phases: {len(workflow.workflow_phases)}")
        print(f"  Total agents: {workflow.metadata['total_agents']}")
        print("  ✓ DPO integration test passed")
    
    async def test_error_handling(self):
        """Test error handling and edge cases"""
        print("\n--- Test: Error Handling ---")
        
        engine = IntelligenceReviewEngine(
            parallel_agents=2,
            output_dir=str(self.output_dir / 'error_handling')
        )
        
        # Test with empty request
        try:
            result = await engine.enhance_request(
                original_request="",
                project_context={}
            )
            # Should still work but with minimal enhancements
            assert result.enhanced_specification
            print("  ✓ Empty request handled gracefully")
        except Exception as e:
            raise AssertionError(f"Failed to handle empty request: {e}")
        
        # Test with invalid categories
        try:
            result = await engine.enhance_request(
                original_request="Test request",
                selected_categories=['invalid_category']
            )
            # Should handle gracefully
            print("  ✓ Invalid categories handled gracefully")
        except Exception as e:
            # This is expected and acceptable
            print(f"  ✓ Invalid categories rejected appropriately: {e}")
        
        # Test with extreme constraints
        advanced_engine = EnhancementIntelligenceEngine()
        result = await advanced_engine.enhance_with_intelligence(
            original_request="Build a complex system",
            constraints={
                'budget_units': 1,  # Impossible budget
                'max_enhancements': 1
            }
        )
        
        # Should still produce valid output
        assert result['metadata']['enhancements_selected'] <= 1
        print("  ✓ Extreme constraints handled")
        
        print("  ✓ Error handling test passed")
    
    async def test_performance(self):
        """Test performance characteristics"""
        print("\n--- Test: Performance ---")
        
        import time
        
        engine = IntelligenceReviewEngine(
            parallel_agents=5,
            output_dir=str(self.output_dir / 'performance')
        )
        
        # Measure enhancement time
        start_time = time.time()
        
        result = await engine.enhance_request(
            original_request="Build a complex enterprise application with multiple integrations",
            project_context={
                'scale': 'enterprise',
                'integrations': 20,
                'users': '100000'
            }
        )
        
        duration = time.time() - start_time
        
        # Performance assertions
        assert duration < 60, f"Enhancement took too long: {duration:.2f}s"
        assert result.metadata['duration_seconds'] < 60
        
        # Check parallelization worked
        total_enhancements = sum(
            len(items) for items in result.enhancement_analysis.values()
        )
        
        print(f"  Duration: {duration:.2f} seconds")
        print(f"  Enhancements generated: {total_enhancements}")
        print(f"  Throughput: {total_enhancements/duration:.1f} enhancements/second")
        print("  ✓ Performance test passed")
    
    def _print_summary(self):
        """Print test summary"""
        print("\n" + "="*80)
        print("TEST SUMMARY")
        print("="*80)
        
        passed = sum(1 for r in self.test_results if r['status'] == 'PASSED')
        failed = sum(1 for r in self.test_results if r['status'] == 'FAILED')
        total = len(self.test_results)
        
        print(f"\nTotal Tests: {total}")
        print(f"Passed: {passed} ({passed/total*100:.1f}%)")
        print(f"Failed: {failed} ({failed/total*100:.1f}%)")
        
        if failed > 0:
            print("\nFailed Tests:")
            for result in self.test_results:
                if result['status'] == 'FAILED':
                    print(f"  - {result['test']}: {result.get('error', 'Unknown error')}")
        
        print("\n" + "="*80)
    
    def _save_results(self):
        """Save test results to file"""
        results_path = self.output_dir / 'test_results.json'
        with open(results_path, 'w') as f:
            json.dump(self.test_results, f, indent=2)
        
        print(f"\nTest results saved to: {results_path}")


async def run_integration_test():
    """Run a comprehensive integration test"""
    print("\n" + "="*80)
    print("INTEGRATION TEST: Complete Enhancement Pipeline")
    print("="*80)
    
    # Create a realistic request
    request = """
    Build a modern SaaS platform for project management that includes:
    - Real-time collaboration features
    - Advanced reporting and analytics
    - Third-party integrations (Slack, GitHub, Jira)
    - Mobile applications (iOS and Android)
    - Enterprise security features
    - Multi-tenant architecture
    """
    
    context = {
        'target_market': 'Enterprise B2B',
        'expected_users': '50,000 across 500 organizations',
        'compliance': ['SOC2', 'GDPR', 'HIPAA'],
        'deployment': 'Multi-region AWS',
        'team_size': 12,
        'timeline_months': 9,
        'budget': '$2M'
    }
    
    constraints = {
        'budget_units': 150,
        'timeline': 'normal',
        'max_enhancements': 25,
        'team_expertise': ['typescript', 'react', 'python', 'aws', 'kubernetes']
    }
    
    goals = [
        'ensure_scalability',
        'maximize_security',
        'optimize_user_experience',
        'minimize_operational_cost'
    ]
    
    print("\nRequest Summary:")
    print("-" * 40)
    print(request[:200] + "...")
    print(f"\nContext: Enterprise B2B, 50K users, {context['team_size']} developers")
    print(f"Timeline: {context['timeline_months']} months")
    print(f"Budget: {context['budget']}")
    
    # Run enhancement
    print("\n" + "-"*40)
    print("Running Intelligence Review...")
    print("-"*40)
    
    engine = EnhancementIntelligenceEngine(
        parallel_agents=6,
        output_dir='output/integration_test'
    )
    
    result = await engine.enhance_with_intelligence(
        original_request=request,
        project_context=context,
        optimization_goals=goals,
        constraints=constraints
    )
    
    # Display results
    print("\n" + "="*80)
    print("ENHANCEMENT RESULTS")
    print("="*80)
    
    print(f"\n📊 Metrics:")
    print(f"  • Enhancements Identified: {result['metadata']['total_enhancements_identified']}")
    print(f"  • Enhancements Selected: {result['metadata']['enhancements_selected']}")
    print(f"  • Estimated Impact: {result['metadata']['estimated_impact_score']:.1%}")
    print(f"  • Processing Time: {result['metadata']['duration_seconds']:.1f}s")
    
    print(f"\n🚀 Quick Wins ({len(result['quick_wins'])} items):")
    for qw in result['quick_wins'][:5]:
        print(f"  • {qw['title']}")
    
    print(f"\n💡 Innovation Highlights ({len(result['innovation_highlights'])} items):")
    for inn in result['innovation_highlights'][:5]:
        print(f"  • {inn['title']}")
    
    print(f"\n📈 Cost-Benefit Analysis:")
    cba = result['cost_benefit_analysis']
    print(f"  • ROI Ratio: {cba['roi_ratio']:.2f}x")
    print(f"  • Payback Period: {cba['payback_period_estimate']}")
    print(f"  • Key Value Drivers:")
    for driver in cba['value_drivers']:
        print(f"    - {driver}")
    
    print(f"\n🗺️ Implementation Roadmap:")
    for phase in result['implementation_roadmap']['phases'][:3]:
        print(f"  • {phase['name']}")
        print(f"    Duration: {phase['estimated_duration']}")
        print(f"    Deliverables: {', '.join(phase['key_deliverables'][:2])}")
    
    print(f"\n⚠️ Risk Analysis:")
    risk = result['risk_analysis']
    print(f"  • Overall Risk Level: {risk['overall_risk_level']}")
    print(f"  • High Risk Items: {len(risk['high_risk_items'])}")
    print(f"  • Mitigation Strategies: {len(risk['mitigation_strategies'])}")
    
    print("\n" + "="*80)
    print("✓ Integration test completed successfully!")
    print("="*80)


async def main():
    """Main test runner"""
    print("\n🚀 Starting Intelligence Review Engine Tests")
    print("Timestamp:", datetime.now().isoformat())
    
    # Run unit tests
    test_suite = IntelligenceReviewEngineTests()
    await test_suite.run_all_tests()
    
    # Run integration test
    await run_integration_test()
    
    print("\n✅ All tests completed!")


if __name__ == "__main__":
    asyncio.run(main())