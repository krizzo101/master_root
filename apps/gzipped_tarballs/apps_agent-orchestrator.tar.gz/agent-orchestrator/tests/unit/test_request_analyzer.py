"""
Unit tests for Request Analyzer component of DPO system.
"""

import unittest
import json
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tests.base_test import DPOTestBase, AsyncDPOTestBase, TestDataGenerator, TestValidator


class TestRequestAnalyzer(AsyncDPOTestBase):
    """Test Request Analyzer classification logic."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.analyzer = self._create_mock_analyzer()
        self.test_data = TestDataGenerator()
        self.validator = TestValidator()
        
    def _create_mock_analyzer(self):
        """Create a mock request analyzer."""
        class MockRequestAnalyzer:
            def __init__(self):
                self.classification_rules = {
                    "api": ["REST", "API", "endpoint", "CRUD", "authentication"],
                    "fullstack": ["frontend", "backend", "database", "full-stack", "web application"],
                    "cli": ["CLI", "command line", "terminal", "console"],
                    "integration": ["integration", "connector", "sync", "webhook"]
                }
                
            async def classify_request(self, request):
                """Classify a request based on keywords."""
                description = request.get("description", "").lower()
                
                # Determine type based on keywords
                request_type = "unknown"
                confidence = 0.0
                
                for req_type, keywords in self.classification_rules.items():
                    matches = sum(1 for keyword in keywords if keyword.lower() in description)
                    match_confidence = matches / len(keywords)
                    
                    if match_confidence > confidence:
                        confidence = match_confidence
                        if req_type == "api":
                            request_type = "api_development"
                        elif req_type == "fullstack":
                            request_type = "fullstack_application"
                        elif req_type == "cli":
                            request_type = "cli_development"
                        elif req_type == "integration":
                            request_type = "integration_connector"
                
                # Determine complexity
                req_count = len(request.get("requirements", []))
                if req_count <= 3:
                    complexity = "simple"
                elif req_count <= 6:
                    complexity = "medium"
                else:
                    complexity = "complex"
                    
                return {
                    "type": request_type,
                    "confidence": min(confidence * 1.5, 1.0),  # Scale up confidence
                    "complexity": complexity,
                    "keywords_matched": self._get_matched_keywords(description)
                }
                
            def _get_matched_keywords(self, description):
                """Get keywords that matched."""
                matched = []
                for keywords in self.classification_rules.values():
                    for keyword in keywords:
                        if keyword.lower() in description.lower():
                            matched.append(keyword)
                return matched
                
        return MockRequestAnalyzer()
        
    def test_classify_api_request(self):
        """Test classification of API development request."""
        request = self.test_data.generate_request(
            request_type="api_development",
            description="Create a REST API with CRUD operations and authentication"
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["type"], "api_development")
        self.assertGreater(result["confidence"], 0.7)
        self.assertTrue(self.validator.validate_request_classification(result))
        
    def test_classify_fullstack_request(self):
        """Test classification of full-stack application request."""
        request = self.test_data.generate_request(
            request_type="fullstack_application",
            description="Build a web application with frontend, backend, and database"
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["type"], "fullstack_application")
        self.assertGreater(result["confidence"], 0.7)
        self.assertTrue(self.validator.validate_request_classification(result))
        
    def test_classify_cli_request(self):
        """Test classification of CLI tool request."""
        request = self.test_data.generate_request(
            request_type="cli_development",
            description="Develop a command line CLI tool for terminal operations"
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["type"], "cli_development")
        self.assertGreater(result["confidence"], 0.7)
        self.assertTrue(self.validator.validate_request_classification(result))
        
    def test_classify_integration_request(self):
        """Test classification of integration connector request."""
        request = self.test_data.generate_request(
            request_type="integration_connector",
            description="Create an integration connector with webhook sync capabilities"
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["type"], "integration_connector")
        self.assertGreater(result["confidence"], 0.5)
        self.assertTrue(self.validator.validate_request_classification(result))
        
    def test_classify_ambiguous_request(self):
        """Test classification of ambiguous request."""
        request = {
            "description": "Build something useful",
            "requirements": ["Make it work"],
            "technology_stack": []
        }
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["type"], "unknown")
        self.assertLess(result["confidence"], 0.3)
        
    def test_complexity_detection_simple(self):
        """Test detection of simple complexity."""
        request = self.test_data.generate_request(
            requirements=["Feature 1", "Feature 2"]
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["complexity"], "simple")
        
    def test_complexity_detection_medium(self):
        """Test detection of medium complexity."""
        request = self.test_data.generate_request(
            requirements=["Feature 1", "Feature 2", "Feature 3", "Feature 4", "Feature 5"]
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["complexity"], "medium")
        
    def test_complexity_detection_complex(self):
        """Test detection of complex request."""
        request = self.test_data.generate_request(
            requirements=[f"Feature {i}" for i in range(10)]
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertEqual(result["complexity"], "complex")
        
    def test_keyword_matching(self):
        """Test keyword matching functionality."""
        request = self.test_data.generate_request(
            description="Create a REST API with CRUD operations"
        )
        
        result = self.run_async(self.analyzer.classify_request(request))
        
        self.assertIn("keywords_matched", result)
        self.assertIn("REST", result["keywords_matched"])
        self.assertIn("API", result["keywords_matched"])
        self.assertIn("CRUD", result["keywords_matched"])
        
    def test_confidence_scoring(self):
        """Test confidence scoring mechanism."""
        # High confidence request
        high_conf_request = {
            "description": "Create a REST API with CRUD operations and authentication",
            "requirements": ["CRUD", "Auth", "Validation"]
        }
        
        high_result = self.run_async(self.analyzer.classify_request(high_conf_request))
        
        # Low confidence request
        low_conf_request = {
            "description": "Build something",
            "requirements": []
        }
        
        low_result = self.run_async(self.analyzer.classify_request(low_conf_request))
        
        self.assertGreater(high_result["confidence"], low_result["confidence"])
        self.assertGreater(high_result["confidence"], 0.7)
        self.assertLess(low_result["confidence"], 0.3)
        
    def test_edge_cases(self):
        """Test edge cases in request classification."""
        # Empty request
        empty_request = {}
        result = self.run_async(self.analyzer.classify_request(empty_request))
        self.assertEqual(result["type"], "unknown")
        
        # Null description
        null_desc_request = {
            "description": None,
            "requirements": ["Something"]
        }
        result = self.run_async(self.analyzer.classify_request(null_desc_request))
        self.assertEqual(result["type"], "unknown")
        
        # Very long description
        long_desc_request = {
            "description": " ".join(["word"] * 1000),
            "requirements": []
        }
        result = self.run_async(self.analyzer.classify_request(long_desc_request))
        self.assertIsNotNone(result["type"])
        
    def test_classification_accuracy(self):
        """Test overall classification accuracy."""
        test_cases = [
            ("Create a REST API", "api_development"),
            ("Build a web application", "fullstack_application"),
            ("Develop a CLI tool", "cli_development"),
            ("Create Salesforce integration", "integration_connector"),
            ("REST API with database", "api_development"),
            ("Frontend and backend system", "fullstack_application"),
            ("Command line interface", "cli_development"),
            ("Webhook connector", "integration_connector")
        ]
        
        correct = 0
        total = len(test_cases)
        
        for description, expected_type in test_cases:
            request = {"description": description, "requirements": []}
            result = self.run_async(self.analyzer.classify_request(request))
            
            if result["type"] == expected_type:
                correct += 1
            else:
                self.logger.warning(
                    f"Misclassified: '{description}' as {result['type']} "
                    f"(expected {expected_type})"
                )
                
        accuracy = (correct / total) * 100
        self.assertGreater(accuracy, 75, f"Classification accuracy {accuracy}% below threshold")
        
        
class TestRequestValidation(DPOTestBase):
    """Test request validation logic."""
    
    def test_validate_required_fields(self):
        """Test validation of required fields."""
        # Valid request
        valid_request = {
            "type": "api_development",
            "description": "Create an API",
            "requirements": ["Feature 1"],
            "technology_stack": ["Python"]
        }
        
        self.assertTrue(self._validate_request(valid_request))
        
        # Missing description
        invalid_request = {
            "type": "api_development",
            "requirements": ["Feature 1"]
        }
        
        self.assertFalse(self._validate_request(invalid_request))
        
    def test_validate_request_types(self):
        """Test validation of request types."""
        valid_types = [
            "api_development",
            "fullstack_application",
            "cli_development",
            "integration_connector"
        ]
        
        for req_type in valid_types:
            request = {"type": req_type, "description": "Test"}
            self.assertTrue(self._validate_request_type(request))
            
        # Invalid type
        invalid_request = {"type": "invalid_type", "description": "Test"}
        self.assertFalse(self._validate_request_type(invalid_request))
        
    def test_validate_requirements_format(self):
        """Test validation of requirements format."""
        # Valid requirements
        valid_request = {
            "requirements": ["Req 1", "Req 2", "Req 3"]
        }
        self.assertTrue(self._validate_requirements(valid_request))
        
        # Empty requirements
        empty_request = {
            "requirements": []
        }
        self.assertFalse(self._validate_requirements(empty_request))
        
        # Invalid format
        invalid_request = {
            "requirements": "Not a list"
        }
        self.assertFalse(self._validate_requirements(invalid_request))
        
    def _validate_request(self, request):
        """Validate complete request."""
        required_fields = ["description"]
        return all(field in request for field in required_fields)
        
    def _validate_request_type(self, request):
        """Validate request type."""
        valid_types = [
            "api_development",
            "fullstack_application",
            "cli_development",
            "integration_connector"
        ]
        return request.get("type") in valid_types
        
    def _validate_requirements(self, request):
        """Validate requirements format."""
        requirements = request.get("requirements")
        return isinstance(requirements, list) and len(requirements) > 0


if __name__ == "__main__":
    unittest.main()