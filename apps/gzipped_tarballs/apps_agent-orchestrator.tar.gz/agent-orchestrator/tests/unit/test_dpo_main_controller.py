#!/usr/bin/env python3
"""
Unit Tests for DPO Main Controller

Tests the core orchestration logic, request processing pipeline,
and component coordination functionality.
"""

import asyncio
import json
import pytest
import tempfile
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from dataclasses import asdict

import sys
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.dpo_main_controller import (
    DevelopmentProcessOrchestrator,
    DPOConfiguration,
    RequestType,
    RequestAnalysis,
    DPOWorkflowExecution,
    ProcessingPhase
)
from src.dpo_intelligence_integration import DPORequest


class TestDPOConfiguration:
    """Test DPO configuration management"""
    
    def test_default_configuration(self):
        """Test default configuration values"""
        config = DPOConfiguration()
        
        assert config.output_base_dir == "output/dpo_workflows"
        assert config.max_parallel_agents == 10
        assert config.enable_websocket is True
        assert config.websocket_port == 8765
        assert config.enable_intelligence is True
        assert config.log_level == "INFO"
    
    def test_configuration_serialization(self):
        """Test configuration save/load functionality"""
        config = DPOConfiguration(
            max_parallel_agents=15,
            websocket_port=9000,
            enable_intelligence=False
        )
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            config.save(f.name)
            loaded_config = DPOConfiguration.from_file(f.name)
        
        assert loaded_config.max_parallel_agents == 15
        assert loaded_config.websocket_port == 9000
        assert loaded_config.enable_intelligence is False
    
    def test_configuration_validation(self):
        """Test configuration validation"""
        # Test invalid values
        with pytest.raises(ValueError):
            DPOConfiguration(max_parallel_agents=0)
        
        with pytest.raises(ValueError):
            DPOConfiguration(websocket_port=-1)
        
        with pytest.raises(ValueError):
            DPOConfiguration(checkpoint_interval=0)


class TestRequestAnalysis:
    """Test request analysis functionality"""
    
    def test_request_analysis_creation(self):
        """Test creation of request analysis objects"""
        analysis = RequestAnalysis(
            request_type=RequestType.BUILD,
            project_type="web_application",
            complexity="medium",
            key_requirements=["authentication", "REST API"],
            suggested_technologies=["React", "Node.js"],
            risk_factors=["complex authentication"],
            estimated_effort="2-3 weeks",
            confidence_score=0.85
        )
        
        assert analysis.request_type == RequestType.BUILD
        assert analysis.project_type == "web_application"
        assert analysis.complexity == "medium"
        assert len(analysis.key_requirements) == 2
        assert analysis.confidence_score == 0.85
    
    def test_request_analysis_serialization(self):
        """Test request analysis serialization"""
        analysis = RequestAnalysis(
            request_type=RequestType.ENHANCE,
            project_type="api",
            complexity="high",
            key_requirements=["performance"],
            suggested_technologies=["Redis"],
            risk_factors=["data migration"],
            estimated_effort="1 week",
            confidence_score=0.92
        )
        
        serialized = asdict(analysis)
        assert serialized['request_type'] == RequestType.ENHANCE
        assert serialized['confidence_score'] == 0.92


class TestDevelopmentProcessOrchestrator:
    """Test main DPO orchestrator functionality"""
    
    @pytest.fixture
    def dpo_config(self):
        """Create test configuration"""
        return DPOConfiguration(
            output_base_dir="test_output",
            max_parallel_agents=5,
            enable_websocket=False,
            enable_intelligence=True
        )
    
    @pytest.fixture
    def mock_components(self):
        """Create mock DPO components"""
        mocks = {
            'intelligence_engine': AsyncMock(),
            'template_system': Mock(),
            'context_injection': AsyncMock(),
            'orchestrator_integration': AsyncMock(),
        }
        return mocks
    
    @pytest.fixture
    async def dpo_orchestrator(self, dpo_config, mock_components):
        """Create DPO orchestrator with mocked components"""
        with patch.multiple(
            'src.dpo_main_controller',
            EnhancementIntelligenceEngine=Mock(return_value=mock_components['intelligence_engine']),
            SDLCTemplateSystem=Mock(return_value=mock_components['template_system']),
            get_context_system=Mock(return_value=mock_components['context_injection']),
            DPOOrchestrator=Mock(return_value=mock_components['orchestrator_integration'])
        ):
            dpo = DevelopmentProcessOrchestrator(dpo_config)
            await dpo.initialize()
            return dpo, mock_components
    
    @pytest.mark.asyncio
    async def test_initialization(self, dpo_config):
        """Test DPO initialization"""
        with patch.multiple(
            'src.dpo_main_controller',
            EnhancementIntelligenceEngine=Mock(),
            SDLCTemplateSystem=Mock(),
            get_context_system=Mock(),
            DPOOrchestrator=Mock()
        ):
            dpo = DevelopmentProcessOrchestrator(dpo_config)
            await dpo.initialize()
            
            assert dpo.is_initialized is True
            assert dpo.config == dpo_config
    
    @pytest.mark.asyncio
    async def test_request_analysis(self, dpo_orchestrator):
        """Test request analysis functionality"""
        dpo, mocks = dpo_orchestrator
        
        request = "Build a REST API for user management with authentication"
        context = {"framework": "FastAPI", "database": "PostgreSQL"}
        
        analysis = await dpo._analyze_request(request, context)
        
        assert isinstance(analysis, RequestAnalysis)
        assert analysis.request_type in [RequestType.BUILD, RequestType.INTEGRATE]
        assert analysis.confidence_score >= 0.0
        assert analysis.confidence_score <= 1.0
        assert len(analysis.key_requirements) > 0
    
    @pytest.mark.asyncio
    async def test_intelligence_enhancement(self, dpo_orchestrator):
        """Test intelligence enhancement integration"""
        dpo, mocks = dpo_orchestrator
        
        # Setup mock intelligence engine
        mock_enhancement = {
            "enhancements": [
                {
                    "category": "PERFORMANCE",
                    "title": "Add caching layer",
                    "description": "Implement Redis caching",
                    "impact": "high",
                    "effort": "medium"
                }
            ],
            "synthesis": {
                "priorities": ["performance", "scalability"],
                "recommendations": ["Use Redis for caching"]
            }
        }
        mocks['intelligence_engine'].enhance_request.return_value = mock_enhancement
        
        request_data = DPORequest(
            original_request="Build an API",
            context={},
            request_analysis=RequestAnalysis(
                request_type=RequestType.BUILD,
                project_type="api",
                complexity="medium",
                key_requirements=["REST API"],
                suggested_technologies=["FastAPI"],
                risk_factors=[],
                estimated_effort="1 week",
                confidence_score=0.8
            )
        )
        
        enhanced = await dpo._enhance_with_intelligence(request_data)
        
        mocks['intelligence_engine'].enhance_request.assert_called_once()
        assert enhanced is not None
        assert 'enhancements' in enhanced
    
    @pytest.mark.asyncio
    async def test_workflow_generation(self, dpo_orchestrator):
        """Test SDLC workflow generation"""
        dpo, mocks = dpo_orchestrator
        
        # Setup mock template system
        mock_workflow = {
            "workflow_id": "test_workflow_123",
            "phases": [
                {
                    "phase_id": "discovery",
                    "agents": [{"role": "analyst", "task": "requirements"}]
                },
                {
                    "phase_id": "implementation",
                    "agents": [{"role": "developer", "task": "coding"}]
                }
            ],
            "metadata": {"total_agents": 2, "estimated_duration": "1 week"}
        }
        mocks['template_system'].generate_workflow.return_value = mock_workflow
        
        enhanced_request = {
            "original_request": "Build an API",
            "analysis": RequestAnalysis(
                request_type=RequestType.BUILD,
                project_type="api",
                complexity="medium",
                key_requirements=["REST"],
                suggested_technologies=["FastAPI"],
                risk_factors=[],
                estimated_effort="1 week",
                confidence_score=0.8
            ),
            "enhancements": []
        }
        
        workflow = await dpo._generate_workflow(enhanced_request)
        
        mocks['template_system'].generate_workflow.assert_called_once()
        assert workflow is not None
        assert 'workflow_id' in workflow
        assert 'phases' in workflow
        assert len(workflow['phases']) == 2
    
    @pytest.mark.asyncio
    async def test_context_injection(self, dpo_orchestrator):
        """Test context injection system"""
        dpo, mocks = dpo_orchestrator
        
        # Setup mock context injection
        mock_context = {
            "agent_contexts": {
                "analyst": {"relevant_patterns": ["API design patterns"]},
                "developer": {"code_examples": ["FastAPI examples"]}
            }
        }
        mocks['context_injection'].prepare_contexts.return_value = mock_context
        
        workflow = {
            "phases": [
                {
                    "agents": [
                        {"role": "analyst", "task": "analysis"},
                        {"role": "developer", "task": "coding"}
                    ]
                }
            ]
        }
        
        enriched_workflow = await dpo._inject_context(workflow, {"framework": "FastAPI"})
        
        mocks['context_injection'].prepare_contexts.assert_called_once()
        assert enriched_workflow is not None
    
    @pytest.mark.asyncio
    async def test_orchestrator_submission(self, dpo_orchestrator):
        """Test workflow submission to orchestrator"""
        dpo, mocks = dpo_orchestrator
        
        # Setup mock orchestrator
        mock_submission_result = {
            "workflow_id": "submitted_123",
            "status": "submitted",
            "output_dir": "/path/to/output"
        }
        mocks['orchestrator_integration'].submit_workflow.return_value = mock_submission_result
        
        workflow = {
            "workflow_id": "test_123",
            "phases": [],
            "metadata": {}
        }
        
        result = await dpo._submit_to_orchestrator(workflow)
        
        mocks['orchestrator_integration'].submit_workflow.assert_called_once_with(workflow)
        assert result == mock_submission_result
        assert result['status'] == "submitted"
    
    @pytest.mark.asyncio
    async def test_end_to_end_processing(self, dpo_orchestrator):
        """Test complete end-to-end request processing"""
        dpo, mocks = dpo_orchestrator
        
        # Setup all mock components
        mocks['intelligence_engine'].enhance_request.return_value = {
            "enhancements": [],
            "synthesis": {}
        }
        mocks['template_system'].generate_workflow.return_value = {
            "workflow_id": "e2e_test_123",
            "phases": [{"phase_id": "test", "agents": []}]
        }
        mocks['context_injection'].prepare_contexts.return_value = {"agent_contexts": {}}
        mocks['orchestrator_integration'].submit_workflow.return_value = {
            "workflow_id": "submitted_e2e_123",
            "status": "submitted",
            "output_dir": "/test/output"
        }
        
        request = "Build a simple REST API for user management"
        context = {"framework": "FastAPI", "database": "SQLite"}
        
        result = await dpo.process_request(request, context)
        
        # Verify all components were called
        mocks['intelligence_engine'].enhance_request.assert_called_once()
        mocks['template_system'].generate_workflow.assert_called_once()
        mocks['context_injection'].prepare_contexts.assert_called_once()
        mocks['orchestrator_integration'].submit_workflow.assert_called_once()
        
        # Verify result structure
        assert isinstance(result, DPOWorkflowExecution)
        assert result.workflow_id is not None
        assert result.status in ["submitted", "running", "completed"]
        assert result.phases[ProcessingPhase.ANALYSIS] is True
        assert result.phases[ProcessingPhase.INTELLIGENCE_REVIEW] is True
        assert result.phases[ProcessingPhase.WORKFLOW_GENERATION] is True
        assert result.phases[ProcessingPhase.CONTEXT_INJECTION] is True
        assert result.phases[ProcessingPhase.ORCHESTRATOR_SUBMISSION] is True
    
    @pytest.mark.asyncio
    async def test_error_handling(self, dpo_orchestrator):
        """Test error handling in request processing"""
        dpo, mocks = dpo_orchestrator
        
        # Simulate intelligence engine failure
        mocks['intelligence_engine'].enhance_request.side_effect = Exception("Intelligence engine failed")
        
        request = "Build an API"
        context = {}
        
        with pytest.raises(Exception) as exc_info:
            await dpo.process_request(request, context)
        
        assert "Intelligence engine failed" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_status_monitoring(self, dpo_orchestrator):
        """Test workflow status monitoring"""
        dpo, mocks = dpo_orchestrator
        
        workflow_id = "status_test_123"
        
        # Setup mock status response
        mock_status = {
            "workflow_id": workflow_id,
            "status": "running",
            "progress": 0.6,
            "current_phase": "implementation",
            "agents": {
                "completed": 3,
                "running": 2,
                "pending": 1
            }
        }
        mocks['orchestrator_integration'].get_status.return_value = mock_status
        
        status = await dpo.get_workflow_status(workflow_id)
        
        mocks['orchestrator_integration'].get_status.assert_called_once_with(workflow_id)
        assert status['workflow_id'] == workflow_id
        assert status['status'] == "running"
        assert status['progress'] == 0.6
    
    @pytest.mark.asyncio
    async def test_workflow_cancellation(self, dpo_orchestrator):
        """Test workflow cancellation"""
        dpo, mocks = dpo_orchestrator
        
        workflow_id = "cancel_test_123"
        
        # Setup mock cancellation response
        mocks['orchestrator_integration'].cancel_workflow.return_value = {
            "workflow_id": workflow_id,
            "status": "cancelled",
            "message": "Workflow cancelled successfully"
        }
        
        result = await dpo.cancel_workflow(workflow_id)
        
        mocks['orchestrator_integration'].cancel_workflow.assert_called_once_with(workflow_id)
        assert result['status'] == "cancelled"
        assert result['workflow_id'] == workflow_id
    
    @pytest.mark.asyncio
    async def test_results_collection(self, dpo_orchestrator):
        """Test workflow results collection"""
        dpo, mocks = dpo_orchestrator
        
        workflow_id = "results_test_123"
        
        # Setup mock results
        mock_results = {
            "workflow_id": workflow_id,
            "status": "completed",
            "outputs": {
                "deliverables": ["API specification", "Implementation"],
                "metrics": {"duration": "2 hours", "agents_used": 5}
            },
            "artifacts": [
                {"type": "documentation", "path": "/docs/api.md"},
                {"type": "code", "path": "/src/api.py"}
            ]
        }
        mocks['orchestrator_integration'].get_results.return_value = mock_results
        
        results = await dpo.get_workflow_results(workflow_id)
        
        mocks['orchestrator_integration'].get_results.assert_called_once_with(workflow_id)
        assert results['status'] == "completed"
        assert len(results['artifacts']) == 2
        assert 'deliverables' in results['outputs']


class TestRequestTypeClassification:
    """Test request type classification logic"""
    
    def test_build_request_classification(self):
        """Test BUILD request classification"""
        requests = [
            "Build a REST API for user management",
            "Create a web application for inventory management",
            "Develop a CLI tool for file processing"
        ]
        
        for request in requests:
            # This would be part of the actual classification logic
            assert "build" in request.lower() or "create" in request.lower() or "develop" in request.lower()
    
    def test_enhance_request_classification(self):
        """Test ENHANCE request classification"""
        requests = [
            "Add caching to the existing API",
            "Enhance the UI with better responsiveness",
            "Improve the search functionality"
        ]
        
        for request in requests:
            assert "add" in request.lower() or "enhance" in request.lower() or "improve" in request.lower()
    
    def test_fix_request_classification(self):
        """Test FIX request classification"""
        requests = [
            "Fix the authentication bug",
            "Resolve the database connection issue",
            "Debug the performance problem"
        ]
        
        for request in requests:
            assert any(word in request.lower() for word in ["fix", "resolve", "debug", "bug", "issue", "problem"])


if __name__ == "__main__":
    pytest.main([__file__])