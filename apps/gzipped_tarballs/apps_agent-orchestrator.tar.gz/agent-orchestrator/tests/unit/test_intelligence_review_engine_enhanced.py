#!/usr/bin/env python3
"""
Unit Tests for Enhanced Intelligence Review Engine

Tests the sophisticated enhancement intelligence including multi-phase
enhancement strategies, cross-category synthesis, and impact scoring.
"""

import asyncio
import json
import pytest
from unittest.mock import Mock, AsyncMock, patch
from pathlib import Path
from dataclasses import asdict

import sys
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.intelligence_review_engine_enhanced import (
    EnhancementIntelligenceEngine,
    EnhancementScore,
    EnhancementDependency,
    EnhancementSynthesis,
    EnhancementPhase
)
from src.intelligence_review_engine import EnhancementResult, EnhancementCategory
from src.dpo_intelligence_integration import DPORequest


class TestEnhancementScore:
    """Test enhancement scoring model"""
    
    def test_enhancement_score_creation(self):
        """Test creation of enhancement score objects"""
        score = EnhancementScore(
            impact_score=0.8,
            effort_score=0.3,  # Lower is better
            innovation_score=0.9,
            risk_score=0.2,    # Lower is better
            dependency_score=0.7
        )
        
        assert score.impact_score == 0.8
        assert score.effort_score == 0.3
        assert score.innovation_score == 0.9
        assert score.risk_score == 0.2
        assert score.dependency_score == 0.7
    
    def test_composite_score_calculation(self):
        """Test composite score calculation algorithm"""
        score = EnhancementScore(
            impact_score=0.8,
            effort_score=0.2,  # Low effort (good)
            innovation_score=0.9,
            risk_score=0.1,    # Low risk (good)
            dependency_score=0.6
        )
        
        composite = score.composite_score
        
        # High impact, low effort, high innovation, low risk should give high score
        assert composite > 0.7
        assert 0.0 <= composite <= 1.0
    
    def test_score_comparison(self):
        """Test scoring for prioritization"""
        high_priority = EnhancementScore(
            impact_score=0.9,
            effort_score=0.2,
            innovation_score=0.8,
            risk_score=0.1,
            dependency_score=0.8
        )
        
        low_priority = EnhancementScore(
            impact_score=0.3,
            effort_score=0.8,
            innovation_score=0.2,
            risk_score=0.7,
            dependency_score=0.1
        )
        
        assert high_priority.composite_score > low_priority.composite_score


class TestEnhancementDependency:
    """Test enhancement dependency analysis"""
    
    def test_dependency_creation(self):
        """Test creation of enhancement dependencies"""
        dep = EnhancementDependency(
            enhancement_id="perf_001",
            depends_on=["arch_001", "db_001"],
            dependency_type="requires",
            strength=0.8,
            rationale="Performance optimization requires architectural changes"
        )
        
        assert dep.enhancement_id == "perf_001"
        assert len(dep.depends_on) == 2
        assert dep.dependency_type == "requires"
        assert dep.strength == 0.8
    
    def test_dependency_validation(self):
        """Test dependency validation"""
        with pytest.raises(ValueError):
            EnhancementDependency(
                enhancement_id="test",
                depends_on=[],
                dependency_type="invalid_type",
                strength=1.5  # Invalid strength
            )


class TestEnhancementIntelligenceEngine:
    """Test enhanced intelligence review engine"""
    
    @pytest.fixture
    def mock_orchestrator(self):
        """Create mock orchestrator"""
        mock = AsyncMock()
        mock.create_and_run_task.return_value = {
            "status": "completed",
            "outputs": {
                "enhancements": [
                    {
                        "category": "PERFORMANCE",
                        "title": "Implement caching layer",
                        "description": "Add Redis caching for frequent queries",
                        "impact": "high",
                        "effort": "medium",
                        "technologies": ["Redis"],
                        "rationale": "Reduce database load and improve response times"
                    }
                ]
            }
        }
        return mock
    
    @pytest.fixture
    async def intelligence_engine(self, mock_orchestrator):
        """Create intelligence engine with mocked orchestrator"""
        with patch('src.intelligence_review_engine_enhanced.GenericOrchestrator', return_value=mock_orchestrator):
            engine = EnhancementIntelligenceEngine(
                orchestrator_config={
                    "max_parallel_agents": 5,
                    "output_base_dir": "test_output"
                }
            )
            await engine.initialize()
            return engine, mock_orchestrator
    
    @pytest.mark.asyncio
    async def test_engine_initialization(self):
        """Test intelligence engine initialization"""
        mock_orchestrator = AsyncMock()
        
        with patch('src.intelligence_review_engine_enhanced.GenericOrchestrator', return_value=mock_orchestrator):
            engine = EnhancementIntelligenceEngine()
            await engine.initialize()
            
            assert engine.is_initialized is True
            assert engine.orchestrator is not None
    
    @pytest.mark.asyncio
    async def test_enhancement_generation(self, intelligence_engine):
        """Test enhancement generation for different categories"""
        engine, mock_orchestrator = intelligence_engine
        
        request_data = DPORequest(
            original_request="Build a user management API",
            context={"framework": "FastAPI", "database": "PostgreSQL"},
            request_analysis=Mock()
        )
        
        enhancements = await engine._generate_enhancements(request_data)
        
        # Verify orchestrator was called for enhancement generation
        mock_orchestrator.create_and_run_task.assert_called()
        assert len(enhancements) > 0
        
        # Verify enhancement structure
        enhancement = enhancements[0]
        assert 'category' in enhancement
        assert 'title' in enhancement
        assert 'description' in enhancement
        assert 'impact' in enhancement
    
    @pytest.mark.asyncio
    async def test_enhancement_scoring(self, intelligence_engine):
        """Test enhancement scoring algorithm"""
        engine, _ = intelligence_engine
        
        enhancement = {
            "category": "PERFORMANCE",
            "title": "Add caching",
            "description": "Implement Redis caching",
            "impact": "high",
            "effort": "medium",
            "innovation_level": "standard",
            "risk_level": "low",
            "dependencies": []
        }
        
        score = engine._calculate_enhancement_score(enhancement, {})
        
        assert isinstance(score, EnhancementScore)
        assert 0.0 <= score.impact_score <= 1.0
        assert 0.0 <= score.effort_score <= 1.0
        assert 0.0 <= score.innovation_score <= 1.0
        assert 0.0 <= score.risk_score <= 1.0
        assert 0.0 <= score.dependency_score <= 1.0
    
    def test_impact_score_mapping(self, intelligence_engine):
        """Test impact score mapping from textual descriptions"""
        engine, _ = intelligence_engine
        
        high_impact = {"impact": "high"}
        medium_impact = {"impact": "medium"}
        low_impact = {"impact": "low"}
        
        high_score = engine._map_impact_score(high_impact)
        medium_score = engine._map_impact_score(medium_impact)
        low_score = engine._map_impact_score(low_impact)
        
        assert high_score > medium_score > low_score
        assert all(0.0 <= score <= 1.0 for score in [high_score, medium_score, low_score])
    
    def test_effort_score_mapping(self, intelligence_engine):
        """Test effort score mapping (lower is better)"""
        engine, _ = intelligence_engine
        
        low_effort = {"effort": "low"}
        medium_effort = {"effort": "medium"}
        high_effort = {"effort": "high"}
        
        low_score = engine._map_effort_score(low_effort)
        medium_score = engine._map_effort_score(medium_effort)
        high_score = engine._map_effort_score(high_effort)
        
        # Lower effort should have lower score (better)
        assert low_score < medium_score < high_score
        assert all(0.0 <= score <= 1.0 for score in [low_score, medium_score, high_score])
    
    @pytest.mark.asyncio
    async def test_dependency_analysis(self, intelligence_engine):
        """Test enhancement dependency analysis"""
        engine, _ = intelligence_engine
        
        enhancements = [
            {
                "id": "perf_001",
                "category": "PERFORMANCE",
                "title": "Add caching",
                "technologies": ["Redis"]
            },
            {
                "id": "arch_001",
                "category": "ARCHITECTURE",
                "title": "Microservices architecture",
                "technologies": ["Docker", "Kubernetes"]
            },
            {
                "id": "perf_002",
                "category": "PERFORMANCE",
                "title": "Database optimization",
                "technologies": ["PostgreSQL"]
            }
        ]
        
        dependencies = engine._analyze_dependencies(enhancements)
        
        assert isinstance(dependencies, list)
        if dependencies:  # May be empty for simple test case
            dep = dependencies[0]
            assert isinstance(dep, EnhancementDependency)
            assert dep.enhancement_id in [e["id"] for e in enhancements]
    
    @pytest.mark.asyncio
    async def test_enhancement_synthesis(self, intelligence_engine):
        """Test multi-phase enhancement synthesis"""
        engine, _ = intelligence_engine
        
        scored_enhancements = [
            {
                "id": "perf_001",
                "category": "PERFORMANCE",
                "title": "Add caching",
                "score": EnhancementScore(0.8, 0.3, 0.6, 0.2, 0.5),
                "phase": EnhancementPhase.FOUNDATION
            },
            {
                "id": "innov_001",
                "category": "INNOVATION",
                "title": "AI-powered features",
                "score": EnhancementScore(0.9, 0.8, 0.95, 0.6, 0.3),
                "phase": EnhancementPhase.ADVANCED
            }
        ]
        
        dependencies = []
        
        synthesis = engine._synthesize_enhancements(scored_enhancements, dependencies)
        
        assert isinstance(synthesis, EnhancementSynthesis)
        assert len(synthesis.priority_order) <= len(scored_enhancements)
        assert len(synthesis.phase_roadmap) > 0
        assert synthesis.implementation_strategy is not None
    
    @pytest.mark.asyncio
    async def test_category_specific_enhancement(self, intelligence_engine):
        """Test category-specific enhancement generation"""
        engine, mock_orchestrator = intelligence_engine
        
        # Test performance enhancements
        perf_context = {
            "category": "PERFORMANCE",
            "current_stack": ["Python", "PostgreSQL"],
            "performance_requirements": ["high_throughput", "low_latency"]
        }
        
        perf_enhancements = await engine._generate_category_enhancements(
            "PERFORMANCE", 
            perf_context
        )
        
        mock_orchestrator.create_and_run_task.assert_called()
        assert len(perf_enhancements) > 0
    
    @pytest.mark.asyncio
    async def test_cross_category_synthesis(self, intelligence_engine):
        """Test cross-category enhancement synthesis"""
        engine, _ = intelligence_engine
        
        enhancements_by_category = {
            "PERFORMANCE": [
                {"id": "perf_001", "title": "Caching", "impact": "high"}
            ],
            "ARCHITECTURE": [
                {"id": "arch_001", "title": "Microservices", "impact": "high"}
            ],
            "INNOVATION": [
                {"id": "innov_001", "title": "AI features", "impact": "medium"}
            ]
        }
        
        synthesis = engine._cross_category_synthesis(enhancements_by_category)
        
        assert 'synergies' in synthesis
        assert 'conflicts' in synthesis
        assert 'recommendations' in synthesis
    
    @pytest.mark.asyncio
    async def test_complete_enhancement_workflow(self, intelligence_engine):
        """Test complete enhancement workflow"""
        engine, mock_orchestrator = intelligence_engine
        
        request_data = DPORequest(
            original_request="Build a scalable e-commerce platform",
            context={
                "framework": "React",
                "backend": "Node.js",
                "database": "MongoDB",
                "scale": "high"
            },
            request_analysis=Mock()
        )
        
        result = await engine.enhance_request(request_data)
        
        # Verify complete enhancement structure
        assert 'enhancements' in result
        assert 'synthesis' in result
        assert 'metadata' in result
        
        # Verify enhancements have proper structure
        if result['enhancements']:
            enhancement = result['enhancements'][0]
            assert 'id' in enhancement
            assert 'category' in enhancement
            assert 'score' in enhancement
            assert 'phase' in enhancement
        
        # Verify synthesis structure
        synthesis = result['synthesis']
        assert 'priority_order' in synthesis
        assert 'phase_roadmap' in synthesis
        assert 'implementation_strategy' in synthesis
    
    def test_enhancement_prioritization(self, intelligence_engine):
        """Test enhancement prioritization algorithm"""
        engine, _ = intelligence_engine
        
        enhancements = [
            {
                "id": "low_priority",
                "score": EnhancementScore(0.3, 0.8, 0.2, 0.7, 0.1)
            },
            {
                "id": "high_priority",
                "score": EnhancementScore(0.9, 0.2, 0.8, 0.1, 0.8)
            },
            {
                "id": "medium_priority",
                "score": EnhancementScore(0.6, 0.5, 0.6, 0.4, 0.5)
            }
        ]
        
        prioritized = engine._prioritize_enhancements(enhancements)
        
        assert len(prioritized) == 3
        assert prioritized[0]["id"] == "high_priority"
        assert prioritized[-1]["id"] == "low_priority"
    
    def test_phase_assignment(self, intelligence_engine):
        """Test enhancement phase assignment"""
        engine, _ = intelligence_engine
        
        enhancement = {
            "category": "PERFORMANCE",
            "impact": "high",
            "dependencies": [],
            "complexity": "low"
        }
        
        phase = engine._assign_phase(enhancement)
        
        assert phase in [
            EnhancementPhase.FOUNDATION,
            EnhancementPhase.CORE,
            EnhancementPhase.ADVANCED,
            EnhancementPhase.INNOVATION
        ]
    
    @pytest.mark.asyncio
    async def test_error_handling(self, intelligence_engine):
        """Test error handling in enhancement generation"""
        engine, mock_orchestrator = intelligence_engine
        
        # Simulate orchestrator failure
        mock_orchestrator.create_and_run_task.side_effect = Exception("Orchestrator failed")
        
        request_data = DPORequest(
            original_request="Test request",
            context={},
            request_analysis=Mock()
        )
        
        with pytest.raises(Exception) as exc_info:
            await engine.enhance_request(request_data)
        
        assert "Orchestrator failed" in str(exc_info.value)
    
    def test_enhancement_validation(self, intelligence_engine):
        """Test enhancement result validation"""
        engine, _ = intelligence_engine
        
        valid_enhancement = {
            "id": "test_001",
            "category": "PERFORMANCE",
            "title": "Add caching",
            "description": "Implement Redis caching",
            "impact": "high",
            "effort": "medium"
        }
        
        invalid_enhancement = {
            "id": "test_002",
            # Missing required fields
        }
        
        assert engine._validate_enhancement(valid_enhancement) is True
        assert engine._validate_enhancement(invalid_enhancement) is False


if __name__ == "__main__":
    pytest.main([__file__])