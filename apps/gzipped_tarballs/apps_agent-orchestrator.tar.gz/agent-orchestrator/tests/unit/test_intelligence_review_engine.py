"""
Unit tests for Intelligence Review Engine component of DPO system.
"""

import unittest
import json
from unittest.mock import Mock, patch, MagicMock
import sys
import os
from typing import Dict, Any, List

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tests.base_test import DPOTestBase, AsyncDPOTestBase, TestDataGenerator, TestValidator


class TestIntelligenceReviewEngine(AsyncDPOTestBase):
    """Test Intelligence Review Engine enhancement synthesis."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.engine = self._create_mock_engine()
        self.test_data = TestDataGenerator()
        self.validator = TestValidator()
        
    def _create_mock_engine(self):
        """Create a mock intelligence review engine."""
        class MockIntelligenceEngine:
            def __init__(self):
                self.enhancement_patterns = {
                    "performance": [
                        "caching", "optimization", "async", "parallel", "indexing"
                    ],
                    "security": [
                        "authentication", "authorization", "encryption", "validation", "audit"
                    ],
                    "scalability": [
                        "load balancing", "horizontal scaling", "microservices", "queue", "cluster"
                    ],
                    "maintainability": [
                        "testing", "documentation", "logging", "monitoring", "refactoring"
                    ],
                    "innovation": [
                        "AI", "machine learning", "blockchain", "IoT", "edge computing"
                    ]
                }
                
            async def analyze_for_enhancements(self, request: Dict[str, Any]) -> List[Dict[str, Any]]:
                """Analyze request and suggest enhancements."""
                description = request.get("description", "").lower()
                requirements = request.get("requirements", [])
                tech_stack = request.get("technology_stack", [])
                
                enhancements = []
                
                # Check for performance opportunities
                if any(keyword in description for keyword in ["api", "web", "service"]):
                    enhancements.append(self._create_enhancement(
                        "performance",
                        "Implement caching strategy",
                        "high",
                        ["Redis caching", "CDN integration", "Query optimization"]
                    ))
                    
                # Check for security needs
                if any(keyword in description for keyword in ["user", "data", "payment"]):
                    enhancements.append(self._create_enhancement(
                        "security",
                        "Enhanced authentication and authorization",
                        "critical",
                        ["JWT tokens", "OAuth2", "Rate limiting", "Input validation"]
                    ))
                    
                # Check for scalability requirements
                if len(requirements) > 5 or "enterprise" in description:
                    enhancements.append(self._create_enhancement(
                        "scalability",
                        "Implement horizontal scaling architecture",
                        "high",
                        ["Microservices", "Load balancing", "Container orchestration"]
                    ))
                    
                # Check for maintainability
                if len(tech_stack) > 3:
                    enhancements.append(self._create_enhancement(
                        "maintainability",
                        "Comprehensive testing and monitoring",
                        "medium",
                        ["Unit tests", "Integration tests", "Monitoring dashboard"]
                    ))
                    
                # Check for innovation opportunities
                if any(keyword in description for keyword in ["modern", "cutting-edge", "advanced"]):
                    enhancements.append(self._create_enhancement(
                        "innovation",
                        "Integrate AI-powered features",
                        "medium",
                        ["ML predictions", "NLP processing", "Computer vision"]
                    ))
                    
                return enhancements
                
            def _create_enhancement(self, type: str, suggestion: str, priority: str, hints: List[str]) -> Dict[str, Any]:
                """Create an enhancement object."""
                return {
                    "type": type,
                    "suggestion": suggestion,
                    "priority": priority,
                    "rationale": f"This enhancement will improve {type} significantly",
                    "implementation_hints": hints,
                    "estimated_impact": self._calculate_impact(priority),
                    "complexity": self._estimate_complexity(len(hints))
                }
                
            def _calculate_impact(self, priority: str) -> str:
                """Calculate enhancement impact."""
                impact_map = {
                    "critical": "very_high",
                    "high": "high",
                    "medium": "medium",
                    "low": "low"
                }
                return impact_map.get(priority, "medium")
                
            def _estimate_complexity(self, hint_count: int) -> str:
                """Estimate implementation complexity."""
                if hint_count <= 2:
                    return "simple"
                elif hint_count <= 4:
                    return "medium"
                else:
                    return "complex"
                    
            async def prioritize_enhancements(self, enhancements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
                """Prioritize enhancements based on impact and complexity."""
                priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
                
                return sorted(
                    enhancements,
                    key=lambda x: (priority_order.get(x["priority"], 4), x["complexity"])
                )
                
            async def generate_ecosystem_integrations(self, tech_stack: List[str]) -> List[Dict[str, Any]]:
                """Generate ecosystem integration suggestions."""
                integrations = []
                
                ecosystem_map = {
                    "Python": ["pip", "conda", "poetry", "pytest", "sphinx"],
                    "JavaScript": ["npm", "yarn", "webpack", "jest", "eslint"],
                    "React": ["Redux", "Material-UI", "React Router", "Storybook"],
                    "Node.js": ["Express", "Koa", "Socket.io", "PM2"],
                    "PostgreSQL": ["pgAdmin", "PostGIS", "pg_stat_statements"],
                    "MongoDB": ["Mongoose", "MongoDB Atlas", "Compass"]
                }
                
                for tech in tech_stack:
                    if tech in ecosystem_map:
                        for tool in ecosystem_map[tech]:
                            integrations.append({
                                "technology": tech,
                                "tool": tool,
                                "purpose": f"Enhance {tech} development",
                                "integration_type": "ecosystem"
                            })
                            
                return integrations[:5]  # Limit to top 5 integrations
                
        return MockIntelligenceEngine()
        
    def test_analyze_api_request_enhancements(self):
        """Test enhancement analysis for API request."""
        request = self.test_data.generate_request(
            request_type="api_development",
            description="Create a REST API for user management with payment processing"
        )
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        self.assertGreater(len(enhancements), 0)
        
        # Should suggest performance and security enhancements
        enhancement_types = [e["type"] for e in enhancements]
        self.assertIn("performance", enhancement_types)
        self.assertIn("security", enhancement_types)
        
        # Validate enhancement structure
        for enhancement in enhancements:
            self.assertTrue(self.validator.validate_enhancement_structure(enhancement))
            
    def test_analyze_complex_request_enhancements(self):
        """Test enhancement analysis for complex request."""
        request = self.test_data.generate_request(
            request_type="fullstack_application",
            description="Build an enterprise-grade modern web application",
            requirements=[f"Feature {i}" for i in range(10)],
            technology_stack=["React", "Node.js", "PostgreSQL", "Redis", "Docker"]
        )
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        # Complex request should generate multiple enhancements
        self.assertGreaterEqual(len(enhancements), 3)
        
        # Should include scalability and maintainability
        enhancement_types = [e["type"] for e in enhancements]
        self.assertIn("scalability", enhancement_types)
        self.assertIn("maintainability", enhancement_types)
        
    def test_prioritize_enhancements(self):
        """Test enhancement prioritization logic."""
        enhancements = [
            self.test_data.generate_enhancement("performance"),
            {"type": "security", "suggestion": "Add auth", "priority": "critical"},
            {"type": "scalability", "suggestion": "Add scaling", "priority": "medium"},
            {"type": "maintainability", "suggestion": "Add tests", "priority": "high"}
        ]
        
        prioritized = self.run_async(self.engine.prioritize_enhancements(enhancements))
        
        # Critical should be first
        self.assertEqual(prioritized[0]["priority"], "critical")
        
        # High priority should come before medium
        high_index = next(i for i, e in enumerate(prioritized) if e["priority"] == "high")
        medium_index = next(i for i, e in enumerate(prioritized) if e["priority"] == "medium")
        self.assertLess(high_index, medium_index)
        
    def test_generate_ecosystem_integrations(self):
        """Test ecosystem integration generation."""
        tech_stack = ["Python", "React", "PostgreSQL"]
        
        integrations = self.run_async(self.engine.generate_ecosystem_integrations(tech_stack))
        
        self.assertGreater(len(integrations), 0)
        self.assertLessEqual(len(integrations), 5)
        
        # Check integration structure
        for integration in integrations:
            self.assertIn("technology", integration)
            self.assertIn("tool", integration)
            self.assertIn("purpose", integration)
            self.assertIn("integration_type", integration)
            
        # Check that integrations match tech stack
        integration_techs = set(i["technology"] for i in integrations)
        self.assertTrue(integration_techs.issubset(set(tech_stack)))
        
    def test_enhancement_impact_calculation(self):
        """Test impact calculation for enhancements."""
        request = self.test_data.generate_request(
            description="Create a critical payment processing API"
        )
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        # Security enhancement should have high/very high impact
        security_enhancement = next(
            (e for e in enhancements if e["type"] == "security"),
            None
        )
        
        if security_enhancement:
            self.assertIn(
                security_enhancement["estimated_impact"],
                ["high", "very_high"]
            )
            
    def test_enhancement_complexity_estimation(self):
        """Test complexity estimation for enhancements."""
        request = self.test_data.generate_request()
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        for enhancement in enhancements:
            hint_count = len(enhancement.get("implementation_hints", []))
            complexity = enhancement.get("complexity")
            
            if hint_count <= 2:
                self.assertEqual(complexity, "simple")
            elif hint_count <= 4:
                self.assertEqual(complexity, "medium")
            else:
                self.assertEqual(complexity, "complex")
                
    def test_empty_request_handling(self):
        """Test handling of empty request."""
        empty_request = {}
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(empty_request))
        
        # Should handle gracefully and return empty or minimal enhancements
        self.assertIsNotNone(enhancements)
        self.assertIsInstance(enhancements, list)
        
    def test_innovation_detection(self):
        """Test detection of innovation opportunities."""
        request = self.test_data.generate_request(
            description="Build a cutting-edge modern application with advanced features"
        )
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        # Should detect innovation opportunity
        innovation_enhancement = next(
            (e for e in enhancements if e["type"] == "innovation"),
            None
        )
        
        self.assertIsNotNone(innovation_enhancement)
        self.assertIn("AI", " ".join(innovation_enhancement["implementation_hints"]))
        
    def test_enhancement_rationale_generation(self):
        """Test that enhancements include proper rationale."""
        request = self.test_data.generate_request()
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        for enhancement in enhancements:
            self.assertIn("rationale", enhancement)
            self.assertIsInstance(enhancement["rationale"], str)
            self.assertGreater(len(enhancement["rationale"]), 10)
            
    def test_multiple_enhancement_types(self):
        """Test generation of multiple enhancement types."""
        request = self.test_data.generate_request(
            description="Create a modern enterprise API with user data and payments",
            requirements=[f"Requirement {i}" for i in range(8)],
            technology_stack=["Python", "React", "PostgreSQL", "Redis"]
        )
        
        enhancements = self.run_async(self.engine.analyze_for_enhancements(request))
        
        enhancement_types = set(e["type"] for e in enhancements)
        
        # Should generate at least 3 different types of enhancements
        self.assertGreaterEqual(len(enhancement_types), 3)
        
        # Check for expected types
        expected_types = {"performance", "security", "scalability"}
        self.assertTrue(
            expected_types.intersection(enhancement_types),
            f"Expected at least one of {expected_types}, got {enhancement_types}"
        )


class TestEnhancementValidation(DPOTestBase):
    """Test enhancement validation logic."""
    
    def test_validate_enhancement_structure(self):
        """Test validation of enhancement structure."""
        valid_enhancement = {
            "type": "performance",
            "suggestion": "Implement caching",
            "priority": "high",
            "rationale": "Improve response times",
            "implementation_hints": ["Use Redis", "Cache API responses"]
        }
        
        self.assertTrue(TestValidator.validate_enhancement_structure(valid_enhancement))
        
        # Missing required field
        invalid_enhancement = {
            "type": "performance",
            "suggestion": "Implement caching"
            # Missing priority
        }
        
        self.assertFalse(TestValidator.validate_enhancement_structure(invalid_enhancement))
        
    def test_validate_priority_values(self):
        """Test validation of priority values."""
        valid_priorities = ["low", "medium", "high", "critical"]
        
        for priority in valid_priorities:
            enhancement = {
                "type": "test",
                "suggestion": "Test",
                "priority": priority
            }
            self.assertTrue(TestValidator.validate_enhancement_structure(enhancement))
            
        # Invalid priority
        invalid_enhancement = {
            "type": "test",
            "suggestion": "Test",
            "priority": "super_high"  # Invalid
        }
        
        self.assertFalse(TestValidator.validate_enhancement_structure(invalid_enhancement))
        
    def test_validate_enhancement_types(self):
        """Test validation of enhancement types."""
        valid_types = [
            "performance",
            "security",
            "scalability",
            "maintainability",
            "innovation"
        ]
        
        for enhancement_type in valid_types:
            enhancement = {
                "type": enhancement_type,
                "suggestion": "Test",
                "priority": "medium"
            }
            self.assertTrue(TestValidator.validate_enhancement_structure(enhancement))


if __name__ == "__main__":
    unittest.main()