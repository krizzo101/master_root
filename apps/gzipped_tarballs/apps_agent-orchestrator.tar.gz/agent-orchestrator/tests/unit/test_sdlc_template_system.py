"""
Unit tests for SDLC Template System component of DPO system.
"""

import unittest
import json
from unittest.mock import Mock, patch, MagicMock
import sys
import os
from typing import Dict, Any, List

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from tests.base_test import DPOTestBase, AsyncDPOTestBase, TestDataGenerator, TestValidator


class TestSDLCTemplateSystem(AsyncDPOTestBase):
    """Test SDLC Template System workflow generation."""
    
    def setUp(self):
        """Set up test fixtures."""
        super().setUp()
        self.template_system = self._create_mock_template_system()
        self.test_data = TestDataGenerator()
        self.validator = TestValidator()
        
    def _create_mock_template_system(self):
        """Create a mock SDLC template system."""
        class MockSDLCTemplateSystem:
            def __init__(self):
                self.templates = {
                    "api_development": {
                        "phases": ["planning", "design", "development", "testing", "deployment"],
                        "agents": ["architect", "api_developer", "tester", "devops"],
                        "quality_gates": ["code_review", "unit_tests", "integration_tests", "performance_tests"]
                    },
                    "fullstack_application": {
                        "phases": ["planning", "design", "frontend", "backend", "integration", "testing", "deployment"],
                        "agents": ["architect", "frontend_dev", "backend_dev", "database_admin", "tester", "devops"],
                        "quality_gates": ["code_review", "unit_tests", "e2e_tests", "performance_tests", "security_scan"]
                    },
                    "cli_development": {
                        "phases": ["planning", "design", "development", "testing", "packaging"],
                        "agents": ["architect", "cli_developer", "tester"],
                        "quality_gates": ["code_review", "unit_tests", "cli_tests"]
                    },
                    "integration_connector": {
                        "phases": ["analysis", "design", "development", "testing", "deployment"],
                        "agents": ["integration_specialist", "api_developer", "tester"],
                        "quality_gates": ["code_review", "integration_tests", "endpoint_tests"]
                    }
                }
                
            async def generate_workflow(self, request_type: str, requirements: List[str], enhancements: List[Dict]) -> Dict[str, Any]:
                """Generate workflow based on request type and enhancements."""
                template = self.templates.get(request_type, self.templates["api_development"])
                
                workflow = {
                    "task_type": request_type,
                    "phases": template["phases"],
                    "agents": self._configure_agents(template["agents"], requirements),
                    "quality_gates": self._configure_quality_gates(template["quality_gates"], enhancements),
                    "config": self._generate_config(request_type, requirements, enhancements),
                    "dependencies": self._resolve_dependencies(template["agents"]),
                    "estimated_duration": self._estimate_duration(len(requirements))
                }
                
                return workflow
                
            def _configure_agents(self, agent_types: List[str], requirements: List[str]) -> List[Dict[str, Any]]:
                """Configure agents based on requirements."""
                agents = []
                
                for i, agent_type in enumerate(agent_types):
                    agent = {
                        "id": f"agent_{agent_type}_{i}",
                        "type": agent_type,
                        "config": {
                            "max_tokens": 4000,
                            "temperature": 0.7,
                            "requirements_assigned": self._assign_requirements(requirements, i, len(agent_types))
                        },
                        "dependencies": [],
                        "priority": self._calculate_priority(agent_type)
                    }
                    
                    # Add dependencies based on agent type
                    if agent_type in ["frontend_dev", "backend_dev"]:
                        agent["dependencies"].append("architect")
                    elif agent_type == "tester":
                        agent["dependencies"].extend(["frontend_dev", "backend_dev", "api_developer", "cli_developer"])
                    elif agent_type == "devops":
                        agent["dependencies"].append("tester")
                        
                    agents.append(agent)
                    
                return agents
                
            def _assign_requirements(self, requirements: List[str], agent_index: int, total_agents: int) -> List[str]:
                """Assign requirements to agents."""
                if not requirements:
                    return []
                    
                reqs_per_agent = len(requirements) // total_agents
                start_idx = agent_index * reqs_per_agent
                end_idx = start_idx + reqs_per_agent if agent_index < total_agents - 1 else len(requirements)
                
                return requirements[start_idx:end_idx]
                
            def _calculate_priority(self, agent_type: str) -> int:
                """Calculate agent priority."""
                priority_map = {
                    "architect": 1,
                    "database_admin": 2,
                    "backend_dev": 3,
                    "api_developer": 3,
                    "frontend_dev": 3,
                    "cli_developer": 3,
                    "integration_specialist": 3,
                    "tester": 4,
                    "devops": 5
                }
                return priority_map.get(agent_type, 3)
                
            def _configure_quality_gates(self, base_gates: List[str], enhancements: List[Dict]) -> List[Dict[str, Any]]:
                """Configure quality gates based on enhancements."""
                gates = []
                
                for gate_name in base_gates:
                    gate = {
                        "name": gate_name,
                        "type": self._get_gate_type(gate_name),
                        "threshold": self._get_gate_threshold(gate_name),
                        "mandatory": gate_name in ["code_review", "unit_tests"],
                        "blocking": gate_name in ["security_scan", "code_review"]
                    }
                    gates.append(gate)
                    
                # Add enhancement-specific gates
                for enhancement in enhancements:
                    if enhancement.get("type") == "security" and not any(g["name"] == "security_scan" for g in gates):
                        gates.append({
                            "name": "security_scan",
                            "type": "security",
                            "threshold": 90,
                            "mandatory": True,
                            "blocking": True
                        })
                    elif enhancement.get("type") == "performance" and not any(g["name"] == "performance_tests" for g in gates):
                        gates.append({
                            "name": "performance_tests",
                            "type": "performance",
                            "threshold": 85,
                            "mandatory": False,
                            "blocking": False
                        })
                        
                return gates
                
            def _get_gate_type(self, gate_name: str) -> str:
                """Get quality gate type."""
                type_map = {
                    "code_review": "review",
                    "unit_tests": "testing",
                    "integration_tests": "testing",
                    "e2e_tests": "testing",
                    "cli_tests": "testing",
                    "endpoint_tests": "testing",
                    "performance_tests": "performance",
                    "security_scan": "security"
                }
                return type_map.get(gate_name, "general")
                
            def _get_gate_threshold(self, gate_name: str) -> int:
                """Get quality gate threshold."""
                threshold_map = {
                    "code_review": 100,
                    "unit_tests": 80,
                    "integration_tests": 75,
                    "e2e_tests": 70,
                    "cli_tests": 80,
                    "endpoint_tests": 85,
                    "performance_tests": 85,
                    "security_scan": 90
                }
                return threshold_map.get(gate_name, 75)
                
            def _generate_config(self, request_type: str, requirements: List[str], enhancements: List[Dict]) -> Dict[str, Any]:
                """Generate workflow configuration."""
                config = {
                    "parallel_execution": len(requirements) > 3,
                    "max_parallel_agents": min(3, len(requirements)),
                    "timeout_minutes": 30 + (len(requirements) * 5),
                    "retry_on_failure": True,
                    "max_retries": 2,
                    "enable_caching": True,
                    "enable_monitoring": True,
                    "optimization_level": self._determine_optimization_level(enhancements)
                }
                
                # Add type-specific config
                if request_type == "fullstack_application":
                    config["frontend_framework"] = "React"
                    config["backend_framework"] = "Node.js"
                elif request_type == "api_development":
                    config["api_spec"] = "OpenAPI 3.0"
                    config["authentication"] = "JWT"
                    
                return config
                
            def _determine_optimization_level(self, enhancements: List[Dict]) -> str:
                """Determine optimization level based on enhancements."""
                if any(e.get("priority") == "critical" for e in enhancements):
                    return "maximum"
                elif any(e.get("priority") == "high" for e in enhancements):
                    return "high"
                else:
                    return "standard"
                    
            def _resolve_dependencies(self, agent_types: List[str]) -> Dict[str, List[str]]:
                """Resolve agent dependencies."""
                dependencies = {}
                
                for agent in agent_types:
                    deps = []
                    if agent in ["frontend_dev", "backend_dev", "api_developer"]:
                        deps.append("architect")
                    elif agent == "tester":
                        deps.extend(["frontend_dev", "backend_dev", "api_developer"])
                    elif agent == "devops":
                        deps.append("tester")
                        
                    if deps:
                        dependencies[agent] = deps
                        
                return dependencies
                
            def _estimate_duration(self, requirement_count: int) -> int:
                """Estimate workflow duration in minutes."""
                base_duration = 30
                per_requirement = 10
                return base_duration + (requirement_count * per_requirement)
                
            async def validate_workflow(self, workflow: Dict[str, Any]) -> bool:
                """Validate generated workflow."""
                required_fields = ["task_type", "agents", "config", "phases"]
                
                # Check required fields
                if not all(field in workflow for field in required_fields):
                    return False
                    
                # Validate agents
                if not workflow["agents"] or not isinstance(workflow["agents"], list):
                    return False
                    
                for agent in workflow["agents"]:
                    if not all(field in agent for field in ["id", "type"]):
                        return False
                        
                # Validate config
                if not isinstance(workflow["config"], dict):
                    return False
                    
                return True
                
        return MockSDLCTemplateSystem()
        
    def test_generate_api_workflow(self):
        """Test workflow generation for API development."""
        request_type = "api_development"
        requirements = ["CRUD operations", "Authentication", "Validation"]
        enhancements = [self.test_data.generate_enhancement("performance")]
        
        workflow = self.run_async(
            self.template_system.generate_workflow(request_type, requirements, enhancements)
        )
        
        self.assertEqual(workflow["task_type"], "api_development")
        self.assertIn("agents", workflow)
        self.assertIn("config", workflow)
        self.assertIn("quality_gates", workflow)
        
        # Validate workflow structure
        self.assertTrue(self.validator.validate_workflow_structure(workflow))
        
        # Check for API-specific agents
        agent_types = [agent["type"] for agent in workflow["agents"]]
        self.assertIn("api_developer", agent_types)
        
    def test_generate_fullstack_workflow(self):
        """Test workflow generation for full-stack application."""
        request_type = "fullstack_application"
        requirements = [f"Feature {i}" for i in range(5)]
        enhancements = [
            self.test_data.generate_enhancement("security"),
            self.test_data.generate_enhancement("performance")
        ]
        
        workflow = self.run_async(
            self.template_system.generate_workflow(request_type, requirements, enhancements)
        )
        
        self.assertEqual(workflow["task_type"], "fullstack_application")
        
        # Should have frontend and backend developers
        agent_types = [agent["type"] for agent in workflow["agents"]]
        self.assertIn("frontend_dev", agent_types)
        self.assertIn("backend_dev", agent_types)
        
        # Should have more phases for full-stack
        self.assertGreater(len(workflow["phases"]), 5)
        
    def test_agent_configuration(self):
        """Test agent configuration based on requirements."""
        requirements = ["Req1", "Req2", "Req3", "Req4", "Req5", "Req6"]
        
        workflow = self.run_async(
            self.template_system.generate_workflow("api_development", requirements, [])
        )
        
        # Check that requirements are distributed among agents
        total_assigned = 0
        for agent in workflow["agents"]:
            assigned_reqs = agent["config"].get("requirements_assigned", [])
            total_assigned += len(assigned_reqs)
            
        self.assertEqual(total_assigned, len(requirements))
        
        # Check agent priorities
        for agent in workflow["agents"]:
            self.assertIn("priority", agent)
            self.assertIsInstance(agent["priority"], int)
            self.assertGreaterEqual(agent["priority"], 1)
            self.assertLessEqual(agent["priority"], 5)
            
    def test_quality_gates_configuration(self):
        """Test quality gates configuration."""
        enhancements = [
            {"type": "security", "suggestion": "Add security", "priority": "critical"},
            {"type": "performance", "suggestion": "Add performance", "priority": "high"}
        ]
        
        workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [], enhancements)
        )
        
        gates = workflow["quality_gates"]
        
        # Should have mandatory gates
        gate_names = [gate["name"] for gate in gates]
        self.assertIn("code_review", gate_names)
        self.assertIn("unit_tests", gate_names)
        
        # Should add security gate for security enhancement
        self.assertIn("security_scan", gate_names)
        
        # Validate gate structure
        for gate in gates:
            self.assertIn("name", gate)
            self.assertIn("type", gate)
            self.assertIn("threshold", gate)
            self.assertIn("mandatory", gate)
            self.assertIn("blocking", gate)
            
    def test_dependency_resolution(self):
        """Test agent dependency resolution."""
        workflow = self.run_async(
            self.template_system.generate_workflow("fullstack_application", ["Feature1"], [])
        )
        
        dependencies = workflow.get("dependencies", {})
        
        # Frontend and backend should depend on architect
        if "frontend_dev" in dependencies:
            self.assertIn("architect", dependencies["frontend_dev"])
        if "backend_dev" in dependencies:
            self.assertIn("architect", dependencies["backend_dev"])
            
        # Tester should depend on developers
        if "tester" in dependencies:
            dev_deps = ["frontend_dev", "backend_dev", "api_developer"]
            for dep in dependencies["tester"]:
                self.assertIn(dep, dev_deps)
                
    def test_parallel_execution_config(self):
        """Test parallel execution configuration."""
        # Few requirements - no parallel execution
        small_workflow = self.run_async(
            self.template_system.generate_workflow("api_development", ["Req1", "Req2"], [])
        )
        
        self.assertFalse(small_workflow["config"]["parallel_execution"])
        
        # Many requirements - enable parallel execution
        large_workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [f"Req{i}" for i in range(10)], [])
        )
        
        self.assertTrue(large_workflow["config"]["parallel_execution"])
        self.assertGreater(large_workflow["config"]["max_parallel_agents"], 0)
        
    def test_optimization_level_determination(self):
        """Test optimization level based on enhancements."""
        # Critical enhancement - maximum optimization
        critical_enhancements = [
            {"type": "security", "suggestion": "Fix", "priority": "critical"}
        ]
        
        workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [], critical_enhancements)
        )
        
        self.assertEqual(workflow["config"]["optimization_level"], "maximum")
        
        # High priority - high optimization
        high_enhancements = [
            {"type": "performance", "suggestion": "Optimize", "priority": "high"}
        ]
        
        workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [], high_enhancements)
        )
        
        self.assertEqual(workflow["config"]["optimization_level"], "high")
        
        # No high priority - standard optimization
        workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [], [])
        )
        
        self.assertEqual(workflow["config"]["optimization_level"], "standard")
        
    def test_duration_estimation(self):
        """Test workflow duration estimation."""
        # Small project
        small_workflow = self.run_async(
            self.template_system.generate_workflow("api_development", ["Req1"], [])
        )
        
        self.assertIn("estimated_duration", small_workflow)
        self.assertLess(small_workflow["estimated_duration"], 60)
        
        # Large project
        large_workflow = self.run_async(
            self.template_system.generate_workflow("api_development", [f"Req{i}" for i in range(10)], [])
        )
        
        self.assertGreater(large_workflow["estimated_duration"], small_workflow["estimated_duration"])
        
    def test_workflow_validation(self):
        """Test workflow validation."""
        valid_workflow = {
            "task_type": "api_development",
            "agents": [{"id": "agent_1", "type": "developer"}],
            "config": {"parallel_execution": True},
            "phases": ["planning", "development"]
        }
        
        is_valid = self.run_async(self.template_system.validate_workflow(valid_workflow))
        self.assertTrue(is_valid)
        
        # Invalid workflow - missing agents
        invalid_workflow = {
            "task_type": "api_development",
            "config": {},
            "phases": []
        }
        
        is_valid = self.run_async(self.template_system.validate_workflow(invalid_workflow))
        self.assertFalse(is_valid)
        
    def test_cli_workflow_generation(self):
        """Test CLI development workflow generation."""
        workflow = self.run_async(
            self.template_system.generate_workflow("cli_development", ["Parse args", "File ops"], [])
        )
        
        self.assertEqual(workflow["task_type"], "cli_development")
        
        # Should have CLI-specific configuration
        agent_types = [agent["type"] for agent in workflow["agents"]]
        self.assertIn("cli_developer", agent_types)
        
        # Should have CLI testing gates
        gate_names = [gate["name"] for gate in workflow["quality_gates"]]
        self.assertIn("cli_tests", gate_names)
        
    def test_integration_workflow_generation(self):
        """Test integration connector workflow generation."""
        workflow = self.run_async(
            self.template_system.generate_workflow("integration_connector", ["API sync", "Webhooks"], [])
        )
        
        self.assertEqual(workflow["task_type"], "integration_connector")
        
        # Should have integration specialist
        agent_types = [agent["type"] for agent in workflow["agents"]]
        self.assertIn("integration_specialist", agent_types)
        
        # Should have integration testing
        gate_names = [gate["name"] for gate in workflow["quality_gates"]]
        self.assertIn("integration_tests", gate_names)


if __name__ == "__main__":
    unittest.main()