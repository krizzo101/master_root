#!/usr/bin/env python3
"""
Test script for DPO Main Controller

Tests the complete integration of all DPO components through the main controller.

Author: Agent Orchestrator Team  
Date: September 2025
"""

import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.append(str(Path(__file__).parent))

from src.dpo_main_controller import (
    DevelopmentProcessOrchestrator,
    DPOConfiguration,
    RequestAnalyzer,
    RequestType
)


async def test_request_analyzer():
    """Test the request analyzer component"""
    print("\n=== Testing Request Analyzer ===")
    
    analyzer = RequestAnalyzer()
    
    test_requests = [
        "Build a REST API for user management with authentication",
        "Create a simple CLI tool for file processing",
        "Develop a complex web application with real-time features and microservices",
        "Fix the authentication bug in the login system",
        "Optimize database performance for large datasets",
        "Document the API endpoints and create user guides"
    ]
    
    for request in test_requests:
        analysis = analyzer.analyze(request)
        print(f"\nRequest: {request[:50]}...")
        print(f"  Type: {analysis.request_type.value}")
        print(f"  Project: {analysis.project_type}")
        print(f"  Complexity: {analysis.complexity}")
        print(f"  Confidence: {analysis.confidence_score:.2f}")
        print(f"  Effort: {analysis.estimated_effort}")
    
    print("\n✓ Request Analyzer test completed")


async def test_configuration_management():
    """Test configuration management"""
    print("\n=== Testing Configuration Management ===")
    
    # Create test configuration
    config = DPOConfiguration(
        output_base_dir="output/test_dpo",
        max_parallel_agents=5,
        enable_intelligence=True,
        enable_context_injection=False,
        metrics_enabled=True
    )
    
    # Save configuration
    test_config_path = "output/test_config.json"
    config.save(test_config_path)
    print(f"Configuration saved to {test_config_path}")
    
    # Load configuration
    loaded_config = DPOConfiguration.from_file(test_config_path)
    print(f"Configuration loaded: max_agents={loaded_config.max_parallel_agents}")
    
    print("\n✓ Configuration management test completed")


async def test_main_controller_initialization():
    """Test main controller initialization"""
    print("\n=== Testing Main Controller Initialization ===")
    
    config = DPOConfiguration(
        output_base_dir="output/test_dpo_init",
        max_parallel_agents=3,
        enable_intelligence=False,  # Disable for quick test
        enable_context_injection=False,
        enable_websocket=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    print("Main controller initialized successfully")
    
    # Check components
    assert dpo.request_analyzer is not None, "Request analyzer not initialized"
    assert dpo.template_system is not None, "Template system not initialized"
    assert dpo.orchestrator is not None, "Orchestrator not initialized"
    print("All core components initialized")
    
    # Check metrics
    metrics = dpo.get_metrics()
    print(f"Initial metrics: {json.dumps(metrics, indent=2)}")
    
    await dpo.shutdown()
    print("\n✓ Main controller initialization test completed")


async def test_simple_workflow():
    """Test a simple workflow execution"""
    print("\n=== Testing Simple Workflow Execution ===")
    
    config = DPOConfiguration(
        output_base_dir="output/test_simple_workflow",
        max_parallel_agents=2,
        enable_intelligence=False,
        enable_context_injection=False,
        enable_websocket=False
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    # Create simple request
    result = await dpo.process_development_request(
        request="Create a simple hello world CLI application",
        project_type="cli",
        complexity="simple",
        context={
            "language": "Python",
            "features": ["help command", "version command"]
        }
    )
    
    if result['success']:
        print(f"Workflow initiated: {result['workflow_id']}")
        print(f"Analysis: {result['analysis']['project_type']}, {result['analysis']['complexity']}")
        print(f"Processing time: {result['processing_time']:.2f}s")
        
        # Wait briefly for workflow to start
        await asyncio.sleep(2)
        
        # Check status
        status = await dpo.get_workflow_status(result['workflow_id'])
        print(f"Workflow status: {status.get('status')}")
        
        # Cancel workflow (for testing)
        cancel_result = await dpo.cancel_workflow(result['workflow_id'])
        print(f"Workflow cancelled: {cancel_result['success']}")
    else:
        print(f"Workflow failed: {result.get('error')}")
    
    await dpo.shutdown()
    print("\n✓ Simple workflow test completed")


async def test_error_recovery():
    """Test error handling and recovery"""
    print("\n=== Testing Error Recovery ===")
    
    config = DPOConfiguration(
        output_base_dir="output/test_error_recovery",
        max_parallel_agents=2,
        enable_intelligence=False,
        enable_context_injection=False,
        auto_recovery=True
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    # Test with problematic request
    result = await dpo.process_development_request(
        request="",  # Empty request should trigger error handling
        project_type="unknown",
        complexity="invalid"
    )
    
    print(f"Result success: {result['success']}")
    if not result['success']:
        print(f"Error handled: {result.get('error')}")
        if result.get('recovery_error'):
            print(f"Recovery attempted: {result.get('recovery_error')}")
    
    await dpo.shutdown()
    print("\n✓ Error recovery test completed")


async def test_workflow_lifecycle():
    """Test complete workflow lifecycle"""
    print("\n=== Testing Workflow Lifecycle ===")
    
    config = DPOConfiguration(
        output_base_dir="output/test_lifecycle",
        max_parallel_agents=2,
        enable_intelligence=False,
        enable_context_injection=False,
        metrics_enabled=True
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    # Submit workflow
    result = await dpo.process_development_request(
        request="Build a simple REST API with one endpoint",
        project_type="api",
        complexity="simple"
    )
    
    if result['success']:
        workflow_id = result['workflow_id']
        print(f"Workflow submitted: {workflow_id}")
        
        # List workflows
        workflows = await dpo.list_workflows()
        print(f"Active workflows: {len(workflows)}")
        
        # Monitor for a few seconds
        for i in range(3):
            await asyncio.sleep(1)
            status = await dpo.get_workflow_status(workflow_id)
            print(f"Status check {i+1}: {status.get('status')}")
        
        # Cancel workflow
        await dpo.cancel_workflow(workflow_id)
        
        # Check metrics
        metrics = dpo.get_metrics()
        print(f"\nFinal metrics:")
        print(f"  Total requests: {metrics['total_requests']}")
        print(f"  Successful: {metrics['successful_workflows']}")
        print(f"  Failed: {metrics['failed_workflows']}")
    
    await dpo.shutdown()
    print("\n✓ Workflow lifecycle test completed")


async def test_metrics_tracking():
    """Test metrics tracking"""
    print("\n=== Testing Metrics Tracking ===")
    
    config = DPOConfiguration(
        output_base_dir="output/test_metrics",
        metrics_enabled=True
    )
    
    dpo = DevelopmentProcessOrchestrator(config)
    
    # Initial metrics
    initial_metrics = dpo.get_metrics()
    print(f"Initial metrics: {json.dumps(initial_metrics, indent=2)}")
    
    # Process a request
    await dpo.process_development_request(
        request="Test request for metrics",
        project_type="api",
        complexity="simple"
    )
    
    # Check updated metrics
    updated_metrics = dpo.get_metrics()
    print(f"\nUpdated metrics: {json.dumps(updated_metrics, indent=2)}")
    
    assert updated_metrics['total_requests'] > initial_metrics['total_requests']
    
    await dpo.shutdown()
    print("\n✓ Metrics tracking test completed")


async def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("DPO MAIN CONTROLLER INTEGRATION TESTS")
    print("=" * 60)
    
    tests = [
        ("Request Analyzer", test_request_analyzer),
        ("Configuration Management", test_configuration_management),
        ("Main Controller Initialization", test_main_controller_initialization),
        ("Simple Workflow", test_simple_workflow),
        ("Error Recovery", test_error_recovery),
        ("Workflow Lifecycle", test_workflow_lifecycle),
        ("Metrics Tracking", test_metrics_tracking)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            await test_func()
            passed += 1
        except Exception as e:
            print(f"\n✗ {test_name} test failed: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"TEST RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)