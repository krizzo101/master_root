#!/usr/bin/env python3
"""
Simple test for DPO Main Controller
"""

import asyncio
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from src.dpo_main_controller import (
    DevelopmentProcessOrchestrator,
    DPOConfiguration,
    RequestAnalyzer
)


async def test_basic_components():
    """Test basic components initialization"""
    print("Testing DPO Main Controller Components...\n")
    
    # Test Request Analyzer
    print("1. Testing Request Analyzer:")
    analyzer = RequestAnalyzer()
    analysis = analyzer.analyze("Build a REST API for user management")
    print(f"   Request Type: {analysis.request_type.value}")
    print(f"   Project Type: {analysis.project_type}")
    print(f"   Complexity: {analysis.complexity}")
    print(f"   Confidence: {analysis.confidence_score:.2f}")
    print("   ✓ Request Analyzer working\n")
    
    # Test Configuration
    print("2. Testing Configuration:")
    config = DPOConfiguration(
        output_base_dir="output/test_simple",
        max_parallel_agents=2,
        enable_intelligence=False,
        enable_context_injection=False,
        enable_websocket=False
    )
    print(f"   Output dir: {config.output_base_dir}")
    print(f"   Max agents: {config.max_parallel_agents}")
    print("   ✓ Configuration working\n")
    
    # Test Main Controller Initialization
    print("3. Testing Main Controller:")
    dpo = DevelopmentProcessOrchestrator(config)
    print("   ✓ Main controller initialized")
    
    # Get initial metrics
    metrics = dpo.get_metrics()
    print(f"   Initial metrics - Total requests: {metrics['total_requests']}")
    
    # Shutdown
    await dpo.shutdown()
    print("   ✓ Main controller shutdown\n")
    
    print("All basic components working correctly!")


if __name__ == "__main__":
    asyncio.run(test_basic_components())