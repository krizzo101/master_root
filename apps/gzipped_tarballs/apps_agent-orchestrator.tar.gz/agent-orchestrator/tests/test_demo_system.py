#!/usr/bin/env python3
"""
Test Script for Agent Orchestrator Demo System

This script validates that all demo components work correctly before running
the full demonstration. It performs quick verification tests without executing
actual agents.
"""

import asyncio
import json
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List

# Import demo components
try:
    from comprehensive_demo import ComprehensiveDemoBuilder, DemoProgressMonitor
    from demo_monitoring import RealTimeMonitor, create_demo_monitor
    from src.generic_orchestrator import AgentTask, GenericOrchestrator
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Make sure you're running from the agent-orchestrator directory")
    sys.exit(1)


class DemoSystemValidator:
    """Validates that the demo system components work correctly"""
    
    def __init__(self):
        self.test_results = []
        self.temp_dir = Path(tempfile.mkdtemp(prefix="demo_test_"))
        
    def log_test(self, test_name: str, success: bool, message: str = ""):
        """Log a test result"""
        status = "✅ PASS" if success else "❌ FAIL"
        self.test_results.append({
            "test": test_name,
            "success": success,
            "message": message
        })
        print(f"{status}: {test_name}")
        if message:
            print(f"      {message}")
            
    def test_task_generation(self):
        """Test that demo task generation works"""
        try:
            builder = ComprehensiveDemoBuilder(self.temp_dir)
            
            # Test basic tasks
            basic_tasks = builder.build_basic_demo_tasks()
            if len(basic_tasks) >= 3:
                self.log_test("Basic task generation", True, f"Generated {len(basic_tasks)} tasks")
            else:
                self.log_test("Basic task generation", False, f"Only generated {len(basic_tasks)} tasks")
                
            # Test parallel tasks
            parallel_tasks = builder.build_parallel_demo_tasks()
            if len(parallel_tasks) >= 5:
                self.log_test("Parallel task generation", True, f"Generated {len(parallel_tasks)} tasks")
            else:
                self.log_test("Parallel task generation", False, f"Only generated {len(parallel_tasks)} tasks")
                
            # Test dependency tasks
            dep_tasks = builder.build_dependency_demo_tasks()
            if len(dep_tasks) >= 6:
                self.log_test("Dependency task generation", True, f"Generated {len(dep_tasks)} tasks")
            else:
                self.log_test("Dependency task generation", False, f"Only generated {len(dep_tasks)} tasks")
                
            # Test task structure
            sample_task = basic_tasks[0]
            required_fields = ['task_id', 'task_type', 'prompt', 'context', 'dependencies']
            missing_fields = [field for field in required_fields if not hasattr(sample_task, field)]
            
            if not missing_fields:
                self.log_test("Task structure validation", True, "All required fields present")
            else:
                self.log_test("Task structure validation", False, f"Missing fields: {missing_fields}")
                
        except Exception as e:
            self.log_test("Task generation", False, f"Exception: {str(e)}")
            
    def test_monitoring_system(self):
        """Test the monitoring system components"""
        try:
            # Test progress monitor
            progress_monitor = DemoProgressMonitor()
            progress_monitor.start_monitoring(5)
            progress_monitor.update_progress(2, "test_task")
            progress_monitor.complete_monitoring([
                {"status": "completed"}, 
                {"status": "completed"},
                {"status": "failed"}
            ])
            self.log_test("Progress monitor", True, "Progress monitoring works")
            
            # Test real-time monitor
            rt_monitor = create_demo_monitor("Test Workflow")
            rt_monitor.initialize_workflow(3)
            rt_monitor.register_task("test_task_1", "test_type")
            rt_monitor.update_task_status("test_task_1", "running")
            rt_monitor.update_task_progress("test_task_1", 50.0, "Mid-process")
            rt_monitor.update_task_status("test_task_1", "completed")
            
            state = rt_monitor.get_current_state()
            if state["workflow"]["total_tasks"] == 3:
                self.log_test("Real-time monitor", True, "RT monitoring works")
            else:
                self.log_test("Real-time monitor", False, "State tracking incorrect")
                
        except Exception as e:
            self.log_test("Monitoring system", False, f"Exception: {str(e)}")
            
    def test_orchestrator_initialization(self):
        """Test that orchestrator can be initialized properly"""
        try:
            # Test with minimal configuration
            orchestrator = GenericOrchestrator(
                output_dir=self.temp_dir / "test_orchestrator",
                max_parallel=2,
                use_optimizations=False,  # Skip optimization for testing
                workflow_name="Test Workflow"
            )
            
            if orchestrator.output_dir.exists():
                self.log_test("Orchestrator initialization", True, "Orchestrator created successfully")
            else:
                self.log_test("Orchestrator initialization", False, "Output directory not created")
                
            # Test directory structure creation
            expected_dirs = ["metadata", "agents", "deliverables", "checkpoints"]
            missing_dirs = [d for d in expected_dirs if not (orchestrator.output_dir / d).exists()]
            
            if not missing_dirs:
                self.log_test("Directory structure", True, "All required directories created")
            else:
                self.log_test("Directory structure", False, f"Missing directories: {missing_dirs}")
                
        except Exception as e:
            self.log_test("Orchestrator initialization", False, f"Exception: {str(e)}")
            
    def test_task_validation(self):
        """Test task validation and dependency checking"""
        try:
            builder = ComprehensiveDemoBuilder(self.temp_dir)
            
            # Get dependency demo tasks (has complex dependencies)
            tasks = builder.build_dependency_demo_tasks()
            
            # Check dependency structure
            task_ids = {task.task_id for task in tasks}
            invalid_deps = []
            
            for task in tasks:
                for dep in task.dependencies:
                    if dep not in task_ids:
                        invalid_deps.append(f"{task.task_id} -> {dep}")
                        
            if not invalid_deps:
                self.log_test("Dependency validation", True, "All dependencies are valid")
            else:
                self.log_test("Dependency validation", False, f"Invalid deps: {invalid_deps}")
                
            # Check for circular dependencies (basic check)
            has_circular = False
            for task in tasks:
                if task.task_id in task.dependencies:
                    has_circular = True
                    break
                    
            if not has_circular:
                self.log_test("Circular dependency check", True, "No obvious circular dependencies")
            else:
                self.log_test("Circular dependency check", False, "Found circular dependency")
                
        except Exception as e:
            self.log_test("Task validation", False, f"Exception: {str(e)}")
            
    def test_demo_task_examples_loading(self):
        """Test loading of demo task examples JSON"""
        try:
            examples_file = Path("demo_task_examples.json")
            if examples_file.exists():
                with open(examples_file, 'r') as f:
                    examples = json.load(f)
                    
                required_sections = ["demo_task_library", "monitoring_examples", "customization_templates"]
                missing_sections = [s for s in required_sections if s not in examples]
                
                if not missing_sections:
                    self.log_test("Task examples loading", True, "All example sections present")
                else:
                    self.log_test("Task examples loading", False, f"Missing sections: {missing_sections}")
            else:
                self.log_test("Task examples loading", False, "demo_task_examples.json not found")
                
        except Exception as e:
            self.log_test("Task examples loading", False, f"Exception: {str(e)}")
            
    def test_comprehensive_demo_script(self):
        """Test the main comprehensive demo script functionality"""
        try:
            builder = ComprehensiveDemoBuilder(self.temp_dir)
            
            # Test all demo types can be built
            demo_types = ["basic", "parallel", "dependencies", "monitoring"]
            
            for demo_type in demo_types:
                try:
                    if demo_type == "basic":
                        tasks = builder.build_basic_demo_tasks()
                    elif demo_type == "parallel":
                        tasks = builder.build_parallel_demo_tasks()
                    elif demo_type == "dependencies":
                        tasks = builder.build_dependency_demo_tasks()
                    elif demo_type == "monitoring":
                        tasks = builder.build_monitoring_demo_tasks()
                        
                    if len(tasks) > 0:
                        self.log_test(f"Demo type '{demo_type}'", True, f"Generated {len(tasks)} tasks")
                    else:
                        self.log_test(f"Demo type '{demo_type}'", False, "No tasks generated")
                        
                except Exception as e:
                    self.log_test(f"Demo type '{demo_type}'", False, f"Exception: {str(e)}")
                    
        except Exception as e:
            self.log_test("Comprehensive demo script", False, f"Exception: {str(e)}")
            
    async def run_all_tests(self):
        """Run all validation tests"""
        print("🧪 AGENT ORCHESTRATOR DEMO SYSTEM VALIDATION")
        print("=" * 60)
        
        test_methods = [
            self.test_task_generation,
            self.test_monitoring_system,
            self.test_orchestrator_initialization,
            self.test_task_validation,
            self.test_demo_task_examples_loading,
            self.test_comprehensive_demo_script
        ]
        
        for test_method in test_methods:
            print(f"\n🔍 Running {test_method.__name__}...")
            test_method()
            
        # Summary
        print("\n" + "=" * 60)
        print("📊 VALIDATION SUMMARY")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for r in self.test_results if r["success"])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {passed_tests/total_tests*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ Failed Tests:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"   • {result['test']}: {result['message']}")
                    
        print("\n" + "=" * 60)
        
        # Overall result
        if failed_tests == 0:
            print("🎉 ALL TESTS PASSED - Demo system is ready!")
            return True
        else:
            print("⚠️  SOME TESTS FAILED - Check issues before running demos")
            return False
            
    def cleanup(self):
        """Clean up test artifacts"""
        import shutil
        try:
            shutil.rmtree(self.temp_dir)
        except Exception:
            pass


async def main():
    """Main test runner"""
    validator = DemoSystemValidator()
    
    try:
        success = await validator.run_all_tests()
        
        if success:
            print("\n✅ Demo system validation complete - you can run the demos!")
            print("\nTo run demos:")
            print("  python comprehensive_demo.py basic      # Basic multi-agent demo")
            print("  python comprehensive_demo.py --info     # See all demo types")
            return 0
        else:
            print("\n❌ Demo system validation failed - fix issues before running demos")
            return 1
            
    finally:
        validator.cleanup()


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)