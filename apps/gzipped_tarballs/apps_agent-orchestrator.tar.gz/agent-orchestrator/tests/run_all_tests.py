#!/usr/bin/env python3
"""
Comprehensive Test Runner for DPO System

Provides automated execution of all test suites with reporting,
coverage analysis, and performance benchmarking.
"""

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
import xml.etree.ElementTree as ET

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))


@dataclass
class TestResult:
    """Test result summary"""
    suite_name: str
    total_tests: int
    passed_tests: int
    failed_tests: int
    skipped_tests: int
    duration: float
    coverage_percentage: float = 0.0
    errors: List[str] = None
    warnings: List[str] = None


@dataclass
class TestSummary:
    """Overall test summary"""
    total_suites: int
    total_tests: int
    total_passed: int
    total_failed: int
    total_skipped: int
    total_duration: float
    overall_coverage: float
    suite_results: List[TestResult]
    start_time: str
    end_time: str


class DPOTestRunner:
    """Comprehensive test runner for DPO system"""
    
    def __init__(self, verbose: bool = False, coverage: bool = True, performance: bool = True):
        self.verbose = verbose
        self.coverage = coverage
        self.performance = performance
        self.results: List[TestResult] = []
        self.test_dir = Path(__file__).parent
        self.project_root = self.test_dir.parent
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO if verbose else logging.WARNING,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    async def run_all_tests(self, test_types: Optional[List[str]] = None) -> TestSummary:
        """Run all test suites"""
        start_time = time.time()
        start_time_str = time.strftime("%Y-%m-%d %H:%M:%S")
        
        self.logger.info("Starting comprehensive DPO test execution")
        
        # Define test suites
        test_suites = {
            "unit": {
                "path": "tests/unit/",
                "description": "Unit tests for individual components",
                "markers": "unit",
                "timeout": 300
            },
            "integration": {
                "path": "tests/integration/",
                "description": "Integration tests for component interactions",
                "markers": "integration",
                "timeout": 600
            },
            "system": {
                "path": "tests/system/",
                "description": "End-to-end system tests",
                "markers": "system",
                "timeout": 1200
            },
            "performance": {
                "path": "tests/performance/",
                "description": "Performance benchmarks and load tests",
                "markers": "performance",
                "timeout": 1800
            }
        }
        
        # Filter test suites if specified
        if test_types:
            test_suites = {k: v for k, v in test_suites.items() if k in test_types}
        
        # Run each test suite
        for suite_name, suite_config in test_suites.items():
            self.logger.info(f"Running {suite_name} tests: {suite_config['description']}")
            
            result = await self.run_test_suite(
                suite_name,
                suite_config["path"],
                suite_config["markers"],
                suite_config["timeout"]
            )
            
            self.results.append(result)
            
            if result.failed_tests > 0:
                self.logger.warning(f"{suite_name} tests had {result.failed_tests} failures")
        
        end_time = time.time()
        end_time_str = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # Generate summary
        summary = self._generate_summary(start_time_str, end_time_str, end_time - start_time)
        
        # Generate reports
        await self._generate_reports(summary)
        
        return summary
    
    async def run_test_suite(self, suite_name: str, test_path: str, markers: str, timeout: int) -> TestResult:
        """Run a single test suite"""
        
        # Build pytest command
        cmd = [
            sys.executable, "-m", "pytest",
            str(self.project_root / test_path),
            "-v" if self.verbose else "-q",
            f"-m", markers,
            "--tb=short",
            "--junit-xml", f"test-results-{suite_name}.xml"
        ]
        
        # Add coverage if enabled
        if self.coverage and suite_name != "performance":
            cmd.extend([
                "--cov=src",
                "--cov-report=xml",
                "--cov-report=term-missing",
                f"--cov-report=html:coverage-{suite_name}"
            ])
        
        # Add performance-specific options
        if suite_name == "performance":
            cmd.extend([
                "--benchmark-only",
                "--benchmark-json=benchmark-results.json"
            ])
        
        self.logger.info(f"Executing: {' '.join(cmd)}")
        
        start_time = time.time()
        
        try:
            # Run the test suite
            result = subprocess.run(
                cmd,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            duration = time.time() - start_time
            
            # Parse results
            test_result = self._parse_test_results(
                suite_name,
                result.returncode,
                result.stdout,
                result.stderr,
                duration
            )
            
            if self.verbose:
                self.logger.info(f"Test output:\n{result.stdout}")
                if result.stderr:
                    self.logger.warning(f"Test errors:\n{result.stderr}")
            
            return test_result
            
        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            self.logger.error(f"{suite_name} tests timed out after {timeout} seconds")
            
            return TestResult(
                suite_name=suite_name,
                total_tests=0,
                passed_tests=0,
                failed_tests=1,
                skipped_tests=0,
                duration=duration,
                errors=[f"Test suite timed out after {timeout} seconds"]
            )
        
        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"Error running {suite_name} tests: {e}")
            
            return TestResult(
                suite_name=suite_name,
                total_tests=0,
                passed_tests=0,
                failed_tests=1,
                skipped_tests=0,
                duration=duration,
                errors=[f"Test execution failed: {str(e)}"]
            )
    
    def _parse_test_results(self, suite_name: str, return_code: int, stdout: str, stderr: str, duration: float) -> TestResult:
        """Parse pytest results from output"""
        
        errors = []
        warnings = []
        
        if stderr:
            errors.append(stderr)
        
        # Try to parse XML results first
        xml_file = self.project_root / f"test-results-{suite_name}.xml"
        if xml_file.exists():
            try:
                tree = ET.parse(xml_file)
                root = tree.getroot()
                
                total_tests = int(root.get("tests", 0))
                passed_tests = total_tests - int(root.get("failures", 0)) - int(root.get("errors", 0)) - int(root.get("skipped", 0))
                failed_tests = int(root.get("failures", 0)) + int(root.get("errors", 0))
                skipped_tests = int(root.get("skipped", 0))
                
            except Exception as e:
                self.logger.warning(f"Could not parse XML results: {e}")
                total_tests, passed_tests, failed_tests, skipped_tests = self._parse_stdout_results(stdout)
        else:
            total_tests, passed_tests, failed_tests, skipped_tests = self._parse_stdout_results(stdout)
        
        # Parse coverage if available
        coverage_percentage = 0.0
        if self.coverage and suite_name != "performance":
            coverage_percentage = self._parse_coverage_results(suite_name)
        
        return TestResult(
            suite_name=suite_name,
            total_tests=total_tests,
            passed_tests=passed_tests,
            failed_tests=failed_tests,
            skipped_tests=skipped_tests,
            duration=duration,
            coverage_percentage=coverage_percentage,
            errors=errors if errors else None,
            warnings=warnings if warnings else None
        )
    
    def _parse_stdout_results(self, stdout: str) -> Tuple[int, int, int, int]:
        """Parse test results from stdout"""
        lines = stdout.split('\n')
        
        # Look for pytest summary line
        for line in lines:
            if "passed" in line or "failed" in line:
                # Parse patterns like "5 passed, 2 failed, 1 skipped"
                parts = line.split(',')
                total_tests = 0
                passed_tests = 0
                failed_tests = 0
                skipped_tests = 0
                
                for part in parts:
                    part = part.strip()
                    if "passed" in part:
                        passed_tests = int(part.split()[0])
                        total_tests += passed_tests
                    elif "failed" in part:
                        failed_tests = int(part.split()[0])
                        total_tests += failed_tests
                    elif "skipped" in part:
                        skipped_tests = int(part.split()[0])
                        total_tests += skipped_tests
                
                return total_tests, passed_tests, failed_tests, skipped_tests
        
        return 0, 0, 0, 0
    
    def _parse_coverage_results(self, suite_name: str) -> float:
        """Parse coverage percentage from results"""
        coverage_xml = self.project_root / "coverage.xml"
        if coverage_xml.exists():
            try:
                tree = ET.parse(coverage_xml)
                root = tree.getroot()
                coverage = float(root.get("line-rate", 0)) * 100
                return coverage
            except Exception as e:
                self.logger.warning(f"Could not parse coverage results: {e}")
        
        return 0.0
    
    def _generate_summary(self, start_time: str, end_time: str, total_duration: float) -> TestSummary:
        """Generate overall test summary"""
        
        total_suites = len(self.results)
        total_tests = sum(r.total_tests for r in self.results)
        total_passed = sum(r.passed_tests for r in self.results)
        total_failed = sum(r.failed_tests for r in self.results)
        total_skipped = sum(r.skipped_tests for r in self.results)
        
        # Calculate overall coverage (weighted average)
        if self.coverage:
            coverage_results = [r for r in self.results if r.coverage_percentage > 0]
            if coverage_results:
                total_coverage = sum(r.coverage_percentage * r.total_tests for r in coverage_results)
                total_tests_with_coverage = sum(r.total_tests for r in coverage_results)
                overall_coverage = total_coverage / total_tests_with_coverage if total_tests_with_coverage > 0 else 0
            else:
                overall_coverage = 0
        else:
            overall_coverage = 0
        
        return TestSummary(
            total_suites=total_suites,
            total_tests=total_tests,
            total_passed=total_passed,
            total_failed=total_failed,
            total_skipped=total_skipped,
            total_duration=total_duration,
            overall_coverage=overall_coverage,
            suite_results=self.results,
            start_time=start_time,
            end_time=end_time
        )
    
    async def _generate_reports(self, summary: TestSummary):
        """Generate test reports"""
        
        # Generate JSON report
        json_report = {
            "summary": asdict(summary),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "metadata": {
                "python_version": sys.version,
                "platform": sys.platform,
                "coverage_enabled": self.coverage,
                "performance_enabled": self.performance
            }
        }
        
        json_file = self.project_root / "test-results.json"
        with open(json_file, 'w') as f:
            json.dump(json_report, f, indent=2)
        
        self.logger.info(f"JSON report saved to {json_file}")
        
        # Generate console report
        self._print_console_report(summary)
        
        # Generate HTML report if requested
        if self.verbose:
            await self._generate_html_report(summary)
    
    def _print_console_report(self, summary: TestSummary):
        """Print comprehensive console report"""
        
        print("\n" + "="*80)
        print("DPO COMPREHENSIVE TEST RESULTS")
        print("="*80)
        
        print(f"Execution Time: {summary.start_time} - {summary.end_time}")
        print(f"Total Duration: {summary.total_duration:.2f} seconds")
        print()
        
        # Overall summary
        print("OVERALL SUMMARY:")
        print(f"  Test Suites: {summary.total_suites}")
        print(f"  Total Tests: {summary.total_tests}")
        print(f"  Passed:      {summary.total_passed} ({summary.total_passed/summary.total_tests*100:.1f}%)" if summary.total_tests > 0 else "  Passed:      0 (0.0%)")
        print(f"  Failed:      {summary.total_failed} ({summary.total_failed/summary.total_tests*100:.1f}%)" if summary.total_tests > 0 else "  Failed:      0 (0.0%)")
        print(f"  Skipped:     {summary.total_skipped} ({summary.total_skipped/summary.total_tests*100:.1f}%)" if summary.total_tests > 0 else "  Skipped:     0 (0.0%)")
        
        if self.coverage:
            print(f"  Coverage:    {summary.overall_coverage:.1f}%")
        
        print()
        
        # Suite-by-suite results
        print("SUITE RESULTS:")
        print("-" * 80)
        
        for result in summary.suite_results:
            status = "PASS" if result.failed_tests == 0 else "FAIL"
            print(f"{result.suite_name.upper():12} | {status:4} | {result.passed_tests:3}/{result.total_tests:3} | {result.duration:6.2f}s", end="")
            
            if self.coverage and result.coverage_percentage > 0:
                print(f" | Coverage: {result.coverage_percentage:5.1f}%", end="")
            
            print()
            
            if result.errors:
                for error in result.errors[:3]:  # Show first 3 errors
                    print(f"    ERROR: {error[:100]}...")
        
        print("-" * 80)
        
        # Final status
        overall_status = "SUCCESS" if summary.total_failed == 0 else "FAILURE"
        print(f"\nFINAL RESULT: {overall_status}")
        
        if summary.total_failed > 0:
            print(f"❌ {summary.total_failed} tests failed - see details above")
        else:
            print("✅ All tests passed successfully")
        
        print("="*80)
    
    async def _generate_html_report(self, summary: TestSummary):
        """Generate HTML report"""
        
        html_template = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>DPO Test Results</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #f0f0f0; padding: 20px; border-radius: 5px; }}
                .summary {{ margin: 20px 0; }}
                .suite {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; }}
                .pass {{ background-color: #d4edda; }}
                .fail {{ background-color: #f8d7da; }}
                .metrics {{ display: flex; gap: 20px; }}
                .metric {{ text-align: center; padding: 10px; background-color: #e9ecef; border-radius: 5px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>DPO Comprehensive Test Results</h1>
                <p>Executed: {summary.start_time} - {summary.end_time}</p>
                <p>Duration: {summary.total_duration:.2f} seconds</p>
            </div>
            
            <div class="summary">
                <h2>Overall Summary</h2>
                <div class="metrics">
                    <div class="metric">
                        <h3>{summary.total_tests}</h3>
                        <p>Total Tests</p>
                    </div>
                    <div class="metric">
                        <h3>{summary.total_passed}</h3>
                        <p>Passed</p>
                    </div>
                    <div class="metric">
                        <h3>{summary.total_failed}</h3>
                        <p>Failed</p>
                    </div>
                    <div class="metric">
                        <h3>{summary.overall_coverage:.1f}%</h3>
                        <p>Coverage</p>
                    </div>
                </div>
            </div>
            
            <div class="suites">
                <h2>Test Suite Results</h2>
                {''.join(self._generate_suite_html(result) for result in summary.suite_results)}
            </div>
        </body>
        </html>
        """
        
        html_file = self.project_root / "test-results.html"
        with open(html_file, 'w') as f:
            f.write(html_template)
        
        self.logger.info(f"HTML report saved to {html_file}")
    
    def _generate_suite_html(self, result: TestResult) -> str:
        """Generate HTML for a single suite"""
        
        status_class = "pass" if result.failed_tests == 0 else "fail"
        
        return f"""
        <div class="suite {status_class}">
            <h3>{result.suite_name.title()} Tests</h3>
            <p>Status: {'PASS' if result.failed_tests == 0 else 'FAIL'}</p>
            <p>Results: {result.passed_tests}/{result.total_tests} passed ({result.passed_tests/result.total_tests*100:.1f}%)</p>
            <p>Duration: {result.duration:.2f} seconds</p>
            {f'<p>Coverage: {result.coverage_percentage:.1f}%</p>' if result.coverage_percentage > 0 else ''}
            {f'<div class="errors"><h4>Errors:</h4><ul>{"".join(f"<li>{error}</li>" for error in (result.errors or []))}</ul></div>' if result.errors else ''}
        </div>
        """


async def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Run comprehensive DPO tests")
    parser.add_argument("--types", nargs="+", choices=["unit", "integration", "system", "performance"],
                       help="Specific test types to run (default: all)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument("--no-coverage", action="store_true", help="Disable coverage collection")
    parser.add_argument("--no-performance", action="store_true", help="Skip performance tests")
    parser.add_argument("--quick", action="store_true", help="Quick test run (unit tests only)")
    
    args = parser.parse_args()
    
    if args.quick:
        test_types = ["unit"]
    else:
        test_types = args.types
    
    runner = DPOTestRunner(
        verbose=args.verbose,
        coverage=not args.no_coverage,
        performance=not args.no_performance
    )
    
    try:
        summary = await runner.run_all_tests(test_types)
        
        # Exit with error code if tests failed
        sys.exit(1 if summary.total_failed > 0 else 0)
        
    except KeyboardInterrupt:
        print("\n❌ Test execution interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Test execution failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())