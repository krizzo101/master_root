#!/usr/bin/env python3
"""
End-to-end test for enhanced task validation with the orchestrator.
"""

import json
import sys
import tempfile
import shutil
from pathlib import Path

# Add the src directory to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import AgentTask, GenericOrchestrator


def test_enhanced_task_validation():
    """Test that enhanced tasks are properly validated by the orchestrator."""
    print("Testing enhanced task validation with orchestrator...")
    
    # Load the example enhanced task
    example_file = Path(__file__).parent / "example_enhanced_task.json"
    if not example_file.exists():
        print("✗ Example enhanced task file not found")
        return False
    
    try:
        with open(example_file) as f:
            task_data = json.load(f)
        
        # Create a temporary orchestrator
        temp_dir = Path(tempfile.mkdtemp(prefix="enhanced_task_test_"))
        orchestrator = GenericOrchestrator(
            output_dir=temp_dir,
            max_parallel=1
        )
        
        # Test with the first task from the example
        first_task_data = task_data["tasks"][0]
        
        # Create AgentTask with all new fields
        task = AgentTask(
            task_id=first_task_data["task_id"],
            task_type=first_task_data["task_type"],
            prompt=first_task_data["prompt"],
            context=first_task_data.get("context", {}),
            dependencies=first_task_data.get("dependencies", []),
            project_location=first_task_data.get("project_location"),
            deliverable_structure=first_task_data.get("deliverable_structure", {}),
            directory_permissions=first_task_data.get("directory_permissions", []),
            output_validation=first_task_data.get("output_validation", {})
        )
        
        print(f"✓ Created task: {task.task_id}")
        print(f"  - Project location: {task.project_location}")
        print(f"  - Deliverable structure keys: {list(task.deliverable_structure.keys())}")
        print(f"  - Directory permissions: {len(task.directory_permissions)} paths")
        print(f"  - Output validation rules: {len(task.output_validation)} rules")
        
        # Test validation
        validation_result = orchestrator._validate_task_project_organization(task)
        print(f"✓ Validation completed: {len(validation_result['warnings'])} warnings, {len(validation_result['suggestions'])} suggestions")
        
        # Test enhancement (should not change much since task is already enhanced)
        enhanced_task = orchestrator._enhance_task_with_project_organization(task)
        print(f"✓ Task enhancement completed")
        
        # Test command generation with directory permissions
        test_cmd = ["claude", "--session-id", "test"]
        enhanced_cmd = orchestrator._apply_task_directory_permissions(enhanced_task, test_cmd)
        
        # Count --add-dir parameters in the enhanced command
        add_dir_count = sum(1 for i in range(len(enhanced_cmd) - 1) if enhanced_cmd[i] == "--add-dir")
        print(f"✓ Command enhanced with {add_dir_count} --add-dir parameters")
        
        # Verify directory permissions were applied
        if hasattr(enhanced_task, 'directory_permissions') and enhanced_task.directory_permissions:
            for perm in enhanced_task.directory_permissions:
                if perm in enhanced_cmd:
                    print(f"  ✓ Directory permission applied: {perm}")
                else:
                    print(f"  ✗ Directory permission missing: {perm}")
                    return False
        
        # Test serialization of enhanced task
        task_dict = enhanced_task.to_dict()
        assert "project_location" in task_dict
        assert "deliverable_structure" in task_dict  
        assert "directory_permissions" in task_dict
        assert "output_validation" in task_dict
        print("✓ Enhanced task serialization successful")
        
        # Cleanup
        shutil.rmtree(temp_dir, ignore_errors=True)
        
        return True
        
    except Exception as e:
        print(f"✗ Enhanced task validation test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_auto_enhancement():
    """Test that tasks without organization fields are automatically enhanced."""
    print("Testing automatic task enhancement...")
    
    try:
        # Create a temporary orchestrator
        temp_dir = Path(tempfile.mkdtemp(prefix="auto_enhance_test_"))
        orchestrator = GenericOrchestrator(
            output_dir=temp_dir,
            max_parallel=1
        )
        
        # Create a task that should trigger auto-enhancement
        task = AgentTask(
            task_id="auto_enhance_test",
            task_type="development",
            prompt="Create a new project called super-cool-app with modern JavaScript framework"
        )
        
        print(f"✓ Created minimal task: {task.task_id}")
        print(f"  - Original project_location: {getattr(task, 'project_location', None)}")
        
        # Test enhancement
        enhanced_task = orchestrator._enhance_task_with_project_organization(task)
        
        # Verify enhancement occurred
        if hasattr(enhanced_task, 'project_location') and enhanced_task.project_location:
            print(f"✓ Auto-enhanced project_location: {enhanced_task.project_location}")
            
            # Verify it follows conventions
            assert "/apps/" in enhanced_task.project_location
            assert "super-cool-app" in enhanced_task.project_location
            print("✓ Project location follows conventions")
            
            # Verify other fields were added
            if hasattr(enhanced_task, 'deliverable_structure') and enhanced_task.deliverable_structure:
                print(f"✓ Auto-generated deliverable structure: {len(enhanced_task.deliverable_structure)} entries")
            
            if hasattr(enhanced_task, 'directory_permissions') and enhanced_task.directory_permissions:
                print(f"✓ Auto-generated directory permissions: {len(enhanced_task.directory_permissions)} paths")
                
            if hasattr(enhanced_task, 'output_validation') and enhanced_task.output_validation:
                print(f"✓ Auto-generated output validation: {len(enhanced_task.output_validation)} rules")
            
        else:
            print("ℹ No project creation detected (this is also valid behavior)")
        
        # Cleanup
        shutil.rmtree(temp_dir, ignore_errors=True)
        
        return True
        
    except Exception as e:
        print(f"✗ Auto-enhancement test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run enhanced task validation tests."""
    print("Running Enhanced Task Validation Tests")
    print("=" * 50)
    
    tests = [
        test_enhanced_task_validation,
        test_auto_enhancement
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
                print(f"✓ {test.__name__} PASSED")
            else:
                failed += 1
                print(f"✗ {test.__name__} FAILED")
        except Exception as e:
            failed += 1
            print(f"✗ {test.__name__} FAILED with exception: {e}")
        
        print()
    
    print("=" * 50)
    print(f"Enhanced Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All enhanced validation tests passed!")
        return 0
    else:
        print("❌ Some enhanced tests failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())