#!/usr/bin/env python3
"""
Test script for UnifiedOrchestrator integration
Tests all enabled features with a simple workflow
"""

import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from unified.unified_orchestrator import (
    UnifiedOrchestrator,
    UnifiedConfig,
    EnhancedAgentTask,
    FeatureFlag,
    create_minimal_orchestrator,
    create_standard_orchestrator,
    create_advanced_orchestrator,
)


async def test_minimal_profile():
    """Test minimal orchestrator with no extra features"""
    print("\n" + "=" * 60)
    print("TEST: Minimal Profile (No Extra Features)")
    print("=" * 60)
    
    orchestrator = create_minimal_orchestrator(
        output_dir=Path(f"output/test_minimal_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    )
    
    # Simple task
    tasks = [
        EnhancedAgentTask(
            task_id="test_001",
            task_type="simple",
            prompt="Test task for minimal orchestrator"
        )
    ]
    
    def process_result(r):
        print(f"Task completed: {r}")
    
    result = await orchestrator.run(
        task_generator=lambda: tasks,
        result_processor=process_result
    )
    
    print(f"✓ Minimal profile test completed")
    print(f"  Tasks: {result['metrics']['total']}")
    print(f"  Completed: {result['metrics']['completed']}")
    
    return result['metrics']['completed'] == 1


async def test_standard_profile():
    """Test standard orchestrator with common features"""
    print("\n" + "=" * 60)
    print("TEST: Standard Profile (Common Features)")
    print("=" * 60)
    
    orchestrator = create_standard_orchestrator(
        output_dir=Path(f"output/test_standard_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    )
    
    # Tasks with dependencies and phases
    tasks = [
        EnhancedAgentTask(
            task_id="plan_001",
            task_type="planning",
            prompt="Plan the test workflow",
            phase="planning",
            priority=10
        ),
        EnhancedAgentTask(
            task_id="exec_001",
            task_type="execution",
            prompt="Execute the plan",
            dependencies=["plan_001"],
            phase="execution",
            priority=5,
            # Simulate a task that might fail to test auto-recovery
            metrics={"fail_probability": 0.3}
        ),
        EnhancedAgentTask(
            task_id="validate_001",
            task_type="validation",
            prompt="Validate the results",
            dependencies=["exec_001"],
            phase="validation",
            priority=3
        )
    ]
    
    def process_batch(r):
        print(f"Batch completed: {len(r) if isinstance(r, list) else 1} tasks")
    
    result = await orchestrator.run(
        task_generator=lambda: tasks,
        result_processor=process_batch
    )
    
    print(f"✓ Standard profile test completed")
    print(f"  Tasks: {result['metrics']['total']}")
    print(f"  Completed: {result['metrics']['completed']}")
    print(f"  Recovery attempts: {result['enhanced_metrics'].get('recovery_attempts', 0)}")
    
    # Check execution plan was created
    if 'execution_plan' in str(result.get('module_status', {})):
        print(f"  ✓ Execution plan created")
    
    return result['metrics']['completed'] >= 2  # At least 2 should complete


async def test_advanced_profile():
    """Test advanced orchestrator with all features"""
    print("\n" + "=" * 60)
    print("TEST: Advanced Profile (All Features)")
    print("=" * 60)
    
    orchestrator = create_advanced_orchestrator(
        output_dir=Path(f"output/test_advanced_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    )
    
    # Complex workflow with teams, quality gates, and monitoring
    tasks = [
        # Team Alpha - Planning
        EnhancedAgentTask(
            task_id="research_001",
            task_type="research",
            prompt="Research best practices",
            phase="planning",
            priority=10,
            team_id="team_alpha",
            validation_required=True,
            quality_gates={"research_complete": False}
        ),
        EnhancedAgentTask(
            task_id="design_001",
            task_type="design",
            prompt="Create system design",
            dependencies=["research_001"],
            phase="preparation",
            priority=8,
            team_id="team_alpha",
            collaboration_mode="handoff"
        ),
        
        # Team Beta - Implementation
        EnhancedAgentTask(
            task_id="code_001",
            task_type="code",
            prompt="Implement core functionality",
            dependencies=["design_001"],
            phase="execution",
            priority=6,
            team_id="team_beta",
            validation_required=True,
            quality_gates={"syntax_check": False, "lint": False},
            collaboration_mode="shared"
        ),
        EnhancedAgentTask(
            task_id="code_002",
            task_type="code",
            prompt="Implement additional features",
            dependencies=["design_001"],
            phase="execution",
            priority=5,
            team_id="team_beta",
            execution_mode="parallel"  # Can run parallel with code_001
        ),
        
        # Team Gamma - Validation
        EnhancedAgentTask(
            task_id="test_001",
            task_type="test",
            prompt="Execute test suite",
            dependencies=["code_001", "code_002"],
            phase="validation",
            priority=3,
            team_id="team_gamma",
            validation_required=True,
            quality_gates={"test_coverage": False, "test_pass_rate": False},
            collaboration_mode="review"
        ),
        EnhancedAgentTask(
            task_id="review_001",
            task_type="review",
            prompt="Perform code review",
            dependencies=["code_001", "code_002"],
            phase="validation",
            priority=3,
            team_id="team_gamma",
            execution_mode="parallel"  # Can run parallel with test_001
        ),
        
        # Cleanup
        EnhancedAgentTask(
            task_id="docs_001",
            task_type="documentation",
            prompt="Generate documentation",
            dependencies=["test_001", "review_001"],
            phase="cleanup",
            priority=1,
            team_id="team_alpha",
            validation_required=True,
            quality_gates={"completeness_check": False}
        )
    ]
    
    # Add metrics to simulate realistic execution
    for task in tasks:
        task.metrics = {
            "estimated_duration": 5.0,
            "complexity": "high" if task.validation_required else "medium"
        }
    
    result = await orchestrator.run(
        task_generator=lambda: tasks
    )
    
    print(f"✓ Advanced profile test completed")
    print(f"  Tasks: {result['metrics']['total']}")
    print(f"  Completed: {result['metrics']['completed']}")
    print(f"  Failed: {result['metrics']['failed']}")
    
    # Check enhanced metrics
    enhanced = result.get('enhanced_metrics', {})
    if enhanced.get('tasks_by_status'):
        print(f"  Task status breakdown: {enhanced['tasks_by_status']}")
    
    if enhanced.get('team_performance'):
        print(f"  Teams involved: {len(enhanced['team_performance'])}")
        for team_id, perf in enhanced['team_performance'].items():
            print(f"    {team_id}: {perf['completed']} completed")
    
    if enhanced.get('checkpoint_saves', 0) > 0:
        print(f"  Checkpoints saved: {enhanced['checkpoint_saves']}")
    
    # Check module status
    modules = result.get('module_status', {})
    active_modules = sum(1 for m in modules.values() if m.get('enabled'))
    print(f"  Active modules: {active_modules}/{len(modules)}")
    
    return result['metrics']['completed'] >= 5  # Most should complete


async def test_execution_plan_integration():
    """Test execution plan module specifically"""
    print("\n" + "=" * 60)
    print("TEST: Execution Plan Module")
    print("=" * 60)
    
    config = UnifiedConfig(
        output_dir=Path(f"output/test_execution_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"),
        enabled_features={FeatureFlag.EXECUTION_PLAN}
    )
    
    orchestrator = UnifiedOrchestrator(config)
    
    # Create tasks with clear dependencies for phase generation
    tasks = [
        # Independent tasks - should be Phase 1
        EnhancedAgentTask(task_id="t1", task_type="type1", prompt="Task 1"),
        EnhancedAgentTask(task_id="t2", task_type="type2", prompt="Task 2"),
        
        # Dependent on Phase 1 - should be Phase 2
        EnhancedAgentTask(task_id="t3", task_type="type3", prompt="Task 3", dependencies=["t1"]),
        EnhancedAgentTask(task_id="t4", task_type="type4", prompt="Task 4", dependencies=["t2"]),
        
        # Dependent on Phase 2 - should be Phase 3
        EnhancedAgentTask(task_id="t5", task_type="type5", prompt="Task 5", dependencies=["t3", "t4"]),
    ]
    
    # Initialize modules
    await orchestrator._ensure_modules_loaded()
    
    # Check if execution plan module is loaded
    execution_module = None
    for module in orchestrator.module_registry.get_enabled_modules():
        if module.name == "execution_plan":
            execution_module = module
            break
    
    if execution_module:
        plan = execution_module.create_plan(tasks)
        print(f"✓ Execution plan created: {plan.plan_id}")
        print(f"  Phases: {len(plan.phases)}")
        print(f"  Total tasks: {plan.total_tasks}")
        
        for i, phase in enumerate(plan.phases):
            print(f"  Phase {i+1}: {len(phase.tasks)} tasks, mode={phase.execution_mode.value}")
        
        success = len(plan.phases) >= 2  # Should have at least 2 phases
    else:
        print("✗ Execution plan module not loaded")
        success = False
    
    await orchestrator.cleanup()
    return success


async def test_dpo_integration():
    """Test DPO enhanced task adapter integration"""
    print("\n" + "=" * 60)
    print("TEST: DPO Enhanced Task Integration")
    print("=" * 60)
    
    # Import DPO adapter
    sys.path.insert(0, '/home/opsvi/master_root/apps/dpo/src')
    from enhanced_task_adapter import EnhancedTaskAdapter
    from generic_orchestrator import AgentTask
    
    # Create regular task
    regular_task = AgentTask(
        task_id="dpo_test_001",
        task_type="coding_specialist",
        prompt="Implement authentication system"
    )
    
    # Convert to enhanced
    enhanced = EnhancedTaskAdapter.convert_task(regular_task)
    
    print(f"✓ Task conversion successful")
    print(f"  Original type: {regular_task.task_type}")
    print(f"  Enhanced phase: {enhanced.phase}")
    print(f"  Priority: {enhanced.priority}")
    print(f"  MCP needs: {enhanced.mcp_needs}")
    
    # Test batch conversion
    batch = [
        AgentTask(task_id="b1", task_type="planning_specialist", prompt="Plan"),
        AgentTask(task_id="b2", task_type="design_specialist", prompt="Design", dependencies=["b1"]),
        AgentTask(task_id="b3", task_type="coding_specialist", prompt="Code", dependencies=["b2"]),
    ]
    
    workflow_ctx = EnhancedTaskAdapter.create_workflow_context(
        workflow_name="test_workflow",
        workflow_type="build",
        priority="high"
    )
    
    enhanced_batch = EnhancedTaskAdapter.convert_batch(batch, workflow_ctx)
    
    print(f"✓ Batch conversion successful")
    print(f"  Converted {len(enhanced_batch)} tasks")
    print(f"  Workflow: {workflow_ctx['workflow_name']}")
    print(f"  Team: {workflow_ctx['team_id']}")
    
    # Verify phases are correct
    expected_phases = ["planning", "preparation", "execution"]
    actual_phases = [t.phase for t in enhanced_batch]
    
    success = actual_phases == expected_phases
    if success:
        print(f"  ✓ Phases correctly assigned: {actual_phases}")
    else:
        print(f"  ✗ Phase mismatch. Expected: {expected_phases}, Got: {actual_phases}")
    
    return success


async def run_all_tests():
    """Run all integration tests"""
    print("=" * 60)
    print("UNIFIED ORCHESTRATOR INTEGRATION TESTS")
    print("=" * 60)
    print(f"Starting at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    test_results = {}
    
    # Run tests
    tests = [
        ("Minimal Profile", test_minimal_profile),
        ("Standard Profile", test_standard_profile),
        ("Advanced Profile", test_advanced_profile),
        ("Execution Plan Module", test_execution_plan_integration),
        ("DPO Integration", test_dpo_integration),
    ]
    
    for test_name, test_func in tests:
        try:
            success = await test_func()
            test_results[test_name] = "PASSED" if success else "FAILED"
        except Exception as e:
            test_results[test_name] = f"ERROR: {str(e)}"
            print(f"\n✗ {test_name} failed with error: {e}")
            import traceback
            traceback.print_exc()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for r in test_results.values() if r == "PASSED")
    total = len(test_results)
    
    for test_name, result in test_results.items():
        icon = "✓" if result == "PASSED" else "✗"
        print(f"{icon} {test_name}: {result}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    # Save test report
    report = {
        "timestamp": datetime.now().isoformat(),
        "test_results": test_results,
        "summary": {
            "total": total,
            "passed": passed,
            "failed": total - passed
        }
    }
    
    report_file = Path(f"output/test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text(json.dumps(report, indent=2))
    print(f"\nTest report saved to: {report_file}")
    
    return passed == total


if __name__ == "__main__":
    # Run all tests
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)