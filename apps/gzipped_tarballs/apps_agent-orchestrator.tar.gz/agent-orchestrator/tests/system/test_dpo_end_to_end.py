#!/usr/bin/env python3
"""
System-Level End-to-End Tests for DPO

Tests complete workflows and real-world user scenarios,
including CLI interface, API endpoints, and full system behavior.
"""

import asyncio
import json
import pytest
import subprocess
import tempfile
import time
import yaml
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch
import requests
from dataclasses import asdict

import sys
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.dpo_main_controller import DevelopmentProcessOrchestrator, DPOConfiguration
from tests.fixtures.mock_orchestrator import MockOrchestratorServer
from tests.fixtures.sample_data import SampleRequestGenerator


class TestDPOEndToEndWorkflows:
    """Test complete end-to-end DPO workflows"""
    
    @pytest.fixture
    def e2e_config(self):
        """Configuration for end-to-end testing"""
        return DPOConfiguration(
            output_base_dir="e2e_test_output",
            max_parallel_agents=5,
            enable_websocket=True,
            websocket_port=8767,
            enable_intelligence=True,
            enable_context_injection=True,
            enable_dashboard=False,
            auto_recovery=True
        )
    
    @pytest.fixture
    def sample_requests(self):
        """Comprehensive sample requests for testing"""
        generator = SampleRequestGenerator()
        return {
            "simple_api": generator.get_api_request("simple"),
            "complex_webapp": generator.get_webapp_request("complex"),
            "cli_tool": generator.get_cli_request("medium"),
            "integration_service": generator.get_integration_request("enterprise"),
            "library": generator.get_library_request("open_source")
        }
    
    @pytest.fixture
    async def mock_orchestrator_server(self):
        """Start mock orchestrator server for testing"""
        server = MockOrchestratorServer(port=8080)
        await server.start()
        yield server
        await server.stop()
    
    @pytest.mark.asyncio
    async def test_simple_api_development_workflow(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test complete workflow for simple API development"""
        
        request_data = sample_requests["simple_api"]
        
        # Setup DPO with real components (but mocked orchestrator)
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        # Process the request
        start_time = time.time()
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        processing_time = time.time() - start_time
        
        # Validate processing time requirement (<30 seconds)
        assert processing_time < 30, f"Processing took {processing_time:.2f} seconds, exceeds 30s limit"
        
        # Validate result structure
        assert result.workflow_id is not None
        assert result.status in ["submitted", "running", "completed"]
        assert result.output_dir is not None
        
        # Validate processing phases completion
        assert result.phases["analysis"] is True
        assert result.phases["intelligence_review"] is True
        assert result.phases["workflow_generation"] is True
        assert result.phases["context_injection"] is True
        assert result.phases["orchestrator_submission"] is True
        
        # Validate workflow characteristics for API project
        workflow_details = await dpo.get_workflow_status(result.workflow_id)
        assert workflow_details is not None
        
        # For simple API, should have reasonable agent count
        if "agent_count" in workflow_details:
            assert 3 <= workflow_details["agent_count"] <= 8
    
    @pytest.mark.asyncio
    async def test_complex_webapp_workflow(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test complete workflow for complex web application"""
        
        request_data = sample_requests["complex_webapp"]
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        
        # Complex webapp should have more agents due to complexity
        workflow_details = await dpo.get_workflow_status(result.workflow_id)
        if "agent_count" in workflow_details:
            assert workflow_details["agent_count"] >= 8  # Complex projects need more agents
        
        # Should include frontend and backend phases
        if "phases" in workflow_details:
            phase_names = [phase.get("phase_name", "").lower() for phase in workflow_details["phases"]]
            has_frontend_phase = any("frontend" in name or "ui" in name for name in phase_names)
            has_backend_phase = any("backend" in name or "api" in name for name in phase_names)
            assert has_frontend_phase or has_backend_phase  # Should have specialized phases
    
    @pytest.mark.asyncio
    async def test_cli_tool_workflow(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test complete workflow for CLI tool development"""
        
        request_data = sample_requests["cli_tool"]
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        
        # CLI tools typically have simpler architecture
        workflow_details = await dpo.get_workflow_status(result.workflow_id)
        if "phases" in workflow_details:
            # Should include testing phase for CLI tools
            phase_names = [phase.get("phase_name", "").lower() for phase in workflow_details["phases"]]
            has_testing_phase = any("test" in name for name in phase_names)
            assert has_testing_phase  # CLI tools need thorough testing
    
    @pytest.mark.asyncio
    async def test_integration_service_workflow(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test complete workflow for integration service development"""
        
        request_data = sample_requests["integration_service"]
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        
        # Integration services should include error handling and monitoring
        workflow_details = await dpo.get_workflow_status(result.workflow_id)
        if "phases" in workflow_details:
            phase_names = [phase.get("phase_name", "").lower() for phase in workflow_details["phases"]]
            has_monitoring = any("monitor" in name or "observability" in name for name in phase_names)
            has_error_handling = any("error" in name or "resilience" in name for name in phase_names)
            # At least one of these should be present for enterprise integration
            assert has_monitoring or has_error_handling
    
    @pytest.mark.asyncio
    async def test_concurrent_workflow_processing(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test concurrent processing of multiple workflows"""
        
        e2e_config.max_parallel_agents = 3  # Limit for testing
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        # Start multiple workflows concurrently
        tasks = []
        request_types = ["simple_api", "cli_tool"]  # Use simpler requests for concurrent testing
        
        for req_type in request_types:
            request_data = sample_requests[req_type]
            task = asyncio.create_task(
                dpo.process_request(request_data["request"], request_data["context"])
            )
            tasks.append(task)
        
        # Wait for all workflows to complete
        results = await asyncio.gather(*tasks)
        
        # Verify all workflows were processed successfully
        assert len(results) == 2
        for result in results:
            assert result.workflow_id is not None
            assert result.status in ["submitted", "running", "completed"]
    
    @pytest.mark.asyncio
    async def test_workflow_status_monitoring(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test real-time workflow status monitoring"""
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        request_data = sample_requests["simple_api"]
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        
        workflow_id = result.workflow_id
        
        # Monitor status over time
        status_history = []
        for _ in range(3):  # Check status 3 times
            status = await dpo.get_workflow_status(workflow_id)
            status_history.append(status)
            await asyncio.sleep(0.5)  # Brief delay between checks
        
        # Verify status responses are consistent
        for status in status_history:
            assert "status" in status
            assert "workflow_id" in status
            assert status["workflow_id"] == workflow_id
    
    @pytest.mark.asyncio
    async def test_workflow_cancellation_and_cleanup(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test workflow cancellation and resource cleanup"""
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        request_data = sample_requests["complex_webapp"]  # Use complex request for longer processing
        result = await dpo.process_request(
            request_data["request"],
            request_data["context"]
        )
        
        workflow_id = result.workflow_id
        
        # Wait briefly then cancel
        await asyncio.sleep(0.1)
        cancel_result = await dpo.cancel_workflow(workflow_id)
        
        # Verify cancellation
        assert cancel_result["status"] == "cancelled"
        assert cancel_result["workflow_id"] == workflow_id
        
        # Verify status reflects cancellation
        final_status = await dpo.get_workflow_status(workflow_id)
        assert final_status["status"] in ["cancelled", "failed"]
    
    @pytest.mark.asyncio
    async def test_error_recovery_and_resilience(self, e2e_config, sample_requests):
        """Test error recovery and system resilience"""
        
        e2e_config.auto_recovery = True
        
        # Simulate component failure and recovery
        failure_count = 0
        
        def failing_orchestrator_call(*args, **kwargs):
            nonlocal failure_count
            failure_count += 1
            if failure_count <= 2:  # Fail first 2 calls
                raise Exception("Simulated orchestrator failure")
            # Succeed on subsequent calls
            return {
                "workflow_id": "recovered_123",
                "status": "submitted",
                "output_dir": "/test/recovered"
            }
        
        with patch('src.dpo_orchestrator_integration.DPOOrchestrator') as mock_orch_class:
            mock_orch = AsyncMock()
            mock_orch.submit_workflow.side_effect = failing_orchestrator_call
            mock_orch_class.return_value = mock_orch
            
            dpo = DevelopmentProcessOrchestrator(e2e_config)
            await dpo.initialize()
            
            request_data = sample_requests["simple_api"]
            
            # Should eventually succeed despite initial failures
            result = await dpo.process_request(
                request_data["request"],
                request_data["context"]
            )
            
            assert result.workflow_id == "recovered_123"
            assert failure_count == 3  # Failed twice, succeeded on third attempt
    
    @pytest.mark.asyncio
    async def test_performance_benchmarks(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test performance benchmarks and validation"""
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        performance_results = {}
        
        for request_type, request_data in sample_requests.items():
            start_time = time.time()
            
            result = await dpo.process_request(
                request_data["request"],
                request_data["context"]
            )
            
            processing_time = time.time() - start_time
            performance_results[request_type] = {
                "processing_time": processing_time,
                "workflow_id": result.workflow_id,
                "success": result.status in ["submitted", "running", "completed"]
            }
        
        # Validate performance requirements
        for request_type, metrics in performance_results.items():
            assert metrics["success"], f"Request {request_type} failed"
            
            # Different complexity levels have different time requirements
            if request_type == "simple_api":
                assert metrics["processing_time"] < 15, f"Simple API took {metrics['processing_time']:.2f}s"
            elif request_type == "complex_webapp":
                assert metrics["processing_time"] < 30, f"Complex webapp took {metrics['processing_time']:.2f}s"
            else:
                assert metrics["processing_time"] < 25, f"{request_type} took {metrics['processing_time']:.2f}s"
        
        # Overall system performance
        avg_processing_time = sum(m["processing_time"] for m in performance_results.values()) / len(performance_results)
        assert avg_processing_time < 20, f"Average processing time {avg_processing_time:.2f}s exceeds target"
    
    @pytest.mark.asyncio
    async def test_quality_validation(self, e2e_config, sample_requests, mock_orchestrator_server):
        """Test output quality validation"""
        
        dpo = DevelopmentProcessOrchestrator(e2e_config)
        await dpo.initialize()
        
        quality_results = {}
        
        for request_type, request_data in sample_requests.items():
            result = await dpo.process_request(
                request_data["request"],
                request_data["context"]
            )
            
            # Get workflow details for quality analysis
            workflow_details = await dpo.get_workflow_status(result.workflow_id)
            
            quality_score = await self._assess_workflow_quality(workflow_details, request_type)
            quality_results[request_type] = quality_score
        
        # Validate quality requirements
        for request_type, quality_score in quality_results.items():
            assert quality_score >= 0.8, f"Quality score for {request_type}: {quality_score:.2f} below threshold"
        
        # Average quality should be high
        avg_quality = sum(quality_results.values()) / len(quality_results)
        assert avg_quality >= 0.85, f"Average quality {avg_quality:.2f} below target"
    
    async def _assess_workflow_quality(self, workflow_details, request_type):
        """Assess workflow quality based on completeness and appropriateness"""
        score = 0.0
        max_score = 0.0
        
        # Check for required phases
        required_phases = ["discovery", "implementation", "testing"]
        if request_type in ["complex_webapp", "integration_service"]:
            required_phases.extend(["architecture", "deployment"])
        
        if "phases" in workflow_details:
            phases = workflow_details["phases"]
            phase_names = [p.get("phase_name", "").lower() for p in phases]
            
            for required_phase in required_phases:
                max_score += 1.0
                if any(required_phase in name for name in phase_names):
                    score += 1.0
        
        # Check agent count appropriateness
        if "agent_count" in workflow_details:
            agent_count = workflow_details["agent_count"]
            max_score += 1.0
            
            if request_type == "simple_api" and 3 <= agent_count <= 8:
                score += 1.0
            elif request_type == "complex_webapp" and 8 <= agent_count <= 15:
                score += 1.0
            elif request_type == "cli_tool" and 3 <= agent_count <= 6:
                score += 1.0
            elif request_type == "integration_service" and 6 <= agent_count <= 12:
                score += 1.0
            elif 3 <= agent_count <= 15:  # Reasonable range
                score += 0.5
        
        return score / max_score if max_score > 0 else 0.0


class TestDPOCLIInterface:
    """Test DPO command-line interface"""
    
    @pytest.fixture
    def cli_script_path(self):
        """Path to DPO CLI script"""
        return Path(__file__).parent.parent.parent / "dpo_cli.py"
    
    def test_cli_help_command(self, cli_script_path):
        """Test CLI help command"""
        result = subprocess.run(
            ["python", str(cli_script_path), "--help"],
            capture_output=True,
            text=True
        )
        
        assert result.returncode == 0
        assert "Development Process Orchestrator" in result.stdout
        assert "build" in result.stdout
        assert "status" in result.stdout
    
    def test_cli_build_command(self, cli_script_path):
        """Test CLI build command with mocked backend"""
        
        with patch('src.dpo_main_controller.DevelopmentProcessOrchestrator') as mock_dpo_class:
            mock_dpo = AsyncMock()
            mock_dpo.process_request.return_value = Mock(
                workflow_id="cli_test_123",
                status="submitted",
                output_dir="/test/cli_output"
            )
            mock_dpo_class.return_value = mock_dpo
            
            result = subprocess.run([
                "python", str(cli_script_path), "build",
                "--request", "Build a simple API",
                "--framework", "FastAPI",
                "--no-interactive"
            ], capture_output=True, text=True)
            
            # CLI should complete successfully
            assert result.returncode == 0 or "workflow_id" in result.stdout
    
    def test_cli_status_command(self, cli_script_path):
        """Test CLI status command"""
        
        with patch('src.dpo_main_controller.DevelopmentProcessOrchestrator') as mock_dpo_class:
            mock_dpo = AsyncMock()
            mock_dpo.get_workflow_status.return_value = {
                "workflow_id": "status_test_123",
                "status": "running",
                "progress": 0.6
            }
            mock_dpo_class.return_value = mock_dpo
            
            result = subprocess.run([
                "python", str(cli_script_path), "status",
                "status_test_123"
            ], capture_output=True, text=True)
            
            # Should display status information
            assert result.returncode == 0 or "running" in result.stdout
    
    def test_cli_configuration_management(self, cli_script_path):
        """Test CLI configuration commands"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "test_config.json"
            
            # Test config creation
            result = subprocess.run([
                "python", str(cli_script_path), "configure",
                "--config-file", str(config_file),
                "--max-agents", "8",
                "--websocket-port", "9000"
            ], capture_output=True, text=True)
            
            # Configuration should be created
            assert result.returncode == 0 or config_file.exists()


class TestDPOSystemIntegration:
    """Test DPO integration with external systems"""
    
    @pytest.mark.asyncio
    async def test_orchestrator_api_connectivity(self):
        """Test connectivity with orchestrator API"""
        
        config = DPOConfiguration(
            enable_websocket=False,
            orchestrator_endpoint="http://localhost:8080"  # Mock endpoint
        )
        
        with patch('requests.post') as mock_post:
            mock_post.return_value.json.return_value = {
                "workflow_id": "api_test_123",
                "status": "submitted"
            }
            mock_post.return_value.status_code = 200
            
            dpo = DevelopmentProcessOrchestrator(config)
            await dpo.initialize()
            
            # Test workflow submission
            workflow = {"workflow_id": "test", "phases": []}
            result = await dpo._submit_to_orchestrator(workflow)
            
            assert result["workflow_id"] == "api_test_123"
            mock_post.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_websocket_real_time_updates(self, mock_orchestrator_server):
        """Test WebSocket real-time updates"""
        
        config = DPOConfiguration(
            enable_websocket=True,
            websocket_port=8768
        )
        
        # Mock WebSocket functionality
        with patch('websockets.serve') as mock_ws:
            dpo = DevelopmentProcessOrchestrator(config)
            await dpo.initialize()
            
            # WebSocket server should be configured
            mock_ws.assert_called_once()
    
    def test_file_system_outputs(self):
        """Test file system output management"""
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config = DPOConfiguration(output_base_dir=temp_dir)
            dpo = DevelopmentProcessOrchestrator(config)
            
            # Test output path generation
            workflow_id = "fs_test_123"
            output_path = dpo._get_output_path(workflow_id)
            
            assert str(temp_dir) in str(output_path)
            assert workflow_id in str(output_path)


if __name__ == "__main__":
    pytest.main([__file__])