# Agent Orchestrator API Specifications

> **Version**: 1.0.0  
> **OpenAPI**: 3.0.3  
> **Base URL**: `http://localhost:8888`  
> **WebSocket URL**: `ws://localhost:8765`

## Overview

The Agent Orchestrator provides a comprehensive API for managing parallel agent execution, real-time monitoring, and collaborative workflows. The system supports both RESTful HTTP endpoints and WebSocket connections for live updates.

## Table of Contents

1. [Authentication](#authentication)
2. [REST API Endpoints](#rest-api-endpoints)
3. [WebSocket Events](#websocket-events)
4. [Data Models](#data-models)
5. [Error Handling](#error-handling)
6. [Rate Limiting](#rate-limiting)
7. [OpenAPI Schema](#openapi-schema)

## Authentication

Currently, the API operates without authentication for development purposes. In production environments, implement appropriate authentication mechanisms:

```bash
# Future authentication header
Authorization: Bearer <token>
```

## REST API Endpoints

### Orchestrator Management

#### GET /status
Get current orchestrator status and metrics.

**Response**:
```json
{
  "analysis_dir": "string",
  "total_tasks": 0,
  "completed_tasks": 0,
  "timestamp": "2025-01-01T12:00:00Z",
  "task_files": ["task1.json", "task2.json"],
  "metrics": {
    "total": 0,
    "completed": 0,
    "failed": 0,
    "running": 0,
    "total_duration": 0,
    "start_time": "2025-01-01T12:00:00Z",
    "end_time": "2025-01-01T12:00:00Z"
  }
}
```

**Status Codes**:
- `200 OK` - Success
- `404 Not Found` - No analysis found
- `500 Internal Server Error` - Server error

#### POST /inject_tasks
Inject new tasks into a running orchestrator.

**Request Body**:
```json
{
  "tasks": [
    {
      "task_id": "string",
      "task_type": "string",
      "prompt": "string",
      "dependencies": ["string"],
      "context": {},
      "quality_gates": ["string"],
      "work_dir_name": "string"
    }
  ],
  "priority": "normal|high|critical",
  "execution_mode": "parallel|sequential|dependency"
}
```

**Response**:
```json
{
  "status": "injection_queued",
  "file": "string",
  "message": "string",
  "injection_id": "string"
}
```

#### POST /update_dependencies
Update task dependencies dynamically.

**Request Body**:
```json
{
  "task_id": "string",
  "new_dependencies": ["string"],
  "remove_dependencies": ["string"],
  "action": "add|remove|replace"
}
```

**Response**:
```json
{
  "status": "dependencies_updated",
  "file": "string",
  "message": "string",
  "affected_tasks": ["string"]
}
```

#### POST /trigger_continue
Force orchestrator to continue with available completed tasks.

**Request Body**:
```json
{
  "override_dependencies": ["string"],
  "force_execution": true,
  "reason": "string"
}
```

**Response**:
```json
{
  "status": "continue_triggered",
  "file": "string",
  "message": "string",
  "triggered_tasks": ["string"]
}
```

### Task Management

#### GET /tasks
List all tasks with their current status.

**Query Parameters**:
- `status` (optional): Filter by status (`pending|running|completed|failed`)
- `type` (optional): Filter by task type
- `limit` (optional): Limit results (default: 100)
- `offset` (optional): Pagination offset (default: 0)

**Response**:
```json
{
  "tasks": [
    {
      "task_id": "string",
      "task_type": "string",
      "status": "string",
      "start_time": 0,
      "end_time": 0,
      "dependencies": ["string"],
      "result": {},
      "error": "string",
      "error_details": {}
    }
  ],
  "total": 0,
  "limit": 100,
  "offset": 0
}
```

#### GET /tasks/{task_id}
Get detailed information about a specific task.

**Path Parameters**:
- `task_id` (required): Task identifier

**Response**:
```json
{
  "task_id": "string",
  "task_type": "string",
  "prompt": "string",
  "context": {},
  "dependencies": ["string"],
  "status": "string",
  "result": {},
  "error": "string",
  "error_details": {},
  "start_time": 0,
  "end_time": 0,
  "quality_gates": ["string"],
  "raw_output": "string",
  "work_dir_name": "string"
}
```

#### POST /tasks/{task_id}/retry
Retry a failed task.

**Request Body**:
```json
{
  "reset_dependencies": false,
  "new_prompt": "string",
  "priority": "normal|high|critical"
}
```

#### DELETE /tasks/{task_id}
Cancel a pending or running task.

**Response**:
```json
{
  "status": "cancelled",
  "message": "string",
  "task_id": "string"
}
```

### Live Chat Integration

#### GET /chat/status
Get group chat status and active agents.

**Response**:
```json
{
  "chat_id": "string",
  "active_agents": [
    {
      "agent_id": "string",
      "agent_type": "string",
      "last_seen": "2025-01-01T12:00:00Z",
      "status": "online|offline"
    }
  ],
  "message_count": 0,
  "orchestrator_online": true
}
```

#### POST /chat/message
Send a message to the group chat.

**Request Body**:
```json
{
  "content": "string",
  "sender_id": "string",
  "message_type": "command|status|update|chat"
}
```

#### GET /chat/messages
Get recent chat messages.

**Query Parameters**:
- `limit` (optional): Number of messages (default: 50)
- `since` (optional): ISO timestamp for messages since
- `agent_id` (optional): Filter by agent

**Response**:
```json
{
  "messages": [
    {
      "id": "string",
      "sender_id": "string",
      "content": "string",
      "timestamp": "2025-01-01T12:00:00Z",
      "message_type": "string"
    }
  ]
}
```

### Metrics and Monitoring

#### GET /metrics
Get comprehensive system metrics.

**Response**:
```json
{
  "orchestrator": {
    "total_tasks": 0,
    "completed_tasks": 0,
    "failed_tasks": 0,
    "running_tasks": 0,
    "average_task_duration": 0,
    "total_execution_time": 0
  },
  "token_pool": {
    "total_tokens": 0,
    "available_tokens": 0,
    "tokens_in_use": 0,
    "total_acquisitions": 0,
    "total_releases": 0,
    "peak_usage": 0,
    "utilization_percentage": 0
  },
  "system": {
    "uptime": 0,
    "memory_usage": 0,
    "cpu_usage": 0
  }
}
```

#### GET /metrics/health
Health check endpoint.

**Response**:
```json
{
  "status": "healthy|degraded|unhealthy",
  "timestamp": "2025-01-01T12:00:00Z",
  "checks": {
    "orchestrator": "ok|error",
    "token_pool": "ok|error",
    "dependencies": "ok|error"
  }
}
```

## WebSocket Events

### Connection

Connect to WebSocket for real-time updates:
```javascript
const ws = new WebSocket('ws://localhost:8765');
```

### Event Types

#### Client → Server Events

##### Subscribe to Updates
```json
{
  "type": "subscribe",
  "channels": ["orchestrator", "tasks", "chat", "metrics"],
  "agent_id": "string"
}
```

##### Send Chat Message
```json
{
  "type": "chat_message",
  "content": "string",
  "sender_id": "string",
  "target": "all|agent_id"
}
```

##### Execute Command
```json
{
  "type": "command",
  "command": "pause|resume|status|priority",
  "parameters": {},
  "sender_id": "string"
}
```

#### Server → Client Events

##### Task Status Update
```json
{
  "type": "task_update",
  "task_id": "string",
  "status": "pending|running|completed|failed",
  "timestamp": "2025-01-01T12:00:00Z",
  "details": {
    "duration": 0,
    "error": "string",
    "progress": 0
  }
}
```

##### Orchestrator Status
```json
{
  "type": "orchestrator_status",
  "metrics": {
    "total": 0,
    "completed": 0,
    "failed": 0,
    "running": 0
  },
  "timestamp": "2025-01-01T12:00:00Z"
}
```

##### Chat Message
```json
{
  "type": "chat_message",
  "sender_id": "string",
  "sender_type": "orchestrator|agent|user",
  "content": "string",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

##### Agent Status
```json
{
  "type": "agent_status",
  "agent_id": "string",
  "status": "thinking|researching|writing|idle",
  "current_task": "string",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

##### System Alert
```json
{
  "type": "alert",
  "level": "info|warning|error|critical",
  "message": "string",
  "source": "orchestrator|agent|system",
  "timestamp": "2025-01-01T12:00:00Z"
}
```

## Data Models

### AgentTask

Core task definition for orchestration:

```json
{
  "task_id": "string",
  "task_type": "research|analysis|monitoring|code|design",
  "prompt": "string",
  "context": {
    "app_name": "string",
    "app_root": "string",
    "additional_context": {}
  },
  "dependencies": ["string"],
  "status": "pending|running|completed|failed",
  "result": {},
  "error": "string",
  "start_time": 0,
  "end_time": 0,
  "quality_gates": ["string"],
  "raw_output": "string",
  "error_details": {
    "type": "string",
    "message": "string",
    "traceback": ["string"],
    "exit_code": 0,
    "timestamp": "2025-01-01T12:00:00Z"
  },
  "work_dir_name": "string"
}
```

### OrchestratorMetrics

System performance and execution metrics:

```json
{
  "total": 0,
  "completed": 0,
  "failed": 0,
  "running": 0,
  "total_duration": 0,
  "start_time": "2025-01-01T12:00:00Z",
  "end_time": "2025-01-01T12:00:00Z",
  "average_task_duration": 0,
  "peak_concurrent_tasks": 0
}
```

### TokenPoolStats

Token pool utilization and performance:

```json
{
  "total_tokens": 0,
  "currently_in_use": 0,
  "currently_available": 0,
  "total_acquisitions": 0,
  "total_releases": 0,
  "peak_usage": 0,
  "utilization_percentage": 0,
  "average_concurrent_usage": 0,
  "acquisition_history": [
    {
      "timestamp": 0,
      "token_idx": 0,
      "tokens_in_use_after": 0,
      "available_after": 0
    }
  ]
}
```

### GroupChatAgent

Chat participant information:

```json
{
  "agent_id": "string",
  "agent_type": "orchestrator|agent|user",
  "status": "online|offline|busy",
  "last_seen": "2025-01-01T12:00:00Z",
  "current_task": "string",
  "capabilities": ["string"],
  "metadata": {}
}
```

### ExecutionPlan

Advanced orchestration workflow definition:

```json
{
  "name": "string",
  "description": "string",
  "tasks": [
    {
      "task_id": "string",
      "task_type": "string",
      "prompt": "string",
      "dependencies": ["string"],
      "parallel_group": "string",
      "timeout": 0,
      "retry_count": 3,
      "quality_gates": ["string"]
    }
  ],
  "execution_mode": "parallel|sequential|dependency|hybrid",
  "enable_quality_gates": true,
  "enable_monitoring": true,
  "use_optimizations": true,
  "max_parallel": 10,
  "global_timeout": 3600,
  "failure_strategy": "stop|continue|retry"
}
```

## Error Handling

### Error Response Format

All API errors follow a consistent format:

```json
{
  "error": {
    "code": "string",
    "message": "string",
    "details": {},
    "timestamp": "2025-01-01T12:00:00Z",
    "request_id": "string"
  }
}
```

### Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `ORCHESTRATOR_NOT_FOUND` | 404 | No orchestrator analysis found |
| `TASK_NOT_FOUND` | 404 | Task ID not found |
| `INVALID_TASK_STATUS` | 400 | Invalid status transition |
| `DEPENDENCY_CYCLE` | 400 | Circular dependency detected |
| `TOKEN_POOL_EXHAUSTED` | 503 | No tokens available |
| `INVALID_REQUEST` | 400 | Malformed request body |
| `ORCHESTRATOR_BUSY` | 429 | Orchestrator at capacity |
| `WEBSOCKET_ERROR` | 500 | WebSocket connection error |
| `CHAT_UNAVAILABLE` | 503 | Group chat service unavailable |
| `AUTHENTICATION_FAILED` | 401 | Invalid credentials |
| `PERMISSION_DENIED` | 403 | Insufficient permissions |

### Error Handling Strategies

#### Client Retry Logic
```javascript
const retryRequest = async (url, options, maxRetries = 3) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return response;
      
      // Don't retry client errors (4xx)
      if (response.status >= 400 && response.status < 500) {
        throw new Error(`Client error: ${response.status}`);
      }
      
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, i)));
    } catch (error) {
      if (i === maxRetries - 1) throw error;
    }
  }
};
```

#### WebSocket Reconnection
```javascript
class OrchestratorWebSocket {
  constructor(url) {
    this.url = url;
    this.reconnectInterval = 5000;
    this.maxReconnectAttempts = 10;
    this.connect();
  }
  
  connect() {
    this.ws = new WebSocket(this.url);
    
    this.ws.onclose = (event) => {
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        setTimeout(() => {
          this.reconnectAttempts++;
          this.connect();
        }, this.reconnectInterval);
      }
    };
    
    this.ws.onopen = () => {
      this.reconnectAttempts = 0;
    };
  }
}
```

## Rate Limiting

### Default Limits

| Endpoint | Limit | Window | Scope |
|----------|-------|--------|-------|
| `/status` | 60 requests | 1 minute | Per IP |
| `/inject_tasks` | 10 requests | 1 minute | Per IP |
| `/tasks/*` | 100 requests | 1 minute | Per IP |
| `/chat/message` | 30 requests | 1 minute | Per IP |
| WebSocket connections | 5 connections | - | Per IP |

### Rate Limit Headers

```http
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1640995200
X-RateLimit-Window: 60
```

### Rate Limit Response

When rate limited (HTTP 429):

```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded",
    "details": {
      "limit": 60,
      "window": 60,
      "reset_at": "2025-01-01T12:01:00Z"
    }
  }
}
```

## OpenAPI Schema

### Complete OpenAPI 3.0.3 Specification

```yaml
openapi: 3.0.3
info:
  title: Agent Orchestrator API
  description: API for managing parallel agent execution and workflow orchestration
  version: 1.0.0
  contact:
    name: Agent Orchestrator Team
    email: support@example.com
  license:
    name: MIT
    url: https://opensource.org/licenses/MIT

servers:
  - url: http://localhost:8888
    description: Development server
  - url: ws://localhost:8765
    description: WebSocket server

paths:
  /status:
    get:
      summary: Get orchestrator status
      operationId: getOrchestratorStatus
      tags: [Orchestrator]
      responses:
        '200':
          description: Orchestrator status
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OrchestratorStatus'
        '404':
          description: No analysis found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
        '500':
          description: Internal server error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

  /inject_tasks:
    post:
      summary: Inject new tasks
      operationId: injectTasks
      tags: [Tasks]
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/TaskInjectionRequest'
      responses:
        '200':
          description: Tasks injected successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/InjectionResponse'
        '400':
          description: Invalid request
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

  /tasks:
    get:
      summary: List all tasks
      operationId: listTasks
      tags: [Tasks]
      parameters:
        - name: status
          in: query
          schema:
            type: string
            enum: [pending, running, completed, failed]
        - name: type
          in: query
          schema:
            type: string
        - name: limit
          in: query
          schema:
            type: integer
            default: 100
            minimum: 1
            maximum: 1000
        - name: offset
          in: query
          schema:
            type: integer
            default: 0
            minimum: 0
      responses:
        '200':
          description: List of tasks
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TaskList'

  /tasks/{taskId}:
    get:
      summary: Get task details
      operationId: getTask
      tags: [Tasks]
      parameters:
        - name: taskId
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: Task details
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentTask'
        '404':
          description: Task not found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

components:
  schemas:
    AgentTask:
      type: object
      required: [task_id, task_type, prompt, status]
      properties:
        task_id:
          type: string
          description: Unique task identifier
        task_type:
          type: string
          enum: [research, analysis, monitoring, code, design]
        prompt:
          type: string
          description: Task instruction prompt
        context:
          type: object
          description: Additional task context
        dependencies:
          type: array
          items:
            type: string
          description: Task dependencies
        status:
          type: string
          enum: [pending, running, completed, failed]
        result:
          type: object
          description: Task execution result
        error:
          type: string
          description: Error message if failed
        start_time:
          type: number
          description: Task start timestamp
        end_time:
          type: number
          description: Task end timestamp
        quality_gates:
          type: array
          items:
            type: string
        raw_output:
          type: string
          description: Raw agent output
        work_dir_name:
          type: string
          description: Custom working directory

    OrchestratorStatus:
      type: object
      properties:
        analysis_dir:
          type: string
        total_tasks:
          type: integer
        completed_tasks:
          type: integer
        timestamp:
          type: string
          format: date-time
        task_files:
          type: array
          items:
            type: string
        metrics:
          $ref: '#/components/schemas/OrchestratorMetrics'

    OrchestratorMetrics:
      type: object
      properties:
        total:
          type: integer
        completed:
          type: integer
        failed:
          type: integer
        running:
          type: integer
        total_duration:
          type: number
        start_time:
          type: string
          format: date-time
        end_time:
          type: string
          format: date-time

    TaskInjectionRequest:
      type: object
      required: [tasks]
      properties:
        tasks:
          type: array
          items:
            $ref: '#/components/schemas/AgentTask'
        priority:
          type: string
          enum: [normal, high, critical]
          default: normal
        execution_mode:
          type: string
          enum: [parallel, sequential, dependency]
          default: parallel

    InjectionResponse:
      type: object
      properties:
        status:
          type: string
        file:
          type: string
        message:
          type: string
        injection_id:
          type: string

    TaskList:
      type: object
      properties:
        tasks:
          type: array
          items:
            $ref: '#/components/schemas/AgentTask'
        total:
          type: integer
        limit:
          type: integer
        offset:
          type: integer

    Error:
      type: object
      required: [error]
      properties:
        error:
          type: object
          required: [code, message]
          properties:
            code:
              type: string
            message:
              type: string
            details:
              type: object
            timestamp:
              type: string
              format: date-time
            request_id:
              type: string
```

## Usage Examples

### JavaScript Client

```javascript
class OrchestratorClient {
  constructor(baseUrl = 'http://localhost:8888') {
    this.baseUrl = baseUrl;
    this.wsUrl = 'ws://localhost:8765';
  }

  async getStatus() {
    const response = await fetch(`${this.baseUrl}/status`);
    return response.json();
  }

  async injectTasks(tasks) {
    const response = await fetch(`${this.baseUrl}/inject_tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tasks })
    });
    return response.json();
  }

  connectWebSocket() {
    this.ws = new WebSocket(this.wsUrl);
    
    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleWebSocketMessage(data);
    };

    return this.ws;
  }

  handleWebSocketMessage(data) {
    switch (data.type) {
      case 'task_update':
        console.log(`Task ${data.task_id}: ${data.status}`);
        break;
      case 'chat_message':
        console.log(`${data.sender_id}: ${data.content}`);
        break;
    }
  }
}

// Usage
const client = new OrchestratorClient();
const status = await client.getStatus();
console.log('Orchestrator status:', status);

const ws = client.connectWebSocket();
ws.send(JSON.stringify({
  type: 'subscribe',
  channels: ['orchestrator', 'tasks', 'chat']
}));
```

### Python Client

```python
import requests
import websocket
import json
import threading

class OrchestratorClient:
    def __init__(self, base_url='http://localhost:8888'):
        self.base_url = base_url
        self.ws_url = 'ws://localhost:8765'
        
    def get_status(self):
        response = requests.get(f"{self.base_url}/status")
        response.raise_for_status()
        return response.json()
    
    def inject_tasks(self, tasks, priority='normal'):
        data = {'tasks': tasks, 'priority': priority}
        response = requests.post(f"{self.base_url}/inject_tasks", json=data)
        response.raise_for_status()
        return response.json()
    
    def connect_websocket(self, on_message=None):
        def on_ws_message(ws, message):
            data = json.loads(message)
            if on_message:
                on_message(data)
        
        def on_error(ws, error):
            print(f"WebSocket error: {error}")
        
        def on_close(ws, close_status_code, close_msg):
            print("WebSocket connection closed")
        
        def on_open(ws):
            # Subscribe to updates
            ws.send(json.dumps({
                'type': 'subscribe',
                'channels': ['orchestrator', 'tasks', 'chat']
            }))
        
        ws = websocket.WebSocketApp(
            self.ws_url,
            on_open=on_open,
            on_message=on_ws_message,
            on_error=on_error,
            on_close=on_close
        )
        
        # Run in background thread
        thread = threading.Thread(target=ws.run_forever)
        thread.daemon = True
        thread.start()
        
        return ws

# Usage
client = OrchestratorClient()

# Get status
status = client.get_status()
print(f"Status: {status}")

# Inject tasks
tasks = [{
    'task_id': 'example_task',
    'task_type': 'research',
    'prompt': 'Research Python async patterns',
    'dependencies': []
}]

result = client.inject_tasks(tasks)
print(f"Injection result: {result}")

# Connect WebSocket
def handle_message(data):
    print(f"WebSocket message: {data}")

ws = client.connect_websocket(on_message=handle_message)
```

---

**Note**: This API specification is based on the current implementation. Features marked as "in development" or "future" may not be fully implemented. Always check the latest documentation for updates.