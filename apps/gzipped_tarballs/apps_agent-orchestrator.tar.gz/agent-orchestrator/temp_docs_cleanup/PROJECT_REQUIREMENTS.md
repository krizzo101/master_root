# PROJECT REQUIREMENTS: Orchestrator Dashboard Monitoring System

## Executive Summary

The agent-orchestrator system currently faces critical operational challenges with concurrent workflow management. With 10+ workflows running simultaneously, operators have no visibility into individual workflow progress, cannot distinguish between workflow logs, and have no way to monitor deliverables or ETAs.

## Critical Problems Identified

### 1. **Concurrent Workflow Chaos**
- **Current State**: 6+ orchestrator processes running simultaneously (as of 2025-09-08 12:35)
- **Problem**: No centralized monitoring of concurrent workflows
- **Impact**: Impossible to determine which workflows are active, stalled, or failed
- **Evidence**: Multiple `python main.py` processes detected running different task files

### 2. **Log File Mixing and Confusion**
- **Current State**: All workflows dump logs into shared directory structures
- **Problem**: Logs from different workflows are intermingled, making debugging impossible
- **Impact**: Critical issues get lost in log noise, no workflow-specific troubleshooting
- **Evidence**: 
  - `/home/opsvi/master_root/apps/agent-orchestrator/output/logs/` contains mixed logs
  - Multiple `orchestrator_YYYYMMDD_HHMMSS.log` files with no workflow identification
  - Log files scattered across multiple output directories

### 3. **No Progress Tracking or ETAs**
- **Current State**: Zero visibility into workflow progress
- **Problem**: No way to determine if a workflow is progressing or stuck
- **Impact**: Workflows can run indefinitely without detection, wasting resources
- **Evidence**: Running workflows with no status indicators or completion estimates

### 4. **Deliverable Management Chaos**
- **Current State**: Output files scattered across multiple directories
- **Problem**: No centralized view of what each workflow has produced
- **Impact**: Results get lost, no download links, no deliverable tracking
- **Evidence**: Files spread across `outputs/`, `output/`, `wbs_output/`, etc.

## Success Criteria

### **Primary Success Metrics**

1. **Concurrent Workflow Monitoring**
   - [ ] Monitor 10+ simultaneous workflows with real-time status updates
   - [ ] Each workflow clearly identified by name, task type, and start time
   - [ ] Process ID tracking and resource utilization monitoring
   - [ ] Workflow health status (running, stalled, completed, failed)

2. **Workflow-Specific Log Separation**
   - [ ] Each workflow gets dedicated log directory: `/logs/{workflow_id}/`
   - [ ] Real-time log streaming for individual workflows
   - [ ] Log level filtering (ERROR, WARNING, INFO, DEBUG)
   - [ ] Log search and filtering within specific workflows

3. **Progress Tracking with ETAs**
   - [ ] Task-level progress indicators (0-100% completion)
   - [ ] ETA calculations based on historical workflow performance
   - [ ] Visual progress bars for each active workflow
   - [ ] Task dependency visualization and completion tracking

4. **Deliverable Management**
   - [ ] Centralized deliverable registry for each workflow
   - [ ] Direct download links for completed outputs
   - [ ] File preview capabilities for common formats (MD, JSON, logs)
   - [ ] Automatic deliverable archiving and organization

### **Secondary Success Metrics**

5. **Dashboard Interface**
   - [ ] Real-time web dashboard accessible via browser
   - [ ] Mobile-responsive design for remote monitoring
   - [ ] Auto-refresh capabilities (5-second intervals)
   - [ ] Historical workflow analytics and performance metrics

6. **Alerting and Notifications**
   - [ ] Workflow failure notifications
   - [ ] Stalled workflow detection (no activity >10 minutes)
   - [ ] Completion notifications with deliverable links
   - [ ] Resource exhaustion warnings

7. **Operational Controls**
   - [ ] Workflow termination controls (graceful and force)
   - [ ] Restart failed workflows functionality
   - [ ] Queue management for pending workflows
   - [ ] Resource allocation controls (max parallel workflows)

## Technical Architecture Requirements

### **Core Components**

1. **Workflow Registry Service**
   - Centralized tracking of all active workflows
   - SQLite/PostgreSQL database for persistence
   - RESTful API for status queries and controls

2. **Log Aggregation System**
   - Structured logging with workflow correlation IDs
   - Real-time log streaming via WebSocket
   - Log rotation and archival policies

3. **Progress Monitoring Engine**
   - Task status tracking integration with orchestrator
   - ETA calculation algorithms
   - Performance metrics collection

4. **Deliverable Management Service**
   - File system monitoring for workflow outputs
   - Metadata extraction and indexing
   - Download API with authentication

5. **Web Dashboard Frontend**
   - React/Vue.js single-page application
   - Real-time updates via WebSocket
   - Responsive design for all devices

### **Integration Points**

- **Orchestrator Integration**: Modify `GenericOrchestrator` to report status
- **File System Integration**: Monitor output directories for deliverables
- **Process Management**: Integration with system process monitoring
- **Database Integration**: Extend existing database schemas

## Implementation Phases

### **Phase 1: Core Monitoring (Week 1-2)**
- Workflow registry and status tracking
- Basic web dashboard with workflow list
- Log separation and correlation IDs

### **Phase 2: Progress & ETAs (Week 3-4)**
- Task-level progress tracking
- ETA calculation engine
- Progress visualization components

### **Phase 3: Deliverable Management (Week 5-6)**
- File monitoring and indexing
- Download API and file serving
- Deliverable preview capabilities

### **Phase 4: Advanced Features (Week 7-8)**
- Advanced analytics and reporting
- Alerting and notification system
- Workflow control operations

## Risk Mitigation

### **High Priority Risks**
1. **Performance Impact**: Monitor dashboard overhead on workflow execution
2. **Database Contention**: Ensure monitoring doesn't slow down workflows
3. **Log Storage Growth**: Implement log rotation and cleanup policies
4. **Security Concerns**: Secure file access and workflow controls

### **Mitigation Strategies**
- Async monitoring with minimal workflow integration
- Separate monitoring database from workflow data
- Automated cleanup policies and storage limits
- Authentication and authorization for dashboard access

## Acceptance Criteria

### **Demo Scenario**
The system will be considered successful when an operator can:

1. **Start 10 concurrent workflows** from different terminals/sessions
2. **View all workflows** in a single dashboard with real-time status
3. **Click on any workflow** to see its dedicated logs in real-time
4. **Monitor progress** with ETAs for each workflow's completion
5. **Access deliverables** immediately when workflows complete
6. **Terminate/restart workflows** directly from the dashboard

### **Performance Targets**
- Dashboard load time: <3 seconds
- Status updates: <5 second latency
- Log streaming: <1 second latency
- File download: <2 seconds for typical deliverables
- System overhead: <5% impact on workflow execution time

## Budget and Resources

### **Development Effort**
- Estimated: 6-8 weeks (1 developer full-time)
- Critical path: Integration with existing orchestrator
- Dependencies: Database access, file system permissions

### **Infrastructure Requirements**
- Web server for dashboard hosting
- Database for workflow state persistence
- File storage for deliverable management
- WebSocket support for real-time updates

---

**Document Status**: Draft v1.0  
**Created**: 2025-09-08  
**Last Updated**: 2025-09-08  
**Next Review**: Weekly until implementation complete