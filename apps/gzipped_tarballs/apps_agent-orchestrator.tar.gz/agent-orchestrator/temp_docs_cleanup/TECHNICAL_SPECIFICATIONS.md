# TECHNICAL SPECIFICATIONS: Orchestrator Dashboard Implementation

## Executive Summary

This document specifies the technical architecture for a real-time monitoring dashboard built on FastAPI + WebSocket stack to manage 10+ concurrent agent orchestrator workflows. The system provides real-time visibility, workflow-specific logging, progress tracking, and deliverable management.

## System Architecture

### 1. Core Technology Stack

**Backend Framework**
- **FastAPI 0.104+**: High-performance async API framework
- **WebSockets**: Real-time bidirectional communication
- **asyncio**: Concurrent processing foundation
- **Pydantic v2**: Data validation and serialization

**Database Layer**
- **PostgreSQL 15+**: Primary database with JSONB support
- **Redis 7+**: Caching and WebSocket session management
- **SQLAlchemy 2.0**: Async ORM with PostgreSQL integration
- **asyncpg**: High-performance PostgreSQL driver

**Frontend Technology**
- **WebSocket Client**: Native browser WebSocket API
- **Progressive Enhancement**: Server-rendered HTML with JavaScript enhancements
- **Responsive CSS**: Mobile-first design

### 2. System Architecture Diagram

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Clients   │◄──►│  FastAPI Server │◄──►│   PostgreSQL    │
│                 │    │                 │    │                 │
│ ┌─────────────┐ │    │ ┌─────────────┐ │    │ ┌─────────────┐ │
│ │Dashboard UI │ │    │ │WebSocket Hub│ │    │ │Workflow Data│ │
│ │Workflow View│ │    │ │REST API     │ │    │ │Task Status  │ │
│ │Comparison   │ │    │ │Task Monitor │ │    │ │Log Entries  │ │
│ └─────────────┘ │    │ └─────────────┘ │    │ │Deliverables │ │
└─────────────────┘    └─────────────────┘    │ └─────────────┘ │
                                ▲              └─────────────────┘
                                │                       ▲
                       ┌─────────────────┐              │
                       │      Redis      │              │
                       │                 │              │
                       │ ┌─────────────┐ │              │
                       │ │Session Cache│ │              │
                       │ │Event Queue  │ │              │
                       │ │Rate Limiting│ │              │
                       │ └─────────────┘ │              │
                       └─────────────────┘              │
                                ▲                       │
                                │                       │
                       ┌─────────────────┐              │
                       │  File System    │──────────────┘
                       │   Monitors      │
                       │                 │
                       │ ┌─────────────┐ │
                       │ │Log Watchers │ │
                       │ │Output Scans │ │
                       │ │Progress Tail│ │
                       │ └─────────────┘ │
                       └─────────────────┘
```

### 3. High-Level Component Architecture

**Dashboard Server Core**
- **WebSocket Hub**: Central event distribution system
- **REST API Layer**: Standard HTTP endpoints for data operations
- **Task Monitor Service**: Background monitoring of orchestrator processes
- **File System Watchers**: Real-time log and output file monitoring

**Data Processing Pipeline**
- **Workflow State Manager**: Tracks workflow lifecycle and status
- **Log Aggregator**: Processes and indexes log entries by workflow
- **Progress Calculator**: ETAs based on historical data and current state
- **Deliverable Registry**: Tracks and indexes output files

## Database Schema Design

### 4. Core Database Tables

```sql
-- Workflow management
CREATE TABLE workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    task_type VARCHAR(100) NOT NULL,
    status workflow_status NOT NULL DEFAULT 'pending',
    config JSONB NOT NULL DEFAULT '{}',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    progress_percent INTEGER DEFAULT 0,
    estimated_completion TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Individual tasks within workflows
CREATE TABLE workflow_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE,
    task_id VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    status task_status NOT NULL DEFAULT 'pending',
    dependencies TEXT[] DEFAULT '{}',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    output_summary TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(workflow_id, task_id)
);

-- Real-time log entries
CREATE TABLE log_entries (
    id BIGSERIAL PRIMARY KEY,
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE,
    task_id VARCHAR(255),
    level log_level NOT NULL,
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Deliverable tracking
CREATE TABLE deliverables (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE,
    task_id VARCHAR(255),
    filename VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT,
    content_type VARCHAR(100),
    checksum VARCHAR(64),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(workflow_id, file_path)
);

-- System metrics and performance
CREATE TABLE system_metrics (
    id BIGSERIAL PRIMARY KEY,
    metric_type VARCHAR(100) NOT NULL,
    metric_name VARCHAR(255) NOT NULL,
    value NUMERIC NOT NULL,
    tags JSONB DEFAULT '{}',
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- WebSocket session management
CREATE TABLE websocket_sessions (
    session_id UUID PRIMARY KEY,
    client_ip INET NOT NULL,
    connected_at TIMESTAMPTZ DEFAULT NOW(),
    last_activity TIMESTAMPTZ DEFAULT NOW(),
    subscriptions TEXT[] DEFAULT '{}'
);
```

### 5. Database Indexes and Optimization

```sql
-- Performance indexes
CREATE INDEX CONCURRENTLY idx_workflows_status_updated ON workflows(status, updated_at DESC);
CREATE INDEX CONCURRENTLY idx_workflow_tasks_workflow_status ON workflow_tasks(workflow_id, status);
CREATE INDEX CONCURRENTLY idx_log_entries_workflow_timestamp ON log_entries(workflow_id, timestamp DESC);
CREATE INDEX CONCURRENTLY idx_deliverables_workflow ON deliverables(workflow_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_system_metrics_type_time ON system_metrics(metric_type, timestamp DESC);

-- JSONB indexes for configuration queries
CREATE INDEX CONCURRENTLY idx_workflows_config_gin ON workflows USING gin(config);
CREATE INDEX CONCURRENTLY idx_log_entries_metadata_gin ON log_entries USING gin(metadata);

-- Composite indexes for common query patterns
CREATE INDEX CONCURRENTLY idx_workflows_type_status_updated ON workflows(task_type, status, updated_at DESC);
```

### 6. Custom Database Types

```sql
-- Workflow status enum
CREATE TYPE workflow_status AS ENUM (
    'pending', 'queued', 'running', 'paused', 
    'completed', 'failed', 'cancelled', 'timeout'
);

-- Task status enum  
CREATE TYPE task_status AS ENUM (
    'pending', 'running', 'completed', 'failed', 
    'skipped', 'cancelled', 'retrying'
);

-- Log level enum
CREATE TYPE log_level AS ENUM (
    'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
);
```

## Caching Strategy

### 7. Redis Cache Architecture

**Cache Layers**
- **L1 - Application Cache**: In-memory Python dictionaries for hot data
- **L2 - Redis Cache**: Shared cache across multiple server instances
- **L3 - Database**: PostgreSQL as the source of truth

**Cache Key Patterns**
```python
# Workflow data caching
workflow:{workflow_id}                 # TTL: 300s
workflow:{workflow_id}:tasks          # TTL: 60s  
workflow:{workflow_id}:logs:recent    # TTL: 30s
workflow:{workflow_id}:progress       # TTL: 10s

# Dashboard aggregations
dashboard:active_workflows            # TTL: 30s
dashboard:system_metrics:latest       # TTL: 60s
dashboard:performance_summary         # TTL: 300s

# WebSocket sessions
ws:session:{session_id}               # TTL: 3600s
ws:subscriptions:{workflow_id}        # TTL: 3600s
```

**Cache Invalidation Strategy**
- **Time-based**: TTL for all cache entries
- **Event-driven**: Immediate invalidation on workflow state changes
- **Write-through**: Critical updates bypass cache directly to database

### 8. Caching Implementation

```python
import redis.asyncio as redis
from typing import Optional, Dict, Any
import json

class CacheManager:
    def __init__(self, redis_url: str):
        self.redis = redis.from_url(redis_url, decode_responses=True)
    
    async def get_workflow(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """Get workflow data with L2 cache fallback"""
        cache_key = f"workflow:{workflow_id}"
        
        # Try L2 cache first
        cached_data = await self.redis.get(cache_key)
        if cached_data:
            return json.loads(cached_data)
        
        # Fallback to database and cache result
        workflow_data = await self.db.get_workflow(workflow_id)
        if workflow_data:
            await self.redis.setex(
                cache_key, 300, json.dumps(workflow_data, default=str)
            )
        
        return workflow_data
    
    async def invalidate_workflow(self, workflow_id: str):
        """Invalidate all cache entries for a workflow"""
        pattern_keys = [
            f"workflow:{workflow_id}*",
            "dashboard:active_workflows",
            "dashboard:system_metrics:latest"
        ]
        
        for pattern in pattern_keys:
            keys = await self.redis.keys(pattern)
            if keys:
                await self.redis.delete(*keys)
```

## WebSocket Event Handling

### 9. Real-Time Event Architecture

**Event Types**
```python
class EventType(str, Enum):
    WORKFLOW_STARTED = "workflow_started"
    WORKFLOW_COMPLETED = "workflow_completed" 
    WORKFLOW_FAILED = "workflow_failed"
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    LOG_ENTRY = "log_entry"
    PROGRESS_UPDATE = "progress_update"
    DELIVERABLE_CREATED = "deliverable_created"
    SYSTEM_METRIC = "system_metric"
```

**WebSocket Message Format**
```python
@dataclass
class WebSocketMessage:
    event_type: EventType
    workflow_id: Optional[str]
    task_id: Optional[str]
    data: Dict[str, Any]
    timestamp: datetime
    sequence_id: int
```

### 10. WebSocket Hub Implementation

```python
from fastapi import WebSocket
import asyncio
from typing import Dict, Set
import json

class WebSocketHub:
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.subscriptions: Dict[str, Set[str]] = {}  # workflow_id -> session_ids
        self.session_workflows: Dict[str, Set[str]] = {}  # session_id -> workflow_ids
    
    async def connect(self, websocket: WebSocket, session_id: str):
        """Handle new WebSocket connection"""
        await websocket.accept()
        self.connections[session_id] = websocket
        self.session_workflows[session_id] = set()
        
        # Send connection confirmation
        await self.send_to_session(session_id, {
            "event_type": "connection_established",
            "session_id": session_id,
            "timestamp": datetime.now().isoformat()
        })
    
    async def subscribe_to_workflow(self, session_id: str, workflow_id: str):
        """Subscribe session to workflow events"""
        if workflow_id not in self.subscriptions:
            self.subscriptions[workflow_id] = set()
        
        self.subscriptions[workflow_id].add(session_id)
        self.session_workflows[session_id].add(workflow_id)
        
        # Send current workflow state
        workflow_state = await self.get_workflow_state(workflow_id)
        await self.send_to_session(session_id, {
            "event_type": "workflow_state",
            "workflow_id": workflow_id,
            "data": workflow_state,
            "timestamp": datetime.now().isoformat()
        })
    
    async def broadcast_to_workflow(self, workflow_id: str, message: Dict[str, Any]):
        """Send message to all sessions subscribed to workflow"""
        if workflow_id not in self.subscriptions:
            return
        
        message_json = json.dumps(message, default=str)
        
        # Send to all subscribed sessions
        dead_sessions = []
        for session_id in self.subscriptions[workflow_id]:
            try:
                websocket = self.connections.get(session_id)
                if websocket:
                    await websocket.send_text(message_json)
            except Exception:
                dead_sessions.append(session_id)
        
        # Clean up dead sessions
        for session_id in dead_sessions:
            await self.disconnect(session_id)
    
    async def send_to_session(self, session_id: str, message: Dict[str, Any]):
        """Send message to specific session"""
        websocket = self.connections.get(session_id)
        if websocket:
            try:
                await websocket.send_text(json.dumps(message, default=str))
            except Exception:
                await self.disconnect(session_id)
    
    async def disconnect(self, session_id: str):
        """Handle WebSocket disconnection"""
        # Remove from all subscriptions
        if session_id in self.session_workflows:
            for workflow_id in self.session_workflows[session_id]:
                if workflow_id in self.subscriptions:
                    self.subscriptions[workflow_id].discard(session_id)
                    
                    # Clean up empty subscriptions
                    if not self.subscriptions[workflow_id]:
                        del self.subscriptions[workflow_id]
        
        # Clean up session data
        self.connections.pop(session_id, None)
        self.session_workflows.pop(session_id, None)
```

### 11. Event Broadcasting System

```python
class EventBroadcaster:
    def __init__(self, websocket_hub: WebSocketHub, cache_manager: CacheManager):
        self.hub = websocket_hub
        self.cache = cache_manager
        self.event_queue = asyncio.Queue(maxsize=10000)
        
    async def emit_workflow_event(self, workflow_id: str, event_type: EventType, 
                                 data: Dict[str, Any], task_id: Optional[str] = None):
        """Emit workflow-related event"""
        message = {
            "event_type": event_type.value,
            "workflow_id": workflow_id,
            "task_id": task_id,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "sequence_id": self.get_sequence_id()
        }
        
        # Queue for processing
        await self.event_queue.put(message)
        
    async def process_events(self):
        """Background task to process event queue"""
        while True:
            try:
                message = await self.event_queue.get()
                
                # Broadcast via WebSocket
                workflow_id = message.get("workflow_id")
                if workflow_id:
                    await self.hub.broadcast_to_workflow(workflow_id, message)
                
                # Update cache
                await self.update_cache_from_event(message)
                
                # Persist to database
                await self.persist_event(message)
                
            except Exception as e:
                logger.error(f"Event processing error: {e}")
                continue
```

## Performance Requirements

### 12. Scalability Targets

**Concurrent Workflow Support**
- **Primary Target**: 10+ simultaneous workflows
- **Stretch Target**: 50+ simultaneous workflows
- **Maximum Load**: 100+ workflows with degraded UI responsiveness

**Real-Time Performance**
- **WebSocket Latency**: <100ms for event delivery
- **Dashboard Refresh**: <500ms for full dashboard update
- **Log Streaming**: <200ms for new log entries
- **Progress Updates**: <1s for progress bar updates

**Database Performance**
- **Query Response**: <50ms for dashboard queries
- **Log Ingestion**: 10,000+ log entries/minute
- **Concurrent Connections**: 50+ simultaneous WebSocket connections
- **Data Retention**: 30 days of detailed logs, 1 year of workflow metadata

### 13. Resource Optimization

**Memory Management**
- **Application Memory**: <512MB baseline, <2GB under full load
- **Redis Cache**: <1GB for 24 hours of workflow data
- **Connection Pooling**: 10-50 PostgreSQL connections, 100+ Redis connections

**CPU Utilization**
- **Background Processing**: <20% CPU under normal load
- **Event Processing**: <10% CPU for WebSocket broadcasting
- **File System Monitoring**: <5% CPU for log watching

**Network Optimization**
- **WebSocket Message Size**: <10KB per event message
- **API Response Size**: <100KB for dashboard data
- **Compression**: gzip enabled for all HTTP responses

## Integration Constraints

### 14. Existing System Integration

**Orchestrator Process Integration**
- **Non-Intrusive Monitoring**: Read-only access to existing log files and output directories
- **Process Detection**: Automatic discovery of running orchestrator processes via process monitoring
- **Configuration Compatibility**: Support existing task file formats without modification

**File System Constraints**
- **Log File Locations**: Monitor existing `outputs/*/logs/` directory structures
- **Output Directory Scanning**: Support multiple output directory patterns (`output/`, `outputs/`, `wbs_output/`)
- **File Lock Handling**: Safe concurrent access to actively written log files

**API Compatibility**
- **Existing API Preservation**: Maintain compatibility with existing `orchestrator_api.py` endpoints
- **State File Integration**: Support existing `current_orchestrator_state.json` format
- **Task Injection**: Extend existing task injection mechanisms

### 15. Deployment Architecture

**Container Strategy**
```yaml
# docker-compose.yml
services:
  dashboard-api:
    build: .
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/orchestrator
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - postgres
      - redis
    ports:
      - "8000:8000"
    volumes:
      - ./outputs:/app/monitor/outputs:ro
      - ./logs:/app/monitor/logs:ro

  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: orchestrator
      POSTGRES_USER: orchestrator_user
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    command: redis-server --maxmemory 1gb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
```

**Environment Configuration**
```python
# settings.py
from pydantic import BaseSettings

class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql://user:pass@localhost:5432/orchestrator"
    database_pool_size: int = 20
    database_max_overflow: int = 30
    
    # Redis
    redis_url: str = "redis://localhost:6379/0"
    redis_pool_size: int = 100
    
    # Monitoring
    log_directories: List[str] = ["outputs", "output", "wbs_output"]
    file_watch_recursive: bool = True
    max_log_file_size_mb: int = 100
    
    # Performance
    websocket_max_connections: int = 100
    event_queue_maxsize: int = 10000
    cache_default_ttl: int = 300
    
    # Security
    cors_origins: List[str] = ["http://localhost:3000"]
    rate_limit_requests_per_minute: int = 1000
    
    class Config:
        env_file = ".env"
```

## Security Considerations

### 16. Security Architecture

**Authentication & Authorization**
- **Read-Only Access**: Dashboard provides read-only monitoring with no orchestrator control
- **IP Whitelisting**: Configurable IP restrictions for dashboard access
- **Session Management**: Secure WebSocket session handling with TTL expiration

**Data Protection**
- **Log Sanitization**: Automatic removal of sensitive data patterns from log displays
- **File Path Validation**: Restricted file system access within configured directories
- **SQL Injection Prevention**: Parameterized queries throughout database layer

**Network Security**
- **CORS Policy**: Strict cross-origin resource sharing configuration
- **Rate Limiting**: Per-IP request rate limiting via Redis
- **TLS/SSL**: HTTPS enforcement in production environments

## Implementation Phases

### 17. Development Roadmap

**Phase 1: Core Infrastructure (Weeks 1-2)**
- FastAPI server with basic REST API
- PostgreSQL schema and migrations
- Redis cache layer implementation
- Basic WebSocket connection handling

**Phase 2: Real-Time Monitoring (Weeks 3-4)**
- File system monitoring and log ingestion
- Workflow state tracking and progress calculation
- WebSocket event broadcasting
- Basic dashboard UI

**Phase 3: Advanced Features (Weeks 5-6)**
- Multi-workflow comparison interface
- Performance metrics and analytics
- Deliverable management system
- Advanced filtering and search

**Phase 4: Production Hardening (Weeks 7-8)**
- Comprehensive error handling and recovery
- Performance optimization and load testing
- Security hardening and vulnerability testing
- Documentation and deployment automation

This technical specification provides a comprehensive foundation for implementing a production-ready orchestrator dashboard that meets all performance, scalability, and integration requirements while maintaining compatibility with the existing agent orchestrator system.