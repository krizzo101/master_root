#!/usr/bin/env python3
"""
Test Context Isolation
Verifies that agents run in isolated contexts without interference.
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import List

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from context_isolated_orchestrator import ContextIsolatedOrchestrator, AgentTask


def create_test_tasks() -> List[AgentTask]:
    """Create test tasks that would normally interfere with each other."""
    
    tasks = [
        AgentTask(
            task_id="agent_1",
            task_type="analysis",
            prompt="Create a file called 'test_output.txt' with content 'Agent 1 was here'",
            context={"agent_number": 1, "test_value": "alpha"},
            mcp_needs=["shell_exec"],
        ),
        AgentTask(
            task_id="agent_2",
            task_type="analysis",
            prompt="Create a file called 'test_output.txt' with content 'Agent 2 was here'",
            context={"agent_number": 2, "test_value": "beta"},
            mcp_needs=["shell_exec"],
        ),
        AgentTask(
            task_id="agent_3",
            task_type="analysis",
            prompt="Create a file called 'test_output.txt' with content 'Agent 3 was here'",
            context={"agent_number": 3, "test_value": "gamma"},
            dependencies=["agent_1"],  # This depends on agent_1
            mcp_needs=["shell_exec"],
        ),
    ]
    
    return tasks


async def test_isolation():
    """Test that agents are properly isolated."""
    
    print("=" * 60)
    print("CONTEXT ISOLATION TEST")
    print("=" * 60)
    
    # Create test output directory
    test_dir = Path("test_isolation_output")
    test_dir.mkdir(exist_ok=True)
    
    # Test 1: Run with isolation enabled
    print("\nTest 1: Running with context isolation ENABLED...")
    orchestrator_isolated = ContextIsolatedOrchestrator(
        output_dir=test_dir / "isolated",
        max_parallel=2,
        enable_context_isolation=True,
        cleanup_on_completion=False,  # Don't cleanup so we can inspect
        use_optimizations=False,  # Disable for testing
    )
    
    try:
        # Mock token if needed
        orchestrator_isolated.token_pool.tokens = [
            os.environ.get("CLAUDE_CODE_TOKEN", "test_token_1"),
            os.environ.get("CLAUDE_CODE_TOKEN", "test_token_2"),
        ]
        
        tasks = create_test_tasks()
        results = await orchestrator_isolated.execute_batch(tasks)
        
        print(f"Completed: {orchestrator_isolated.metrics['completed']}/{orchestrator_isolated.metrics['total']}")
        print(f"Failed: {orchestrator_isolated.metrics['failed']}")
        
        # Check isolation
        print("\nChecking isolation:")
        agent_exec_dir = test_dir / "isolated" / ".agent_exec"
        if agent_exec_dir.exists():
            contexts = list(agent_exec_dir.iterdir())
            print(f"Created {len(contexts)} isolated contexts:")
            for ctx in contexts:
                print(f"  - {ctx.name}")
                
                # Check for test_output.txt in each context
                test_file = ctx / "workspace" / "test_output.txt"
                if test_file.exists():
                    content = test_file.read_text()
                    print(f"    Contains: {content.strip()}")
                
                # Check for MCP config
                mcp_config = ctx / "mcp_config.json"
                if mcp_config.exists():
                    print(f"    Has isolated MCP config: ✓")
                
                # Check for .env file
                env_file = ctx / ".env"
                if env_file.exists():
                    print(f"    Has isolated .env file: ✓")
        
    except Exception as e:
        print(f"Test 1 error: {e}")
    
    print("\n" + "=" * 60)
    
    # Test 2: Run without isolation (for comparison)
    print("\nTest 2: Running WITHOUT context isolation...")
    orchestrator_shared = ContextIsolatedOrchestrator(
        output_dir=test_dir / "shared",
        max_parallel=2,
        enable_context_isolation=False,  # Disabled
        use_optimizations=False,
    )
    
    try:
        # Mock token if needed
        orchestrator_shared.token_pool.tokens = [
            os.environ.get("CLAUDE_CODE_TOKEN", "test_token_1"),
            os.environ.get("CLAUDE_CODE_TOKEN", "test_token_2"),
        ]
        
        tasks = create_test_tasks()
        results = await orchestrator_shared.execute_batch(tasks)
        
        print(f"Completed: {orchestrator_shared.metrics['completed']}/{orchestrator_shared.metrics['total']}")
        print(f"Failed: {orchestrator_shared.metrics['failed']}")
        
        # Check for conflicts
        print("\nChecking shared context:")
        shared_output = test_dir / "shared" / "test_output.txt"
        if shared_output.exists():
            content = shared_output.read_text()
            print(f"Shared test_output.txt contains: {content.strip()}")
            print("⚠️  File was overwritten by multiple agents (no isolation)")
        else:
            print("No test_output.txt found in shared context")
        
    except Exception as e:
        print(f"Test 2 error: {e}")
    
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    print("\nWith isolation:")
    print("  - Each agent runs in its own .agent_exec/[id]/ directory")
    print("  - Agents cannot interfere with each other's files")
    print("  - Each agent has its own MCP config and environment")
    print("  - Contexts can be cleaned up after completion")
    
    print("\nWithout isolation:")
    print("  - All agents share the same directory")
    print("  - Files can be overwritten by concurrent agents")
    print("  - Potential for config and environment conflicts")
    
    return True


async def test_cleanup():
    """Test that cleanup properly removes isolated contexts."""
    
    print("\n" + "=" * 60)
    print("CLEANUP TEST")
    print("=" * 60)
    
    test_dir = Path("test_cleanup_output")
    test_dir.mkdir(exist_ok=True)
    
    orchestrator = ContextIsolatedOrchestrator(
        output_dir=test_dir,
        max_parallel=1,
        enable_context_isolation=True,
        cleanup_on_completion=True,  # Enable cleanup
        use_optimizations=False,
    )
    
    try:
        # Mock token
        orchestrator.token_pool.tokens = [
            os.environ.get("CLAUDE_CODE_TOKEN", "test_token"),
        ]
        
        task = AgentTask(
            task_id="cleanup_test",
            task_type="analysis",
            prompt="Create a temporary file",
        )
        
        result = await orchestrator.execute_agent(task)
        
        # Check that context was cleaned up
        agent_exec_dir = test_dir / ".agent_exec"
        if agent_exec_dir.exists():
            remaining = list(agent_exec_dir.iterdir())
            if len(remaining) == 0:
                print("✓ Context was properly cleaned up")
            else:
                print(f"⚠️  {len(remaining)} contexts remain after cleanup")
        
        # Check that artifacts were preserved
        artifacts_dir = test_dir / "artifacts"
        if artifacts_dir.exists():
            print("✓ Artifacts directory was created")
        
    except Exception as e:
        print(f"Cleanup test error: {e}")
    
    return True


async def main():
    """Run all tests."""
    
    print("\n🧪 Testing Context Isolation Implementation\n")
    
    # Check for token
    if not os.environ.get("CLAUDE_CODE_TOKEN"):
        print("⚠️  Warning: CLAUDE_CODE_TOKEN not set")
        print("   Tests will create mock structures but agents won't actually run")
        print("   Set CLAUDE_CODE_TOKEN to run full tests\n")
    
    # Run tests
    await test_isolation()
    await test_cleanup()
    
    print("\n✅ Context isolation tests complete!")
    print("\nKey Features Implemented:")
    print("  1. Isolated .agent_exec/[agent_id]/ directories")
    print("  2. Agent-specific MCP configurations")
    print("  3. Isolated environment variables")
    print("  4. Automatic context cleanup")
    print("  5. Artifact preservation before cleanup")
    print("  6. No config leakage between agents")


if __name__ == "__main__":
    asyncio.run(main())