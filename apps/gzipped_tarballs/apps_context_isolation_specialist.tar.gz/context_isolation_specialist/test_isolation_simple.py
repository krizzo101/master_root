#!/usr/bin/env python3
"""
Simple Test for Context Isolation
Tests the basic isolation mechanism without requiring actual Claude tokens.
"""

import asyncio
import json
import shutil
from pathlib import Path
from typing import List

# Import the orchestrator
import sys
sys.path.insert(0, str(Path(__file__).parent))
from context_isolated_orchestrator import ContextIsolatedOrchestrator, AgentTask


def test_directory_structure():
    """Test that the isolation creates the expected directory structure."""
    
    print("\n" + "=" * 60)
    print("TEST: Directory Structure Creation")
    print("=" * 60)
    
    # Clean up any previous test
    test_dir = Path("test_structure")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    
    # Create orchestrator with isolation
    orchestrator = ContextIsolatedOrchestrator(
        output_dir=test_dir,
        tokens=["mock_token_1", "mock_token_2"],  # Provide mock tokens
        enable_context_isolation=True,
        cleanup_on_completion=False,  # Keep for inspection
    )
    
    # Create a test task
    task = AgentTask(
        task_id="test_task_1",
        task_type="analysis",
        prompt="Test prompt",
        context={"test_key": "test_value"},
    )
    
    # Create isolated context
    context_dir = orchestrator._create_isolated_context(task)
    
    # Verify structure
    print(f"\n✓ Created context at: {context_dir}")
    
    expected_dirs = ["workspace", "logs", "data"]
    for dir_name in expected_dirs:
        dir_path = context_dir / dir_name
        if dir_path.exists():
            print(f"  ✓ {dir_name}/ exists")
        else:
            print(f"  ✗ {dir_name}/ missing")
    
    # Generate MCP config
    mcp_config_path = orchestrator._generate_isolated_mcp_config(task, context_dir)
    if mcp_config_path.exists():
        print(f"  ✓ mcp_config.json created")
        
        # Check content
        with open(mcp_config_path) as f:
            config = json.load(f)
            if "mcpServers" in config:
                print(f"    - Contains {len(config['mcpServers'])} MCP servers")
    
    # Create env file
    env_file_path = orchestrator._create_isolated_env_file(task, context_dir)
    if env_file_path.exists():
        print(f"  ✓ .env file created")
        
        # Check content
        env_content = env_file_path.read_text()
        if "AGENT_ID=test_task_1" in env_content:
            print(f"    - Contains correct AGENT_ID")
        if "ISOLATION_ENABLED=true" in env_content:
            print(f"    - Isolation flag set")
    
    # Test cleanup
    print("\nTesting cleanup...")
    orchestrator._cleanup_isolated_context(task.task_id)
    
    if not context_dir.exists():
        print("✓ Context successfully cleaned up")
    else:
        print("✗ Context not cleaned up")
    
    return True


def test_multiple_contexts():
    """Test that multiple agents get separate contexts."""
    
    print("\n" + "=" * 60)
    print("TEST: Multiple Agent Isolation")
    print("=" * 60)
    
    # Clean up
    test_dir = Path("test_multiple")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    
    # Create orchestrator
    orchestrator = ContextIsolatedOrchestrator(
        output_dir=test_dir,
        tokens=["mock_token_1", "mock_token_2"],
        enable_context_isolation=True,
        cleanup_on_completion=False,
    )
    
    # Create multiple tasks
    tasks = [
        AgentTask(task_id=f"agent_{i}", task_type="test", prompt=f"Task {i}")
        for i in range(3)
    ]
    
    # Create contexts for each
    contexts = []
    for task in tasks:
        ctx = orchestrator._create_isolated_context(task)
        contexts.append(ctx)
        print(f"Created context for {task.task_id}: {ctx.name}")
    
    # Verify they're different
    context_names = [c.name for c in contexts]
    if len(set(context_names)) == len(context_names):
        print("\n✓ All contexts have unique directories")
    else:
        print("\n✗ Context directories are not unique!")
    
    # Create test files in each context
    for i, (task, ctx) in enumerate(zip(tasks, contexts)):
        test_file = ctx / "workspace" / "test.txt"
        test_file.write_text(f"Agent {i} data")
        
        # Verify isolation
        content = test_file.read_text()
        if content == f"Agent {i} data":
            print(f"  ✓ {task.task_id} has isolated file with correct content")
        else:
            print(f"  ✗ {task.task_id} file content incorrect")
    
    # Check that all contexts are tracked
    print(f"\nTracked contexts: {len(orchestrator.isolated_contexts)}")
    for task_id, path in orchestrator.isolated_contexts.items():
        print(f"  - {task_id}: {path.name}")
    
    return True


def test_config_isolation():
    """Test that MCP configs are isolated per agent."""
    
    print("\n" + "=" * 60)
    print("TEST: Configuration Isolation")
    print("=" * 60)
    
    test_dir = Path("test_config")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    
    orchestrator = ContextIsolatedOrchestrator(
        output_dir=test_dir,
        tokens=["mock_token"],
        enable_context_isolation=True,
        cleanup_on_completion=False,
    )
    
    # Create tasks with different MCP needs
    task1 = AgentTask(
        task_id="research_agent",
        task_type="research",
        prompt="Research task",
        mcp_needs=["mcp_web_search", "research_papers"],
    )
    
    task2 = AgentTask(
        task_id="system_agent",
        task_type="system",
        prompt="System task",
        mcp_needs=["shell_exec"],
    )
    
    # Create contexts and configs
    ctx1 = orchestrator._create_isolated_context(task1)
    config1_path = orchestrator._generate_isolated_mcp_config(task1, ctx1)
    
    ctx2 = orchestrator._create_isolated_context(task2)
    config2_path = orchestrator._generate_isolated_mcp_config(task2, ctx2)
    
    # Load and compare configs
    with open(config1_path) as f:
        config1 = json.load(f)
    
    with open(config2_path) as f:
        config2 = json.load(f)
    
    print(f"\nAgent 1 (research) MCP servers: {list(config1.get('mcpServers', {}).keys())}")
    print(f"Agent 2 (system) MCP servers: {list(config2.get('mcpServers', {}).keys())}")
    
    # Check environment isolation in configs
    for server in config1.get("mcpServers", {}).values():
        if server.get("env", {}).get("AGENT_TASK_ID") == "research_agent":
            print("✓ Agent 1 has correct task ID in MCP env")
            break
    
    for server in config2.get("mcpServers", {}).values():
        if server.get("env", {}).get("AGENT_TASK_ID") == "system_agent":
            print("✓ Agent 2 has correct task ID in MCP env")
            break
    
    return True


def test_artifact_preservation():
    """Test that artifacts are preserved before cleanup."""
    
    print("\n" + "=" * 60)
    print("TEST: Artifact Preservation")
    print("=" * 60)
    
    test_dir = Path("test_artifacts")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    
    orchestrator = ContextIsolatedOrchestrator(
        output_dir=test_dir,
        tokens=["mock_token"],
        enable_context_isolation=True,
        cleanup_on_completion=True,  # Enable cleanup
    )
    
    # Create task and context
    task = AgentTask(
        task_id="artifact_test",
        task_type="test",
        prompt="Create artifacts",
    )
    
    ctx = orchestrator._create_isolated_context(task)
    
    # Create some "artifacts" in workspace
    workspace = ctx / "workspace"
    (workspace / "result.json").write_text('{"status": "success"}')
    (workspace / "output.txt").write_text("Important output")
    
    print(f"Created artifacts in: {workspace}")
    
    # Cleanup (should preserve artifacts)
    orchestrator._cleanup_isolated_context(task.task_id)
    
    # Check artifacts were preserved
    artifacts_dir = test_dir / "artifacts" / task.task_id
    if artifacts_dir.exists():
        print(f"✓ Artifacts preserved at: {artifacts_dir}")
        
        preserved_files = list(artifacts_dir.iterdir())
        print(f"  Preserved {len(preserved_files)} files:")
        for f in preserved_files:
            print(f"    - {f.name}")
    else:
        print("✗ Artifacts not preserved")
    
    # Check context was removed
    if not ctx.exists():
        print("✓ Original context was cleaned up")
    else:
        print("✗ Original context still exists")
    
    return True


def main():
    """Run all tests."""
    
    print("\n🧪 Context Isolation Implementation Tests")
    print("=" * 60)
    
    tests = [
        ("Directory Structure", test_directory_structure),
        ("Multiple Contexts", test_multiple_contexts),
        ("Config Isolation", test_config_isolation),
        ("Artifact Preservation", test_artifact_preservation),
    ]
    
    passed = 0
    failed = 0
    
    for name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"\n✗ {name} failed with error: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("TEST RESULTS")
    print("=" * 60)
    print(f"Passed: {passed}/{len(tests)}")
    print(f"Failed: {failed}/{len(tests)}")
    
    if failed == 0:
        print("\n✅ All tests passed! Context isolation is working correctly.")
    else:
        print(f"\n⚠️  {failed} test(s) failed. Review the output above.")
    
    # Cleanup test directories
    print("\nCleaning up test directories...")
    for dir_name in ["test_structure", "test_multiple", "test_config", "test_artifacts"]:
        test_dir = Path(dir_name)
        if test_dir.exists():
            shutil.rmtree(test_dir)
            print(f"  Removed {dir_name}/")


if __name__ == "__main__":
    main()