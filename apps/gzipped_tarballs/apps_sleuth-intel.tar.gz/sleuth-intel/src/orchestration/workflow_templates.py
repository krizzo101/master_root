"""
Workflow Templates for Sleuth Intel Investigation Orchestration

Provides pre-configured, optimized workflow templates for common intelligence gathering scenarios.
Each workflow template includes agent coordination, dependency chains, error handling, and result formatting.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union, Callable

from ..models.query import IntelligenceQuery, QueryType, QueryPriority, DataProvider, CacheStrategy
from ..models.intelligence import IntelligenceResult
from .sleuth_orchestrator import WorkflowType, WorkflowConfig, SleuthIntelOrchestrator


class InvestigationDepth(Enum):
    """Investigation depth levels"""
    BASIC = "basic"
    COMPREHENSIVE = "comprehensive"
    DEEP = "deep"
    FORENSIC = "forensic"


class OutputFormat(Enum):
    """Supported output formats"""
    JSON = "json"
    PDF = "pdf"
    CSV = "csv"
    HTML = "html"
    MARKDOWN = "markdown"


@dataclass
class WorkflowTemplate:
    """Base workflow template configuration"""
    name: str
    description: str
    depth: InvestigationDepth
    estimated_cost: float
    estimated_time_minutes: int
    required_agents: List[str]
    optional_agents: List[str] = field(default_factory=list)
    dependencies: Dict[str, List[str]] = field(default_factory=dict)
    config_overrides: Dict[str, Any] = field(default_factory=dict)
    output_formats: List[OutputFormat] = field(default_factory=lambda: [OutputFormat.JSON])


@dataclass
class WorkflowBudget:
    """Budget constraints for workflow execution"""
    max_cost_usd: Optional[float] = None
    max_credits: Optional[int] = None
    max_time_minutes: Optional[int] = None
    priority_allocation: Dict[str, float] = field(default_factory=dict)  # agent_type -> budget_percentage


@dataclass
class WorkflowCustomization:
    """Customization options for workflow templates"""
    skip_agents: List[str] = field(default_factory=list)
    additional_agents: List[str] = field(default_factory=list)
    custom_config: Dict[str, Any] = field(default_factory=dict)
    result_filters: List[str] = field(default_factory=list)
    correlation_rules: Dict[str, Any] = field(default_factory=dict)


class WorkflowTemplateManager:
    """Manages workflow templates and execution"""

    def __init__(self, orchestrator: SleuthIntelOrchestrator):
        self.orchestrator = orchestrator
        self.templates = {}
        self._initialize_templates()

    def _initialize_templates(self):
        """Initialize all workflow templates"""
        self.templates = {
            'phone_investigation': self._create_phone_investigation_template(),
            'person_investigation': self._create_person_investigation_template(),
            'business_due_diligence': self._create_business_due_diligence_template(),
            'address_analysis': self._create_address_analysis_template(),
            'bulk_processing': self._create_bulk_processing_template(),
        }

    def _create_phone_investigation_template(self) -> Dict[str, WorkflowTemplate]:
        """Create phone investigation workflow templates"""
        return {
            'basic': WorkflowTemplate(
                name="Phone Investigation - Basic",
                description="Basic phone number lookup with carrier and location data",
                depth=InvestigationDepth.BASIC,
                estimated_cost=0.50,
                estimated_time_minutes=2,
                required_agents=['phone_search_agent'],
                dependencies={},
                config_overrides={
                    'max_parallel_agents': 1,
                    'timeout_seconds': 120,
                    'cost_optimization': True
                }
            ),
            'comprehensive': WorkflowTemplate(
                name="Phone Investigation - Comprehensive",
                description="Comprehensive phone investigation with owner lookup and social media discovery",
                depth=InvestigationDepth.COMPREHENSIVE,
                estimated_cost=2.50,
                estimated_time_minutes=5,
                required_agents=['phone_search_agent', 'person_search_agent'],
                optional_agents=['email_search_agent'],
                dependencies={
                    'person_search_agent': ['phone_search_agent'],
                    'email_search_agent': ['person_search_agent']
                },
                config_overrides={
                    'max_parallel_agents': 2,
                    'correlation_threshold': 0.7
                }
            ),
            'deep': WorkflowTemplate(
                name="Phone Investigation - Deep",
                description="Deep investigation with business connections and historical data",
                depth=InvestigationDepth.DEEP,
                estimated_cost=8.00,
                estimated_time_minutes=15,
                required_agents=['phone_search_agent', 'person_search_agent', 'business_search_agent'],
                optional_agents=['email_search_agent', 'address_search_agent', 'data_enrichment_agent'],
                dependencies={
                    'person_search_agent': ['phone_search_agent'],
                    'business_search_agent': ['person_search_agent'],
                    'email_search_agent': ['person_search_agent'],
                    'address_search_agent': ['person_search_agent'],
                    'data_enrichment_agent': ['person_search_agent', 'business_search_agent']
                },
                config_overrides={
                    'max_parallel_agents': 4,
                    'enable_caching': True,
                    'cache_ttl': 7200
                }
            )
        }

    def _create_person_investigation_template(self) -> Dict[str, WorkflowTemplate]:
        """Create person investigation workflow templates"""
        return {
            'basic': WorkflowTemplate(
                name="Person Investigation - Basic",
                description="Basic person search with contact information",
                depth=InvestigationDepth.BASIC,
                estimated_cost=1.00,
                estimated_time_minutes=3,
                required_agents=['person_search_agent'],
                config_overrides={'timeout_seconds': 180}
            ),
            'comprehensive': WorkflowTemplate(
                name="Person Investigation - Comprehensive",
                description="Comprehensive person investigation with multi-source verification",
                depth=InvestigationDepth.COMPREHENSIVE,
                estimated_cost=5.00,
                estimated_time_minutes=8,
                required_agents=['person_search_agent', 'phone_search_agent', 'email_search_agent'],
                optional_agents=['address_search_agent'],
                dependencies={
                    'phone_search_agent': ['person_search_agent'],
                    'email_search_agent': ['person_search_agent'],
                    'address_search_agent': ['person_search_agent']
                },
                config_overrides={
                    'max_parallel_agents': 3,
                    'correlation_threshold': 0.8
                }
            ),
            'deep': WorkflowTemplate(
                name="Person Investigation - Deep",
                description="Deep background investigation with business and asset discovery",
                depth=InvestigationDepth.DEEP,
                estimated_cost=15.00,
                estimated_time_minutes=25,
                required_agents=['person_search_agent', 'phone_search_agent', 'email_search_agent', 'business_search_agent'],
                optional_agents=['address_search_agent', 'data_enrichment_agent', 'analysis_agent'],
                dependencies={
                    'phone_search_agent': ['person_search_agent'],
                    'email_search_agent': ['person_search_agent'],
                    'business_search_agent': ['person_search_agent'],
                    'address_search_agent': ['person_search_agent'],
                    'data_enrichment_agent': ['person_search_agent', 'business_search_agent'],
                    'analysis_agent': ['data_enrichment_agent']
                },
                config_overrides={
                    'max_parallel_agents': 5,
                    'enable_caching': True,
                    'retry_failed_queries': True
                }
            )
        }

    def _create_business_due_diligence_template(self) -> Dict[str, WorkflowTemplate]:
        """Create business due diligence workflow templates"""
        return {
            'basic': WorkflowTemplate(
                name="Business Due Diligence - Basic",
                description="Basic business verification and registration lookup",
                depth=InvestigationDepth.BASIC,
                estimated_cost=2.00,
                estimated_time_minutes=5,
                required_agents=['business_search_agent'],
                config_overrides={'preferred_providers': ['enformion']}
            ),
            'comprehensive': WorkflowTemplate(
                name="Business Due Diligence - Comprehensive",
                description="Comprehensive business analysis with executive and financial data",
                depth=InvestigationDepth.COMPREHENSIVE,
                estimated_cost=8.00,
                estimated_time_minutes=12,
                required_agents=['business_search_agent', 'person_search_agent'],
                optional_agents=['address_search_agent'],
                dependencies={
                    'person_search_agent': ['business_search_agent'],  # Search for executives
                    'address_search_agent': ['business_search_agent']
                },
                config_overrides={
                    'max_parallel_agents': 3,
                    'correlation_threshold': 0.75
                }
            ),
            'deep': WorkflowTemplate(
                name="Business Due Diligence - Deep",
                description="Deep forensic business investigation with network analysis",
                depth=InvestigationDepth.DEEP,
                estimated_cost=25.00,
                estimated_time_minutes=35,
                required_agents=['business_search_agent', 'person_search_agent', 'address_search_agent'],
                optional_agents=['phone_search_agent', 'email_search_agent', 'data_enrichment_agent', 'analysis_agent'],
                dependencies={
                    'person_search_agent': ['business_search_agent'],
                    'address_search_agent': ['business_search_agent'],
                    'phone_search_agent': ['business_search_agent', 'person_search_agent'],
                    'email_search_agent': ['person_search_agent'],
                    'data_enrichment_agent': ['business_search_agent', 'person_search_agent'],
                    'analysis_agent': ['data_enrichment_agent']
                },
                config_overrides={
                    'max_parallel_agents': 6,
                    'enable_caching': True,
                    'cache_ttl': 3600
                }
            )
        }

    def _create_address_analysis_template(self) -> Dict[str, WorkflowTemplate]:
        """Create address analysis workflow templates"""
        return {
            'basic': WorkflowTemplate(
                name="Address Analysis - Basic",
                description="Basic address verification and property lookup",
                depth=InvestigationDepth.BASIC,
                estimated_cost=0.75,
                estimated_time_minutes=2,
                required_agents=['address_search_agent']
            ),
            'comprehensive': WorkflowTemplate(
                name="Address Analysis - Comprehensive",
                description="Comprehensive address investigation with resident history",
                depth=InvestigationDepth.COMPREHENSIVE,
                estimated_cost=3.50,
                estimated_time_minutes=7,
                required_agents=['address_search_agent', 'person_search_agent'],
                optional_agents=['business_search_agent'],
                dependencies={
                    'person_search_agent': ['address_search_agent'],
                    'business_search_agent': ['address_search_agent']
                },
                config_overrides={'max_parallel_agents': 2}
            ),
            'deep': WorkflowTemplate(
                name="Address Analysis - Deep",
                description="Deep address forensics with ownership and financial history",
                depth=InvestigationDepth.DEEP,
                estimated_cost=10.00,
                estimated_time_minutes=18,
                required_agents=['address_search_agent', 'person_search_agent', 'business_search_agent'],
                optional_agents=['phone_search_agent', 'email_search_agent', 'data_enrichment_agent'],
                dependencies={
                    'person_search_agent': ['address_search_agent'],
                    'business_search_agent': ['address_search_agent'],
                    'phone_search_agent': ['person_search_agent'],
                    'email_search_agent': ['person_search_agent'],
                    'data_enrichment_agent': ['person_search_agent', 'business_search_agent']
                },
                config_overrides={'max_parallel_agents': 4}
            )
        }

    def _create_bulk_processing_template(self) -> Dict[str, WorkflowTemplate]:
        """Create bulk processing workflow templates"""
        return {
            'basic': WorkflowTemplate(
                name="Bulk Processing - Basic",
                description="Basic bulk processing with minimal data points",
                depth=InvestigationDepth.BASIC,
                estimated_cost=0.25,  # Per record
                estimated_time_minutes=1,  # Per record
                required_agents=['person_search_agent'],
                config_overrides={
                    'max_parallel_agents': 10,
                    'cost_optimization': True,
                    'enable_caching': True,
                    'cache_ttl': 86400  # 24 hours for bulk operations
                }
            ),
            'comprehensive': WorkflowTemplate(
                name="Bulk Processing - Comprehensive",
                description="Comprehensive bulk processing with cross-referencing",
                depth=InvestigationDepth.COMPREHENSIVE,
                estimated_cost=1.50,  # Per record
                estimated_time_minutes=3,  # Per record
                required_agents=['person_search_agent', 'phone_search_agent'],
                optional_agents=['email_search_agent'],
                dependencies={
                    'phone_search_agent': ['person_search_agent'],
                    'email_search_agent': ['person_search_agent']
                },
                config_overrides={
                    'max_parallel_agents': 8,
                    'correlation_threshold': 0.6,
                    'enable_caching': True
                }
            )
        }

    async def execute_workflow(
        self,
        template_type: str,
        depth: str,
        query_data: Union[Dict[str, Any], List[Dict[str, Any]]],
        budget: Optional[WorkflowBudget] = None,
        customization: Optional[WorkflowCustomization] = None,
        progress_callback: Optional[Callable] = None
    ) -> Dict[str, Any]:
        """Execute a workflow template with the given parameters"""
        
        if template_type not in self.templates:
            raise ValueError(f"Unknown template type: {template_type}")
        
        if depth not in self.templates[template_type]:
            raise ValueError(f"Unknown depth '{depth}' for template '{template_type}'")
        
        template = self.templates[template_type][depth]
        
        # Apply budget constraints
        if budget:
            template = self._apply_budget_constraints(template, budget)
        
        # Apply customizations
        if customization:
            template = self._apply_customization(template, customization)
        
        # Create workflow configuration
        workflow_config = self._create_workflow_config(template)
        
        # Generate queries
        queries = self._generate_queries(template, query_data)
        
        # Execute workflow
        workflow_id = await self.orchestrator.start_workflow(
            workflow_type=self._determine_workflow_type(template),
            queries=queries,
            config=workflow_config
        )
        
        # Monitor progress
        if progress_callback:
            await self._monitor_progress(workflow_id, progress_callback)
        
        # Wait for completion
        results = await self.orchestrator.wait_for_completion(workflow_id)
        
        # Format results
        formatted_results = self._format_results(template, results)
        
        return {
            'workflow_id': workflow_id,
            'template': template.name,
            'results': formatted_results,
            'metadata': {
                'execution_time': (datetime.now() - results.start_time).total_seconds(),
                'total_cost': self._calculate_cost(results),
                'agents_used': list(results.agent_assignments.values()),
                'success_rate': len([r for r in results.results if r.success]) / len(results.results) if results.results else 0
            }
        }

    def _apply_budget_constraints(self, template: WorkflowTemplate, budget: WorkflowBudget) -> WorkflowTemplate:
        """Apply budget constraints to template"""
        if budget.max_cost_usd and template.estimated_cost > budget.max_cost_usd:
            # Reduce scope or switch to basic template
            if template.depth != InvestigationDepth.BASIC:
                template.depth = InvestigationDepth.BASIC
                template.optional_agents = []
        
        if budget.max_time_minutes and template.estimated_time_minutes > budget.max_time_minutes:
            # Increase parallelization
            template.config_overrides['max_parallel_agents'] = min(
                template.config_overrides.get('max_parallel_agents', 5) + 2,
                10
            )
        
        return template

    def _apply_customization(self, template: WorkflowTemplate, customization: WorkflowCustomization) -> WorkflowTemplate:
        """Apply customization options to template"""
        # Remove skipped agents
        for agent in customization.skip_agents:
            if agent in template.required_agents:
                template.required_agents.remove(agent)
            if agent in template.optional_agents:
                template.optional_agents.remove(agent)
        
        # Add additional agents
        template.optional_agents.extend(customization.additional_agents)
        
        # Apply custom configuration
        template.config_overrides.update(customization.custom_config)
        
        return template

    def _create_workflow_config(self, template: WorkflowTemplate) -> WorkflowConfig:
        """Create workflow configuration from template"""
        config = WorkflowConfig()
        
        # Apply template overrides
        for key, value in template.config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        return config

    def _generate_queries(self, template: WorkflowTemplate, query_data: Union[Dict[str, Any], List[Dict[str, Any]]]) -> List[IntelligenceQuery]:
        """Generate queries based on template and input data"""
        queries = []
        
        if isinstance(query_data, dict):
            query_data = [query_data]
        
        for data in query_data:
            for agent_type in template.required_agents + template.optional_agents:
                query = self._create_query_for_agent(agent_type, data, template)
                if query:
                    queries.append(query)
        
        return queries

    def _create_query_for_agent(self, agent_type: str, data: Dict[str, Any], template: WorkflowTemplate) -> Optional[IntelligenceQuery]:
        """Create a query for a specific agent type"""
        query_type_map = {
            'person_search_agent': QueryType.PERSON_SEARCH,
            'business_search_agent': QueryType.BUSINESS_SEARCH,
            'phone_search_agent': QueryType.PHONE_LOOKUP,
            'email_search_agent': QueryType.EMAIL_LOOKUP,
            'address_search_agent': QueryType.ADDRESS_LOOKUP
        }
        
        if agent_type not in query_type_map:
            return None
        
        query_type = query_type_map[agent_type]
        
        # Extract relevant data based on query type
        query_params = self._extract_query_params(query_type, data)
        
        if not query_params:
            return None
        
        return IntelligenceQuery(
            query_type=query_type,
            parameters=query_params,
            priority=QueryPriority.NORMAL if agent_type in template.required_agents else QueryPriority.LOW,
            cache_strategy=CacheStrategy.USE_CACHE if template.config_overrides.get('enable_caching', True) else CacheStrategy.NO_CACHE,
            providers=[DataProvider.ALL] if template.depth == InvestigationDepth.DEEP else [DataProvider.ENFORMION]
        )

    def _extract_query_params(self, query_type: QueryType, data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract relevant parameters for query type"""
        param_map = {
            QueryType.PERSON_SEARCH: ['first_name', 'last_name', 'middle_name', 'age', 'city', 'state'],
            QueryType.BUSINESS_SEARCH: ['company_name', 'city', 'state', 'zip_code'],
            QueryType.PHONE_LOOKUP: ['phone_number'],
            QueryType.EMAIL_LOOKUP: ['email_address'],
            QueryType.ADDRESS_LOOKUP: ['street_address', 'city', 'state', 'zip_code']
        }
        
        relevant_keys = param_map.get(query_type, [])
        return {k: v for k, v in data.items() if k in relevant_keys and v}

    def _determine_workflow_type(self, template: WorkflowTemplate) -> WorkflowType:
        """Determine workflow type based on template"""
        if len(template.required_agents) == 1 and not template.optional_agents:
            return WorkflowType.SINGLE_SOURCE
        elif template.dependencies:
            return WorkflowType.INVESTIGATION_CHAIN
        elif 'bulk' in template.name.lower():
            return WorkflowType.BULK_PROCESSING
        else:
            return WorkflowType.MULTI_SOURCE_PARALLEL

    async def _monitor_progress(self, workflow_id: str, callback: Callable):
        """Monitor workflow progress and call callback with updates"""
        while True:
            status = await self.orchestrator.get_workflow_status(workflow_id)
            
            await callback({
                'workflow_id': workflow_id,
                'status': status.status,
                'progress': len(status.results) / len(status.queries) if status.queries else 0,
                'agents_active': len([a for a in status.agent_assignments.values()]),
                'errors': status.errors
            })
            
            if status.status in ['completed', 'failed']:
                break
                
            await asyncio.sleep(2)

    def _format_results(self, template: WorkflowTemplate, results: Any) -> Dict[str, Any]:
        """Format workflow results based on template requirements"""
        formatted = {
            'summary': self._create_result_summary(results),
            'detailed_results': [],
            'correlations': [],
            'confidence_scores': {},
            'data_sources': set()
        }
        
        # Process each result
        for result in results.results:
            formatted_result = {
                'agent_type': result.agent_type if hasattr(result, 'agent_type') else 'unknown',
                'query_id': result.query_id if hasattr(result, 'query_id') else None,
                'success': result.success,
                'data': result.data if result.success else None,
                'error': result.error_message if not result.success else None,
                'timestamp': result.timestamp,
                'confidence': result.confidence if hasattr(result, 'confidence') else 0.0
            }
            formatted['detailed_results'].append(formatted_result)
            
            # Track data sources
            if hasattr(result, 'provider'):
                formatted['data_sources'].add(result.provider)
        
        # Calculate correlations
        formatted['correlations'] = self._calculate_correlations(results.results)
        
        # Convert set to list for JSON serialization
        formatted['data_sources'] = list(formatted['data_sources'])
        
        return formatted

    def _create_result_summary(self, results: Any) -> Dict[str, Any]:
        """Create a summary of workflow results"""
        total_queries = len(results.results)
        successful_queries = len([r for r in results.results if r.success])
        
        return {
            'total_queries': total_queries,
            'successful_queries': successful_queries,
            'success_rate': successful_queries / total_queries if total_queries > 0 else 0,
            'execution_time_seconds': (results.end_time - results.start_time).total_seconds() if results.end_time else None,
            'unique_data_points': self._count_unique_data_points(results.results),
            'coverage_score': self._calculate_coverage_score(results.results)
        }

    def _calculate_correlations(self, results: List[IntelligenceResult]) -> List[Dict[str, Any]]:
        """Calculate correlations between results"""
        correlations = []
        
        # Simple correlation detection based on common fields
        for i, result1 in enumerate(results):
            for j, result2 in enumerate(results[i+1:], i+1):
                if result1.success and result2.success:
                    correlation = self._calculate_result_correlation(result1, result2)
                    if correlation > 0.5:  # Minimum correlation threshold
                        correlations.append({
                            'result_1': i,
                            'result_2': j,
                            'correlation_score': correlation,
                            'common_fields': self._find_common_fields(result1.data, result2.data)
                        })
        
        return correlations

    def _calculate_result_correlation(self, result1: IntelligenceResult, result2: IntelligenceResult) -> float:
        """Calculate correlation score between two results"""
        if not (hasattr(result1, 'data') and hasattr(result2, 'data')):
            return 0.0
        
        common_fields = self._find_common_fields(result1.data, result2.data)
        total_fields = len(set(list(result1.data.keys()) + list(result2.data.keys())))
        
        return len(common_fields) / total_fields if total_fields > 0 else 0.0

    def _find_common_fields(self, data1: Dict[str, Any], data2: Dict[str, Any]) -> List[str]:
        """Find common fields with matching values"""
        common = []
        for key in data1.keys():
            if key in data2 and data1[key] == data2[key]:
                common.append(key)
        return common

    def _count_unique_data_points(self, results: List[IntelligenceResult]) -> int:
        """Count unique data points across all results"""
        unique_points = set()
        
        for result in results:
            if result.success and hasattr(result, 'data'):
                for key, value in result.data.items():
                    if value:  # Only count non-empty values
                        unique_points.add(f"{key}:{value}")
        
        return len(unique_points)

    def _calculate_coverage_score(self, results: List[IntelligenceResult]) -> float:
        """Calculate coverage score based on expected vs actual data points"""
        # This would be more sophisticated in a real implementation
        expected_fields = ['name', 'phone', 'email', 'address', 'business']
        found_fields = set()
        
        for result in results:
            if result.success and hasattr(result, 'data'):
                for key in result.data.keys():
                    for expected_field in expected_fields:
                        if expected_field.lower() in key.lower():
                            found_fields.add(expected_field)
        
        return len(found_fields) / len(expected_fields)

    def _calculate_cost(self, results: Any) -> float:
        """Calculate total cost of workflow execution"""
        # This would integrate with actual billing system
        base_cost = 0.10  # Base cost per query
        return len(results.results) * base_cost

    def get_available_templates(self) -> Dict[str, Dict[str, str]]:
        """Get list of available workflow templates"""
        available = {}
        
        for template_type, depths in self.templates.items():
            available[template_type] = {}
            for depth, template in depths.items():
                available[template_type][depth] = {
                    'name': template.name,
                    'description': template.description,
                    'estimated_cost': template.estimated_cost,
                    'estimated_time_minutes': template.estimated_time_minutes,
                    'required_agents': template.required_agents,
                    'optional_agents': template.optional_agents
                }
        
        return available

    def estimate_workflow_cost(
        self,
        template_type: str,
        depth: str,
        record_count: int = 1
    ) -> Dict[str, float]:
        """Estimate workflow execution cost"""
        if template_type not in self.templates or depth not in self.templates[template_type]:
            raise ValueError(f"Invalid template: {template_type}/{depth}")
        
        template = self.templates[template_type][depth]
        
        base_cost = template.estimated_cost * record_count
        time_cost = template.estimated_time_minutes * 0.01 * record_count  # Rough time cost
        
        return {
            'base_cost': base_cost,
            'time_cost': time_cost,
            'total_estimated_cost': base_cost + time_cost,
            'per_record_cost': template.estimated_cost
        }


# Export workflow template functions for direct use
async def phone_investigation_workflow(
    phone_number: str,
    depth: InvestigationDepth = InvestigationDepth.BASIC,
    orchestrator: Optional[SleuthIntelOrchestrator] = None,
    **kwargs
) -> Dict[str, Any]:
    """Execute phone investigation workflow"""
    if not orchestrator:
        orchestrator = SleuthIntelOrchestrator()
    
    manager = WorkflowTemplateManager(orchestrator)
    return await manager.execute_workflow(
        'phone_investigation',
        depth.value,
        {'phone_number': phone_number},
        **kwargs
    )


async def person_investigation_workflow(
    first_name: str,
    last_name: str,
    city: Optional[str] = None,
    state: Optional[str] = None,
    depth: InvestigationDepth = InvestigationDepth.BASIC,
    orchestrator: Optional[SleuthIntelOrchestrator] = None,
    **kwargs
) -> Dict[str, Any]:
    """Execute person investigation workflow"""
    if not orchestrator:
        orchestrator = SleuthIntelOrchestrator()
    
    manager = WorkflowTemplateManager(orchestrator)
    return await manager.execute_workflow(
        'person_investigation',
        depth.value,
        {
            'first_name': first_name,
            'last_name': last_name,
            'city': city,
            'state': state
        },
        **kwargs
    )


async def business_due_diligence_workflow(
    company_name: str,
    city: Optional[str] = None,
    state: Optional[str] = None,
    depth: InvestigationDepth = InvestigationDepth.BASIC,
    orchestrator: Optional[SleuthIntelOrchestrator] = None,
    **kwargs
) -> Dict[str, Any]:
    """Execute business due diligence workflow"""
    if not orchestrator:
        orchestrator = SleuthIntelOrchestrator()
    
    manager = WorkflowTemplateManager(orchestrator)
    return await manager.execute_workflow(
        'business_due_diligence',
        depth.value,
        {
            'company_name': company_name,
            'city': city,
            'state': state
        },
        **kwargs
    )


async def address_analysis_workflow(
    street_address: str,
    city: str,
    state: str,
    zip_code: Optional[str] = None,
    depth: InvestigationDepth = InvestigationDepth.BASIC,
    orchestrator: Optional[SleuthIntelOrchestrator] = None,
    **kwargs
) -> Dict[str, Any]:
    """Execute address analysis workflow"""
    if not orchestrator:
        orchestrator = SleuthIntelOrchestrator()
    
    manager = WorkflowTemplateManager(orchestrator)
    return await manager.execute_workflow(
        'address_analysis',
        depth.value,
        {
            'street_address': street_address,
            'city': city,
            'state': state,
            'zip_code': zip_code
        },
        **kwargs
    )


async def bulk_processing_workflow(
    records: List[Dict[str, Any]],
    depth: InvestigationDepth = InvestigationDepth.BASIC,
    orchestrator: Optional[SleuthIntelOrchestrator] = None,
    **kwargs
) -> Dict[str, Any]:
    """Execute bulk processing workflow"""
    if not orchestrator:
        orchestrator = SleuthIntelOrchestrator()
    
    manager = WorkflowTemplateManager(orchestrator)
    return await manager.execute_workflow(
        'bulk_processing',
        depth.value,
        records,
        **kwargs
    )