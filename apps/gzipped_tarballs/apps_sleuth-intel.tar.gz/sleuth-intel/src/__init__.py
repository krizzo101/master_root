"""
Sleuth Intel Core Module
"""
