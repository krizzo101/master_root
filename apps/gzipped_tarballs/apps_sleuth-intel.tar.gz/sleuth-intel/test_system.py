#!/usr/bin/env python3
"""
Test script for Sleuth Intel secure API system
"""

import sys
from pathlib import Path

# Add the project to Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.core.secure_api_locker import api_locker_manager
from src.providers.enformion_client import EnformionClient, lookup_phone


def test_api_locker():
    """Test the secure API locker system"""
    print("🔒 Testing Secure API Locker")
    print("-" * 40)
    
    # Get locker status
    status = api_locker_manager.get_locker_status()
    print(f"Providers: {status['providers']}")
    print(f"Total credentials: {status['total_credentials']}")
    
    # Test credential retrieval
    enformion_cred = api_locker_manager.get_credential("enformion")
    if enformion_cred:
        print(f"✅ EnformionGO credential loaded")
        print(f"   Provider: {enformion_cred.provider}")
        print(f"   Key Name: {enformion_cred.key_name}")
        print(f"   Base URL: {enformion_cred.base_url}")
        print(f"   Rate Limit: {enformion_cred.rate_limit}")
        print(f"   Key Preview: {enformion_cred.key_value[:8]}...")
        if enformion_cred.password:
            print(f"   Password Preview: {enformion_cred.password[:8]}...")
    else:
        print("❌ No EnformionGO credential found")
    
    print()


def test_enformion_client():
    """Test the EnformionGO client"""
    print("🌐 Testing EnformionGO Client")
    print("-" * 40)
    
    try:
        client = EnformionClient()
        print("✅ EnformionGO client initialized")
        
        # Test the client is properly configured
        if hasattr(client, '_credential') and client._credential:
            print("✅ Credentials loaded successfully")
            print(f"   Using key: {client._credential.key_name}")
        else:
            print("❌ No credentials loaded")
            return
        
        # Note: We won't make actual API calls in this test to avoid using credits
        print("ℹ️  Client ready for API calls")
        print("   Available methods:")
        print("   • reverse_phone_search()")
        print("   • caller_id_lookup()")
        print("   • person_search()")
        print("   • business_search()")
        print("   • identity_verification()")
        print("   • contact_enrichment()")
        
    except Exception as e:
        print(f"❌ EnformionGO client failed: {e}")
    
    print()


def test_phone_lookup_demo():
    """Demo phone lookup functionality (without making actual API call)"""
    print("📞 Phone Lookup Demo")
    print("-" * 40)
    
    test_number = "(910) 392-5349"
    print(f"Demo lookup for: {test_number}")
    print("ℹ️  This would call EnformionGO API with your secure credentials")
    print("ℹ️  Actual API call commented out to preserve credits")
    
    # Uncomment to make real API call:
    # try:
    #     result = lookup_phone(test_number)
    #     print(f"Result: {result}")
    # except Exception as e:
    #     print(f"API call failed: {e}")
    
    print()


def main():
    """Main test function"""
    print("🕵️  Sleuth Intel System Test")
    print("=" * 50)
    
    # Test API locker
    test_api_locker()
    
    # Test EnformionGO client
    test_enformion_client()
    
    # Demo phone lookup
    test_phone_lookup_demo()
    
    print("=" * 50)
    print("✅ System test complete!")
    print()
    print("🚀 Ready to use:")
    print("1. Run setup_api_keys.py to store your credentials securely")
    print("2. Use EnformionClient for API calls")
    print("3. All credentials are encrypted and rotation-ready")


if __name__ == "__main__":
    main()