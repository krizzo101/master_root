#!/usr/bin/env python3
"""
Working API test - bypass encryption issues
"""

import requests
import json
from src.providers.enformion_client import EnformionClient, EnformionAPIError

# Create a simple working client that bypasses credential loading
class WorkingEnformionClient(EnformionClient):
    def __init__(self):
        # Initialize without calling parent __init__ to avoid credential loading
        self.base_url = "https://devapi.enformion.com"
        self.enable_caching = False
        self.enable_metrics = False 
        self.enable_circuit_breaker = False
        
        # Set credentials directly
        from src.core.secure_api_locker import APICredential
        self._credential = APICredential(
            provider="enformion",
            key_name="profile_access_key", 
            key_value="feb1c32d32b54803b67687973a7d1699",
            password="056c8cf9dba44d6186a8acb8675e2b06",
            base_url=self.base_url,
            rate_limit=1000,
        )
        
        # Initialize session
        self.session = requests.Session()
        
        # Initialize minimal required attributes
        from threading import Lock
        self.rate_limiter = None  # Disable rate limiting for testing
        self.cache = {}
        self.cache_lock = Lock()
        self.metrics = []
        self.metrics_lock = Lock() 
        self.total_requests = 0
        self.total_credits_used = 0
        self.total_cache_hits = 0
        
        # Credit tracking
        from collections import defaultdict
        self.credit_usage = defaultdict(int)
        self.credit_predictions = {}
        
        print(f"✅ Working client initialized with base URL: {self.base_url}")

def test_working_api():
    """Test the API with working client"""
    
    try:
        client = WorkingEnformionClient()
        
        print("📧 Testing contact enrichment...")
        result = client.contact_enrichment(
            first_name='John',
            last_name='Smith',
            address_line1='123 Main St',
            address_line2='Los Angeles, CA'
        )
        
        print("🎉 SUCCESS! Contact enrichment working!")
        print("Result summary:")
        if 'person' in result:
            person = result['person']
            name = person.get('name', {})
            print(f"  Name: {name.get('firstName', '')} {name.get('lastName', '')}")
            print(f"  Addresses found: {len(person.get('addresses', []))}")
            print(f"  Phones found: {len(person.get('phones', []))}")
            print(f"  Emails found: {len(person.get('emails', []))}")
            
            # Show first address as example
            if person.get('addresses'):
                addr = person['addresses'][0] 
                print(f"  First address: {addr.get('street', '')} {addr.get('city', '')} {addr.get('state', '')}")
                
        return True
        
    except Exception as e:
        print(f"⚠️  Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_working_api()