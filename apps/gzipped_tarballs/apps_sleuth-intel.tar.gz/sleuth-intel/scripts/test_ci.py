#!/usr/bin/env python3
"""CI/CD test orchestration script."""

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yaml


class TestRunner:
    """Orchestrate test execution for CI/CD."""
    
    def __init__(self, config_file: Optional[str] = None):
        """Initialize the test runner."""
        self.config = self.load_config(config_file)
        self.results = {}
        self.start_time = None
        self.end_time = None
    
    def load_config(self, config_file: Optional[str]) -> Dict:
        """Load test configuration."""
        if config_file and Path(config_file).exists():
            with open(config_file, 'r') as f:
                return yaml.safe_load(f)
        
        # Default configuration
        return {
            "test_suites": {
                "unit": {
                    "path": "tests/unit",
                    "markers": "not integration and not e2e and not performance",
                    "parallel": True,
                    "required": True
                },
                "integration": {
                    "path": "tests/integration",
                    "markers": "integration",
                    "parallel": False,
                    "required": True
                },
                "e2e": {
                    "path": "tests/e2e",
                    "markers": "e2e",
                    "parallel": False,
                    "required": False
                },
                "performance": {
                    "path": "tests/performance",
                    "markers": "performance",
                    "parallel": False,
                    "required": False
                }
            },
            "coverage": {
                "enabled": True,
                "min_coverage": 80,
                "fail_under": 70
            },
            "quality_checks": {
                "black": True,
                "isort": True,
                "flake8": True,
                "mypy": True,
                "bandit": True
            },
            "reports": {
                "junit": True,
                "coverage_xml": True,
                "coverage_html": True
            }
        }
    
    def run_command(self, cmd: List[str], capture_output: bool = True) -> Tuple[int, str, str]:
        """Run a shell command."""
        print(f"Running: {' '.join(cmd)}")
        
        if capture_output:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True
            )
            return result.returncode, result.stdout, result.stderr
        else:
            result = subprocess.run(cmd)
            return result.returncode, "", ""
    
    def run_quality_checks(self) -> bool:
        """Run code quality checks."""
        print("\n" + "="*50)
        print("Running Code Quality Checks")
        print("="*50)
        
        all_passed = True
        checks = self.config.get("quality_checks", {})
        
        # Black
        if checks.get("black", True):
            print("\n[Black] Checking code formatting...")
            returncode, _, _ = self.run_command(["black", "--check", "src", "tests"])
            if returncode != 0:
                print("❌ Black formatting check failed")
                all_passed = False
            else:
                print("✅ Black formatting check passed")
        
        # isort
        if checks.get("isort", True):
            print("\n[isort] Checking import sorting...")
            returncode, _, _ = self.run_command(["isort", "--check-only", "src", "tests"])
            if returncode != 0:
                print("❌ Import sorting check failed")
                all_passed = False
            else:
                print("✅ Import sorting check passed")
        
        # Flake8
        if checks.get("flake8", True):
            print("\n[Flake8] Running linter...")
            returncode, _, _ = self.run_command(["flake8", "src", "tests"])
            if returncode != 0:
                print("❌ Flake8 linting failed")
                all_passed = False
            else:
                print("✅ Flake8 linting passed")
        
        # MyPy
        if checks.get("mypy", True):
            print("\n[MyPy] Checking types...")
            returncode, _, _ = self.run_command(["mypy", "src"])
            if returncode != 0:
                print("❌ Type checking failed")
                all_passed = False
            else:
                print("✅ Type checking passed")
        
        # Bandit
        if checks.get("bandit", False):
            print("\n[Bandit] Security scan...")
            returncode, _, _ = self.run_command(
                ["bandit", "-r", "src", "-f", "json", "-o", "test-results/bandit.json"]
            )
            if returncode != 0:
                print("⚠️ Security issues found")
            else:
                print("✅ Security scan passed")
        
        return all_passed
    
    def run_test_suite(self, suite_name: str, suite_config: Dict) -> bool:
        """Run a specific test suite."""
        print(f"\n[{suite_name.upper()}] Running tests...")
        
        cmd = ["pytest", suite_config["path"], "-v"]
        
        # Add parallel execution
        if suite_config.get("parallel", False):
            cmd.extend(["-n", "auto"])
        
        # Add markers
        if "markers" in suite_config:
            cmd.extend(["-m", suite_config["markers"]])
        
        # Add coverage
        if self.config["coverage"]["enabled"]:
            cmd.extend([
                "--cov=src",
                "--cov-branch",
                "--cov-append"
            ])
        
        # Add reports
        if self.config["reports"]["junit"]:
            cmd.extend([
                "--junit-xml",
                f"test-results/{suite_name}-junit.xml"
            ])
        
        returncode, stdout, stderr = self.run_command(cmd, capture_output=False)
        
        self.results[suite_name] = {
            "passed": returncode == 0,
            "required": suite_config.get("required", True),
            "returncode": returncode
        }
        
        if returncode == 0:
            print(f"✅ {suite_name} tests passed")
        else:
            print(f"❌ {suite_name} tests failed")
        
        return returncode == 0
    
    def run_all_tests(self) -> bool:
        """Run all test suites."""
        print("\n" + "="*50)
        print("Running Test Suites")
        print("="*50)
        
        # Clear coverage data
        if self.config["coverage"]["enabled"]:
            subprocess.run(["coverage", "erase"])
        
        all_passed = True
        
        for suite_name, suite_config in self.config["test_suites"].items():
            passed = self.run_test_suite(suite_name, suite_config)
            
            if not passed and suite_config.get("required", True):
                all_passed = False
        
        return all_passed
    
    def generate_coverage_report(self) -> bool:
        """Generate coverage reports."""
        if not self.config["coverage"]["enabled"]:
            return True
        
        print("\n" + "="*50)
        print("Generating Coverage Reports")
        print("="*50)
        
        # Generate terminal report
        print("\n[Coverage] Terminal report:")
        subprocess.run(["coverage", "report", "--skip-empty"])
        
        # Generate XML report
        if self.config["reports"]["coverage_xml"]:
            subprocess.run(["coverage", "xml", "-o", "test-results/coverage.xml"])
            print("✅ XML coverage report generated")
        
        # Generate HTML report
        if self.config["reports"]["coverage_html"]:
            subprocess.run(["coverage", "html", "-d", "test-results/htmlcov"])
            print("✅ HTML coverage report generated")
        
        # Check coverage threshold
        returncode, stdout, _ = self.run_command(
            ["coverage", "report", "--skip-empty", "--format=total"],
            capture_output=True
        )
        
        try:
            # Parse total coverage from output
            for line in stdout.split('\n'):
                if 'TOTAL' in line:
                    parts = line.split()
                    coverage_percent = float(parts[-1].rstrip('%'))
                    
                    print(f"\nTotal coverage: {coverage_percent}%")
                    
                    if coverage_percent < self.config["coverage"]["fail_under"]:
                        print(f"❌ Coverage below threshold ({self.config['coverage']['fail_under']}%)")
                        return False
                    elif coverage_percent < self.config["coverage"]["min_coverage"]:
                        print(f"⚠️ Coverage below target ({self.config['coverage']['min_coverage']}%)")
                    else:
                        print(f"✅ Coverage meets target")
                    
                    break
        except Exception as e:
            print(f"⚠️ Could not parse coverage: {e}")
        
        return True
    
    def generate_summary(self) -> None:
        """Generate test execution summary."""
        print("\n" + "="*50)
        print("TEST EXECUTION SUMMARY")
        print("="*50)
        
        duration = self.end_time - self.start_time if self.end_time and self.start_time else 0
        
        print(f"\nExecution time: {duration:.2f} seconds")
        print("\nTest Suite Results:")
        
        for suite_name, result in self.results.items():
            status = "✅ PASSED" if result["passed"] else "❌ FAILED"
            required = " (Required)" if result["required"] else " (Optional)"
            print(f"  {suite_name}: {status}{required}")
        
        # Overall status
        required_passed = all(
            result["passed"] for result in self.results.values()
            if result["required"]
        )
        
        print("\n" + "-"*50)
        if required_passed:
            print("✅ All required tests passed!")
        else:
            print("❌ Some required tests failed!")
        
        # Generate JSON report
        report = {
            "timestamp": datetime.now().isoformat(),
            "duration": duration,
            "results": self.results,
            "overall_status": "passed" if required_passed else "failed"
        }
        
        with open("test-results/summary.json", "w") as f:
            json.dump(report, f, indent=2)
        
        print("\nDetailed reports available in test-results/")
    
    def run(self) -> int:
        """Run the complete test pipeline."""
        self.start_time = time.time()
        
        # Create test results directory
        Path("test-results").mkdir(exist_ok=True)
        
        print("🚀 Starting CI/CD Test Pipeline")
        print(f"Configuration: {json.dumps(self.config, indent=2)}")
        
        # Run quality checks
        quality_passed = self.run_quality_checks()
        
        # Run tests
        tests_passed = self.run_all_tests()
        
        # Generate coverage report
        coverage_passed = self.generate_coverage_report()
        
        self.end_time = time.time()
        
        # Generate summary
        self.generate_summary()
        
        # Determine exit code
        if quality_passed and tests_passed and coverage_passed:
            print("\n🎉 All checks passed!")
            return 0
        else:
            print("\n❌ Some checks failed!")
            return 1


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="CI/CD Test Runner")
    parser.add_argument(
        "--config",
        help="Path to test configuration file",
        default=None
    )
    parser.add_argument(
        "--suite",
        help="Run specific test suite",
        choices=["unit", "integration", "e2e", "performance"],
        default=None
    )
    parser.add_argument(
        "--skip-quality",
        action="store_true",
        help="Skip quality checks"
    )
    parser.add_argument(
        "--no-coverage",
        action="store_true",
        help="Disable coverage reporting"
    )
    
    args = parser.parse_args()
    
    runner = TestRunner(args.config)
    
    # Override configuration based on arguments
    if args.skip_quality:
        runner.config["quality_checks"] = {}
    
    if args.no_coverage:
        runner.config["coverage"]["enabled"] = False
    
    if args.suite:
        # Run only specific suite
        runner.config["test_suites"] = {
            args.suite: runner.config["test_suites"][args.suite]
        }
    
    sys.exit(runner.run())


if __name__ == "__main__":
    main()