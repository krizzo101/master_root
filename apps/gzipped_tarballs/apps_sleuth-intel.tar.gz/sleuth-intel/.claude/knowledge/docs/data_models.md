# Sleuth Intel Data Models Documentation

## Overview

The Sleuth Intel data models provide comprehensive, validated data structures for all intelligence data types. Built with Pydantic for validation and serialization, these models ensure data integrity and provide a consistent API for working with intelligence data.

## Architecture

The models are organized into four main modules:

- **person.py** - Person profiles, contacts, and demographics
- **business.py** - Business profiles, registrations, and corporate data  
- **intelligence.py** - Intelligence results with confidence scoring and correlation
- **query.py** - Query parameter classes with validation and optimization

## Person Models (`src/models/person.py`)

### Core Classes

#### `PersonProfile`
Complete person profile from intelligence gathering.

```python
from src.models import PersonProfile, PersonName, Phone, Address, Email

# Create a person profile
profile = PersonProfile(
    name=PersonName(first="John", last="Doe"),
    source_provider="enformion",
    confidence_score=0.85
)

# Add contact information
profile.add_phone("555-123-4567")
profile.add_email("john.doe@example.com")
profile.add_address({
    "street": "123 Main St",
    "city": "Anytown", 
    "state": "NY",
    "zip_code": "12345"
})

# Access current information
current_phone = profile.current_phone
current_address = profile.current_address
primary_email = profile.primary_email
```

#### `PersonName`
Person name with variations and aliases.

```python
name = PersonName(
    first="John",
    middle="Michael", 
    last="Smith",
    suffix="Jr",
    aliases=["Johnny Smith", "J.M. Smith"]
)

print(name.display_name)  # "John Michael Smith Jr"
print(name.full)         # Auto-generated full name
```

#### `Phone`
Phone number with metadata and carrier information.

```python
phone = Phone(
    number="5551234567",
    type=PhoneType.MOBILE,
    carrier="Verizon",
    confidence_score=0.9,
    is_current=True
)

print(phone.formatted)  # "(555) 123-4567"
```

#### `Address`
Address with geocoding and validation.

```python
address = Address(
    street="123 Main St",
    city="New York",
    state="NY",
    zip_code="10001",
    type=AddressType.CURRENT,
    latitude=40.7589,
    longitude=-73.9851
)

print(address.full_address)  # "123 Main St, New York, NY 10001"
```

#### `Email`
Email with domain extraction and verification status.

```python
email = Email(
    address="user@example.com",
    is_verified=True,
    confidence_score=0.8
)

print(email.domain)  # "example.com"
```

### Supporting Classes

- **`Demographics`** - Age, gender, occupation, education
- **`Associate`** - Related persons (relatives, associates)

## Business Models (`src/models/business.py`)

### Core Classes

#### `BusinessProfile`
Complete business profile with all corporate data.

```python
from src.models import BusinessProfile, BusinessLocation, Principal

# Create business profile
business = BusinessProfile(
    business_name="Acme Corporation",
    entity_type=EntityType.CORPORATION,
    source_provider="enformion"
)

# Add location
business.add_location({
    "address": {
        "street": "456 Business Ave",
        "city": "Corporate City",
        "state": "CA", 
        "zip_code": "90210"
    },
    "location_type": "headquarters",
    "is_headquarters": True
})

# Add principal
business.add_principal({
    "name": {"first": "Jane", "last": "CEO"},
    "title": "Chief Executive Officer",
    "ownership_percentage": 51.0
})
```

#### `Registration`
Business registration and legal entity information.

```python
registration = Registration(
    entity_id="C1234567",
    federal_ein="12-3456789",
    registration_date=datetime(2020, 1, 15),
    registered_state="DE",
    status=BusinessStatus.ACTIVE
)
```

#### `Principal`
Business officers, owners, and key personnel.

```python
principal = Principal(
    name=PersonName(first="John", last="Smith"),
    title="Chief Technology Officer",
    ownership_percentage=25.0,
    start_date=datetime(2021, 3, 1),
    is_current=True
)
```

### Supporting Classes

- **`IndustryClassification`** - NAICS/SIC codes and descriptions
- **`Filing`** - Legal filings and court records
- **`License`** - Business licenses and permits
- **`FinancialData`** - Revenue, employees, credit rating
- **`BusinessLocation`** - Physical locations with operational details

## Intelligence Models (`src/models/intelligence.py`)

### Core Classes

#### `IntelligenceResult[T]`
Generic wrapper for intelligence results with confidence scoring.

```python
from src.models import PersonIntelligenceResult, ConfidenceScoring, DataSource

# Create intelligence result
result = PersonIntelligenceResult(
    data=person_profile,
    confidence=ConfidenceScoring(
        overall_score=0.85,
        data_quality=0.9,
        source_reliability=0.8
    ),
    sources=[
        DataSource(
            provider="enformion",
            query_method="person_search",
            query_params={"name": "John Doe"},
            completeness=0.75
        )
    ],
    primary_source="enformion",
    query_metadata=query_meta
)

# Check result quality
if result.is_reliable:
    print(f"High confidence result: {result.confidence.level}")
    person = result.person
```

#### `ConfidenceScoring`
Detailed confidence breakdown with component scores.

```python
confidence = ConfidenceScoring(
    overall_score=0.78,
    data_quality=0.85,
    data_recency=0.70,
    source_reliability=0.80,
    cross_validation=0.75,
    completeness=0.82,
    warnings=["Limited recent activity", "Single source verification"]
)

print(confidence.level)  # ConfidenceLevel.HIGH
```

#### `DataSource`
Source attribution with performance metrics.

```python
source = DataSource(
    provider="enformion",
    dataset="consumer_records",
    query_method="reverse_phone",
    query_params={"phone": "5551234567"},
    response_time=1.25,
    completeness=0.88,
    reliability=0.92
)
```

### Specialized Result Types

- **`PersonIntelligenceResult`** - Person-specific intelligence
- **`BusinessIntelligenceResult`** - Business-specific intelligence  
- **`ComprehensiveIntelligenceResult`** - Combined person and business data

### Supporting Classes

- **`DataCorrelation`** - Cross-reference analysis
- **`ValidationResult`** - Data validation results
- **`QueryMetadata`** - Query execution information

## Query Models (`src/models/query.py`)

### Core Classes

#### `PersonSearchQuery`
Person search parameters with validation.

```python
from src.models import PersonSearchQuery, DataProvider, QueryPriority

query = PersonSearchQuery(
    first_name="John",
    last_name="Smith",
    city="New York",
    state="NY",
    phone="5551234567",
    providers=[DataProvider.ENFORMION, DataProvider.WHITEPAGES],
    priority=QueryPriority.HIGH,
    min_confidence=0.7,
    fuzzy_matching=True,
    include_relatives=True
)

# Validate query
if query.has_sufficient_params():
    print("Query has sufficient parameters")

# Optimize query
optimized = QueryOptimizer.optimize_person_query(query)
```

#### `BusinessSearchQuery`
Business search with corporate identifiers.

```python
business_query = BusinessSearchQuery(
    business_name="Acme Corp",
    city="San Francisco",
    state="CA",
    ein="12-3456789",
    include_principals=True,
    include_filings=True,
    max_results=5
)
```

#### `PhoneLookupQuery`
Phone number reverse lookup.

```python
phone_query = PhoneLookupQuery(
    phone_number="5551234567",
    include_caller_id=True,
    include_owner_details=True,
    include_carrier=True,
    timeout=15
)
```

### Query Types

- **`BaseQuery`** - Base parameters for all queries
- **`EmailLookupQuery`** - Email reverse lookup
- **`AddressLookupQuery`** - Address resident lookup
- **`IdentityVerificationQuery`** - Identity verification
- **`ComprehensiveSearchQuery`** - Multi-type search

### Query Optimization

#### `QueryOptimizer`
Helper class for query optimization and cost estimation.

```python
from src.models import QueryOptimizer

# Optimize query
optimized_query = QueryOptimizer.optimize_person_query(original_query)

# Estimate cost
cost_estimate = QueryOptimizer.estimate_query_cost(query)
print(f"Estimated cost: ${cost_estimate['estimated_cost']:.2f}")
print(f"Estimated time: {cost_estimate['estimated_time']:.1f}s")
```

## Validation and Error Handling

All models use Pydantic validators for data validation:

```python
from pydantic import ValidationError

try:
    phone = Phone(number="invalid")
except ValidationError as e:
    print(e.errors())
    # [{'loc': ('number',), 'msg': 'Phone number must have at least 10 digits', 'type': 'value_error'}]
```

## Usage Examples

### Complete Person Intelligence Workflow

```python
from datetime import datetime
from src.models import (
    PersonSearchQuery, PersonIntelligenceResult,
    PersonProfile, PersonName, ConfidenceScoring,
    DataSource, QueryMetadata
)

# 1. Create query
query = PersonSearchQuery(
    first_name="John",
    last_name="Doe",
    phone="5551234567",
    providers=["enformion"],
    min_confidence=0.7
)

# 2. Execute search (hypothetical)
person_data = execute_person_search(query)  # Your search logic

# 3. Create person profile
profile = PersonProfile(
    name=PersonName(first="John", last="Doe"),
    source_provider="enformion",
    confidence_score=0.85
)

# Add data to profile
profile.add_phone("5551234567")
profile.add_address({
    "street": "123 Main St",
    "city": "Anytown",
    "state": "NY",
    "zip_code": "12345"
})

# 4. Create intelligence result
result = PersonIntelligenceResult(
    data=profile,
    confidence=ConfidenceScoring(
        overall_score=0.85,
        data_quality=0.9,
        source_reliability=0.8,
        completeness=0.7
    ),
    sources=[
        DataSource(
            provider="enformion",
            query_method="person_search",
            query_params=query.dict(),
            response_time=1.5
        )
    ],
    primary_source="enformion",
    query_metadata=QueryMetadata(
        query_id="q123",
        query_type="person_search",
        original_query=query.dict(),
        execution_time=1.5,
        sources_queried=1,
        sources_successful=1
    )
)

# 5. Use result
if result.is_reliable:
    person = result.person
    print(f"Found: {person.name.display_name}")
    print(f"Phone: {person.current_phone.formatted}")
    print(f"Confidence: {result.confidence.level}")
```

### Business Intelligence Example

```python
from src.models import BusinessSearchQuery, BusinessProfile, Registration

# Search for business
query = BusinessSearchQuery(
    business_name="Acme Corporation",
    state="CA",
    include_principals=True
)

# Create business profile
business = BusinessProfile(
    business_name="Acme Corporation",
    entity_type=EntityType.CORPORATION,
    registration=Registration(
        entity_id="C1234567",
        federal_ein="12-3456789",
        status=BusinessStatus.ACTIVE
    ),
    source_provider="enformion"
)

# Add business location
business.add_location({
    "address": {
        "street": "456 Business Ave",
        "city": "San Francisco",
        "state": "CA",
        "zip_code": "94105"
    },
    "is_headquarters": True
})

print(f"Business: {business.business_name}")
print(f"Status: {business.is_active}")
print(f"Location: {business.primary_location.address.full_address}")
```

## Integration with Existing Code

The models integrate seamlessly with the existing Sleuth Intel architecture:

```python
# In your agents
from src.models import PersonSearchQuery, PersonIntelligenceResult

class PersonAgent:
    async def search(self, query_params: dict) -> PersonIntelligenceResult:
        # Validate and create query
        query = PersonSearchQuery(**query_params)
        
        # Execute search using existing providers
        raw_data = await self.enformion_client.person_search(
            first_name=query.first_name,
            last_name=query.last_name,
            # ... other params
        )
        
        # Create structured result
        profile = self._parse_person_data(raw_data)
        result = PersonIntelligenceResult(
            data=profile,
            # ... confidence and source info
        )
        
        return result
```

## Benefits

1. **Type Safety** - Full type checking with mypy
2. **Validation** - Automatic data validation and cleaning
3. **Consistency** - Standardized data structures across agents
4. **Documentation** - Self-documenting code with field descriptions
5. **Serialization** - Easy JSON serialization for APIs and storage
6. **Extensibility** - Easy to add new fields and validation rules

## Next Steps

1. Update existing agents to use these models
2. Add model serialization for API responses
3. Implement model-based caching
4. Add more sophisticated validation rules
5. Create model factories for different data sources