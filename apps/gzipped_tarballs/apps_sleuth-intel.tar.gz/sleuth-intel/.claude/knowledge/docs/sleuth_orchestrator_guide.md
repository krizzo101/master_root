# SleuthIntelOrchestrator - Workflow Patterns and Usage Guide

## Overview

The SleuthIntelOrchestrator is an advanced intelligence workflow management system that coordinates multiple intelligence agents with sophisticated patterns, load balancing, rate limiting, and result correlation. It extends beyond basic orchestration to provide intelligent workflow execution optimized for intelligence gathering operations.

## Key Features

- **Multi-Agent Coordination**: Manages pools of specialized intelligence agents
- **Advanced Workflow Patterns**: Five distinct execution patterns for different use cases
- **Rate Limiting & Cost Optimization**: Global rate limiting with credit usage tracking
- **Dynamic Agent Selection**: Intelligent agent selection based on performance and costs
- **Result Correlation**: Automatic correlation and pattern detection in results
- **Comprehensive Caching**: Multi-level caching with TTL management
- **Chat Monitor Integration**: Real-time monitoring and tracking of orchestrator runs

## Workflow Patterns

### 1. Single Source Workflow (`SINGLE_SOURCE`)

**Use Case**: Direct, single-agent queries where you need the best available agent for each query.

**Characteristics**:
- One agent per query
- Optimal agent selection based on performance metrics
- Fastest execution for simple queries
- Lowest cost option

**Example**:
```python
from src.orchestration.sleuth_orchestrator import SleuthIntelOrchestrator, WorkflowType
from src.models.query import IntelligenceQuery

orchestrator = SleuthIntelOrchestrator()

# Register agent pools
orchestrator.register_agent_pool(
    agent_type="person_search",
    agent_class=PersonSearchAgent,
    providers=["enformion", "spokeo", "whitepages"]
)

queries = [
    IntelligenceQuery(
        query_type="person",
        parameters={"full_name": "John Smith", "city": "New York"}
    )
]

execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.SINGLE_SOURCE,
    queries=queries
)
```

### 2. Multi-Source Parallel Workflow (`MULTI_SOURCE_PARALLEL`)

**Use Case**: Execute the same query across multiple providers simultaneously to get comprehensive results and cross-validation.

**Characteristics**:
- Multiple agents per query from different providers
- Parallel execution for speed
- Cross-provider validation
- Higher confidence in results

**Example**:
```python
queries = [
    IntelligenceQuery(
        query_type="person",
        parameters={"email": "john.smith@company.com"}
    )
]

# This will execute the query across multiple providers simultaneously
execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.MULTI_SOURCE_PARALLEL,
    queries=queries
)

# Results will contain data from multiple providers
for result in execution.results:
    print(f"Provider: {result.provider}, Success: {result.success}")
```

### 3. Investigation Chain Workflow (`INVESTIGATION_CHAIN`)

**Use Case**: Sequential queries where each result informs the next query, building an investigation chain.

**Characteristics**:
- Sequential execution with context propagation
- Results from previous queries enrich subsequent queries
- Automatic follow-up query generation
- Comprehensive investigation workflow

**Example**:
```python
# Start with a person search, which may lead to business searches,
# which may lead to additional person searches of executives, etc.
queries = [
    IntelligenceQuery(
        query_type="person",
        parameters={"full_name": "Jane Doe", "state": "CA"}
    ),
    IntelligenceQuery(
        query_type="business",
        parameters={"business_name": "TechCorp Inc"}  # Will be enriched with context
    )
]

execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.INVESTIGATION_CHAIN,
    queries=queries
)

# The orchestrator will automatically generate additional queries based on results
print(f"Started with {len(queries)} queries, executed {len(execution.results)} total")
```

### 4. Bulk Processing Workflow (`BULK_PROCESSING`)

**Use Case**: Process large batches of queries efficiently with intelligent batching and throttling.

**Characteristics**:
- Batch processing with configurable batch sizes
- Semaphore-based concurrency control
- Automatic rate limiting between batches
- Optimized for large-scale operations

**Example**:
```python
# Process hundreds of queries efficiently
queries = []
for name in large_name_list:  # Could be 100s or 1000s of names
    queries.append(IntelligenceQuery(
        query_type="person",
        parameters={"full_name": name}
    ))

config = WorkflowConfig(
    max_parallel_agents=10,  # Control concurrency
    enable_caching=True,     # Reduce duplicate queries
    cost_optimization=True   # Optimize provider usage
)

orchestrator = SleuthIntelOrchestrator(config=config)
execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.BULK_PROCESSING,
    queries=queries
)

print(f"Processed {len(queries)} queries with {execution.metrics['success_rate']:.1f}% success rate")
```

### 5. Adaptive Enrichment Workflow (`ADAPTIVE_ENRICHMENT`)

**Use Case**: Start with basic queries, then adaptively expand based on what's found in the initial results.

**Characteristics**:
- Two-pass execution: initial queries + adaptive enrichment
- Automatic enrichment query generation
- Smart expansion based on data discovery
- Balances thoroughness with efficiency

**Example**:
```python
# Start with basic person queries
initial_queries = [
    IntelligenceQuery(
        query_type="person",
        parameters={"full_name": "Bob Johnson", "age": 45}
    )
]

execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.ADAPTIVE_ENRICHMENT,
    queries=initial_queries
)

# If initial person search finds email/phone, orchestrator automatically
# searches those as well for additional data
print(f"Initial queries: {len(initial_queries)}")
print(f"Total queries executed: {len(execution.results)}")
print(f"Enrichment queries: {len(execution.results) - len(initial_queries)}")
```

## Agent Pool Management

### Registering Agent Pools

```python
orchestrator = SleuthIntelOrchestrator()

# Register different agent types
orchestrator.register_agent_pool(
    agent_type="person_search",
    agent_class=PersonSearchAgent,
    max_instances=5,
    providers=["enformion", "spokeo", "whitepages", "truthfinder"]
)

orchestrator.register_agent_pool(
    agent_type="business_search",
    agent_class=BusinessSearchAgent,
    max_instances=3,
    providers=["enformion", "duns_bradstreet"]
)

orchestrator.register_agent_pool(
    agent_type="email_search",
    agent_class=EmailSearchAgent,
    max_instances=2,
    providers=["hunter", "clearbit"]
)
```

### Agent Selection Logic

The orchestrator selects agents based on multiple factors:

1. **Performance Metrics**: Success rate, average response time, rate limit hits
2. **Cost Optimization**: Provider usage distribution, cost per request
3. **Provider Preferences**: Configured preferred providers get priority
4. **Availability**: Only idle agents are considered
5. **Credit Limits**: Respects daily usage limits per provider

## Configuration Options

```python
config = WorkflowConfig(
    max_parallel_agents=8,           # Maximum concurrent agents
    timeout_seconds=300,             # Query timeout
    enable_caching=True,             # Result caching
    cache_ttl=3600,                  # Cache TTL in seconds
    retry_failed_queries=True,       # Retry failed queries
    max_retries=3,                   # Maximum retry attempts
    correlation_threshold=0.8,       # Result correlation threshold
    cost_optimization=True,          # Enable cost optimization
    preferred_providers=["enformion"] # Preferred provider list
)

orchestrator = SleuthIntelOrchestrator(config=config)
```

## Result Correlation

The orchestrator automatically correlates results to find connections:

```python
execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.MULTI_SOURCE_PARALLEL,
    queries=multiple_queries
)

# Access correlation data
correlation_data = execution.metrics.get("correlation", {})
print(f"Found {len(correlation_data['connections'])} connections between results")

for connection in correlation_data["connections"]:
    print(f"Results {connection['result_indices']} overlap: {connection['overlap_score']:.2f}")
    print(f"Shared fields: {connection['shared_fields']}")
```

## Monitoring and Metrics

### Workflow Metrics

```python
# Get metrics for specific workflow
workflow_metrics = orchestrator.get_workflow_metrics(execution.workflow_id)
print(f"Execution time: {workflow_metrics['execution_time_seconds']:.2f}s")
print(f"Success rate: {workflow_metrics['successful_results']}/{workflow_metrics['total_queries']}")

# Get aggregate metrics across all workflows
aggregate_metrics = orchestrator.get_workflow_metrics()
print(f"Total executions: {aggregate_metrics['total_executions']}")
print(f"Average execution time: {aggregate_metrics['average_execution_time']:.2f}s")
print(f"Cache hit rate: {aggregate_metrics['cache_hit_rate']:.1f}%")
```

### Agent Status

```python
agent_status = orchestrator.get_agent_status_summary()
print(f"Total agents: {agent_status['total_agents']}")
print(f"Status distribution: {agent_status['status_distribution']}")

# Individual agent metrics
for agent_id, metrics in agent_status["individual_metrics"].items():
    print(f"{agent_id}: {metrics['success_rate']:.1f}% success, {metrics['total_requests']} requests")
```

## Error Handling and Recovery

The orchestrator provides comprehensive error handling:

1. **Agent Failures**: Automatically retries with different agents
2. **Rate Limiting**: Intelligent backoff and provider rotation
3. **Quota Exhaustion**: Automatic provider switching
4. **Network Issues**: Configurable retry policies
5. **Partial Failures**: Continues execution with available agents

```python
execution = await orchestrator.execute_workflow(
    workflow_type=WorkflowType.INVESTIGATION_CHAIN,
    queries=queries
)

# Check for errors
if execution.errors:
    print(f"Workflow completed with {len(execution.errors)} errors:")
    for error in execution.errors:
        print(f"  - {error}")

# Individual result status
successful_results = [r for r in execution.results if r.success]
failed_results = [r for r in execution.results if not r.success]

print(f"Success: {len(successful_results)}, Failed: {len(failed_results)}")
```

## Performance Optimization

### Caching Strategy

```python
# Enable aggressive caching for bulk operations
config = WorkflowConfig(
    enable_caching=True,
    cache_ttl=7200,  # 2 hours
    cost_optimization=True
)

# Cache hit rates are automatically tracked
metrics = orchestrator.get_workflow_metrics()
cache_hit_rate = metrics['cache_hit_rate']
print(f"Cache efficiency: {cache_hit_rate:.1f}%")
```

### Cost Optimization

```python
# Set up credit usage tracking
orchestrator.credit_tracker.daily_limits = {
    "enformion": 1000,
    "spokeo": 500,
    "whitepages": 200
}

orchestrator.credit_tracker.cost_per_request = {
    "enformion": 0.50,
    "spokeo": 0.25,
    "whitepages": 0.10
}

# The orchestrator will automatically prefer lower-cost providers
# when performance is comparable
```

## Integration Examples

### Basic Intelligence Lookup

```python
async def basic_person_lookup(full_name: str, state: str = None) -> Dict:
    orchestrator = SleuthIntelOrchestrator()
    
    # Register required agents
    orchestrator.register_agent_pool("person_search", PersonSearchAgent, providers=["enformion"])
    
    query = IntelligenceQuery(
        query_type="person",
        parameters={"full_name": full_name, "state": state}
    )
    
    execution = await orchestrator.execute_workflow(
        WorkflowType.SINGLE_SOURCE,
        [query]
    )
    
    if execution.results and execution.results[0].success:
        return execution.results[0].data
    else:
        return {"error": "No results found"}
```

### Comprehensive Investigation

```python
async def comprehensive_investigation(target_name: str) -> Dict:
    config = WorkflowConfig(
        max_parallel_agents=6,
        correlation_threshold=0.7,
        cost_optimization=True
    )
    
    orchestrator = SleuthIntelOrchestrator(config=config)
    
    # Register multiple agent types
    orchestrator.register_agent_pool("person_search", PersonSearchAgent, providers=["enformion", "spokeo"])
    orchestrator.register_agent_pool("business_search", BusinessSearchAgent, providers=["enformion"])
    orchestrator.register_agent_pool("email_search", EmailSearchAgent, providers=["hunter"])
    
    initial_query = IntelligenceQuery(
        query_type="person",
        parameters={"full_name": target_name}
    )
    
    # Use investigation chain to build comprehensive profile
    execution = await orchestrator.execute_workflow(
        WorkflowType.INVESTIGATION_CHAIN,
        [initial_query]
    )
    
    return {
        "target": target_name,
        "total_queries": len(execution.results),
        "successful_queries": len([r for r in execution.results if r.success]),
        "execution_time": execution.metrics.get("execution_time_seconds", 0),
        "correlations": execution.metrics.get("correlation", {}),
        "results": [r.data for r in execution.results if r.success]
    }
```

## Best Practices

1. **Choose the Right Workflow**: Match workflow pattern to use case
2. **Configure Appropriately**: Set realistic limits and timeouts
3. **Monitor Performance**: Regularly check metrics and optimize
4. **Handle Failures Gracefully**: Always check execution status and individual results
5. **Use Caching Effectively**: Enable caching for repeated operations
6. **Optimize Costs**: Set up credit tracking and limits
7. **Register Sufficient Agents**: Provide multiple providers per agent type
8. **Clean Up Resources**: Call `orchestrator.shutdown()` when done

## Troubleshooting

### Common Issues

1. **No Available Agents**: Ensure agent pools are registered with valid credentials
2. **Rate Limiting**: Reduce `max_parallel_agents` or increase timeouts
3. **High Costs**: Enable `cost_optimization` and set `daily_limits`
4. **Slow Performance**: Check cache hit rates and optimize queries
5. **Correlation Issues**: Adjust `correlation_threshold` based on data quality

### Debug Mode

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# This will show detailed orchestrator operations
execution = await orchestrator.execute_workflow(workflow_type, queries)
```

The SleuthIntelOrchestrator provides a powerful, flexible foundation for intelligence gathering operations with sophisticated workflow management and optimization capabilities.