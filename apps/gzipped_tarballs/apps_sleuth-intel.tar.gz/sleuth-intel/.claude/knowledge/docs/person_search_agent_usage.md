# PersonSearchAgent Usage Guide

## Overview

The `PersonSearchAgent` is a comprehensive person search agent that leverages the EnformionGO API to find detailed information about individuals. It provides advanced features including fuzzy name matching, confidence scoring, intelligent caching, and comprehensive data validation.

## Features

- **Name-based search** with fuzzy matching support
- **Phone number lookup** to find associated persons
- **Address-based search** to find residents
- **Age range filtering** for demographic targeting
- **Location-based filtering** with proximity matching
- **Confidence scoring** for result reliability
- **Intelligent caching** to reduce API calls and costs
- **Duplicate detection** to consolidate similar results
- **Comprehensive data validation** and cleanup
- **Rate limiting** optimized for person searches

## Installation and Setup

### Prerequisites

1. Ensure you have EnformionGO API credentials configured in the secure API locker
2. Install required dependencies (see requirements.txt)
3. Configure rate limiting and caching parameters as needed

### Basic Initialization

```python
from src.agents.person_search_agent import PersonSearchAgent

# Basic initialization with default settings
agent = PersonSearchAgent()

# Custom configuration
agent = PersonSearchAgent(
    fuzzy_threshold=0.8,        # Name matching threshold (0.0-1.0)
    max_age_variance=5,         # Age tolerance in years
    location_radius_miles=50,   # Location proximity radius
    rate_limit_config=custom_rate_config,
    cache_config=custom_cache_config
)
```

## API Usage Patterns

### 1. Name-Based Search

#### Basic Name Search
```python
from src.models.query import PersonSearchQuery

# Simple name search
query = PersonSearchQuery(
    first_name="John",
    last_name="Doe"
)

results = agent.search(query)
for person in results:
    print(f"Found: {person.name.display_name}")
    print(f"Confidence: {person.confidence_score:.2f}")
```

#### Name Search with Location Filtering
```python
# Search with city and state
query = PersonSearchQuery(
    first_name="John",
    last_name="Doe",
    city="Los Angeles",
    state="CA"
)

results = agent.search(query)
```

#### Fuzzy Name Matching
```python
# Enable fuzzy matching for similar names
query = PersonSearchQuery(
    first_name="Jon",       # Will match "John"
    last_name="Smith",
    fuzzy_matching=True
)

results = agent.search(query)
```

### 2. Phone Number Search

#### Reverse Phone Lookup
```python
# Search by phone number
results = agent.search_by_phone("(555) 123-4567")

for person in results:
    print(f"Phone owner: {person.name.display_name}")
    if person.current_address:
        print(f"Address: {person.current_address.full_address}")
```

#### Using PersonSearchQuery for Phone Search
```python
query = PersonSearchQuery(
    phone="5551234567",
    max_results=5
)

results = agent.search(query)
```

### 3. Address-Based Search

#### Find Residents at Address
```python
# Search by full address
results = agent.search_by_address(
    street="123 Main Street",
    city="Anytown", 
    state="CA",
    zip_code="90210"
)

for person in results:
    print(f"Resident: {person.name.display_name}")
```

#### City and State Search
```python
# Broader location search
results = agent.search_by_address(
    city="Beverly Hills",
    state="CA",
    max_results=20
)
```

### 4. Age-Filtered Search

#### Search with Age Range
```python
# Find people within specific age range
results = agent.search_with_age_filter(
    first_name="John",
    last_name="Doe",
    age_min=30,
    age_max=45,
    city="San Francisco",
    state="CA"
)

for person in results:
    age = person.demographics.age if person.demographics else "Unknown"
    print(f"{person.name.display_name}, Age: {age}")
```

### 5. Comprehensive Search with Multiple Parameters

#### Multi-Parameter Search
```python
query = PersonSearchQuery(
    first_name="John",
    last_name="Doe",
    phone="5551234567",
    city="Los Angeles",
    state="CA",
    age_min=25,
    age_max=50,
    fuzzy_matching=True,
    include_relatives=True,
    include_associates=True,
    max_results=10,
    min_confidence=0.7
)

results = agent.search(query)

for person in results:
    print(f"Name: {person.name.display_name}")
    print(f"Confidence: {person.confidence_score:.2f}")
    
    if person.current_phone:
        print(f"Phone: {person.current_phone.formatted}")
    
    if person.primary_email:
        print(f"Email: {person.primary_email.address}")
    
    if person.current_address:
        print(f"Address: {person.current_address.full_address}")
    
    if person.associates:
        print("Associates:")
        for associate in person.associates:
            print(f"  - {associate.name.display_name} ({associate.relationship})")
```

## Advanced Usage

### 1. Caching and Performance

#### Using Cache Strategically
```python
# Use cache for repeated queries
results1 = agent.search(query, use_cache=True)

# Force refresh cache
results2 = agent.search(query, use_cache=False)

# Clear cache when needed
agent.clear_cache()
```

#### Custom Cache Configuration
```python
from src.agents.base_agent import CacheConfig

cache_config = CacheConfig(
    enabled=True,
    ttl_seconds=3600,  # 1 hour cache
    max_entries=1000,
    compress=True
)

agent = PersonSearchAgent(cache_config=cache_config)
```

### 2. Rate Limiting

#### Custom Rate Limiting
```python
from src.agents.base_agent import RateLimitConfig

rate_config = RateLimitConfig(
    requests_per_second=1.0,
    requests_per_minute=30,
    requests_per_hour=600,
    burst_size=5
)

agent = PersonSearchAgent(rate_limit_config=rate_config)
```

### 3. Error Handling

#### Comprehensive Error Handling
```python
from src.providers.enformion_client import EnformionAPIError

try:
    query = PersonSearchQuery(first_name="John", last_name="Doe")
    results = agent.search(query)
    
    if not results:
        print("No results found")
    else:
        for person in results:
            print(f"Found: {person.name.display_name}")
            
except ValueError as e:
    print(f"Invalid query parameters: {e}")
    
except EnformionAPIError as e:
    print(f"API Error: {e}")
    if e.status_code == 429:
        print("Rate limited - wait before retrying")
    elif e.status_code == 401:
        print("Authentication failed - check credentials")
        
except Exception as e:
    print(f"Unexpected error: {e}")
```

### 4. Result Processing

#### Confidence Filtering
```python
# Filter results by confidence threshold
high_confidence_results = [
    person for person in results 
    if person.confidence_score >= 0.8
]
```

#### Duplicate Detection
```python
# Find and remove duplicates
all_results = agent.search(query1) + agent.search(query2)
duplicates = agent.find_duplicates(all_results, similarity_threshold=0.9)

print(f"Found {len(duplicates)} potential duplicates")
for dup in duplicates:
    person1, person2, similarity = dup
    print(f"Similarity: {similarity:.2f}")
    print(f"  - {person1.name.display_name}")
    print(f"  - {person2.name.display_name}")
```

#### Data Export
```python
# Convert to summary format
summaries = [person.to_summary_dict() for person in results]

# Export to JSON
import json
with open("search_results.json", "w") as f:
    json.dump(summaries, f, indent=2, default=str)
```

### 5. Monitoring and Metrics

#### Performance Monitoring
```python
# Check agent metrics
metrics = agent.get_metrics()
print(f"Total requests: {metrics['total_requests']}")
print(f"Success rate: {metrics['success_rate']:.1f}%")
print(f"Cache hit rate: {metrics['cache_hit_rate']:.1f}%")
print(f"Average response time: {metrics['average_response_time']:.2f}s")

# Reset metrics
agent.reset_metrics()
```

#### Health Check
```python
# Verify agent health
health = agent.health_check()
if health['status'] == 'healthy':
    print("Agent is operational")
else:
    print(f"Agent issue: {health['error']}")
```

## Data Models

### PersonProfile Structure
```python
# PersonProfile contains:
person = results[0]

# Core identity
person.name.first           # First name
person.name.last            # Last name
person.name.full            # Full name
person.name.display_name    # Best display name

# Demographics
person.demographics.age     # Age
person.demographics.birth_year
person.demographics.gender

# Contact information
person.phones              # List[Phone]
person.emails              # List[Email]  
person.addresses           # List[Address]

# Relationships
person.associates          # List[Associate]
person.relatives           # List[Associate]

# Metadata
person.confidence_score    # Result confidence (0.0-1.0)
person.source_provider     # Data source
person.query_timestamp     # When retrieved
person.raw_response        # Original API response

# Convenience properties
person.current_phone       # Most likely current phone
person.primary_email       # Most likely primary email
person.current_address     # Most likely current address
```

## Configuration Options

### Agent Configuration
```python
PersonSearchAgent(
    # Search behavior
    fuzzy_threshold=0.8,           # Name similarity threshold
    max_age_variance=5,            # Age tolerance in years
    location_radius_miles=50,      # Location proximity radius
    
    # Rate limiting
    rate_limit_config=RateLimitConfig(
        requests_per_second=0.5,
        requests_per_minute=25,
        requests_per_hour=500,
        requests_per_day=2000,
        burst_size=3
    ),
    
    # Caching
    cache_config=CacheConfig(
        enabled=True,
        ttl_seconds=7200,          # 2 hours
        max_entries=500,
        compress=True
    ),
    
    # HTTP settings
    timeout=45                     # Request timeout in seconds
)
```

### Query Configuration
```python
PersonSearchQuery(
    # Search parameters
    first_name="John",
    last_name="Doe",
    phone="5551234567",
    city="Los Angeles",
    state="CA",
    
    # Search options
    fuzzy_matching=True,
    include_relatives=True,
    include_associates=True,
    historical_addresses=True,
    
    # Quality controls
    min_confidence=0.7,
    require_validation=False,
    
    # Result limits
    max_results=10,
    include_raw_data=False,
    
    # Performance
    timeout=30,
    cache_strategy="use_cache"
)
```

## Best Practices

### 1. Query Optimization

- **Start specific**: Use as many identifying parameters as possible
- **Use fuzzy matching**: Enable for better name matching
- **Set appropriate confidence thresholds**: Filter low-quality results
- **Limit results**: Don't request more data than needed

### 2. Performance Optimization

- **Enable caching**: Reduces API calls for similar queries
- **Batch related queries**: Group searches when possible
- **Monitor rate limits**: Respect API usage limits
- **Use async patterns**: For multiple concurrent searches

### 3. Error Handling

- **Handle API errors gracefully**: Implement retry logic
- **Validate input data**: Check parameters before searching
- **Log important events**: Track usage and errors
- **Implement fallbacks**: Have alternative search strategies

### 4. Data Quality

- **Validate results**: Check confidence scores
- **Clean duplicate data**: Use duplicate detection
- **Verify critical information**: Cross-reference important data
- **Handle missing data**: Gracefully handle incomplete profiles

## Example Applications

### 1. Identity Verification System
```python
def verify_identity(first_name, last_name, phone, address):
    """Verify person identity using multiple data points"""
    agent = PersonSearchAgent(min_confidence=0.8)
    
    query = PersonSearchQuery(
        first_name=first_name,
        last_name=last_name,
        phone=phone,
        street=address.get('street'),
        city=address.get('city'),
        state=address.get('state')
    )
    
    results = agent.search(query)
    
    if results and results[0].confidence_score >= 0.9:
        return {
            'verified': True,
            'confidence': results[0].confidence_score,
            'profile': results[0]
        }
    else:
        return {'verified': False, 'reason': 'Insufficient match confidence'}
```

### 2. Contact Enrichment Service
```python
def enrich_contact(email_or_phone):
    """Enrich contact information from email or phone"""
    agent = PersonSearchAgent()
    
    if '@' in email_or_phone:
        # Email search not directly supported - would need additional logic
        return None
    else:
        # Phone search
        results = agent.search_by_phone(email_or_phone)
        
        if results:
            person = results[0]
            return {
                'name': person.name.display_name,
                'additional_phones': [p.formatted for p in person.phones[1:]],
                'emails': [e.address for e in person.emails],
                'address': person.current_address.full_address if person.current_address else None,
                'confidence': person.confidence_score
            }
    
    return None
```

### 3. Background Check Helper
```python
def background_search(first_name, last_name, known_locations):
    """Comprehensive background search across multiple locations"""
    agent = PersonSearchAgent(include_relatives=True, include_associates=True)
    
    all_results = []
    
    for location in known_locations:
        query = PersonSearchQuery(
            first_name=first_name,
            last_name=last_name,
            city=location.get('city'),
            state=location.get('state'),
            historical_addresses=True,
            max_results=20
        )
        
        results = agent.search(query)
        all_results.extend(results)
    
    # Remove duplicates
    duplicates = agent.find_duplicates(all_results)
    unique_results = []
    seen_ids = set()
    
    for person in all_results:
        person_id = f"{person.name.display_name}_{person.current_phone.number if person.current_phone else 'no_phone'}"
        if person_id not in seen_ids:
            unique_results.append(person)
            seen_ids.add(person_id)
    
    return {
        'total_found': len(unique_results),
        'high_confidence': [p for p in unique_results if p.confidence_score >= 0.8],
        'all_addresses': list(set([
            addr.full_address for person in unique_results 
            for addr in person.addresses
        ])),
        'associates': list(set([
            assoc.name.display_name for person in unique_results 
            for assoc in person.associates
        ]))
    }
```

## Troubleshooting

### Common Issues

1. **No Results Found**
   - Check parameter spelling and formatting
   - Try fuzzy matching
   - Reduce confidence threshold
   - Try broader search parameters

2. **Low Confidence Scores**
   - Use more specific parameters
   - Check data quality in query
   - Verify name spelling variations
   - Consider age variance settings

3. **Rate Limiting Errors**
   - Check rate limit configuration
   - Implement exponential backoff
   - Use caching to reduce API calls
   - Monitor usage patterns

4. **Authentication Failures**
   - Verify API credentials in secure locker
   - Check credential expiration
   - Ensure proper provider configuration
   - Test with EnformionGO client directly

### Debugging

```python
import logging

# Enable debug logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('src.agents.person_search_agent')
logger.setLevel(logging.DEBUG)

# Check agent health
health = agent.health_check()
print(f"Agent status: {health}")

# Monitor metrics
metrics = agent.get_metrics()
print(f"Performance metrics: {metrics}")
```

This comprehensive guide covers all major usage patterns and features of the PersonSearchAgent. Refer to the source code and unit tests for additional implementation details.