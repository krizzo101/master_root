# Base Agent Framework Documentation

## Overview

The `BaseIntelligenceAgent` class provides a comprehensive, secure foundation for all intelligence gathering agents in the Sleuth Intel system. It implements industry best practices for API integration, security, performance, and monitoring.

## Key Features

### 🔐 Security
- **Secure Credential Management**: Integrates with `SecureAPILocker` for encrypted credential storage
- **Safe Logging**: Credential hashes and safe IDs prevent sensitive data leakage
- **Authentication Abstraction**: Pluggable authentication methods per provider

### ⚡ Performance
- **Response Caching**: LRU cache with TTL for reduced API calls
- **Disk Persistence**: Optional compressed disk caching for large datasets
- **Connection Pooling**: Efficient HTTP session management with keep-alive

### 🛡️ Reliability
- **Rate Limiting**: Multi-tier rate limiting (per second/minute/hour/day)
- **Retry Logic**: Exponential backoff with configurable retry strategies  
- **Circuit Breaking**: Quota exhaustion detection and handling
- **Graceful Degradation**: Fallback mechanisms for service failures

### 📊 Monitoring
- **Comprehensive Metrics**: Request counts, timing, success rates, cache performance
- **Health Checks**: Built-in agent health monitoring
- **Structured Logging**: Detailed logging with safe credential handling

## Architecture

```
BaseIntelligenceAgent
├── SecureAPILocker Integration
├── RateLimiter (Multi-tier)
├── ResponseCache (LRU + Disk)
├── MetricsData (Thread-safe)
├── RetryStrategy (Exponential backoff)
└── Health Monitoring
```

## Configuration Classes

### RateLimitConfig
Controls API request rate limiting across multiple time windows:

```python
@dataclass 
class RateLimitConfig:
    requests_per_second: float = 1.0    # Sustained rate
    requests_per_minute: int = 60        # Burst protection
    requests_per_hour: int = 3600        # Hourly quota
    requests_per_day: int = 86400        # Daily quota
    burst_size: int = 5                  # Burst token bucket
    backoff_multiplier: float = 2.0      # Exponential backoff
    max_backoff: float = 300.0           # Max wait time
```

### RetryConfig
Configures retry behavior for failed requests:

```python
@dataclass
class RetryConfig:
    max_retries: int = 3                 # Max retry attempts
    backoff_factor: float = 1.0          # Retry delay multiplier
    status_forcelist: List[int] = [429, 500, 502, 503, 504]  # Retry statuses
    allowed_methods: List[str] = ["HEAD", "GET", "OPTIONS"]  # Safe methods
    raise_on_status: bool = True         # Raise on HTTP errors
```

### CacheConfig
Controls response caching behavior:

```python
@dataclass
class CacheConfig:
    enabled: bool = True                 # Enable caching
    ttl_seconds: int = 3600             # Default TTL (1 hour)
    max_entries: int = 1000             # LRU capacity
    cache_dir: Optional[Path] = None    # Disk cache location
    compress: bool = True               # Gzip compression
```

## Core Components

### 1. RateLimiter
Multi-tier rate limiter with burst protection:
- **Burst Tokens**: Allow temporary rate spikes within limits
- **Time Windows**: Per-second, minute, hour, and day limits
- **Thread Safety**: Full thread-safe operation with RLock
- **Timeout Support**: Configurable wait timeouts

### 2. ResponseCache  
LRU cache with disk persistence:
- **Memory Cache**: Fast in-memory LRU with access tracking
- **Disk Persistence**: Optional compressed JSON storage
- **TTL Support**: Per-entry time-to-live expiration
- **Thread Safety**: Concurrent access protection
- **Size Limits**: Configurable memory and disk limits

### 3. Metrics Collection
Comprehensive performance tracking:
- **Request Metrics**: Total, successful, failed counts
- **Timing Data**: Average response times, total time
- **Cache Performance**: Hit rates, cached responses
- **Error Tracking**: Rate limits, quota exhaustion
- **Thread Safety**: Atomic metric updates

### 4. Secure Authentication
Integration with SecureAPILocker:
- **Credential Rotation**: Automatic round-robin credential usage
- **Usage Tracking**: Per-credential usage statistics
- **Safe Logging**: Hashed identifiers prevent credential leakage
- **Multiple Providers**: Support for various authentication schemes

## Usage Examples

### Basic Agent Implementation

```python
from src.agents.base_agent import BaseIntelligenceAgent, RateLimitConfig
from src.core.secure_api_locker import APICredential

class MyIntelligenceAgent(BaseIntelligenceAgent):
    def __init__(self):
        rate_config = RateLimitConfig(
            requests_per_second=2.0,
            requests_per_minute=100
        )
        
        super().__init__(
            provider="my_provider",
            agent_name="my_agent",
            rate_limit_config=rate_config
        )
    
    def _apply_authentication(self, credential: APICredential, request_kwargs: Dict) -> Dict:
        """Apply API key authentication"""
        request_kwargs['headers'] = request_kwargs.get('headers', {})
        request_kwargs['headers']['Authorization'] = f'Bearer {credential.key_value}'
        return request_kwargs
    
    def query(self, query_params: Dict[str, Any], **kwargs) -> Any:
        """Execute intelligence query"""
        response = self.make_request(
            method='GET',
            url=f'https://api.myprovider.com/search',
            params=query_params,
            use_cache=True,
            cache_ttl=1800  # 30 minutes
        )
        
        return response.json()
```

### Advanced Configuration

```python
from pathlib import Path

# Custom configurations
rate_config = RateLimitConfig(
    requests_per_second=0.5,     # Conservative rate
    requests_per_minute=30,      # API limit
    burst_size=3,                # Small bursts allowed
    backoff_multiplier=1.5       # Gentle backoff
)

cache_config = CacheConfig(
    enabled=True,
    ttl_seconds=7200,            # 2 hour cache
    max_entries=5000,            # Large cache
    cache_dir=Path('/tmp/intel_cache'),
    compress=True
)

retry_config = RetryConfig(
    max_retries=5,               # Aggressive retries
    backoff_factor=2.0,          # Exponential backoff
    status_forcelist=[429, 500, 502, 503, 504, 408]  # Include timeouts
)

agent = MyIntelligenceAgent(
    rate_limit_config=rate_config,
    cache_config=cache_config,
    retry_config=retry_config,
    custom_headers={'X-Client': 'SleuthIntel-Advanced'},
    timeout=60
)
```

### Async Usage

```python
async def async_query_example():
    agent = MyIntelligenceAgent()
    
    response = await agent.make_async_request(
        method='GET',
        url='https://api.provider.com/data',
        params={'query': 'search_term'},
        use_cache=True
    )
    
    data = await response.json()
    return data
```

## Monitoring and Metrics

### Health Checks
```python
# Check agent health
health = agent.health_check()
print(f"Status: {health['status']}")
print(f"Metrics: {health['metrics']}")
```

### Performance Metrics
```python
# Get detailed metrics
metrics = agent.get_metrics()
print(f"Success Rate: {metrics['success_rate']:.1f}%")
print(f"Cache Hit Rate: {metrics['cache_hit_rate']:.1f}%")
print(f"Average Response Time: {metrics['average_response_time']:.2f}s")
print(f"Rate Limit Hits: {metrics['rate_limit_hits']}")
```

### Metric Reset and Cache Management
```python
# Reset metrics
agent.reset_metrics()

# Clear cache
agent.clear_cache()
```

## Error Handling

The framework provides comprehensive error handling:

### Rate Limiting
- **429 Status**: Automatic retry with exponential backoff
- **Retry-After Header**: Respects server retry timing
- **Quota Exhaustion**: Detection and tracking of quota limits
- **Burst Protection**: Token bucket prevents sustained overuse

### Network Errors
- **Connection Failures**: Automatic retry with backoff
- **Timeouts**: Configurable request and connection timeouts  
- **DNS Failures**: Retry on temporary DNS issues
- **SSL Errors**: Proper certificate validation

### API Errors
- **Invalid Responses**: JSON parsing error handling
- **Authentication Failures**: Credential rotation on 401/403
- **Server Errors**: Retry on 5xx status codes
- **Malformed Requests**: Validation before sending

## Security Considerations

### Credential Security
- **No Plain Text Storage**: All credentials encrypted in SecureAPILocker
- **Safe Logging**: Only hashed credential identifiers in logs
- **Automatic Rotation**: Round-robin usage prevents overuse
- **Audit Trail**: Usage tracking for security monitoring

### Request Security
- **HTTPS Only**: All requests use secure connections
- **Certificate Validation**: Proper SSL/TLS verification
- **Header Sanitization**: Safe header construction
- **Input Validation**: Parameter validation before requests

### Cache Security
- **Temporary Storage**: Configurable cache persistence
- **File Permissions**: Restrictive cache file permissions (600)
- **Compression**: Optional data compression reduces exposure
- **TTL Enforcement**: Automatic expiration of cached data

## Best Practices

### 1. Configuration
- **Environment-Specific**: Different configs for dev/staging/prod
- **Conservative Defaults**: Start with lower rate limits
- **Monitor Metrics**: Adjust based on actual performance
- **Cache Tuning**: Balance memory usage vs. performance

### 2. Error Handling
- **Graceful Degradation**: Handle API failures gracefully
- **User Feedback**: Provide meaningful error messages
- **Logging**: Log errors for debugging but not credentials
- **Circuit Breaking**: Stop on repeated failures

### 3. Performance
- **Cache Everything**: Cache successful responses aggressively
- **Batch Requests**: Combine multiple queries when possible
- **Async When Appropriate**: Use async for I/O bound operations
- **Monitor Quotas**: Track usage to prevent exhaustion

### 4. Security
- **Minimal Permissions**: Use least-privilege principle
- **Regular Rotation**: Rotate API keys periodically
- **Audit Usage**: Monitor for unusual patterns
- **Encrypt at Rest**: Secure credential storage

## Extension Points

### Custom Authentication
Override `_apply_authentication` for provider-specific auth:

```python
def _apply_authentication(self, credential: APICredential, request_kwargs: Dict) -> Dict:
    if credential.password:  # OAuth or similar
        request_kwargs['auth'] = (credential.key_value, credential.password)
    else:  # API key
        request_kwargs['headers']['X-API-Key'] = credential.key_value
    
    return request_kwargs
```

### Custom Caching
Override cache behavior for specialized needs:

```python
def _generate_cache_key(self, method: str, url: str, **kwargs) -> str:
    # Custom key generation logic
    sensitive_params = kwargs.get('params', {}).copy()
    sensitive_params.pop('api_key', None)  # Remove sensitive data
    
    return super()._generate_cache_key(method, url, params=sensitive_params)
```

### Custom Metrics
Extend metrics collection:

```python
def _update_metrics(self, success: bool, response_time: float, cached: bool = False) -> None:
    super()._update_metrics(success, response_time, cached)
    
    # Custom metric tracking
    if hasattr(self, 'custom_metrics'):
        self.custom_metrics.update({
            'custom_field': calculate_custom_metric()
        })
```

## Testing

The framework supports comprehensive testing:

### Unit Tests
```python
import unittest
from unittest.mock import patch, Mock

class TestMyAgent(unittest.TestCase):
    def setUp(self):
        self.agent = MyIntelligenceAgent()
    
    @patch('requests.Session.request')
    def test_successful_request(self, mock_request):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'result': 'success'}
        mock_request.return_value = mock_response
        
        result = self.agent.query({'q': 'test'})
        self.assertEqual(result['result'], 'success')
        
    def test_metrics_tracking(self):
        initial_requests = self.agent.metrics.total_requests
        # Make some requests...
        final_requests = self.agent.metrics.total_requests
        self.assertGreater(final_requests, initial_requests)
```

### Integration Tests
```python
def test_integration_with_real_api():
    agent = MyIntelligenceAgent()
    
    # Test with real credentials (if available)
    if agent.get_credential():
        result = agent.query({'q': 'test_query'})
        assert result is not None
        
        # Check metrics were updated
        metrics = agent.get_metrics()
        assert metrics['total_requests'] > 0
```

## Troubleshooting

### Common Issues

1. **No Credentials Available**
   - Check SecureAPILocker configuration
   - Verify credentials are properly loaded
   - Ensure provider name matches

2. **Rate Limit Errors**
   - Adjust rate limit configuration
   - Check API provider limits
   - Monitor burst usage patterns

3. **Cache Miss Rate High**  
   - Increase cache size
   - Extend TTL for stable data
   - Check cache key generation

4. **High Response Times**
   - Reduce timeout values
   - Enable connection pooling
   - Use async requests

5. **Memory Usage Growth**
   - Limit cache size
   - Enable disk caching
   - Regular cache cleanup

### Debugging

Enable debug logging:
```python
import logging
logging.getLogger('src.agents.base_agent').setLevel(logging.DEBUG)
```

Monitor metrics continuously:
```python
def monitor_agent(agent, interval=60):
    while True:
        metrics = agent.get_metrics()
        print(f"Requests: {metrics['total_requests']}, "
              f"Success Rate: {metrics['success_rate']:.1f}%, "
              f"Cache Hit Rate: {metrics['cache_hit_rate']:.1f}%")
        time.sleep(interval)
```

## Future Enhancements

Planned improvements for the framework:

1. **Distributed Caching**: Redis/Memcached integration
2. **Advanced Metrics**: Prometheus/StatsD export
3. **Circuit Breaker**: Automatic failure detection
4. **Load Balancing**: Multiple endpoint support  
5. **Request Queuing**: Background job processing
6. **Streaming Support**: Real-time data processing
7. **GraphQL Support**: Modern API integration
8. **Webhook Integration**: Event-driven processing

## Conclusion

The BaseIntelligenceAgent framework provides a production-ready foundation for building secure, performant, and reliable intelligence gathering agents. Its comprehensive feature set handles the complexities of external API integration while providing excellent observability and maintainability.

For implementation examples and specific agent development, see individual agent documentation in the `/agents/` directory.