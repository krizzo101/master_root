"""
Comprehensive tests for EmailSearchAgent
Tests all email intelligence capabilities with privacy compliance
"""

import pytest
import json
import time
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

from src.agents.email_search_agent import EmailSearchAgent
from src.agents.base_agent import RateLimitConfig, CacheConfig
from src.core.secure_api_locker import APICredential
from src.providers.enformion_client import EnformionAPIError


class TestEmailSearchAgent:
    """Test suite for EmailSearchAgent functionality"""
    
    @pytest.fixture
    def mock_credential(self):
        """Create mock API credential"""
        return APICredential(
            provider="enformion",
            key_name="test_key",
            key_value="test_api_key",
            password="test_password",
            created_at=datetime.now(),
            last_used=None,
            usage_count=0
        )
    
    @pytest.fixture
    def email_agent(self, mock_credential):
        """Create EmailSearchAgent instance with mocked credentials"""
        with patch('src.agents.email_search_agent.APILockerManager') as mock_locker:
            mock_locker.get_instance.return_value.get_credential.return_value = mock_credential
            
            agent = EmailSearchAgent(
                rate_limit_config=RateLimitConfig(requests_per_second=10),  # Fast for testing
                cache_config=CacheConfig(enabled=False),  # Disable cache for testing
                enable_breach_detection=True,
                enable_social_correlation=False,  # Privacy-safe default
                enable_mx_validation=True
            )
            return agent
    
    def test_initialization(self, email_agent):
        """Test EmailSearchAgent initialization"""
        assert email_agent.agent_name == "EmailSearchAgent"
        assert email_agent.provider == "enformion"
        assert email_agent.enable_breach_detection is True
        assert email_agent.enable_social_correlation is False
        assert email_agent.enable_mx_validation is True
        assert len(email_agent.DISPOSABLE_DOMAINS) > 0
        assert "10minutemail.com" in email_agent.DISPOSABLE_DOMAINS
    
    def test_email_format_validation_valid(self, email_agent):
        """Test email format validation with valid emails"""
        test_cases = [
            "user@example.com",
            "test.email@domain.org",
            "user+tag@example.co.uk",
            "a@b.co"
        ]
        
        for email in test_cases:
            result = email_agent.validate_email_format(email)
            assert result['is_valid'] is True
            assert result['format_valid'] is True
            assert result['local_part'] != ''
            assert result['domain_part'] != ''
            assert len(result['issues']) == 0
    
    def test_email_format_validation_invalid(self, email_agent):
        """Test email format validation with invalid emails"""
        test_cases = [
            "invalid-email",
            "@example.com",
            "user@",
            "user@.com",
            ".user@example.com",
            "user.@example.com",
            "user..name@example.com",
            "user@ex..ample.com"
        ]
        
        for email in test_cases:
            result = email_agent.validate_email_format(email)
            assert result['is_valid'] is False
            assert len(result['issues']) > 0
    
    def test_email_format_validation_edge_cases(self, email_agent):
        """Test email format validation edge cases"""
        # Empty email
        result = email_agent.validate_email_format("")
        assert result['is_valid'] is False
        assert "Email is empty" in result['issues'][0]
        
        # None email
        result = email_agent.validate_email_format(None)
        assert result['is_valid'] is False
        
        # Very long local part
        long_local = "a" * 65 + "@example.com"
        result = email_agent.validate_email_format(long_local)
        assert result['is_valid'] is False
        assert any("too long" in issue for issue in result['issues'])
    
    @patch('dns.resolver.resolve')
    def test_email_deliverability_valid(self, mock_dns, email_agent):
        """Test email deliverability with valid MX records"""
        # Mock DNS response
        mock_mx = Mock()
        mock_mx.__str__ = lambda: "10 mail.example.com."
        mock_dns.return_value = [mock_mx]
        
        result = email_agent.validate_email_deliverability("user@example.com")
        
        assert result['deliverable'] is True
        assert result['mx_valid'] is True
        assert len(result['mx_records']) > 0
        assert len(result['issues']) == 0
    
    @patch('dns.resolver.resolve')
    def test_email_deliverability_invalid(self, mock_dns, email_agent):
        """Test email deliverability with no MX records"""
        from dns.resolver import NXDOMAIN
        mock_dns.side_effect = NXDOMAIN()
        
        result = email_agent.validate_email_deliverability("user@nonexistent.com")
        
        assert result['deliverable'] is False
        assert result['mx_valid'] is False
        assert "Domain does not exist" in result['issues']
    
    def test_email_classification_disposable(self, email_agent):
        """Test classification of disposable email addresses"""
        disposable_emails = [
            "user@10minutemail.com",
            "test@guerrillamail.com",
            "temp@mailinator.com"
        ]
        
        for email in disposable_emails:
            result = email_agent.classify_email_type(email)
            assert result['type'] == 'disposable'
            assert result['is_disposable'] is True
            assert result['confidence'] > 0.9
    
    def test_email_classification_personal(self, email_agent):
        """Test classification of personal email addresses"""
        personal_emails = [
            "user@gmail.com",
            "test@yahoo.com",
            "person@hotmail.com",
            "user@outlook.com"
        ]
        
        for email in personal_emails:
            result = email_agent.classify_email_type(email)
            assert result['type'] == 'personal'
            assert result['is_personal'] is True
            assert result['confidence'] > 0.7
    
    def test_email_classification_business(self, email_agent):
        """Test classification of business email addresses"""
        business_emails = [
            "contact@company.com",
            "info@business.org",
            "support@startup.io"
        ]
        
        for email in business_emails:
            result = email_agent.classify_email_type(email)
            assert result['type'] == 'professional'
            assert result['is_professional'] is True
            assert result['is_business'] is True
            assert result['confidence'] > 0.8
    
    def test_email_classification_role_based(self, email_agent):
        """Test classification of role-based email addresses"""
        role_emails = [
            "admin@company.com",
            "sales@business.com",
            "marketing@startup.io"
        ]
        
        for email in role_emails:
            result = email_agent.classify_email_type(email)
            assert result['is_business'] is True
            assert "Role-based email address" in result['indicators']
            assert result['confidence'] > 0.9
    
    @patch('whois.whois')
    def test_domain_info_extraction(self, mock_whois, email_agent):
        """Test domain information extraction"""
        # Mock whois response
        mock_whois.return_value = {
            'registrar': 'Test Registrar',
            'org': 'Test Organization',
            'country': 'US',
            'creation_date': datetime(2020, 1, 1),
            'expiration_date': datetime(2025, 1, 1)
        }
        
        result = email_agent.extract_domain_info("user@example.com")
        
        assert result['domain'] == 'example.com'
        assert result['registrar'] == 'Test Registrar'
        assert result['organization'] == 'Test Organization'
        assert result['country'] == 'US'
        assert result['error'] is None
    
    @patch('whois.whois')
    def test_domain_info_extraction_error(self, mock_whois, email_agent):
        """Test domain information extraction with whois error"""
        mock_whois.side_effect = Exception("WHOIS lookup failed")
        
        result = email_agent.extract_domain_info("user@example.com")
        
        assert result['domain'] == 'example.com'
        assert 'WHOIS lookup failed' in result['error']
    
    def test_reverse_lookup_mock_response(self, email_agent):
        """Test reverse email lookup with mocked API response"""
        mock_response = {
            'results': [{
                'person': {
                    'first_name': 'John',
                    'last_name': 'Doe',
                    'full_name': 'John Doe',
                    'age': 35,
                    'phones': ['5551234567'],
                    'addresses': [{'street': '123 Main St', 'city': 'Anytown', 'state': 'CA'}]
                },
                'business': {
                    'name': 'Acme Corp',
                    'industry': 'Technology',
                    'website': 'https://acme.com'
                }
            }]
        }
        
        with patch.object(email_agent.enformion_client, '_make_request', return_value=mock_response):
            result = email_agent.reverse_email_lookup("john.doe@example.com")
            
            assert result['found'] is True
            assert result['person_info']['first_name'] == 'John'
            assert result['person_info']['last_name'] == 'Doe'
            assert result['business_info']['name'] == 'Acme Corp'
            assert result['confidence_score'] > 0.0
    
    def test_reverse_lookup_no_results(self, email_agent):
        """Test reverse email lookup with no results"""
        mock_response = {'results': []}
        
        with patch.object(email_agent.enformion_client, '_make_request', return_value=mock_response):
            result = email_agent.reverse_email_lookup("unknown@example.com")
            
            assert result['found'] is False
            assert result['person_info'] == {}
            assert result['confidence_score'] == 0.0
    
    def test_reverse_lookup_api_error(self, email_agent):
        """Test reverse email lookup with API error"""
        with patch.object(email_agent.enformion_client, '_make_request', 
                         side_effect=EnformionAPIError("API Error")):
            result = email_agent.reverse_email_lookup("error@example.com")
            
            assert result['found'] is False
            assert 'error' in result
            assert 'API Error' in result['error']
    
    def test_breach_detection_enabled(self, email_agent):
        """Test breach detection when enabled"""
        # Mock reverse lookup with breach data
        mock_breach_result = {
            'breach_info': {
                'found_in_breaches': True,
                'breach_count': 2,
                'breaches': [
                    {'name': 'Test Breach 1', 'date': '2020-01-01'},
                    {'name': 'Test Breach 2', 'date': '2021-01-01'}
                ]
            }
        }
        
        with patch.object(email_agent, 'reverse_email_lookup', return_value=mock_breach_result):
            result = email_agent.detect_email_breaches("compromised@example.com")
            
            assert result['found_in_breaches'] is True
            assert result['breach_count'] == 2
            assert result['risk_level'] == 'medium'
            assert len(result['breaches']) == 2
    
    def test_breach_detection_disabled(self):
        """Test breach detection when disabled"""
        with patch('src.agents.email_search_agent.APILockerManager'):
            agent = EmailSearchAgent(enable_breach_detection=False)
            
            result = agent.detect_email_breaches("test@example.com")
            
            assert result['breach_detection_enabled'] is False
            assert 'disabled' in result['message']
    
    def test_social_profiles_disabled(self, email_agent):
        """Test social profile correlation when disabled (default)"""
        profiles = email_agent.find_social_profiles("test@example.com")
        assert profiles == []
    
    def test_social_profiles_enabled(self):
        """Test social profile correlation when enabled"""
        with patch('src.agents.email_search_agent.APILockerManager'):
            agent = EmailSearchAgent(enable_social_correlation=True)
            
            mock_result = {
                'social_profiles': [
                    {'platform': 'twitter', 'username': 'testuser', 'url': 'https://twitter.com/testuser'}
                ]
            }
            
            with patch.object(agent, 'reverse_email_lookup', return_value=mock_result):
                profiles = agent.find_social_profiles("test@example.com")
                
                assert len(profiles) == 1
                assert profiles[0]['platform'] == 'twitter'
                assert profiles[0]['username'] == 'testuser'
    
    def test_cross_reference_with_person_agent(self, email_agent):
        """Test cross-referencing with PersonSearchAgent"""
        # Mock person agent
        mock_person_agent = Mock()
        mock_person = Mock()
        mock_person.name.display_name = "John Doe"
        mock_person.confidence_score = 0.9
        mock_person.phones = []
        mock_person.addresses = []
        mock_person_agent.search.return_value = [mock_person]
        
        # Mock email lookup result
        email_result = {
            'found': True,
            'person_info': {
                'first_name': 'John',
                'last_name': 'Doe'
            }
        }
        
        with patch.object(email_agent, 'reverse_email_lookup', return_value=email_result):
            result = email_agent.cross_reference_with_person("john.doe@example.com", mock_person_agent)
            
            assert result['cross_reference_performed'] is True
            assert len(result['matching_persons']) == 1
            assert result['matching_persons'][0]['name'] == "John Doe"
            assert result['confidence_score'] == 0.9
    
    def test_comprehensive_analysis(self, email_agent):
        """Test comprehensive email analysis"""
        email = "test@example.com"
        
        # Mock all the individual methods
        with patch.object(email_agent, 'validate_email_format') as mock_format, \
             patch.object(email_agent, 'validate_email_deliverability') as mock_deliver, \
             patch.object(email_agent, 'classify_email_type') as mock_classify, \
             patch.object(email_agent, 'extract_domain_info') as mock_domain, \
             patch.object(email_agent, 'reverse_email_lookup') as mock_reverse, \
             patch.object(email_agent, 'detect_email_breaches') as mock_breach, \
             patch.object(email_agent, 'find_social_profiles') as mock_social, \
             patch.object(email_agent, 'cross_reference_with_person') as mock_cross:
            
            # Setup mock returns
            mock_format.return_value = {'is_valid': True, 'format_valid': True}
            mock_deliver.return_value = {'deliverable': True}
            mock_classify.return_value = {'type': 'personal', 'confidence': 0.8}
            mock_domain.return_value = {'domain': 'example.com'}
            mock_reverse.return_value = {'found': True, 'confidence_score': 0.7}
            mock_breach.return_value = {'found_in_breaches': False}
            mock_social.return_value = []
            mock_cross.return_value = {'confidence_score': 0.9}
            
            result = email_agent.comprehensive_email_analysis(email)
            
            # Verify all analysis components are present
            assert 'format_validation' in result
            assert 'deliverability' in result
            assert 'classification' in result
            assert 'domain_info' in result
            assert 'reverse_lookup' in result
            assert 'breach_detection' in result
            assert 'social_profiles' in result
            assert 'cross_reference' in result
            assert 'overall_confidence' in result
            assert 'processing_time' in result
            
            # Verify overall confidence calculation
            assert result['overall_confidence'] > 0.0
    
    def test_comprehensive_analysis_invalid_email(self, email_agent):
        """Test comprehensive analysis with invalid email"""
        email = "invalid-email"
        
        result = email_agent.comprehensive_email_analysis(email)
        
        # Should stop at format validation
        assert result['format_validation']['is_valid'] is False
        assert result['processing_time'] > 0
    
    def test_query_interface(self, email_agent):
        """Test BaseIntelligenceAgent query interface"""
        with patch.object(email_agent, 'comprehensive_email_analysis') as mock_analysis:
            mock_analysis.return_value = {'comprehensive': 'result'}
            
            # Test with email_address parameter
            result1 = email_agent.query({'email_address': 'test@example.com'})
            assert result1 == {'comprehensive': 'result'}
            mock_analysis.assert_called_with('test@example.com', None)
            
            # Test with email parameter
            result2 = email_agent.query({'email': 'test2@example.com'})
            mock_analysis.assert_called_with('test2@example.com', None)
            
            # Test with person_agent
            mock_person_agent = Mock()
            result3 = email_agent.query({'email': 'test3@example.com'}, person_agent=mock_person_agent)
            mock_analysis.assert_called_with('test3@example.com', mock_person_agent)
    
    def test_query_interface_missing_email(self, email_agent):
        """Test query interface with missing email parameter"""
        with pytest.raises(ValueError, match="Query must contain 'email_address' or 'email' parameter"):
            email_agent.query({'invalid': 'parameter'})
    
    def test_health_check(self, email_agent):
        """Test agent health check"""
        health = email_agent.health_check()
        
        assert health['status'] == 'healthy'
        assert health['agent_name'] == 'EmailSearchAgent'
        assert 'email_validation_ready' in health
        assert 'breach_detection_enabled' in health
        assert 'social_correlation_enabled' in health
        assert 'mx_validation_enabled' in health
        assert 'disposable_domains_count' in health
        
        # Verify feature flags
        assert health['breach_detection_enabled'] is True
        assert health['social_correlation_enabled'] is False
        assert health['mx_validation_enabled'] is True
        assert health['disposable_domains_count'] > 0
    
    def test_rate_limiting(self, mock_credential):
        """Test rate limiting configuration"""
        with patch('src.agents.email_search_agent.APILockerManager') as mock_locker:
            mock_locker.get_instance.return_value.get_credential.return_value = mock_credential
            
            # Create agent with strict rate limits
            strict_config = RateLimitConfig(
                requests_per_second=0.1,  # Very slow
                requests_per_minute=5,
                burst_size=1
            )
            
            agent = EmailSearchAgent(rate_limit_config=strict_config)
            
            assert agent.rate_limit_config.requests_per_second == 0.1
            assert agent.rate_limit_config.requests_per_minute == 5
            assert agent.rate_limit_config.burst_size == 1
    
    def test_caching_behavior(self, mock_credential):
        """Test caching behavior"""
        with patch('src.agents.email_search_agent.APILockerManager') as mock_locker:
            mock_locker.get_instance.return_value.get_credential.return_value = mock_credential
            
            # Create agent with caching enabled
            cache_config = CacheConfig(enabled=True, ttl_seconds=300)
            agent = EmailSearchAgent(cache_config=cache_config)
            
            email = "cached@example.com"
            mock_response = {
                'results': [{'person': {'first_name': 'Cached', 'last_name': 'User'}}]
            }
            
            # First call - should hit API
            with patch.object(agent.enformion_client, '_make_request', return_value=mock_response) as mock_api:
                result1 = agent.reverse_email_lookup(email)
                assert mock_api.call_count == 1
                assert result1['found'] is True
            
            # Second call - should use cache (if caching works properly)
            with patch.object(agent.enformion_client, '_make_request', return_value=mock_response) as mock_api:
                result2 = agent.reverse_email_lookup(email)
                # Note: Actual cache behavior depends on implementation details
                assert result2['found'] is True
    
    def test_privacy_compliance(self, email_agent):
        """Test privacy-compliant behavior"""
        # Verify social correlation is disabled by default
        assert email_agent.enable_social_correlation is False
        
        # Verify that sensitive operations respect privacy settings
        profiles = email_agent.find_social_profiles("privacy@example.com")
        assert profiles == []  # Should return empty when disabled
        
        # Test that the agent doesn't log sensitive information
        with patch('src.agents.email_search_agent.logger') as mock_logger:
            email_agent.reverse_email_lookup("sensitive@example.com")
            
            # Check that full email addresses are not logged
            logged_calls = mock_logger.info.call_args_list
            for call in logged_calls:
                args = call[0][0] if call[0] else ""
                assert "sensitive@example.com" not in args
                # Should contain masked version like "sensi***"
    
    def test_authentication_application(self, email_agent, mock_credential):
        """Test authentication method application"""
        request_kwargs = {'headers': {}}
        
        result = email_agent._apply_authentication(mock_credential, request_kwargs)
        
        assert 'X-API-Key' in result['headers']
        assert 'X-API-Password' in result['headers']
        assert result['headers']['X-API-Key'] == 'test_api_key'
        assert result['headers']['X-API-Password'] == 'test_password'
    
    def test_authentication_bearer_fallback(self, email_agent):
        """Test authentication fallback to bearer token"""
        credential_no_password = APICredential(
            provider="enformion",
            key_name="test_key",
            key_value="test_token",
            password=None,  # No password
            created_at=datetime.now(),
            last_used=None,
            usage_count=0
        )
        
        request_kwargs = {'headers': {}}
        result = email_agent._apply_authentication(credential_no_password, request_kwargs)
        
        assert 'Authorization' in result['headers']
        assert result['headers']['Authorization'] == 'Bearer test_token'


# Integration tests (require actual API credentials - run separately)
class TestEmailSearchAgentIntegration:
    """Integration tests for EmailSearchAgent - requires real API credentials"""
    
    @pytest.mark.integration
    def test_real_email_validation(self):
        """Test with real email validation (no API calls)"""
        agent = EmailSearchAgent(enable_mx_validation=False)  # Disable to avoid DNS calls
        
        # Test real email format validation
        result = agent.validate_email_format("test@gmail.com")
        assert result['is_valid'] is True
        assert result['domain_part'] == 'gmail.com'
        assert result['local_part'] == 'test'
        assert result['tld'] == 'com'
    
    @pytest.mark.integration  
    def test_real_email_classification(self):
        """Test with real email classification"""
        agent = EmailSearchAgent()
        
        # Test disposable email detection
        result = agent.classify_email_type("temp@10minutemail.com")
        assert result['is_disposable'] is True
        assert result['type'] == 'disposable'
        
        # Test personal email detection
        result = agent.classify_email_type("user@gmail.com")
        assert result['is_personal'] is True
        assert result['type'] == 'personal'


if __name__ == "__main__":
    # Run tests with pytest
    pytest.main([__file__, "-v", "--tb=short"])