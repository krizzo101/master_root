"""Integration tests for agent-to-agent communication."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.agents import PersonSearchAgent, BusinessSearchAgent, AnalysisAgent
from src.orchestration.message_bus import MessageBus
from tests.fixtures.mock_data import MockDataGenerator


class TestAgentCommunication:
    """Test agent-to-agent communication."""
    
    @pytest.fixture
    async def message_bus(self):
        """Create a message bus instance."""
        bus = MessageBus()
        await bus.start()
        yield bus
        await bus.stop()
    
    @pytest.fixture
    def person_agent(self, mock_api_client):
        """Create a PersonSearchAgent."""
        return PersonSearchAgent(api_client=mock_api_client)
    
    @pytest.fixture
    def business_agent(self, mock_api_client):
        """Create a BusinessSearchAgent."""
        return BusinessSearchAgent(api_client=mock_api_client)
    
    @pytest.fixture
    def analysis_agent(self, mock_openai_client):
        """Create an AnalysisAgent."""
        return AnalysisAgent(ai_client=mock_openai_client)
    
    @pytest.mark.asyncio
    async def test_agent_registration(self, message_bus, person_agent):
        """Test agent registration with message bus."""
        await message_bus.register_agent(person_agent)
        
        assert person_agent.name in message_bus.registered_agents
        assert message_bus.registered_agents[person_agent.name] == person_agent
    
    @pytest.mark.asyncio
    async def test_agent_message_publishing(self, message_bus, person_agent):
        """Test agent publishing messages."""
        await message_bus.register_agent(person_agent)
        
        message = {
            "type": "search_result",
            "agent": person_agent.name,
            "data": {"results": []}
        }
        
        await message_bus.publish(person_agent.name, message)
        
        # Verify message was published
        assert message_bus.message_count > 0
    
    @pytest.mark.asyncio
    async def test_agent_message_subscription(self, message_bus, person_agent, business_agent):
        """Test agent subscribing to messages."""
        await message_bus.register_agent(person_agent)
        await message_bus.register_agent(business_agent)
        
        received_messages = []
        
        async def message_handler(message):
            received_messages.append(message)
        
        await message_bus.subscribe(business_agent.name, "person_search_results", message_handler)
        
        # Person agent publishes a message
        message = {
            "type": "person_search_results",
            "data": {"person": {"name": "John Doe"}}
        }
        await message_bus.publish(person_agent.name, message, topic="person_search_results")
        
        # Give time for async processing
        await asyncio.sleep(0.1)
        
        assert len(received_messages) == 1
        assert received_messages[0]["data"]["person"]["name"] == "John Doe"
    
    @pytest.mark.asyncio
    async def test_request_response_pattern(self, message_bus, person_agent, analysis_agent):
        """Test request-response communication pattern."""
        await message_bus.register_agent(person_agent)
        await message_bus.register_agent(analysis_agent)
        
        # Analysis agent requests data from person agent
        request = {
            "type": "data_request",
            "target": person_agent.name,
            "query": {"first_name": "John", "last_name": "Doe"}
        }
        
        response = await message_bus.request(
            analysis_agent.name,
            person_agent.name,
            request,
            timeout=5.0
        )
        
        assert response is not None
        assert "data" in response
    
    @pytest.mark.asyncio
    async def test_broadcast_message(self, message_bus, person_agent, business_agent, analysis_agent):
        """Test broadcasting messages to all agents."""
        agents = [person_agent, business_agent, analysis_agent]
        for agent in agents:
            await message_bus.register_agent(agent)
        
        received_by = []
        
        async def handler(message, agent_name):
            received_by.append(agent_name)
        
        # Subscribe all agents to broadcast channel
        for agent in agents:
            await message_bus.subscribe(
                agent.name,
                "broadcast",
                lambda m, a=agent.name: handler(m, a)
            )
        
        # Broadcast a message
        await message_bus.broadcast({
            "type": "system_alert",
            "message": "Test broadcast"
        })
        
        await asyncio.sleep(0.1)
        
        assert len(received_by) == len(agents)
    
    @pytest.mark.asyncio
    async def test_agent_coordination(self, message_bus, person_agent, business_agent, mock_data_generator):
        """Test coordinated workflow between agents."""
        await message_bus.register_agent(person_agent)
        await message_bus.register_agent(business_agent)
        
        # Mock data
        mock_person = mock_data_generator.create_person()
        mock_business = mock_data_generator.create_business()
        
        person_agent.api_client.search_person.return_value = [mock_person]
        business_agent.api_client.search_business.return_value = [mock_business]
        
        workflow_results = {}
        
        # Person agent searches and notifies business agent
        async def person_search_complete(person_data):
            workflow_results["person"] = person_data
            # Trigger business search based on person data
            await business_agent.search(name=person_data.employment.get("company"))
        
        async def business_search_complete(business_data):
            workflow_results["business"] = business_data
        
        # Set up handlers
        person_agent.on_complete = person_search_complete
        business_agent.on_complete = business_search_complete
        
        # Start workflow
        await person_agent.search(first_name="John", last_name="Doe")
        
        await asyncio.sleep(0.1)
        
        assert "person" in workflow_results
        assert "business" in workflow_results
    
    @pytest.mark.asyncio
    async def test_error_propagation(self, message_bus, person_agent, analysis_agent):
        """Test error propagation between agents."""
        await message_bus.register_agent(person_agent)
        await message_bus.register_agent(analysis_agent)
        
        # Make person agent fail
        person_agent.api_client.search_person.side_effect = Exception("API Error")
        
        error_received = None
        
        async def error_handler(error):
            nonlocal error_received
            error_received = error
        
        await message_bus.subscribe(
            analysis_agent.name,
            "agent_error",
            error_handler
        )
        
        # Trigger error
        try:
            await person_agent.search(first_name="John", last_name="Doe")
        except Exception:
            await message_bus.publish(
                person_agent.name,
                {
                    "type": "error",
                    "error": "API Error",
                    "agent": person_agent.name
                },
                topic="agent_error"
            )
        
        await asyncio.sleep(0.1)
        
        assert error_received is not None
        assert error_received["error"] == "API Error"
    
    @pytest.mark.asyncio
    async def test_message_queue_overflow(self, message_bus):
        """Test message queue overflow handling."""
        message_bus.max_queue_size = 10
        
        # Flood the queue
        for i in range(20):
            await message_bus.publish(
                "test_agent",
                {"message": f"Message {i}"},
                topic="test_topic"
            )
        
        # Verify queue size limit is respected
        assert message_bus.queue_size <= message_bus.max_queue_size
    
    @pytest.mark.asyncio
    async def test_message_priority(self, message_bus):
        """Test message priority handling."""
        high_priority_received = []
        normal_priority_received = []
        
        async def high_handler(message):
            high_priority_received.append(message)
        
        async def normal_handler(message):
            normal_priority_received.append(message)
        
        await message_bus.subscribe("agent1", "high_priority", high_handler)
        await message_bus.subscribe("agent1", "normal_priority", normal_handler)
        
        # Send messages with different priorities
        for i in range(5):
            await message_bus.publish(
                "agent2",
                {"id": i, "priority": "normal"},
                topic="normal_priority"
            )
        
        for i in range(5):
            await message_bus.publish(
                "agent2",
                {"id": i, "priority": "high"},
                topic="high_priority",
                priority="high"
            )
        
        await asyncio.sleep(0.2)
        
        # High priority messages should be processed first
        assert len(high_priority_received) == 5
        assert len(normal_priority_received) == 5


class TestMessageBusResilience:
    """Test message bus resilience and recovery."""
    
    @pytest.mark.asyncio
    async def test_agent_reconnection(self, message_bus, person_agent):
        """Test agent reconnection after disconnect."""
        await message_bus.register_agent(person_agent)
        
        # Simulate disconnect
        await message_bus.unregister_agent(person_agent.name)
        assert person_agent.name not in message_bus.registered_agents
        
        # Reconnect
        await message_bus.register_agent(person_agent)
        assert person_agent.name in message_bus.registered_agents
    
    @pytest.mark.asyncio
    async def test_message_persistence(self, message_bus, mock_redis_client):
        """Test message persistence during agent downtime."""
        message_bus.persistence = mock_redis_client
        
        # Send message to offline agent
        await message_bus.publish(
            "online_agent",
            {"data": "important"},
            topic="offline_agent_topic"
        )
        
        # Verify message was persisted
        mock_redis_client.set.assert_called()
    
    @pytest.mark.asyncio
    async def test_message_replay(self, message_bus, person_agent):
        """Test message replay for recovered agents."""
        await message_bus.register_agent(person_agent)
        
        stored_messages = [
            {"id": 1, "data": "message1"},
            {"id": 2, "data": "message2"}
        ]
        
        # Simulate agent recovery with pending messages
        await message_bus.replay_messages(person_agent.name, stored_messages)
        
        # Verify agent received replayed messages
        assert message_bus.replay_count == len(stored_messages)
    
    @pytest.mark.asyncio
    async def test_circuit_breaker(self, message_bus, person_agent):
        """Test circuit breaker for failing agents."""
        await message_bus.register_agent(person_agent)
        
        # Simulate repeated failures
        for _ in range(5):
            await message_bus.record_failure(person_agent.name)
        
        # Circuit should be open
        is_available = await message_bus.is_agent_available(person_agent.name)
        assert not is_available
        
        # Wait for circuit to reset
        await asyncio.sleep(message_bus.circuit_reset_timeout)
        
        is_available = await message_bus.is_agent_available(person_agent.name)
        assert is_available