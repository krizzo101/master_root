"""Integration tests for orchestrator workflows."""

import asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.orchestration.sleuth_orchestrator import SleuthOrchestrator
from tests.fixtures.mock_data import MockDataGenerator


class TestOrchestratorWorkflows:
    """Test orchestrator workflow execution."""
    
    @pytest.fixture
    async def orchestrator(self, mock_api_client, mock_redis_client, mock_message_bus):
        """Create an orchestrator instance."""
        orch = SleuthOrchestrator(
            api_client=mock_api_client,
            cache=mock_redis_client,
            message_bus=mock_message_bus
        )
        await orch.initialize()
        yield orch
        await orch.shutdown()
    
    @pytest.mark.asyncio
    async def test_simple_person_search_workflow(self, orchestrator, mock_data_generator):
        """Test simple person search workflow."""
        mock_person = mock_data_generator.create_person()
        orchestrator.api_client.search_person.return_value = [mock_person]
        
        workflow = {
            "name": "person_search",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {
                        "first_name": "John",
                        "last_name": "Doe"
                    }
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        assert "results" in result
        assert len(result["results"]) == 1
    
    @pytest.mark.asyncio
    async def test_multi_step_workflow(self, orchestrator, mock_data_generator):
        """Test multi-step workflow execution."""
        mock_person = mock_data_generator.create_person()
        mock_business = mock_data_generator.create_business()
        
        orchestrator.api_client.search_person.return_value = [mock_person]
        orchestrator.api_client.search_business.return_value = [mock_business]
        
        workflow = {
            "name": "comprehensive_search",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {
                        "first_name": "John",
                        "last_name": "Doe"
                    }
                },
                {
                    "agent": "business_search",
                    "action": "search",
                    "params": {
                        "name": "Tech Corp"
                    }
                },
                {
                    "agent": "analysis",
                    "action": "analyze",
                    "params": {
                        "data": "${steps[0].results}"
                    }
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        assert len(result["steps_completed"]) == 3
    
    @pytest.mark.asyncio
    async def test_conditional_workflow(self, orchestrator, mock_data_generator):
        """Test conditional workflow execution."""
        mock_person = mock_data_generator.create_person()
        orchestrator.api_client.search_person.return_value = [mock_person]
        
        workflow = {
            "name": "conditional_search",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {
                        "first_name": "John",
                        "last_name": "Doe"
                    }
                },
                {
                    "agent": "email_search",
                    "action": "search",
                    "condition": "len(steps[0].results) > 0",
                    "params": {
                        "email": "${steps[0].results[0].emails[0]}"
                    }
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        # Second step should execute since condition is met
        assert len(result["steps_completed"]) == 2
    
    @pytest.mark.asyncio
    async def test_parallel_workflow_execution(self, orchestrator, mock_data_generator):
        """Test parallel workflow execution."""
        mock_person = mock_data_generator.create_person()
        mock_business = mock_data_generator.create_business()
        
        orchestrator.api_client.search_person.return_value = [mock_person]
        orchestrator.api_client.search_business.return_value = [mock_business]
        orchestrator.api_client.search_email.return_value = []
        
        workflow = {
            "name": "parallel_search",
            "parallel": True,
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                },
                {
                    "agent": "business_search",
                    "action": "search",
                    "params": {"name": "Tech Corp"}
                },
                {
                    "agent": "email_search",
                    "action": "search",
                    "params": {"email": "john@example.com"}
                }
            ]
        }
        
        import time
        start = time.time()
        result = await orchestrator.execute_workflow(workflow)
        duration = time.time() - start
        
        assert result["status"] == "completed"
        assert len(result["steps_completed"]) == 3
        # Parallel execution should be faster than sequential
        assert duration < 1.0  # Assuming each step would take ~0.5s sequentially
    
    @pytest.mark.asyncio
    async def test_workflow_with_data_enrichment(self, orchestrator, mock_data_generator):
        """Test workflow with data enrichment step."""
        mock_person = mock_data_generator.create_person()
        enriched_data = {
            "social_media": {"linkedin": "linkedin.com/in/johndoe"},
            "additional_phones": ["(555) 987-6543"]
        }
        
        orchestrator.api_client.search_person.return_value = [mock_person]
        orchestrator.api_client.enrich_person = AsyncMock(return_value=enriched_data)
        
        workflow = {
            "name": "search_and_enrich",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                },
                {
                    "agent": "data_enrichment",
                    "action": "enrich",
                    "params": {
                        "data": "${steps[0].results[0]}"
                    }
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        assert result["steps_completed"][1]["enriched_data"] == enriched_data
    
    @pytest.mark.asyncio
    async def test_workflow_error_handling(self, orchestrator):
        """Test workflow error handling."""
        orchestrator.api_client.search_person.side_effect = Exception("API Error")
        
        workflow = {
            "name": "error_workflow",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "failed"
        assert "error" in result
        assert "API Error" in result["error"]
    
    @pytest.mark.asyncio
    async def test_workflow_retry_logic(self, orchestrator, mock_data_generator):
        """Test workflow retry logic on failure."""
        mock_person = mock_data_generator.create_person()
        
        # Fail twice, then succeed
        orchestrator.api_client.search_person.side_effect = [
            Exception("Temporary Error"),
            Exception("Temporary Error"),
            [mock_person]
        ]
        
        workflow = {
            "name": "retry_workflow",
            "retry_on_failure": True,
            "max_retries": 3,
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        assert result["retry_count"] == 2
    
    @pytest.mark.asyncio
    async def test_workflow_timeout(self, orchestrator):
        """Test workflow timeout handling."""
        async def slow_search(*args, **kwargs):
            await asyncio.sleep(10)
            return []
        
        orchestrator.api_client.search_person = slow_search
        
        workflow = {
            "name": "timeout_workflow",
            "timeout": 1,  # 1 second timeout
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "timeout"
        assert "error" in result
    
    @pytest.mark.asyncio
    async def test_workflow_caching(self, orchestrator, mock_data_generator, mock_redis_client):
        """Test workflow result caching."""
        mock_person = mock_data_generator.create_person()
        orchestrator.api_client.search_person.return_value = [mock_person]
        
        workflow = {
            "name": "cached_workflow",
            "cache_results": True,
            "cache_ttl": 300,
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                }
            ]
        }
        
        # First execution
        result1 = await orchestrator.execute_workflow(workflow)
        
        # Second execution should use cache
        result2 = await orchestrator.execute_workflow(workflow)
        
        assert result1 == result2
        assert orchestrator.api_client.search_person.call_count == 1
        mock_redis_client.set.assert_called()
    
    @pytest.mark.asyncio
    async def test_workflow_validation(self, orchestrator):
        """Test workflow validation."""
        invalid_workflow = {
            "name": "invalid_workflow",
            "steps": [
                {
                    "agent": "nonexistent_agent",
                    "action": "search"
                }
            ]
        }
        
        with pytest.raises(ValueError) as exc_info:
            await orchestrator.execute_workflow(invalid_workflow)
        
        assert "Invalid agent" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_workflow_with_loops(self, orchestrator, mock_data_generator):
        """Test workflow with loop constructs."""
        people = mock_data_generator.create_bulk_persons(3)
        orchestrator.api_client.search_person.return_value = people
        
        workflow = {
            "name": "loop_workflow",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"last_name": "Smith"}
                },
                {
                    "agent": "data_enrichment",
                    "action": "enrich",
                    "loop": "for person in steps[0].results",
                    "params": {
                        "data": "${person}"
                    }
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "completed"
        # Should have enriched all 3 people
        assert len(result["steps_completed"][1]["results"]) == 3


class TestOrchestratorResilience:
    """Test orchestrator resilience and recovery."""
    
    @pytest.mark.asyncio
    async def test_agent_failure_recovery(self, orchestrator):
        """Test recovery from agent failure."""
        # Simulate agent failure
        orchestrator.agents["person_search"].is_available = AsyncMock(return_value=False)
        
        workflow = {
            "name": "recovery_workflow",
            "fallback_agent": "backup_person_search",
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        # Should use fallback agent
        assert result["used_fallback"] == True
    
    @pytest.mark.asyncio
    async def test_partial_workflow_completion(self, orchestrator, mock_data_generator):
        """Test partial workflow completion on failure."""
        mock_person = mock_data_generator.create_person()
        orchestrator.api_client.search_person.return_value = [mock_person]
        orchestrator.api_client.search_business.side_effect = Exception("Business API Error")
        
        workflow = {
            "name": "partial_completion",
            "allow_partial": True,
            "steps": [
                {
                    "agent": "person_search",
                    "action": "search",
                    "params": {"first_name": "John", "last_name": "Doe"}
                },
                {
                    "agent": "business_search",
                    "action": "search",
                    "params": {"name": "Tech Corp"}
                }
            ]
        }
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "partial"
        assert len(result["steps_completed"]) == 1
        assert len(result["steps_failed"]) == 1
    
    @pytest.mark.asyncio
    async def test_workflow_rollback(self, orchestrator):
        """Test workflow rollback on critical failure."""
        workflow = {
            "name": "rollback_workflow",
            "transactional": True,
            "steps": [
                {
                    "agent": "person_search",
                    "action": "create",
                    "params": {"data": {"name": "John Doe"}}
                },
                {
                    "agent": "business_search",
                    "action": "create",
                    "params": {"data": {"name": "Tech Corp"}},
                    "critical": True
                }
            ]
        }
        
        # Make second step fail
        orchestrator.api_client.create_business = AsyncMock(side_effect=Exception("Critical Error"))
        
        result = await orchestrator.execute_workflow(workflow)
        
        assert result["status"] == "rolled_back"
        assert result["rollback_successful"] == True