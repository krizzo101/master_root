"""Comprehensive system integration tests for Sleuth Intel."""

import asyncio
import json
import time
from datetime import datetime
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

from src.orchestrator import InvestigationOrchestrator
from src.agents import (
    PersonSearchAgent,
    BusinessSearchAgent,
    EmailSearchAgent,
    PhoneSearchAgent,
    AddressSearchAgent,
    DataEnrichmentAgent,
    AnalysisAgent
)
from src.models import Query, IntelligenceReport
from src.providers import EnhancedEnformionClient
from src.utils.cache import CacheManager
from src.utils.rate_limiter import RateLimiter


class TestFullSystemIntegration:
    """Test complete system workflows with all components."""

    @pytest_asyncio.fixture
    async def orchestrator(self, test_config):
        """Create a real orchestrator instance."""
        orchestrator = InvestigationOrchestrator(config=test_config)
        await orchestrator.initialize()
        yield orchestrator
        await orchestrator.cleanup()

    @pytest_asyncio.fixture
    async def all_agents(self, test_config):
        """Initialize all agent instances."""
        agents = {
            'person': PersonSearchAgent(config=test_config),
            'business': BusinessSearchAgent(config=test_config),
            'email': EmailSearchAgent(config=test_config),
            'phone': PhoneSearchAgent(config=test_config),
            'address': AddressSearchAgent(config=test_config),
            'enrichment': DataEnrichmentAgent(config=test_config),
            'analysis': AnalysisAgent(config=test_config)
        }
        
        for agent in agents.values():
            await agent.initialize()
        
        yield agents
        
        for agent in agents.values():
            await agent.cleanup()

    @pytest.mark.asyncio
    async def test_complete_person_investigation(self, orchestrator, all_agents):
        """Test complete person investigation workflow."""
        query = Query(
            query_type="person_investigation",
            parameters={
                "first_name": "John",
                "last_name": "Smith",
                "city": "New York",
                "state": "NY",
                "phone": "555-0123",
                "email": "john.smith@example.com"
            },
            metadata={
                "request_id": "test-person-001",
                "priority": "high"
            }
        )
        
        # Execute investigation
        result = await orchestrator.investigate(query, agents=all_agents)
        
        # Validate result structure
        assert result is not None
        assert isinstance(result, IntelligenceReport)
        assert result.subject == "John Smith"
        assert len(result.findings) > 0
        assert result.risk_assessment is not None
        assert result.confidence_score >= 0.0
        assert result.confidence_score <= 1.0

    @pytest.mark.asyncio
    async def test_complete_business_investigation(self, orchestrator, all_agents):
        """Test complete business investigation workflow."""
        query = Query(
            query_type="business_investigation",
            parameters={
                "business_name": "Tech Solutions Inc",
                "city": "San Francisco",
                "state": "CA",
                "industry": "Technology"
            },
            metadata={
                "request_id": "test-business-001",
                "priority": "medium"
            }
        )
        
        result = await orchestrator.investigate(query, agents=all_agents)
        
        assert result is not None
        assert isinstance(result, IntelligenceReport)
        assert "Tech Solutions" in result.subject
        assert len(result.findings) > 0

    @pytest.mark.asyncio
    async def test_agent_collaboration(self, all_agents):
        """Test agents working together on shared data."""
        # Initial search with person agent
        person_result = await all_agents['person'].execute({
            "first_name": "Jane",
            "last_name": "Doe",
            "city": "Los Angeles"
        })
        
        # Enrich data with enrichment agent
        enriched_result = await all_agents['enrichment'].execute({
            "data": person_result,
            "enrichment_types": ["social_media", "professional", "public_records"]
        })
        
        # Analyze with analysis agent
        analysis_result = await all_agents['analysis'].execute({
            "data": enriched_result,
            "analysis_types": ["risk_assessment", "pattern_detection", "relationship_mapping"]
        })
        
        # Validate data flow
        assert person_result is not None
        assert enriched_result is not None
        assert analysis_result is not None
        assert len(analysis_result.get('patterns', [])) >= 0
        assert 'risk_score' in analysis_result

    @pytest.mark.asyncio
    async def test_error_recovery(self, orchestrator):
        """Test system recovery from errors."""
        # Test with invalid query
        invalid_query = Query(
            query_type="invalid_type",
            parameters={},
            metadata={}
        )
        
        with pytest.raises(ValueError):
            await orchestrator.investigate(invalid_query)
        
        # Test recovery - system should still work
        valid_query = Query(
            query_type="person_search",
            parameters={"first_name": "Test", "last_name": "User"},
            metadata={}
        )
        
        result = await orchestrator.investigate(valid_query)
        assert result is not None

    @pytest.mark.asyncio
    async def test_concurrent_investigations(self, orchestrator):
        """Test multiple concurrent investigations."""
        queries = [
            Query(
                query_type="person_search",
                parameters={
                    "first_name": f"User{i}",
                    "last_name": "Test",
                    "city": "Boston"
                },
                metadata={"request_id": f"concurrent-{i}"}
            )
            for i in range(5)
        ]
        
        # Execute all investigations concurrently
        tasks = [orchestrator.investigate(q) for q in queries]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Validate all completed
        successful_results = [r for r in results if not isinstance(r, Exception)]
        assert len(successful_results) >= 3  # At least 60% should succeed

    @pytest.mark.asyncio
    async def test_data_consistency(self, all_agents):
        """Test data consistency across agent operations."""
        test_data = {
            "person": {
                "first_name": "Alice",
                "last_name": "Johnson",
                "age": 30,
                "city": "Seattle"
            }
        }
        
        # Process through multiple agents
        results = {}
        for agent_name, agent in all_agents.items():
            if agent_name not in ['analysis', 'enrichment']:
                try:
                    result = await agent.execute(test_data['person'])
                    results[agent_name] = result
                except:
                    pass
        
        # Verify data consistency
        for agent_name, result in results.items():
            if result and 'person' in result:
                assert result['person'].get('first_name') == "Alice"
                assert result['person'].get('last_name') == "Johnson"

    @pytest.mark.asyncio 
    async def test_cache_effectiveness(self, orchestrator, performance_timer):
        """Test caching improves performance."""
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "Cache",
                "last_name": "Test",
                "city": "Chicago"
            },
            metadata={"cache_enabled": True}
        )
        
        # First request (cache miss)
        with performance_timer() as timer1:
            result1 = await orchestrator.investigate(query)
        time1 = timer1.elapsed
        
        # Second request (cache hit)
        with performance_timer() as timer2:
            result2 = await orchestrator.investigate(query)
        time2 = timer2.elapsed
        
        # Cache should make second request faster
        assert time2 < time1 * 0.5  # At least 50% faster
        assert result1 == result2  # Results should be identical

    @pytest.mark.asyncio
    async def test_rate_limit_compliance(self, all_agents):
        """Test rate limiting works correctly."""
        # Rapid fire requests
        tasks = []
        for i in range(20):
            tasks.append(
                all_agents['person'].execute({
                    "first_name": f"RateTest{i}",
                    "last_name": "User"
                })
            )
        
        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        elapsed_time = time.time() - start_time
        
        # Should take time due to rate limiting
        assert elapsed_time > 1.0  # Rate limiting should slow down requests
        
        # Check for rate limit errors
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) < len(results)  # Some should succeed

    @pytest.mark.asyncio
    async def test_message_bus_communication(self, orchestrator):
        """Test message bus facilitates agent communication."""
        messages_received = []
        
        async def message_handler(message):
            messages_received.append(message)
        
        # Subscribe to test channel
        await orchestrator.message_bus.subscribe("test_channel", message_handler)
        
        # Publish test messages
        for i in range(5):
            await orchestrator.message_bus.publish("test_channel", {
                "id": i,
                "data": f"test_message_{i}"
            })
        
        # Allow time for message processing
        await asyncio.sleep(0.1)
        
        assert len(messages_received) == 5
        assert all(msg['data'].startswith('test_message_') for msg in messages_received)

    @pytest.mark.asyncio
    async def test_transaction_rollback(self, orchestrator):
        """Test transaction rollback on failure."""
        # Start a complex investigation
        query = Query(
            query_type="comprehensive_investigation",
            parameters={
                "targets": ["person1", "person2", "person3"],
                "fail_on": "person2"  # Simulate failure
            },
            metadata={"transaction_id": "test-rollback-001"}
        )
        
        with patch.object(orchestrator, 'investigate') as mock_investigate:
            mock_investigate.side_effect = Exception("Simulated failure")
            
            try:
                await orchestrator.investigate(query)
            except Exception:
                pass
            
            # Verify no partial data was saved
            cache_key = f"investigation_{query.metadata['transaction_id']}"
            cached_data = await orchestrator.cache.get(cache_key)
            assert cached_data is None

    @pytest.mark.asyncio
    async def test_graceful_degradation(self, all_agents):
        """Test system degrades gracefully when services fail."""
        # Simulate API failure
        with patch.object(all_agents['person'], 'api_client') as mock_api:
            mock_api.search.side_effect = ConnectionError("API unavailable")
            
            result = await all_agents['person'].execute({
                "first_name": "Fallback",
                "last_name": "Test"
            })
            
            # Should return partial/cached results or error gracefully
            assert result is not None
            assert 'error' in result or 'fallback' in result


class TestPerformanceValidation:
    """Performance testing and benchmarking."""

    @pytest_asyncio.fixture
    async def load_generator(self):
        """Create load generator for performance testing."""
        class LoadGenerator:
            async def generate_load(self, orchestrator, num_requests, duration):
                """Generate load on the system."""
                results = {
                    'successful': 0,
                    'failed': 0,
                    'response_times': [],
                    'throughput': 0
                }
                
                start_time = time.time()
                tasks = []
                
                for i in range(num_requests):
                    query = Query(
                        query_type="person_search",
                        parameters={
                            "first_name": f"Load{i}",
                            "last_name": "Test"
                        },
                        metadata={"load_test": True}
                    )
                    tasks.append(self._timed_request(orchestrator, query))
                
                responses = await asyncio.gather(*tasks, return_exceptions=True)
                
                for response in responses:
                    if isinstance(response, Exception):
                        results['failed'] += 1
                    else:
                        results['successful'] += 1
                        if isinstance(response, tuple):
                            results['response_times'].append(response[1])
                
                elapsed = time.time() - start_time
                results['throughput'] = num_requests / elapsed
                
                return results
            
            async def _timed_request(self, orchestrator, query):
                start = time.time()
                try:
                    result = await orchestrator.investigate(query)
                    elapsed = time.time() - start
                    return (result, elapsed)
                except Exception as e:
                    return e
        
        return LoadGenerator()

    @pytest.mark.asyncio
    async def test_load_handling(self, orchestrator, load_generator):
        """Test system under load."""
        results = await load_generator.generate_load(
            orchestrator,
            num_requests=50,
            duration=10
        )
        
        # Performance assertions
        assert results['successful'] > results['failed']
        assert results['throughput'] > 1.0  # At least 1 request per second
        
        # Response time analysis
        if results['response_times']:
            avg_response_time = sum(results['response_times']) / len(results['response_times'])
            assert avg_response_time < 5.0  # Average under 5 seconds

    @pytest.mark.asyncio
    async def test_memory_usage(self, orchestrator, load_generator):
        """Test for memory leaks."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Run load test
        await load_generator.generate_load(
            orchestrator,
            num_requests=100,
            duration=20
        )
        
        # Force garbage collection
        import gc
        gc.collect()
        await asyncio.sleep(1)
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        # Memory should not increase excessively
        assert memory_increase < 100  # Less than 100MB increase

    @pytest.mark.asyncio
    async def test_response_time_percentiles(self, orchestrator, load_generator):
        """Test response time percentiles."""
        results = await load_generator.generate_load(
            orchestrator,
            num_requests=100,
            duration=30
        )
        
        response_times = sorted(results['response_times'])
        if len(response_times) > 0:
            p50 = response_times[int(len(response_times) * 0.5)]
            p95 = response_times[int(len(response_times) * 0.95)]
            p99 = response_times[int(len(response_times) * 0.99)]
            
            # Performance SLA assertions
            assert p50 < 2.0  # 50th percentile under 2 seconds
            assert p95 < 5.0  # 95th percentile under 5 seconds
            assert p99 < 10.0  # 99th percentile under 10 seconds


class TestSecurityValidation:
    """Security testing and validation."""

    @pytest.mark.asyncio
    async def test_credential_security(self, orchestrator):
        """Test credentials are properly secured."""
        # Check environment variables are not exposed
        config = orchestrator.config
        
        # Credentials should be masked or encrypted
        assert 'api_key' not in str(config).lower()
        assert 'password' not in str(config).lower()
        assert 'secret' not in str(config).lower()

    @pytest.mark.asyncio
    async def test_sql_injection_prevention(self, all_agents):
        """Test SQL injection prevention."""
        malicious_inputs = [
            "'; DROP TABLE users; --",
            "1' OR '1'='1",
            "admin'--",
            "<script>alert('XSS')</script>"
        ]
        
        for agent in all_agents.values():
            for malicious_input in malicious_inputs:
                try:
                    result = await agent.execute({
                        "search": malicious_input
                    })
                    # Should either sanitize or reject
                    if result:
                        assert malicious_input not in str(result)
                except ValueError:
                    # Rejecting malicious input is acceptable
                    pass

    @pytest.mark.asyncio
    async def test_rate_limiting_security(self, orchestrator):
        """Test rate limiting prevents abuse."""
        # Attempt rapid requests from same source
        queries = [
            Query(
                query_type="person_search",
                parameters={"first_name": f"Abuse{i}", "last_name": "Test"},
                metadata={"source_ip": "192.168.1.100"}
            )
            for i in range(100)
        ]
        
        results = await asyncio.gather(
            *[orchestrator.investigate(q) for q in queries],
            return_exceptions=True
        )
        
        # Should have rate limit errors
        rate_limit_errors = [
            r for r in results 
            if isinstance(r, Exception) and 'rate limit' in str(r).lower()
        ]
        assert len(rate_limit_errors) > 0

    @pytest.mark.asyncio
    async def test_data_encryption(self, orchestrator):
        """Test sensitive data is encrypted."""
        sensitive_data = {
            "ssn": "123-45-6789",
            "credit_card": "4111111111111111",
            "password": "secret123"
        }
        
        # Store sensitive data
        await orchestrator.cache.set("sensitive_test", sensitive_data)
        
        # Retrieve and verify encryption
        stored_data = await orchestrator.cache.get_raw("sensitive_test")
        
        # Raw data should not contain plaintext sensitive info
        assert "123-45-6789" not in str(stored_data)
        assert "4111111111111111" not in str(stored_data)
        assert "secret123" not in str(stored_data)

    @pytest.mark.asyncio
    async def test_access_control(self, orchestrator):
        """Test access control mechanisms."""
        # Test unauthorized access attempt
        unauthorized_query = Query(
            query_type="admin_operation",
            parameters={"action": "delete_all"},
            metadata={"auth_token": "invalid"}
        )
        
        with pytest.raises((ValueError, PermissionError)):
            await orchestrator.investigate(unauthorized_query)

    @pytest.mark.asyncio
    async def test_audit_logging(self, orchestrator, temp_directory):
        """Test audit trail is maintained."""
        # Perform operations
        query = Query(
            query_type="person_search",
            parameters={"first_name": "Audit", "last_name": "Test"},
            metadata={"user_id": "test_user", "action": "search"}
        )
        
        await orchestrator.investigate(query)
        
        # Check audit log exists
        audit_log = temp_directory / "audit.log"
        if audit_log.exists():
            content = audit_log.read_text()
            assert "test_user" in content
            assert "person_search" in content
            assert "Audit Test" in content

    @pytest.mark.asyncio
    async def test_input_validation(self, all_agents):
        """Test input validation and sanitization."""
        invalid_inputs = [
            {"first_name": "A" * 1000},  # Too long
            {"email": "not-an-email"},  # Invalid format
            {"phone": "invalid-phone"},  # Invalid format
            {"age": -5},  # Invalid value
            {"state": "XYZ"},  # Invalid state code
        ]
        
        for agent in all_agents.values():
            for invalid_input in invalid_inputs:
                try:
                    result = await agent.execute(invalid_input)
                    # If accepted, should be sanitized
                    assert result is not None
                except (ValueError, ValidationError):
                    # Rejecting invalid input is correct
                    pass


class TestRealWorldScenarios:
    """Test with real-world data and scenarios."""

    @pytest.mark.asyncio
    async def test_real_phone_lookup(self, orchestrator):
        """Test with actual phone number lookup."""
        query = Query(
            query_type="phone_search",
            parameters={
                "phone": "555-123-4567",  # Test number
                "include_carrier": True,
                "include_owner": True
            },
            metadata={"real_world_test": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        assert result.findings is not None
        
        # Verify expected data structure
        phone_data = result.findings.get('phone_data', {})
        assert 'formatted' in phone_data or 'number' in phone_data

    @pytest.mark.asyncio
    async def test_business_enrichment(self, orchestrator):
        """Test business data enrichment."""
        query = Query(
            query_type="business_investigation",
            parameters={
                "business_name": "Apple Inc",
                "city": "Cupertino",
                "state": "CA",
                "enrich": True
            },
            metadata={"enrichment_test": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        assert len(result.findings) > 0
        
        # Should have enriched data
        business_data = result.findings.get('business', {})
        assert any(key in business_data for key in [
            'industry', 'employees', 'revenue', 'website', 'founded'
        ])

    @pytest.mark.asyncio
    async def test_person_relationship_mapping(self, orchestrator):
        """Test relationship discovery and mapping."""
        query = Query(
            query_type="person_investigation",
            parameters={
                "first_name": "John",
                "last_name": "Smith",
                "city": "New York",
                "discover_relationships": True
            },
            metadata={"relationship_mapping": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        
        # Check for relationship data
        relationships = result.findings.get('relationships', [])
        assert isinstance(relationships, list)

    @pytest.mark.asyncio
    async def test_email_validation_accuracy(self, orchestrator):
        """Test email validation accuracy."""
        test_emails = [
            ("valid@example.com", True),
            ("invalid@", False),
            ("user@domain.co.uk", True),
            ("test..email@example.com", False),
            ("user+tag@example.com", True)
        ]
        
        for email, expected_valid in test_emails:
            query = Query(
                query_type="email_validation",
                parameters={"email": email},
                metadata={"validation_test": True}
            )
            
            result = await orchestrator.investigate(query)
            
            if expected_valid:
                assert result.confidence_score > 0.5
            else:
                assert result.confidence_score < 0.5

    @pytest.mark.asyncio
    async def test_address_geocoding(self, orchestrator):
        """Test address geocoding and validation."""
        query = Query(
            query_type="address_search",
            parameters={
                "street": "1600 Pennsylvania Avenue NW",
                "city": "Washington",
                "state": "DC",
                "zip": "20500",
                "geocode": True
            },
            metadata={"geocoding_test": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        
        # Should have geocoding data
        location_data = result.findings.get('location', {})
        assert 'latitude' in location_data or 'lat' in location_data
        assert 'longitude' in location_data or 'lng' in location_data

    @pytest.mark.asyncio
    async def test_cost_optimization(self, orchestrator):
        """Test cost optimization features."""
        # Enable cost optimization
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "Cost",
                "last_name": "Test",
                "optimize_cost": True,
                "max_cost": 10.0  # Maximum $10
            },
            metadata={"cost_tracking": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        
        # Check cost tracking
        cost_data = result.metadata.get('cost', {})
        if cost_data:
            assert cost_data.get('total', 0) <= 10.0
            assert 'breakdown' in cost_data

    @pytest.mark.asyncio
    async def test_compliance_requirements(self, orchestrator):
        """Test compliance with data protection requirements."""
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "Jane",
                "last_name": "Doe",
                "compliance_mode": "GDPR"
            },
            metadata={"compliance_test": True}
        )
        
        result = await orchestrator.investigate(query)
        
        assert result is not None
        
        # Check compliance metadata
        compliance_data = result.metadata.get('compliance', {})
        if compliance_data:
            assert 'gdpr_compliant' in compliance_data
            assert 'data_retention' in compliance_data
            assert 'consent_status' in compliance_data