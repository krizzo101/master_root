"""Test helper utilities."""

import asyncio
import json
import os
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import aiohttp
import pytest


class TestAPIClient:
    """Test API client for mocking external API calls."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the test API client."""
        self.config = config
        self.responses = {}
        self.call_history = []
    
    def set_response(self, endpoint: str, response: Any, status: int = 200):
        """Set a mock response for an endpoint."""
        self.responses[endpoint] = {
            "data": response,
            "status": status
        }
    
    async def make_request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """Make a mock API request."""
        self.call_history.append({
            "method": method,
            "endpoint": endpoint,
            "params": kwargs,
            "timestamp": datetime.now().isoformat()
        })
        
        if endpoint in self.responses:
            response = self.responses[endpoint]
            if response["status"] >= 400:
                raise aiohttp.ClientError(f"API Error: {response['status']}")
            return response["data"]
        
        return {"status": "success", "data": []}
    
    def get_call_history(self) -> List[Dict]:
        """Get the call history."""
        return self.call_history
    
    def clear_history(self):
        """Clear the call history."""
        self.call_history = []


def create_test_config() -> Dict[str, Any]:
    """Create a test configuration."""
    return {
        "api": {
            "base_url": "http://test.api.local",
            "timeout": 30,
            "retry_attempts": 3,
            "api_key": "test_api_key"
        },
        "redis": {
            "host": "localhost",
            "port": 6379,
            "db": 1,
            "password": None
        },
        "message_bus": {
            "broker_url": "memory://",
            "result_backend": "cache+memory://"
        },
        "agents": {
            "max_concurrent": 5,
            "timeout": 60,
            "retry_on_failure": True
        },
        "security": {
            "encryption_key": "test_encryption_key_32_bytes_long",
            "jwt_secret": "test_jwt_secret",
            "enable_audit_log": True
        },
        "performance": {
            "cache_ttl": 300,
            "max_cache_size": 1000,
            "enable_profiling": True
        }
    }


@contextmanager
def mock_env_vars(**kwargs):
    """Context manager to temporarily set environment variables."""
    original = os.environ.copy()
    os.environ.update(kwargs)
    try:
        yield
    finally:
        os.environ.clear()
        os.environ.update(original)


@asynccontextmanager
async def async_timeout(seconds: float):
    """Async context manager for timeouts."""
    async def timeout_handler():
        await asyncio.sleep(seconds)
        raise TimeoutError(f"Operation timed out after {seconds} seconds")
    
    task = asyncio.create_task(timeout_handler())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


class MockCache:
    """Mock cache implementation for testing."""
    
    def __init__(self):
        """Initialize the mock cache."""
        self.data = {}
        self.hits = 0
        self.misses = 0
    
    async def get(self, key: str) -> Optional[Any]:
        """Get a value from the cache."""
        if key in self.data:
            self.hits += 1
            return self.data[key]
        self.misses += 1
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set a value in the cache."""
        self.data[key] = value
        return True
    
    async def delete(self, key: str) -> bool:
        """Delete a value from the cache."""
        if key in self.data:
            del self.data[key]
            return True
        return False
    
    async def clear(self):
        """Clear the cache."""
        self.data.clear()
        self.hits = 0
        self.misses = 0
    
    def get_stats(self) -> Dict[str, int]:
        """Get cache statistics."""
        return {
            "hits": self.hits,
            "misses": self.misses,
            "size": len(self.data),
            "hit_rate": self.hits / (self.hits + self.misses) if (self.hits + self.misses) > 0 else 0
        }


class AsyncIteratorMock:
    """Mock async iterator for testing."""
    
    def __init__(self, items: List[Any]):
        """Initialize the mock iterator."""
        self.items = items
        self.index = 0
    
    def __aiter__(self):
        """Return self as async iterator."""
        return self
    
    async def __anext__(self):
        """Get next item."""
        if self.index >= len(self.items):
            raise StopAsyncIteration
        item = self.items[self.index]
        self.index += 1
        return item


def assert_api_called(client: TestAPIClient, endpoint: str, times: int = 1):
    """Assert that an API endpoint was called a specific number of times."""
    calls = [c for c in client.call_history if c["endpoint"] == endpoint]
    assert len(calls) == times, f"Expected {endpoint} to be called {times} times, but was called {len(calls)} times"


def assert_cache_hit(cache: MockCache, expected_hits: int):
    """Assert cache hit count."""
    assert cache.hits == expected_hits, f"Expected {expected_hits} cache hits, got {cache.hits}"


def create_mock_agent(name: str = "test_agent", capabilities: Optional[List[str]] = None):
    """Create a mock agent for testing."""
    agent = MagicMock()
    agent.name = name
    agent.capabilities = capabilities or ["search", "analyze"]
    agent.execute = AsyncMock(return_value={"status": "success", "data": []})
    agent.validate = AsyncMock(return_value=True)
    agent.is_available = AsyncMock(return_value=True)
    return agent


def create_mock_orchestrator():
    """Create a mock orchestrator for testing."""
    orchestrator = MagicMock()
    orchestrator.agents = {}
    orchestrator.execute_workflow = AsyncMock(return_value={"status": "completed"})
    orchestrator.register_agent = MagicMock()
    orchestrator.unregister_agent = MagicMock()
    orchestrator.get_agent = MagicMock()
    return orchestrator


async def wait_for_condition(condition_func, timeout: float = 5.0, interval: float = 0.1):
    """Wait for a condition to become true."""
    start_time = asyncio.get_event_loop().time()
    while asyncio.get_event_loop().time() - start_time < timeout:
        if await condition_func():
            return True
        await asyncio.sleep(interval)
    return False


def load_test_data(filename: str) -> Any:
    """Load test data from a JSON file."""
    test_data_dir = Path(__file__).parent.parent / "fixtures" / "data"
    file_path = test_data_dir / filename
    
    if not file_path.exists():
        raise FileNotFoundError(f"Test data file not found: {file_path}")
    
    with open(file_path, 'r') as f:
        return json.load(f)


def save_test_results(results: Any, filename: str):
    """Save test results to a file."""
    results_dir = Path(__file__).parent.parent / "results"
    results_dir.mkdir(exist_ok=True)
    
    file_path = results_dir / filename
    with open(file_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)


class PerformanceProfiler:
    """Performance profiler for tests."""
    
    def __init__(self):
        """Initialize the profiler."""
        self.measurements = []
    
    def start(self, name: str):
        """Start a measurement."""
        import time
        return {
            "name": name,
            "start": time.perf_counter()
        }
    
    def stop(self, measurement: Dict):
        """Stop a measurement."""
        import time
        measurement["end"] = time.perf_counter()
        measurement["duration"] = measurement["end"] - measurement["start"]
        self.measurements.append(measurement)
        return measurement["duration"]
    
    def get_report(self) -> Dict:
        """Get performance report."""
        if not self.measurements:
            return {}
        
        total_time = sum(m["duration"] for m in self.measurements)
        return {
            "total_time": total_time,
            "measurements": self.measurements,
            "average_time": total_time / len(self.measurements),
            "slowest": max(self.measurements, key=lambda x: x["duration"]),
            "fastest": min(self.measurements, key=lambda x: x["duration"])
        }