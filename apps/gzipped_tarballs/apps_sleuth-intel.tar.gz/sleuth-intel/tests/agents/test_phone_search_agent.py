"""
Comprehensive tests for PhoneSearchAgent
Tests phone lookup, validation, fraud assessment, and integration features
"""

import pytest
import json
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

from src.agents.phone_search_agent import (
    PhoneSearchAgent, PhoneLookupResult, PhoneMetadata, PhoneCarrierInfo,
    FraudRiskAssessment, RiskLevel, PhoneLineType, PhoneHistoryEntry
)
from src.models.person import PersonProfile, PersonName, Phone, PhoneType
from src.providers.enformion_client import EnformionAPIError
from src.core.secure_api_locker import APICredential


class TestPhoneSearchAgent:
    """Test suite for PhoneSearchAgent"""
    
    @pytest.fixture
    def mock_credential(self):
        """Mock API credential"""
        return APICredential(
            provider="enformion",
            key_name="test_key",
            key_value="test_api_key_123",
            password="test_password"
        )
    
    @pytest.fixture
    def mock_enformion_response(self):
        """Mock EnformionGO API response"""
        return {
            "phone": "5551234567",
            "carrier": "Verizon Wireless",
            "line_type": "wireless",
            "location": "New York, NY",
            "ported": False,
            "owner": {
                "first_name": "John",
                "last_name": "Doe",
                "address": "123 Main St, New York, NY 10001"
            },
            "confidence": 0.85
        }
    
    @pytest.fixture
    @patch('src.agents.phone_search_agent.EnformionClient')
    @patch('src.agents.base_agent.APILockerManager.get_instance')
    def phone_agent(self, mock_locker_manager, mock_enformion_client, mock_credential):
        """Create PhoneSearchAgent instance with mocked dependencies"""
        mock_locker = Mock()
        mock_locker.get_credential.return_value = mock_credential
        mock_locker_manager.return_value = mock_locker
        
        agent = PhoneSearchAgent(enable_person_enrichment=False)  # Disable for isolated testing
        return agent
    
    def test_phone_number_validation(self, phone_agent):
        """Test phone number validation"""
        # Valid phone numbers
        valid_phones = [
            "5551234567",
            "15551234567", 
            "(555) 123-4567",
            "555-123-4567",
            "+1 555 123 4567"
        ]
        
        for phone in valid_phones:
            assert phone_agent._validate_phone_number(phone), f"Should be valid: {phone}"
        
        # Invalid phone numbers
        invalid_phones = [
            "",
            "123",
            "555123456",  # Too short
            "555123456789",  # Too long
            "0551234567",  # Invalid area code (starts with 0)
            "1551234567",  # Invalid area code (starts with 1)  
            "5551134567",  # Invalid exchange (starts with 1)
            "911",
            "411",
            "000",
            "25551234567"  # 11 digits not starting with 1
        ]
        
        for phone in invalid_phones:
            assert not phone_agent._validate_phone_number(phone), f"Should be invalid: {phone}"
    
    def test_phone_number_cleaning(self, phone_agent):
        """Test phone number cleaning"""
        test_cases = [
            ("(555) 123-4567", "5551234567"),
            ("+1 555 123 4567", "15551234567"),
            ("555-123-4567", "5551234567"),
            ("555.123.4567", "5551234567"),
            ("555 123 4567", "5551234567"),
            ("1-555-123-4567", "15551234567")
        ]
        
        for input_phone, expected in test_cases:
            result = phone_agent._clean_phone_number(input_phone)
            assert result == expected, f"Clean {input_phone} should be {expected}, got {result}"
    
    def test_phone_number_formatting(self, phone_agent):
        """Test phone number formatting"""
        # Test national format
        assert phone_agent._format_phone_number("5551234567") == "(555) 123-4567"
        assert phone_agent._format_phone_number("15551234567") == "(555) 123-4567"
        
        # Test international format
        assert phone_agent._format_phone_number("5551234567", "international") == "+1 (555) 123-4567"
        assert phone_agent._format_phone_number("15551234567", "international") == "+1 (555) 123-4567"
    
    def test_phone_number_parsing(self, phone_agent):
        """Test phone number parsing into components"""
        metadata = phone_agent._parse_phone_number("5551234567")
        
        assert metadata.area_code == "555"
        assert metadata.exchange == "123"
        assert metadata.subscriber == "4567"
        assert metadata.country_code == "1"
        assert metadata.formatted_national == "(555) 123-4567"
        assert metadata.formatted_international == "+1 (555) 123-4567"
        assert metadata.is_valid == True
    
    def test_phone_type_classification(self, phone_agent):
        """Test phone type classification"""
        # Test toll-free numbers
        toll_free_codes = ['800', '833', '844', '855', '866', '877', '888']
        for code in toll_free_codes:
            phone_type = phone_agent._classify_phone_type(code, "123")
            assert phone_type == PhoneLineType.TOLL_FREE
        
        # Test regular numbers (should be unknown without carrier data)
        phone_type = phone_agent._classify_phone_type("555", "123")
        assert phone_type == PhoneLineType.UNKNOWN
    
    def test_geographic_description(self, phone_agent):
        """Test geographic description lookup"""
        # Test known area codes
        assert phone_agent._get_geographic_description("212") == "New York, NY"
        assert phone_agent._get_geographic_description("213") == "Los Angeles, CA"
        assert phone_agent._get_geographic_description("800") == "Toll Free"
        
        # Test unknown area code
        assert phone_agent._get_geographic_description("999") is None
    
    def test_carrier_info_extraction(self, phone_agent, mock_enformion_response):
        """Test carrier information extraction"""
        carrier_info = phone_agent._extract_carrier_info(mock_enformion_response)
        
        assert carrier_info.name == "Verizon Wireless"
        assert carrier_info.type == "wireless"
        assert carrier_info.location == "New York, NY"
        assert carrier_info.is_ported == False
        assert carrier_info.confidence > 0.0
    
    def test_fraud_risk_assessment(self, phone_agent):
        """Test fraud risk assessment"""
        # Test low-risk number
        carrier_info = PhoneCarrierInfo(name="Verizon", type="wireless")
        assessment = phone_agent._assess_fraud_risk("5551234567", carrier_info)
        
        assert assessment.overall_risk in [RiskLevel.LOW, RiskLevel.MEDIUM]
        assert assessment.spam_score >= 0.0
        assert assessment.reputation_score >= 0.0
        
        # Test high-risk patterns
        high_risk_assessment = phone_agent._assess_fraud_risk("8001234567", carrier_info)
        assert high_risk_assessment.spam_score > assessment.spam_score
        
        # Test VOIP risk
        voip_carrier = PhoneCarrierInfo(name="Google Voice", type="voip")
        voip_assessment = phone_agent._assess_fraud_risk("5551234567", voip_carrier)
        assert voip_assessment.spam_score > assessment.spam_score
    
    @patch('src.agents.phone_search_agent.EnformionClient')
    def test_reverse_phone_lookup_success(self, mock_client_class, phone_agent, mock_enformion_response):
        """Test successful reverse phone lookup"""
        # Setup mock
        mock_client = Mock()
        mock_client.reverse_phone_search.return_value = mock_enformion_response
        phone_agent.enformion_client = mock_client
        
        # Perform lookup
        result = phone_agent.reverse_phone_lookup("5551234567")
        
        # Verify result
        assert isinstance(result, PhoneLookupResult)
        assert result.phone_number == "5551234567"
        assert result.formatted_number == "(555) 123-4567"
        assert result.carrier_info.name == "Verizon Wireless"
        assert result.confidence_score > 0.0
        assert result.fraud_assessment is not None
        
        # Verify API was called
        mock_client.reverse_phone_search.assert_called_once_with("5551234567")
    
    @patch('src.agents.phone_search_agent.EnformionClient')
    def test_reverse_phone_lookup_invalid_phone(self, mock_client_class, phone_agent):
        """Test reverse phone lookup with invalid phone number"""
        with pytest.raises(ValueError, match="Invalid phone number"):
            phone_agent.reverse_phone_lookup("invalid")
    
    @patch('src.agents.phone_search_agent.EnformionClient')
    def test_reverse_phone_lookup_api_error(self, mock_client_class, phone_agent):
        """Test reverse phone lookup with API error"""
        # Setup mock to raise API error
        mock_client = Mock()
        mock_client.reverse_phone_search.side_effect = EnformionAPIError("API Error", 500)
        phone_agent.enformion_client = mock_client
        
        with pytest.raises(EnformionAPIError):
            phone_agent.reverse_phone_lookup("5551234567")
    
    def test_get_carrier_info(self, phone_agent):
        """Test carrier info extraction"""
        with patch.object(phone_agent, 'reverse_phone_lookup') as mock_lookup:
            mock_result = Mock()
            mock_result.carrier_info = PhoneCarrierInfo(name="Test Carrier")
            mock_lookup.return_value = mock_result
            
            carrier_info = phone_agent.get_carrier_info("5551234567")
            
            assert carrier_info.name == "Test Carrier"
            mock_lookup.assert_called_once_with("5551234567", include_owner_details=False, include_fraud_assessment=False)
    
    def test_get_line_type(self, phone_agent):
        """Test line type detection"""
        with patch.object(phone_agent, 'reverse_phone_lookup') as mock_lookup:
            mock_result = Mock()
            mock_result.metadata = Mock()
            mock_result.metadata.number_type = PhoneLineType.MOBILE
            mock_lookup.return_value = mock_result
            
            line_type = phone_agent.get_line_type("5551234567")
            
            assert line_type == PhoneLineType.MOBILE
    
    def test_assess_spam_risk(self, phone_agent):
        """Test spam risk assessment"""
        with patch.object(phone_agent, 'reverse_phone_lookup') as mock_lookup:
            mock_result = Mock()
            mock_result.fraud_assessment = FraudRiskAssessment(overall_risk=RiskLevel.LOW)
            mock_lookup.return_value = mock_result
            
            risk_assessment = phone_agent.assess_spam_risk("5551234567")
            
            assert risk_assessment.overall_risk == RiskLevel.LOW
    
    def test_batch_phone_lookup(self, phone_agent):
        """Test batch phone lookup"""
        phone_numbers = ["5551234567", "5557654321", "5559876543"]
        
        with patch.object(phone_agent, 'reverse_phone_lookup') as mock_lookup:
            mock_result = Mock()
            mock_lookup.return_value = mock_result
            
            results = phone_agent.batch_phone_lookup(phone_numbers)
            
            assert len(results) == 3
            assert mock_lookup.call_count == 3
    
    def test_validate_phone_format(self, phone_agent):
        """Test phone format validation with error messages"""
        # Valid phone
        is_valid, message = phone_agent.validate_phone_format("5551234567")
        assert is_valid == True
        assert message == "Phone number is valid"
        
        # Invalid phone - too short
        is_valid, message = phone_agent.validate_phone_format("555123")
        assert is_valid == False
        assert "too short" in message.lower()
        
        # Invalid phone - empty
        is_valid, message = phone_agent.validate_phone_format("")
        assert is_valid == False
        assert "empty" in message.lower()
        
        # Invalid phone - bad area code
        is_valid, message = phone_agent.validate_phone_format("0551234567")
        assert is_valid == False
        assert "area code" in message.lower()
    
    def test_normalize_phone_number(self, phone_agent):
        """Test phone number normalization"""
        # Test various formats normalize to same result
        formats = [
            "(555) 123-4567",
            "555-123-4567", 
            "555.123.4567",
            "5551234567",
            "1-555-123-4567"
        ]
        
        expected = "5551234567"
        for phone_format in formats:
            normalized = phone_agent.normalize_phone_number(phone_format)
            assert normalized == expected, f"Failed to normalize {phone_format}"
        
        # Test invalid phone raises error
        with pytest.raises(ValueError):
            phone_agent.normalize_phone_number("invalid")
    
    def test_query_interface(self, phone_agent):
        """Test BaseIntelligenceAgent query interface"""
        with patch.object(phone_agent, 'reverse_phone_lookup') as mock_lookup:
            mock_result = Mock()
            mock_lookup.return_value = mock_result
            
            result = phone_agent.query({"phone": "5551234567"})
            
            assert result == mock_result
            mock_lookup.assert_called_once_with("5551234567")
        
        # Test missing phone parameter
        with pytest.raises(ValueError, match="Query must include 'phone' parameter"):
            phone_agent.query({})
    
    def test_health_check(self, phone_agent):
        """Test agent health check"""
        health = phone_agent.health_check()
        
        assert "status" in health
        assert "phone_validation_ready" in health
        assert "person_enrichment_enabled" in health
        assert "fraud_detection_enabled" in health
        assert "fraud_threshold" in health
    
    def test_caching_functionality(self, phone_agent):
        """Test that results are cached properly"""
        with patch.object(phone_agent, 'enformion_client') as mock_client:
            mock_client.reverse_phone_search.return_value = {"phone": "5551234567", "carrier": "Test"}
            
            # First call should hit API
            result1 = phone_agent.reverse_phone_lookup("5551234567", use_cache=True)
            assert mock_client.reverse_phone_search.call_count == 1
            
            # Second call should use cache (mock won't be called again)
            result2 = phone_agent.reverse_phone_lookup("5551234567", use_cache=True)
            assert mock_client.reverse_phone_search.call_count == 1
            
            # Results should be similar (cache returns dict, so reconstructed object)
            assert result1.phone_number == result2.phone_number
    
    def test_find_related_numbers(self, phone_agent):
        """Test finding related phone numbers"""
        # Mock owner with multiple phone numbers
        mock_owner = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            phones=[
                Phone(number="5551234567", type=PhoneType.MOBILE),
                Phone(number="5557654321", type=PhoneType.LANDLINE),
                Phone(number="5559876543", type=PhoneType.VOIP)
            ]
        )
        
        with patch.object(phone_agent, 'identify_owner') as mock_identify:
            mock_identify.return_value = mock_owner
            
            related = phone_agent.find_related_numbers("5551234567")
            
            # Should return other numbers, not the queried one
            assert "5557654321" in related
            assert "5559876543" in related
            assert "5551234567" not in related
    
    def test_fraud_pattern_detection(self, phone_agent):
        """Test specific fraud pattern detection"""
        # Test toll-free spam pattern
        assessment = phone_agent._assess_fraud_risk("8005551234", PhoneCarrierInfo())
        assert len(assessment.fraud_indicators) > 0
        assert assessment.spam_score > 0.0
        
        # Test repeated digits pattern  
        assessment = phone_agent._assess_fraud_risk("1111111111", PhoneCarrierInfo())
        assert len(assessment.fraud_indicators) > 0
        
        # Test premium rate pattern
        assessment = phone_agent._assess_fraud_risk("9005551234", PhoneCarrierInfo())
        assert len(assessment.fraud_indicators) > 0


class TestPhoneDataModels:
    """Test phone-related data models"""
    
    def test_phone_metadata_creation(self):
        """Test PhoneMetadata creation"""
        metadata = PhoneMetadata(
            area_code="555",
            exchange="123", 
            subscriber="4567",
            country_code="1"
        )
        
        assert metadata.area_code == "555"
        assert metadata.exchange == "123"
        assert metadata.subscriber == "4567"
        assert metadata.is_valid == True
    
    def test_phone_carrier_info_creation(self):
        """Test PhoneCarrierInfo creation"""
        carrier_info = PhoneCarrierInfo(
            name="Verizon",
            type="wireless",
            location="New York, NY",
            is_ported=False
        )
        
        assert carrier_info.name == "Verizon"
        assert carrier_info.type == "wireless"
        assert carrier_info.is_ported == False
    
    def test_fraud_risk_assessment_creation(self):
        """Test FraudRiskAssessment creation"""
        assessment = FraudRiskAssessment(
            overall_risk=RiskLevel.MEDIUM,
            spam_score=0.5,
            fraud_indicators=["Test indicator"],
            reputation_score=0.7
        )
        
        assert assessment.overall_risk == RiskLevel.MEDIUM
        assert assessment.spam_score == 0.5
        assert "Test indicator" in assessment.fraud_indicators
        assert assessment.reputation_score == 0.7
    
    def test_phone_lookup_result_creation(self):
        """Test PhoneLookupResult creation"""
        metadata = PhoneMetadata(area_code="555", exchange="123", subscriber="4567")
        carrier_info = PhoneCarrierInfo(name="Test Carrier")
        
        result = PhoneLookupResult(
            phone_number="5551234567",
            formatted_number="(555) 123-4567",
            metadata=metadata,
            carrier_info=carrier_info,
            confidence_score=0.8
        )
        
        assert result.phone_number == "5551234567"
        assert result.formatted_number == "(555) 123-4567"
        assert result.confidence_score == 0.8
        assert isinstance(result.lookup_timestamp, datetime)


class TestPhoneSearchIntegration:
    """Integration tests for PhoneSearchAgent"""
    
    @pytest.fixture
    @patch('src.agents.phone_search_agent.EnformionClient')
    @patch('src.agents.base_agent.APILockerManager.get_instance')
    def integrated_agent(self, mock_locker_manager, mock_enformion_client):
        """Create agent with person enrichment enabled"""
        mock_locker = Mock()
        mock_locker.get_credential.return_value = APICredential(
            provider="enformion",
            key_name="test_key", 
            key_value="test_key_123",
            password="test_password"
        )
        mock_locker_manager.return_value = mock_locker
        
        # Mock PersonSearchAgent import
        with patch('src.agents.phone_search_agent.PersonSearchAgent') as mock_person_agent:
            mock_person_agent.return_value = Mock()
            agent = PhoneSearchAgent(enable_person_enrichment=True)
            return agent
    
    def test_person_enrichment_integration(self, integrated_agent):
        """Test integration with PersonSearchAgent"""
        # Mock enrich_with_person_data to return a person profile
        mock_person = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            phones=[Phone(number="5551234567", type=PhoneType.MOBILE)]
        )
        
        with patch.object(integrated_agent, '_enrich_with_person_data') as mock_enrich:
            with patch.object(integrated_agent.enformion_client, 'reverse_phone_search') as mock_api:
                mock_enrich.return_value = mock_person
                mock_api.return_value = {"phone": "5551234567", "carrier": "Test"}
                
                result = integrated_agent.reverse_phone_lookup("5551234567", include_owner_details=True)
                
                assert result.owner_info is not None
                assert result.owner_info.name.first == "John"
                mock_enrich.assert_called_once_with("5551234567")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])