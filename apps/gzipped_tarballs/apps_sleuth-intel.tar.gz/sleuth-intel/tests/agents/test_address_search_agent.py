"""
Comprehensive tests for AddressSearchAgent
Tests all address intelligence capabilities including validation, resident identification,
property analysis, demographics, and movement patterns.
"""

import pytest
import json
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
import requests
from requests import Response

from src.agents.address_search_agent import (
    AddressSearchAgent, 
    AddressValidationResult,
    ResidentProfile,
    PropertyOwnershipRecord,
    DemographicProfile,
    MovementPattern,
    AddressIntelligenceReport
)
from src.models.query import AddressLookupQuery
from src.models.person import PersonProfile, PersonName, Address, Phone
from src.providers.enformion_client import EnformionAPIError


class TestAddressValidationResult:
    """Test AddressValidationResult class"""
    
    def test_initialization(self):
        """Test AddressValidationResult initialization"""
        result = AddressValidationResult("123 Main St")
        assert result.input_address == "123 Main St"
        assert result.is_valid == False
        assert result.quality_score == 0.0
        assert result.validation_errors == []
        
    def test_to_dict(self):
        """Test AddressValidationResult to_dict method"""
        result = AddressValidationResult("123 Main St")
        result.is_valid = True
        result.quality_score = 0.85
        result.standardized_address = "123 Main Street, Anytown, NY 12345"
        
        result_dict = result.to_dict()
        assert result_dict["input_address"] == "123 Main St"
        assert result_dict["is_valid"] == True
        assert result_dict["quality_score"] == 0.85
        assert result_dict["standardized_address"] == "123 Main Street, Anytown, NY 12345"


class TestResidentProfile:
    """Test ResidentProfile class"""
    
    def test_initialization(self):
        """Test ResidentProfile initialization"""
        resident = ResidentProfile()
        assert resident.name is None
        assert resident.age is None
        assert resident.phone_numbers == []
        assert resident.confidence_score == 0.0
        
    def test_to_dict(self):
        """Test ResidentProfile to_dict method"""
        resident = ResidentProfile()
        resident.name = "John Doe"
        resident.age = 35
        resident.phone_numbers = ["5551234567"]
        resident.confidence_score = 0.8
        
        resident_dict = resident.to_dict()
        assert resident_dict["name"] == "John Doe"
        assert resident_dict["age"] == 35
        assert resident_dict["phone_numbers"] == ["5551234567"]
        assert resident_dict["confidence_score"] == 0.8


class TestAddressSearchAgent:
    """Test AddressSearchAgent functionality"""
    
    @pytest.fixture
    def mock_enformion_client(self):
        """Mock EnformionClient"""
        with patch('src.agents.address_search_agent.EnformionClient') as mock_client:
            mock_instance = Mock()
            mock_instance.base_url = "https://api.enformion.com/v1"
            mock_client.return_value = mock_instance
            yield mock_instance
    
    @pytest.fixture
    def mock_person_search_agent(self):
        """Mock PersonSearchAgent"""
        mock_agent = Mock()
        return mock_agent
    
    @pytest.fixture
    def address_agent(self, mock_enformion_client, mock_person_search_agent):
        """Create AddressSearchAgent with mocked dependencies"""
        with patch('src.agents.address_search_agent.APILockerManager'):
            agent = AddressSearchAgent(person_search_agent=mock_person_search_agent)
            return agent
    
    def test_initialization(self, mock_enformion_client):
        """Test AddressSearchAgent initialization"""
        with patch('src.agents.address_search_agent.APILockerManager'):
            agent = AddressSearchAgent()
            assert agent.provider == "enformion"
            assert agent.agent_name == "AddressSearchAgent"
            assert agent.person_search_agent is None
    
    def test_parse_address_complete(self, address_agent):
        """Test parsing a complete address"""
        address = "123 Main Street, Apt 4B, Anytown, NY 12345"
        parsed = address_agent.parse_address(address)
        
        assert parsed["street_number"] == "123"
        assert "Main Street" in parsed["street_name"]
        assert parsed["city"] == "Anytown"
        assert parsed["state"] == "NY"
        assert parsed["zip_code"] == "12345"
        assert parsed["original"] == address
    
    def test_parse_address_minimal(self, address_agent):
        """Test parsing a minimal address"""
        address = "456 Oak St, Boston, MA"
        parsed = address_agent.parse_address(address)
        
        assert parsed["street_number"] == "456"
        assert "Oak St" in parsed["street_name"]
        assert parsed["city"] == "Boston"
        assert parsed["state"] == "MA"
        assert parsed["zip_code"] is None
    
    def test_parse_address_invalid(self, address_agent):
        """Test parsing invalid address"""
        parsed = address_agent.parse_address("")
        assert parsed == {}
        
        parsed = address_agent.parse_address(None)
        assert parsed == {}
    
    def test_validate_address_valid(self, address_agent):
        """Test validating a complete, valid address"""
        address = "123 Main Street, Anytown, NY 12345"
        result = address_agent.validate_address(address)
        
        assert isinstance(result, AddressValidationResult)
        assert result.input_address == address
        assert result.quality_score > 0.7  # Should be high for complete address
        assert result.is_valid == True
        assert result.standardized_address is not None
    
    def test_validate_address_incomplete(self, address_agent):
        """Test validating incomplete address"""
        address = "Main Street"  # Missing number, city, state
        result = address_agent.validate_address(address)
        
        assert result.quality_score < 0.7
        assert result.is_valid == False
        assert len(result.validation_errors) == 0  # No explicit errors, just low quality
    
    def test_normalize_address(self, address_agent):
        """Test address normalization"""
        address = "123 Main Street, Apartment 4B"
        normalized = address_agent.normalize_address(address)
        
        assert normalized == "123 main st, apt 4b"
    
    def test_calculate_address_similarity(self, address_agent):
        """Test address similarity calculation"""
        addr1 = "123 Main Street, Anytown, NY 12345"
        addr2 = "123 Main St, Anytown, NY 12345"
        
        similarity = address_agent.calculate_address_similarity(addr1, addr2)
        assert similarity > 0.8  # Should be very similar
        
        addr3 = "456 Oak Avenue, Boston, MA 02101"
        similarity2 = address_agent.calculate_address_similarity(addr1, addr3)
        assert similarity2 < 0.3  # Should be very different
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_identify_current_residents(self, mock_request, address_agent):
        """Test identifying current residents"""
        # Mock API response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'results': [
                {
                    'first_name': 'John',
                    'last_name': 'Doe',
                    'age': 35,
                    'phones': [{'number': '5551234567', 'type': 'mobile'}],
                    'emails': ['john.doe@example.com'],
                    'is_current': True,
                    'relationship': 'owner'
                },
                {
                    'first_name': 'Jane',
                    'last_name': 'Smith',
                    'age': 32,
                    'phones': ['5559876543'],
                    'is_current': True,
                    'relationship': 'resident'
                }
            ]
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        residents = address_agent.identify_current_residents(address)
        
        assert len(residents) == 2
        assert residents[0].name == "John Doe"
        assert residents[0].age == 35
        assert residents[0].phone_numbers == ['5551234567']
        assert residents[0].email_addresses == ['john.doe@example.com']
        assert residents[0].relationship_to_property == 'owner'
        assert residents[0].confidence_score > 0.5
        
        assert residents[1].name == "Jane Smith"
        assert residents[1].age == 32
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_identify_historical_residents(self, mock_request, address_agent):
        """Test identifying historical residents"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'historical_results': [
                {
                    'first_name': 'Bob',
                    'last_name': 'Wilson',
                    'age': 45,
                    'residence_start': '2020-01-01',
                    'residence_end': '2022-12-31',
                    'phones': [{'number': '5551111111'}],
                    'relationship': 'former_resident'
                }
            ]
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        historical = address_agent.identify_historical_residents(address, years_back=3)
        
        assert len(historical) == 1
        assert historical[0].name == "Bob Wilson"
        assert historical[0].age == 45
        assert historical[0].occupancy_period['current'] == False
        assert historical[0].relationship_to_property == 'former_resident'
        assert historical[0].confidence_score < 1.0  # Should be lower for historical data
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_analyze_property_ownership(self, mock_request, address_agent):
        """Test property ownership analysis"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'property_info': {
                'current_owner': 'John and Jane Doe',
                'ownership_type': 'joint_tenancy',
                'ownership_date': '2020-06-15',
                'mortgage_info': {
                    'lender': 'First National Bank',
                    'loan_amount': 350000,
                    'loan_date': '2020-06-15'
                },
                'tax_assessment': {
                    'assessed_value': 400000,
                    'tax_year': 2023,
                    'annual_taxes': 8500
                },
                'property_type': 'single_family',
                'square_footage': 2400,
                'bedrooms': 4,
                'bathrooms': 2.5,
                'year_built': 1995,
                'verified': True,
                'previous_owners': [
                    {
                        'name': 'Previous Owner LLC',
                        'ownership_type': 'corporation',
                        'ownership_start': '2015-03-01',
                        'ownership_end': '2020-06-14'
                    }
                ]
            }
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        ownership_records = address_agent.analyze_property_ownership(address)
        
        assert len(ownership_records) >= 1
        current_record = ownership_records[0]
        assert current_record.current_owner == 'John and Jane Doe'
        assert current_record.ownership_type == 'joint_tenancy'
        assert current_record.mortgage_info['lender'] == 'First National Bank'
        assert current_record.tax_assessment['assessed_value'] == 400000
        assert current_record.property_details['bedrooms'] == 4
        assert current_record.confidence_score == 0.9  # High confidence for verified data
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_profile_neighborhood_demographics(self, mock_request, address_agent):
        """Test neighborhood demographic profiling"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'demographics': {
                'total_population': 25000,
                'population_density': 3500,
                'total_households': 9500,
                'average_household_size': 2.6,
                'median_household_income': 75000,
                'mean_household_income': 85000,
                'poverty_rate': 8.5,
                'age_distribution': {
                    '18-25': 12.5,
                    '26-35': 22.3,
                    '36-45': 18.7,
                    '46-55': 16.8,
                    '56-65': 14.2,
                    '65+': 15.5
                },
                'education_levels': {
                    'high_school': 25.4,
                    'bachelors': 35.2,
                    'masters': 22.1,
                    'doctorate': 8.3
                },
                'median_home_value': 450000,
                'median_rent': 2100,
                'homeownership_rate': 68.5,
                'employment_rate': 94.2,
                'major_employers': ['Tech Corp', 'University Hospital', 'City Government']
            }
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        demographics = address_agent.profile_neighborhood_demographics(address, radius_miles=1.0)
        
        assert isinstance(demographics, DemographicProfile)
        assert demographics.population_data['total_population'] == 25000
        assert demographics.income_statistics['median_household_income'] == 75000
        assert demographics.age_distribution['26-35'] == 22.3
        assert demographics.education_levels['bachelors'] == 35.2
        assert demographics.housing_characteristics['median_home_value'] == 450000
        assert len(demographics.economic_indicators['major_employers']) == 3
    
    def test_analyze_movement_patterns_with_person_agent(self, address_agent):
        """Test movement pattern analysis with PersonSearchAgent integration"""
        # Mock PersonSearchAgent
        mock_profile = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            source_provider="test",
            confidence_score=0.8
        )
        
        # Add address history
        addresses = [
            Address(
                street="123 Current St",
                city="Current City",
                state="NY",
                zip_code="12345",
                is_current=True,
                first_seen=datetime(2022, 1, 1),
                last_seen=datetime.now(),
                confidence_score=0.9
            ),
            Address(
                street="456 Previous Ave",
                city="Previous City",
                state="NY",
                zip_code="12346",
                is_current=False,
                first_seen=datetime(2020, 6, 1),
                last_seen=datetime(2021, 12, 31),
                confidence_score=0.8
            ),
            Address(
                street="789 Old Road",
                city="Old City",
                state="CA",
                zip_code="90210",
                is_current=False,
                first_seen=datetime(2018, 3, 1),
                last_seen=datetime(2020, 5, 31),
                confidence_score=0.7
            )
        ]
        mock_profile.addresses = addresses
        
        address_agent.person_search_agent.search.return_value = [mock_profile]
        
        pattern = address_agent.analyze_movement_patterns("John Doe", "123 Current St")
        
        assert isinstance(pattern, MovementPattern)
        assert pattern.person_name == "John Doe"
        assert len(pattern.address_history) == 3
        assert pattern.geographic_mobility > 0  # Moved between states
        assert pattern.stability_score < 1.0  # Some mobility
        assert pattern.prediction_confidence > 0
        
        # Check for cross-state movement trigger
        assert any('geographic_mobility' in triggers for triggers in [pattern.movement_triggers])
    
    def test_analyze_movement_patterns_no_person_agent(self, mock_enformion_client):
        """Test movement pattern analysis without PersonSearchAgent"""
        with patch('src.agents.address_search_agent.APILockerManager'):
            agent = AddressSearchAgent(person_search_agent=None)
            
            pattern = agent.analyze_movement_patterns("John Doe", "123 Main St")
            
            assert isinstance(pattern, MovementPattern)
            assert pattern.person_name == "John Doe"
            assert len(pattern.address_history) == 0
            assert pattern.prediction_confidence == 0.0
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_verify_address(self, mock_request, address_agent):
        """Test address verification"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'is_deliverable': True,
            'property_type': 'residential',
            'postal_status': 'active',
            'confidence_score': 0.95,
            'suggested_address': None
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        verification = address_agent.verify_address(address)
        
        assert verification['address'] == address
        assert verification['is_deliverable'] == True
        assert verification['is_residential'] == True
        assert verification['is_business'] == False
        assert verification['verification_level'] == 'confirmed'
        assert verification['postal_service_status'] == 'active'
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_verify_address_invalid(self, mock_request, address_agent):
        """Test verification of invalid address"""
        # Test with badly formatted address first
        address = "Invalid Address Format"
        verification = address_agent.verify_address(address)
        
        assert verification['verification_level'] == 'invalid'
        
        # Test with API returning low confidence
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'is_deliverable': False,
            'confidence_score': 0.3,
            'suggested_address': '123 Main Street, Anytown, NY 12345'
        }
        mock_request.return_value = mock_response
        
        address = "123 Main St, Anytown, NY 12345"  # Valid format but low API confidence
        verification = address_agent.verify_address(address)
        
        assert verification['verification_level'] == 'questionable'
        assert len(verification['suggestions']) > 0
    
    def test_search_comprehensive(self, address_agent):
        """Test comprehensive address intelligence search"""
        # Mock all the component methods
        with patch.multiple(
            address_agent,
            validate_address=Mock(return_value=AddressValidationResult("123 Main St")),
            identify_current_residents=Mock(return_value=[ResidentProfile()]),
            identify_historical_residents=Mock(return_value=[ResidentProfile()]),
            analyze_property_ownership=Mock(return_value=[PropertyOwnershipRecord()]),
            profile_neighborhood_demographics=Mock(return_value=DemographicProfile()),
            analyze_movement_patterns=Mock(return_value=MovementPattern()),
            verify_address=Mock(return_value={'verification_level': 'confirmed'})
        ):
            # Set up validation result
            address_agent.validate_address.return_value.quality_score = 0.9
            address_agent.validate_address.return_value.is_valid = True
            
            # Set up resident with name for movement analysis
            resident = ResidentProfile()
            resident.name = "John Doe"
            resident.confidence_score = 0.8
            address_agent.identify_current_residents.return_value = [resident]
            
            # Set up ownership record
            ownership = PropertyOwnershipRecord()
            ownership.confidence_score = 0.9
            address_agent.analyze_property_ownership.return_value = [ownership]
            
            query = AddressLookupQuery(
                full_address="123 Main Street, Anytown, NY 12345",
                include_residents=True,
                include_property_data=True,
                include_demographics=True
            )
            
            report = address_agent.search_comprehensive(query)
            
            assert isinstance(report, AddressIntelligenceReport)
            assert report.query_address == "123 Main Street, Anytown, NY 12345"
            assert report.validation_result is not None
            assert len(report.current_residents) == 1
            assert len(report.historical_residents) == 1
            assert len(report.ownership_records) == 1
            assert report.demographic_profile is not None
            assert len(report.movement_patterns) == 1
            assert report.verification_status is not None
            assert report.confidence_score > 0.5
    
    def test_search_comprehensive_insufficient_params(self, address_agent):
        """Test comprehensive search with insufficient parameters"""
        query = AddressLookupQuery()  # Empty query
        
        with pytest.raises(ValueError, match="sufficient address parameters"):
            address_agent.search_comprehensive(query)
    
    def test_query_dict_interface(self, address_agent):
        """Test dict-based query interface"""
        with patch.object(address_agent, 'search_comprehensive') as mock_search:
            mock_report = AddressIntelligenceReport("test address")
            mock_search.return_value = mock_report
            
            query_params = {
                'full_address': '123 Main Street, Anytown, NY 12345',
                'include_residents': True,
                'include_property_data': False
            }
            
            result = address_agent.query(query_params)
            
            assert result == mock_report
            mock_search.assert_called_once()
            # Check that AddressLookupQuery was created properly
            args = mock_search.call_args[0]
            assert isinstance(args[0], AddressLookupQuery)
            assert args[0].full_address == '123 Main Street, Anytown, NY 12345'
            assert args[0].include_residents == True
            assert args[0].include_property_data == False
    
    @patch('src.agents.address_search_agent.AddressSearchAgent.make_request')
    def test_geocode_address(self, mock_request, address_agent):
        """Test address geocoding"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'latitude': 40.7128,
            'longitude': -74.0060,
            'accuracy': 'rooftop'
        }
        mock_request.return_value = mock_response
        
        address = "123 Main Street, Anytown, NY 12345"
        coordinates = address_agent.geocode_address(address)
        
        assert coordinates is not None
        assert coordinates['latitude'] == 40.7128
        assert coordinates['longitude'] == -74.0060
        assert coordinates['accuracy'] == 'rooftop'
    
    def test_geocode_address_failure(self, address_agent):
        """Test geocoding when API fails"""
        with patch.object(address_agent, 'make_request', side_effect=Exception("API Error")):
            coordinates = address_agent.geocode_address("123 Main St")
            assert coordinates is None
    
    def test_health_check(self, address_agent):
        """Test agent health check"""
        health = address_agent.health_check()
        
        assert 'address_search_ready' in health
        assert 'validation_functional' in health
        assert 'person_search_integration' in health
        assert health['person_search_integration'] == True  # We provided mock agent


class TestAddressIntelligenceReport:
    """Test AddressIntelligenceReport functionality"""
    
    def test_initialization(self):
        """Test report initialization"""
        address = "123 Main Street, Anytown, NY 12345"
        report = AddressIntelligenceReport(address)
        
        assert report.query_address == address
        assert report.current_residents == []
        assert report.historical_residents == []
        assert report.ownership_records == []
        assert report.movement_patterns == []
        assert report.risk_indicators == []
        assert report.confidence_score == 0.0
        assert isinstance(report.query_timestamp, datetime)
    
    def test_to_dict(self):
        """Test report serialization"""
        address = "123 Main Street, Anytown, NY 12345"
        report = AddressIntelligenceReport(address)
        
        # Add some test data
        validation = AddressValidationResult(address)
        validation.is_valid = True
        validation.quality_score = 0.8
        report.validation_result = validation
        
        resident = ResidentProfile()
        resident.name = "John Doe"
        resident.confidence_score = 0.7
        report.current_residents = [resident]
        
        report.confidence_score = 0.75
        
        report_dict = report.to_dict()
        
        assert report_dict['query_address'] == address
        assert report_dict['validation_result']['is_valid'] == True
        assert len(report_dict['current_residents']) == 1
        assert report_dict['current_residents'][0]['name'] == "John Doe"
        assert report_dict['confidence_score'] == 0.75
        assert 'query_timestamp' in report_dict


class TestRealWorldScenarios:
    """Test realistic address intelligence scenarios"""
    
    @pytest.fixture
    def full_featured_agent(self, mock_enformion_client):
        """Address agent with all features enabled"""
        mock_person_agent = Mock()
        with patch('src.agents.address_search_agent.APILockerManager'):
            agent = AddressSearchAgent(person_search_agent=mock_person_agent)
            return agent, mock_person_agent
    
    def test_single_family_home_analysis(self, full_featured_agent):
        """Test analysis of a single-family home"""
        agent, mock_person_agent = full_featured_agent
        
        # Mock comprehensive data for single-family home
        with patch.multiple(
            agent,
            make_request=Mock()
        ) as mocks:
            # Setup address validation
            validation = AddressValidationResult("123 Oak Lane, Suburbia, TX 75001")
            validation.is_valid = True
            validation.quality_score = 0.95
            validation.standardized_address = "123 Oak Lane, Suburbia, TX 75001"
            
            # Mock API responses
            responses = [
                # Address search response
                Mock(status_code=200, json=Mock(return_value={
                    'results': [
                        {
                            'first_name': 'Robert',
                            'last_name': 'Johnson',
                            'age': 42,
                            'phones': [{'number': '9725551234', 'type': 'mobile'}],
                            'emails': ['rob.johnson@email.com'],
                            'is_current': True,
                            'relationship': 'owner'
                        },
                        {
                            'first_name': 'Sarah',
                            'last_name': 'Johnson',
                            'age': 39,
                            'phones': [{'number': '9725555678'}],
                            'is_current': True,
                            'relationship': 'owner'
                        }
                    ]
                })),
                # Property search response
                Mock(status_code=200, json=Mock(return_value={
                    'property_info': {
                        'current_owner': 'Robert and Sarah Johnson',
                        'ownership_type': 'joint_tenancy',
                        'ownership_date': '2018-04-15',
                        'property_type': 'single_family',
                        'square_footage': 3200,
                        'bedrooms': 4,
                        'bathrooms': 3,
                        'year_built': 2005,
                        'lot_size': '0.25 acres',
                        'tax_assessment': {
                            'assessed_value': 485000,
                            'annual_taxes': 12500
                        },
                        'verified': True
                    }
                })),
                # Demographics response
                Mock(status_code=200, json=Mock(return_value={
                    'demographics': {
                        'total_population': 18500,
                        'median_household_income': 89000,
                        'median_home_value': 465000,
                        'homeownership_rate': 78.5,
                        'age_distribution': {
                            '35-44': 28.5,
                            '45-54': 22.3,
                            '25-34': 18.7
                        }
                    }
                })),
                # Address verification response
                Mock(status_code=200, json=Mock(return_value={
                    'is_deliverable': True,
                    'property_type': 'residential',
                    'confidence_score': 0.98
                }))
            ]
            
            mocks['make_request'].side_effect = responses
            
            with patch.object(agent, 'validate_address', return_value=validation):
                query = AddressLookupQuery(
                    full_address="123 Oak Lane, Suburbia, TX 75001",
                    include_residents=True,
                    include_property_data=True,
                    include_demographics=True
                )
                
                report = agent.search_comprehensive(query)
                
                # Validate results
                assert report.confidence_score > 0.8
                assert len(report.current_residents) == 2
                assert report.current_residents[0].name == "Robert Johnson"
                assert report.current_residents[1].name == "Sarah Johnson"
                
                assert len(report.ownership_records) == 1
                assert report.ownership_records[0].current_owner == "Robert and Sarah Johnson"
                assert report.ownership_records[0].property_details['bedrooms'] == 4
                
                assert report.demographic_profile.income_statistics['median_household_income'] == 89000
                assert report.verification_status['is_deliverable'] == True
    
    def test_apartment_complex_analysis(self, full_featured_agent):
        """Test analysis of an apartment in a complex"""
        agent, mock_person_agent = full_featured_agent
        
        with patch.multiple(agent, make_request=Mock()) as mocks:
            validation = AddressValidationResult("450 Riverside Drive, Apt 12B, Metropolitan City, NY 10025")
            validation.is_valid = True
            validation.quality_score = 0.88
            
            # Apartment-specific responses
            responses = [
                # Multiple residents in apartment complex
                Mock(status_code=200, json=Mock(return_value={
                    'results': [
                        {
                            'first_name': 'Elena',
                            'last_name': 'Rodriguez',
                            'age': 28,
                            'phones': [{'number': '2125551111'}],
                            'unit': '12B',
                            'relationship': 'primary_tenant'
                        },
                        {
                            'first_name': 'James',
                            'last_name': 'Chen',
                            'age': 30,
                            'phones': [{'number': '2125552222'}],
                            'unit': '12B',
                            'relationship': 'co_tenant'
                        }
                    ],
                    'historical_results': [
                        {
                            'first_name': 'Previous',
                            'last_name': 'Tenant',
                            'residence_start': '2022-01-01',
                            'residence_end': '2023-03-31',
                            'relationship': 'former_tenant'
                        }
                    ]
                })),
                # Property owned by management company
                Mock(status_code=200, json=Mock(return_value={
                    'property_info': {
                        'current_owner': 'Metropolitan Housing LLC',
                        'ownership_type': 'corporation',
                        'property_type': 'multi_family',
                        'units': 150,
                        'year_built': 1987
                    }
                })),
                # Urban demographics
                Mock(status_code=200, json=Mock(return_value={
                    'demographics': {
                        'total_population': 45000,
                        'population_density': 8500,
                        'median_household_income': 95000,
                        'homeownership_rate': 35.2,  # Low for urban area
                        'age_distribution': {
                            '25-34': 35.8,
                            '35-44': 22.1
                        }
                    }
                })),
                Mock(status_code=200, json=Mock(return_value={
                    'is_deliverable': True,
                    'property_type': 'residential',
                    'confidence_score': 0.92
                }))
            ]
            
            mocks['make_request'].side_effect = responses
            
            with patch.object(agent, 'validate_address', return_value=validation):
                query = AddressLookupQuery(
                    full_address="450 Riverside Drive, Apt 12B, Metropolitan City, NY 10025",
                    include_residents=True,
                    include_property_data=True,
                    include_demographics=True
                )
                
                report = agent.search_comprehensive(query)
                
                # Validate apartment-specific results
                assert len(report.current_residents) == 2
                assert report.current_residents[0].relationship_to_property in ['primary_tenant', 'co_tenant']
                
                assert len(report.historical_residents) == 1
                assert report.historical_residents[0].relationship_to_property == 'former_tenant'
                
                # Corporate ownership
                assert report.ownership_records[0].current_owner == "Metropolitan Housing LLC"
                assert report.ownership_records[0].ownership_type == "corporation"
                
                # Urban demographics
                assert report.demographic_profile.housing_characteristics['homeownership_rate'] < 50
    
    def test_business_address_analysis(self, full_featured_agent):
        """Test analysis of a business address"""
        agent, mock_person_agent = full_featured_agent
        
        with patch.multiple(agent, make_request=Mock()) as mocks:
            validation = AddressValidationResult("789 Commerce Boulevard, Business Park, CA 94107")
            validation.is_valid = True
            validation.quality_score = 0.92
            
            responses = [
                # Business occupants instead of residents
                Mock(status_code=200, json=Mock(return_value={
                    'results': [
                        {
                            'business_name': 'TechStart Solutions Inc',
                            'contact_person': 'David Kim',
                            'phones': [{'number': '4155551234', 'type': 'business'}],
                            'emails': ['info@techstart.com'],
                            'relationship': 'tenant'
                        }
                    ]
                })),
                # Commercial property ownership
                Mock(status_code=200, json=Mock(return_value={
                    'property_info': {
                        'current_owner': 'Commercial Real Estate Partners',
                        'ownership_type': 'corporation',
                        'property_type': 'commercial_office',
                        'square_footage': 15000,
                        'year_built': 1998,
                        'zoning': 'commercial'
                    }
                })),
                # Business district demographics
                Mock(status_code=200, json=Mock(return_value={
                    'demographics': {
                        'business_count': 245,
                        'employment_density': 1200,
                        'primary_industries': ['Technology', 'Professional Services', 'Finance']
                    }
                })),
                Mock(status_code=200, json=Mock(return_value={
                    'is_deliverable': True,
                    'property_type': 'commercial',
                    'confidence_score': 0.89
                }))
            ]
            
            mocks['make_request'].side_effect = responses
            
            with patch.object(agent, 'validate_address', return_value=validation):
                query = AddressLookupQuery(
                    full_address="789 Commerce Boulevard, Business Park, CA 94107",
                    include_residents=True,
                    include_property_data=True,
                    include_demographics=True
                )
                
                report = agent.search_comprehensive(query)
                
                # Business-specific validations
                assert report.verification_status['is_business'] == True
                assert report.ownership_records[0].property_details.get('zoning') == 'commercial'


# Integration test for error handling
class TestErrorHandling:
    """Test error handling scenarios"""
    
    @pytest.fixture
    def error_prone_agent(self, mock_enformion_client):
        """Agent configured for testing error scenarios"""
        with patch('src.agents.address_search_agent.APILockerManager'):
            agent = AddressSearchAgent()
            return agent
    
    def test_api_error_handling(self, error_prone_agent):
        """Test handling of API errors"""
        with patch.object(error_prone_agent, 'make_request', side_effect=requests.RequestException("Network error")):
            residents = error_prone_agent.identify_current_residents("123 Main St, Any City, NY")
            assert residents == []  # Should return empty list, not raise exception
    
    def test_malformed_response_handling(self, error_prone_agent):
        """Test handling of malformed API responses"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        
        with patch.object(error_prone_agent, 'make_request', return_value=mock_response):
            residents = error_prone_agent.identify_current_residents("123 Main St")
            assert residents == []
    
    def test_partial_data_handling(self, error_prone_agent):
        """Test handling of partial/incomplete data"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'results': [
                {
                    # Incomplete resident data - missing name
                    'age': 25,
                    'phones': ['5551234567']
                },
                {
                    'first_name': 'John',
                    # Missing last name, but should still process
                    'phones': []  # Empty phones
                }
            ]
        }
        
        with patch.object(error_prone_agent, 'make_request', return_value=mock_response):
            residents = error_prone_agent.identify_current_residents("123 Main St")
            
            # Should handle partial data gracefully
            assert len(residents) == 2
            assert residents[0].name is None  # No name data
            assert residents[1].name == "John"  # Partial name data