"""
Tests for BusinessSearchAgent
Comprehensive test suite covering all business intelligence features
"""

import pytest
import json
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

from src.agents.business_search_agent import BusinessSearchAgent
from src.models.business import (
    BusinessProfile, BusinessStatus, EntityType, Principal, Filing, Registration
)
from src.models.query import BusinessSearchQuery
from src.models.person import PersonName, Address, Phone
from src.providers.enformion_client import EnformionAPIError


class TestBusinessSearchAgent:
    """Test suite for BusinessSearchAgent"""
    
    @pytest.fixture
    def agent(self):
        """Create BusinessSearchAgent instance for testing"""
        with patch('src.agents.business_search_agent.EnformionClient'):
            agent = BusinessSearchAgent()
            return agent
    
    @pytest.fixture
    def mock_business_data(self) -> Dict[str, Any]:
        """Mock business data response"""
        return {
            'business_name': 'Acme Corporation',
            'dba_name': 'Acme Co',
            'ein': '12-3456789',
            'entity_type': 'corporation',
            'status': 'active',
            'industry': 'Technology',
            'phones': ['5551234567'],
            'addresses': [{
                'street': '123 Main St',
                'city': 'Anytown',
                'state': 'CA',
                'zip_code': '12345'
            }],
            'website': 'https://acme.com',
            'description': 'Technology company',
            'officers': [{
                'name': 'John Doe',
                'title': 'CEO',
                'role': 'officer'
            }],
            'financial': {
                'revenue': 5000000,
                'employees': 50
            }
        }
    
    @pytest.fixture
    def mock_enformion_response(self, mock_business_data) -> Dict[str, Any]:
        """Mock EnformionGO API response"""
        return {
            'results': [mock_business_data],
            'total_results': 1,
            'status': 'success'
        }
    
    def test_initialization(self, agent):
        """Test agent initialization"""
        assert agent.agent_name == "BusinessSearchAgent"
        assert agent.provider == "enformion"
        assert agent.fuzzy_threshold == 0.8
        assert agent.risk_threshold == 0.7
    
    def test_calculate_name_similarity(self, agent):
        """Test business name similarity calculation"""
        # Exact match
        assert agent._calculate_name_similarity("Acme Corp", "Acme Corp") == 1.0
        
        # Similar with different suffixes
        assert agent._calculate_name_similarity("Acme Corporation", "Acme Corp") > 0.9
        
        # Different names
        assert agent._calculate_name_similarity("Acme Corp", "Beta Inc") < 0.5
    
    def test_validate_and_cleanup_business_data(self, agent, mock_business_data):
        """Test business data validation and cleanup"""
        cleaned = agent._validate_and_cleanup_business_data(mock_business_data)
        
        assert cleaned['business_name'] == 'Acme Corporation'
        assert cleaned['ein'] == '12-3456789'
        assert len(cleaned['phones']) == 1
        assert cleaned['phones'][0]['formatted'] == '(555) 123-4567'
        assert len(cleaned['addresses']) == 1
        assert cleaned['addresses'][0]['city'] == 'Anytown'
    
    def test_convert_to_business_profile(self, agent, mock_business_data):
        """Test conversion of raw data to BusinessProfile"""
        query = BusinessSearchQuery(business_name="Acme Corporation")
        profile = agent._convert_to_business_profile(mock_business_data, query)
        
        assert isinstance(profile, BusinessProfile)
        assert profile.business_name == "Acme Corporation"
        assert profile.entity_type == EntityType.CORPORATION
        assert len(profile.locations) == 1
        assert len(profile.phones) == 1
        assert profile.registration.status == BusinessStatus.ACTIVE
        assert profile.confidence_score > 0.0
    
    @patch('src.agents.business_search_agent.EnformionClient')
    def test_search_by_name(self, mock_client_class, agent, mock_enformion_response):
        """Test search by business name"""
        # Setup mock
        mock_client = Mock()
        mock_client.business_search.return_value = mock_enformion_response
        mock_client_class.return_value = mock_client
        agent.enformion_client = mock_client
        
        # Execute search
        results = agent.search_by_name("Acme Corporation", city="Anytown", state="CA")
        
        # Verify results
        assert len(results) == 1
        assert results[0].business_name == "Acme Corporation"
        assert results[0].primary_location.address.city == "Anytown"
        
        # Verify API call
        mock_client.business_search.assert_called_once_with(
            business_name="Acme Corporation",
            city="Anytown",
            state="CA"
        )
    
    @patch('src.agents.business_search_agent.EnformionClient')
    def test_search_by_ein(self, mock_client_class, agent, mock_enformion_response):
        """Test search by EIN"""
        mock_client = Mock()
        mock_client.business_search.return_value = mock_enformion_response
        mock_client_class.return_value = mock_client
        agent.enformion_client = mock_client
        
        results = agent.search_by_ein("12-3456789")
        
        assert len(results) == 1
        assert results[0].registration.federal_ein == "12-3456789"
    
    @patch('src.agents.business_search_agent.EnformionClient')
    def test_search_by_phone(self, mock_client_class, agent, mock_enformion_response):
        """Test search by phone number"""
        mock_client = Mock()
        mock_client.business_search.return_value = mock_enformion_response
        mock_client_class.return_value = mock_client
        agent.enformion_client = mock_client
        
        results = agent.search_by_phone("(555) 123-4567")
        
        assert len(results) == 1
        assert results[0].primary_phone.number == "5551234567"
    
    def test_verify_business_entity(self, agent, mock_business_data):
        """Test business entity verification"""
        with patch.object(agent, 'search') as mock_search:
            # Create mock BusinessProfile
            profile = agent._convert_to_business_profile(
                mock_business_data, 
                BusinessSearchQuery(business_name="Acme Corporation")
            )
            profile.confidence_score = 0.9
            mock_search.return_value = [profile]
            
            result = agent.verify_business_entity("Acme Corporation", "12-3456789")
            
            assert result['verified'] is True
            assert result['confidence'] == 0.9
            assert result['business_name'] == "Acme Corporation"
            assert result['entity_type'] == "corporation"
            assert result['status'] == "active"
    
    def test_identify_principals(self, agent, mock_business_data):
        """Test principal identification"""
        profile = agent._convert_to_business_profile(
            mock_business_data,
            BusinessSearchQuery(business_name="Acme Corporation")
        )
        
        principals = agent.identify_principals(profile)
        
        # Should find the officer from mock data
        assert len(principals) >= 0  # May be 0 if no principals in converted profile
        
        # Test with raw data containing officers
        profile.raw_response = mock_business_data
        principals = agent.identify_principals(profile)
        
        assert len(principals) == 1
        assert principals[0].name.full == "John Doe"
        assert principals[0].title == "CEO"
    
    def test_analyze_corporate_filings(self, agent):
        """Test corporate filing analysis"""
        # Create business profile with filings
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion"
        )
        
        # Add some test filings
        recent_filing = Filing(
            filing_type="Annual Report",
            filing_date=datetime.utcnow() - timedelta(days=30),
            description="Annual business report"
        )
        
        risk_filing = Filing(
            filing_type="Legal Notice",
            filing_date=datetime.utcnow() - timedelta(days=60),
            description="Lien filed against business"
        )
        
        profile.add_filing(recent_filing)
        profile.add_filing(risk_filing)
        
        analysis = agent.analyze_corporate_filings(profile)
        
        assert analysis['total_filings'] == 2
        assert analysis['recent_filings'] == 2
        assert len(analysis['risk_indicators']) == 1
        assert analysis['risk_indicators'][0]['type'] == 'lien'
        assert analysis['compliance_status'] == 'moderate_risk'
    
    def test_map_business_relationships(self, agent):
        """Test business relationship mapping"""
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion",
            parent_company="Parent Corp",
            subsidiaries=["Sub Corp 1", "Sub Corp 2"]
        )
        
        # Add a principal
        principal = Principal(
            name=PersonName(full="John Doe"),
            title="CEO"
        )
        profile.add_principal(principal)
        
        relationships = agent.map_business_relationships(profile)
        
        assert relationships['parent_company'] == "Parent Corp"
        assert len(relationships['subsidiaries']) == 2
        assert relationships['relationship_confidence'] > 0.0
    
    def test_assess_business_risk(self, agent, mock_business_data):
        """Test business risk assessment"""
        profile = agent._convert_to_business_profile(
            mock_business_data,
            BusinessSearchQuery(business_name="Acme Corporation")
        )
        
        # Set years in business for testing
        profile.years_in_business = 15
        
        risk_assessment = agent.assess_business_risk(profile)
        
        assert 'overall_risk_score' in risk_assessment
        assert 'risk_level' in risk_assessment
        assert 'risk_factors' in risk_assessment
        assert 'positive_indicators' in risk_assessment
        
        # Should be low risk for established, active business
        assert risk_assessment['risk_level'] in ['low', 'moderate']
    
    def test_assess_business_risk_high_risk(self, agent):
        """Test high-risk business assessment"""
        # Create high-risk profile
        profile = BusinessProfile(
            business_name="High Risk Corp",
            source_provider="enformion"
        )
        
        # Add risk factors
        profile.registration = Registration(
            status=BusinessStatus.SUSPENDED,
            federal_ein="12-3456789"
        )
        
        profile.years_in_business = 1  # New business
        
        # Add bankruptcy filing
        from src.models.business import FinancialData
        profile.financial_data = FinancialData(bankruptcy_filed=True)
        
        risk_assessment = agent.assess_business_risk(profile)
        
        assert risk_assessment['overall_risk_score'] > 0.5
        assert risk_assessment['risk_level'] in ['high', 'critical']
        assert len(risk_assessment['risk_factors']) > 0
    
    def test_conduct_due_diligence(self, agent, mock_business_data):
        """Test comprehensive due diligence"""
        with patch.object(agent, 'search') as mock_search:
            profile = agent._convert_to_business_profile(
                mock_business_data,
                BusinessSearchQuery(business_name="Acme Corporation")
            )
            profile.confidence_score = 0.9
            mock_search.return_value = [profile]
            
            report = agent.conduct_due_diligence("Acme Corporation")
            
            assert report['business_profile']['business_name'] == "Acme Corporation"
            assert 'verification' in report
            assert 'principals' in report
            assert 'filing_analysis' in report
            assert 'relationships' in report
            assert 'risk_assessment' in report
            assert 'compliance_check' in report
            assert 'recommendations' in report
            assert report['data_confidence'] == 0.9
    
    def test_search_with_insufficient_params(self, agent):
        """Test search with insufficient parameters"""
        query = BusinessSearchQuery()  # Empty query
        
        with pytest.raises(ValueError, match="insufficient parameters"):
            agent.search(query)
    
    def test_search_with_api_error(self, agent):
        """Test search handling API errors"""
        query = BusinessSearchQuery(business_name="Test Corp", city="Test City")
        
        with patch.object(agent.enformion_client, 'business_search') as mock_search:
            mock_search.side_effect = EnformionAPIError("API Error")
            
            with pytest.raises(EnformionAPIError):
                agent.search(query)
    
    def test_search_no_results(self, agent):
        """Test search with no results"""
        query = BusinessSearchQuery(business_name="Nonexistent Corp", city="Nowhere")
        
        with patch.object(agent.enformion_client, 'business_search') as mock_search:
            mock_search.return_value = {'results': []}
            
            results = agent.search(query)
            assert len(results) == 0
    
    def test_cache_functionality(self, agent, mock_enformion_response):
        """Test caching functionality"""
        query = BusinessSearchQuery(business_name="Acme Corp", city="Test City")
        
        with patch.object(agent.enformion_client, 'business_search') as mock_search:
            mock_search.return_value = mock_enformion_response
            
            # First search - should hit API
            results1 = agent.search(query, use_cache=True)
            assert len(results1) == 1
            assert mock_search.call_count == 1
            
            # Second search - should use cache
            results2 = agent.search(query, use_cache=True)
            assert len(results2) == 1
            assert mock_search.call_count == 1  # No additional API calls
    
    def test_confidence_scoring(self, agent):
        """Test confidence scoring mechanism"""
        query = BusinessSearchQuery(business_name="Acme Corp", ein="12-3456789")
        
        # Test exact matches
        result_exact = {
            'business_name': 'Acme Corp',
            'ein': '12-3456789'
        }
        
        score_exact = agent._score_result_confidence(query, result_exact)
        assert score_exact > 0.8  # High confidence for exact matches
        
        # Test partial matches
        result_partial = {
            'business_name': 'Acme Corporation',
            'ein': '98-7654321'  # Different EIN
        }
        
        score_partial = agent._score_result_confidence(query, result_partial)
        assert score_partial < score_exact  # Lower confidence for partial matches
    
    def test_health_check(self, agent):
        """Test agent health check"""
        with patch.object(agent, 'get_credential') as mock_cred:
            mock_cred.return_value = Mock(key_value="test", password="test")
            
            health = agent.health_check()
            
            assert health['status'] == 'healthy'
            assert health['agent_name'] == 'BusinessSearchAgent'
            assert health['business_search_ready'] is True


class TestBusinessSearchQueryValidation:
    """Test BusinessSearchQuery parameter validation"""
    
    def test_valid_query_creation(self):
        """Test creation of valid business search query"""
        query = BusinessSearchQuery(
            business_name="Acme Corp",
            city="Anytown",
            state="CA",
            phone="5551234567",
            ein="12-3456789"
        )
        
        assert query.business_name == "Acme Corp"
        assert query.city == "Anytown"
        assert query.state == "CA"
        assert query.phone == "5551234567"
        assert query.ein == "123456789"  # Should be cleaned
    
    def test_ein_validation(self):
        """Test EIN validation"""
        # Valid EIN
        query = BusinessSearchQuery(business_name="Test", ein="12-3456789")
        assert query.ein == "123456789"
        
        # Invalid EIN (too short)
        with pytest.raises(ValueError, match="EIN must be 9 digits"):
            BusinessSearchQuery(business_name="Test", ein="123456")
    
    def test_phone_validation(self):
        """Test phone number validation"""
        # Valid phone
        query = BusinessSearchQuery(business_name="Test", phone="(555) 123-4567")
        assert query.phone == "5551234567"
        
        # Invalid phone (too short)
        with pytest.raises(ValueError, match="at least 10 digits"):
            BusinessSearchQuery(business_name="Test", phone="555123")
    
    def test_sufficient_params_validation(self):
        """Test query parameter sufficiency validation"""
        # Sufficient params - name + location
        query1 = BusinessSearchQuery(business_name="Test", city="City", state="ST")
        assert query1.has_sufficient_params() is True
        
        # Sufficient params - EIN only
        query2 = BusinessSearchQuery(ein="123456789", city="City")
        assert query2.has_sufficient_params() is True
        
        # Insufficient params - only name
        query3 = BusinessSearchQuery(business_name="Test")
        assert query3.has_sufficient_params() is False


class TestBusinessProfileModel:
    """Test BusinessProfile model functionality"""
    
    def test_business_profile_creation(self):
        """Test creation of BusinessProfile"""
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion"
        )
        
        assert profile.business_name == "Test Corp"
        assert profile.entity_type == EntityType.UNKNOWN
        assert len(profile.locations) == 0
        assert profile.is_active is False  # No registration data
    
    def test_primary_location_property(self):
        """Test primary location property"""
        from src.models.business import BusinessLocation
        
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion"
        )
        
        # No locations
        assert profile.primary_location is None
        
        # Add headquarters location
        hq_location = BusinessLocation(
            address=Address(street="123 Main St", city="Test City"),
            is_headquarters=True
        )
        profile.locations.append(hq_location)
        
        # Add regular location
        regular_location = BusinessLocation(
            address=Address(street="456 Oak St", city="Test City"),
            is_headquarters=False
        )
        profile.locations.append(regular_location)
        
        # Should return headquarters
        assert profile.primary_location == hq_location
    
    def test_current_principals_property(self):
        """Test current principals property"""
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion"
        )
        
        # Add current principal
        current_principal = Principal(
            name=PersonName(full="John Current"),
            title="CEO",
            is_current=True
        )
        profile.add_principal(current_principal)
        
        # Add former principal
        former_principal = Principal(
            name=PersonName(full="Jane Former"),
            title="Former CEO",
            is_current=False
        )
        profile.add_principal(former_principal)
        
        current_principals = profile.current_principals
        assert len(current_principals) == 1
        assert current_principals[0].name.full == "John Current"
    
    def test_add_duplicate_prevention(self):
        """Test prevention of duplicate entries"""
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion"
        )
        
        # Add same principal twice
        principal_data = {
            'name': PersonName(full="John Doe"),
            'title': 'CEO'
        }
        
        profile.add_principal(Principal(**principal_data))
        profile.add_principal(Principal(**principal_data))
        
        # Should only have one principal
        assert len(profile.principals) == 1
    
    def test_to_summary_dict(self):
        """Test summary dict generation"""
        profile = BusinessProfile(
            business_name="Test Corp",
            source_provider="enformion",
            entity_type=EntityType.CORPORATION,
            confidence_score=0.85
        )
        
        summary = profile.to_summary_dict()
        
        assert summary['business_name'] == "Test Corp"
        assert summary['entity_type'] == "corporation"
        assert summary['confidence'] == 0.85
        assert summary['source'] == "enformion"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])