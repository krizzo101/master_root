"""
Comprehensive tests for Enhanced EnformionClient
Tests all advanced features including caching, metrics, circuit breaker, and bulk operations
"""

import unittest
import json
import time
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.providers.enhanced_enformion_client import (
    EnformionClient,
    MockEnformionClient,
    EnformionAPIError,
    ErrorType,
    RequestMetrics,
    CacheEntry,
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerState,
    RateLimiter,
    EndpointConfig
)


class TestEnhancedEnformionClient(unittest.TestCase):
    """Test suite for Enhanced EnformionClient"""

    def setUp(self):
        """Set up test fixtures"""
        # Mock credentials to avoid needing real API keys
        self.mock_credential = Mock()
        self.mock_credential.key_name = "test_key"
        self.mock_credential.key_value = "test_api_key_123"
        self.mock_credential.password = None

    def test_client_initialization_with_default_settings(self):
        """Test client initialization with default settings"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient()
            
            self.assertTrue(client.enable_caching)
            self.assertTrue(client.enable_metrics)
            self.assertTrue(client.enable_circuit_breaker)
            self.assertEqual(client.total_requests, 0)
            self.assertEqual(client.total_credits_used, 0)
            self.assertIsNotNone(client.session)
            self.assertIsNotNone(client.rate_limiter)

    def test_client_initialization_with_custom_settings(self):
        """Test client initialization with custom settings"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient(
                enable_caching=False,
                enable_metrics=False,
                enable_circuit_breaker=False,
                rate_limit_per_minute=120
            )
            
            self.assertFalse(client.enable_caching)
            self.assertFalse(client.enable_metrics)
            self.assertFalse(client.enable_circuit_breaker)

    def test_credential_loading_success(self):
        """Test successful credential loading"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient()
            
            self.assertIsNotNone(client._credential)
            self.assertEqual(client._credential.key_name, "test_key")

    def test_credential_loading_failure(self):
        """Test credential loading failure"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = None
            
            with self.assertRaises(EnformionAPIError) as context:
                EnformionClient()
            
            self.assertEqual(context.exception.error_type, ErrorType.AUTHENTICATION)

    def test_phone_search_with_valid_input(self):
        """Test reverse phone search with valid input"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            with patch.object(EnformionClient, '_make_request') as mock_request:
                mock_response = {
                    "phone_number": "9103925349",
                    "line_type": "mobile",
                    "carrier": "Verizon",
                    "owner_name": "John Smith"
                }
                mock_request.return_value = mock_response
                
                client = EnformionClient()
                result = client.reverse_phone_search("(910) 392-5349")
                
                # Verify the request was made with cleaned phone number
                mock_request.assert_called_once()
                args, kwargs = mock_request.call_args
                self.assertEqual(kwargs['params']['phone'], "9103925349")
                self.assertIn('_sleuth_metadata', result)

    def test_phone_search_with_invalid_input(self):
        """Test reverse phone search with invalid input"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient()
            
            with self.assertRaises(EnformionAPIError) as context:
                client.reverse_phone_search("123")  # Too short
            
            self.assertEqual(context.exception.error_type, ErrorType.VALIDATION)

    def test_address_search_comprehensive(self):
        """Test comprehensive address search"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            with patch.object(EnformionClient, '_make_request') as mock_request:
                mock_response = {
                    "address": "123 Main St",
                    "residents": [{"name": "John Smith", "type": "owner"}],
                    "property_details": {"bedrooms": 3, "bathrooms": 2}
                }
                mock_request.return_value = mock_response
                
                client = EnformionClient()
                result = client.address_search(
                    "123 Main St",
                    city="Charlotte",
                    state="NC",
                    include_residents=True,
                    include_property_details=True,
                    include_demographics=True
                )
                
                # Verify parameters
                args, kwargs = mock_request.call_args
                params = kwargs['params']
                self.assertEqual(params['address'], "123 Main St")
                self.assertEqual(params['city'], "Charlotte")
                self.assertEqual(params['state'], "NC")
                self.assertEqual(params['include_residents'], "true")
                self.assertEqual(params['include_property'], "true")
                self.assertEqual(params['include_demographics'], "true")
                self.assertIn('_sleuth_metadata', result)

    def test_email_search_with_validation(self):
        """Test email search with validation"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            with patch.object(EnformionClient, '_make_request') as mock_request:
                mock_response = {
                    "email": "john.smith@example.com",
                    "is_deliverable": True,
                    "domain_info": {"type": "corporate"},
                    "social_profiles": []
                }
                mock_request.return_value = mock_response
                
                client = EnformionClient()
                result = client.email_search(
                    "John.Smith@Example.com",  # Test case normalization
                    include_validation=True,
                    include_social_profiles=True
                )
                
                # Verify email was normalized
                args, kwargs = mock_request.call_args
                self.assertEqual(kwargs['params']['email'], "john.smith@example.com")
                self.assertEqual(kwargs['params']['validate'], "true")
                self.assertEqual(kwargs['params']['include_social'], "true")
                self.assertIn('_sleuth_metadata', result)

    def test_email_search_invalid_format(self):
        """Test email search with invalid format"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient()
            
            with self.assertRaises(EnformionAPIError) as context:
                client.email_search("invalid-email")
            
            self.assertEqual(context.exception.error_type, ErrorType.VALIDATION)

    def test_bulk_search_operations(self):
        """Test bulk search operations"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            with patch.object(EnformionClient, '_make_request') as mock_request:
                mock_response = {
                    "job_id": "bulk_12345",
                    "status": "submitted",
                    "estimated_completion": "2024-01-01T12:00:00"
                }
                mock_request.return_value = mock_response
                
                client = EnformionClient()
                search_requests = [
                    {"phone": "9103925349"},
                    {"email": "test@example.com"},
                    {"address": "123 Main St", "city": "Charlotte"}
                ]
                
                result = client.bulk_search(
                    search_requests=search_requests,
                    search_type="mixed",
                    batch_size=2,
                    webhook_url="https://example.com/webhook"
                )
                
                # Verify bulk request structure
                args, kwargs = mock_request.call_args
                data = kwargs['data']
                self.assertEqual(data['requests'], search_requests)
                self.assertEqual(data['search_type'], "mixed")
                self.assertEqual(data['batch_size'], 2)
                self.assertEqual(data['webhook_url'], "https://example.com/webhook")
                self.assertIn('_sleuth_metadata', result)

    def test_bulk_search_empty_requests(self):
        """Test bulk search with empty requests"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            client = EnformionClient()
            
            with self.assertRaises(EnformionAPIError) as context:
                client.bulk_search([])
            
            self.assertEqual(context.exception.error_type, ErrorType.VALIDATION)

    def test_account_status_with_breakdown(self):
        """Test account status with usage breakdown"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_locker.get_credential.return_value = self.mock_credential
            
            with patch.object(EnformionClient, '_make_request') as mock_request:
                mock_response = {
                    "status": "active",
                    "credits_remaining": 1000,
                    "usage_breakdown": {
                        "phone_search": 50,
                        "person_search": 25
                    }
                }
                mock_request.return_value = mock_response
                
                client = EnformionClient()
                # Simulate some usage
                client.total_requests = 10
                client.total_credits_used = 15
                client.total_cache_hits = 3
                
                result = client.get_account_status(include_usage_breakdown=True)
                
                # Verify client stats are included
                self.assertIn('_client_stats', result)
                client_stats = result['_client_stats']
                self.assertEqual(client_stats['total_requests'], 10)
                self.assertEqual(client_stats['total_credits_used'], 15)
                self.assertEqual(client_stats['cache_hit_rate'], 0.3)  # 3/10


class TestRateLimiter(unittest.TestCase):
    """Test suite for RateLimiter class"""

    def test_rate_limiter_initialization(self):
        """Test rate limiter initialization"""
        limiter = RateLimiter(rate_per_minute=60)
        
        self.assertEqual(limiter.rate_per_second, 1.0)  # 60/60
        self.assertEqual(limiter.burst_size, 60)
        self.assertEqual(limiter.tokens, 60)

    def test_token_acquisition_success(self):
        """Test successful token acquisition"""
        limiter = RateLimiter(rate_per_minute=60)
        
        # Should be able to acquire tokens initially
        self.assertTrue(limiter.acquire(1))
        self.assertEqual(limiter.tokens, 59)

    def test_token_acquisition_failure(self):
        """Test failed token acquisition when depleted"""
        limiter = RateLimiter(rate_per_minute=60)
        
        # Deplete all tokens
        for _ in range(60):
            limiter.acquire(1)
        
        # Should fail to acquire more tokens
        self.assertFalse(limiter.acquire(1))

    def test_token_replenishment(self):
        """Test token replenishment over time"""
        limiter = RateLimiter(rate_per_minute=60)
        
        # Deplete tokens
        limiter.tokens = 0
        
        # Simulate 1 second passing (should add 1 token)
        limiter.last_update = time.time() - 1
        
        self.assertTrue(limiter.acquire(1))

    def test_wait_time_calculation(self):
        """Test wait time calculation"""
        limiter = RateLimiter(rate_per_minute=60)  # 1 token per second
        
        # Deplete tokens
        limiter.tokens = 0
        
        # Should need to wait 1 second for 1 token
        wait_time = limiter.wait_time(1)
        self.assertEqual(wait_time, 1.0)


class TestCircuitBreaker(unittest.TestCase):
    """Test suite for CircuitBreaker class"""

    def setUp(self):
        """Set up test fixtures"""
        self.config = CircuitBreakerConfig(
            failure_threshold=3,
            success_threshold=2,
            timeout_seconds=5
        )
        self.circuit_breaker = CircuitBreaker(self.config)

    def test_circuit_breaker_initialization(self):
        """Test circuit breaker initialization"""
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.CLOSED)
        self.assertEqual(self.circuit_breaker.failure_count, 0)
        self.assertEqual(self.circuit_breaker.success_count, 0)

    def test_successful_call(self):
        """Test successful function call through circuit breaker"""
        def mock_function():
            return "success"
        
        result = self.circuit_breaker.call(mock_function)
        self.assertEqual(result, "success")
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.CLOSED)

    def test_circuit_breaker_opens_after_failures(self):
        """Test circuit breaker opens after failure threshold"""
        def failing_function():
            raise EnformionAPIError("Test failure", error_type=ErrorType.API_ERROR)
        
        # Cause failures up to threshold
        for _ in range(3):
            with self.assertRaises(EnformionAPIError):
                self.circuit_breaker.call(failing_function)
        
        # Circuit should now be open
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.OPEN)
        
        # Next call should fail immediately
        with self.assertRaises(EnformionAPIError) as context:
            self.circuit_breaker.call(failing_function)
        
        self.assertEqual(context.exception.error_type, ErrorType.CIRCUIT_BREAKER)

    def test_circuit_breaker_half_open_recovery(self):
        """Test circuit breaker recovery through half-open state"""
        def failing_function():
            raise EnformionAPIError("Test failure", error_type=ErrorType.API_ERROR)
        
        def successful_function():
            return "success"
        
        # Open the circuit breaker
        for _ in range(3):
            with self.assertRaises(EnformionAPIError):
                self.circuit_breaker.call(failing_function)
        
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.OPEN)
        
        # Simulate timeout passing
        self.circuit_breaker.last_failure_time = datetime.now() - timedelta(seconds=10)
        
        # Next successful call should transition to half-open
        result = self.circuit_breaker.call(successful_function)
        self.assertEqual(result, "success")
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.HALF_OPEN)
        
        # Another successful call should close the circuit
        result = self.circuit_breaker.call(successful_function)
        self.assertEqual(result, "success")
        self.assertEqual(self.circuit_breaker.state, CircuitBreakerState.CLOSED)


class TestCacheEntry(unittest.TestCase):
    """Test suite for CacheEntry class"""

    def test_cache_entry_creation(self):
        """Test cache entry creation"""
        data = {"test": "data"}
        expires_at = datetime.now() + timedelta(minutes=5)
        
        entry = CacheEntry(data=data, expires_at=expires_at, credit_cost=2)
        
        self.assertEqual(entry.data, data)
        self.assertEqual(entry.expires_at, expires_at)
        self.assertEqual(entry.credit_cost, 2)
        self.assertEqual(entry.hit_count, 0)

    def test_cache_entry_expiration(self):
        """Test cache entry expiration checking"""
        # Expired entry
        expired_entry = CacheEntry(
            data={"test": "data"},
            expires_at=datetime.now() - timedelta(minutes=1)
        )
        self.assertTrue(expired_entry.is_expired())
        
        # Non-expired entry
        valid_entry = CacheEntry(
            data={"test": "data"},
            expires_at=datetime.now() + timedelta(minutes=5)
        )
        self.assertFalse(valid_entry.is_expired())

    def test_cache_entry_hit_tracking(self):
        """Test cache entry hit tracking"""
        entry = CacheEntry(
            data={"test": "data"},
            expires_at=datetime.now() + timedelta(minutes=5)
        )
        
        # Initial hit count should be 0
        self.assertEqual(entry.hit_count, 0)
        
        # After hitting, count should increment and data should be returned
        data = entry.hit()
        self.assertEqual(entry.hit_count, 1)
        self.assertEqual(data, {"test": "data"})
        
        # Multiple hits
        entry.hit()
        entry.hit()
        self.assertEqual(entry.hit_count, 3)


class TestMockEnformionClient(unittest.TestCase):
    """Test suite for MockEnformionClient"""

    def setUp(self):
        """Set up test fixtures"""
        self.mock_client = MockEnformionClient()

    def test_mock_client_initialization(self):
        """Test mock client initialization"""
        self.assertEqual(self.mock_client.total_requests, 0)
        self.assertEqual(self.mock_client.total_credits_used, 0)
        self.assertTrue(self.mock_client.enable_caching)
        self.assertTrue(self.mock_client.enable_metrics)

    def test_mock_phone_search(self):
        """Test mock phone search"""
        result = self.mock_client.reverse_phone_search("9103925349")
        
        self.assertEqual(self.mock_client.total_requests, 1)
        self.assertEqual(self.mock_client.total_credits_used, 1)
        self.assertEqual(result["phone_number"], "9103925349")
        self.assertIn("line_type", result)
        self.assertIn("carrier", result)
        self.assertIn("_sleuth_metadata", result)

    def test_mock_address_search(self):
        """Test mock address search"""
        result = self.mock_client.address_search("123 Main St")
        
        self.assertEqual(self.mock_client.total_requests, 1)
        self.assertEqual(self.mock_client.total_credits_used, 1)
        self.assertEqual(result["address"], "123 Main St")
        self.assertIn("residents", result)
        self.assertIn("property_details", result)
        self.assertIn("_sleuth_metadata", result)

    def test_mock_email_search(self):
        """Test mock email search"""
        result = self.mock_client.email_search("test@example.com")
        
        self.assertEqual(self.mock_client.total_requests, 1)
        self.assertEqual(self.mock_client.total_credits_used, 1)
        self.assertEqual(result["email_address"], "test@example.com")
        self.assertIn("is_deliverable", result)
        self.assertIn("domain", result)
        self.assertIn("_sleuth_metadata", result)

    def test_mock_bulk_search(self):
        """Test mock bulk search"""
        requests = [
            {"phone": "9103925349"},
            {"email": "test@example.com"}
        ]
        
        result = self.mock_client.bulk_search(requests)
        
        self.assertIn("job_id", result)
        self.assertEqual(result["status"], "submitted")
        self.assertEqual(result["total_requests"], 2)
        self.assertIn("_sleuth_metadata", result)

    def test_mock_account_status(self):
        """Test mock account status"""
        # Simulate some usage
        self.mock_client.total_requests = 5
        self.mock_client.total_credits_used = 10
        
        result = self.mock_client.get_account_status()
        
        self.assertEqual(result["status"], "active")
        self.assertEqual(result["credits_used_today"], 10)
        self.assertIn("_client_stats", result)
        self.assertEqual(result["_client_stats"]["total_requests"], 5)


class TestRequestMetrics(unittest.TestCase):
    """Test suite for RequestMetrics class"""

    def test_metrics_initialization(self):
        """Test metrics initialization"""
        start_time = datetime.now()
        metrics = RequestMetrics(endpoint="/test", start_time=start_time)
        
        self.assertEqual(metrics.endpoint, "/test")
        self.assertEqual(metrics.start_time, start_time)
        self.assertIsNone(metrics.end_time)
        self.assertIsNone(metrics.duration_ms)
        self.assertFalse(metrics.cache_hit)

    def test_metrics_finish(self):
        """Test metrics completion"""
        start_time = datetime.now()
        metrics = RequestMetrics(endpoint="/test", start_time=start_time)
        
        # Simulate small delay
        time.sleep(0.01)
        
        metrics.finish(status_code=200, credit_cost=2, error_type=None)
        
        self.assertIsNotNone(metrics.end_time)
        self.assertGreater(metrics.duration_ms, 0)
        self.assertEqual(metrics.status_code, 200)
        self.assertEqual(metrics.credit_cost, 2)
        self.assertIsNone(metrics.error_type)

    def test_metrics_with_error(self):
        """Test metrics with error"""
        metrics = RequestMetrics(endpoint="/test", start_time=datetime.now())
        
        metrics.finish(status_code=429, credit_cost=1, error_type=ErrorType.RATE_LIMIT)
        
        self.assertEqual(metrics.status_code, 429)
        self.assertEqual(metrics.error_type, ErrorType.RATE_LIMIT)


class TestEndpointConfig(unittest.TestCase):
    """Test suite for EndpointConfig class"""

    def test_endpoint_config_defaults(self):
        """Test endpoint configuration defaults"""
        config = EndpointConfig("/test-endpoint")
        
        self.assertEqual(config.path, "/test-endpoint")
        self.assertEqual(config.credit_cost, 1)
        self.assertEqual(config.cache_ttl_minutes, 60)
        self.assertEqual(config.rate_limit_per_minute, 60)
        self.assertEqual(config.timeout_seconds, 30)

    def test_endpoint_config_custom_values(self):
        """Test endpoint configuration with custom values"""
        config = EndpointConfig(
            path="/premium-endpoint",
            credit_cost=5,
            cache_ttl_minutes=120,
            rate_limit_per_minute=30,
            timeout_seconds=60
        )
        
        self.assertEqual(config.path, "/premium-endpoint")
        self.assertEqual(config.credit_cost, 5)
        self.assertEqual(config.cache_ttl_minutes, 120)
        self.assertEqual(config.rate_limit_per_minute, 30)
        self.assertEqual(config.timeout_seconds, 60)


class TestErrorClassification(unittest.TestCase):
    """Test suite for error classification and handling"""

    def test_error_type_enum(self):
        """Test error type enumeration"""
        self.assertEqual(ErrorType.AUTHENTICATION.value, "authentication")
        self.assertEqual(ErrorType.RATE_LIMIT.value, "rate_limit")
        self.assertEqual(ErrorType.VALIDATION.value, "validation")
        self.assertEqual(ErrorType.NETWORK.value, "network")

    def test_enformion_api_error_creation(self):
        """Test EnformionAPIError creation"""
        error = EnformionAPIError(
            message="Test error",
            error_type=ErrorType.RATE_LIMIT,
            status_code=429,
            retry_after=60,
            credit_cost=2
        )
        
        self.assertEqual(str(error), "Test error")
        self.assertEqual(error.error_type, ErrorType.RATE_LIMIT)
        self.assertEqual(error.status_code, 429)
        self.assertEqual(error.retry_after, 60)
        self.assertEqual(error.credit_cost, 2)
        self.assertIsNotNone(error.timestamp)

    def test_error_retryability(self):
        """Test error retryability logic"""
        # Retryable errors
        retryable_error = EnformionAPIError("Rate limited", error_type=ErrorType.RATE_LIMIT)
        self.assertTrue(retryable_error.is_retryable())
        
        network_error = EnformionAPIError("Network error", error_type=ErrorType.NETWORK)
        self.assertTrue(network_error.is_retryable())
        
        timeout_error = EnformionAPIError("Timeout", error_type=ErrorType.TIMEOUT)
        self.assertTrue(timeout_error.is_retryable())
        
        # Non-retryable errors
        auth_error = EnformionAPIError("Auth failed", error_type=ErrorType.AUTHENTICATION)
        self.assertFalse(auth_error.is_retryable())
        
        validation_error = EnformionAPIError("Invalid input", error_type=ErrorType.VALIDATION)
        self.assertFalse(validation_error.is_retryable())


class TestIntegrationScenarios(unittest.TestCase):
    """Integration test scenarios"""

    def test_complete_investigation_workflow(self):
        """Test complete investigation workflow using mock client"""
        client = MockEnformionClient()
        
        # Step 1: Phone lookup
        phone_result = client.reverse_phone_search("9103925349")
        self.assertEqual(client.total_requests, 1)
        
        # Step 2: Address search based on phone result
        address_result = client.address_search("123 Main St", city="Charlotte", state="NC")
        self.assertEqual(client.total_requests, 2)
        
        # Step 3: Email search for residents
        email_result = client.email_search("john.smith@example.com")
        self.assertEqual(client.total_requests, 3)
        
        # Step 4: Check account status
        status = client.get_account_status()
        self.assertEqual(status["_client_stats"]["total_requests"], 3)

    def test_bulk_investigation_workflow(self):
        """Test bulk investigation workflow"""
        client = MockEnformionClient()
        
        # Prepare bulk requests
        bulk_requests = [
            {"phone": "9103925349"},
            {"phone": "7045551234"},
            {"email": "test1@example.com"},
            {"email": "test2@example.com"},
            {"address": "123 Main St", "city": "Charlotte"},
            {"address": "456 Oak Ave", "city": "Raleigh"}
        ]
        
        # Submit bulk search
        bulk_result = client.bulk_search(bulk_requests, search_type="mixed")
        
        self.assertIn("job_id", bulk_result)
        self.assertEqual(bulk_result["total_requests"], 6)
        self.assertIn("_sleuth_metadata", bulk_result)
        
        # Verify estimated credits
        metadata = bulk_result["_sleuth_metadata"]
        self.assertEqual(metadata["total_requests"], 6)
        self.assertEqual(metadata["estimated_credits"], 6)

    def test_error_handling_and_recovery(self):
        """Test error handling and recovery mechanisms"""
        with patch('src.providers.enhanced_enformion_client.api_locker_manager') as mock_locker:
            mock_credential = Mock()
            mock_credential.key_name = "test_key"
            mock_credential.key_value = "test_api_key"
            mock_locker.get_credential.return_value = mock_credential
            
            client = EnformionClient()
            
            # Test validation error
            with self.assertRaises(EnformionAPIError) as context:
                client.reverse_phone_search("invalid")
            self.assertEqual(context.exception.error_type, ErrorType.VALIDATION)
            
            # Test email validation error
            with self.assertRaises(EnformionAPIError) as context:
                client.email_search("invalid-email")
            self.assertEqual(context.exception.error_type, ErrorType.VALIDATION)


if __name__ == '__main__':
    # Set up logging for tests
    logging.basicConfig(level=logging.INFO)
    
    # Run tests
    unittest.main(verbosity=2)