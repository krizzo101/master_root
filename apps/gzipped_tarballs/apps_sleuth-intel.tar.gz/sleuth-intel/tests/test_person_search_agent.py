"""
Unit tests for PersonSearchAgent
Comprehensive testing of person search functionality, caching, and error handling
"""

import json
import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

from src.agents.person_search_agent import PersonSearchAgent
from src.models.person import PersonProfile, PersonName, Demographics, Phone, Email, Address
from src.models.query import PersonSearchQuery
from src.providers.enformion_client import EnformionAPIError
from src.core.secure_api_locker import APICredential


class TestPersonSearchAgent:
    """Test suite for PersonSearchAgent"""

    @pytest.fixture
    def mock_api_credential(self):
        """Mock API credential for testing"""
        return APICredential(
            key_name="test_enformion_key",
            key_value="test_api_key_123",
            password="test_password",
            provider="enformion"
        )

    @pytest.fixture
    def mock_enformion_response(self):
        """Mock EnformionGO API response"""
        return {
            "results": [
                {
                    "first_name": "John",
                    "last_name": "Doe",
                    "full_name": "John Michael Doe",
                    "age": 35,
                    "phones": [
                        {"number": "5551234567", "type": "mobile"},
                        {"number": "5559876543", "type": "landline"}
                    ],
                    "emails": ["john.doe@email.com", "j.doe@work.com"],
                    "addresses": [
                        {
                            "street": "123 Main St",
                            "city": "Anytown",
                            "state": "CA",
                            "zip_code": "90210"
                        }
                    ],
                    "relatives": [
                        {
                            "first_name": "Jane",
                            "last_name": "Doe",
                            "relationship": "spouse"
                        }
                    ]
                },
                {
                    "first_name": "Jonathan",
                    "last_name": "Doe",
                    "age": 42,
                    "phones": [{"number": "5555551234", "type": "mobile"}],
                    "addresses": [
                        {
                            "street": "456 Oak Ave",
                            "city": "Different City",
                            "state": "CA",
                            "zip_code": "90211"
                        }
                    ]
                }
            ]
        }

    @pytest.fixture
    def agent(self, mock_api_credential):
        """Create PersonSearchAgent instance for testing"""
        with patch('src.agents.person_search_agent.APILockerManager') as mock_locker_manager:
            mock_manager = Mock()
            mock_manager.get_credential.return_value = mock_api_credential
            mock_locker_manager.get_instance.return_value = mock_manager
            
            with patch('src.agents.person_search_agent.EnformionClient') as mock_client:
                agent = PersonSearchAgent(fuzzy_threshold=0.8)
                agent.enformion_client = mock_client.return_value
                return agent

    def test_agent_initialization(self, agent):
        """Test agent initialization"""
        assert agent.provider == "enformion"
        assert agent.agent_name == "PersonSearchAgent"
        assert agent.fuzzy_threshold == 0.8
        assert agent.max_age_variance == 5
        assert agent.location_radius_miles == 50

    def test_name_similarity_calculation(self, agent):
        """Test fuzzy name matching"""
        # Exact match
        assert agent._calculate_name_similarity("John Doe", "John Doe") == 1.0
        
        # Similar names
        assert agent._calculate_name_similarity("John", "Jon") > 0.7
        
        # Different names
        assert agent._calculate_name_similarity("John", "Mary") < 0.3
        
        # Empty strings
        assert agent._calculate_name_similarity("", "John") == 0.0
        assert agent._calculate_name_similarity("John", "") == 0.0

    def test_age_match_scoring(self, agent):
        """Test age matching logic"""
        # Exact match
        assert agent._calculate_age_match_score(35, 35) == 1.0
        
        # Within variance
        assert agent._calculate_age_match_score(35, 37) > 0.7
        
        # Outside variance
        assert agent._calculate_age_match_score(35, 50) < 0.5
        
        # Missing data
        assert agent._calculate_age_match_score(None, 35) == 0.5
        assert agent._calculate_age_match_score(35, None) == 0.5

    def test_location_match_scoring(self, agent):
        """Test location matching logic"""
        query_location = {"city": "Los Angeles", "state": "CA", "zip_code": "90210"}
        
        # Exact city and state match
        result_location = {"city": "Los Angeles", "state": "CA", "zip_code": "90210"}
        assert agent._calculate_location_match_score(query_location, result_location) == 1.0
        
        # City match only
        result_location = {"city": "Los Angeles", "state": "NY", "zip_code": "10001"}
        score = agent._calculate_location_match_score(query_location, result_location)
        assert 0.7 < score < 1.0
        
        # State match only
        result_location = {"city": "San Francisco", "state": "CA", "zip_code": "94102"}
        score = agent._calculate_location_match_score(query_location, result_location)
        assert 0.5 < score < 0.7
        
        # No match
        result_location = {"city": "New York", "state": "NY", "zip_code": "10001"}
        score = agent._calculate_location_match_score(query_location, result_location)
        assert score < 0.5

    def test_phone_number_formatting(self, agent):
        """Test phone number formatting"""
        assert agent._format_phone_number("5551234567") == "(555) 123-4567"
        assert agent._format_phone_number("15551234567") == "+1 (555) 123-4567"
        assert agent._format_phone_number("123") == "123"  # Invalid length

    def test_data_validation_and_cleanup(self, agent):
        """Test data validation and cleanup"""
        raw_data = {
            "first_name": "  john  ",
            "last_name": "DOE",
            "age": "35",
            "phones": ["555-123-4567", {"number": "(555) 987-6543", "type": "mobile"}],
            "addresses": [{"street": "123 Main St", "city": "  anytown  ", "state": "ca"}],
            "emails": ["JOHN.DOE@EMAIL.COM", {"address": "j.doe@work.com"}]
        }
        
        cleaned = agent._validate_and_cleanup_data(raw_data)
        
        assert cleaned["first_name"] == "John"
        assert cleaned["last_name"] == "Doe"
        assert cleaned["age"] == 35
        assert len(cleaned["phones"]) == 2
        assert cleaned["phones"][0]["number"] == "5551234567"
        assert cleaned["phones"][1]["type"] == "mobile"
        assert cleaned["addresses"][0]["city"] == "anytown"
        assert cleaned["addresses"][0]["state"] == "ca"
        assert "john.doe@email.com" in cleaned["emails"]

    def test_convert_to_person_profile(self, agent, mock_enformion_response):
        """Test conversion of API response to PersonProfile"""
        query = PersonSearchQuery(first_name="John", last_name="Doe")
        raw_result = mock_enformion_response["results"][0]
        
        profile = agent._convert_to_person_profile(raw_result, query)
        
        assert isinstance(profile, PersonProfile)
        assert profile.name.first == "John"
        assert profile.name.last == "Doe"
        assert profile.demographics.age == 35
        assert len(profile.phones) == 2
        assert len(profile.emails) == 2
        assert len(profile.addresses) == 1
        assert len(profile.associates) == 1
        assert profile.source_provider == "enformion"
        assert 0 <= profile.confidence_score <= 1

    def test_confidence_scoring(self, agent, mock_enformion_response):
        """Test confidence scoring algorithm"""
        # High confidence: exact name and location match
        query = PersonSearchQuery(
            first_name="John",
            last_name="Doe",
            city="Anytown",
            state="CA"
        )
        raw_result = mock_enformion_response["results"][0]
        
        score = agent._score_result_confidence(query, raw_result)
        assert score > 0.8
        
        # Lower confidence: partial match
        query = PersonSearchQuery(
            first_name="Jonathan",  # Similar but not exact
            last_name="Doe",
            city="Different City",
            state="CA"
        )
        
        score = agent._score_result_confidence(query, raw_result)
        assert 0.3 < score < 0.8

    def test_cache_key_generation(self, agent):
        """Test cache key generation"""
        query1 = PersonSearchQuery(first_name="John", last_name="Doe", city="LA")
        query2 = PersonSearchQuery(first_name="john", last_name="doe", city="la")  # Different case
        query3 = PersonSearchQuery(first_name="Jane", last_name="Doe", city="LA")
        
        key1 = agent._generate_search_cache_key(query1)
        key2 = agent._generate_search_cache_key(query2)
        key3 = agent._generate_search_cache_key(query3)
        
        # Same parameters should generate same key (case insensitive)
        assert key1 == key2
        
        # Different parameters should generate different keys
        assert key1 != key3

    @patch('src.agents.person_search_agent.EnformionClient')
    def test_successful_search(self, mock_client_class, agent, mock_enformion_response):
        """Test successful person search"""
        # Setup mock
        mock_client = Mock()
        mock_client.person_search.return_value = mock_enformion_response
        agent.enformion_client = mock_client
        
        query = PersonSearchQuery(
            first_name="John",
            last_name="Doe",
            city="Anytown",
            state="CA",
            max_results=10
        )
        
        results = agent.search(query, use_cache=False)
        
        assert len(results) == 2
        assert all(isinstance(result, PersonProfile) for result in results)
        assert results[0].confidence_score >= results[1].confidence_score  # Sorted by confidence
        
        # Verify API was called correctly
        mock_client.person_search.assert_called_once_with(
            first_name="John",
            last_name="Doe",
            city="Anytown",
            state="CA"
        )

    @patch('src.agents.person_search_agent.EnformionClient')
    def test_search_with_phone(self, mock_client_class, agent, mock_enformion_response):
        """Test search by phone number"""
        mock_client = Mock()
        mock_client.person_search.return_value = mock_enformion_response
        agent.enformion_client = mock_client
        
        results = agent.search_by_phone("555-123-4567")
        
        assert len(results) == 2
        mock_client.person_search.assert_called_once()

    def test_search_insufficient_params(self, agent):
        """Test search with insufficient parameters"""
        query = PersonSearchQuery()  # Empty query
        
        with pytest.raises(ValueError, match="insufficient parameters"):
            agent.search(query)

    @patch('src.agents.person_search_agent.EnformionClient')
    def test_search_api_error(self, mock_client_class, agent):
        """Test search with API error"""
        mock_client = Mock()
        mock_client.person_search.side_effect = EnformionAPIError("API Error")
        agent.enformion_client = mock_client
        
        query = PersonSearchQuery(first_name="John", last_name="Doe")
        
        with pytest.raises(EnformionAPIError):
            agent.search(query)

    @patch('src.agents.person_search_agent.EnformionClient')
    def test_search_empty_results(self, mock_client_class, agent):
        """Test search with no results"""
        mock_client = Mock()
        mock_client.person_search.return_value = {"results": []}
        agent.enformion_client = mock_client
        
        query = PersonSearchQuery(first_name="NonExistent", last_name="Person")
        results = agent.search(query)
        
        assert results == []

    @patch('src.agents.person_search_agent.EnformionClient')
    def test_caching_functionality(self, mock_client_class, agent, mock_enformion_response):
        """Test caching of search results"""
        mock_client = Mock()
        mock_client.person_search.return_value = mock_enformion_response
        agent.enformion_client = mock_client
        
        query = PersonSearchQuery(first_name="John", last_name="Doe")
        
        # First search - should call API
        results1 = agent.search(query, use_cache=True)
        assert mock_client.person_search.call_count == 1
        
        # Second search - should use cache
        results2 = agent.search(query, use_cache=True)
        assert mock_client.person_search.call_count == 1  # Still only called once
        
        # Results should be identical
        assert len(results1) == len(results2)
        assert results1[0].name.display_name == results2[0].name.display_name

    def test_age_filter_search(self, agent):
        """Test search with age filtering"""
        with patch.object(agent.enformion_client, 'person_search') as mock_search:
            mock_search.return_value = {"results": []}
            
            results = agent.search_with_age_filter(
                first_name="John",
                last_name="Doe",
                age_min=30,
                age_max=40,
                city="Anytown"
            )
            
            assert results == []
            mock_search.assert_called_once()

    def test_duplicate_detection(self, agent):
        """Test duplicate profile detection"""
        # Create test profiles with similar data
        profile1 = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            phones=[Phone(number="5551234567")],
            source_provider="enformion"
        )
        
        profile2 = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            phones=[Phone(number="5551234567")],
            source_provider="enformion"
        )
        
        profile3 = PersonProfile(
            name=PersonName(first="Jane", last="Smith"),
            phones=[Phone(number="5559876543")],
            source_provider="enformion"
        )
        
        profiles = [profile1, profile2, profile3]
        duplicates = agent.find_duplicates(profiles, similarity_threshold=0.9)
        
        assert len(duplicates) == 1
        assert duplicates[0][0] == profile1
        assert duplicates[0][1] == profile2
        assert duplicates[0][2] > 0.9

    def test_query_interface(self, agent):
        """Test the BaseIntelligenceAgent query interface"""
        with patch.object(agent, 'search') as mock_search:
            mock_search.return_value = []
            
            query_params = {
                "first_name": "John",
                "last_name": "Doe",
                "city": "Anytown"
            }
            
            agent.query(query_params)
            
            mock_search.assert_called_once()
            call_args = mock_search.call_args[0][0]
            assert isinstance(call_args, PersonSearchQuery)
            assert call_args.first_name == "John"
            assert call_args.last_name == "Doe"
            assert call_args.city == "Anytown"

    def test_health_check(self, agent):
        """Test agent health check"""
        health = agent.health_check()
        
        assert "status" in health
        assert "person_search_ready" in health
        assert "fuzzy_threshold" in health
        assert health["fuzzy_threshold"] == 0.8

    def test_confidence_threshold_filtering(self, agent, mock_enformion_response):
        """Test filtering results by confidence threshold"""
        with patch.object(agent.enformion_client, 'person_search') as mock_search:
            mock_search.return_value = mock_enformion_response
            
            # High confidence threshold should return fewer results
            query = PersonSearchQuery(
                first_name="John",
                last_name="Doe",
                min_confidence=0.95  # Very high threshold
            )
            
            results = agent.search(query, use_cache=False)
            
            # All returned results should meet the confidence threshold
            for result in results:
                assert result.confidence_score >= 0.95

    def test_max_results_limit(self, agent):
        """Test max results limiting"""
        # Create mock response with many results
        many_results = {
            "results": [
                {
                    "first_name": f"Person{i}",
                    "last_name": "Test",
                    "age": 30 + i
                } for i in range(20)  # 20 results
            ]
        }
        
        with patch.object(agent.enformion_client, 'person_search') as mock_search:
            mock_search.return_value = many_results
            
            query = PersonSearchQuery(
                first_name="Person",
                last_name="Test",
                max_results=5
            )
            
            results = agent.search(query, use_cache=False)
            
            # Should be limited to max_results
            assert len(results) <= 5

    @pytest.mark.parametrize("fuzzy_threshold,expected_behavior", [
        (0.9, "strict matching"),
        (0.7, "moderate matching"), 
        (0.5, "loose matching")
    ])
    def test_fuzzy_threshold_behavior(self, mock_api_credential, fuzzy_threshold, expected_behavior):
        """Test different fuzzy matching thresholds"""
        with patch('src.agents.person_search_agent.APILockerManager') as mock_locker_manager:
            mock_manager = Mock()
            mock_manager.get_credential.return_value = mock_api_credential
            mock_locker_manager.get_instance.return_value = mock_manager
            
            with patch('src.agents.person_search_agent.EnformionClient'):
                agent = PersonSearchAgent(fuzzy_threshold=fuzzy_threshold)
                assert agent.fuzzy_threshold == fuzzy_threshold

    def test_authentication_application(self, agent, mock_api_credential):
        """Test authentication header application"""
        request_kwargs = {"headers": {}}
        
        result = agent._apply_authentication(mock_api_credential, request_kwargs)
        
        assert "X-API-Key" in result["headers"]
        assert "X-API-Password" in result["headers"]
        assert result["headers"]["X-API-Key"] == "test_api_key_123"
        assert result["headers"]["X-API-Password"] == "test_password"

    def test_authentication_fallback(self, agent):
        """Test authentication fallback to bearer token"""
        credential = APICredential(
            key_name="test_key",
            key_value="test_token",
            password=None,  # No password - should use bearer token
            provider="enformion"
        )
        
        request_kwargs = {"headers": {}}
        result = agent._apply_authentication(credential, request_kwargs)
        
        assert "Authorization" in result["headers"]
        assert result["headers"]["Authorization"] == "Bearer test_token"