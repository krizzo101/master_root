"""Unit tests for API clients."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import aiohttp
import pytest
from httpx import AsyncClient, Response

from src.providers.enhanced_enformion_client import EnhancedEnformionClient
from tests.fixtures.mock_data import MockDataGenerator


class TestEnhancedEnformionClient:
    """Test EnhancedEnformionClient functionality."""
    
    @pytest.fixture
    def client(self):
        """Create an EnhancedEnformionClient instance."""
        return EnhancedEnformionClient(
            api_key="test_key",
            base_url="https://api.test.com"
        )
    
    @pytest.fixture
    def mock_response(self):
        """Create a mock HTTP response."""
        response = MagicMock(spec=Response)
        response.status_code = 200
        response.json.return_value = {"status": "success", "data": []}
        response.text = '{"status": "success", "data": []}'
        return response
    
    @pytest.mark.asyncio
    async def test_client_initialization(self, client):
        """Test client initialization."""
        assert client.api_key == "test_key"
        assert client.base_url == "https://api.test.com"
        assert client.max_retries == 3
        assert client.timeout == 30
    
    @pytest.mark.asyncio
    async def test_search_person(self, client, mock_response, mock_data_generator):
        """Test person search API call."""
        mock_person = mock_data_generator.create_person()
        mock_response.json.return_value = {
            "status": "success",
            "data": [mock_person.__dict__]
        }
        
        with patch.object(client, '_make_request', return_value=mock_response.json.return_value):
            result = await client.search_person(
                first_name="John",
                last_name="Doe"
            )
            
            assert result["status"] == "success"
            assert len(result["data"]) == 1
    
    @pytest.mark.asyncio
    async def test_search_business(self, client, mock_response, mock_data_generator):
        """Test business search API call."""
        mock_business = mock_data_generator.create_business()
        mock_response.json.return_value = {
            "status": "success",
            "data": [mock_business.__dict__]
        }
        
        with patch.object(client, '_make_request', return_value=mock_response.json.return_value):
            result = await client.search_business(name="Tech Corp")
            
            assert result["status"] == "success"
            assert len(result["data"]) == 1
    
    @pytest.mark.asyncio
    async def test_retry_logic(self, client):
        """Test retry logic on failure."""
        with patch.object(client, '_make_request') as mock_request:
            mock_request.side_effect = [
                aiohttp.ClientError("Connection error"),
                aiohttp.ClientError("Connection error"),
                {"status": "success", "data": []}
            ]
            
            result = await client.search_person(
                first_name="John",
                last_name="Doe"
            )
            
            assert mock_request.call_count == 3
            assert result["status"] == "success"
    
    @pytest.mark.asyncio
    async def test_max_retries_exceeded(self, client):
        """Test behavior when max retries are exceeded."""
        with patch.object(client, '_make_request') as mock_request:
            mock_request.side_effect = aiohttp.ClientError("Connection error")
            
            with pytest.raises(aiohttp.ClientError):
                await client.search_person(
                    first_name="John",
                    last_name="Doe"
                )
            
            assert mock_request.call_count == client.max_retries
    
    @pytest.mark.asyncio
    async def test_timeout_handling(self, client):
        """Test timeout handling."""
        with patch.object(client, '_make_request') as mock_request:
            mock_request.side_effect = asyncio.TimeoutError()
            
            with pytest.raises(asyncio.TimeoutError):
                await client.search_person(
                    first_name="John",
                    last_name="Doe"
                )
    
    @pytest.mark.asyncio
    async def test_rate_limiting(self, client):
        """Test rate limiting implementation."""
        client.rate_limiter = MagicMock()
        client.rate_limiter.acquire = AsyncMock()
        
        with patch.object(client, '_make_request', return_value={"status": "success"}):
            await client.search_person(first_name="John", last_name="Doe")
            
            client.rate_limiter.acquire.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_caching(self, client, mock_redis_client):
        """Test caching functionality."""
        client.cache = mock_redis_client
        
        cached_data = {"status": "success", "data": [{"name": "John Doe"}]}
        mock_redis_client.get.return_value = json.dumps(cached_data)
        
        result = await client.search_person(
            first_name="John",
            last_name="Doe",
            use_cache=True
        )
        
        assert result == cached_data
        mock_redis_client.get.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_cache_miss(self, client, mock_redis_client):
        """Test cache miss scenario."""
        client.cache = mock_redis_client
        mock_redis_client.get.return_value = None
        
        api_response = {"status": "success", "data": []}
        with patch.object(client, '_make_request', return_value=api_response):
            result = await client.search_person(
                first_name="John",
                last_name="Doe",
                use_cache=True
            )
            
            assert result == api_response
            mock_redis_client.set.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_batch_search(self, client):
        """Test batch search functionality."""
        queries = [
            {"first_name": "John", "last_name": "Doe"},
            {"first_name": "Jane", "last_name": "Smith"},
            {"first_name": "Bob", "last_name": "Johnson"}
        ]
        
        with patch.object(client, 'search_person', return_value={"status": "success", "data": []}):
            results = await client.batch_search_persons(queries)
            
            assert len(results) == 3
            assert all(r["status"] == "success" for r in results)
    
    @pytest.mark.asyncio
    async def test_error_response_handling(self, client):
        """Test handling of error responses from API."""
        error_response = {
            "status": "error",
            "message": "Invalid parameters",
            "code": 400
        }
        
        with patch.object(client, '_make_request', return_value=error_response):
            result = await client.search_person(first_name="", last_name="")
            
            assert result["status"] == "error"
            assert "message" in result
    
    @pytest.mark.asyncio
    async def test_response_validation(self, client):
        """Test response validation."""
        invalid_response = {"invalid": "structure"}
        
        with patch.object(client, '_make_request', return_value=invalid_response):
            with pytest.raises(ValueError):
                await client.search_person(
                    first_name="John",
                    last_name="Doe",
                    validate_response=True
                )
    
    @pytest.mark.asyncio
    async def test_header_injection(self, client):
        """Test custom header injection."""
        custom_headers = {
            "X-Custom-Header": "test_value",
            "X-Request-ID": "123456"
        }
        
        with patch.object(client, '_make_request') as mock_request:
            mock_request.return_value = {"status": "success"}
            
            await client.search_person(
                first_name="John",
                last_name="Doe",
                headers=custom_headers
            )
            
            call_args = mock_request.call_args
            assert "headers" in call_args[1]
            assert call_args[1]["headers"]["X-Custom-Header"] == "test_value"
    
    @pytest.mark.asyncio
    async def test_pagination(self, client):
        """Test pagination handling."""
        page1_response = {
            "status": "success",
            "data": [{"id": 1}, {"id": 2}],
            "pagination": {
                "page": 1,
                "total_pages": 3,
                "next_page": 2
            }
        }
        
        page2_response = {
            "status": "success",
            "data": [{"id": 3}, {"id": 4}],
            "pagination": {
                "page": 2,
                "total_pages": 3,
                "next_page": 3
            }
        }
        
        with patch.object(client, '_make_request') as mock_request:
            mock_request.side_effect = [page1_response, page2_response]
            
            results = await client.search_person_paginated(
                first_name="John",
                last_name="Doe",
                max_pages=2
            )
            
            assert len(results) == 4
            assert mock_request.call_count == 2


class TestAPIClientMetrics:
    """Test API client metrics and monitoring."""
    
    @pytest.fixture
    def client_with_metrics(self):
        """Create a client with metrics enabled."""
        client = EnhancedEnformionClient(
            api_key="test_key",
            enable_metrics=True
        )
        return client
    
    @pytest.mark.asyncio
    async def test_request_metrics(self, client_with_metrics):
        """Test request metrics collection."""
        with patch.object(client_with_metrics, '_make_request', return_value={"status": "success"}):
            await client_with_metrics.search_person(
                first_name="John",
                last_name="Doe"
            )
            
            metrics = client_with_metrics.get_metrics()
            assert "total_requests" in metrics
            assert metrics["total_requests"] == 1
    
    @pytest.mark.asyncio
    async def test_error_metrics(self, client_with_metrics):
        """Test error metrics collection."""
        with patch.object(client_with_metrics, '_make_request', side_effect=Exception("API Error")):
            with pytest.raises(Exception):
                await client_with_metrics.search_person(
                    first_name="John",
                    last_name="Doe"
                )
            
            metrics = client_with_metrics.get_metrics()
            assert "total_errors" in metrics
            assert metrics["total_errors"] == 1
    
    @pytest.mark.asyncio
    async def test_latency_metrics(self, client_with_metrics, performance_timer):
        """Test latency metrics collection."""
        with patch.object(client_with_metrics, '_make_request') as mock_request:
            async def delayed_response(*args, **kwargs):
                await asyncio.sleep(0.1)
                return {"status": "success"}
            
            mock_request.side_effect = delayed_response
            
            with performance_timer as timer:
                await client_with_metrics.search_person(
                    first_name="John",
                    last_name="Doe"
                )
            
            assert timer.elapsed >= 0.1
            
            metrics = client_with_metrics.get_metrics()
            assert "average_latency" in metrics
            assert metrics["average_latency"] >= 0.1