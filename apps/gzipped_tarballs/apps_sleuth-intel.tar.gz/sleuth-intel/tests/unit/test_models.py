"""Unit tests for data models and validation."""

from datetime import datetime

import pytest
from pydantic import ValidationError

from src.models import Person, Business, Query, IntelligenceReport


class TestPersonModel:
    """Test Person model."""
    
    def test_create_person_minimal(self):
        """Test creating a person with minimal data."""
        person = Person(
            first_name="John",
            last_name="Doe"
        )
        
        assert person.first_name == "John"
        assert person.last_name == "Doe"
        assert person.full_name == "John Doe"
        assert person.emails == []
        assert person.phones == []
    
    def test_create_person_full(self):
        """Test creating a person with full data."""
        person = Person(
            first_name="John",
            middle_name="Robert",
            last_name="Doe",
            age=35,
            date_of_birth="1989-01-15",
            emails=["john.doe@example.com"],
            phones=["(555) 123-4567"],
            addresses=[{
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001"
            }],
            ssn_last_four="1234",
            employment={
                "company": "Tech Corp",
                "position": "Engineer"
            }
        )
        
        assert person.full_name == "John Robert Doe"
        assert person.age == 35
        assert len(person.emails) == 1
        assert len(person.phones) == 1
        assert len(person.addresses) == 1
    
    def test_person_validation_errors(self):
        """Test person model validation errors."""
        with pytest.raises(ValidationError):
            Person()
        
        with pytest.raises(ValidationError):
            Person(first_name="John")
        
        with pytest.raises(ValidationError):
            Person(last_name="Doe")
    
    def test_person_email_validation(self):
        """Test email validation in person model."""
        with pytest.raises(ValidationError):
            Person(
                first_name="John",
                last_name="Doe",
                emails=["invalid-email"]
            )
    
    def test_person_serialization(self):
        """Test person model serialization."""
        person = Person(
            first_name="John",
            last_name="Doe",
            emails=["john@example.com"]
        )
        
        data = person.model_dump()
        assert data["first_name"] == "John"
        assert data["last_name"] == "Doe"
        assert "emails" in data
        
        json_str = person.model_dump_json()
        assert "John" in json_str
        assert "Doe" in json_str


class TestBusinessModel:
    """Test Business model."""
    
    def test_create_business_minimal(self):
        """Test creating a business with minimal data."""
        business = Business(
            name="Tech Solutions LLC"
        )
        
        assert business.name == "Tech Solutions LLC"
        assert business.type is None
        assert business.ein is None
        assert business.addresses == []
    
    def test_create_business_full(self):
        """Test creating a business with full data."""
        business = Business(
            name="Tech Solutions LLC",
            type="LLC",
            ein="12-3456789",
            formation_date="2020-01-15",
            status="Active",
            addresses=[{
                "street": "456 Business Ave",
                "city": "San Francisco",
                "state": "CA",
                "zip": "94105"
            }],
            phones=["(555) 987-6543"],
            website="www.techsolutions.com",
            email="info@techsolutions.com",
            industry="Technology",
            naics_code="541511",
            employees=50,
            revenue=5000000
        )
        
        assert business.name == "Tech Solutions LLC"
        assert business.type == "LLC"
        assert business.ein == "12-3456789"
        assert business.status == "Active"
        assert business.employees == 50
        assert business.revenue == 5000000
    
    def test_business_validation_errors(self):
        """Test business model validation errors."""
        with pytest.raises(ValidationError):
            Business()
        
        with pytest.raises(ValidationError):
            Business(name="")
    
    def test_business_email_validation(self):
        """Test email validation in business model."""
        with pytest.raises(ValidationError):
            Business(
                name="Tech Corp",
                email="invalid-email"
            )
    
    def test_business_officers(self):
        """Test business officers field."""
        business = Business(
            name="Tech Corp",
            officers=[
                {
                    "name": "John Doe",
                    "title": "CEO",
                    "start_date": "2020-01-01"
                },
                {
                    "name": "Jane Smith",
                    "title": "CFO",
                    "start_date": "2020-06-01"
                }
            ]
        )
        
        assert len(business.officers) == 2
        assert business.officers[0]["title"] == "CEO"
        assert business.officers[1]["name"] == "Jane Smith"


class TestQueryModel:
    """Test Query model."""
    
    def test_create_query(self):
        """Test creating a query."""
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "John",
                "last_name": "Doe"
            }
        )
        
        assert query.query_type == "person_search"
        assert query.parameters["first_name"] == "John"
        assert query.metadata == {}
    
    def test_query_with_metadata(self):
        """Test query with metadata."""
        query = Query(
            query_type="business_search",
            parameters={"name": "Tech Corp"},
            metadata={
                "request_id": "123",
                "user": "test_user",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        assert query.query_type == "business_search"
        assert query.metadata["request_id"] == "123"
        assert query.metadata["user"] == "test_user"
    
    def test_query_validation(self):
        """Test query validation."""
        with pytest.raises(ValidationError):
            Query()
        
        with pytest.raises(ValidationError):
            Query(query_type="person_search")
        
        with pytest.raises(ValidationError):
            Query(parameters={})
    
    def test_query_types(self):
        """Test different query types."""
        query_types = [
            "person_search",
            "business_search",
            "email_search",
            "phone_search",
            "address_search"
        ]
        
        for qt in query_types:
            query = Query(
                query_type=qt,
                parameters={"test": "value"}
            )
            assert query.query_type == qt


class TestIntelligenceReportModel:
    """Test IntelligenceReport model."""
    
    def test_create_report_minimal(self):
        """Test creating a report with minimal data."""
        report = IntelligenceReport(
            subject="John Doe",
            summary="Test report"
        )
        
        assert report.subject == "John Doe"
        assert report.summary == "Test report"
        assert report.findings == []
        assert report.recommendations == []
    
    def test_create_report_full(self):
        """Test creating a report with full data."""
        report = IntelligenceReport(
            subject="John Doe",
            summary="Comprehensive background check",
            findings=[
                {
                    "category": "personal",
                    "confidence": 0.95,
                    "data": {
                        "name": "John Doe",
                        "age": 35,
                        "location": "New York"
                    }
                },
                {
                    "category": "employment",
                    "confidence": 0.85,
                    "data": {
                        "company": "Tech Corp",
                        "position": "Engineer"
                    }
                }
            ],
            risk_assessment={
                "level": "low",
                "score": 25,
                "factors": ["No criminal record", "Stable employment"]
            },
            recommendations=[
                "No immediate concerns",
                "Continue standard monitoring"
            ],
            metadata={
                "generated_at": datetime.now().isoformat(),
                "analyst": "system",
                "version": "1.0"
            }
        )
        
        assert len(report.findings) == 2
        assert report.findings[0]["confidence"] == 0.95
        assert report.risk_assessment["level"] == "low"
        assert len(report.recommendations) == 2
        assert "version" in report.metadata
    
    def test_report_validation(self):
        """Test report validation."""
        with pytest.raises(ValidationError):
            IntelligenceReport()
        
        with pytest.raises(ValidationError):
            IntelligenceReport(subject="John Doe")
        
        with pytest.raises(ValidationError):
            IntelligenceReport(summary="Test")
    
    def test_report_risk_levels(self):
        """Test different risk levels."""
        risk_levels = ["low", "medium", "high", "critical"]
        
        for level in risk_levels:
            report = IntelligenceReport(
                subject="Test Subject",
                summary="Test",
                risk_assessment={"level": level}
            )
            assert report.risk_assessment["level"] == level
    
    def test_report_serialization(self):
        """Test report serialization."""
        report = IntelligenceReport(
            subject="John Doe",
            summary="Test report",
            findings=[{"category": "test", "data": {}}]
        )
        
        data = report.model_dump()
        assert "subject" in data
        assert "summary" in data
        assert "findings" in data
        
        json_str = report.model_dump_json()
        assert "John Doe" in json_str
        assert "Test report" in json_str
    
    def test_report_finding_structure(self):
        """Test finding structure in report."""
        report = IntelligenceReport(
            subject="Test",
            summary="Test",
            findings=[
                {
                    "category": "personal",
                    "confidence": 0.9,
                    "data": {"test": "value"},
                    "source": "API",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        )
        
        finding = report.findings[0]
        assert "category" in finding
        assert "confidence" in finding
        assert "data" in finding
        assert finding["confidence"] >= 0 and finding["confidence"] <= 1