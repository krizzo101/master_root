"""Unit tests for agent functionality."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.agents import (
    PersonSearchAgent,
    BusinessSearchAgent,
    EmailSearchAgent,
    PhoneSearchAgent,
    AddressSearchAgent,
    AnalysisAgent,
    DataEnrichmentAgent
)
from tests.fixtures.mock_data import MockDataGenerator


class TestPersonSearchAgent:
    """Test PersonSearchAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create a PersonSearchAgent instance."""
        return PersonSearchAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_search_basic(self, agent, mock_data_generator):
        """Test basic person search."""
        mock_person = mock_data_generator.create_person()
        agent.api_client.search_person.return_value = [mock_person]
        
        result = await agent.search(first_name="John", last_name="Doe")
        
        assert len(result) == 1
        assert result[0].first_name == mock_person.first_name
        agent.api_client.search_person.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_search_with_filters(self, agent, mock_data_generator):
        """Test person search with filters."""
        people = mock_data_generator.create_bulk_persons(5)
        agent.api_client.search_person.return_value = people
        
        result = await agent.search(
            first_name="John",
            last_name="Doe",
            city="New York",
            state="NY",
            age_range=(25, 45)
        )
        
        assert len(result) == 5
        agent.api_client.search_person.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_validate_input(self, agent):
        """Test input validation."""
        assert await agent.validate_input(first_name="John", last_name="Doe")
        assert not await agent.validate_input()
        assert not await agent.validate_input(first_name="")
    
    @pytest.mark.asyncio
    async def test_error_handling(self, agent):
        """Test error handling in search."""
        agent.api_client.search_person.side_effect = Exception("API Error")
        
        with pytest.raises(Exception) as exc_info:
            await agent.search(first_name="John", last_name="Doe")
        
        assert "API Error" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_empty_results(self, agent):
        """Test handling of empty results."""
        agent.api_client.search_person.return_value = []
        
        result = await agent.search(first_name="NonExistent", last_name="Person")
        
        assert result == []
        agent.api_client.search_person.assert_called_once()


class TestBusinessSearchAgent:
    """Test BusinessSearchAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create a BusinessSearchAgent instance."""
        return BusinessSearchAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_search_by_name(self, agent, mock_data_generator):
        """Test business search by name."""
        mock_business = mock_data_generator.create_business()
        agent.api_client.search_business.return_value = [mock_business]
        
        result = await agent.search(name="Tech Solutions")
        
        assert len(result) == 1
        assert result[0].name == mock_business.name
        agent.api_client.search_business.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_search_by_ein(self, agent, mock_data_generator):
        """Test business search by EIN."""
        mock_business = mock_data_generator.create_business(ein="12-3456789")
        agent.api_client.search_business.return_value = [mock_business]
        
        result = await agent.search(ein="12-3456789")
        
        assert len(result) == 1
        assert result[0].ein == "12-3456789"
    
    @pytest.mark.asyncio
    async def test_search_with_industry_filter(self, agent, mock_data_generator):
        """Test business search with industry filter."""
        businesses = mock_data_generator.create_bulk_businesses(3)
        agent.api_client.search_business.return_value = businesses
        
        result = await agent.search(industry="Technology", state="CA")
        
        assert len(result) == 3
        agent.api_client.search_business.assert_called_with(
            industry="Technology",
            state="CA"
        )


class TestEmailSearchAgent:
    """Test EmailSearchAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create an EmailSearchAgent instance."""
        return EmailSearchAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_search_by_email(self, agent, mock_data_generator):
        """Test search by email address."""
        mock_person = mock_data_generator.create_person()
        agent.api_client.search_email.return_value = [mock_person]
        
        result = await agent.search(email="john.doe@example.com")
        
        assert len(result) == 1
        agent.api_client.search_email.assert_called_once_with(
            email="john.doe@example.com"
        )
    
    @pytest.mark.asyncio
    async def test_validate_email_format(self, agent):
        """Test email format validation."""
        assert await agent.validate_email("valid@email.com")
        assert not await agent.validate_email("invalid-email")
        assert not await agent.validate_email("@invalid.com")
        assert not await agent.validate_email("invalid@")


class TestPhoneSearchAgent:
    """Test PhoneSearchAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create a PhoneSearchAgent instance."""
        return PhoneSearchAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_search_by_phone(self, agent, mock_data_generator):
        """Test search by phone number."""
        mock_person = mock_data_generator.create_person()
        agent.api_client.search_phone.return_value = [mock_person]
        
        result = await agent.search(phone="(555) 123-4567")
        
        assert len(result) == 1
        agent.api_client.search_phone.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_normalize_phone_number(self, agent):
        """Test phone number normalization."""
        normalized = agent.normalize_phone("(555) 123-4567")
        assert normalized == "5551234567"
        
        normalized = agent.normalize_phone("555-123-4567")
        assert normalized == "5551234567"
        
        normalized = agent.normalize_phone("555.123.4567")
        assert normalized == "5551234567"


class TestAddressSearchAgent:
    """Test AddressSearchAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create an AddressSearchAgent instance."""
        return AddressSearchAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_search_by_address(self, agent, mock_data_generator):
        """Test search by address."""
        people = mock_data_generator.create_bulk_persons(2)
        agent.api_client.search_address.return_value = people
        
        result = await agent.search(
            street="123 Main St",
            city="New York",
            state="NY",
            zip_code="10001"
        )
        
        assert len(result) == 2
        agent.api_client.search_address.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_partial_address_search(self, agent, mock_data_generator):
        """Test search with partial address."""
        people = mock_data_generator.create_bulk_persons(3)
        agent.api_client.search_address.return_value = people
        
        result = await agent.search(city="Los Angeles", state="CA")
        
        assert len(result) == 3
        agent.api_client.search_address.assert_called_with(
            city="Los Angeles",
            state="CA"
        )


class TestAnalysisAgent:
    """Test AnalysisAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_openai_client):
        """Create an AnalysisAgent instance."""
        return AnalysisAgent(ai_client=mock_openai_client)
    
    @pytest.mark.asyncio
    async def test_analyze_data(self, agent, mock_data_generator):
        """Test data analysis."""
        person = mock_data_generator.create_person()
        
        analysis = await agent.analyze(person)
        
        assert analysis is not None
        assert "Mock AI response" in analysis
        agent.ai_client.chat.completions.create.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_generate_report(self, agent, mock_data_generator):
        """Test report generation."""
        person = mock_data_generator.create_person()
        business = mock_data_generator.create_business()
        
        report = await agent.generate_report(
            subjects=[person, business],
            analysis_type="comprehensive"
        )
        
        assert report is not None
        assert agent.ai_client.chat.completions.create.called
    
    @pytest.mark.asyncio
    async def test_risk_assessment(self, agent, mock_data_generator):
        """Test risk assessment."""
        person = mock_data_generator.create_person()
        
        agent.ai_client.chat.completions.create.return_value = MagicMock(
            choices=[MagicMock(message=MagicMock(content='{"risk_level": "low", "score": 25}'))]
        )
        
        risk = await agent.assess_risk(person)
        
        assert risk is not None
        assert "risk_level" in risk
        assert risk["risk_level"] == "low"


class TestDataEnrichmentAgent:
    """Test DataEnrichmentAgent functionality."""
    
    @pytest.fixture
    def agent(self, mock_api_client):
        """Create a DataEnrichmentAgent instance."""
        return DataEnrichmentAgent(api_client=mock_api_client)
    
    @pytest.mark.asyncio
    async def test_enrich_person(self, agent, mock_data_generator):
        """Test person data enrichment."""
        person = mock_data_generator.create_person()
        enriched_data = {
            "social_media": {
                "facebook": "facebook.com/johndoe",
                "instagram": "@johndoe"
            },
            "employment_history": [
                {"company": "Tech Corp", "position": "Engineer", "years": 3}
            ]
        }
        
        agent.api_client.enrich_person = AsyncMock(return_value=enriched_data)
        
        result = await agent.enrich(person)
        
        assert result is not None
        assert "social_media" in result
        assert "employment_history" in result
        agent.api_client.enrich_person.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_enrich_business(self, agent, mock_data_generator):
        """Test business data enrichment."""
        business = mock_data_generator.create_business()
        enriched_data = {
            "financials": {
                "annual_revenue": 5000000,
                "employees": 50,
                "growth_rate": 0.15
            },
            "competitors": ["Competitor A", "Competitor B"]
        }
        
        agent.api_client.enrich_business = AsyncMock(return_value=enriched_data)
        
        result = await agent.enrich(business)
        
        assert result is not None
        assert "financials" in result
        assert "competitors" in result
        agent.api_client.enrich_business.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_batch_enrichment(self, agent, mock_data_generator):
        """Test batch data enrichment."""
        people = mock_data_generator.create_bulk_persons(5)
        
        agent.api_client.enrich_person = AsyncMock(return_value={})
        
        results = await agent.enrich_batch(people)
        
        assert len(results) == 5
        assert agent.api_client.enrich_person.call_count == 5