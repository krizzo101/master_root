"""
Test suite for AnalysisAgent
Comprehensive tests for intelligence analysis functionality
"""

import asyncio
import json
import pytest
import unittest
from datetime import datetime, timedelta
from typing import Dict, List, Any
from unittest.mock import Mock, patch, MagicMock

from src.agents.analysis_agent import (
    AnalysisAgent, RiskFactor, PatternMatch, NetworkNode, NetworkEdge,
    TimelineEvent, BehavioralPattern, AnalysisReport
)
from src.agents.base_agent import RateLimitConfig, RetryConfig, CacheConfig
from src.models.intelligence import ConfidenceLevel, ConfidenceScoring


class TestAnalysisAgent(unittest.TestCase):
    """Test cases for AnalysisAgent functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.analysis_agent = AnalysisAgent(
            provider="test_analysis",
            rate_limit_config=RateLimitConfig(requests_per_second=100.0),
            retry_config=RetryConfig(max_retries=1),
            cache_config=CacheConfig(enabled=False)  # Disable cache for testing
        )
        
        # Sample test data
        self.sample_person_data = [
            {
                "type": "person_profile",
                "name": {"first": "Test", "last": "Subject", "middle": "A"},
                "demographics": {"age": 35, "gender": "M"},
                "phones": [{"number": "+1-555-TEST-001", "type": "mobile"}],
                "emails": [{"address": "test@example.com", "type": "personal"}],
                "addresses": [{"street": "123 Test St", "city": "Test City", "state": "TS"}],
                "source": "test_data",
                "confidence": 0.9
            }
        ]
        
        self.sample_risk_data = [
            {
                "type": "financial_activity",
                "entity_id": "test_subject",
                "activities": [
                    {
                        "date": "2024-01-15",
                        "type": "large_cash_deposit", 
                        "amount": 15000,
                        "flags": ["unusual_amount", "cash_transaction"]
                    }
                ],
                "source": "test_financial",
                "confidence": 0.85
            }
        ]
        
        self.sample_network_data = [
            {
                "type": "entity_relationships",
                "relationships": [
                    {
                        "source": "person_001",
                        "source_type": "person",
                        "target": "business_001",
                        "target_type": "business", 
                        "relationship_type": "director",
                        "strength": 0.9,
                        "evidence": ["corporate_filing"]
                    }
                ],
                "source": "test_relationships",
                "confidence": 0.88
            }
        ]
    
    def test_agent_initialization(self):
        """Test AnalysisAgent initialization"""
        agent = AnalysisAgent()
        
        self.assertEqual(agent.agent_name, "AnalysisAgent")
        self.assertEqual(agent.provider, "analysis")
        self.assertEqual(agent.risk_threshold, 0.7)
        self.assertEqual(agent.pattern_significance_threshold, 0.05)
        self.assertEqual(agent.network_edge_threshold, 0.3)
        self.assertEqual(agent.anomaly_threshold, 2.5)
        
        # Check internal data structures
        self.assertIsInstance(agent.entity_cache, dict)
        self.assertIsInstance(agent.pattern_cache, dict)
        self.assertEqual(agent.analysis_count, 0)
        self.assertEqual(agent.pattern_detection_count, 0)
        self.assertEqual(agent.anomaly_detection_count, 0)
    
    def test_comprehensive_analysis_query(self):
        """Test comprehensive analysis query execution"""
        analysis_params = {
            'analysis_type': 'comprehensive',
            'data': self.sample_person_data,
            'focus_areas': ['risk', 'patterns', 'network', 'timeline', 'behavior']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Verify report structure
        self.assertIsInstance(report, AnalysisReport)
        self.assertEqual(report.analysis_type, 'comprehensive')
        self.assertIsInstance(report.report_id, str)
        self.assertIsInstance(report.query_id, str)
        self.assertIsInstance(report.timestamp, datetime)
        
        # Verify all analysis components are present
        self.assertIsInstance(report.risk_assessment, dict)
        self.assertIsInstance(report.pattern_analysis, dict)
        self.assertIsInstance(report.network_analysis, dict)
        self.assertIsInstance(report.timeline_analysis, dict)
        self.assertIsInstance(report.behavioral_analysis, dict)
        
        # Verify summary components
        self.assertIsInstance(report.executive_summary, str)
        self.assertIsInstance(report.key_findings, list)
        self.assertIsInstance(report.risk_recommendations, list)
        self.assertIsInstance(report.confidence_assessment, ConfidenceScoring)
        
        # Verify processing metrics
        self.assertIsInstance(report.processing_metrics, dict)
        self.assertIn('processing_time_seconds', report.processing_metrics)
        self.assertIn('data_points_analyzed', report.processing_metrics)
        
        # Verify agent metrics are updated
        self.assertEqual(self.analysis_agent.analysis_count, 1)
    
    def test_risk_assessment_only(self):
        """Test risk assessment focused analysis"""
        analysis_params = {
            'analysis_type': 'risk_only',
            'data': self.sample_risk_data,
            'focus_areas': ['risk']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should have risk assessment but not other components
        self.assertIsInstance(report.risk_assessment, dict)
        self.assertEqual(report.pattern_analysis, {})
        self.assertEqual(report.network_analysis, {})
        self.assertEqual(report.timeline_analysis, {})
        self.assertEqual(report.behavioral_analysis, {})
    
    def test_pattern_analysis_only(self):
        """Test pattern analysis focused analysis"""
        analysis_params = {
            'analysis_type': 'pattern_only',
            'data': self.sample_person_data,
            'focus_areas': ['patterns']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should have pattern analysis but not other components
        self.assertEqual(report.risk_assessment, {})
        self.assertIsInstance(report.pattern_analysis, dict)
        self.assertEqual(report.network_analysis, {})
        self.assertEqual(report.timeline_analysis, {})
        self.assertEqual(report.behavioral_analysis, {})
    
    def test_network_analysis_only(self):
        """Test network analysis focused analysis"""
        analysis_params = {
            'analysis_type': 'network_only',
            'data': self.sample_network_data,
            'focus_areas': ['network']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should have network analysis but not other components
        self.assertEqual(report.risk_assessment, {})
        self.assertEqual(report.pattern_analysis, {})
        self.assertIsInstance(report.network_analysis, dict)
        self.assertEqual(report.timeline_analysis, {})
        self.assertEqual(report.behavioral_analysis, {})
    
    def test_empty_data_handling(self):
        """Test handling of empty input data"""
        analysis_params = {
            'analysis_type': 'comprehensive',
            'data': [],
            'focus_areas': ['risk', 'patterns']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should complete without errors
        self.assertIsInstance(report, AnalysisReport)
        self.assertEqual(len(report.key_findings), 0)
        self.assertIsInstance(report.executive_summary, str)
    
    def test_invalid_analysis_type(self):
        """Test handling of invalid analysis type"""
        analysis_params = {
            'analysis_type': 'invalid_type',
            'data': self.sample_person_data,
            'focus_areas': ['risk']
        }
        
        # Should not raise exception, should handle gracefully
        report = self.analysis_agent.query(analysis_params)
        self.assertIsInstance(report, AnalysisReport)
        self.assertEqual(report.analysis_type, 'invalid_type')
    
    def test_risk_factor_serialization(self):
        """Test risk factor serialization"""
        risk_factor = RiskFactor(
            factor_type="identity_verification",
            description="Failed identity verification",
            risk_level=0.8,
            confidence=0.9,
            evidence=["document_mismatch", "photo_inconsistency"],
            source="kyc_system"
        )
        
        serialized = self.analysis_agent._serialize_risk_factor(risk_factor)
        
        self.assertEqual(serialized['factor_type'], "identity_verification")
        self.assertEqual(serialized['description'], "Failed identity verification")
        self.assertEqual(serialized['risk_level'], 0.8)
        self.assertEqual(serialized['confidence'], 0.9)
        self.assertEqual(serialized['evidence'], ["document_mismatch", "photo_inconsistency"])
        self.assertEqual(serialized['source'], "kyc_system")
        self.assertIn('timestamp', serialized)
    
    def test_pattern_match_serialization(self):
        """Test pattern match serialization"""
        pattern = PatternMatch(
            pattern_type="temporal",
            description="Regular weekly activity pattern",
            strength=0.85,
            frequency=52,
            entities=["person_001"],
            time_range=(datetime(2023, 1, 1), datetime(2023, 12, 31)),
            confidence=0.9,
            statistical_significance=0.01
        )
        
        serialized = self.analysis_agent._serialize_pattern(pattern)
        
        self.assertEqual(serialized['pattern_type'], "temporal")
        self.assertEqual(serialized['description'], "Regular weekly activity pattern")
        self.assertEqual(serialized['strength'], 0.85)
        self.assertEqual(serialized['frequency'], 52)
        self.assertEqual(serialized['entities'], ["person_001"])
        self.assertEqual(len(serialized['time_range']), 2)
        self.assertEqual(serialized['confidence'], 0.9)
        self.assertEqual(serialized['statistical_significance'], 0.01)
    
    def test_timeline_event_serialization(self):
        """Test timeline event serialization"""
        event = TimelineEvent(
            timestamp=datetime(2024, 1, 15, 14, 30),
            event_type="transaction",
            description="Large cash deposit",
            entities=["person_001", "bank_001"],
            confidence=0.9,
            source="financial_records",
            metadata={"amount": 15000, "currency": "USD"}
        )
        
        serialized = self.analysis_agent._serialize_timeline_event(event)
        
        self.assertEqual(serialized['event_type'], "transaction")
        self.assertEqual(serialized['description'], "Large cash deposit")
        self.assertEqual(serialized['entities'], ["person_001", "bank_001"])
        self.assertEqual(serialized['confidence'], 0.9)
        self.assertEqual(serialized['source'], "financial_records")
        self.assertEqual(serialized['metadata'], {"amount": 15000, "currency": "USD"})
        self.assertIn('timestamp', serialized)
    
    def test_behavioral_pattern_serialization(self):
        """Test behavioral pattern serialization"""
        pattern = BehavioralPattern(
            pattern_name="unusual_activity_hours",
            description="Activity during unusual hours",
            entities=["person_001"],
            pattern_strength=0.75,
            temporal_distribution={"night": 15, "day": 5},
            geographic_distribution={"NY": 10, "FL": 10},
            anomalies=["3am_transactions", "weekend_activity"],
            predictive_indicators=["stress_behavior", "evasive_patterns"]
        )
        
        serialized = self.analysis_agent._serialize_behavioral_pattern(pattern)
        
        self.assertEqual(serialized['pattern_name'], "unusual_activity_hours")
        self.assertEqual(serialized['description'], "Activity during unusual hours")
        self.assertEqual(serialized['entities'], ["person_001"])
        self.assertEqual(serialized['pattern_strength'], 0.75)
        self.assertEqual(serialized['temporal_distribution'], {"night": 15, "day": 5})
        self.assertEqual(serialized['geographic_distribution'], {"NY": 10, "FL": 10})
        self.assertEqual(serialized['anomalies'], ["3am_transactions", "weekend_activity"])
        self.assertEqual(serialized['predictive_indicators'], ["stress_behavior", "evasive_patterns"])
    
    def test_risk_level_classification(self):
        """Test risk level classification"""
        self.assertEqual(self.analysis_agent._classify_risk_level(0.9), "CRITICAL")
        self.assertEqual(self.analysis_agent._classify_risk_level(0.7), "HIGH")
        self.assertEqual(self.analysis_agent._classify_risk_level(0.5), "MEDIUM")
        self.assertEqual(self.analysis_agent._classify_risk_level(0.3), "LOW")
        self.assertEqual(self.analysis_agent._classify_risk_level(0.1), "MINIMAL")
    
    def test_confidence_level_classification(self):
        """Test confidence level classification"""
        self.assertEqual(self.analysis_agent._classify_confidence_level(0.95), ConfidenceLevel.VERY_HIGH)
        self.assertEqual(self.analysis_agent._classify_confidence_level(0.8), ConfidenceLevel.HIGH)
        self.assertEqual(self.analysis_agent._classify_confidence_level(0.6), ConfidenceLevel.MEDIUM)
        self.assertEqual(self.analysis_agent._classify_confidence_level(0.4), ConfidenceLevel.LOW)
        self.assertEqual(self.analysis_agent._classify_confidence_level(0.2), ConfidenceLevel.VERY_LOW)
    
    def test_executive_summary_generation(self):
        """Test executive summary generation"""
        # Mock report
        mock_report = AnalysisReport(
            report_id="test_001",
            query_id="query_001",
            analysis_type="test",
            timestamp=datetime.utcnow(),
            risk_assessment={},
            pattern_analysis={},
            network_analysis={},
            timeline_analysis={},
            behavioral_analysis={},
            executive_summary="",
            key_findings=[],
            risk_recommendations=[],
            confidence_assessment=ConfidenceScoring(overall_score=0.0, level=ConfidenceLevel.LOW),
            data_sources=[],
            processing_metrics={}
        )
        
        # Test with no findings
        summary = self.analysis_agent._generate_executive_summary(mock_report, [])
        self.assertIn("no significant findings", summary.lower())
        
        # Test with findings
        findings = ["High risk detected", "Suspicious patterns found", "Network anomalies identified"]
        summary = self.analysis_agent._generate_executive_summary(mock_report, findings)
        self.assertIn("3 key findings", summary)
        self.assertIn("High risk detected", summary)
    
    def test_overall_confidence_calculation(self):
        """Test overall confidence calculation"""
        # Mock report with all analysis components successful
        mock_report = AnalysisReport(
            report_id="test_001",
            query_id="query_001",
            analysis_type="test",
            timestamp=datetime.utcnow(),
            risk_assessment={"overall_risk_score": 0.5},  # No error
            pattern_analysis={"patterns": []},  # No error
            network_analysis={"network_metrics": {}},  # No error
            timeline_analysis={"analysis_metadata": {"reconstruction_confidence": 0.8}},
            behavioral_analysis={"behavioral_summary": {"prediction_confidence": 0.7}},
            executive_summary="",
            key_findings=[],
            risk_recommendations=[],
            confidence_assessment=ConfidenceScoring(overall_score=0.0, level=ConfidenceLevel.LOW),
            data_sources=[],
            processing_metrics={}
        )
        
        confidence = self.analysis_agent._calculate_overall_confidence(mock_report)
        self.assertGreater(confidence, 0.5)
        self.assertLessEqual(confidence, 1.0)
        
        # Test with errors
        mock_report.risk_assessment = {"error": "Risk assessment failed"}
        mock_report.pattern_analysis = {"error": "Pattern analysis failed"}
        confidence_with_errors = self.analysis_agent._calculate_overall_confidence(mock_report)
        self.assertLess(confidence_with_errors, confidence)
    
    def test_risk_recommendations_generation(self):
        """Test risk recommendations generation"""
        risk_factors = [
            RiskFactor(
                factor_type="identity_verification",
                description="Failed identity check",
                risk_level=0.8,
                confidence=0.9,
                evidence=["document_issue"],
                source="kyc"
            ),
            RiskFactor(
                factor_type="financial_pattern",
                description="Suspicious transactions",
                risk_level=0.9,
                confidence=0.85,
                evidence=["structuring"],
                source="aml"
            )
        ]
        
        recommendations = self.analysis_agent._generate_risk_recommendations(risk_factors)
        
        self.assertIsInstance(recommendations, list)
        self.assertGreater(len(recommendations), 0)
        
        # Should have recommendations for high-risk factors
        identity_rec = any("identity_verification" in rec for rec in recommendations)
        financial_rec = any("financial_pattern" in rec for rec in recommendations)
        self.assertTrue(identity_rec or financial_rec)
    
    def test_analysis_with_custom_parameters(self):
        """Test analysis with custom configuration parameters"""
        custom_params = {
            'analysis_type': 'custom_analysis',
            'data': self.sample_person_data,
            'focus_areas': ['risk', 'patterns'],
            'risk_threshold': 0.5,  # Custom threshold
            'pattern_significance_threshold': 0.01,  # Custom threshold
            'include_visualizations': True,
            'custom_settings': {'deep_analysis': True}
        }
        
        report = self.analysis_agent.query(custom_params)
        
        self.assertIsInstance(report, AnalysisReport)
        self.assertEqual(report.analysis_type, 'custom_analysis')
        
        # Should process without errors even with custom parameters
        self.assertIsInstance(report.processing_metrics, dict)
    
    def test_error_handling_in_analysis_components(self):
        """Test error handling in individual analysis components"""
        # Test with malformed data that might cause errors
        malformed_data = [
            {
                "type": "invalid_data_structure",
                "malformed_field": None,
                "missing_required_fields": True
            }
        ]
        
        analysis_params = {
            'analysis_type': 'error_test',
            'data': malformed_data,
            'focus_areas': ['risk', 'patterns', 'network', 'timeline', 'behavior']
        }
        
        # Should not raise exceptions, should handle errors gracefully
        report = self.analysis_agent.query(analysis_params)
        
        self.assertIsInstance(report, AnalysisReport)
        
        # Components may contain error messages instead of results
        for component in [report.risk_assessment, report.pattern_analysis, 
                         report.network_analysis, report.timeline_analysis, 
                         report.behavioral_analysis]:
            # Should either be empty dict or contain error handling
            self.assertIsInstance(component, dict)
    
    @patch('matplotlib.pyplot.savefig')
    @patch('matplotlib.pyplot.subplots')
    def test_visualization_generation(self, mock_subplots, mock_savefig):
        """Test visualization generation (mocked)"""
        # Mock matplotlib components
        mock_fig = MagicMock()
        mock_ax = MagicMock()
        mock_subplots.return_value = (mock_fig, mock_ax)
        
        # Mock BytesIO for image data
        mock_buf = MagicMock()
        mock_buf.read.return_value = b'fake_image_data'
        
        with patch('io.BytesIO', return_value=mock_buf):
            # Create mock report with risk data
            mock_report = AnalysisReport(
                report_id="test_viz",
                query_id="query_viz",
                analysis_type="visualization_test",
                timestamp=datetime.utcnow(),
                risk_assessment={'risk_distribution': {'high': 2, 'medium': 3, 'low': 1}},
                pattern_analysis={},
                network_analysis={},
                timeline_analysis={},
                behavioral_analysis={},
                executive_summary="",
                key_findings=[],
                risk_recommendations=[],
                confidence_assessment=ConfidenceScoring(overall_score=0.0, level=ConfidenceLevel.LOW),
                data_sources=[],
                processing_metrics={}
            )
            
            visualizations = self.analysis_agent._generate_visualizations(mock_report)
            
            self.assertIsInstance(visualizations, dict)
            # Should attempt to create risk visualization
            if 'risk_assessment' in visualizations:
                self.assertEqual(visualizations['risk_assessment'], b'fake_image_data')


class TestAnalysisAgentIntegration(unittest.TestCase):
    """Integration tests for AnalysisAgent with realistic data scenarios"""
    
    def setUp(self):
        """Set up integration test fixtures"""
        self.analysis_agent = AnalysisAgent()
    
    def test_fraud_detection_scenario(self):
        """Test complete fraud detection analysis scenario"""
        fraud_scenario_data = [
            {
                "type": "transaction_patterns",
                "entity_id": "fraud_suspect_001",
                "transactions": [
                    {"date": "2024-01-01", "amount": 9900, "type": "cash_deposit", "location": "Bank A"},
                    {"date": "2024-01-01", "amount": 9800, "type": "cash_deposit", "location": "Bank B"},
                    {"date": "2024-01-02", "amount": 9950, "type": "cash_deposit", "location": "Bank C"}
                ],
                "flags": ["structuring_pattern", "multiple_locations"],
                "source": "transaction_monitoring",
                "confidence": 0.92
            },
            {
                "type": "identity_verification",
                "entity_id": "fraud_suspect_001",
                "verification_results": [
                    {"date": "2023-12-15", "result": "failed", "reason": "document_mismatch"},
                    {"date": "2024-01-05", "result": "passed", "reason": "manual_override", "flags": ["suspicious"]}
                ],
                "source": "kyc_system",
                "confidence": 0.95
            }
        ]
        
        analysis_params = {
            'analysis_type': 'fraud_detection',
            'data': fraud_scenario_data,
            'focus_areas': ['risk', 'patterns', 'timeline'],
            'risk_threshold': 0.6
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should identify fraud indicators
        self.assertIsInstance(report, AnalysisReport)
        self.assertGreater(len(report.key_findings), 0)
        
        # Should have high confidence in analysis
        self.assertGreaterEqual(report.confidence_assessment.overall_score, 0.7)
        
        # Risk assessment should flag high risk
        if report.risk_assessment and not report.risk_assessment.get('error'):
            risk_score = report.risk_assessment.get('overall_risk_score', 0)
            self.assertGreaterEqual(risk_score, 0.6)
    
    def test_network_analysis_scenario(self):
        """Test complete network analysis scenario"""
        network_scenario_data = [
            {
                "type": "entity_relationships",
                "relationships": [
                    {
                        "source": "person_001", "source_name": "John Smith",
                        "target": "business_001", "target_name": "ABC Corp",
                        "relationship_type": "director", "strength": 0.9,
                        "evidence": ["corporate_filing"]
                    },
                    {
                        "source": "person_001", "target": "person_002", "target_name": "Jane Doe",
                        "relationship_type": "business_partner", "strength": 0.8,
                        "evidence": ["joint_ventures"]
                    },
                    {
                        "source": "person_002", "target": "business_002", "target_name": "XYZ Holdings",
                        "relationship_type": "beneficial_owner", "strength": 0.95,
                        "evidence": ["ownership_records"]
                    },
                    {
                        "source": "business_002", "target": "location_001", "target_name": "Offshore Address",
                        "relationship_type": "registered_address", "strength": 0.9,
                        "evidence": ["corporate_records"], "flags": ["offshore"]
                    }
                ],
                "source": "relationship_intelligence",
                "confidence": 0.88
            }
        ]
        
        analysis_params = {
            'analysis_type': 'network_analysis',
            'data': network_scenario_data,
            'focus_areas': ['network'],
            'network_algorithms': ['centrality', 'community_detection']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should build network successfully
        self.assertIsInstance(report, AnalysisReport)
        
        # Network analysis should have results
        if report.network_analysis and not report.network_analysis.get('error'):
            network_metrics = report.network_analysis.get('network_metrics', {})
            self.assertGreater(network_metrics.get('node_count', 0), 0)
            self.assertGreater(network_metrics.get('edge_count', 0), 0)
    
    def test_behavioral_analysis_scenario(self):
        """Test complete behavioral analysis scenario"""
        behavioral_scenario_data = [
            {
                "type": "activity_patterns",
                "entity_id": "subject_behavioral",
                "activities": [
                    {"activity_type": "login", "timestamp": "2024-01-01T09:15:00Z", 
                     "location": "New York, NY", "duration_minutes": 45},
                    {"activity_type": "login", "timestamp": "2024-01-02T09:18:00Z",
                     "location": "New York, NY", "duration_minutes": 42},
                    {"activity_type": "login", "timestamp": "2024-01-03T03:45:00Z",
                     "location": "Miami, FL", "duration_minutes": 5,
                     "flags": ["unusual_time", "location_change", "short_session"]},
                    {"activity_type": "transaction", "timestamp": "2024-01-03T04:00:00Z",
                     "location": "Miami, FL", "amount": 25000,
                     "flags": ["unusual_time", "large_amount"]}
                ],
                "source": "activity_monitoring",
                "confidence": 0.91
            }
        ]
        
        analysis_params = {
            'analysis_type': 'behavioral_analysis',
            'data': behavioral_scenario_data,
            'focus_areas': ['behavior', 'patterns', 'timeline'],
            'behavioral_models': ['activity_clustering', 'anomaly_detection']
        }
        
        report = self.analysis_agent.query(analysis_params)
        
        # Should complete behavioral analysis
        self.assertIsInstance(report, AnalysisReport)
        
        # Should detect unusual behavioral patterns
        if report.behavioral_analysis and not report.behavioral_analysis.get('error'):
            behavioral_summary = report.behavioral_analysis.get('behavioral_summary', {})
            # Should detect some anomalies from the unusual activity
            anomalies = behavioral_summary.get('anomalies_detected', 0)
            self.assertGreaterEqual(anomalies, 0)  # May be 0 in basic implementation


class TestAnalysisAgentPerformance(unittest.TestCase):
    """Performance and stress tests for AnalysisAgent"""
    
    def setUp(self):
        """Set up performance test fixtures"""
        self.analysis_agent = AnalysisAgent()
    
    def test_large_dataset_analysis(self):
        """Test analysis with large dataset"""
        # Create large dataset (1000 data points)
        large_dataset = []
        for i in range(1000):
            large_dataset.append({
                "type": "test_data_point",
                "id": f"entity_{i:04d}",
                "timestamp": datetime(2024, 1, 1) + timedelta(hours=i),
                "value": i * 1.5,
                "category": f"category_{i % 10}",
                "source": "performance_test",
                "confidence": 0.8
            })
        
        analysis_params = {
            'analysis_type': 'performance_test',
            'data': large_dataset,
            'focus_areas': ['patterns']  # Focus on one area for performance
        }
        
        start_time = datetime.utcnow()
        report = self.analysis_agent.query(analysis_params)
        end_time = datetime.utcnow()
        
        processing_time = (end_time - start_time).total_seconds()
        
        # Should complete within reasonable time (adjust based on requirements)
        self.assertLess(processing_time, 30.0, "Large dataset analysis took too long")
        
        # Should process all data points
        processed_count = report.processing_metrics.get('data_points_analyzed', 0)
        self.assertEqual(processed_count, 1000)
        
        self.assertIsInstance(report, AnalysisReport)
    
    def test_concurrent_analysis_requests(self):
        """Test handling of concurrent analysis requests"""
        import threading
        import queue
        
        results_queue = queue.Queue()
        
        def run_analysis(thread_id):
            try:
                analysis_params = {
                    'analysis_type': f'concurrent_test_{thread_id}',
                    'data': [{"type": "test", "thread_id": thread_id, "value": thread_id * 10}],
                    'focus_areas': ['risk']
                }
                
                report = self.analysis_agent.query(analysis_params)
                results_queue.put(('success', thread_id, report))
            except Exception as e:
                results_queue.put(('error', thread_id, str(e)))
        
        # Start 5 concurrent analysis threads
        threads = []
        for i in range(5):
            thread = threading.Thread(target=run_analysis, args=(i,))
            threads.append(thread)
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        # Check results
        success_count = 0
        error_count = 0
        
        while not results_queue.empty():
            result_type, thread_id, result = results_queue.get()
            if result_type == 'success':
                success_count += 1
                self.assertIsInstance(result, AnalysisReport)
            else:
                error_count += 1
                print(f"Thread {thread_id} failed: {result}")
        
        # All threads should succeed
        self.assertEqual(success_count, 5)
        self.assertEqual(error_count, 0)


if __name__ == '__main__':
    # Configure test logging
    logging.basicConfig(level=logging.WARNING)  # Reduce log noise during tests
    
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test classes
    test_suite.addTest(unittest.makeSuite(TestAnalysisAgent))
    test_suite.addTest(unittest.makeSuite(TestAnalysisAgentIntegration))
    test_suite.addTest(unittest.makeSuite(TestAnalysisAgentPerformance))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Exit with proper code
    exit(0 if result.wasSuccessful() else 1)