"""Comprehensive performance testing suite for Sleuth Intel."""

import asyncio
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Dict, List, Tuple

import psutil
import pytest
import pytest_asyncio
from aiohttp import ClientSession

from src.orchestrator import InvestigationOrchestrator
from src.models import Query


class TestSystemPerformance:
    """Comprehensive performance testing."""

    @pytest_asyncio.fixture
    async def performance_monitor(self):
        """Monitor system performance metrics."""
        class PerformanceMonitor:
            def __init__(self):
                self.metrics = {
                    'cpu': [],
                    'memory': [],
                    'disk_io': [],
                    'network_io': [],
                    'response_times': [],
                    'errors': [],
                    'throughput': []
                }
                self.process = psutil.Process()
                self.start_time = None
                
            def start(self):
                """Start monitoring."""
                self.start_time = time.time()
                self.initial_io = self.process.io_counters()
                self.initial_net = psutil.net_io_counters()
                
            def record_metric(self):
                """Record current metrics."""
                self.metrics['cpu'].append(self.process.cpu_percent())
                self.metrics['memory'].append(
                    self.process.memory_info().rss / 1024 / 1024
                )
                
                io_counters = self.process.io_counters()
                self.metrics['disk_io'].append({
                    'read_bytes': io_counters.read_bytes,
                    'write_bytes': io_counters.write_bytes
                })
                
                net_counters = psutil.net_io_counters()
                self.metrics['network_io'].append({
                    'bytes_sent': net_counters.bytes_sent,
                    'bytes_recv': net_counters.bytes_recv
                })
                
            def record_response(self, response_time: float, error: bool = False):
                """Record response metrics."""
                self.metrics['response_times'].append(response_time)
                if error:
                    self.metrics['errors'].append(time.time())
                    
            def calculate_throughput(self, total_requests: int):
                """Calculate throughput."""
                if self.start_time:
                    elapsed = time.time() - self.start_time
                    throughput = total_requests / elapsed
                    self.metrics['throughput'].append(throughput)
                    return throughput
                return 0
                
            def get_summary(self) -> Dict:
                """Get performance summary."""
                response_times = self.metrics['response_times']
                if not response_times:
                    return {}
                    
                sorted_times = sorted(response_times)
                return {
                    'avg_response_time': sum(response_times) / len(response_times),
                    'min_response_time': min(response_times),
                    'max_response_time': max(response_times),
                    'p50_response_time': sorted_times[int(len(sorted_times) * 0.5)],
                    'p95_response_time': sorted_times[int(len(sorted_times) * 0.95)],
                    'p99_response_time': sorted_times[int(len(sorted_times) * 0.99)],
                    'avg_cpu': sum(self.metrics['cpu']) / len(self.metrics['cpu']) if self.metrics['cpu'] else 0,
                    'max_memory_mb': max(self.metrics['memory']) if self.metrics['memory'] else 0,
                    'error_rate': len(self.metrics['errors']) / len(response_times) if response_times else 0,
                    'throughput': self.metrics['throughput'][-1] if self.metrics['throughput'] else 0
                }
        
        return PerformanceMonitor()

    @pytest.mark.asyncio
    async def test_sustained_load(self, orchestrator, performance_monitor):
        """Test system under sustained load."""
        performance_monitor.start()
        
        # Sustained load for 60 seconds
        duration = 60
        requests_per_second = 10
        total_requests = duration * requests_per_second
        
        async def make_request(i: int) -> Tuple[float, bool]:
            """Make a single request."""
            start = time.time()
            query = Query(
                query_type="person_search",
                parameters={
                    "first_name": f"Load{i}",
                    "last_name": "Test",
                    "city": "Boston"
                },
                metadata={"load_test": True, "request_id": f"sustained-{i}"}
            )
            
            try:
                await orchestrator.investigate(query)
                elapsed = time.time() - start
                return elapsed, False
            except Exception:
                elapsed = time.time() - start
                return elapsed, True
        
        # Generate load
        tasks = []
        for second in range(duration):
            for req in range(requests_per_second):
                req_id = second * requests_per_second + req
                task = asyncio.create_task(make_request(req_id))
                tasks.append(task)
                
            # Record metrics every second
            performance_monitor.record_metric()
            await asyncio.sleep(1)
        
        # Wait for all requests to complete
        results = await asyncio.gather(*tasks)
        
        # Process results
        for response_time, is_error in results:
            performance_monitor.record_response(response_time, is_error)
        
        performance_monitor.calculate_throughput(total_requests)
        
        # Analyze results
        summary = performance_monitor.get_summary()
        
        # Performance assertions
        assert summary['avg_response_time'] < 3.0  # Average under 3 seconds
        assert summary['p95_response_time'] < 5.0  # 95th percentile under 5 seconds
        assert summary['error_rate'] < 0.1  # Less than 10% errors
        assert summary['throughput'] > 5  # At least 5 requests per second

    @pytest.mark.asyncio
    async def test_spike_load(self, orchestrator, performance_monitor):
        """Test system response to traffic spikes."""
        performance_monitor.start()
        
        # Normal load
        normal_load = 5
        spike_load = 50
        
        async def generate_load(num_requests: int, label: str):
            """Generate a load burst."""
            tasks = []
            for i in range(num_requests):
                query = Query(
                    query_type="person_search",
                    parameters={
                        "first_name": f"Spike{label}{i}",
                        "last_name": "Test"
                    },
                    metadata={"spike_test": True}
                )
                tasks.append(orchestrator.investigate(query))
            
            start = time.time()
            results = await asyncio.gather(*tasks, return_exceptions=True)
            elapsed = time.time() - start
            
            success = sum(1 for r in results if not isinstance(r, Exception))
            return success, elapsed
        
        # Normal load
        normal_success, normal_time = await generate_load(normal_load, "normal")
        
        # Spike load
        spike_success, spike_time = await generate_load(spike_load, "spike")
        
        # Recovery - normal load again
        recovery_success, recovery_time = await generate_load(normal_load, "recovery")
        
        # System should handle spike and recover
        assert spike_success > spike_load * 0.5  # At least 50% success during spike
        assert recovery_time < normal_time * 2  # Recovery time should be reasonable

    @pytest.mark.asyncio
    async def test_memory_leak_detection(self, orchestrator, performance_monitor):
        """Test for memory leaks over extended operation."""
        import gc
        
        performance_monitor.start()
        
        # Initial memory
        gc.collect()
        initial_memory = performance_monitor.process.memory_info().rss / 1024 / 1024
        
        # Run many iterations
        for iteration in range(100):
            queries = []
            for i in range(10):
                query = Query(
                    query_type="person_search",
                    parameters={
                        "first_name": f"MemTest{iteration}_{i}",
                        "last_name": "User"
                    },
                    metadata={"memory_test": True}
                )
                queries.append(orchestrator.investigate(query))
            
            await asyncio.gather(*queries, return_exceptions=True)
            
            # Force garbage collection every 10 iterations
            if iteration % 10 == 0:
                gc.collect()
                current_memory = performance_monitor.process.memory_info().rss / 1024 / 1024
                performance_monitor.metrics['memory'].append(current_memory)
        
        # Final memory check
        gc.collect()
        final_memory = performance_monitor.process.memory_info().rss / 1024 / 1024
        
        # Check for memory leak
        memory_increase = final_memory - initial_memory
        memory_increase_percent = (memory_increase / initial_memory) * 100
        
        # Memory increase should be minimal
        assert memory_increase < 50  # Less than 50MB increase
        assert memory_increase_percent < 25  # Less than 25% increase

    @pytest.mark.asyncio
    async def test_concurrent_user_simulation(self, orchestrator):
        """Simulate multiple concurrent users."""
        num_users = 20
        requests_per_user = 10
        
        async def simulate_user(user_id: int) -> Dict:
            """Simulate a single user session."""
            user_metrics = {
                'user_id': user_id,
                'requests': [],
                'total_time': 0,
                'errors': 0
            }
            
            start_session = time.time()
            
            for req_id in range(requests_per_user):
                # Simulate user think time
                await asyncio.sleep(0.1 + (req_id * 0.05))
                
                query = Query(
                    query_type="person_search" if req_id % 2 == 0 else "business_search",
                    parameters={
                        "first_name": f"User{user_id}",
                        "last_name": f"Request{req_id}",
                        "business_name": f"Company{user_id}"
                    },
                    metadata={"user_id": user_id, "request_id": req_id}
                )
                
                req_start = time.time()
                try:
                    await orchestrator.investigate(query)
                    req_time = time.time() - req_start
                    user_metrics['requests'].append(req_time)
                except Exception:
                    user_metrics['errors'] += 1
            
            user_metrics['total_time'] = time.time() - start_session
            return user_metrics
        
        # Simulate all users concurrently
        user_tasks = [simulate_user(i) for i in range(num_users)]
        user_results = await asyncio.gather(*user_tasks)
        
        # Analyze user experience
        avg_session_time = sum(u['total_time'] for u in user_results) / num_users
        total_errors = sum(u['errors'] for u in user_results)
        avg_request_time = sum(
            sum(u['requests']) / len(u['requests']) if u['requests'] else 0
            for u in user_results
        ) / num_users
        
        # User experience assertions
        assert avg_session_time < 30  # Average session under 30 seconds
        assert avg_request_time < 2  # Average request under 2 seconds
        assert total_errors < num_users * requests_per_user * 0.05  # Less than 5% errors

    @pytest.mark.asyncio
    async def test_database_connection_pooling(self, orchestrator):
        """Test database connection pool efficiency."""
        # Monitor connection pool metrics
        pool_metrics = {
            'connections_created': 0,
            'connections_reused': 0,
            'pool_exhausted': 0
        }
        
        async def monitor_connections():
            """Monitor database connections."""
            # This would integrate with actual database monitoring
            pass
        
        # Concurrent database operations
        tasks = []
        for i in range(100):
            query = Query(
                query_type="person_search",
                parameters={"first_name": f"DBTest{i}", "last_name": "User"},
                metadata={"db_test": True}
            )
            tasks.append(orchestrator.investigate(query))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Connection pool should handle load efficiently
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) < 5  # Very few connection errors

    @pytest.mark.asyncio
    async def test_cache_performance(self, orchestrator):
        """Test cache performance impact."""
        # Test data
        test_queries = [
            Query(
                query_type="person_search",
                parameters={"first_name": f"Cache{i % 10}", "last_name": "Test"},
                metadata={"cache_test": True}
            )
            for i in range(100)
        ]
        
        # First pass - populate cache
        start_cold = time.time()
        for query in test_queries[:50]:
            await orchestrator.investigate(query)
        cold_time = time.time() - start_cold
        
        # Second pass - use cache
        start_warm = time.time()
        for query in test_queries[50:]:
            await orchestrator.investigate(query)
        warm_time = time.time() - start_warm
        
        # Cache should significantly improve performance
        performance_improvement = (cold_time - warm_time) / cold_time
        assert performance_improvement > 0.3  # At least 30% improvement

    @pytest.mark.asyncio
    async def test_rate_limit_efficiency(self, orchestrator):
        """Test rate limiting efficiency."""
        # Generate requests at different rates
        rates = [10, 20, 50, 100]  # requests per second
        
        results = {}
        for rate in rates:
            tasks = []
            start = time.time()
            
            for i in range(rate):
                query = Query(
                    query_type="person_search",
                    parameters={"first_name": f"Rate{rate}_{i}", "last_name": "Test"},
                    metadata={"rate_test": True}
                )
                tasks.append(orchestrator.investigate(query))
            
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            elapsed = time.time() - start
            
            success = sum(1 for r in responses if not isinstance(r, Exception))
            actual_rate = success / elapsed
            
            results[rate] = {
                'requested': rate,
                'actual': actual_rate,
                'success_rate': success / rate
            }
        
        # Rate limiting should be consistent
        for rate, metrics in results.items():
            if rate <= 20:  # Within normal limits
                assert metrics['success_rate'] > 0.9  # Most should succeed
            else:  # Above limits
                assert metrics['actual'] < rate  # Should be rate limited

    @pytest.mark.asyncio
    async def test_graceful_degradation_performance(self, orchestrator):
        """Test performance during degraded conditions."""
        # Simulate various failure scenarios
        scenarios = [
            {'name': 'api_slow', 'delay': 2.0},
            {'name': 'api_partial_failure', 'failure_rate': 0.3},
            {'name': 'cache_miss', 'cache_disabled': True}
        ]
        
        baseline_times = []
        degraded_times = {}
        
        # Baseline performance
        for i in range(10):
            query = Query(
                query_type="person_search",
                parameters={"first_name": f"Baseline{i}", "last_name": "Test"},
                metadata={"degradation_test": True}
            )
            start = time.time()
            await orchestrator.investigate(query)
            baseline_times.append(time.time() - start)
        
        baseline_avg = sum(baseline_times) / len(baseline_times)
        
        # Test each degradation scenario
        for scenario in scenarios:
            scenario_times = []
            
            # Apply degradation (would need actual implementation)
            # For testing, we simulate the effect
            
            for i in range(10):
                query = Query(
                    query_type="person_search",
                    parameters={"first_name": f"{scenario['name']}{i}", "last_name": "Test"},
                    metadata={"scenario": scenario['name']}
                )
                
                start = time.time()
                try:
                    await orchestrator.investigate(query)
                except:
                    pass
                scenario_times.append(time.time() - start)
            
            degraded_times[scenario['name']] = sum(scenario_times) / len(scenario_times)
        
        # System should degrade gracefully
        for scenario_name, avg_time in degraded_times.items():
            # Should not be more than 5x slower
            assert avg_time < baseline_avg * 5