"""Performance and load testing suite."""

import asyncio
import random
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import List, Dict, Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from locust import HttpUser, task, between, events

from tests.fixtures.mock_data import MockDataGenerator
from tests.utils.test_helpers import PerformanceProfiler


class TestPerformanceBaseline:
    """Test performance baselines."""
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_single_agent_performance(self, person_agent, mock_data_generator, performance_timer):
        """Test single agent performance baseline."""
        mock_person = mock_data_generator.create_person()
        person_agent.api_client.search_person.return_value = [mock_person]
        
        with performance_timer as timer:
            result = await person_agent.search(first_name="John", last_name="Doe")
        
        assert timer.elapsed < 0.1  # Should complete in under 100ms
        assert len(result) == 1
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_orchestrator_performance(self, orchestrator, mock_data_generator, performance_timer):
        """Test orchestrator performance baseline."""
        mock_person = mock_data_generator.create_person()
        orchestrator.api_client.search_person.return_value = [mock_person]
        
        workflow = {
            "name": "simple_search",
            "steps": [{
                "agent": "person_search",
                "action": "search",
                "params": {"first_name": "John", "last_name": "Doe"}
            }]
        }
        
        with performance_timer as timer:
            result = await orchestrator.execute_workflow(workflow)
        
        assert timer.elapsed < 0.5  # Should complete in under 500ms
        assert result["status"] == "completed"
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_parallel_agent_performance(self, orchestrator, mock_data_generator, performance_timer):
        """Test parallel agent execution performance."""
        mock_person = mock_data_generator.create_person()
        mock_business = mock_data_generator.create_business()
        
        orchestrator.api_client.search_person.return_value = [mock_person]
        orchestrator.api_client.search_business.return_value = [mock_business]
        orchestrator.api_client.search_email.return_value = []
        
        workflow = {
            "name": "parallel_search",
            "parallel": True,
            "steps": [
                {"agent": "person_search", "action": "search", "params": {"first_name": "John"}},
                {"agent": "business_search", "action": "search", "params": {"name": "Tech"}},
                {"agent": "email_search", "action": "search", "params": {"email": "test@example.com"}}
            ]
        }
        
        with performance_timer as timer:
            result = await orchestrator.execute_workflow(workflow)
        
        # Parallel execution should be faster than sequential (3 * 0.1s = 0.3s)
        assert timer.elapsed < 0.2
        assert result["status"] == "completed"
        assert len(result["steps_completed"]) == 3


class TestLoadTesting:
    """Load testing scenarios."""
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_concurrent_requests(self, system, mock_data_generator):
        """Test system under concurrent requests."""
        num_requests = 100
        profiler = PerformanceProfiler()
        
        async def make_request(i):
            person = mock_data_generator.create_person()
            system.api_client.search_person.return_value = [person]
            
            measurement = profiler.start(f"request_{i}")
            result = await system.investigate({
                "type": "background_check",
                "subject": {"first_name": f"User{i}", "last_name": "Test"}
            })
            profiler.stop(measurement)
            
            return result
        
        # Execute concurrent requests
        tasks = [make_request(i) for i in range(num_requests)]
        results = await asyncio.gather(*tasks)
        
        # Verify all completed
        assert len(results) == num_requests
        assert all(r["status"] == "completed" for r in results)
        
        # Check performance metrics
        report = profiler.get_report()
        assert report["average_time"] < 0.5  # Average under 500ms
        assert report["slowest"]["duration"] < 2.0  # No request over 2s
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_sustained_load(self, system, mock_data_generator):
        """Test system under sustained load."""
        duration = 10  # 10 seconds
        requests_per_second = 10
        profiler = PerformanceProfiler()
        errors = []
        
        async def generate_load():
            start_time = time.time()
            request_count = 0
            
            while time.time() - start_time < duration:
                try:
                    person = mock_data_generator.create_person()
                    system.api_client.search_person.return_value = [person]
                    
                    measurement = profiler.start(f"request_{request_count}")
                    await system.investigate({
                        "type": "background_check",
                        "subject": {"first_name": "Load", "last_name": "Test"}
                    })
                    profiler.stop(measurement)
                    
                    request_count += 1
                    await asyncio.sleep(1.0 / requests_per_second)
                    
                except Exception as e:
                    errors.append(str(e))
        
        await generate_load()
        
        # Verify performance
        report = profiler.get_report()
        assert len(errors) == 0  # No errors
        assert report["average_time"] < 1.0  # Average under 1 second
        assert len(profiler.measurements) >= duration * requests_per_second * 0.9  # At least 90% success
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_burst_load(self, system, mock_data_generator):
        """Test system under burst load."""
        burst_size = 50
        profiler = PerformanceProfiler()
        
        async def burst_request(i):
            person = mock_data_generator.create_person()
            system.api_client.search_person.return_value = [person]
            
            measurement = profiler.start(f"burst_{i}")
            result = await system.investigate({
                "type": "background_check",
                "subject": {"first_name": f"Burst{i}", "last_name": "Test"}
            })
            profiler.stop(measurement)
            return result
        
        # Send burst of requests
        tasks = [burst_request(i) for i in range(burst_size)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Count successes and failures
        successes = sum(1 for r in results if isinstance(r, dict) and r.get("status") == "completed")
        failures = sum(1 for r in results if isinstance(r, Exception))
        
        # Should handle at least 90% of burst
        assert successes >= burst_size * 0.9
        assert failures <= burst_size * 0.1
        
        # Check recovery time
        report = profiler.get_report()
        assert report["slowest"]["duration"] < 5.0  # Max 5 seconds for any request
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_memory_usage(self, system, mock_data_generator):
        """Test memory usage under load."""
        import psutil
        import gc
        
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Generate significant load
        for _ in range(100):
            people = mock_data_generator.create_bulk_persons(100)
            system.api_client.search_person.return_value = people
            
            await system.investigate({
                "type": "batch_background_check",
                "subjects": [{"first_name": p.first_name, "last_name": p.last_name} for p in people[:10]]
            })
        
        # Force garbage collection
        gc.collect()
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        # Memory increase should be reasonable (less than 100MB)
        assert memory_increase < 100, f"Memory increased by {memory_increase}MB"
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_cache_performance(self, system, mock_redis_client, mock_data_generator):
        """Test cache performance impact."""
        person = mock_data_generator.create_person()
        system.api_client.search_person.return_value = [person]
        
        profiler = PerformanceProfiler()
        
        # First request (cache miss)
        measurement1 = profiler.start("cache_miss")
        await system.investigate({
            "type": "background_check",
            "subject": {"first_name": "Cache", "last_name": "Test"}
        })
        time_without_cache = profiler.stop(measurement1)
        
        # Configure cache hit
        mock_redis_client.get.return_value = json.dumps({"cached": True, "data": person.__dict__})
        
        # Second request (cache hit)
        measurement2 = profiler.start("cache_hit")
        await system.investigate({
            "type": "background_check",
            "subject": {"first_name": "Cache", "last_name": "Test"}
        })
        time_with_cache = profiler.stop(measurement2)
        
        # Cache hit should be at least 50% faster
        assert time_with_cache < time_without_cache * 0.5


class TestStressTesting:
    """Stress testing scenarios."""
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_resource_exhaustion(self, system):
        """Test system behavior when resources are exhausted."""
        # Simulate resource exhaustion
        system.max_concurrent_agents = 2
        active_agents = []
        
        async def long_running_task():
            await asyncio.sleep(5)
            return {"status": "completed"}
        
        # Start max concurrent tasks
        for i in range(5):
            task = asyncio.create_task(long_running_task())
            active_agents.append(task)
        
        # Try to execute when resources are exhausted
        start = time.time()
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(system.investigate({
                "type": "background_check",
                "subject": {"first_name": "Test", "last_name": "User"}
            }), timeout=1.0)
        
        # Clean up
        for task in active_agents:
            task.cancel()
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_cascading_failures(self, system):
        """Test system resilience to cascading failures."""
        failure_count = 0
        
        async def failing_search(*args, **kwargs):
            nonlocal failure_count
            failure_count += 1
            if failure_count < 10:
                raise Exception("Service unavailable")
            return []
        
        system.api_client.search_person = failing_search
        
        results = []
        for i in range(15):
            try:
                result = await system.investigate({
                    "type": "background_check",
                    "subject": {"first_name": f"Test{i}", "last_name": "User"}
                })
                results.append(result)
            except Exception:
                pass
        
        # System should recover after initial failures
        assert len(results) >= 5  # At least some requests succeed after recovery
    
    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_connection_pool_exhaustion(self, system):
        """Test connection pool exhaustion handling."""
        # Simulate limited connection pool
        system.api_client.max_connections = 5
        
        async def slow_request(*args, **kwargs):
            await asyncio.sleep(2)
            return []
        
        system.api_client.search_person = slow_request
        
        # Send more requests than connection pool size
        tasks = []
        for i in range(20):
            task = asyncio.create_task(system.investigate({
                "type": "background_check",
                "subject": {"first_name": f"Pool{i}", "last_name": "Test"}
            }))
            tasks.append(task)
        
        # Wait with timeout
        done, pending = await asyncio.wait(tasks, timeout=5.0)
        
        # Some should complete, some should be pending
        assert len(done) >= 5
        assert len(pending) > 0
        
        # Clean up
        for task in pending:
            task.cancel()


class LocustLoadTest(HttpUser):
    """Locust-based load testing."""
    
    wait_time = between(1, 3)
    
    def on_start(self):
        """Initialize test data."""
        self.mock_generator = MockDataGenerator()
    
    @task(3)
    def search_person(self):
        """Test person search endpoint."""
        person = self.mock_generator.create_person()
        with self.client.post(
            "/api/search/person",
            json={
                "first_name": person.first_name,
                "last_name": person.last_name
            },
            catch_response=True
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Status code: {response.status_code}")
    
    @task(2)
    def search_business(self):
        """Test business search endpoint."""
        business = self.mock_generator.create_business()
        with self.client.post(
            "/api/search/business",
            json={"name": business.name},
            catch_response=True
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Status code: {response.status_code}")
    
    @task(1)
    def complex_investigation(self):
        """Test complex investigation endpoint."""
        with self.client.post(
            "/api/investigate",
            json={
                "type": "background_check",
                "subject": {
                    "first_name": "Load",
                    "last_name": "Test"
                }
            },
            catch_response=True
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Status code: {response.status_code}")


@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """Initialize test environment."""
    print("Load test starting...")


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Generate test report."""
    print("\n=== Load Test Report ===")
    print(f"Total requests: {environment.stats.total.num_requests}")
    print(f"Failed requests: {environment.stats.total.num_failures}")
    print(f"Average response time: {environment.stats.total.avg_response_time}ms")
    print(f"Min response time: {environment.stats.total.min_response_time}ms")
    print(f"Max response time: {environment.stats.total.max_response_time}ms")