"""Real-world end-to-end testing scenarios."""

import asyncio
import json
import time
from datetime import datetime
from typing import Any, Dict, List

import pytest
import pytest_asyncio

from src.orchestrator import InvestigationOrchestrator
from src.models import Query, IntelligenceReport


class RealWorldTestSuite:
    """Real-world testing scenarios with actual use cases."""
    
    def __init__(self):
        self.config = self.load_test_config()
        self.orchestrator = None
        self.results = []
        
    def load_test_config(self) -> Dict:
        """Load test configuration."""
        return {
            'api_endpoint': 'https://api.enformion.com/v2',
            'timeout': 30,
            'max_retries': 3,
            'cache_enabled': True
        }
    
    async def setup(self):
        """Initialize test environment."""
        self.orchestrator = InvestigationOrchestrator(config=self.config)
        await self.orchestrator.initialize()
    
    async def teardown(self):
        """Clean up test environment."""
        if self.orchestrator:
            await self.orchestrator.cleanup()
    
    async def test_phone_number_investigation(self) -> Dict:
        """Test with actual phone number lookup."""
        print("\n[TEST] Phone Number Investigation")
        print("-" * 40)
        
        test_phone = "555-123-4567"  # Example number provided
        
        query = Query(
            query_type="phone_investigation",
            parameters={
                "phone": test_phone,
                "include_carrier": True,
                "include_owner": True,
                "include_address": True,
                "include_relatives": True
            },
            metadata={
                "test_type": "real_world_phone",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        # Validate results
        test_result = {
            'test': 'phone_investigation',
            'input': test_phone,
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.findings:
            test_result['passed'] = True
            test_result['findings'] = {
                'phone_valid': result.findings.get('phone_valid', False),
                'carrier_found': 'carrier' in result.findings,
                'owner_found': 'owner' in result.findings,
                'address_found': 'address' in result.findings,
                'confidence_score': result.confidence_score
            }
            
            print(f"✓ Phone lookup completed in {elapsed:.2f}s")
            print(f"  - Valid Phone: {test_result['findings']['phone_valid']}")
            print(f"  - Carrier Found: {test_result['findings']['carrier_found']}")
            print(f"  - Owner Found: {test_result['findings']['owner_found']}")
            print(f"  - Confidence: {test_result['findings']['confidence_score']:.2%}")
        else:
            print(f"✗ Phone lookup failed or returned no results")
        
        return test_result
    
    async def test_business_comprehensive_search(self) -> Dict:
        """Test comprehensive business investigation."""
        print("\n[TEST] Business Comprehensive Search")
        print("-" * 40)
        
        query = Query(
            query_type="business_investigation",
            parameters={
                "business_name": "Apple Inc",
                "city": "Cupertino",
                "state": "CA",
                "include_financials": True,
                "include_executives": True,
                "include_legal": True,
                "include_social_media": True
            },
            metadata={
                "test_type": "real_world_business",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'business_investigation',
            'input': 'Apple Inc',
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.findings:
            business_data = result.findings.get('business', {})
            test_result['passed'] = True
            test_result['findings'] = {
                'business_found': bool(business_data),
                'has_address': 'address' in business_data,
                'has_phone': 'phone' in business_data,
                'has_website': 'website' in business_data,
                'has_executives': 'executives' in result.findings,
                'has_financials': 'financials' in result.findings,
                'data_completeness': len([k for k, v in business_data.items() if v]) / 10
            }
            
            print(f"✓ Business search completed in {elapsed:.2f}s")
            print(f"  - Business Found: {test_result['findings']['business_found']}")
            print(f"  - Data Completeness: {test_result['findings']['data_completeness']:.0%}")
        else:
            print(f"✗ Business search failed or returned no results")
        
        return test_result
    
    async def test_person_deep_investigation(self) -> Dict:
        """Test deep person investigation with relationship mapping."""
        print("\n[TEST] Person Deep Investigation")
        print("-" * 40)
        
        query = Query(
            query_type="person_deep_investigation",
            parameters={
                "first_name": "John",
                "last_name": "Smith",
                "middle_name": "",
                "city": "New York",
                "state": "NY",
                "age_range": "30-40",
                "include_criminal": True,
                "include_property": True,
                "include_vehicles": True,
                "include_licenses": True,
                "include_social_media": True,
                "include_employment": True,
                "include_education": True,
                "include_relatives": True,
                "include_associates": True,
                "relationship_depth": 2
            },
            metadata={
                "test_type": "real_world_person_deep",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'person_deep_investigation',
            'input': 'John Smith',
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.findings:
            person_data = result.findings.get('person', {})
            test_result['passed'] = True
            test_result['findings'] = {
                'person_found': bool(person_data),
                'has_addresses': len(result.findings.get('addresses', [])),
                'has_phones': len(result.findings.get('phones', [])),
                'has_emails': len(result.findings.get('emails', [])),
                'has_relatives': len(result.findings.get('relatives', [])),
                'has_associates': len(result.findings.get('associates', [])),
                'has_criminal': 'criminal_records' in result.findings,
                'has_property': 'properties' in result.findings,
                'has_vehicles': 'vehicles' in result.findings,
                'relationship_network_size': len(result.findings.get('relationship_network', []))
            }
            
            print(f"✓ Person investigation completed in {elapsed:.2f}s")
            print(f"  - Person Found: {test_result['findings']['person_found']}")
            print(f"  - Addresses: {test_result['findings']['has_addresses']}")
            print(f"  - Relatives: {test_result['findings']['has_relatives']}")
            print(f"  - Network Size: {test_result['findings']['relationship_network_size']}")
        else:
            print(f"✗ Person investigation failed or returned no results")
        
        return test_result
    
    async def test_email_validation_batch(self) -> Dict:
        """Test batch email validation."""
        print("\n[TEST] Batch Email Validation")
        print("-" * 40)
        
        test_emails = [
            "john.doe@gmail.com",
            "jane.smith@yahoo.com",
            "info@company.com",
            "support@example.org",
            "invalid.email@",
            "not-an-email",
            "test@test.test"
        ]
        
        results = []
        start_time = time.time()
        
        for email in test_emails:
            query = Query(
                query_type="email_validation",
                parameters={
                    "email": email,
                    "check_deliverability": True,
                    "check_reputation": True
                },
                metadata={"test_type": "email_validation"}
            )
            
            result = await self.orchestrator.investigate(query)
            
            if result:
                results.append({
                    'email': email,
                    'valid': result.findings.get('valid', False),
                    'deliverable': result.findings.get('deliverable', False),
                    'reputation': result.findings.get('reputation', 'unknown')
                })
        
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'email_validation_batch',
            'input': f"{len(test_emails)} emails",
            'passed': len(results) > 0,
            'elapsed_time': elapsed,
            'findings': {
                'total_tested': len(test_emails),
                'valid_count': sum(1 for r in results if r['valid']),
                'deliverable_count': sum(1 for r in results if r['deliverable']),
                'avg_time_per_email': elapsed / len(test_emails) if test_emails else 0
            }
        }
        
        print(f"✓ Email validation completed in {elapsed:.2f}s")
        print(f"  - Emails Tested: {test_result['findings']['total_tested']}")
        print(f"  - Valid: {test_result['findings']['valid_count']}")
        print(f"  - Deliverable: {test_result['findings']['deliverable_count']}")
        print(f"  - Avg Time: {test_result['findings']['avg_time_per_email']:.2f}s")
        
        return test_result
    
    async def test_address_enrichment(self) -> Dict:
        """Test address enrichment and geocoding."""
        print("\n[TEST] Address Enrichment")
        print("-" * 40)
        
        test_addresses = [
            {
                "street": "1600 Pennsylvania Avenue NW",
                "city": "Washington",
                "state": "DC",
                "zip": "20500"
            },
            {
                "street": "1 Infinite Loop",
                "city": "Cupertino",
                "state": "CA",
                "zip": "95014"
            }
        ]
        
        results = []
        start_time = time.time()
        
        for address in test_addresses:
            query = Query(
                query_type="address_enrichment",
                parameters={
                    **address,
                    "geocode": True,
                    "include_demographics": True,
                    "include_property_data": True,
                    "include_neighbors": True
                },
                metadata={"test_type": "address_enrichment"}
            )
            
            result = await self.orchestrator.investigate(query)
            
            if result and result.findings:
                results.append({
                    'address': f"{address['street']}, {address['city']}",
                    'geocoded': 'coordinates' in result.findings,
                    'has_demographics': 'demographics' in result.findings,
                    'has_property': 'property_data' in result.findings,
                    'has_neighbors': len(result.findings.get('neighbors', [])) > 0
                })
        
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'address_enrichment',
            'input': f"{len(test_addresses)} addresses",
            'passed': len(results) > 0,
            'elapsed_time': elapsed,
            'findings': {
                'total_tested': len(test_addresses),
                'geocoded_count': sum(1 for r in results if r['geocoded']),
                'enriched_count': sum(1 for r in results if r['has_demographics']),
                'avg_time_per_address': elapsed / len(test_addresses) if test_addresses else 0
            }
        }
        
        print(f"✓ Address enrichment completed in {elapsed:.2f}s")
        print(f"  - Addresses Tested: {test_result['findings']['total_tested']}")
        print(f"  - Geocoded: {test_result['findings']['geocoded_count']}")
        print(f"  - Enriched: {test_result['findings']['enriched_count']}")
        
        return test_result
    
    async def test_fraud_detection_workflow(self) -> Dict:
        """Test fraud detection workflow."""
        print("\n[TEST] Fraud Detection Workflow")
        print("-" * 40)
        
        # Simulate suspicious activity
        query = Query(
            query_type="fraud_detection",
            parameters={
                "email": "suspicious@example.com",
                "phone": "555-999-8888",
                "ip_address": "192.168.1.100",
                "transaction_amount": 5000,
                "user_age_days": 2,
                "previous_transactions": 0,
                "shipping_address": {
                    "street": "123 Fake St",
                    "city": "Nowhere",
                    "state": "XX",
                    "zip": "00000"
                },
                "billing_address": {
                    "street": "456 Different St",
                    "city": "Elsewhere",
                    "state": "YY",
                    "zip": "11111"
                }
            },
            metadata={
                "test_type": "fraud_detection",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'fraud_detection',
            'input': 'Suspicious transaction',
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.risk_assessment:
            test_result['passed'] = True
            test_result['findings'] = {
                'risk_level': result.risk_assessment.get('level', 'unknown'),
                'risk_score': result.risk_assessment.get('score', 0),
                'fraud_indicators': len(result.risk_assessment.get('indicators', [])),
                'recommended_action': result.risk_assessment.get('action', 'review')
            }
            
            print(f"✓ Fraud detection completed in {elapsed:.2f}s")
            print(f"  - Risk Level: {test_result['findings']['risk_level']}")
            print(f"  - Risk Score: {test_result['findings']['risk_score']:.2f}")
            print(f"  - Fraud Indicators: {test_result['findings']['fraud_indicators']}")
            print(f"  - Action: {test_result['findings']['recommended_action']}")
        else:
            print(f"✗ Fraud detection failed")
        
        return test_result
    
    async def test_cost_optimization(self) -> Dict:
        """Test cost optimization features."""
        print("\n[TEST] Cost Optimization")
        print("-" * 40)
        
        # Run investigation with cost limits
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "Cost",
                "last_name": "Test",
                "city": "Boston",
                "optimize_cost": True,
                "max_cost": 10.00,
                "required_data": ["name", "address", "phone"],
                "optional_data": ["criminal", "property", "vehicles"]
            },
            metadata={
                "test_type": "cost_optimization",
                "track_costs": True
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'cost_optimization',
            'input': 'Cost-limited search',
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.metadata:
            cost_data = result.metadata.get('cost', {})
            test_result['passed'] = cost_data.get('total', 0) <= 10.00
            test_result['findings'] = {
                'total_cost': cost_data.get('total', 0),
                'api_calls': cost_data.get('api_calls', 0),
                'data_sources': len(cost_data.get('breakdown', {})),
                'under_budget': cost_data.get('total', 0) <= 10.00,
                'optimization_saved': cost_data.get('saved', 0)
            }
            
            print(f"✓ Cost optimization test completed in {elapsed:.2f}s")
            print(f"  - Total Cost: ${test_result['findings']['total_cost']:.2f}")
            print(f"  - Under Budget: {test_result['findings']['under_budget']}")
            print(f"  - Saved: ${test_result['findings']['optimization_saved']:.2f}")
        else:
            print(f"✗ Cost optimization test failed")
        
        return test_result
    
    async def test_compliance_workflow(self) -> Dict:
        """Test compliance and data protection workflows."""
        print("\n[TEST] Compliance Workflow")
        print("-" * 40)
        
        # Test GDPR compliance
        query = Query(
            query_type="person_search",
            parameters={
                "first_name": "Jane",
                "last_name": "European",
                "country": "Germany",
                "compliance_mode": "GDPR",
                "consent_id": "consent-123-456",
                "purpose": "legitimate_interest",
                "retention_days": 30
            },
            metadata={
                "test_type": "compliance",
                "jurisdiction": "EU"
            }
        )
        
        start_time = time.time()
        result = await self.orchestrator.investigate(query)
        elapsed = time.time() - start_time
        
        test_result = {
            'test': 'compliance_workflow',
            'input': 'GDPR-compliant search',
            'passed': False,
            'elapsed_time': elapsed,
            'findings': {}
        }
        
        if result and result.metadata:
            compliance_data = result.metadata.get('compliance', {})
            test_result['passed'] = compliance_data.get('gdpr_compliant', False)
            test_result['findings'] = {
                'gdpr_compliant': compliance_data.get('gdpr_compliant', False),
                'consent_verified': compliance_data.get('consent_verified', False),
                'data_minimization': compliance_data.get('data_minimization', False),
                'retention_set': compliance_data.get('retention_days', 0) > 0,
                'audit_logged': compliance_data.get('audit_logged', False)
            }
            
            print(f"✓ Compliance test completed in {elapsed:.2f}s")
            print(f"  - GDPR Compliant: {test_result['findings']['gdpr_compliant']}")
            print(f"  - Consent Verified: {test_result['findings']['consent_verified']}")
            print(f"  - Audit Logged: {test_result['findings']['audit_logged']}")
        else:
            print(f"✗ Compliance test failed")
        
        return test_result
    
    async def run_all_tests(self) -> Dict:
        """Run all real-world tests."""
        await self.setup()
        
        try:
            print("\n" + "="*60)
            print("REAL-WORLD TESTING SUITE")
            print("="*60)
            
            # Run each test
            self.results.append(await self.test_phone_number_investigation())
            self.results.append(await self.test_business_comprehensive_search())
            self.results.append(await self.test_person_deep_investigation())
            self.results.append(await self.test_email_validation_batch())
            self.results.append(await self.test_address_enrichment())
            self.results.append(await self.test_fraud_detection_workflow())
            self.results.append(await self.test_cost_optimization())
            self.results.append(await self.test_compliance_workflow())
            
            # Calculate summary
            total_tests = len(self.results)
            passed_tests = sum(1 for r in self.results if r['passed'])
            total_time = sum(r['elapsed_time'] for r in self.results)
            
            summary = {
                'total': total_tests,
                'passed': passed_tests,
                'failed': total_tests - passed_tests,
                'success_rate': (passed_tests / total_tests * 100) if total_tests else 0,
                'total_time': total_time,
                'avg_time': total_time / total_tests if total_tests else 0,
                'results': self.results
            }
            
            print("\n" + "="*60)
            print("REAL-WORLD TEST SUMMARY")
            print("="*60)
            print(f"Total Tests: {summary['total']}")
            print(f"Passed: {summary['passed']}")
            print(f"Failed: {summary['failed']}")
            print(f"Success Rate: {summary['success_rate']:.1f}%")
            print(f"Total Time: {summary['total_time']:.2f}s")
            print(f"Average Time: {summary['avg_time']:.2f}s")
            
            return summary
            
        finally:
            await self.teardown()


# Pytest integration
@pytest.mark.asyncio
class TestRealWorldScenarios:
    """Pytest wrapper for real-world tests."""
    
    @pytest_asyncio.fixture
    async def test_suite(self):
        """Create test suite instance."""
        suite = RealWorldTestSuite()
        await suite.setup()
        yield suite
        await suite.teardown()
    
    async def test_all_scenarios(self, test_suite):
        """Run all real-world scenarios."""
        results = await test_suite.run_all_tests()
        assert results['success_rate'] >= 80  # At least 80% should pass