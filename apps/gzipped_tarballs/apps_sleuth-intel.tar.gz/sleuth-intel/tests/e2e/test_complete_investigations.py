"""End-to-end tests for complete investigation scenarios."""

import asyncio
import json
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.orchestration.sleuth_orchestrator import SleuthOrchestrator
from tests.fixtures.mock_data import MockDataGenerator


class TestCompleteInvestigations:
    """Test complete investigation scenarios."""
    
    @pytest.fixture
    async def system(self, test_config):
        """Create a complete system instance."""
        system = await create_test_system(test_config)
        yield system
        await system.shutdown()
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_person_background_check(self, system, mock_data_generator):
        """Test complete person background check."""
        # Setup mock data
        person = mock_data_generator.create_person(
            first_name="John",
            last_name="Doe",
            age=35,
            emails=["john.doe@example.com", "jdoe@company.com"],
            phones=["(555) 123-4567"],
            addresses=[{
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001"
            }]
        )
        
        business = mock_data_generator.create_business(
            name="Tech Solutions Inc",
            ein="12-3456789"
        )
        
        # Configure mock responses
        system.api_client.search_person.return_value = [person]
        system.api_client.search_business.return_value = [business]
        system.api_client.search_email.return_value = [person]
        system.api_client.search_phone.return_value = [person]
        system.api_client.search_address.return_value = [person]
        
        # Execute investigation
        investigation = {
            "type": "background_check",
            "subject": {
                "first_name": "John",
                "last_name": "Doe",
                "dob": "1989-01-15"
            },
            "scope": "comprehensive",
            "include": [
                "criminal_records",
                "employment_history",
                "education_verification",
                "financial_records",
                "social_media",
                "associates"
            ]
        }
        
        result = await system.investigate(investigation)
        
        # Verify comprehensive results
        assert result["status"] == "completed"
        assert result["subject"]["name"] == "John Doe"
        assert "criminal_records" in result["findings"]
        assert "employment_history" in result["findings"]
        assert "risk_assessment" in result
        assert result["risk_assessment"]["level"] in ["low", "medium", "high"]
        assert len(result["data_sources"]) > 3
        assert result["confidence_score"] >= 0.7
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_business_due_diligence(self, system, mock_data_generator):
        """Test complete business due diligence."""
        business = mock_data_generator.create_business(
            name="Global Tech Solutions LLC",
            ein="98-7654321",
            industry="Technology",
            employees=150,
            revenue=25000000
        )
        
        officers = [
            mock_data_generator.create_person(first_name="Jane", last_name="Smith"),
            mock_data_generator.create_person(first_name="Robert", last_name="Johnson")
        ]
        
        # Configure mock responses
        system.api_client.search_business.return_value = [business]
        system.api_client.search_person.side_effect = [[officer] for officer in officers]
        
        # Execute investigation
        investigation = {
            "type": "business_due_diligence",
            "subject": {
                "name": "Global Tech Solutions LLC",
                "ein": "98-7654321"
            },
            "scope": "comprehensive",
            "include": [
                "corporate_structure",
                "financial_analysis",
                "legal_filings",
                "officers_background",
                "compliance_check",
                "market_analysis"
            ]
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert result["business"]["name"] == "Global Tech Solutions LLC"
        assert "corporate_structure" in result["findings"]
        assert "officers" in result["findings"]
        assert len(result["findings"]["officers"]) == 2
        assert "compliance_status" in result
        assert "financial_health" in result
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_fraud_investigation(self, system, mock_data_generator):
        """Test fraud investigation scenario."""
        suspect = mock_data_generator.create_person(
            first_name="Alice",
            last_name="Suspect",
            emails=["alice@fake.com", "alice.suspect@scam.org"]
        )
        
        related_businesses = [
            mock_data_generator.create_business(name="Fake Corp", status="Dissolved"),
            mock_data_generator.create_business(name="Scam LLC", status="Inactive")
        ]
        
        # Configure suspicious patterns
        system.api_client.search_person.return_value = [suspect]
        system.api_client.search_business.return_value = related_businesses
        
        investigation = {
            "type": "fraud_investigation",
            "subject": {
                "email": "alice@fake.com"
            },
            "indicators": [
                "multiple_identities",
                "business_associations",
                "financial_anomalies",
                "communication_patterns"
            ]
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert result["fraud_risk"]["level"] == "high"
        assert len(result["red_flags"]) > 0
        assert "multiple_businesses_dissolved" in result["red_flags"]
        assert result["recommendations"][0] == "Further investigation recommended"
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_relationship_mapping(self, system, mock_data_generator):
        """Test relationship and network mapping."""
        # Create network of people
        main_subject = mock_data_generator.create_person(
            first_name="Central",
            last_name="Figure"
        )
        
        associates = [
            mock_data_generator.create_person() for _ in range(5)
        ]
        
        businesses = [
            mock_data_generator.create_business() for _ in range(3)
        ]
        
        # Configure relationships
        system.api_client.search_person.return_value = [main_subject] + associates
        system.api_client.search_business.return_value = businesses
        
        investigation = {
            "type": "relationship_mapping",
            "subject": {
                "first_name": "Central",
                "last_name": "Figure"
            },
            "depth": 2,  # Two degrees of separation
            "include": [
                "family_members",
                "business_associates",
                "shared_addresses",
                "shared_phones"
            ]
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert "network" in result
        assert len(result["network"]["nodes"]) > 5
        assert len(result["network"]["edges"]) > 0
        assert "relationship_summary" in result
        assert result["network"]["central_figure"] == "Central Figure"
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_multi_source_verification(self, system, mock_data_generator):
        """Test multi-source data verification."""
        person = mock_data_generator.create_person(
            first_name="Verify",
            last_name="Me"
        )
        
        # Different sources return slightly different data
        source1_data = person.model_copy()
        source1_data.age = 35
        
        source2_data = person.model_copy()
        source2_data.age = 36
        
        source3_data = person.model_copy()
        source3_data.age = 35
        
        system.api_client.search_person.side_effect = [
            [source1_data],
            [source2_data],
            [source3_data]
        ]
        
        investigation = {
            "type": "identity_verification",
            "subject": {
                "first_name": "Verify",
                "last_name": "Me"
            },
            "verification_level": "high",
            "sources": ["source1", "source2", "source3"]
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert "verification_score" in result
        assert result["verification_score"] >= 0.8  # High confidence
        assert "discrepancies" in result
        assert "age" in result["discrepancies"]  # Age mismatch detected
        assert result["verified_data"]["age"] == 35  # Majority value
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_real_time_monitoring(self, system):
        """Test real-time monitoring scenario."""
        monitoring_config = {
            "type": "continuous_monitoring",
            "subjects": [
                {"first_name": "Monitor", "last_name": "One"},
                {"first_name": "Monitor", "last_name": "Two"}
            ],
            "alert_conditions": [
                "new_criminal_record",
                "address_change",
                "new_business_registration",
                "bankruptcy_filing"
            ],
            "check_interval": 1,  # 1 second for testing
            "duration": 5  # Monitor for 5 seconds
        }
        
        alerts = []
        
        async def alert_handler(alert):
            alerts.append(alert)
        
        system.on_alert = alert_handler
        
        # Start monitoring
        monitoring_task = asyncio.create_task(
            system.monitor(monitoring_config)
        )
        
        # Simulate alert condition after 2 seconds
        await asyncio.sleep(2)
        system.api_client.search_person.return_value = [
            mock_data_generator.create_person(
                first_name="Monitor",
                last_name="One",
                criminal_records=[{"type": "misdemeanor", "date": "2024-01-01"}]
            )
        ]
        
        # Wait for monitoring to complete
        await monitoring_task
        
        assert len(alerts) > 0
        assert alerts[0]["type"] == "new_criminal_record"
        assert alerts[0]["subject"]["name"] == "Monitor One"
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_batch_investigation(self, system, mock_data_generator):
        """Test batch investigation processing."""
        # Create batch of subjects
        subjects = [
            {"first_name": f"Person{i}", "last_name": "Test"}
            for i in range(10)
        ]
        
        # Configure mock responses
        for i in range(10):
            person = mock_data_generator.create_person(
                first_name=f"Person{i}",
                last_name="Test"
            )
            system.api_client.search_person.return_value.append([person])
        
        batch_investigation = {
            "type": "batch_background_check",
            "subjects": subjects,
            "parallel_processing": True,
            "max_concurrent": 5
        }
        
        results = await system.investigate_batch(batch_investigation)
        
        assert len(results) == 10
        assert all(r["status"] == "completed" for r in results)
        assert results[0]["subject"]["first_name"] == "Person0"
        assert results[9]["subject"]["first_name"] == "Person9"
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_investigation_with_export(self, system, mock_data_generator, temp_directory):
        """Test investigation with result export."""
        person = mock_data_generator.create_person()
        system.api_client.search_person.return_value = [person]
        
        investigation = {
            "type": "background_check",
            "subject": {
                "first_name": person.first_name,
                "last_name": person.last_name
            },
            "export": {
                "formats": ["json", "pdf", "csv"],
                "output_dir": str(temp_directory)
            }
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert "export_files" in result
        
        # Verify exported files
        for format in ["json", "pdf", "csv"]:
            file_path = Path(result["export_files"][format])
            assert file_path.exists()
            
            if format == "json":
                with open(file_path) as f:
                    exported_data = json.load(f)
                assert exported_data["subject"]["first_name"] == person.first_name


class TestErrorScenarios:
    """Test error handling in end-to-end scenarios."""
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_api_failure_recovery(self, system):
        """Test recovery from API failures."""
        # Configure intermittent failures
        call_count = 0
        
        async def flaky_search(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count % 3 == 0:
                raise Exception("API temporarily unavailable")
            return []
        
        system.api_client.search_person = flaky_search
        
        investigation = {
            "type": "background_check",
            "subject": {"first_name": "Test", "last_name": "User"},
            "retry_strategy": "exponential_backoff",
            "max_retries": 5
        }
        
        result = await system.investigate(investigation)
        
        # Should eventually complete despite failures
        assert result["status"] in ["completed", "partial"]
        assert result["retry_count"] > 0
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_data_inconsistency_handling(self, system, mock_data_generator):
        """Test handling of inconsistent data."""
        # Create conflicting data
        person1 = mock_data_generator.create_person(
            first_name="John",
            last_name="Doe",
            date_of_birth="1985-01-15"
        )
        
        person2 = mock_data_generator.create_person(
            first_name="John",
            last_name="Doe",
            date_of_birth="1986-01-15"  # Different DOB
        )
        
        system.api_client.search_person.return_value = [person1, person2]
        
        investigation = {
            "type": "identity_verification",
            "subject": {"first_name": "John", "last_name": "Doe"},
            "handle_duplicates": "analyze"
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "completed"
        assert "duplicate_analysis" in result
        assert result["duplicate_analysis"]["potential_duplicates"] == 2
        assert "confidence_score" in result["duplicate_analysis"]
    
    @pytest.mark.asyncio
    @pytest.mark.e2e
    async def test_performance_degradation(self, system):
        """Test system behavior under performance degradation."""
        # Simulate slow API responses
        async def slow_search(*args, **kwargs):
            await asyncio.sleep(5)  # 5 second delay
            return []
        
        system.api_client.search_person = slow_search
        
        investigation = {
            "type": "background_check",
            "subject": {"first_name": "Test", "last_name": "User"},
            "timeout": 3,  # 3 second timeout
            "fallback_mode": "cached_only"
        }
        
        result = await system.investigate(investigation)
        
        assert result["status"] == "timeout"
        assert result["fallback_used"] == True
        assert "cached_results" in result


async def create_test_system(config):
    """Create a complete test system."""
    from src.orchestration.sleuth_orchestrator import SleuthOrchestrator
    from src.providers.enhanced_enformion_client import EnhancedEnformionClient
    from src.orchestration.message_bus import MessageBus
    
    # Initialize components
    api_client = MagicMock(spec=EnhancedEnformionClient)
    api_client.search_person = AsyncMock(return_value=[])
    api_client.search_business = AsyncMock(return_value=[])
    api_client.search_email = AsyncMock(return_value=[])
    api_client.search_phone = AsyncMock(return_value=[])
    api_client.search_address = AsyncMock(return_value=[])
    
    message_bus = MessageBus()
    await message_bus.start()
    
    orchestrator = SleuthOrchestrator(
        api_client=api_client,
        message_bus=message_bus
    )
    await orchestrator.initialize()
    
    class TestSystem:
        def __init__(self):
            self.api_client = api_client
            self.message_bus = message_bus
            self.orchestrator = orchestrator
        
        async def investigate(self, config):
            return await self.orchestrator.execute_investigation(config)
        
        async def investigate_batch(self, config):
            return await self.orchestrator.execute_batch_investigation(config)
        
        async def monitor(self, config):
            return await self.orchestrator.monitor_subjects(config)
        
        async def shutdown(self):
            await self.orchestrator.shutdown()
            await self.message_bus.stop()
    
    return TestSystem()