"""
Integration tests for DataEnrichmentAgent
Tests comprehensive data enrichment, cross-referencing, and integration with all other agents
"""

import asyncio
import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

from src.agents.data_enrichment_agent import (
    DataEnrichmentAgent, DataEnrichmentConfig, SourceReliabilityScore, EnrichmentMetrics
)
from src.agents.person_search_agent import PersonSearchAgent
from src.agents.business_search_agent import BusinessSearchAgent
from src.agents.phone_search_agent import PhoneSearchAgent
from src.agents.email_search_agent import EmailSearchAgent
from src.agents.address_search_agent import AddressSearchAgent

from src.models.person import PersonProfile, PersonName, Demographics, Phone, Email, Address, Associate, PhoneType
from src.models.business import BusinessProfile, BusinessLocation, Principal, EntityType, BusinessStatus
from src.models.query import PersonSearchQuery, BusinessSearchQuery
from src.models.intelligence import (
    PersonIntelligenceResult, BusinessIntelligenceResult, ComprehensiveIntelligenceResult,
    ConfidenceScoring, ConfidenceLevel, DataSource, DataCorrelation, QueryMetadata
)


class TestDataEnrichmentAgent:
    """Test DataEnrichmentAgent functionality"""
    
    @pytest.fixture
    def mock_person_agent(self):
        """Mock PersonSearchAgent"""
        agent = Mock(spec=PersonSearchAgent)
        agent.search = Mock()
        return agent
    
    @pytest.fixture
    def mock_business_agent(self):
        """Mock BusinessSearchAgent"""
        agent = Mock(spec=BusinessSearchAgent)
        agent.search = Mock()
        return agent
    
    @pytest.fixture
    def mock_phone_agent(self):
        """Mock PhoneSearchAgent"""
        agent = Mock(spec=PhoneSearchAgent)
        agent.query = Mock()
        return agent
    
    @pytest.fixture
    def mock_email_agent(self):
        """Mock EmailSearchAgent"""
        agent = Mock(spec=EmailSearchAgent)
        agent.query = Mock()
        return agent
    
    @pytest.fixture
    def mock_address_agent(self):
        """Mock AddressSearchAgent"""
        agent = Mock(spec=AddressSearchAgent)
        agent.query = Mock()
        return agent
    
    @pytest.fixture
    def sample_person_profiles(self):
        """Sample person profiles for testing"""
        profile1 = PersonProfile(
            name=PersonName(first="John", last="Doe", full="John Doe"),
            demographics=Demographics(age=35, birth_year=1988),
            phones=[
                Phone(number="5551234567", formatted="(555) 123-4567", type=PhoneType.MOBILE),
                Phone(number="5557654321", formatted="(555) 765-4321", type=PhoneType.LANDLINE)
            ],
            emails=[
                Email(address="john.doe@gmail.com", confidence_score=0.9),
                Email(address="j.doe@company.com", confidence_score=0.8)
            ],
            addresses=[
                Address(
                    street="123 Main St",
                    city="Anytown",
                    state="CA",
                    zip_code="90210",
                    confidence_score=0.9
                )
            ],
            associates=[
                Associate(
                    name=PersonName(first="Jane", last="Doe", full="Jane Doe"),
                    relationship="spouse",
                    confidence_score=0.8
                )
            ],
            source_provider="person-search",
            confidence_score=0.85
        )
        
        profile2 = PersonProfile(
            name=PersonName(first="John", last="Doe", full="John Doe"),
            demographics=Demographics(age=36, birth_year=1987),  # Slight age difference
            phones=[
                Phone(number="5551234567", formatted="(555) 123-4567", type=PhoneType.MOBILE),  # Same phone
                Phone(number="5559876543", formatted="(555) 987-6543", type=PhoneType.LANDLINE)     # Different second phone
            ],
            emails=[
                Email(address="john.doe@gmail.com", confidence_score=0.9),  # Same email
                Email(address="john.doe@yahoo.com", confidence_score=0.7)   # Different second email
            ],
            addresses=[
                Address(
                    street="123 Main Street",  # Slightly different format
                    city="Anytown",
                    state="CA",
                    zip_code="90210",
                    confidence_score=0.8
                )
            ],
            source_provider="phone-search",
            confidence_score=0.82
        )
        
        profile3 = PersonProfile(
            name=PersonName(first="John", last="Smith", full="John Smith"),  # Different last name
            demographics=Demographics(age=35),
            phones=[
                Phone(number="5551111111", formatted="(555) 111-1111", type=PhoneType.MOBILE)
            ],
            emails=[
                Email(address="john.smith@gmail.com", confidence_score=0.8)
            ],
            addresses=[
                Address(
                    street="456 Oak Ave",
                    city="Somewhere",
                    state="NY",
                    zip_code="10001",
                    confidence_score=0.9
                )
            ],
            source_provider="email-search",
            confidence_score=0.75
        )
        
        return [profile1, profile2, profile3]
    
    @pytest.fixture
    def sample_business_profiles(self):
        """Sample business profiles for testing"""
        profile1 = BusinessProfile(
            business_name="Acme Corporation",
            entity_type=EntityType.CORPORATION,
            status=BusinessStatus.ACTIVE,
            primary_location=BusinessLocation(
                address=Address(
                    street="100 Business Blvd",
                    city="Corporate City",
                    state="CA",
                    zip_code="90210"
                ),
                is_headquarters=True
            ),
            principals=[
                Principal(
                    name=PersonName(first="John", last="Doe", full="John Doe"),
                    title="CEO",
                    ownership_percentage=51.0
                )
            ],
            tax_id="12-3456789",
            source_provider="business-search",
            confidence_score=0.88
        )
        
        return [profile1]
    
    @pytest.fixture
    def enrichment_agent(self, mock_person_agent, mock_business_agent, mock_phone_agent, 
                        mock_email_agent, mock_address_agent):
        """DataEnrichmentAgent with mocked dependencies"""
        config = DataEnrichmentConfig(
            confidence_threshold=0.7,
            deduplication_threshold=0.9,
            enable_deep_enrichment=True,
            enable_anomaly_detection=True
        )
        
        return DataEnrichmentAgent(
            person_search_agent=mock_person_agent,
            business_search_agent=mock_business_agent,
            phone_search_agent=mock_phone_agent,
            email_search_agent=mock_email_agent,
            address_search_agent=mock_address_agent,
            enrichment_config=config
        )
    
    def test_agent_initialization(self, enrichment_agent):
        """Test DataEnrichmentAgent initialization"""
        assert enrichment_agent.agent_name == "DataEnrichmentAgent"
        assert enrichment_agent.provider == "data-enrichment"
        assert enrichment_agent.config.confidence_threshold == 0.7
        assert enrichment_agent.config.enable_deep_enrichment is True
        assert enrichment_agent.person_agent is not None
        assert enrichment_agent.business_agent is not None
    
    def test_similarity_calculation(self, enrichment_agent):
        """Test various similarity calculation methods"""
        # Text similarity
        assert enrichment_agent._calculate_similarity_score("John Doe", "John Doe") == 1.0
        assert enrichment_agent._calculate_similarity_score("John Doe", "Jon Doe") > 0.7  # Relaxed threshold
        assert enrichment_agent._calculate_similarity_score("John Doe", "Jane Smith") < 0.6  # Relaxed threshold
        
        # Phone similarity
        assert enrichment_agent._calculate_phone_similarity("555-123-4567", "5551234567") == 1.0
        assert enrichment_agent._calculate_phone_similarity("1-555-123-4567", "555-123-4567") == 1.0
        assert enrichment_agent._calculate_phone_similarity("555-123-4567", "999-123-4567") == 0.8  # Last 7 digits match
        assert enrichment_agent._calculate_phone_similarity("555-999-8888", "777-123-4567") == 0.0  # No match
        
        # Address similarity
        addr1 = {"street": "123 Main St", "city": "Anytown", "state": "CA", "zip_code": "90210"}
        addr2 = {"street": "123 Main Street", "city": "Anytown", "state": "CA", "zip_code": "90210"}
        addr3 = {"street": "456 Oak Ave", "city": "Otherville", "state": "NY", "zip_code": "10001"}
        
        assert enrichment_agent._calculate_address_similarity(addr1, addr2) > 0.8
        assert enrichment_agent._calculate_address_similarity(addr1, addr3) < 0.3
    
    def test_duplicate_detection(self, enrichment_agent, sample_person_profiles):
        """Test duplicate profile detection"""
        # Should detect profiles 1 and 2 as duplicates (same name, phone, email)
        duplicates = enrichment_agent._detect_duplicates(sample_person_profiles)
        
        assert len(duplicates) >= 1
        # Check that profiles 0 and 1 are identified as duplicates
        duplicate_pairs = [(i, j) for i, j, _ in duplicates]
        assert (0, 1) in duplicate_pairs or (1, 0) in duplicate_pairs
    
    def test_profile_merging(self, enrichment_agent, sample_person_profiles):
        """Test profile merging functionality"""
        # Get the first two profiles (they should be duplicates)
        profiles_to_merge = sample_person_profiles[:2]
        duplicates = [(0, 1, 0.95)]  # Mock duplicate detection result
        
        merged_profiles = enrichment_agent._merge_duplicate_profiles(profiles_to_merge, duplicates)
        
        assert len(merged_profiles) == 1  # Two profiles merged into one
        merged = merged_profiles[0]
        
        # Should have combined data from both profiles
        assert len(merged.phones) >= 2  # Should have phones from both profiles
        assert len(merged.emails) >= 2  # Should have emails from both profiles
        assert merged.confidence_score > max(p.confidence_score for p in profiles_to_merge)
    
    def test_cross_validation(self, enrichment_agent, sample_person_profiles):
        """Test cross-validation functionality"""
        correlation = enrichment_agent._cross_validate_data(sample_person_profiles)
        
        # Should find matches between profiles 1 and 2
        assert correlation.phone_matches >= 1  # Same phone number
        assert correlation.email_matches >= 1  # Same email address
        assert correlation.name_matches >= 1   # Same name
        assert correlation.correlation_score > 0.0
    
    def test_gap_identification(self, enrichment_agent, sample_person_profiles):
        """Test data gap identification"""
        # Create a profile with missing data
        incomplete_profile = PersonProfile(
            name=PersonName(first="Jane", last="Doe"),
            phones=[],  # Missing phones
            emails=[],  # Missing emails
            addresses=[],  # Missing addresses
            source_provider="test",
            confidence_score=0.5
        )
        
        gaps = enrichment_agent._identify_data_gaps([incomplete_profile])
        
        assert "Missing phone number information" in gaps
        assert "Missing email address information" in gaps
        assert "Missing address information" in gaps
    
    def test_anomaly_detection(self, enrichment_agent, sample_person_profiles):
        """Test anomaly detection"""
        # Add a profile with inconsistent age
        anomalous_profile = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            demographics=Demographics(age=80),  # Very different age
            phones=[Phone(number="5551234560", type=PhoneType.MOBILE)],  # Valid phone but different
            source_provider="test",
            confidence_score=0.6
        )
        
        profiles_with_anomaly = sample_person_profiles + [anomalous_profile]
        anomalies = enrichment_agent._detect_anomalies(profiles_with_anomaly)
        
        assert len(anomalies) > 0
        assert any("age" in anomaly.lower() for anomaly in anomalies)
    
    def test_pattern_recognition(self, enrichment_agent, sample_person_profiles):
        """Test pattern recognition"""
        patterns = enrichment_agent._recognize_patterns(sample_person_profiles)
        
        assert "dominant_area_code" in patterns
        assert "email_domains" in patterns
        assert "geographic_distribution" in patterns
        
        # Should identify 555 as dominant area code
        assert patterns["dominant_area_code"]["code"] == "555"
    
    def test_freshness_scoring(self, enrichment_agent):
        """Test data freshness scoring"""
        now = datetime.utcnow()
        
        sources = [
            DataSource(
                provider="recent",
                query_method="test",
                query_params={},
                timestamp=now - timedelta(hours=1)  # 1 hour old
            ),
            DataSource(
                provider="old",
                query_method="test",
                query_params={},
                timestamp=now - timedelta(days=100)  # 100 days old
            )
        ]
        
        freshness_score = enrichment_agent._calculate_data_freshness_score(sources)
        assert 0.0 < freshness_score < 1.0  # Should be between recent and old
    
    def test_source_reliability_tracking(self, enrichment_agent):
        """Test source reliability tracking"""
        # Update reliability for a provider
        enrichment_agent._update_source_reliability(
            provider="test-provider",
            success=True,
            accuracy=0.9,
            freshness=0.8,
            completeness=0.85
        )
        
        assert "test-provider" in enrichment_agent.source_reliability
        reliability = enrichment_agent.source_reliability["test-provider"]
        
        assert reliability.total_queries == 1
        assert reliability.successful_queries == 1
        # Check that accuracy_rate is properly averaged (should be 0.45 since it averages with initial 0.0)
        assert reliability.accuracy_rate > 0.0
        assert reliability.overall_reliability > 0.0
    
    @pytest.mark.asyncio
    async def test_person_data_enrichment(self, enrichment_agent, sample_person_profiles, 
                                        mock_person_agent, mock_phone_agent):
        """Test comprehensive person data enrichment"""
        query = PersonSearchQuery(
            first_name="John",
            last_name="Doe",
            phone="5551234567",
            city="Anytown",
            state="CA"
        )
        
        # Setup mock responses
        mock_person_agent.search.return_value = sample_person_profiles[:2]  # Return duplicates
        mock_phone_agent.query.return_value = [sample_person_profiles[1]]   # Return one match
        
        result = await enrichment_agent.enrich_person_data(query)
        
        assert isinstance(result, PersonIntelligenceResult)
        assert result.has_data is True
        assert result.person is not None
        assert result.confidence.overall_score > 0.0
        assert len(result.sources) > 0
        
        # Should have called multiple agents
        mock_person_agent.search.assert_called_once()
        mock_phone_agent.query.assert_called_once()
        
        # Should have enhanced confidence due to cross-validation (or at least have run the analysis)
        assert result.confidence.cross_validation >= 0.0
    
    @pytest.mark.asyncio
    async def test_comprehensive_data_enrichment(self, enrichment_agent, sample_person_profiles,
                                               sample_business_profiles, mock_person_agent, 
                                               mock_business_agent):
        """Test comprehensive data enrichment across person and business sources"""
        query = {
            "first_name": "John",
            "last_name": "Doe",
            "phone": "5551234567",
            "business_name": "Acme Corporation"
        }
        
        # Setup mock responses
        mock_person_agent.search.return_value = sample_person_profiles[:1]
        mock_business_agent.search.return_value = sample_business_profiles
        
        result = await enrichment_agent.enrich_comprehensive_data(query)
        
        assert isinstance(result, ComprehensiveIntelligenceResult)
        assert result.has_person_data is True
        assert result.has_business_data is True
        assert len(result.person_results) > 0
        assert len(result.business_results) > 0
        assert result.overall_confidence.overall_score > 0.0
    
    def test_sync_query_interface(self, enrichment_agent):
        """Test synchronous query interface"""
        query_params = {
            "first_name": "John",
            "last_name": "Doe",
            "phone": "5551234567"
        }
        
        # Mock the async method
        with patch.object(enrichment_agent, 'enrich_comprehensive_data') as mock_enrich:
            mock_result = ComprehensiveIntelligenceResult(
                person_results=[],
                business_results=[],
                overall_confidence=ConfidenceScoring(overall_score=0.8),
                query_metadata=QueryMetadata(
                    query_id="test",
                    query_type="test",
                    original_query=query_params,
                    execution_time=1.0,
                    sources_queried=1,
                    sources_successful=1
                )
            )
            mock_enrich.return_value = mock_result
            
            result = enrichment_agent.query(query_params)
            
            assert isinstance(result, ComprehensiveIntelligenceResult)
            mock_enrich.assert_called_once_with(query_params)
    
    def test_source_reliability_report(self, enrichment_agent):
        """Test source reliability reporting"""
        # Add some reliability data
        enrichment_agent._update_source_reliability("provider1", True, 0.9, 0.8, 0.85)
        enrichment_agent._update_source_reliability("provider2", True, 0.7, 0.6, 0.75)
        enrichment_agent._update_source_reliability("provider1", False, 0.5, 0.4, 0.6)
        
        report = enrichment_agent.get_source_reliability_report()
        
        assert "sources" in report
        assert "summary" in report
        assert len(report["sources"]) == 2
        assert "provider1" in report["sources"]
        assert "provider2" in report["sources"]
        
        assert report["summary"]["total_sources"] == 2
        assert report["summary"]["avg_reliability"] > 0.0
        assert report["summary"]["most_reliable"] in ["provider1", "provider2"]
    
    def test_health_check(self, enrichment_agent):
        """Test health check functionality"""
        health = enrichment_agent.health_check()
        
        assert health["status"] == "healthy"
        assert health["data_enrichment_ready"] is True
        assert health["available_agents"] == 5  # All agents are mocked and available
        assert "agent_status" in health
        assert "enrichment_config" in health
        
        # Check individual agent status
        agent_status = health["agent_status"]
        assert agent_status["person_agent"] is True
        assert agent_status["business_agent"] is True
        assert agent_status["phone_agent"] is True
        assert agent_status["email_agent"] is True
        assert agent_status["address_agent"] is True


class TestEnrichmentEdgeCases:
    """Test edge cases and error conditions"""
    
    @pytest.fixture
    def minimal_agent(self):
        """DataEnrichmentAgent with no dependencies"""
        return DataEnrichmentAgent()
    
    def test_no_agents_available(self, minimal_agent):
        """Test behavior when no sub-agents are available"""
        health = minimal_agent.health_check()
        
        assert health["available_agents"] == 0
        assert health["data_enrichment_ready"] is False
    
    @pytest.mark.asyncio
    async def test_empty_results(self, minimal_agent):
        """Test handling of empty results from agents"""
        query = PersonSearchQuery(first_name="NonExistent", last_name="Person")
        
        result = await minimal_agent.enrich_person_data(query)
        
        assert isinstance(result, PersonIntelligenceResult)
        assert result.has_data is False
        assert result.confidence.overall_score == 0.0
        # Check if the warning contains relevant text
        warnings = result.confidence.warnings
        assert len(warnings) > 0
        assert any("No data found" in warning or "sources" in warning for warning in warnings)
    
    def test_duplicate_detection_empty_list(self, minimal_agent):
        """Test duplicate detection with empty profile list"""
        duplicates = minimal_agent._detect_duplicates([])
        assert duplicates == []
    
    def test_duplicate_detection_single_profile(self, minimal_agent):
        """Test duplicate detection with single profile"""
        profile = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            source_provider="test",
            confidence_score=0.8
        )
        
        duplicates = minimal_agent._detect_duplicates([profile])
        assert duplicates == []
    
    def test_cross_validation_insufficient_data(self, minimal_agent):
        """Test cross-validation with insufficient data"""
        profile = PersonProfile(
            name=PersonName(first="John", last="Doe"),
            source_provider="test",
            confidence_score=0.8
        )
        
        correlation = minimal_agent._cross_validate_data([profile])
        assert correlation.correlation_score == 0.0
        assert correlation.phone_matches == 0
        assert correlation.email_matches == 0
    
    def test_pattern_recognition_empty_data(self, minimal_agent):
        """Test pattern recognition with no data"""
        patterns = minimal_agent._recognize_patterns([])
        assert patterns == {}
    
    def test_freshness_scoring_no_sources(self, minimal_agent):
        """Test freshness scoring with no sources"""
        score = minimal_agent._calculate_data_freshness_score([])
        assert score == 0.0


class TestDataEnrichmentConfiguration:
    """Test configuration and customization options"""
    
    def test_custom_configuration(self):
        """Test custom enrichment configuration"""
        config = DataEnrichmentConfig(
            confidence_threshold=0.9,
            deduplication_threshold=0.95,
            correlation_threshold=0.85,
            max_sources_per_query=10,
            enable_deep_enrichment=False,
            enable_anomaly_detection=False,
            freshness_penalty_days=60
        )
        
        agent = DataEnrichmentAgent(enrichment_config=config)
        
        assert agent.config.confidence_threshold == 0.9
        assert agent.config.deduplication_threshold == 0.95
        assert agent.config.enable_deep_enrichment is False
        assert agent.config.enable_anomaly_detection is False
        assert agent.config.freshness_penalty_days == 60
    
    def test_source_reliability_score_calculation(self):
        """Test SourceReliabilityScore calculations"""
        score = SourceReliabilityScore(
            provider="test",
            total_queries=100,
            successful_queries=90,
            accuracy_rate=0.85,
            freshness_score=0.9,
            completeness_score=0.8,
            consistency_score=0.75
        )
        
        reliability = score.overall_reliability
        assert 0.0 <= reliability <= 1.0
        assert reliability > 0.5  # Should be good with these scores
    
    def test_enrichment_metrics_tracking(self):
        """Test EnrichmentMetrics data structure"""
        metrics = EnrichmentMetrics(
            sources_queried=5,
            sources_successful=4,
            duplicates_found=3,
            duplicates_merged=2,
            data_gaps_identified=1,
            anomalies_detected=1
        )
        
        assert metrics.sources_queried == 5
        assert metrics.sources_successful == 4
        assert metrics.duplicates_found == 3
        assert len(metrics.data_quality_warnings) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])