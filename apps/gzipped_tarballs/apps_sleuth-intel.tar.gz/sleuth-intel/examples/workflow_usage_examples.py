"""
Workflow Template Usage Examples

Demonstrates how to use the workflow templates for common investigation scenarios.
Each example shows different depth levels and customization options.
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, Any, List

from src.orchestration.workflow_templates import (
    WorkflowTemplateManager,
    InvestigationDepth,
    WorkflowBudget,
    WorkflowCustomization,
    phone_investigation_workflow,
    person_investigation_workflow,
    business_due_diligence_workflow,
    address_analysis_workflow,
    bulk_processing_workflow
)
from src.orchestration.sleuth_orchestrator import SleuthIntelOrchestrator


async def example_phone_investigation():
    """Example: Phone number investigation with different depth levels"""
    print("=== Phone Investigation Workflow Examples ===\n")
    
    phone_number = "+1-555-123-4567"
    orchestrator = SleuthIntelOrchestrator()
    
    # Basic phone investigation
    print("1. Basic Phone Investigation:")
    result = await phone_investigation_workflow(
        phone_number=phone_number,
        depth=InvestigationDepth.BASIC,
        orchestrator=orchestrator
    )
    print(f"   Cost: ${result['metadata']['total_cost']:.2f}")
    print(f"   Time: {result['metadata']['execution_time']:.1f}s")
    print(f"   Success Rate: {result['metadata']['success_rate']:.1%}\n")
    
    # Comprehensive investigation with budget constraints
    print("2. Comprehensive Phone Investigation (Budget Constrained):")
    budget = WorkflowBudget(
        max_cost_usd=3.00,
        max_time_minutes=5
    )
    
    result = await phone_investigation_workflow(
        phone_number=phone_number,
        depth=InvestigationDepth.COMPREHENSIVE,
        orchestrator=orchestrator,
        budget=budget
    )
    print(f"   Cost: ${result['metadata']['total_cost']:.2f}")
    print(f"   Agents Used: {', '.join(result['metadata']['agents_used'])}\n")
    
    # Deep investigation with customizations
    print("3. Deep Phone Investigation (Customized):")
    customization = WorkflowCustomization(
        skip_agents=['email_search_agent'],  # Skip email search
        additional_agents=['analysis_agent'],  # Add analysis
        custom_config={
            'correlation_threshold': 0.9,
            'max_parallel_agents': 3
        }
    )
    
    result = await phone_investigation_workflow(
        phone_number=phone_number,
        depth=InvestigationDepth.DEEP,
        orchestrator=orchestrator,
        customization=customization
    )
    print(f"   Correlations Found: {len(result['results']['correlations'])}")
    print(f"   Coverage Score: {result['results']['summary']['coverage_score']:.1%}\n")


async def example_person_investigation():
    """Example: Person investigation with progress tracking"""
    print("=== Person Investigation Workflow Example ===\n")
    
    async def progress_callback(update):
        print(f"Progress: {update['progress']:.1%} - Status: {update['status']}")
        if update['errors']:
            print(f"Errors: {update['errors']}")
    
    print("Person Investigation with Progress Tracking:")
    result = await person_investigation_workflow(
        first_name="John",
        last_name="Smith",
        city="Los Angeles",
        state="CA",
        depth=InvestigationDepth.COMPREHENSIVE,
        progress_callback=progress_callback
    )
    
    print(f"\nResults Summary:")
    print(f"   Unique Data Points: {result['results']['summary']['unique_data_points']}")
    print(f"   Data Sources: {', '.join(result['results']['data_sources'])}")
    print(f"   Confidence Scores: {result['results']['confidence_scores']}\n")


async def example_business_due_diligence():
    """Example: Business due diligence with multiple output formats"""
    print("=== Business Due Diligence Workflow Example ===\n")
    
    orchestrator = SleuthIntelOrchestrator()
    manager = WorkflowTemplateManager(orchestrator)
    
    # Execute comprehensive business investigation
    result = await manager.execute_workflow(
        template_type='business_due_diligence',
        depth='comprehensive',
        query_data={
            'company_name': 'Acme Corporation',
            'city': 'New York',
            'state': 'NY'
        }
    )
    
    print("Business Due Diligence Results:")
    print(f"   Template Used: {result['template']}")
    print(f"   Execution Time: {result['metadata']['execution_time']:.1f}s")
    print(f"   Total Cost: ${result['metadata']['total_cost']:.2f}")
    
    # Export results to different formats
    await export_results_example(result, 'business_due_diligence')
    print("   Results exported to multiple formats\n")


async def example_address_analysis():
    """Example: Address analysis with error handling"""
    print("=== Address Analysis Workflow Example ===\n")
    
    try:
        result = await address_analysis_workflow(
            street_address="123 Main Street",
            city="Anytown",
            state="CA",
            zip_code="90210",
            depth=InvestigationDepth.DEEP
        )
        
        print("Address Analysis Results:")
        print(f"   Success Rate: {result['metadata']['success_rate']:.1%}")
        print(f"   Coverage Score: {result['results']['summary']['coverage_score']:.1%}")
        
        if result['results']['correlations']:
            print(f"   Found {len(result['results']['correlations'])} correlations:")
            for corr in result['results']['correlations'][:3]:  # Show first 3
                print(f"     - Correlation Score: {corr['correlation_score']:.2f}")
                print(f"       Common Fields: {', '.join(corr['common_fields'])}")
        
    except Exception as e:
        print(f"Error during address analysis: {e}")
        print("This demonstrates error handling in workflow execution\n")


async def example_bulk_processing():
    """Example: Bulk processing with optimization"""
    print("=== Bulk Processing Workflow Example ===\n")
    
    # Sample bulk data
    bulk_records = [
        {'first_name': 'John', 'last_name': 'Doe', 'city': 'Seattle', 'state': 'WA'},
        {'first_name': 'Jane', 'last_name': 'Smith', 'city': 'Portland', 'state': 'OR'},
        {'company_name': 'Tech Startup Inc', 'city': 'San Francisco', 'state': 'CA'},
        {'phone_number': '+1-555-987-6543'},
        {'email_address': 'contact@example.com'}
    ]
    
    # Set budget constraints for bulk processing
    budget = WorkflowBudget(
        max_cost_usd=10.00,
        max_time_minutes=15
    )
    
    print(f"Processing {len(bulk_records)} records...")
    result = await bulk_processing_workflow(
        records=bulk_records,
        depth=InvestigationDepth.BASIC,
        budget=budget
    )
    
    print(f"Bulk Processing Results:")
    print(f"   Records Processed: {len(bulk_records)}")
    print(f"   Total Cost: ${result['metadata']['total_cost']:.2f}")
    print(f"   Average Cost per Record: ${result['metadata']['total_cost'] / len(bulk_records):.2f}")
    print(f"   Success Rate: {result['metadata']['success_rate']:.1%}\n")


async def example_workflow_estimation():
    """Example: Cost and time estimation before execution"""
    print("=== Workflow Cost Estimation Examples ===\n")
    
    orchestrator = SleuthIntelOrchestrator()
    manager = WorkflowTemplateManager(orchestrator)
    
    # Get available templates
    templates = manager.get_available_templates()
    print("Available Workflow Templates:")
    for template_type, depths in templates.items():
        print(f"\n{template_type.replace('_', ' ').title()}:")
        for depth, details in depths.items():
            print(f"  {depth}: {details['description']}")
            print(f"    Estimated Cost: ${details['estimated_cost']:.2f}")
            print(f"    Estimated Time: {details['estimated_time_minutes']} minutes")
    
    print("\n" + "="*50)
    print("Cost Estimation Examples:")
    
    # Estimate different scenarios
    scenarios = [
        ('phone_investigation', 'basic', 1),
        ('person_investigation', 'comprehensive', 1),
        ('business_due_diligence', 'deep', 1),
        ('bulk_processing', 'basic', 100)
    ]
    
    for template_type, depth, record_count in scenarios:
        estimation = manager.estimate_workflow_cost(template_type, depth, record_count)
        print(f"\n{template_type.replace('_', ' ').title()} ({depth}) - {record_count} record(s):")
        print(f"   Total Estimated Cost: ${estimation['total_estimated_cost']:.2f}")
        print(f"   Per Record Cost: ${estimation['per_record_cost']:.2f}")


async def example_custom_workflow():
    """Example: Creating a custom workflow with specific requirements"""
    print("\n=== Custom Workflow Example ===\n")
    
    orchestrator = SleuthIntelOrchestrator()
    manager = WorkflowTemplateManager(orchestrator)
    
    # Custom workflow for fraud investigation
    customization = WorkflowCustomization(
        additional_agents=['data_enrichment_agent', 'analysis_agent'],
        custom_config={
            'correlation_threshold': 0.95,  # High correlation required
            'max_parallel_agents': 6,
            'enable_caching': False,  # Fresh data only
            'retry_failed_queries': True,
            'max_retries': 5
        },
        result_filters=['high_confidence_only'],
        correlation_rules={
            'require_multi_source_verification': True,
            'flag_inconsistencies': True
        }
    )
    
    budget = WorkflowBudget(
        max_cost_usd=50.00,
        max_time_minutes=30,
        priority_allocation={
            'person_search_agent': 0.4,
            'business_search_agent': 0.3,
            'data_enrichment_agent': 0.2,
            'analysis_agent': 0.1
        }
    )
    
    print("Executing Custom Fraud Investigation Workflow:")
    result = await manager.execute_workflow(
        template_type='person_investigation',
        depth='deep',
        query_data={
            'first_name': 'Suspected',
            'last_name': 'Fraudster',
            'city': 'Miami',
            'state': 'FL'
        },
        budget=budget,
        customization=customization
    )
    
    print(f"   High-confidence correlations: {len([c for c in result['results']['correlations'] if c['correlation_score'] > 0.95])}")
    print(f"   Data integrity score: {result['results']['summary']['coverage_score']:.1%}")
    print(f"   Budget utilization: ${result['metadata']['total_cost']:.2f} / ${budget.max_cost_usd:.2f}\n")


async def export_results_example(result: Dict[str, Any], workflow_type: str):
    """Example: Export results to different formats"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Export to JSON
    json_filename = f"results_{workflow_type}_{timestamp}.json"
    with open(json_filename, 'w') as f:
        json.dump(result, f, indent=2, default=str)
    
    # Export summary to CSV (simplified example)
    csv_filename = f"summary_{workflow_type}_{timestamp}.csv"
    with open(csv_filename, 'w') as f:
        f.write("Metric,Value\n")
        f.write(f"Total Queries,{result['results']['summary']['total_queries']}\n")
        f.write(f"Success Rate,{result['results']['summary']['success_rate']:.2%}\n")
        f.write(f"Execution Time,{result['metadata']['execution_time']:.1f}s\n")
        f.write(f"Total Cost,${result['metadata']['total_cost']:.2f}\n")
    
    # Generate HTML report (basic example)
    html_filename = f"report_{workflow_type}_{timestamp}.html"
    with open(html_filename, 'w') as f:
        f.write(f"""
        <html>
        <head><title>{workflow_type.replace('_', ' ').title()} Report</title></head>
        <body>
        <h1>{workflow_type.replace('_', ' ').title()} Investigation Report</h1>
        <h2>Summary</h2>
        <ul>
            <li>Total Queries: {result['results']['summary']['total_queries']}</li>
            <li>Success Rate: {result['results']['summary']['success_rate']:.1%}</li>
            <li>Execution Time: {result['metadata']['execution_time']:.1f} seconds</li>
            <li>Total Cost: ${result['metadata']['total_cost']:.2f}</li>
        </ul>
        <h2>Data Sources</h2>
        <ul>
        """)
        
        for source in result['results']['data_sources']:
            f.write(f"<li>{source}</li>")
        
        f.write("""
        </ul>
        </body>
        </html>
        """)
    
    print(f"   Exported: {json_filename}, {csv_filename}, {html_filename}")


async def demo_all_workflows():
    """Run demonstration of all workflow types"""
    print("SLEUTH INTEL WORKFLOW TEMPLATES DEMONSTRATION")
    print("=" * 60)
    
    try:
        await example_phone_investigation()
        await example_person_investigation()
        await example_business_due_diligence()
        await example_address_analysis()
        await example_bulk_processing()
        await example_workflow_estimation()
        await example_custom_workflow()
        
        print("=" * 60)
        print("All workflow examples completed successfully!")
        
    except Exception as e:
        print(f"Error during demonstration: {e}")
        print("This might occur if required services are not running.")


async def interactive_workflow_builder():
    """Interactive workflow builder for testing"""
    print("\n=== Interactive Workflow Builder ===")
    print("Choose a workflow type:")
    print("1. Phone Investigation")
    print("2. Person Investigation") 
    print("3. Business Due Diligence")
    print("4. Address Analysis")
    print("5. Bulk Processing")
    
    choice = input("Enter choice (1-5): ").strip()
    
    workflows = {
        '1': 'phone_investigation',
        '2': 'person_investigation',
        '3': 'business_due_diligence',
        '4': 'address_analysis',
        '5': 'bulk_processing'
    }
    
    if choice not in workflows:
        print("Invalid choice")
        return
    
    workflow_type = workflows[choice]
    
    print("\nChoose investigation depth:")
    print("1. Basic")
    print("2. Comprehensive")
    print("3. Deep")
    
    depth_choice = input("Enter depth (1-3): ").strip()
    depths = {'1': 'basic', '2': 'comprehensive', '3': 'deep'}
    
    if depth_choice not in depths:
        print("Invalid choice")
        return
    
    depth = depths[depth_choice]
    
    # Get input data based on workflow type
    query_data = {}
    
    if workflow_type == 'phone_investigation':
        query_data['phone_number'] = input("Enter phone number: ").strip()
    elif workflow_type == 'person_investigation':
        query_data['first_name'] = input("Enter first name: ").strip()
        query_data['last_name'] = input("Enter last name: ").strip()
        query_data['city'] = input("Enter city (optional): ").strip() or None
        query_data['state'] = input("Enter state (optional): ").strip() or None
    elif workflow_type == 'business_due_diligence':
        query_data['company_name'] = input("Enter company name: ").strip()
        query_data['city'] = input("Enter city (optional): ").strip() or None
        query_data['state'] = input("Enter state (optional): ").strip() or None
    elif workflow_type == 'address_analysis':
        query_data['street_address'] = input("Enter street address: ").strip()
        query_data['city'] = input("Enter city: ").strip()
        query_data['state'] = input("Enter state: ").strip()
        query_data['zip_code'] = input("Enter ZIP code (optional): ").strip() or None
    
    # Budget constraints
    max_cost = input("Enter max cost in USD (optional): ").strip()
    budget = None
    if max_cost:
        try:
            budget = WorkflowBudget(max_cost_usd=float(max_cost))
        except ValueError:
            print("Invalid cost, proceeding without budget constraints")
    
    print(f"\nExecuting {workflow_type} workflow with {depth} depth...")
    
    try:
        orchestrator = SleuthIntelOrchestrator()
        manager = WorkflowTemplateManager(orchestrator)
        
        result = await manager.execute_workflow(
            template_type=workflow_type,
            depth=depth,
            query_data=query_data,
            budget=budget
        )
        
        print(f"\nWorkflow completed!")
        print(f"Success Rate: {result['metadata']['success_rate']:.1%}")
        print(f"Total Cost: ${result['metadata']['total_cost']:.2f}")
        print(f"Execution Time: {result['metadata']['execution_time']:.1f}s")
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"interactive_result_{workflow_type}_{timestamp}.json"
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        print(f"Results saved to: {filename}")
        
    except Exception as e:
        print(f"Error executing workflow: {e}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'interactive':
        asyncio.run(interactive_workflow_builder())
    else:
        asyncio.run(demo_all_workflows())