#!/usr/bin/env python3
"""
Test the autonomous coder orchestrator integration
"""

import asyncio
import sys
from pathlib import Path

# Add agent-orchestrator to path
sys.path.insert(0, str(Path(__file__).parent.parent / "agent-orchestrator" / "src"))

from generic_orchestrator import GenericOrchestrator
from orchestrator_integration import AutonomousCoderPlugin


async def test_integration():
    """Test the integration with a simple example"""
    print("🧪 Testing Autonomous Coder - Orchestrator Integration")
    print("="*60)
    
    # Initialize orchestrator
    orchestrator = GenericOrchestrator(max_parallel=3, use_optimizations=True)
    plugin = AutonomousCoderPlugin(orchestrator)
    
    # Test quick build
    print("⚡ Testing Quick Build...")
    test_request = "Create a simple Python calculator with add, subtract, multiply, and divide functions"
    
    try:
        result = await plugin.quick_build(test_request)
        
        print(f"✅ Quick Build Test Complete!")
        print(f"   Request: {result['request']}")
        print(f"   Output: {result['output_directory']}")
        print(f"   Tasks: {len(result['results'])}")
        
        # Show some results
        for task_id, task_result in list(result['results'].items())[:2]:
            print(f"\n📋 {task_id}:")
            if isinstance(task_result, dict) and 'result' in task_result:
                result_text = str(task_result['result'])[:200]
                print(f"   {result_text}...")
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*60)
    print("🎯 Integration test complete!")
    

if __name__ == "__main__":
    asyncio.run(test_integration())