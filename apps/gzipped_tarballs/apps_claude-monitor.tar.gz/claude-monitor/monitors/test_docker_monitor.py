#!/usr/bin/env python3
"""
Test script for Docker Monitor
"""

import sys
import traceback

def test_imports():
    try:
        import docker
        print("✓ Docker module imported successfully")
        return True
    except ImportError as e:
        print(f"✗ Failed to import docker: {e}")
        return False

def test_docker_connection():
    try:
        import docker
        client = docker.from_env()
        client.ping()
        print("✓ Docker daemon connection successful")
        return True
    except Exception as e:
        print(f"✗ Docker connection failed: {e}")
        return False

def test_monitor_initialization():
    try:
        sys.path.append('/home/opsvi/master_root/apps/claude-monitor/monitors')
        from docker_monitor import DockerClaudeMonitor
        
        monitor = DockerClaudeMonitor()
        status = monitor.get_status()
        print(f"✓ Monitor initialized successfully")
        print(f"  Docker connected: {status['docker_connected']}")
        print(f"  Monitoring active: {status['monitoring_active']}")
        return True
    except Exception as e:
        print(f"✗ Monitor initialization failed: {e}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("Testing Docker Monitor...")
    
    tests = [
        ("Import Test", test_imports),
        ("Docker Connection Test", test_docker_connection),
        ("Monitor Initialization Test", test_monitor_initialization)
    ]
    
    passed = 0
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        if test_func():
            passed += 1
    
    print(f"\n{passed}/{len(tests)} tests passed")