#!/usr/bin/env python3
"""
Simple test script for the data collector.
"""

import sys
from pathlib import Path

# Add collectors directory to path
sys.path.insert(0, str(Path(__file__).parent / 'collectors'))

try:
    print("Testing data collector imports...")
    
    from data_collector import (
        DataCollector, 
        SystemMetrics, 
        TokenMetrics, 
        ProcessMetrics,
        DockerMetrics,
        LogMetrics,
        LRUCache
    )
    
    print("✓ All imports successful")
    
    # Test cache
    print("Testing LRU cache...")
    cache = LRUCache(max_size=3)
    cache.set("test1", "value1")
    cache.set("test2", "value2") 
    cache.set("test3", "value3")
    
    assert cache.get("test1") == "value1"
    print("✓ Cache test passed")
    
    # Test basic collector initialization
    print("Testing collector initialization...")
    collector = DataCollector()
    print("✓ DataCollector initialized successfully")
    
    # Test system collector
    print("Testing system metrics collection...")
    system_metrics = collector.system_collector.get_system_metrics()
    assert system_metrics.cpu_percent >= 0
    assert system_metrics.memory_percent >= 0
    print(f"✓ System metrics: CPU {system_metrics.cpu_percent}%, Memory {system_metrics.memory_percent}%")
    
    # Test process collector  
    print("Testing process metrics collection...")
    process_metrics = collector.process_collector.get_claude_processes()
    print(f"✓ Process metrics: {process_metrics.total_processes} Claude processes found")
    
    # Test cache stats
    cache_stats = collector.get_cache_stats()
    print(f"✓ Cache stats: {cache_stats}")
    
    print("\n🎉 All tests passed successfully!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Test error: {e}")
    sys.exit(1)
finally:
    # Cleanup
    try:
        collector.executor.shutdown(wait=False)
    except:
        pass