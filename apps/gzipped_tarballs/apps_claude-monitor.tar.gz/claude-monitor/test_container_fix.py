#!/usr/bin/env python3
"""
Test script to verify container monitoring fixes work correctly
"""
import sys
import os

# Add current directory to path for imports
sys.path.insert(0, '.')

def test_container_monitoring():
    """Test the fixed container monitoring functionality"""
    try:
        from backend.monitoring_service import get_docker_containers
        
        print("Testing Docker container monitoring with percpu_usage fixes...")
        
        # This should not raise any 'percpu_usage' errors
        containers = get_docker_containers()
        
        print(f"✅ Successfully retrieved {len(containers)} containers without errors")
        
        # Display first few containers if any exist
        if containers:
            print("\nContainer details (showing first 3):")
            for i, container in enumerate(containers[:3]):
                print(f"  {i+1}. {container.name}")
                print(f"     CPU: {container.cpu_percent}%")
                print(f"     Memory: {container.memory_percent}%")
                print(f"     Status: {container.status}")
        else:
            print("No containers found (this is normal if Docker has no running containers)")
            
        return True
        
    except Exception as e:
        print(f"❌ Container monitoring test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_container_monitoring()
    sys.exit(0 if success else 1)