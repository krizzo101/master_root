#!/usr/bin/env python3
"""
Simple test for keyboard input and view switching
"""
import asyncio
import sys
import select
import termios
import tty
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

class SimpleTest:
    def __init__(self):
        self.console = Console()
        self.current_view = 1
        self.views = {
            1: "Master View",
            2: "Docker View", 
            3: "Agents View",
            4: "Tokens View",
            5: "System View",
            6: "Costs View"
        }
        
    def _get_key_input(self):
        """Non-blocking keyboard input"""
        if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
            try:
                key = sys.stdin.read(1)
                # Handle special keys
                if key == "\x1b":  # ESC sequence
                    key += sys.stdin.read(2)
                    if key == "\x1b[A":
                        return "up"
                    elif key == "\x1b[B":
                        return "down"
                elif key == "\t":
                    return "tab"
                return key
            except:
                return None
        return None
        
    def _handle_key(self, key):
        """Handle keyboard input, return False to quit"""
        if not key:
            return True
            
        key = key.lower()
        
        if key == "q":
            return False
        elif key == "tab":
            # Switch to next view
            self.current_view = (self.current_view % 6) + 1
        elif key in "123456":
            self.current_view = int(key)
            
        return True
        
    def _render(self):
        """Render current view"""
        view_name = self.views[self.current_view]
        content = Text(f"Current View: {view_name}\n\nPress Tab to cycle views\nPress 1-6 for direct view\nPress Q to quit", justify="center")
        panel = Panel(content, title=f"Simple Test - View {self.current_view}")
        return panel
        
    async def run(self):
        """Main loop"""
        # Save original terminal settings
        old_settings = None
        try:
            old_settings = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin.fileno())
        except:
            pass
            
        try:
            running = True
            while running:
                # Clear screen and render
                self.console.clear()
                self.console.print(self._render())
                
                # Handle input
                key = self._get_key_input()
                if key:
                    running = self._handle_key(key)
                    
                await asyncio.sleep(0.1)
                
        except KeyboardInterrupt:
            pass
        finally:
            # Restore terminal settings  
            if old_settings:
                try:
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
                except:
                    pass
                    
async def main():
    test = SimpleTest()
    await test.run()
    
if __name__ == "__main__":
    asyncio.run(main())