# Claude Monitor Console Module
