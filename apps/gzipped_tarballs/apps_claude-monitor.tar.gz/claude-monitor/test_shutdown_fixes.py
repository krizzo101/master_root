#!/usr/bin/env python3
"""
Test script to validate the claude-monitor shutdown fixes.
Tests various shutdown scenarios to ensure robust process lifecycle management.
"""

import asyncio
import logging
import multiprocessing as mp
import os
import signal
import sys
import time
from pathlib import Path

# Add the app directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from main import ClaudeMonitor, create_argument_parser

# Configure logging
logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class ShutdownTestScenarios:
    """Test scenarios for shutdown behavior"""
    
    @staticmethod
    async def test_normal_shutdown():
        """Test normal shutdown sequence"""
        logger.info("=== Testing Normal Shutdown ===")
        
        # Create mock args
        args = type('Args', (), {
            'mode': 'backend',
            'host': 'localhost', 
            'port': 8001,  # Use different port to avoid conflicts
            'log_level': 'INFO',
            'access_log': False,
            'debug': False
        })()
        
        monitor = ClaudeMonitor(args)
        
        try:
            # Start backend service
            monitor.start_backend_service()
            await asyncio.sleep(1)  # Let it start
            
            # Normal shutdown
            await monitor.shutdown()
            logger.info("✅ Normal shutdown completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Normal shutdown failed: {e}")
            return False
    
    @staticmethod
    async def test_process_not_started():
        """Test shutdown when process was never started"""
        logger.info("=== Testing Shutdown with No Process ===")
        
        args = type('Args', (), {
            'mode': 'backend',
            'host': 'localhost',
            'port': 8002,
            'log_level': 'INFO', 
            'access_log': False,
            'debug': False
        })()
        
        monitor = ClaudeMonitor(args)
        
        try:
            # Don't start process, just try shutdown
            await monitor.shutdown()
            logger.info("✅ Shutdown with no process completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Shutdown with no process failed: {e}")
            return False
    
    @staticmethod
    async def test_process_already_dead():
        """Test shutdown when process died unexpectedly"""
        logger.info("=== Testing Shutdown with Dead Process ===")
        
        args = type('Args', (), {
            'mode': 'backend',
            'host': 'localhost',
            'port': 8003,
            'log_level': 'INFO',
            'access_log': False,
            'debug': False
        })()
        
        monitor = ClaudeMonitor(args)
        
        try:
            # Start backend service
            monitor.start_backend_service()
            await asyncio.sleep(1)
            
            # Kill process externally to simulate unexpected death
            if monitor.backend_process and monitor.backend_process.pid:
                os.kill(monitor.backend_process.pid, signal.SIGKILL)
                await asyncio.sleep(0.5)  # Let it die
            
            # Try shutdown
            await monitor.shutdown()
            logger.info("✅ Shutdown with dead process completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Shutdown with dead process failed: {e}")
            return False
    
    @staticmethod
    async def test_rapid_shutdown_cycles():
        """Test rapid startup/shutdown cycles"""
        logger.info("=== Testing Rapid Shutdown Cycles ===")
        
        results = []
        for i in range(3):
            args = type('Args', (), {
                'mode': 'backend',
                'host': 'localhost',
                'port': 8004 + i,
                'log_level': 'INFO',
                'access_log': False,
                'debug': False
            })()
            
            monitor = ClaudeMonitor(args)
            
            try:
                # Quick start/stop cycle
                monitor.start_backend_service()
                await asyncio.sleep(0.5)  # Minimal startup time
                await monitor.shutdown()
                results.append(True)
                logger.info(f"✅ Rapid cycle {i+1} completed successfully")
                
            except Exception as e:
                logger.error(f"❌ Rapid cycle {i+1} failed: {e}")
                results.append(False)
                
            await asyncio.sleep(0.2)  # Brief pause between cycles
        
        success = all(results)
        if success:
            logger.info("✅ All rapid shutdown cycles completed successfully")
        else:
            logger.error("❌ Some rapid shutdown cycles failed")
            
        return success


async def run_all_tests():
    """Run all shutdown test scenarios"""
    logger.info("🚀 Starting Claude Monitor Shutdown Tests")
    logger.info("=" * 60)
    
    test_results = {}
    
    # Run test scenarios
    test_scenarios = [
        ("Normal Shutdown", ShutdownTestScenarios.test_normal_shutdown),
        ("No Process Shutdown", ShutdownTestScenarios.test_process_not_started),
        ("Dead Process Shutdown", ShutdownTestScenarios.test_process_already_dead),
        ("Rapid Cycles", ShutdownTestScenarios.test_rapid_shutdown_cycles),
    ]
    
    for test_name, test_func in test_scenarios:
        try:
            logger.info(f"\n🧪 Running test: {test_name}")
            result = await test_func()
            test_results[test_name] = result
            
        except Exception as e:
            logger.error(f"❌ Test {test_name} crashed: {e}")
            test_results[test_name] = False
        
        # Small delay between tests
        await asyncio.sleep(1)
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("📊 TEST RESULTS SUMMARY")
    logger.info("=" * 60)
    
    passed = sum(1 for result in test_results.values() if result)
    total = len(test_results)
    
    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        logger.info(f"{status} - {test_name}")
    
    logger.info(f"\n🎯 Overall Results: {passed}/{total} tests passed")
    
    if passed == total:
        logger.info("🎉 ALL TESTS PASSED! Shutdown fixes are working correctly.")
        return True
    else:
        logger.error(f"⚠️  {total - passed} test(s) failed. Review fixes needed.")
        return False


if __name__ == "__main__":
    try:
        success = asyncio.run(run_all_tests())
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        logger.info("\n🛑 Tests interrupted by user")
        sys.exit(1)
        
    except Exception as e:
        logger.error(f"\n💥 Test suite crashed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)