#!/usr/bin/env python3
"""
Test Runner for Claude Monitoring System

Usage:
  python run_tests.py              # Run all tests
  python run_tests.py --unit       # Run only unit tests
  python run_tests.py --integration # Run only integration tests
  python run_tests.py --performance # Run only performance tests
  python run_tests.py --benchmark   # Run performance benchmarks
  python run_tests.py --coverage    # Run with coverage report
"""

import argparse
import subprocess
import sys
import os
from pathlib import Path

# Add project directories to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'backend'))
sys.path.insert(0, str(project_root / 'monitors'))
sys.path.insert(0, str(project_root / 'collectors'))


def run_command(command, description=""):
    """Run a shell command and return success status."""
    print(f"\n{'='*60}")
    if description:
        print(f"RUNNING: {description}")
    print(f"COMMAND: {command}")
    print('='*60)
    
    try:
        result = subprocess.run(command, shell=True, check=True, 
                              capture_output=False, text=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"ERROR: Command failed with exit code {e.returncode}")
        return False


def check_dependencies():
    """Check if required dependencies are installed."""
    print("Checking dependencies...")
    
    required_packages = [
        'pytest', 'fastapi', 'uvicorn', 'docker', 'psutil', 'pydantic'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} (missing)")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\nMissing packages: {', '.join(missing_packages)}")
        print("Install with: pip install -r tests/requirements.txt")
        return False
    
    print("✓ All dependencies satisfied")
    return True


def run_unit_tests():
    """Run unit tests only."""
    command = f"python -m pytest tests/test_monitor.py::TestLRUCache tests/test_monitor.py::TestDatabaseCollector tests/test_monitor.py::TestSystemCollector tests/test_monitor.py::TestProcessCollector tests/test_monitor.py::TestDockerCollector tests/test_monitor.py::TestDockerClaudeMonitor tests/test_monitor.py::TestLogCollector tests/test_monitor.py::TestDataCollector tests/test_monitor.py::TestMonitoringServiceAPI -v"
    return run_command(command, "Unit Tests")


def run_integration_tests():
    """Run integration tests only."""
    command = f"python -m pytest tests/test_monitor.py::TestIntegrationDataFlow tests/test_monitor.py::TestWebSocketIntegration -v"
    return run_command(command, "Integration Tests")


def run_performance_tests():
    """Run performance tests only."""
    command = f"python -m pytest tests/test_monitor.py::TestPerformance -v"
    return run_command(command, "Performance Tests")


def run_benchmark():
    """Run performance benchmark."""
    command = f"python tests/test_monitor.py benchmark"
    return run_command(command, "Performance Benchmark")


def run_all_tests():
    """Run all tests."""
    command = f"python -m pytest tests/test_monitor.py -v"
    return run_command(command, "All Tests")


def run_with_coverage():
    """Run tests with coverage report."""
    command = f"python -m pytest tests/test_monitor.py --cov=backend --cov=monitors --cov=collectors --cov-report=html --cov-report=term -v"
    return run_command(command, "Tests with Coverage")


def main():
    parser = argparse.ArgumentParser(description="Run Claude Monitor tests")
    parser.add_argument('--unit', action='store_true', help='Run unit tests only')
    parser.add_argument('--integration', action='store_true', help='Run integration tests only')
    parser.add_argument('--performance', action='store_true', help='Run performance tests only')
    parser.add_argument('--benchmark', action='store_true', help='Run performance benchmark')
    parser.add_argument('--coverage', action='store_true', help='Run with coverage report')
    parser.add_argument('--no-deps-check', action='store_true', help='Skip dependency check')
    
    args = parser.parse_args()
    
    # Change to project directory
    os.chdir(project_root)
    
    # Check dependencies unless skipped
    if not args.no_deps_check and not check_dependencies():
        print("\nDependency check failed. Install missing packages or use --no-deps-check")
        sys.exit(1)
    
    success = True
    
    if args.unit:
        success = run_unit_tests()
    elif args.integration:
        success = run_integration_tests()
    elif args.performance:
        success = run_performance_tests()
    elif args.benchmark:
        success = run_benchmark()
    elif args.coverage:
        success = run_with_coverage()
    else:
        success = run_all_tests()
    
    if success:
        print(f"\n{'='*60}")
        print("✅ ALL TESTS COMPLETED SUCCESSFULLY")
        print('='*60)
    else:
        print(f"\n{'='*60}")
        print("❌ TESTS FAILED")
        print('='*60)
        sys.exit(1)


if __name__ == '__main__':
    main()