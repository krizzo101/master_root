#!/usr/bin/env python3
"""
Comprehensive Test Suite for Claude Monitoring System

Tests include:
1. Unit tests for each component
2. Integration tests for data flow  
3. Mock Docker and database for testing
4. Performance tests
"""

import asyncio
import json
import os
import sqlite3
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from unittest.mock import Mock, MagicMock, patch, AsyncMock
from typing import Dict, List, Any
import threading
from dataclasses import asdict

import pytest
import docker
import psutil
from fastapi.testclient import TestClient

# Add parent directories to path for imports
import sys
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-monitor')
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-monitor/backend')
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-monitor/monitors')
sys.path.insert(0, '/home/opsvi/master_root/apps/claude-monitor/collectors')

# Import modules to test
from monitoring_service import app, get_db_connection, get_token_usage, get_system_metrics, get_docker_containers
from docker_monitor import DockerClaudeMonitor
from data_collector import (
    DataCollector, DatabaseCollector, SystemCollector, ProcessCollector, 
    DockerCollector, LogCollector, LRUCache, SystemMetrics, TokenMetrics,
    ProcessMetrics, DockerMetrics, LogMetrics, ProjectMetrics
)


class TestLRUCache(unittest.TestCase):
    """Test the LRU Cache implementation."""
    
    def setUp(self):
        self.cache = LRUCache(max_size=3)
    
    def test_basic_set_get(self):
        """Test basic cache set and get operations."""
        self.cache.set("key1", "value1")
        self.assertEqual(self.cache.get("key1"), "value1")
    
    def test_cache_expiry(self):
        """Test cache TTL expiry."""
        self.cache.set("key1", "value1")
        # Should return value immediately
        self.assertEqual(self.cache.get("key1", ttl=10), "value1")
        # Mock time passing
        with patch('time.time', return_value=time.time() + 20):
            self.assertIsNone(self.cache.get("key1", ttl=10))
    
    def test_lru_eviction(self):
        """Test LRU eviction when cache is full."""
        # Fill cache to max size
        self.cache.set("key1", "value1")
        self.cache.set("key2", "value2") 
        self.cache.set("key3", "value3")
        
        # Add another item (should evict key1)
        self.cache.set("key4", "value4")
        
        # key1 should be evicted
        self.assertIsNone(self.cache.get("key1"))
        self.assertEqual(self.cache.get("key4"), "value4")
    
    def test_cache_clear(self):
        """Test cache clearing."""
        self.cache.set("key1", "value1")
        self.cache.clear()
        self.assertIsNone(self.cache.get("key1"))


class TestDatabaseCollector(unittest.TestCase):
    """Test database collection functionality."""
    
    def setUp(self):
        """Set up test database."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        # Create test database schema
        self._create_test_db()
        self.collector = DatabaseCollector(self.db_path)
    
    def tearDown(self):
        """Clean up test database."""
        try:
            os.unlink(self.db_path)
        except:
            pass
    
    def _create_test_db(self):
        """Create test database with sample data."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute("""
            CREATE TABLE nodes (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                raw_json TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE sessions (
                id INTEGER PRIMARY KEY,
                created_at TEXT
            )
        """)
        
        cursor.execute("""
            CREATE TABLE tool_calls (
                id INTEGER PRIMARY KEY,
                timestamp TEXT
            )
        """)
        
        # Insert test data
        test_nodes = [
            {
                'timestamp': (datetime.now() - timedelta(hours=1)).isoformat(),
                'raw_json': json.dumps({
                    'input_tokens': 100,
                    'output_tokens': 50,
                    'model': 'claude-3-sonnet'
                })
            },
            {
                'timestamp': (datetime.now() - timedelta(hours=2)).isoformat(),
                'raw_json': json.dumps({
                    'input_tokens': 200,
                    'output_tokens': 75,
                    'model': 'gpt-4'
                })
            }
        ]
        
        for node in test_nodes:
            cursor.execute(
                "INSERT INTO nodes (timestamp, raw_json) VALUES (?, ?)",
                (node['timestamp'], node['raw_json'])
            )
        
        # Insert test sessions
        cursor.execute(
            "INSERT INTO sessions (created_at) VALUES (?)",
            ((datetime.now() - timedelta(minutes=30)).isoformat(),)
        )
        
        # Insert test tool calls
        cursor.execute(
            "INSERT INTO tool_calls (timestamp) VALUES (?)",
            ((datetime.now() - timedelta(minutes=15)).isoformat(),)
        )
        
        conn.commit()
        conn.close()
    
    def test_token_metrics_calculation(self):
        """Test token usage metrics calculation."""
        metrics = self.collector.get_token_metrics()
        
        self.assertEqual(metrics.total_input_tokens, 300)
        self.assertEqual(metrics.total_output_tokens, 125)
        self.assertEqual(metrics.total_tokens, 425)
        self.assertEqual(metrics.sessions_count, 2)
        self.assertGreater(metrics.total_cost, 0)
        self.assertIn('claude-3-sonnet', metrics.cost_by_model)
        self.assertIn('gpt-4', metrics.cost_by_model)
    
    def test_session_metrics(self):
        """Test session metrics retrieval."""
        metrics = self.collector.get_session_metrics()
        
        self.assertEqual(metrics['active_sessions'], 1)
        self.assertEqual(metrics['total_sessions'], 1)
        self.assertEqual(metrics['recent_tool_calls'], 1)
    
    def test_database_connection_error(self):
        """Test handling of database connection errors."""
        collector = DatabaseCollector("/nonexistent/path.db")
        
        # Should return default metrics on error
        metrics = collector.get_token_metrics()
        self.assertEqual(metrics.total_input_tokens, 0)
        self.assertEqual(metrics.total_output_tokens, 0)


class TestSystemCollector(unittest.TestCase):
    """Test system metrics collection."""
    
    def setUp(self):
        self.collector = SystemCollector()
    
    @patch('psutil.cpu_percent')
    @patch('psutil.virtual_memory')
    @patch('psutil.disk_usage')
    @patch('psutil.net_io_counters')
    @patch('psutil.getloadavg')
    def test_system_metrics_collection(self, mock_loadavg, mock_net, mock_disk, mock_memory, mock_cpu):
        """Test system metrics collection with mocked psutil."""
        # Mock psutil responses
        mock_cpu.return_value = 45.5
        mock_memory.return_value = Mock(percent=78.2, used=8589934592, total=10737418240)
        mock_disk.return_value = Mock(percent=65.0, used=536870912000, total=824633720832)
        mock_net.return_value = Mock(
            bytes_sent=1048576, bytes_recv=2097152, packets_sent=100, packets_recv=200,
            errin=0, errout=0, dropin=0, dropout=0
        )
        mock_loadavg.return_value = [1.5, 1.2, 1.0]
        
        metrics = self.collector.get_system_metrics()
        
        self.assertEqual(metrics.cpu_percent, 45.5)
        self.assertEqual(metrics.memory_percent, 78.2)
        self.assertEqual(metrics.disk_percent, 65.0)
        self.assertEqual(len(metrics.load_average), 3)
        self.assertIsInstance(metrics.network_io, dict)
    
    def test_system_metrics_caching(self):
        """Test system metrics caching."""
        # First call should cache the result
        with patch('psutil.cpu_percent', return_value=50.0):
            metrics1 = self.collector.get_system_metrics()
            metrics2 = self.collector.get_system_metrics()
            
            # Should return cached result
            self.assertEqual(metrics1.cpu_percent, metrics2.cpu_percent)


class TestProcessCollector(unittest.TestCase):
    """Test process monitoring functionality."""
    
    def setUp(self):
        self.collector = ProcessCollector()
    
    @patch('psutil.process_iter')
    def test_claude_process_detection(self, mock_process_iter):
        """Test detection of Claude-related processes."""
        # Mock processes
        mock_proc1 = Mock()
        mock_proc1.info = {
            'pid': 1234,
            'name': 'claude-assistant',
            'cmdline': ['python', '/path/to/claude', '--config'],
            'cpu_percent': 15.5,
            'memory_info': Mock(rss=1048576, vms=2097152),
            'create_time': time.time() - 3600
        }
        mock_proc1.cpu_percent.return_value = 15.5
        mock_proc1.status.return_value = 'running'
        mock_proc1.username.return_value = 'user'
        
        mock_proc2 = Mock()
        mock_proc2.info = {
            'pid': 5678,
            'name': 'nginx',
            'cmdline': ['nginx', '-g', 'daemon off;'],
            'cpu_percent': 5.0,
            'memory_info': Mock(rss=2097152, vms=4194304),
            'create_time': time.time() - 1800
        }
        mock_proc2.cpu_percent.return_value = 5.0
        mock_proc2.status.return_value = 'running'
        mock_proc2.username.return_value = 'www-data'
        
        mock_process_iter.return_value = [mock_proc1, mock_proc2]
        
        metrics = self.collector.get_claude_processes()
        
        # Should only detect claude-related process
        self.assertEqual(metrics.total_processes, 1)
        self.assertEqual(len(metrics.claude_processes), 1)
        self.assertEqual(metrics.claude_processes[0]['name'], 'claude-assistant')
        self.assertIn('1234', metrics.cpu_usage_by_process)


class TestDockerCollector(unittest.TestCase):
    """Test Docker container monitoring."""
    
    def setUp(self):
        self.collector = DockerCollector()
    
    @patch('docker.from_env')
    def test_docker_connection_success(self, mock_docker):
        """Test successful Docker connection."""
        mock_client = Mock()
        mock_client.ping.return_value = True
        mock_docker.return_value = mock_client
        
        collector = DockerCollector()
        self.assertIsNotNone(collector.client)
    
    @patch('docker.from_env')
    def test_docker_connection_failure(self, mock_docker):
        """Test Docker connection failure handling."""
        mock_docker.side_effect = docker.errors.DockerException("Connection failed")
        
        collector = DockerCollector()
        self.assertIsNone(collector.client)
    
    @patch('docker.from_env')
    def test_docker_metrics_collection(self, mock_docker):
        """Test Docker metrics collection with mocked containers."""
        # Mock Docker client and containers
        mock_container = Mock()
        mock_container.id = 'container123456789'
        mock_container.name = 'claude-app'
        mock_container.status = 'running'
        mock_container.image.tags = ['claude:latest']
        mock_container.attrs = {'Created': '2023-01-01T00:00:00Z'}
        
        # Mock container stats
        mock_stats = {
            'cpu_stats': {
                'cpu_usage': {'total_usage': 2000000, 'percpu_usage': [1000000, 1000000]},
                'system_cpu_usage': 10000000,
                'online_cpus': 2
            },
            'precpu_stats': {
                'cpu_usage': {'total_usage': 1000000},
                'system_cpu_usage': 9000000
            },
            'memory_stats': {
                'usage': 104857600,  # 100MB
                'limit': 1073741824  # 1GB
            },
            'networks': {
                'eth0': {'rx_bytes': 1048576, 'tx_bytes': 2097152}
            }
        }
        mock_container.stats.return_value = mock_stats
        
        mock_client = Mock()
        mock_client.ping.return_value = True
        mock_client.containers.list.return_value = [mock_container]
        mock_docker.return_value = mock_client
        
        collector = DockerCollector()
        metrics = collector.get_docker_metrics()
        
        self.assertEqual(metrics.total_containers, 1)
        self.assertEqual(metrics.running_containers, 1)
        self.assertEqual(metrics.claude_containers, 1)
        self.assertGreater(metrics.total_cpu_percent, 0)
        self.assertGreater(metrics.total_memory_bytes, 0)


class TestDockerClaudeMonitor(unittest.TestCase):
    """Test Docker Claude Monitor functionality."""
    
    def setUp(self):
        with patch('docker.from_env') as mock_docker:
            mock_client = Mock()
            mock_client.ping.return_value = True
            mock_docker.return_value = mock_client
            self.monitor = DockerClaudeMonitor()
    
    def test_monitor_initialization(self):
        """Test monitor initialization."""
        status = self.monitor.get_status()
        self.assertIn('docker_connected', status)
        self.assertIn('monitoring_active', status)
        self.assertIn('containers_tracked', status)
    
    @patch('docker.from_env')
    def test_container_discovery(self, mock_docker):
        """Test Claude container discovery."""
        # Mock container with Claude indicators
        mock_container = Mock()
        mock_container.id = 'abc123'
        mock_container.short_id = 'abc123'
        mock_container.name = 'claude-assistant'
        mock_container.status = 'running'
        mock_container.image.tags = ['claude:latest']
        mock_container.image.id = 'img123'
        mock_container.attrs = {
            'Created': '2023-01-01T00:00:00Z',
            'State': {'StartedAt': '2023-01-01T00:01:00Z'},
            'Config': {'Env': ['CLAUDE_API_KEY=sk-...', 'PATH=/usr/bin']}
        }
        mock_container.labels = {'app': 'claude-assistant'}
        mock_container.logs.return_value = b'Starting claude assistant...'
        mock_container.top.return_value = {
            'Processes': [['1000', 'user', 'python', '/app/claude.py']]
        }
        
        mock_client = Mock()
        mock_client.containers.list.return_value = [mock_container]
        mock_docker.return_value = mock_client
        self.monitor.client = mock_client
        
        containers = self.monitor.discover_claude_containers()
        
        self.assertEqual(len(containers), 1)
        container_info = list(containers.values())[0]
        self.assertEqual(container_info['name'], 'claude-assistant')
        self.assertTrue(len(container_info['claude_indicators']['env_vars']) > 0)
    
    def test_monitoring_lifecycle(self):
        """Test monitoring start/stop lifecycle."""
        with patch.object(self.monitor, '_is_docker_available', return_value=True):
            # Start monitoring
            result = self.monitor.start_monitoring(interval=1)
            self.assertTrue(result)
            self.assertTrue(self.monitor.monitoring_active)
            
            # Stop monitoring
            self.monitor.stop_monitoring()
            self.assertFalse(self.monitor.monitoring_active)


class TestLogCollector(unittest.TestCase):
    """Test log analysis functionality."""
    
    def setUp(self):
        self.temp_log_dir = tempfile.mkdtemp()
        self.collector = LogCollector([self.temp_log_dir])
    
    def tearDown(self):
        """Clean up temporary log directory."""
        import shutil
        shutil.rmtree(self.temp_log_dir, ignore_errors=True)
    
    def test_log_analysis(self):
        """Test log file analysis."""
        # Create test log file
        log_content = """
2023-01-01 10:00:00 INFO Starting application
2023-01-01 10:01:00 ERROR Database connection failed
2023-01-01 10:02:00 WARNING Low memory detected
2023-01-01 10:03:00 INFO Claude request processed
2023-01-01 10:04:00 ERROR API timeout occurred
        """
        
        log_file = os.path.join(self.temp_log_dir, 'test.log')
        with open(log_file, 'w') as f:
            f.write(log_content)
        
        metrics = self.collector.get_log_metrics()
        
        self.assertEqual(metrics.error_count, 2)
        self.assertEqual(metrics.warning_count, 1)
        self.assertEqual(metrics.log_files_processed, 1)
        self.assertGreater(metrics.error_rate, 0)
    
    def test_log_pattern_detection(self):
        """Test error pattern detection."""
        log_content = """
2023-01-01 10:00:00 ERROR: Connection timeout
2023-01-01 10:01:00 ERROR: Connection timeout  
2023-01-01 10:02:00 ERROR: Database locked
        """
        
        log_file = os.path.join(self.temp_log_dir, 'errors.log')
        with open(log_file, 'w') as f:
            f.write(log_content)
        
        metrics = self.collector.get_log_metrics()
        
        # Should detect common error patterns
        self.assertIn('Connection timeout', str(metrics.common_errors))


class TestDataCollector(unittest.TestCase):
    """Test main data collection orchestrator."""
    
    def setUp(self):
        # Create temporary database
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        # Create test database with minimal schema
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE nodes (id INTEGER PRIMARY KEY, timestamp TEXT, raw_json TEXT)")
        cursor.execute("CREATE TABLE sessions (id INTEGER PRIMARY KEY, created_at TEXT)")
        cursor.execute("CREATE TABLE tool_calls (id INTEGER PRIMARY KEY, timestamp TEXT)")
        conn.commit()
        conn.close()
        
        self.collector = DataCollector(self.db_path)
    
    def tearDown(self):
        """Clean up."""
        try:
            os.unlink(self.db_path)
        except:
            pass
    
    @patch('psutil.cpu_percent', return_value=50.0)
    @patch('psutil.virtual_memory')
    @patch('psutil.disk_usage')
    @patch('psutil.net_io_counters')
    @patch('psutil.getloadavg', return_value=[1.0, 1.0, 1.0])
    async def test_collect_all_metrics(self, mock_loadavg, mock_net, mock_disk, mock_memory, mock_cpu):
        """Test comprehensive metrics collection."""
        mock_memory.return_value = Mock(percent=60.0, used=1000000, total=2000000)
        mock_disk.return_value = Mock(percent=70.0, used=5000000, total=10000000)
        mock_net.return_value = Mock(
            bytes_sent=1000, bytes_recv=2000, packets_sent=10, packets_recv=20,
            errin=0, errout=0, dropin=0, dropout=0
        )
        
        with patch('docker.from_env', side_effect=Exception("No docker")):
            data = await self.collector.collect_all_metrics()
        
        self.assertIn('summary', data)
        self.assertIn('token_usage', data)
        self.assertIn('system_resources', data)
        self.assertIn('process_monitoring', data)
        self.assertIn('docker_containers', data)
        self.assertIn('log_analysis', data)
        
        # Check summary data
        summary = data['summary']
        self.assertIn('total_cost', summary)
        self.assertIn('system_cpu_percent', summary)
        self.assertIn('system_memory_percent', summary)
    
    def test_project_metrics(self):
        """Test project-specific metrics."""
        metrics = self.collector.get_project_metrics("test-project")
        
        self.assertEqual(metrics.project_name, "test-project")
        self.assertIsInstance(metrics.resource_usage, dict)
        self.assertIsInstance(metrics.token_usage, TokenMetrics)
        self.assertIsInstance(metrics.active_sessions, int)
    
    def test_cache_management(self):
        """Test cache clearing and statistics."""
        # Set some cache data
        self.collector.cache.set("test_key", "test_value")
        
        cache_stats = self.collector.get_cache_stats()
        self.assertIn('main_cache_size', cache_stats)
        
        # Clear cache
        self.collector.clear_cache()
        cache_stats_after = self.collector.get_cache_stats()
        self.assertEqual(cache_stats_after['main_cache_size'], 0)


class TestMonitoringServiceAPI(unittest.TestCase):
    """Test FastAPI monitoring service endpoints."""
    
    def setUp(self):
        self.client = TestClient(app)
    
    @patch('monitoring_service.get_system_metrics')
    @patch('monitoring_service.get_token_usage')
    @patch('monitoring_service.get_docker_containers')
    @patch('monitoring_service.get_active_sessions')
    @patch('monitoring_service.get_recent_tool_calls')
    def test_dashboard_endpoint(self, mock_tool_calls, mock_sessions, mock_docker, mock_tokens, mock_system):
        """Test dashboard API endpoint."""
        # Mock all the dependencies
        mock_system.return_value = Mock(
            cpu_percent=45.0, memory_percent=60.0, memory_used=1000000, memory_total=2000000,
            disk_percent=70.0, disk_used=5000000, disk_total=10000000,
            load_average=[1.0, 1.0, 1.0], timestamp=datetime.now()
        )
        
        mock_tokens.return_value = Mock(
            total_input_tokens=1000, total_output_tokens=500, total_cost=0.50,
            sessions_count=10, avg_tokens_per_session=150.0, timestamp=datetime.now()
        )
        
        mock_docker.return_value = []
        mock_sessions.return_value = 5
        mock_tool_calls.return_value = 25
        
        response = self.client.get("/api/dashboard")
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        
        self.assertIn('system_metrics', data)
        self.assertIn('token_usage', data)
        self.assertIn('docker_containers', data)
        self.assertIn('active_sessions', data)
        self.assertIn('recent_tool_calls', data)
    
    def test_health_endpoint(self):
        """Test health check endpoint."""
        response = self.client.get("/health")
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        
        self.assertIn('status', data)
        self.assertEqual(data['status'], 'healthy')
        self.assertIn('timestamp', data)
    
    @patch('monitoring_service.get_token_usage')
    def test_tokens_endpoint(self, mock_tokens):
        """Test tokens API endpoint."""
        mock_tokens.return_value = Mock(
            total_input_tokens=1000, total_output_tokens=500, total_cost=0.50,
            sessions_count=10, avg_tokens_per_session=150.0, timestamp=datetime.now()
        )
        
        response = self.client.get("/api/tokens")
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        
        self.assertIn('total_input_tokens', data)
        self.assertIn('total_output_tokens', data)
        self.assertIn('total_cost', data)


class TestIntegrationDataFlow(unittest.TestCase):
    """Integration tests for data flow between components."""
    
    def setUp(self):
        """Set up integration test environment."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        # Create test database with realistic data
        self._create_integration_test_db()
        
        self.temp_log_dir = tempfile.mkdtemp()
        self._create_test_log_files()
        
        self.collector = DataCollector(self.db_path, [self.temp_log_dir])
    
    def tearDown(self):
        """Clean up integration test environment."""
        try:
            os.unlink(self.db_path)
        except:
            pass
        
        import shutil
        shutil.rmtree(self.temp_log_dir, ignore_errors=True)
    
    def _create_integration_test_db(self):
        """Create realistic test database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create schema
        cursor.execute("""
            CREATE TABLE nodes (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                raw_json TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE sessions (
                id INTEGER PRIMARY KEY,
                created_at TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE tool_calls (
                id INTEGER PRIMARY KEY,
                timestamp TEXT
            )
        """)
        
        # Insert realistic data
        models = ['claude-3-sonnet', 'claude-3-haiku', 'gpt-4', 'gpt-3.5-turbo']
        for i in range(50):
            node_data = {
                'input_tokens': 50 + (i * 10),
                'output_tokens': 25 + (i * 5),
                'model': models[i % len(models)]
            }
            cursor.execute(
                "INSERT INTO nodes (timestamp, raw_json) VALUES (?, ?)",
                ((datetime.now() - timedelta(hours=i // 10)).isoformat(), json.dumps(node_data))
            )
        
        for i in range(10):
            cursor.execute(
                "INSERT INTO sessions (created_at) VALUES (?)",
                ((datetime.now() - timedelta(hours=i)).isoformat(),)
            )
        
        for i in range(100):
            cursor.execute(
                "INSERT INTO tool_calls (timestamp) VALUES (?)",
                ((datetime.now() - timedelta(minutes=i * 5)).isoformat(),)
            )
        
        conn.commit()
        conn.close()
    
    def _create_test_log_files(self):
        """Create test log files with realistic content."""
        app_log = os.path.join(self.temp_log_dir, 'app.log')
        with open(app_log, 'w') as f:
            f.write("""
2023-12-01 10:00:00 INFO Starting Claude monitoring service
2023-12-01 10:01:00 INFO Database connection established
2023-12-01 10:02:00 WARNING High memory usage detected: 85%
2023-12-01 10:03:00 ERROR Failed to connect to Docker daemon
2023-12-01 10:04:00 INFO Token usage: 1500 tokens processed
2023-12-01 10:05:00 ERROR Database query timeout after 30s
2023-12-01 10:06:00 INFO Claude API response received in 250ms
            """)
        
        error_log = os.path.join(self.temp_log_dir, 'errors.log')
        with open(error_log, 'w') as f:
            f.write("""
2023-12-01 10:00:00 ERROR Connection failed: timeout
2023-12-01 10:15:00 ERROR Connection failed: timeout
2023-12-01 10:30:00 ERROR Database locked
2023-12-01 10:45:00 ERROR API rate limit exceeded
            """)
    
    @patch('psutil.cpu_percent', return_value=75.0)
    @patch('psutil.virtual_memory')
    @patch('psutil.disk_usage')
    @patch('psutil.net_io_counters')
    @patch('psutil.getloadavg', return_value=[2.5, 2.0, 1.8])
    async def test_complete_data_collection_flow(self, mock_loadavg, mock_net, mock_disk, mock_memory, mock_cpu):
        """Test complete integration data flow."""
        mock_memory.return_value = Mock(percent=85.0, used=8589934592, total=10737418240)
        mock_disk.return_value = Mock(percent=65.0, used=500000000000, total=800000000000)
        mock_net.return_value = Mock(
            bytes_sent=1000000000, bytes_recv=2000000000, packets_sent=10000, packets_recv=20000,
            errin=5, errout=2, dropin=1, dropout=0
        )
        
        with patch('docker.from_env', side_effect=Exception("Docker not available")):
            data = await self.collector.collect_all_metrics(hours_back=48)
        
        # Verify complete data structure
        self.assertIn('summary', data)
        self.assertIn('token_usage', data)
        self.assertIn('system_resources', data)
        self.assertIn('process_monitoring', data)
        self.assertIn('docker_containers', data)
        self.assertIn('log_analysis', data)
        self.assertIn('session_activity', data)
        self.assertIn('collection_info', data)
        
        # Verify data quality
        summary = data['summary']
        self.assertGreater(summary['total_tokens'], 0)
        self.assertGreater(summary['total_cost'], 0)
        self.assertEqual(summary['system_cpu_percent'], 75.0)
        self.assertEqual(summary['system_memory_percent'], 85.0)
        
        # Verify log analysis picked up errors
        log_data = data['log_analysis']
        self.assertGreater(log_data['error_count'], 0)
        self.assertGreater(log_data['warning_count'], 0)
        self.assertIn('Connection failed', str(log_data['common_errors']))
        
        # Verify token analysis by model
        token_data = data['token_usage']
        self.assertIn('cost_by_model', token_data)
        self.assertIn('tokens_by_model', token_data)
        self.assertGreater(len(token_data['cost_by_model']), 0)
    
    def test_cross_component_consistency(self):
        """Test data consistency between components."""
        # Get data from individual collectors
        db_collector = DatabaseCollector(self.db_path)
        system_collector = SystemCollector()
        log_collector = LogCollector([self.temp_log_dir])
        
        # Get individual metrics
        token_metrics = db_collector.get_token_metrics()
        session_metrics = db_collector.get_session_metrics()
        log_metrics = log_collector.get_log_metrics()
        
        # Verify data consistency
        self.assertGreater(token_metrics.sessions_count, 0)
        self.assertGreater(session_metrics['total_sessions'], 0)
        self.assertGreater(log_metrics.log_files_processed, 0)
        
        # Token calculation should be consistent
        expected_total = token_metrics.total_input_tokens + token_metrics.total_output_tokens
        self.assertEqual(token_metrics.total_tokens, expected_total)


class TestPerformance(unittest.TestCase):
    """Performance tests for monitoring system."""
    
    def setUp(self):
        """Set up performance test environment."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        self._create_large_test_database()
        self.collector = DataCollector(self.db_path)
    
    def tearDown(self):
        """Clean up performance test environment."""
        try:
            os.unlink(self.db_path)
        except:
            pass
    
    def _create_large_test_database(self):
        """Create a large test database for performance testing."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create schema
        cursor.execute("""
            CREATE TABLE nodes (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                raw_json TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE sessions (
                id INTEGER PRIMARY KEY,
                created_at TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE tool_calls (
                id INTEGER PRIMARY KEY,
                timestamp TEXT
            )
        """)
        
        # Insert large dataset (10,000 records)
        models = ['claude-3-sonnet', 'claude-3-haiku', 'gpt-4', 'gpt-3.5-turbo']
        for i in range(10000):
            node_data = {
                'input_tokens': 100 + (i % 1000),
                'output_tokens': 50 + (i % 500),
                'model': models[i % len(models)]
            }
            cursor.execute(
                "INSERT INTO nodes (timestamp, raw_json) VALUES (?, ?)",
                ((datetime.now() - timedelta(minutes=i)).isoformat(), json.dumps(node_data))
            )
            
            if i % 100 == 0:  # Session every 100 nodes
                cursor.execute(
                    "INSERT INTO sessions (created_at) VALUES (?)",
                    ((datetime.now() - timedelta(minutes=i)).isoformat(),)
                )
            
            if i % 10 == 0:  # Tool call every 10 nodes
                cursor.execute(
                    "INSERT INTO tool_calls (timestamp) VALUES (?)",
                    ((datetime.now() - timedelta(minutes=i)).isoformat(),)
                )
        
        # Create indices for performance
        cursor.execute("CREATE INDEX idx_nodes_timestamp ON nodes(timestamp)")
        cursor.execute("CREATE INDEX idx_sessions_created_at ON sessions(created_at)")
        cursor.execute("CREATE INDEX idx_tool_calls_timestamp ON tool_calls(timestamp)")
        
        conn.commit()
        conn.close()
    
    def test_database_query_performance(self):
        """Test database query performance with large dataset."""
        db_collector = DatabaseCollector(self.db_path)
        
        # Measure token metrics query performance
        start_time = time.time()
        metrics = db_collector.get_token_metrics()
        query_time = time.time() - start_time
        
        # Should complete within reasonable time (< 1 second for 10k records)
        self.assertLess(query_time, 1.0, f"Query took {query_time:.3f}s, expected < 1.0s")
        
        # Verify correct results
        self.assertGreater(metrics.total_tokens, 0)
        self.assertEqual(metrics.sessions_count, 100)  # 10000 / 100
    
    def test_cache_performance(self):
        """Test cache performance with repeated queries."""
        db_collector = DatabaseCollector(self.db_path)
        
        # First query (should be slow)
        start_time = time.time()
        metrics1 = db_collector.get_token_metrics()
        first_query_time = time.time() - start_time
        
        # Second query (should be fast due to caching)
        start_time = time.time()
        metrics2 = db_collector.get_token_metrics()
        cached_query_time = time.time() - start_time
        
        # Cached query should be significantly faster
        self.assertLess(cached_query_time, first_query_time / 10)
        
        # Results should be identical
        self.assertEqual(metrics1.total_tokens, metrics2.total_tokens)
    
    @patch('psutil.cpu_percent', return_value=50.0)
    @patch('psutil.virtual_memory')
    @patch('psutil.disk_usage')
    @patch('psutil.net_io_counters')
    @patch('psutil.getloadavg', return_value=[1.0, 1.0, 1.0])
    async def test_concurrent_collection_performance(self, mock_loadavg, mock_net, mock_disk, mock_memory, mock_cpu):
        """Test performance of concurrent data collection."""
        mock_memory.return_value = Mock(percent=60.0, used=1000000, total=2000000)
        mock_disk.return_value = Mock(percent=70.0, used=5000000, total=10000000)
        mock_net.return_value = Mock(
            bytes_sent=1000, bytes_recv=2000, packets_sent=10, packets_recv=20,
            errin=0, errout=0, dropin=0, dropout=0
        )
        
        with patch('docker.from_env', side_effect=Exception("No docker")):
            # Measure concurrent collection time
            start_time = time.time()
            data = await self.collector.collect_all_metrics()
            collection_time = time.time() - start_time
            
            # Should complete within reasonable time (< 5 seconds)
            self.assertLess(collection_time, 5.0, f"Collection took {collection_time:.3f}s, expected < 5.0s")
            
            # Verify data completeness
            self.assertIn('summary', data)
            self.assertGreater(data['summary']['total_tokens'], 0)
    
    def test_memory_usage_efficiency(self):
        """Test memory usage efficiency during data collection."""
        import tracemalloc
        
        # Start memory tracing
        tracemalloc.start()
        
        # Perform data collection
        db_collector = DatabaseCollector(self.db_path)
        metrics = db_collector.get_token_metrics()
        
        # Get current memory usage
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        
        # Memory usage should be reasonable (< 50MB)
        memory_mb = peak / 1024 / 1024
        self.assertLess(memory_mb, 50, f"Peak memory usage: {memory_mb:.2f}MB, expected < 50MB")
        
        # Verify data was collected correctly
        self.assertGreater(metrics.total_tokens, 0)


class TestWebSocketIntegration(unittest.TestCase):
    """Test WebSocket functionality for real-time updates."""
    
    def setUp(self):
        self.client = TestClient(app)
    
    @patch('monitoring_service.get_dashboard')
    async def test_websocket_connection(self, mock_dashboard):
        """Test WebSocket connection and message handling."""
        mock_dashboard.return_value = {
            'system_metrics': {
                'cpu_percent': 50.0,
                'memory_percent': 60.0,
                'timestamp': datetime.now().isoformat()
            },
            'token_usage': {
                'total_tokens': 1000,
                'total_cost': 0.50
            }
        }
        
        with self.client.websocket_connect("/ws") as websocket:
            # Should be able to connect
            self.assertIsNotNone(websocket)
            
            # Send a keepalive message
            websocket.send_text("ping")
            
            # Should receive a dashboard update
            data = websocket.receive_json()
            self.assertIn('type', data)
            self.assertEqual(data['type'], 'dashboard_update')
            self.assertIn('data', data)


def run_performance_benchmark():
    """Run performance benchmarks and print results."""
    print("\n" + "="*60)
    print("PERFORMANCE BENCHMARK RESULTS")
    print("="*60)
    
    # Database performance test
    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
    db_path = temp_db.name
    temp_db.close()
    
    try:
        # Create large test database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("CREATE TABLE nodes (id INTEGER PRIMARY KEY, timestamp TEXT, raw_json TEXT)")
        cursor.execute("CREATE TABLE sessions (id INTEGER PRIMARY KEY, created_at TEXT)")
        cursor.execute("CREATE TABLE tool_calls (id INTEGER PRIMARY KEY, timestamp TEXT)")
        
        # Insert test data
        print("Creating test database with 10,000 records...")
        start_time = time.time()
        
        for i in range(10000):
            node_data = json.dumps({
                'input_tokens': 100 + (i % 1000),
                'output_tokens': 50 + (i % 500),
                'model': ['claude-3-sonnet', 'gpt-4'][i % 2]
            })
            cursor.execute(
                "INSERT INTO nodes (timestamp, raw_json) VALUES (?, ?)",
                ((datetime.now() - timedelta(minutes=i)).isoformat(), node_data)
            )
        
        conn.commit()
        conn.close()
        
        creation_time = time.time() - start_time
        print(f"✓ Database creation: {creation_time:.3f}s")
        
        # Test query performance
        db_collector = DatabaseCollector(db_path)
        
        start_time = time.time()
        metrics = db_collector.get_token_metrics()
        query_time = time.time() - start_time
        print(f"✓ Token metrics query: {query_time:.3f}s")
        
        # Test cache performance
        start_time = time.time()
        metrics2 = db_collector.get_token_metrics()
        cache_time = time.time() - start_time
        print(f"✓ Cached query: {cache_time:.6f}s (speedup: {query_time/cache_time:.1f}x)")
        
        print(f"✓ Processed {metrics.sessions_count} sessions, {metrics.total_tokens:,} tokens")
        
    finally:
        try:
            os.unlink(db_path)
        except:
            pass
    
    print("="*60)


if __name__ == '__main__':
    # Check if running as performance benchmark
    if len(sys.argv) > 1 and sys.argv[1] == 'benchmark':
        run_performance_benchmark()
    else:
        # Run tests
        print("Running comprehensive monitoring system tests...")
        
        # Discover and run tests
        test_suite = unittest.TestLoader().discover('.', pattern='test_monitor.py')
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(test_suite)
        
        # Print summary
        print(f"\n{'='*60}")
        print(f"TEST SUMMARY")
        print(f"{'='*60}")
        print(f"Tests run: {result.testsRun}")
        print(f"Failures: {len(result.failures)}")
        print(f"Errors: {len(result.errors)}")
        
        if result.failures:
            print(f"\nFAILURES:")
            for test, traceback in result.failures:
                print(f"- {test}: {traceback}")
        
        if result.errors:
            print(f"\nERRORS:")
            for test, traceback in result.errors:
                print(f"- {test}: {traceback}")
        
        # Exit with appropriate code
        sys.exit(0 if result.wasSuccessful() else 1)