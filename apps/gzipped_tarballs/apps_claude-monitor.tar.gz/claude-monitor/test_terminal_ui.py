#!/usr/bin/env python3
"""
Test script for terminal UI - validates imports and basic functionality
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

def test_imports():
    """Test all required imports"""
    try:
        from console.terminal_ui import TerminalUI, ViewMode, MonitoringData, UIState
        print("✅ All imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error during import: {e}")
        return False

def test_initialization():
    """Test UI initialization"""
    try:
        from console.terminal_ui import TerminalUI
        ui = TerminalUI("ws://localhost:8000/ws")
        print("✅ TerminalUI initialization successful")
        
        # Test view switching
        ui.state.current_view = ViewMode.DOCKER
        print("✅ View switching works")
        
        return True
    except Exception as e:
        print(f"❌ Initialization error: {e}")
        return False

def test_data_structures():
    """Test data structure creation"""
    try:
        from console.terminal_ui import MonitoringData, UIState, ViewMode
        
        data = MonitoringData()
        state = UIState()
        
        print("✅ Data structures created successfully")
        
        # Test enum
        assert ViewMode.MASTER.value == "master"
        assert ViewMode.DOCKER.value == "docker"
        print("✅ ViewMode enum works correctly")
        
        return True
    except Exception as e:
        print(f"❌ Data structure error: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Testing Claude Monitor Terminal UI")
    print("=" * 50)
    
    tests = [
        ("Import Test", test_imports),
        ("Initialization Test", test_initialization), 
        ("Data Structure Test", test_data_structures)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n🔍 Running {test_name}...")
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All tests passed! Terminal UI is ready to use.")
        print("\nTo run the terminal UI:")
        print("  python console/terminal_ui.py")
        return True
    else:
        print("❌ Some tests failed. Please check the errors above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)