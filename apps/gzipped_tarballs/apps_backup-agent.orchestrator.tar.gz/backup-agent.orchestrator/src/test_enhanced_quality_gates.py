#!/usr/bin/env python3
"""
Comprehensive Test Suite for Enhanced Quality Gate System

Tests all four enhancement areas:
1. Intelligent Context Management System  
2. Dynamic Plan Adaptation Engine
3. Predictive Resource Optimization
4. Inter-Agent Collaboration Framework

Also tests integration with existing orchestrator components.
"""

import asyncio
import json
import tempfile
import time
from pathlib import Path
from unittest.mock import Mock, AsyncMock
import pytest

try:
    from .enhanced_quality_gates import (
        ContextBroker, ExecutionContext, ResourcePredictor, PlanAdaptationEngine,
        AgentMesh, Message, EnhancedQualityGateManager, TaskMetrics, ResourcePrediction
    )
    from .enhanced_orchestrator_integration import IntelligentOrchestrator, create_intelligent_orchestrator
    from .enhanced_orchestrator import EnhancedAgentTask
except ImportError:
    from enhanced_quality_gates import (
        ContextBroker, ExecutionContext, ResourcePredictor, PlanAdaptationEngine,
        AgentMesh, Message, EnhancedQualityGateManager, TaskMetrics, ResourcePrediction
    )
    from enhanced_orchestrator_integration import IntelligentOrchestrator, create_intelligent_orchestrator
    from enhanced_orchestrator import EnhancedAgentTask


class TestContextBroker:
    """Test Intelligent Context Management System"""
    
    @pytest.fixture
    async def context_broker(self):
        """Create context broker for testing"""
        with tempfile.TemporaryDirectory() as temp_dir:
            context_store = Path(temp_dir) / "contexts"
            broker = ContextBroker(context_store)
            yield broker
    
    async def test_create_context(self, context_broker):
        """Test context creation"""
        context_id = await context_broker.create_context("plan_123", {"key": "value"})
        
        assert context_id.startswith("ctx_plan_123_")
        assert context_id in context_broker.active_contexts
        
        context = context_broker.active_contexts[context_id]
        assert context.plan_id == "plan_123"
        assert context.global_variables["key"] == "value"
    
    async def test_update_context(self, context_broker):
        """Test context updates"""
        context_id = await context_broker.create_context("plan_456")
        
        updates = {
            'variables': {'new_var': 'new_value'},
            'knowledge': {'task_1': {'insight': 'important finding'}},
            'decision': {'choice': 'use approach A'},
            'task_id': 'task_1'
        }
        
        await context_broker.update_context(context_id, updates)
        
        context = context_broker.active_contexts[context_id]
        assert context.global_variables['new_var'] == 'new_value'
        assert context.cross_task_knowledge['task_1']['insight'] == 'important finding'
        assert len(context.decision_history) == 1
        assert context.decision_history[0]['decision'] == {'choice': 'use approach A'}
    
    async def test_get_context_for_task(self, context_broker):
        """Test context retrieval for specific task"""
        context_id = await context_broker.create_context("plan_789", {"shared": "data"})
        
        # Add some context data
        await context_broker.update_context(context_id, {
            'knowledge': {'prev_task': {'result': 'success'}},
            'decision': {'approach': 'iterative'},
            'task_id': 'prev_task'
        })
        
        task_context = await context_broker.get_context_for_task(context_id, "current_task")
        
        assert task_context['global_variables']['shared'] == 'data'
        assert task_context['cross_task_knowledge']['prev_task']['result'] == 'success'
        assert len(task_context['relevant_decisions']) == 1
    
    async def test_context_subscribers(self, context_broker):
        """Test context update notifications"""
        context_id = await context_broker.create_context("plan_notify")
        
        updates_received = []
        
        async def callback(ctx_id, updates):
            updates_received.append((ctx_id, updates))
        
        context_broker.subscribe_to_context_updates(context_id, callback)
        
        await context_broker.update_context(context_id, {'variables': {'test': 'value'}})
        
        assert len(updates_received) == 1
        assert updates_received[0][0] == context_id
        assert updates_received[0][1]['variables']['test'] == 'value'


class TestResourcePredictor:
    """Test Predictive Resource Optimization"""
    
    @pytest.fixture
    def resource_predictor(self):
        """Create resource predictor for testing"""
        with tempfile.TemporaryDirectory() as temp_dir:
            data_path = Path(temp_dir) / "resource_history.json"
            predictor = ResourcePredictor(data_path)
            yield predictor
    
    def test_predict_resources_no_history(self, resource_predictor):
        """Test resource prediction with no historical data"""
        task = EnhancedAgentTask(
            task_id="test_task",
            task_type="code",
            prompt="Write a simple function",
            context={},
            dependencies=[]
        )
        
        prediction = resource_predictor.predict_resources(task)
        
        assert isinstance(prediction, ResourcePrediction)
        assert prediction.estimated_tokens > 0
        assert prediction.estimated_duration > 0
        assert 0 <= prediction.confidence <= 1
    
    def test_record_and_predict(self, resource_predictor):
        """Test learning from execution history"""
        # Create and record a task execution
        task = EnhancedAgentTask(
            task_id="learning_task",
            task_type="research",
            prompt="Research machine learning algorithms",
            context={},
            dependencies=[]
        )
        
        metrics = TaskMetrics(
            duration=120.5,
            memory_usage=256,
            tokens_used=1500,
            status='completed'
        )
        
        # Record execution
        resource_predictor.record_execution(task, metrics)
        
        # Create similar task
        similar_task = EnhancedAgentTask(
            task_id="similar_task", 
            task_type="research",
            prompt="Research neural network architectures",
            context={},
            dependencies=[]
        )
        
        # Predict should be more accurate now
        prediction = resource_predictor.predict_resources(similar_task)
        
        # Should have some confidence since we have history
        assert prediction.confidence > 0.3
        assert prediction.estimated_duration > 0
    
    def test_find_similar_tasks(self, resource_predictor):
        """Test similar task finding algorithm"""
        # Add some history
        for i in range(5):
            task = EnhancedAgentTask(
                task_id=f"task_{i}",
                task_type="code",
                prompt=f"Implement function {i}",
                context={},
                dependencies=[]
            )
            
            metrics = TaskMetrics(
                duration=60 + i * 10,
                tokens_used=1000 + i * 100
            )
            
            resource_predictor.record_execution(task, metrics)
        
        # Test features
        features = {
            'task_type': 'code',
            'prompt_length': 20,
            'context_size': 100,
            'dependencies_count': 0,
            'has_quality_gates': False
        }
        
        similar_tasks = resource_predictor._find_similar_tasks(features)
        
        # Should find some similar tasks
        assert len(similar_tasks) > 0
        assert all(task['task_type'] == 'code' for task in similar_tasks)
    
    def test_save_load_historical_data(self, resource_predictor):
        """Test persistence of historical data"""
        # Record some data
        task = EnhancedAgentTask(
            task_id="persist_task",
            task_type="test",
            prompt="Test persistence",
            context={},
            dependencies=[]
        )
        
        metrics = TaskMetrics(duration=30, tokens_used=500)
        resource_predictor.record_execution(task, metrics)
        
        # Save data
        resource_predictor.save_historical_data()
        
        # Create new predictor with same data path
        new_predictor = ResourcePredictor(resource_predictor.data_path)
        
        # Should have loaded the data
        assert len(new_predictor.execution_history) == len(resource_predictor.execution_history)


class TestAgentMesh:
    """Test Inter-Agent Collaboration Framework"""
    
    @pytest.fixture
    def agent_mesh(self):
        """Create agent mesh for testing"""
        return AgentMesh("test_mesh")
    
    def test_register_agent(self, agent_mesh):
        """Test agent registration"""
        agent_mesh.register_agent("agent_1", ["programming", "testing"])
        
        assert "agent_1" in agent_mesh.active_agents
        assert agent_mesh.active_agents["agent_1"]["capabilities"] == ["programming", "testing"]
        assert agent_mesh.active_agents["agent_1"]["status"] == "active"
    
    async def test_send_receive_message(self, agent_mesh):
        """Test message sending and receiving"""
        # Register agents
        agent_mesh.register_agent("sender", ["analysis"])
        agent_mesh.register_agent("receiver", ["execution"])
        
        # Create and send message
        message = Message(
            sender_id="sender",
            recipient_id="receiver",
            message_type="request",
            content={"task": "analyze code"},
            timestamp=time.time()
        )
        
        success = await agent_mesh.send_message(message)
        assert success
        
        # Receive message
        messages = await agent_mesh.get_messages("receiver")
        assert len(messages) == 1
        assert messages[0].content["task"] == "analyze code"
        assert messages[0].sender_id == "sender"
    
    async def test_expert_consultation_pattern(self, agent_mesh):
        """Test built-in expert consultation pattern"""
        # Register expert agents
        agent_mesh.register_agent("expert_1", ["machine_learning"])
        agent_mesh.register_agent("expert_2", ["machine_learning", "deep_learning"])
        agent_mesh.register_agent("requester", ["programming"])
        
        # Test consultation
        consultation = await agent_mesh.collaboration_patterns['expert_consultation'](
            "requester", "How to optimize neural networks?", "machine_learning"
        )
        
        assert consultation['success']
        assert len(consultation['experts_consulted']) == 2
        assert 'correlation_id' in consultation
    
    async def test_message_queue_limits(self, agent_mesh):
        """Test message queue size limits"""
        agent_mesh.register_agent("sender", [])
        agent_mesh.register_agent("receiver", [])
        
        # Send many messages (more than queue limit)
        for i in range(150):  # Queue limit is 100
            message = Message(
                sender_id="sender",
                recipient_id="receiver", 
                message_type="test",
                content={"number": i},
                timestamp=time.time()
            )
            await agent_mesh.send_message(message)
        
        # Should only keep last 100 messages
        messages = await agent_mesh.get_messages("receiver", limit=150)
        assert len(messages) == 100
        assert messages[0].content["number"] >= 50  # Should be later messages


class TestPlanAdaptationEngine:
    """Test Dynamic Plan Adaptation Engine"""
    
    @pytest.fixture
    def adaptation_engine(self):
        """Create adaptation engine for testing"""
        mock_orchestrator = Mock()
        return PlanAdaptationEngine(mock_orchestrator)
    
    async def test_analyze_failure(self, adaptation_engine):
        """Test failure analysis"""
        # Test transient error
        analysis = await adaptation_engine._analyze_failure("Connection timeout occurred")
        assert analysis['category'] == 'transient'
        assert analysis['confidence'] > 0.8
        
        # Test resource limitation
        analysis = await adaptation_engine._analyze_failure("Memory limit exceeded")
        assert analysis['category'] == 'resource_limitation'
        
        # Test unknown error
        analysis = await adaptation_engine._analyze_failure("Some random error")
        assert analysis['category'] == 'unknown'
    
    async def test_adaptation_history(self, adaptation_engine):
        """Test adaptation history tracking"""
        # Mock plan object
        mock_plan = Mock()
        mock_plan.id = "plan_123"
        
        context = {
            'failed_task_id': 'task_1',
            'error': 'Connection timeout'
        }
        
        # Perform adaptation (will return same plan for now, but should record)
        await adaptation_engine.adapt_plan(mock_plan, 'task_failure', context)
        
        # Check history was recorded
        assert len(adaptation_engine.adaptation_history) == 1
        history_entry = adaptation_engine.adaptation_history[0]
        assert history_entry['trigger'] == 'task_failure'
        assert history_entry['original_plan_id'] == 'plan_123'


class TestEnhancedQualityGateManager:
    """Test Enhanced Quality Gate Manager"""
    
    @pytest.fixture
    async def enhanced_manager(self):
        """Create enhanced quality gate manager"""
        with tempfile.TemporaryDirectory() as temp_dir:
            context_store = Path(temp_dir) / "contexts"
            manager = EnhancedQualityGateManager(
                context_store_path=context_store,
                enable_predictions=True,
                enable_collaboration=True
            )
            yield manager
    
    async def test_validate_with_context(self, enhanced_manager):
        """Test context-aware validation"""
        task = EnhancedAgentTask(
            task_id="context_test",
            task_type="code", 
            prompt="Implement user authentication",
            context={},
            dependencies=[]
        )
        
        # Create context
        context_id = await enhanced_manager.context_broker.create_context("plan_1")
        
        # Add conflicting decision to context
        await enhanced_manager.context_broker.update_context(context_id, {
            'decision': {'approach': 'avoid authentication for now'},
            'task_id': 'previous_task'
        })
        
        # Validate with context
        results = await enhanced_manager.validate_with_context(task, context_id)
        
        # Should have context validation results
        assert 'context' in results
        assert 'resources' in results
        
        # Context validation might have warnings about conflicting decisions
        context_result = results['context']
        assert isinstance(context_result.warnings, list)


class TestIntelligentOrchestrator:
    """Test the complete Intelligent Orchestrator"""
    
    @pytest.fixture
    async def intelligent_orchestrator(self):
        """Create intelligent orchestrator for testing"""
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir)
            orchestrator = create_intelligent_orchestrator(
                output_dir=output_dir,
                intelligence_level="full"
            )
            yield orchestrator
    
    async def test_initialization(self, intelligent_orchestrator):
        """Test intelligent orchestrator initialization"""
        assert intelligent_orchestrator.enable_intelligent_gates
        assert intelligent_orchestrator.enable_context_management  
        assert intelligent_orchestrator.enable_resource_prediction
        assert intelligent_orchestrator.enable_collaboration
        assert intelligent_orchestrator.enable_adaptation
        
        assert intelligent_orchestrator.context_broker is not None
        assert intelligent_orchestrator.resource_predictor is not None
        assert intelligent_orchestrator.agent_mesh is not None
        assert intelligent_orchestrator.adaptation_engine is not None
    
    async def test_create_optimal_batches(self, intelligent_orchestrator):
        """Test intelligent batch creation"""
        tasks = [
            EnhancedAgentTask(
                task_id=f"task_{i}",
                task_type="code",
                prompt=f"Task {i}",
                context={},
                dependencies=[]
            )
            for i in range(5)
        ]
        
        # Generate predictions
        predictions = {}
        for task in tasks:
            predictions[task.task_id] = ResourcePrediction(
                estimated_tokens=1000 + i * 200,
                estimated_duration=60 + i * 30,
                memory_requirements=256,
                parallel_compatibility=0.8,
                optimal_batch_size=3,
                confidence=0.7
            )
        
        # Create optimized batches
        batches = intelligent_orchestrator._create_optimal_batches(tasks, predictions)
        
        # Should create reasonable batches
        assert len(batches) > 0
        assert all(len(batch) <= intelligent_orchestrator.max_parallel for batch in batches)
        
        # All tasks should be included
        total_tasks = sum(len(batch) for batch in batches)
        assert total_tasks == len(tasks)
    
    async def test_intelligence_report(self, intelligent_orchestrator):
        """Test intelligence reporting"""
        report = await intelligent_orchestrator.get_intelligence_report()
        
        assert 'intelligence_metrics' in report
        assert 'features_enabled' in report
        assert 'resource_predictor' in report
        assert 'context_broker' in report
        assert 'agent_mesh' in report
        
        # Check feature flags
        features = report['features_enabled']
        assert features['intelligent_gates']
        assert features['context_management']
        assert features['resource_prediction']
        assert features['collaboration']
        assert features['adaptation']


class TestIntegrationScenarios:
    """Test real-world integration scenarios"""
    
    async def test_development_workflow(self):
        """Test a complete development workflow"""
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir)
            
            # Create development-optimized orchestrator
            from enhanced_orchestrator_integration import create_development_orchestrator
            orchestrator = create_development_orchestrator(output_dir)
            
            # Create development tasks
            tasks = [
                EnhancedAgentTask(
                    task_id="design",
                    task_type="design",
                    prompt="Design user registration system",
                    context={},
                    dependencies=[]
                ),
                EnhancedAgentTask(
                    task_id="implement",
                    task_type="code", 
                    prompt="Implement user registration based on design",
                    context={},
                    dependencies=["design"]
                ),
                EnhancedAgentTask(
                    task_id="test",
                    task_type="test",
                    prompt="Write tests for user registration",
                    context={},
                    dependencies=["implement"]
                )
            ]
            
            # Test context creation
            context_id = await orchestrator.context_broker.create_context(
                "dev_workflow",
                {"project": "user_system", "phase": "initial"}
            )
            
            orchestrator.current_context_id = context_id
            
            # Test intelligence features on first task
            design_task = tasks[0]
            await orchestrator._apply_pre_execution_intelligence(design_task)
            
            # Should have context injected
            assert 'project' in design_task.context
            assert design_task.context['project'] == "user_system"
            
            # Should have resource prediction
            assert 'resource_prediction' in design_task.context
            prediction = design_task.context['resource_prediction']
            assert 'estimated_tokens' in prediction
            assert 'confidence' in prediction


# Utility functions for running tests

async def run_all_tests():
    """Run all tests manually (for when pytest isn't available)"""
    
    print("Running Enhanced Quality Gate System Tests...")
    print("=" * 60)
    
    # Context Broker Tests
    print("\n1. Testing Context Management System...")
    context_test = TestContextBroker()
    
    with tempfile.TemporaryDirectory() as temp_dir:
        context_store = Path(temp_dir) / "contexts"
        broker = ContextBroker(context_store)
        
        # Test context creation
        context_id = await broker.create_context("test_plan", {"test": "data"})
        assert context_id.startswith("ctx_test_plan_")
        print("   ✓ Context creation")
        
        # Test context updates
        await broker.update_context(context_id, {
            'variables': {'new_var': 'value'},
            'decision': {'choice': 'A'},
            'task_id': 'test_task'
        })
        context = broker.active_contexts[context_id]
        assert context.global_variables['new_var'] == 'value'
        print("   ✓ Context updates")
        
        # Test context retrieval
        task_context = await broker.get_context_for_task(context_id, "other_task")
        assert 'global_variables' in task_context
        print("   ✓ Context retrieval")
    
    # Resource Predictor Tests  
    print("\n2. Testing Resource Prediction System...")
    with tempfile.TemporaryDirectory() as temp_dir:
        data_path = Path(temp_dir) / "resource_history.json"
        predictor = ResourcePredictor(data_path)
        
        # Test prediction without history
        task = EnhancedAgentTask(
            task_id="test", task_type="code", prompt="Test task",
            context={}, dependencies=[]
        )
        prediction = predictor.predict_resources(task)
        assert prediction.estimated_tokens > 0
        print("   ✓ Basic prediction")
        
        # Test learning
        metrics = TaskMetrics(duration=60, tokens_used=1200)
        predictor.record_execution(task, metrics)
        assert len(predictor.execution_history) == 1
        print("   ✓ Learning from execution")
    
    # Agent Mesh Tests
    print("\n3. Testing Collaboration Framework...")
    mesh = AgentMesh("test")
    
    # Test agent registration
    mesh.register_agent("agent_1", ["coding"])
    assert "agent_1" in mesh.active_agents
    print("   ✓ Agent registration")
    
    # Test messaging
    mesh.register_agent("agent_2", ["testing"])
    message = Message(
        sender_id="agent_1", recipient_id="agent_2",
        message_type="request", content={"task": "help"},
        timestamp=time.time()
    )
    success = await mesh.send_message(message)
    assert success
    
    messages = await mesh.get_messages("agent_2")
    assert len(messages) == 1
    print("   ✓ Message passing")
    
    # Plan Adaptation Tests
    print("\n4. Testing Plan Adaptation...")
    mock_orchestrator = Mock()
    adapter = PlanAdaptationEngine(mock_orchestrator)
    
    # Test failure analysis
    analysis = await adapter._analyze_failure("Connection timeout")
    assert analysis['category'] == 'transient'
    print("   ✓ Failure analysis")
    
    # Integration Test
    print("\n5. Testing Full Integration...")
    with tempfile.TemporaryDirectory() as temp_dir:
        output_dir = Path(temp_dir)
        orchestrator = create_intelligent_orchestrator(output_dir, intelligence_level="full")
        
        assert orchestrator.enable_intelligent_gates
        assert orchestrator.context_broker is not None
        assert orchestrator.resource_predictor is not None
        assert orchestrator.agent_mesh is not None
        print("   ✓ Intelligent orchestrator creation")
        
        # Test intelligence report
        report = await orchestrator.get_intelligence_report()
        assert 'intelligence_metrics' in report
        assert 'features_enabled' in report
        print("   ✓ Intelligence reporting")
    
    print("\n" + "=" * 60)
    print("All Enhanced Quality Gate Tests PASSED! ✅")
    print("\nEnhancements successfully implemented:")
    print("  • Intelligent Context Management System")
    print("  • Dynamic Plan Adaptation Engine") 
    print("  • Predictive Resource Optimization")
    print("  • Inter-Agent Collaboration Framework")
    print("  • Full Integration with Existing Orchestrator")


if __name__ == "__main__":
    # Run tests manually if called directly
    asyncio.run(run_all_tests())