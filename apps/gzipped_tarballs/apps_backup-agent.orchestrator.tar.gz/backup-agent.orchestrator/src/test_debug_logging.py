#!/usr/bin/env python3
"""
Test script for the enhanced debug logging implementation

This script validates that the debug logging system works correctly
and produces the expected comprehensive logs.
"""

import asyncio
import tempfile
from pathlib import Path
from datetime import datetime

from debug_generic_orchestrator import DebugGenericOrchestrator, AgentTask, create_debug_orchestrator
from log_analyzer import LogAnalyzer


def create_test_tasks() -> list:
    """Create a set of test tasks with various dependency patterns"""
    tasks = [
        AgentTask(
            task_id="task_1",
            task_type="research",
            prompt="Research async programming patterns in Python",
            dependencies=[],
        ),
        AgentTask(
            task_id="task_2", 
            task_type="analysis",
            prompt="Analyze the research findings",
            dependencies=["task_1"],
        ),
        AgentTask(
            task_id="task_3",
            task_type="research", 
            prompt="Research testing frameworks",
            dependencies=[],
        ),
        AgentTask(
            task_id="task_4",
            task_type="design",
            prompt="Design a testing strategy",
            dependencies=["task_2", "task_3"],
        ),
        AgentTask(
            task_id="task_5",
            task_type="implementation",
            prompt="Implement the solution",
            dependencies=["task_4"],
        ),
    ]
    return tasks


async def test_debug_logging():
    """Test the debug logging implementation"""
    
    print("🔬 Testing Debug Logging Implementation")
    print("=" * 50)
    
    # Create temporary directory for test
    with tempfile.TemporaryDirectory(prefix="debug_orchestrator_test_") as temp_dir:
        test_dir = Path(temp_dir)
        
        print(f"📁 Test directory: {test_dir}")
        
        # Test 1: Basic initialization
        print("\\n📋 Test 1: Orchestrator Initialization")
        try:
            orchestrator = create_debug_orchestrator(
                output_dir=test_dir,
                max_parallel=2,
                tokens=["test_token_1", "test_token_2", "test_token_3"],  # Use fake tokens for testing
                enable_debug_logging=True
            )
            print("✅ Orchestrator initialized successfully")
            
            # Check if log directories were created
            logs_dir = test_dir / "logs"
            if logs_dir.exists():
                print("✅ Logs directory created")
                log_files = list(logs_dir.glob("*.log*"))
                print(f"📄 Log files created: {len(log_files)}")
                for log_file in log_files:
                    print(f"   - {log_file.name} ({log_file.stat().st_size} bytes)")
            else:
                print("❌ Logs directory not found")
                
        except Exception as e:
            print(f"❌ Initialization failed: {e}")
            return False
        
        # Test 2: Token pool logging
        print("\\n🎫 Test 2: Token Pool Operations")
        try:
            # Test token acquisition and release
            token, token_idx = await orchestrator.token_pool.acquire()
            print(f"✅ Token acquired: idx={token_idx}")
            
            # Get token stats
            stats = orchestrator.token_pool.get_stats()
            print(f"📊 Token stats: {stats['currently_in_use']} in use, {stats['currently_available']} available")
            
            # Release token
            orchestrator.token_pool.release(token_idx)
            print("✅ Token released")
            
        except Exception as e:
            print(f"❌ Token pool test failed: {e}")
            return False
        
        # Test 3: Dependency manager logging
        print("\\n🔗 Test 3: Dependency Manager Operations")
        try:
            tasks = create_test_tasks()
            
            # Test can_run checks
            task1 = tasks[0]  # No dependencies
            task2 = tasks[1]  # Depends on task1
            
            can_run_1 = await orchestrator.dep_manager.can_run(task1)
            print(f"✅ Task 1 can run: {can_run_1}")
            
            can_run_2 = await orchestrator.dep_manager.can_run(task2)
            print(f"✅ Task 2 can run (should be False): {can_run_2}")
            
            # Mark task1 as completed
            await orchestrator.dep_manager.mark_running(task1.task_id)
            await orchestrator.dep_manager.mark_completed(task1.task_id)
            print("✅ Task 1 marked as completed")
            
            # Now task2 should be runnable
            can_run_2_after = await orchestrator.dep_manager.can_run(task2)
            print(f"✅ Task 2 can run after task 1 completion: {can_run_2_after}")
            
        except Exception as e:
            print(f"❌ Dependency manager test failed: {e}")
            return False
        
        # Test 4: Check log contents
        print("\\n📝 Test 4: Log Content Validation")
        try:
            logs_dir = test_dir / "logs"
            
            # Check for values logs
            values_logs = list(logs_dir.glob("values_*.jsonl"))
            if values_logs:
                print(f"✅ Found {len(values_logs)} values log files")
                
                # Read and validate some entries
                with open(values_logs[0], 'r') as f:
                    lines = f.readlines()
                    print(f"📊 Values log has {len(lines)} entries")
                    
                    if lines:
                        import json
                        try:
                            first_entry = json.loads(lines[0])
                            print(f"✅ First entry structure valid: {first_entry.get('context', 'unknown')}")
                        except json.JSONDecodeError:
                            print("❌ First entry is not valid JSON")
            else:
                print("❌ No values log files found")
            
            # Check for performance logs
            perf_logs = list(logs_dir.glob("performance_*.log"))
            if perf_logs:
                print(f"✅ Found {len(perf_logs)} performance log files")
            else:
                print("⚠️  No performance log files found (may be normal for basic operations)")
            
        except Exception as e:
            print(f"❌ Log content validation failed: {e}")
            return False
        
        # Test 5: Log analysis
        print("\\n📊 Test 5: Log Analysis")
        try:
            analyzer = LogAnalyzer(logs_dir)
            log_summary = analyzer.get_log_summary()
            print(f"✅ Log analyzer initialized successfully")
            print(f"📋 Found {log_summary['values_logs']} values logs, {log_summary['debug_logs']} debug logs")
            
            # Test token usage analysis
            token_analysis = analyzer.analyze_token_usage()
            print(f"📈 Token analysis: {token_analysis.get('total_acquisitions', 0)} acquisitions")
            
            # Test dependency analysis
            dep_analysis = analyzer.analyze_dependency_flow()
            print(f"🔗 Dependency analysis: {dep_analysis.get('total_can_run_checks', 0)} can_run checks")
            
        except Exception as e:
            print(f"❌ Log analysis test failed: {e}")
            return False
        
        print("\\n🎉 All tests passed! Debug logging implementation is working correctly.")
        print(f"\\n📁 Test logs are available at: {test_dir}")
        print("\\nYou can now use the DebugGenericOrchestrator for comprehensive orchestration logging.")
        
        return True


def demonstrate_usage():
    """Demonstrate how to use the debug orchestrator in practice"""
    print("\\n" + "="*60)
    print("USAGE EXAMPLE")
    print("="*60)
    
    example_code = '''
# Import the debug orchestrator
from src.debug_generic_orchestrator import create_debug_orchestrator, AgentTask

# Create orchestrator with debug logging enabled
orchestrator = create_debug_orchestrator(
    output_dir=Path("./debug_orchestration"),
    max_parallel=5,
    tokens=your_token_list,  # Your actual tokens
    enable_debug_logging=True
)

# Define your tasks
def create_tasks():
    return [
        AgentTask(
            task_id="research_task",
            task_type="research", 
            prompt="Research the topic",
            dependencies=[]
        ),
        # ... more tasks
    ]

# Run orchestration with full logging
results = await orchestrator.run(create_tasks)

# Analyze the logs
from src.log_analyzer import LogAnalyzer
analyzer = LogAnalyzer(Path("./debug_orchestration/logs"))
analyzer.print_summary()

# Generate detailed report
report = analyzer.generate_comprehensive_report(
    Path("./analysis_report.json")
)
'''
    
    print(example_code)
    print("\\nThis will generate comprehensive logs including:")
    print("  • Token acquisition/release patterns")
    print("  • Dependency resolution flow")
    print("  • Task execution timelines") 
    print("  • Performance bottlenecks")
    print("  • Error analysis and debugging info")


async def main():
    """Main test function"""
    success = await test_debug_logging()
    
    if success:
        demonstrate_usage()
    else:
        print("\\n❌ Tests failed. Please check the implementation.")


if __name__ == "__main__":
    # Note: This is a test that can't actually run Claude agents since we don't have real tokens
    # It tests the logging infrastructure itself
    print("⚠️  Note: This test validates the logging infrastructure only.")
    print("   Real agent execution requires valid Claude tokens.")
    
    asyncio.run(main())