"""
Performance Tests and Benchmarks for the Message Bus System.

Tests message throughput, latency, and scalability under various load conditions.
Provides comprehensive benchmarking to ensure 1000+ msgs/second with sub-100ms delivery.
"""

import asyncio
import logging
import time
import statistics
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import uuid

from ..core.message_bus import MessageBus
from ..core.message_types import Message, MessageType, MessagePriority
from ..client.agent_client import AgentMessageClient, AgentClientConfig
from ..gateway.websocket_gateway import WebSocketGateway

logger = logging.getLogger(__name__)


@dataclass
class PerformanceTestResult:
    """Results from a performance test"""
    test_name: str
    duration_seconds: float
    total_messages: int
    messages_per_second: float
    avg_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    error_count: int
    error_rate: float
    success_rate: float
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "test_name": self.test_name,
            "duration_seconds": self.duration_seconds,
            "total_messages": self.total_messages,
            "messages_per_second": self.messages_per_second,
            "avg_latency_ms": self.avg_latency_ms,
            "p95_latency_ms": self.p95_latency_ms,
            "p99_latency_ms": self.p99_latency_ms,
            "error_count": self.error_count,
            "error_rate": self.error_rate,
            "success_rate": self.success_rate,
            "memory_usage_mb": self.memory_usage_mb,
            "cpu_usage_percent": self.cpu_usage_percent,
        }


class MessageBusPerformanceTester:
    """Performance testing framework for the message bus"""
    
    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        websocket_port: int = 8767,
    ):
        self.redis_url = redis_url
        self.websocket_port = websocket_port
        
        # Test infrastructure
        self.message_bus: Optional[MessageBus] = None
        self.websocket_gateway: Optional[WebSocketGateway] = None
        self.test_clients: List[AgentMessageClient] = []
        
        # Test tracking
        self.sent_messages: Dict[str, float] = {}  # message_id -> timestamp
        self.received_messages: Dict[str, float] = {}  # message_id -> timestamp
        self.test_results: List[PerformanceTestResult] = []
        
        logger.info("MessageBusPerformanceTester initialized")
    
    async def setup_test_infrastructure(self) -> None:
        """Setup message bus and gateway for testing"""
        try:
            # Initialize message bus
            self.message_bus = MessageBus(
                redis_url=self.redis_url,
                max_connections=50,  # Higher for performance testing
                enable_compression=True,
                compression_threshold=512,
            )
            
            await self.message_bus.start()
            
            # Initialize WebSocket gateway
            self.websocket_gateway = WebSocketGateway(
                message_bus=self.message_bus,
                port=self.websocket_port,
                max_connections=200,  # Higher for performance testing
            )
            
            await self.websocket_gateway.start()
            
            logger.info("Test infrastructure setup complete")
            
        except Exception as e:
            logger.error("Failed to setup test infrastructure: %s", e)
            raise
    
    async def teardown_test_infrastructure(self) -> None:
        """Cleanup test infrastructure"""
        try:
            # Disconnect all test clients
            for client in self.test_clients:
                if client.is_connected:
                    await client.disconnect()
            
            self.test_clients.clear()
            
            # Stop gateway and message bus
            if self.websocket_gateway:
                await self.websocket_gateway.stop()
            
            if self.message_bus:
                await self.message_bus.stop()
            
            logger.info("Test infrastructure teardown complete")
            
        except Exception as e:
            logger.error("Error during test infrastructure teardown: %s", e)
    
    async def create_test_client(self, agent_id: str) -> AgentMessageClient:
        """Create and connect a test client"""
        config = AgentClientConfig(
            agent_id=agent_id,
            websocket_url=f"ws://localhost:{self.websocket_port}",
            auto_reconnect=False,  # Disable for testing
            capabilities=["test_agent"],
        )
        
        client = AgentMessageClient(config)
        
        # Register message handler to track received messages
        def handle_message(message: Message):
            self.received_messages[message.message_id] = time.time()
        
        client.register_default_handler(handle_message)
        
        # Connect client
        success = await client.connect()
        if not success:
            raise Exception(f"Failed to connect test client {agent_id}")
        
        self.test_clients.append(client)
        return client
    
    async def run_throughput_test(
        self, 
        num_clients: int = 10,
        messages_per_client: int = 100,
        test_duration_seconds: int = 60
    ) -> PerformanceTestResult:
        """Test message throughput under high load"""
        test_name = f"throughput_test_{num_clients}clients_{messages_per_client}msgs"
        logger.info("Starting %s", test_name)
        
        start_time = time.time()
        
        # Create test clients
        clients = []
        for i in range(num_clients):
            client = await self.create_test_client(f"test_agent_{i}")
            clients.append(client)
        
        # Clear tracking data
        self.sent_messages.clear()
        self.received_messages.clear()
        
        # Send messages from all clients concurrently
        async def send_messages_from_client(client: AgentMessageClient, msg_count: int):
            error_count = 0
            for j in range(msg_count):
                try:
                    message_id = await client.send_point_to_point(
                        recipient_id="test_agent_0",  # Send to first client
                        payload={"test_data": f"message_{j}", "timestamp": time.time()},
                        priority=MessagePriority.NORMAL,
                    )
                    if message_id:
                        self.sent_messages[message_id] = time.time()
                    else:
                        error_count += 1
                        
                    # Small delay to avoid overwhelming
                    await asyncio.sleep(0.001)
                    
                except Exception as e:
                    logger.error("Error sending message: %s", e)
                    error_count += 1
            
            return error_count
        
        # Execute concurrent message sending
        tasks = [
            send_messages_from_client(client, messages_per_client)
            for client in clients
        ]
        
        error_counts = await asyncio.gather(*tasks)
        total_errors = sum(error_counts)
        
        # Wait for messages to be processed
        await asyncio.sleep(2)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Calculate metrics
        total_sent = len(self.sent_messages)
        total_received = len(self.received_messages)
        
        # Calculate latencies for received messages
        latencies = []
        for msg_id, received_time in self.received_messages.items():
            if msg_id in self.sent_messages:
                latency_ms = (received_time - self.sent_messages[msg_id]) * 1000
                latencies.append(latency_ms)
        
        # Calculate statistics
        avg_latency = statistics.mean(latencies) if latencies else 0
        p95_latency = statistics.quantiles(latencies, n=20)[18] if latencies else 0  # 95th percentile
        p99_latency = statistics.quantiles(latencies, n=100)[98] if latencies else 0  # 99th percentile
        
        result = PerformanceTestResult(
            test_name=test_name,
            duration_seconds=duration,
            total_messages=total_sent,
            messages_per_second=total_sent / duration,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            p99_latency_ms=p99_latency,
            error_count=total_errors,
            error_rate=(total_errors / max(1, total_sent + total_errors)) * 100,
            success_rate=(total_received / max(1, total_sent)) * 100,
        )
        
        self.test_results.append(result)
        logger.info("Completed %s: %.2f msg/s, %.2f ms avg latency", 
                   test_name, result.messages_per_second, result.avg_latency_ms)
        
        return result
    
    async def run_latency_test(
        self,
        num_messages: int = 1000,
        interval_ms: int = 10
    ) -> PerformanceTestResult:
        """Test message delivery latency"""
        test_name = f"latency_test_{num_messages}msgs_{interval_ms}ms"
        logger.info("Starting %s", test_name)
        
        start_time = time.time()
        
        # Create two clients for round-trip testing
        sender = await self.create_test_client("latency_sender")
        receiver = await self.create_test_client("latency_receiver")
        
        # Clear tracking data
        self.sent_messages.clear()
        self.received_messages.clear()
        
        error_count = 0
        
        # Send messages with specified interval
        for i in range(num_messages):
            try:
                message_id = await sender.send_point_to_point(
                    recipient_id="latency_receiver",
                    payload={
                        "test_data": f"latency_test_{i}",
                        "sequence": i,
                        "timestamp": time.time(),
                    }
                )
                
                if message_id:
                    self.sent_messages[message_id] = time.time()
                else:
                    error_count += 1
                
                await asyncio.sleep(interval_ms / 1000.0)
                
            except Exception as e:
                logger.error("Error in latency test: %s", e)
                error_count += 1
        
        # Wait for all messages to be processed
        await asyncio.sleep(5)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Calculate latency metrics
        latencies = []
        for msg_id, received_time in self.received_messages.items():
            if msg_id in self.sent_messages:
                latency_ms = (received_time - self.sent_messages[msg_id]) * 1000
                latencies.append(latency_ms)
        
        avg_latency = statistics.mean(latencies) if latencies else 0
        p95_latency = statistics.quantiles(latencies, n=20)[18] if latencies else 0
        p99_latency = statistics.quantiles(latencies, n=100)[98] if latencies else 0
        
        result = PerformanceTestResult(
            test_name=test_name,
            duration_seconds=duration,
            total_messages=len(self.sent_messages),
            messages_per_second=len(self.sent_messages) / duration,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            p99_latency_ms=p99_latency,
            error_count=error_count,
            error_rate=(error_count / max(1, len(self.sent_messages) + error_count)) * 100,
            success_rate=(len(self.received_messages) / max(1, len(self.sent_messages))) * 100,
        )
        
        self.test_results.append(result)
        logger.info("Completed %s: %.2f ms avg latency, %.2f msg/s", 
                   test_name, result.avg_latency_ms, result.messages_per_second)
        
        return result
    
    async def run_scalability_test(
        self,
        max_clients: int = 100,
        step_size: int = 10,
        messages_per_step: int = 50
    ) -> List[PerformanceTestResult]:
        """Test system scalability with increasing client count"""
        test_name = "scalability_test"
        logger.info("Starting %s up to %d clients", test_name, max_clients)
        
        results = []
        
        for num_clients in range(step_size, max_clients + 1, step_size):
            try:
                # Clear previous clients
                for client in self.test_clients:
                    if client.is_connected:
                        await client.disconnect()
                self.test_clients.clear()
                
                # Run throughput test with current client count
                result = await self.run_throughput_test(
                    num_clients=num_clients,
                    messages_per_client=messages_per_step,
                    test_duration_seconds=30
                )
                
                result.test_name = f"scalability_{num_clients}clients"
                results.append(result)
                
                logger.info("Scalability test with %d clients: %.2f msg/s", 
                           num_clients, result.messages_per_second)
                
                # Break if performance degrades significantly
                if result.success_rate < 90 or result.avg_latency_ms > 1000:
                    logger.warning("Performance degraded at %d clients, stopping test", num_clients)
                    break
                    
            except Exception as e:
                logger.error("Error in scalability test at %d clients: %s", num_clients, e)
                break
        
        return results
    
    async def run_stress_test(
        self,
        duration_seconds: int = 300,
        target_rate: int = 1000
    ) -> PerformanceTestResult:
        """Stress test the system at target message rate"""
        test_name = f"stress_test_{target_rate}msg_s_{duration_seconds}s"
        logger.info("Starting %s", test_name)
        
        start_time = time.time()
        
        # Calculate optimal client count
        num_clients = max(10, target_rate // 100)  # ~100 msg/s per client
        messages_per_second_per_client = target_rate / num_clients
        interval_between_messages = 1.0 / messages_per_second_per_client
        
        # Create clients
        clients = []
        for i in range(num_clients):
            client = await self.create_test_client(f"stress_agent_{i}")
            clients.append(client)
        
        # Clear tracking data
        self.sent_messages.clear()
        self.received_messages.clear()
        
        # Stress test function
        async def stress_client(client: AgentMessageClient, duration: float):
            end_time = time.time() + duration
            error_count = 0
            message_count = 0
            
            while time.time() < end_time:
                try:
                    message_id = await client.broadcast(
                        payload={
                            "stress_test": True,
                            "message_num": message_count,
                            "timestamp": time.time(),
                        }
                    )
                    
                    if message_id:
                        self.sent_messages[message_id] = time.time()
                        message_count += 1
                    else:
                        error_count += 1
                    
                    await asyncio.sleep(interval_between_messages)
                    
                except Exception as e:
                    error_count += 1
                    if message_count % 100 == 0:  # Log every 100 errors
                        logger.error("Stress test error: %s", e)
            
            return error_count
        
        # Run stress test
        tasks = [stress_client(client, duration_seconds) for client in clients]
        error_counts = await asyncio.gather(*tasks)
        
        # Wait for message processing
        await asyncio.sleep(10)
        
        end_time = time.time()
        actual_duration = end_time - start_time
        
        total_errors = sum(error_counts)
        total_sent = len(self.sent_messages)
        total_received = len(self.received_messages)
        
        # Calculate latencies
        latencies = []
        for msg_id, received_time in self.received_messages.items():
            if msg_id in self.sent_messages:
                latency_ms = (received_time - self.sent_messages[msg_id]) * 1000
                latencies.append(latency_ms)
        
        avg_latency = statistics.mean(latencies) if latencies else 0
        p95_latency = statistics.quantiles(latencies, n=20)[18] if latencies else 0
        p99_latency = statistics.quantiles(latencies, n=100)[98] if latencies else 0
        
        result = PerformanceTestResult(
            test_name=test_name,
            duration_seconds=actual_duration,
            total_messages=total_sent,
            messages_per_second=total_sent / actual_duration,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            p99_latency_ms=p99_latency,
            error_count=total_errors,
            error_rate=(total_errors / max(1, total_sent + total_errors)) * 100,
            success_rate=(total_received / max(1, total_sent)) * 100,
        )
        
        self.test_results.append(result)
        logger.info("Completed %s: %.2f msg/s target vs %.2f actual", 
                   test_name, target_rate, result.messages_per_second)
        
        return result
    
    async def run_reliability_test(
        self,
        duration_seconds: int = 180,
        failure_injection: bool = True
    ) -> PerformanceTestResult:
        """Test system reliability and recovery"""
        test_name = f"reliability_test_{duration_seconds}s"
        logger.info("Starting %s", test_name)
        
        start_time = time.time()
        
        # Create clients
        num_clients = 20
        clients = []
        for i in range(num_clients):
            client = await self.create_test_client(f"reliability_agent_{i}")
            clients.append(client)
        
        # Clear tracking data
        self.sent_messages.clear()
        self.received_messages.clear()
        
        error_count = 0
        
        # Reliability test with potential failures
        async def reliability_client(client: AgentMessageClient, duration: float):
            end_time = time.time() + duration
            local_errors = 0
            msg_count = 0
            
            while time.time() < end_time:
                try:
                    # Send message to random recipient
                    recipient = f"reliability_agent_{(msg_count + 1) % num_clients}"
                    
                    message_id = await client.send_point_to_point(
                        recipient_id=recipient,
                        payload={
                            "reliability_test": True,
                            "sender": client.config.agent_id,
                            "sequence": msg_count,
                            "timestamp": time.time(),
                        }
                    )
                    
                    if message_id:
                        self.sent_messages[message_id] = time.time()
                    else:
                        local_errors += 1
                    
                    msg_count += 1
                    await asyncio.sleep(0.1)  # 10 msg/s per client
                    
                except Exception as e:
                    local_errors += 1
            
            return local_errors
        
        # Run reliability test
        tasks = [reliability_client(client, duration_seconds) for client in clients]
        error_counts = await asyncio.gather(*tasks)
        
        # Wait for processing
        await asyncio.sleep(5)
        
        end_time = time.time()
        actual_duration = end_time - start_time
        
        total_errors = sum(error_counts)
        total_sent = len(self.sent_messages)
        total_received = len(self.received_messages)
        
        # Calculate metrics
        latencies = []
        for msg_id, received_time in self.received_messages.items():
            if msg_id in self.sent_messages:
                latency_ms = (received_time - self.sent_messages[msg_id]) * 1000
                latencies.append(latency_ms)
        
        avg_latency = statistics.mean(latencies) if latencies else 0
        p95_latency = statistics.quantiles(latencies, n=20)[18] if latencies else 0
        p99_latency = statistics.quantiles(latencies, n=100)[98] if latencies else 0
        
        result = PerformanceTestResult(
            test_name=test_name,
            duration_seconds=actual_duration,
            total_messages=total_sent,
            messages_per_second=total_sent / actual_duration,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            p99_latency_ms=p99_latency,
            error_count=total_errors,
            error_rate=(total_errors / max(1, total_sent + total_errors)) * 100,
            success_rate=(total_received / max(1, total_sent)) * 100,
        )
        
        self.test_results.append(result)
        logger.info("Completed %s: %.2f%% success rate, %.2f ms avg latency", 
                   test_name, result.success_rate, result.avg_latency_ms)
        
        return result
    
    async def run_full_test_suite(self) -> Dict[str, Any]:
        """Run the complete performance test suite"""
        logger.info("Starting full performance test suite")
        
        suite_start = time.time()
        
        try:
            await self.setup_test_infrastructure()
            
            # Run all tests
            test_results = {}
            
            # 1. Throughput test
            logger.info("=== Running Throughput Test ===")
            throughput_result = await self.run_throughput_test(
                num_clients=20, 
                messages_per_client=100
            )
            test_results["throughput"] = throughput_result.to_dict()
            
            # 2. Latency test
            logger.info("=== Running Latency Test ===")
            latency_result = await self.run_latency_test(
                num_messages=1000,
                interval_ms=10
            )
            test_results["latency"] = latency_result.to_dict()
            
            # 3. Scalability test
            logger.info("=== Running Scalability Test ===")
            scalability_results = await self.run_scalability_test(
                max_clients=50,
                step_size=10,
                messages_per_step=50
            )
            test_results["scalability"] = [r.to_dict() for r in scalability_results]
            
            # 4. Stress test
            logger.info("=== Running Stress Test ===")
            stress_result = await self.run_stress_test(
                duration_seconds=120,
                target_rate=800  # Target 800 msg/s
            )
            test_results["stress"] = stress_result.to_dict()
            
            # 5. Reliability test
            logger.info("=== Running Reliability Test ===")
            reliability_result = await self.run_reliability_test(
                duration_seconds=120
            )
            test_results["reliability"] = reliability_result.to_dict()
            
            suite_end = time.time()
            suite_duration = suite_end - suite_start
            
            # Summary report
            summary = {
                "suite_duration_seconds": suite_duration,
                "total_tests_run": len(test_results),
                "test_results": test_results,
                "performance_summary": {
                    "max_throughput_msg_s": throughput_result.messages_per_second,
                    "avg_latency_ms": latency_result.avg_latency_ms,
                    "stress_test_success_rate": stress_result.success_rate,
                    "reliability_success_rate": reliability_result.success_rate,
                    "meets_requirements": {
                        "throughput_1000_msg_s": throughput_result.messages_per_second >= 1000,
                        "latency_under_100ms": latency_result.avg_latency_ms <= 100,
                        "reliability_99_percent": reliability_result.success_rate >= 99.0,
                    }
                }
            }
            
            logger.info("=== Performance Test Suite Complete ===")
            logger.info("Max throughput: %.2f msg/s", throughput_result.messages_per_second)
            logger.info("Average latency: %.2f ms", latency_result.avg_latency_ms)
            logger.info("Stress test success rate: %.2f%%", stress_result.success_rate)
            logger.info("Reliability success rate: %.2f%%", reliability_result.success_rate)
            
            return summary
            
        except Exception as e:
            logger.error("Error in performance test suite: %s", e)
            raise
        finally:
            await self.teardown_test_infrastructure()
    
    def save_results(self, filename: str) -> None:
        """Save test results to file"""
        try:
            results_data = {
                "timestamp": time.time(),
                "test_count": len(self.test_results),
                "results": [result.to_dict() for result in self.test_results]
            }
            
            with open(filename, 'w') as f:
                json.dump(results_data, f, indent=2)
            
            logger.info("Test results saved to %s", filename)
            
        except Exception as e:
            logger.error("Error saving results: %s", e)


# Utility function for running tests
async def run_performance_tests():
    """Run the complete performance test suite"""
    tester = MessageBusPerformanceTester()
    
    try:
        results = await tester.run_full_test_suite()
        
        # Save results
        timestamp = int(time.time())
        tester.save_results(f"message_bus_performance_results_{timestamp}.json")
        
        return results
        
    except Exception as e:
        logger.error("Performance test failed: %s", e)
        raise


if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run performance tests
    asyncio.run(run_performance_tests())