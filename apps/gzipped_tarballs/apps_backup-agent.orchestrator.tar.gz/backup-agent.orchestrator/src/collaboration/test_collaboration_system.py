#!/usr/bin/env python3
"""
Integration tests for the Collaborative Workspace System

Tests the complete collaboration workflow including workspace creation,
file operations, real-time sync, and multi-agent collaboration.
"""

import asyncio
import tempfile
import shutil
from pathlib import Path

from .workspace_sdk import WorkspaceSDK, CollaborationConfig
from .sync_engine import SyncEngine
from .change_tracker import ChangeTracker


async def test_basic_collaboration():
    """Test basic two-agent collaboration workflow"""
    
    print("🧪 Testing basic collaboration...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        base_path = Path(temp_dir)
        
        # Create two agents
        agent1 = WorkspaceSDK("test_agent_1", base_path / "agent1")
        agent2 = WorkspaceSDK("test_agent_2", base_path / "agent2") 
        
        try:
            # Agent 1 creates workspace
            workspace_id = await agent1.create_workspace(
                "Test Collaboration",
                "project",
                "Testing collaboration system"
            )
            assert workspace_id, "Workspace creation failed"
            print("✅ Workspace created successfully")
            
            # Agent 1 joins workspace
            joined = await agent1.join_workspace(workspace_id)
            assert joined, "Agent 1 failed to join workspace"
            print("✅ Agent 1 joined workspace")
            
            # Agent 1 creates files
            success = await agent1.write_file(
                "test_file.txt",
                "Hello from Agent 1!",
                "Initial file"
            )
            assert success, "File creation failed"
            print("✅ Agent 1 created file")
            
            # Share workspace with Agent 2
            shared = await agent1.workspace_manager.share_workspace(
                workspace_id, "test_agent_1", "test_agent_2", "editor"
            )
            assert shared, "Workspace sharing failed"
            print("✅ Workspace shared with Agent 2")
            
            # Agent 2 joins workspace
            joined = await agent2.join_workspace(workspace_id)
            assert joined, "Agent 2 failed to join workspace"
            print("✅ Agent 2 joined workspace")
            
            # Agent 2 reads file
            content = await agent2.read_file("test_file.txt")
            assert content == "Hello from Agent 1!", f"Content mismatch: {content}"
            print("✅ Agent 2 read file successfully")
            
            # Agent 2 modifies file
            success = await agent2.write_file(
                "test_file.txt",
                "Hello from Agent 1!\nHello from Agent 2!",
                "Agent 2 addition"
            )
            assert success, "Agent 2 file modification failed"
            print("✅ Agent 2 modified file")
            
            # Agent 1 reads updated file
            updated_content = await agent1.read_file("test_file.txt")
            expected = "Hello from Agent 1!\nHello from Agent 2!"
            assert updated_content == expected, f"Updated content mismatch: {updated_content}"
            print("✅ Agent 1 read updated file")
            
            # Test file listing
            files = await agent1.list_files()
            assert len(files) > 0, "No files found"
            test_file = next((f for f in files if f["name"] == "test_file.txt"), None)
            assert test_file, "test_file.txt not found in listing"
            assert test_file["size"] > 0, "File has no size"
            print("✅ File listing works correctly")
            
            # Test collaborators
            collaborators = await agent1.get_collaborators()
            assert len(collaborators) == 2, f"Expected 2 collaborators, got {len(collaborators)}"
            agent_ids = [c["agent_id"] for c in collaborators]
            assert "test_agent_1" in agent_ids, "Agent 1 not in collaborators"
            assert "test_agent_2" in agent_ids, "Agent 2 not in collaborators"
            print("✅ Collaborators list correct")
            
            # Test version control
            commit_id = await agent1.commit_changes("Test collaboration commit")
            assert commit_id, "Commit failed"
            print("✅ Version control commit works")
            
            # Test change history
            history = await agent1.get_change_history(limit=5)
            assert len(history) > 0, "No change history found"
            assert history[0]["agent_id"] == "test_agent_1", "Wrong agent in history"
            print("✅ Change history tracking works")
            
            # Test workspace stats
            stats = await agent1.get_workspace_stats()
            assert stats["workspace_id"] == workspace_id, "Wrong workspace ID in stats"
            assert stats["total_collaborators"] == 2, "Wrong collaborator count in stats"
            assert stats["total_files"] > 0, "No files in stats"
            print("✅ Workspace statistics correct")
            
        finally:
            await agent1.cleanup()
            await agent2.cleanup()
    
    print("✅ Basic collaboration test passed!")


async def test_conflict_detection():
    """Test conflict detection and resolution"""
    
    print("🧪 Testing conflict detection...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        base_path = Path(temp_dir)
        
        agent1 = WorkspaceSDK("conflict_agent_1", base_path / "agent1")
        agent2 = WorkspaceSDK("conflict_agent_2", base_path / "agent2")
        
        try:
            # Setup workspace
            workspace_id = await agent1.create_workspace("Conflict Test", "project")
            await agent1.join_workspace(workspace_id)
            await agent2.join_workspace(workspace_id)
            await agent1.workspace_manager.share_workspace(
                workspace_id, "conflict_agent_1", "conflict_agent_2", "editor"
            )
            
            # Initial file
            initial_content = "Line 1\nLine 2\nLine 3"
            await agent1.write_file("conflict_file.txt", initial_content, "Initial")
            
            # Both agents read the file to get version info
            content1, version1 = await agent1.current_filesystem.read_file("conflict_file.txt", "conflict_agent_1")
            content2, version2 = await agent2.current_filesystem.read_file("conflict_file.txt", "conflict_agent_2")
            
            assert version1 == version2, "Versions should be the same initially"
            print("✅ Both agents have same initial version")
            
            # Agent 1 modifies first
            modified1 = content1.replace("Line 2", "Line 2 - Modified by Agent 1")
            success1, _ = await agent1.current_filesystem.write_file(
                "conflict_file.txt", modified1, "conflict_agent_1", version1, "Agent 1 changes"
            )
            assert success1, "Agent 1 modification should succeed"
            print("✅ Agent 1 modified file successfully")
            
            # Agent 2 tries to modify with old version (should cause conflict)
            modified2 = content2.replace("Line 2", "Line 2 - Modified by Agent 2")
            success2, error2 = await agent2.current_filesystem.write_file(
                "conflict_file.txt", modified2, "conflict_agent_2", version2, "Agent 2 changes"
            )
            assert not success2, "Agent 2 modification should fail due to conflict"
            assert "Version conflict" in error2, f"Expected version conflict error, got: {error2}"
            print("✅ Conflict detected correctly")
            
            # Check file info shows conflict
            file_info = await agent1.get_file_info("conflict_file.txt")
            assert file_info["has_conflicts"], "File should be marked as having conflicts"
            print("✅ File marked as conflicted")
            
            # Resolve conflict
            resolved_content = "Line 1\nLine 2 - Merged by both agents\nLine 3"
            resolved = await agent1.current_filesystem.resolve_conflict(
                "conflict_file.txt", "conflict_agent_1", "manual", resolved_content
            )
            assert resolved, "Conflict resolution failed"
            print("✅ Conflict resolved successfully")
            
            # Verify conflict is resolved
            file_info_after = await agent1.get_file_info("conflict_file.txt")
            assert not file_info_after["has_conflicts"], "Conflict should be resolved"
            print("✅ Conflict resolution verified")
            
        finally:
            await agent1.cleanup()
            await agent2.cleanup()
    
    print("✅ Conflict detection test passed!")


async def test_real_time_sync():
    """Test real-time synchronization"""
    
    print("🧪 Testing real-time synchronization...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        base_path = Path(temp_dir)
        
        # Setup sync server
        change_tracker = ChangeTracker(base_path / "tracking")
        sync_engine = SyncEngine(host="localhost", port=8766, change_tracker=change_tracker)
        
        try:
            # Start sync server
            await sync_engine.start_server()
            print("✅ Sync server started")
            
            # Create agents with sync
            config = CollaborationConfig(
                enable_real_time_sync=True,
                sync_server_port=8766
            )
            
            agent1 = WorkspaceSDK("sync_agent_1", base_path / "agent1", config)
            agent2 = WorkspaceSDK("sync_agent_2", base_path / "agent2", config)
            
            # Connect to sync server
            connected1 = await agent1.connect_to_sync_server()
            connected2 = await agent2.connect_to_sync_server()
            assert connected1 and connected2, "Failed to connect to sync server"
            print("✅ Agents connected to sync server")
            
            # Setup event tracking
            events_received = []
            
            def track_events(event):
                events_received.append(event)
            
            agent1.on_event("file_changed", track_events)
            agent2.on_event("file_changed", track_events)
            
            # Create and join workspace
            workspace_id = await agent1.create_workspace("Sync Test", "project")
            await agent1.join_workspace(workspace_id)
            await agent2.join_workspace(workspace_id)
            await agent1.workspace_manager.share_workspace(
                workspace_id, "sync_agent_1", "sync_agent_2", "editor"
            )
            
            # Agent 1 creates file (should trigger sync event)
            await agent1.write_file("sync_test.txt", "Sync test content", "Initial")
            
            # Wait for sync
            await asyncio.sleep(0.5)
            
            # Check that Agent 2 received the sync event
            assert len(events_received) > 0, "No sync events received"
            file_changed_events = [e for e in events_received if e.get("event_type") == "file_changed"]
            assert len(file_changed_events) > 0, "No file_changed events received"
            print("✅ Real-time sync events working")
            
            # Verify Agent 2 can read the file
            content = await agent2.read_file("sync_test.txt")
            assert content == "Sync test content", f"Content not synced: {content}"
            print("✅ File content synchronized")
            
            # Test connected agents
            connected_agents = await sync_engine.get_connected_agents(workspace_id)
            assert len(connected_agents) == 2, f"Expected 2 connected agents, got {len(connected_agents)}"
            agent_ids = [a["agent_id"] for a in connected_agents]
            assert "sync_agent_1" in agent_ids, "Agent 1 not in connected agents"
            assert "sync_agent_2" in agent_ids, "Agent 2 not in connected agents"
            print("✅ Connected agents tracking works")
            
            # Test workspace activity
            activity = await sync_engine.get_workspace_activity(workspace_id)
            assert activity["workspace_id"] == workspace_id, "Wrong workspace in activity"
            assert activity["active_agents"] == 2, f"Expected 2 active agents, got {activity['active_agents']}"
            print("✅ Workspace activity tracking works")
            
        finally:
            await agent1.cleanup()
            await agent2.cleanup()
            await sync_engine.stop_server()
    
    print("✅ Real-time sync test passed!")


async def test_messaging():
    """Test inter-agent messaging"""
    
    print("🧪 Testing inter-agent messaging...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        base_path = Path(temp_dir)
        
        agent1 = WorkspaceSDK("msg_agent_1", base_path / "agent1")
        agent2 = WorkspaceSDK("msg_agent_2", base_path / "agent2")
        
        try:
            # Setup workspace
            workspace_id = await agent1.create_workspace("Messaging Test", "project")
            await agent1.join_workspace(workspace_id)
            await agent2.join_workspace(workspace_id)
            await agent1.workspace_manager.share_workspace(
                workspace_id, "msg_agent_1", "msg_agent_2", "editor"
            )
            
            # Agent 1 sends message to Agent 2
            await agent1.send_message_to_collaborator(
                "msg_agent_2",
                "Hello from Agent 1! Ready to collaborate?",
                "text"
            )
            print("✅ Message sent successfully")
            
            # Agent 2 reads messages
            messages = await agent2.get_messages()
            assert len(messages) == 1, f"Expected 1 message, got {len(messages)}"
            
            message = messages[0]
            assert message["from"] == "msg_agent_1", f"Wrong sender: {message['from']}"
            assert message["to"] == "msg_agent_2", f"Wrong recipient: {message['to']}"
            assert "Hello from Agent 1" in message["content"], f"Wrong content: {message['content']}"
            assert message["type"] == "text", f"Wrong type: {message['type']}"
            assert message["workspace_id"] == workspace_id, f"Wrong workspace: {message['workspace_id']}"
            print("✅ Message received correctly")
            
            # Agent 2 sends reply
            await agent2.send_message_to_collaborator(
                "msg_agent_1",
                "Hi Agent 1! Yes, ready to work together!",
                "text"
            )
            
            # Agent 1 reads reply
            replies = await agent1.get_messages()
            assert len(replies) == 1, f"Expected 1 reply, got {len(replies)}"
            
            reply = replies[0]
            assert reply["from"] == "msg_agent_2", f"Wrong sender: {reply['from']}"
            assert "ready to work together" in reply["content"], f"Wrong content: {reply['content']}"
            print("✅ Reply received correctly")
            
        finally:
            await agent1.cleanup()
            await agent2.cleanup()
    
    print("✅ Messaging test passed!")


async def test_snapshots():
    """Test workspace snapshots"""
    
    print("🧪 Testing workspace snapshots...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        base_path = Path(temp_dir)
        
        agent = WorkspaceSDK("snapshot_agent", base_path / "agent")
        
        try:
            # Create workspace and files
            workspace_id = await agent.create_workspace("Snapshot Test", "project")
            await agent.join_workspace(workspace_id)
            
            await agent.write_file("file1.txt", "Content 1", "File 1")
            await agent.write_file("file2.txt", "Content 2", "File 2")
            await agent.commit_changes("Initial files")
            
            # Create snapshot
            snapshot_id = await agent.create_snapshot(
                "milestone_1",
                "Initial workspace state"
            )
            assert snapshot_id, "Snapshot creation failed"
            print("✅ Snapshot created successfully")
            
            # Modify files
            await agent.write_file("file1.txt", "Modified Content 1", "Modified file 1")
            await agent.write_file("file3.txt", "Content 3", "New file 3")
            await agent.commit_changes("Modified files")
            
            # Verify modifications
            content1 = await agent.read_file("file1.txt")
            content3 = await agent.read_file("file3.txt")
            assert content1 == "Modified Content 1", "File 1 not modified"
            assert content3 == "Content 3", "File 3 not created"
            print("✅ Files modified after snapshot")
            
            # Restore snapshot
            workspace_path = await agent.workspace_manager.get_workspace_path(workspace_id)
            restored = await agent.change_tracker.restore_snapshot(
                snapshot_id, workspace_path, "snapshot_agent"
            )
            assert restored, "Snapshot restoration failed"
            print("✅ Snapshot restored successfully")
            
            # Verify restoration
            restored_content1 = await agent.read_file("file1.txt")
            restored_content2 = await agent.read_file("file2.txt")
            restored_content3 = await agent.read_file("file3.txt")
            
            assert restored_content1 == "Content 1", f"File 1 not restored: {restored_content1}"
            assert restored_content2 == "Content 2", f"File 2 not restored: {restored_content2}"
            assert restored_content3 is None, "File 3 should not exist after restore"
            print("✅ Workspace restored to snapshot state")
            
        finally:
            await agent.cleanup()
    
    print("✅ Snapshots test passed!")


async def run_all_tests():
    """Run all integration tests"""
    
    print("🚀 Starting Collaborative Workspace System Integration Tests")
    print("=" * 60)
    
    tests = [
        test_basic_collaboration,
        test_conflict_detection,
        test_real_time_sync,
        test_messaging,
        test_snapshots
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            await test()
            passed += 1
            print("")
        except Exception as e:
            print(f"❌ Test {test.__name__} failed: {e}")
            failed += 1
            print("")
    
    print("=" * 60)
    print(f"📊 Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All integration tests passed!")
        return True
    else:
        print("💥 Some tests failed!")
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    exit(0 if success else 1)