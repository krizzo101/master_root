#!/usr/bin/env python3
"""
Simple integration test for enhanced mode
Tests with a very simple task that should complete quickly
"""

import asyncio
import sys
from pathlib import Path

# Add the hecaton src directory to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from hecaton.orchestration.enhanced_orchestrator import EnhancedOrchestrator, EnhancedConfig
from hecaton.resources.secure_token_pool import SecureTokenPool
from hecaton.resources.worktree import WorktreeManager

async def test_enhanced_simple():
    """Test enhanced mode with a simple task"""
    
    print("=" * 60)
    print("Testing Enhanced Mode - Simple Task")
    print("=" * 60)
    
    # Initialize resources (mock tokens for testing)
    token_pool = SecureTokenPool(tokens=["mock_token_1", "mock_token_2", "mock_token_3"])
    worktree_manager = WorktreeManager()
    
    # Create enhanced config
    config = EnhancedConfig(
        task_decomposition=True,
        checkpointing=False,  # Disable for speed
        progressive_autonomy=False,  # Disable for simplicity
        quality_gates=False,  # Disable for speed
        intelligent_delegation=False,  # Use default delegation
        error_boundaries=True,
        handoff_protocol=False,
        enable_metrics=True
    )
    
    # Create orchestrator without real executor (will use simulation)
    orchestrator = EnhancedOrchestrator(
        executor=None,  # Use simulation
        token_pool=token_pool,
        worktree_manager=worktree_manager,
        performance_monitor=None,
        config=config
    )
    
    # Test with different agent counts
    test_cases = [
        (1, "Create a hello world function"),
        (3, "Build a simple calculator"),
        (5, "Create a TODO list application")
    ]
    
    for num_agents, task in test_cases:
        print(f"\n--- Test: {num_agents} agents for '{task}' ---")
        
        try:
            # Execute the task
            result = await orchestrator.execute(task, num_agents)
            
            # Check results
            status = result.get("status")
            metrics = result.get("metrics", {})
            total_tasks = result.get("total_tasks", 0)
            successful = metrics.get("successful", 0)
            
            print(f"  Status: {status}")
            print(f"  Tasks created: {total_tasks}")
            print(f"  Successful: {successful}/{total_tasks}")
            
            if total_tasks == num_agents:
                print(f"  ✅ Created exactly {num_agents} tasks as requested")
            else:
                print(f"  ⚠️  Created {total_tasks} tasks but {num_agents} were requested")
                
            if status == "success":
                print(f"  ✅ Task completed successfully")
            else:
                print(f"  ❌ Task failed: {result.get('error', 'Unknown error')}")
                
        except Exception as e:
            print(f"  ❌ Exception: {e}")
    
    print("\n" + "=" * 60)
    print("Enhanced Mode Testing Complete")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_enhanced_simple())