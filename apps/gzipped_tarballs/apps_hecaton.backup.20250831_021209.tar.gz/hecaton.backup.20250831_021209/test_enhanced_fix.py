#!/usr/bin/env python3
"""
Test script to verify enhanced mode fixes
"""

import asyncio
import sys
from pathlib import Path

# Add the hecaton src directory to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from hecaton.swarm.swarm_decomposer import SwarmTaskDecomposer

async def test_decomposer():
    """Test the swarm decomposer with different agent counts"""
    
    decomposer = SwarmTaskDecomposer()
    task = {
        "type": "code_implementation",
        "description": "Build a monitoring dashboard that tracks metrics"
    }
    
    print("=" * 60)
    print("Testing SwarmTaskDecomposer with different agent counts")
    print("=" * 60)
    
    # Test with different agent counts
    for num_agents in [1, 2, 4, 7, 10, 15]:
        print(f"\n--- Testing with {num_agents} agents ---")
        
        # Decompose the task
        execution_groups = await decomposer.decompose_task(task, num_agents)
        
        # Count total tasks
        total_tasks = sum(len(g.tasks) for g in execution_groups)
        
        print(f"  Execution groups: {len(execution_groups)}")
        print(f"  Total tasks created: {total_tasks}")
        
        # Show task distribution
        for i, group in enumerate(execution_groups):
            task_types = [t.task_type for t in group.tasks]
            print(f"  Group {i+1}: {len(group.tasks)} tasks - {', '.join(task_types)}")
        
        # Verify we created approximately the right number of tasks
        if total_tasks != num_agents:
            print(f"  ⚠️  WARNING: Created {total_tasks} tasks but {num_agents} were requested")
        else:
            print(f"  ✅ Created exactly {num_agents} tasks as requested")

if __name__ == "__main__":
    asyncio.run(test_decomposer())