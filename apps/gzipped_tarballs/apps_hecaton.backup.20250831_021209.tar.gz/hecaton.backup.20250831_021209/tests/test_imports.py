#!/usr/bin/env python3
"""Simple test to verify message broker works."""

import sys
import os
import asyncio

# Add src to path
sys.path.insert(0, '/home/opsvi/master_root/apps/hecaton/src')

from hecaton.messaging.message_broker import MessageBroker, Message


async def main():
    print("Testing Message Broker...")
    
    # Create and start broker
    broker = MessageBroker()
    await broker.start()
    print("✓ Broker started")
    
    # Test message creation
    msg = Message(
        sender="test_sender",
        topic="test_topic",
        payload={"test": "data"}
    )
    print(f"✓ Message created: {msg.id}")
    
    # Test publish/subscribe
    received = []
    async def callback(m):
        received.append(m)
        print(f"✓ Received message: {m.id}")
    
    await broker.subscribe("test_topic", callback)
    print("✓ Subscribed to topic")
    
    await broker.publish("test_topic", msg)
    await asyncio.sleep(0.1)  # Let callback execute
    print(f"✓ Published message")
    
    # Test direct messaging
    direct_msg = Message(payload="direct")
    await broker.send_direct("agent1", direct_msg)
    print("✓ Sent direct message")
    
    received_direct = await broker.receive_direct("agent1", timeout=1.0)
    print(f"✓ Received direct message: {received_direct.id}")
    
    # Clean up
    await broker.stop()
    print("✓ Broker stopped")
    
    print("\n✅ All basic tests passed!")
    return True


if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)