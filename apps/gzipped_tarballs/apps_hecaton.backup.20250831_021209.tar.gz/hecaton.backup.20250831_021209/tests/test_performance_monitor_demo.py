#!/usr/bin/env python3
"""Demo script to test the PerformanceMonitor implementation."""

import time
import json
from src.hecaton.monitoring.performance_monitor import PerformanceMonitor


def simulate_task(duration: float, task_name: str) -> str:
    """Simulate a task that takes some time."""
    time.sleep(duration)
    return f"Task {task_name} completed"


def main():
    """Run a demonstration of the PerformanceMonitor."""
    print("Starting Performance Monitor Demo")
    print("=" * 50)
    
    # Create monitor instance
    monitor = PerformanceMonitor()
    
    # Test Task 1: Successful task
    print("\n1. Starting Task 1 (successful, 1 second)...")
    monitor.start_tracking("task_1")
    result = simulate_task(1.0, "task_1")
    monitor.end_tracking("task_1", success=True, token_usage=150)
    print(f"   {result}")
    
    # Test Task 2: Another successful task
    print("\n2. Starting Task 2 (successful, 0.5 seconds)...")
    monitor.start_tracking("task_2")
    result = simulate_task(0.5, "task_2")
    monitor.end_tracking("task_2", success=True, token_usage=200)
    print(f"   {result}")
    
    # Test Task 3: Failed task
    print("\n3. Starting Task 3 (failed, 0.3 seconds)...")
    monitor.start_tracking("task_3")
    try:
        simulate_task(0.3, "task_3")
        # Simulate failure
        raise Exception("Simulated error")
    except Exception as e:
        monitor.end_tracking("task_3", success=False, error=str(e), token_usage=50)
        print(f"   Task 3 failed: {e}")
    
    # Test Task 4: Successful task
    print("\n4. Starting Task 4 (successful, 0.8 seconds)...")
    monitor.start_tracking("task_4")
    result = simulate_task(0.8, "task_4")
    monitor.end_tracking("task_4", success=True, token_usage=180)
    print(f"   {result}")
    
    # Get metrics for a specific task
    print("\n" + "=" * 50)
    print("Individual Task Metrics:")
    print("-" * 50)
    task_1_metrics = monitor.get_metrics("task_1")
    if task_1_metrics:
        print(f"Task 1 execution time: {task_1_metrics.execution_time:.3f} seconds")
        print(f"Task 1 token usage: {task_1_metrics.token_usage}")
        print(f"Task 1 success: {task_1_metrics.success}")
    
    # Calculate statistics
    print("\n" + "=" * 50)
    print("Aggregate Statistics:")
    print("-" * 50)
    stats = monitor.calculate_statistics()
    print(f"Total tasks: {stats['total_tasks']}")
    print(f"Successful tasks: {stats['successful_tasks']}")
    print(f"Failed tasks: {stats['failed_tasks']}")
    print(f"Success rate: {stats['success_rate']:.1%}")
    print(f"Average execution time: {stats['avg_execution_time']:.3f} seconds")
    print(f"Min execution time: {stats['min_execution_time']:.3f} seconds")
    print(f"Max execution time: {stats['max_execution_time']:.3f} seconds")
    print(f"Total token usage: {stats['total_token_usage']}")
    print(f"Peak memory: {stats['peak_memory'] / 1024 / 1024:.2f} MB")
    
    # Export metrics to JSON
    print("\n" + "=" * 50)
    print("Exporting Metrics to JSON:")
    print("-" * 50)
    json_output = monitor.export_metrics("performance_metrics_demo.json")
    print("Metrics exported to: performance_metrics_demo.json")
    
    # Show a sample of the JSON output
    data = json.loads(json_output)
    print(f"\nJSON Export Sample:")
    print(f"  Timestamp: {data['timestamp']}")
    print(f"  Total completed tasks: {len(data['completed_tasks'])}")
    print(f"  Success rate: {data['statistics']['success_rate']:.1%}")
    
    print("\n" + "=" * 50)
    print("Performance Monitor Demo Complete!")


if __name__ == "__main__":
    main()