#!/usr/bin/env python3
"""
Test single Claude execution with full debug logging
"""

import asyncio
import os
import sys
from pathlib import Path

# Load tokens
sys.path.insert(0, str(Path(__file__).parent))
from scripts.load_tokens import load_real_tokens
print("Loading tokens...")
load_real_tokens()

# Test direct Claude command first
print("\n" + "="*60)
print("TESTING DIRECT CLAUDE COMMAND")
print("="*60)

import subprocess

# Verify we have a token
token = os.environ.get("CLAUDE_CODE_TOKEN")
if not token:
    print("❌ No CLAUDE_CODE_TOKEN found!")
    sys.exit(1)
else:
    print(f"✅ Token found: {token[:10]}...")

# Create a simple test
test_prompt = "echo 'Hello from Claude' && echo 'Token test successful'"

print(f"\nRunning: claude --dangerously-skip-permissions -p \"{test_prompt}\"")
print("With CLAUDE_CODE_TOKEN set and ANTHROPIC_API_KEY empty")

env = os.environ.copy()
env["ANTHROPIC_API_KEY"] = ""

try:
    result = subprocess.run(
        ["claude", "--dangerously-skip-permissions", "-p", test_prompt],
        capture_output=True,
        text=True,
        env=env,
        timeout=30
    )
    
    print(f"\nReturn code: {result.returncode}")
    print(f"Stdout: {result.stdout}")
    print(f"Stderr: {result.stderr}")
    
    if result.returncode == 0:
        print("\n✅ Direct Claude command successful!")
    else:
        print("\n❌ Direct Claude command failed!")
        
except subprocess.TimeoutExpired:
    print("\n❌ Command timed out after 30 seconds")
except FileNotFoundError:
    print("\n❌ 'claude' command not found - is Claude CLI installed?")
except Exception as e:
    print(f"\n❌ Unexpected error: {e}")
    import traceback
    traceback.print_exc()

# Now test with HECATON infrastructure
print("\n" + "="*60)
print("TESTING HECATON INFRASTRUCTURE")
print("="*60)

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from hecaton.utils.debug_logger import set_debug_mode
set_debug_mode(True)

from hecaton.resources.token_pool import TokenPool
from hecaton.resources.worktree import WorktreeManager
from hecaton.agents.real_claude_executor_debug import RealClaudeSubprocessExecutor

async def test_single():
    """Test single Claude execution"""
    
    print("\nInitializing HECATON components...")
    
    try:
        token_pool = TokenPool()
        print(f"✅ Token pool: {token_pool.get_token_count()} tokens")
    except Exception as e:
        print(f"❌ Token pool failed: {e}")
        return
    
    try:
        worktree_manager = WorktreeManager(base_path=Path("/tmp/hecaton_test"))
        print(f"✅ Worktree manager: {worktree_manager.base_path}")
    except Exception as e:
        print(f"❌ Worktree manager failed: {e}")
        return
    
    executor = RealClaudeSubprocessExecutor(token_pool, worktree_manager)
    
    # Simple test task
    test_task = {
        "id": "test-single",
        "prompt": "echo 'HECATON test successful' && ls -la"
    }
    
    print(f"\n📋 Executing task: {test_task['prompt']}")
    
    result = await executor.execute_single_task(test_task)
    
    print(f"\n📊 Result:")
    print(f"   Status: {result.get('status')}")
    if result.get('output'):
        print(f"   Output: {result.get('output')[:500]}")
    if result.get('error'):
        print(f"   Error: {result.get('error')}")
    if result.get('traceback'):
        print(f"   Traceback:\n{result.get('traceback')}")
    
    return result

# Run the test
print("\n🚀 Starting HECATON test...")
result = asyncio.run(test_single())

if result and result.get('status') == 'completed':
    print("\n✅ HECATON infrastructure test PASSED!")
else:
    print("\n❌ HECATON infrastructure test FAILED!")
    print("\nCheck the debug log for detailed information")