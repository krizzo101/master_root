"""
Test to verify there are no stubbed implementations in production code
"""

import os
import re
from pathlib import Path

def test_no_stub_classes():
    """Verify no stub classes with only pass statements in src/"""
    src_path = Path(__file__).parent.parent / "src"
    stub_files = []
    
    for py_file in src_path.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue
            
        content = py_file.read_text()
        
        # Check for classes with only pass
        # Look for class definition followed immediately by pass (stub pattern)
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('class ') and ':' in line:
                # Check next non-empty, non-comment, non-docstring line
                j = i + 1
                while j < len(lines):
                    next_line = lines[j].strip()
                    if next_line and not next_line.startswith('#'):
                        if next_line.startswith('"""') or next_line.startswith("'''"):
                            # Skip docstring
                            doc_quote = next_line[:3]
                            j += 1
                            while j < len(lines) and doc_quote not in lines[j]:
                                j += 1
                            j += 1
                            continue
                        if next_line == 'pass':
                            # Found a stub class
                            stub_files.append(str(py_file.relative_to(src_path.parent)))
                            break
                        else:
                            # Has real implementation
                            break
                    j += 1
            
    assert not stub_files, f"Found stub classes in: {stub_files}"

def test_no_placeholder_comments():
    """Verify no placeholder comments in production code"""
    src_path = Path(__file__).parent.parent / "src"
    placeholder_files = []
    
    placeholder_patterns = [
        r"#\s*TODO.*implement",
        r"#\s*FIXME.*implement",
        r"Placeholder.*will be implemented",
        r"stub.*implementation",
    ]
    
    for py_file in src_path.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue
            
        content = py_file.read_text()
        
        for pattern in placeholder_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                placeholder_files.append(str(py_file.relative_to(src_path.parent)))
                break
                
    assert not placeholder_files, f"Found placeholder comments in: {placeholder_files}"

def test_no_mock_imports_in_src():
    """Verify no mock imports in production code"""
    src_path = Path(__file__).parent.parent / "src"
    mock_files = []
    
    mock_patterns = [
        r"from unittest\.mock import",
        r"import unittest\.mock",
        r"from mock import",
        r"import mock",
    ]
    
    for py_file in src_path.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue
            
        content = py_file.read_text()
        
        for pattern in mock_patterns:
            if re.search(pattern, content):
                mock_files.append(str(py_file.relative_to(src_path.parent)))
                break
                
    assert not mock_files, f"Found mock imports in production code: {mock_files}"

def test_all_abstract_methods_raise_not_implemented():
    """Verify abstract methods raise NotImplementedError instead of using pass"""
    src_path = Path(__file__).parent.parent / "src"
    bad_abstract_files = []
    
    for py_file in src_path.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue
            
        content = py_file.read_text()
        
        # Look for @abstractmethod followed by a function with only pass
        pattern = r'@abstractmethod\s+def\s+\w+\(.*?\).*?:\s*(?:""".*?"""\s*)?pass\s*$'
        if re.search(pattern, content, re.MULTILINE | re.DOTALL):
            bad_abstract_files.append(str(py_file.relative_to(src_path.parent)))
            
    assert not bad_abstract_files, f"Found abstract methods with pass instead of NotImplementedError: {bad_abstract_files}"

def test_engine_is_implemented():
    """Verify ExecutionEngine is properly implemented"""
    engine_file = Path(__file__).parent.parent / "src" / "hecaton" / "core" / "engine.py"
    content = engine_file.read_text()
    
    # Should have real methods, not just pass
    assert "async def start(self)" in content, "ExecutionEngine missing start method"
    assert "async def stop(self)" in content, "ExecutionEngine missing stop method"
    assert "async def execute_task(self" in content, "ExecutionEngine missing execute_task method"
    
    # Should not be a placeholder
    assert "Placeholder" not in content, "ExecutionEngine still contains placeholder text"
    
    # Should import real components
    assert "from ..agents.agent_registry import AgentRegistry" in content
    assert "from ..messaging.message_broker import MessageBroker" in content
    
if __name__ == "__main__":
    test_no_stub_classes()
    print("✓ No stub classes found")
    
    test_no_placeholder_comments()
    print("✓ No placeholder comments found")
    
    test_no_mock_imports_in_src()
    print("✓ No mock imports in production code")
    
    test_all_abstract_methods_raise_not_implemented()
    print("✓ All abstract methods properly implemented")
    
    test_engine_is_implemented()
    print("✓ ExecutionEngine properly implemented")
    
    print("\n✅ All stub checks passed - HECATON has no stubbed implementations!")