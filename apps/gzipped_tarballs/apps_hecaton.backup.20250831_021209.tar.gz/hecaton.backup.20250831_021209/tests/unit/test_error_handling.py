"""
Tests for Phase 1 error handling and retry logic.
Created by Agent-2 during self-amplification.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock

from hecaton.orchestration.error_handler import ErrorHandler, RetryConfig
from hecaton.orchestration.enhanced_orchestrator import EnhancedOrchestrator


class TestErrorHandling:
    """Test suite for error handling."""
    
    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Test that retry logic works correctly."""
        
        # Create a function that fails twice then succeeds
        call_count = 0
        
        async def flaky_function():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RuntimeError(f"Attempt {call_count} failed")
            return "success"
        
        # Execute with retry
        handler = ErrorHandler(RetryConfig(max_retries=3, base_delay=0.01))
        result = await handler.execute_with_retry(flaky_function)
        
        assert result == "success"
        assert call_count == 3
    
    @pytest.mark.asyncio
    async def test_exponential_backoff(self):
        """Test exponential backoff between retries."""
        
        async def always_fails():
            raise RuntimeError("Always fails")
        
        handler = ErrorHandler(RetryConfig(
            max_retries=3,
            base_delay=0.01,
            exponential_base=2
        ))
        
        start_time = asyncio.get_event_loop().time()
        
        with pytest.raises(RuntimeError):
            await handler.execute_with_retry(always_fails)
        
        elapsed = asyncio.get_event_loop().time() - start_time
        
        # Should have delays of 0.01, 0.02, 0.04 = 0.07 seconds minimum
        assert elapsed >= 0.07
    
    @pytest.mark.asyncio  
    async def test_enhanced_orchestrator(self):
        """Test the enhanced orchestrator with retry."""
        
        orchestrator = EnhancedOrchestrator(
            retry_config=RetryConfig(max_retries=2, base_delay=0.01)
        )
        
        tasks = [
            {"id": "task-1", "description": "Test task 1"},
            {"id": "task-2", "description": "Test task 2"},
        ]
        
        results = await orchestrator.execute_parallel_with_retry(tasks)
        
        assert len(results) == 2
        
        stats = orchestrator.get_statistics()
        assert stats["total_tasks"] == 2
