"""
Unit tests for ErrorBoundary
"""

import pytest
import asyncio
from hecaton.safety.error_boundaries import (
    ErrorBoundary, ErrorResult, ErrorSeverity, CompositeErrorBoundary
)


@pytest.fixture
def error_boundary():
    """Create an error boundary for testing"""
    return ErrorBoundary(
        propagate_critical=True,
        max_retries=3,
        fallback_handler=None
    )


@pytest.mark.asyncio
async def test_successful_execution(error_boundary):
    """Test successful function execution"""
    async def successful_func():
        return "success"
    
    result = await error_boundary.execute_with_boundary(successful_func)
    assert result == "success"


@pytest.mark.asyncio
async def test_error_handling(error_boundary):
    """Test error handling and retry logic"""
    call_count = 0
    
    async def failing_func():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise ValueError("Test error")
        return "recovered"
    
    result = await error_boundary.execute_with_boundary(failing_func)
    assert result == "recovered"
    assert call_count == 3


@pytest.mark.asyncio
async def test_max_retries_exceeded(error_boundary):
    """Test when max retries are exceeded"""
    async def always_failing_func():
        raise ValueError("Persistent error")
    
    result = await error_boundary.execute_with_boundary(always_failing_func)
    
    assert isinstance(result, ErrorResult)
    assert result.severity == ErrorSeverity.MEDIUM
    assert result.recoverable is True
    assert isinstance(result.error, ValueError)


@pytest.mark.asyncio
async def test_critical_error_propagation(error_boundary):
    """Test that critical errors are propagated"""
    async def critical_func():
        raise MemoryError("Out of memory")
    
    with pytest.raises(MemoryError):
        await error_boundary.execute_with_boundary(critical_func)


@pytest.mark.asyncio
async def test_critical_error_no_propagation():
    """Test critical errors when propagation is disabled"""
    boundary = ErrorBoundary(propagate_critical=False)
    
    async def critical_func():
        raise MemoryError("Out of memory")
    
    result = await boundary.execute_with_boundary(critical_func)
    
    assert isinstance(result, ErrorResult)
    assert result.severity == ErrorSeverity.CRITICAL
    assert result.recoverable is False


@pytest.mark.asyncio
async def test_custom_error_handler(error_boundary):
    """Test custom error handlers"""
    handler_called = False
    
    def custom_handler(error, context):
        nonlocal handler_called
        handler_called = True
        return "handled"
    
    error_boundary.register_handler(ValueError, custom_handler)
    
    def failing_func():
        raise ValueError("Test error")
    
    result = await error_boundary.execute_with_boundary(failing_func)
    
    assert result == "handled"
    assert handler_called is True


@pytest.mark.asyncio
async def test_fallback_handler():
    """Test fallback handler execution"""
    fallback_called = False
    
    async def fallback_handler(error_result):
        nonlocal fallback_called
        fallback_called = True
        return "fallback_result"
    
    boundary = ErrorBoundary(
        max_retries=1,
        fallback_handler=fallback_handler
    )
    
    async def failing_func():
        raise ValueError("Test error")
    
    result = await boundary.execute_with_boundary(failing_func)
    
    assert result == "fallback_result"
    assert fallback_called is True


@pytest.mark.asyncio
async def test_error_classification():
    """Test error severity classification"""
    boundary = ErrorBoundary()
    
    # Test different error types
    assert boundary._classify_error(SystemExit()) == ErrorSeverity.CRITICAL
    assert boundary._classify_error(MemoryError()) == ErrorSeverity.CRITICAL
    assert boundary._classify_error(ConnectionError()) == ErrorSeverity.HIGH
    assert boundary._classify_error(TimeoutError()) == ErrorSeverity.HIGH
    assert boundary._classify_error(ValueError()) == ErrorSeverity.MEDIUM
    assert boundary._classify_error(TypeError()) == ErrorSeverity.MEDIUM
    assert boundary._classify_error(Exception()) == ErrorSeverity.LOW


def test_error_recovery_suggestions():
    """Test error recovery suggestions"""
    boundary = ErrorBoundary()
    
    assert "network" in boundary._suggest_action(ConnectionError()).lower()
    assert "timeout" in boundary._suggest_action(TimeoutError()).lower()
    assert "memory" in boundary._suggest_action(MemoryError()).lower()


@pytest.mark.asyncio
async def test_composite_error_boundary():
    """Test composite error boundary"""
    composite = CompositeErrorBoundary()
    
    # Add boundaries with different configurations
    strict_boundary = ErrorBoundary(max_retries=1)
    lenient_boundary = ErrorBoundary(max_retries=5)
    
    composite.add_boundary("strict", strict_boundary)
    composite.add_boundary("lenient", lenient_boundary)
    
    # Test with strict boundary
    call_count = 0
    
    async def failing_func():
        nonlocal call_count
        call_count += 1
        raise ValueError("Error")
    
    result = await composite.execute_with_boundary("strict", failing_func)
    assert isinstance(result, ErrorResult)
    assert call_count == 1  # Only one retry
    
    # Reset and test with lenient boundary
    call_count = 0
    result = await composite.execute_with_boundary("lenient", failing_func)
    assert isinstance(result, ErrorResult)
    assert call_count == 5  # Five retries


@pytest.mark.asyncio
async def test_context_passing(error_boundary):
    """Test that context is passed to handlers"""
    received_context = None
    
    def context_handler(error, context):
        nonlocal received_context
        received_context = context
        return "handled"
    
    error_boundary.register_handler(ValueError, context_handler)
    
    def failing_func():
        raise ValueError("Test")
    
    test_context = {"task_id": "123", "agent": "test"}
    await error_boundary.execute_with_boundary(
        failing_func,
        context=test_context
    )
    
    assert received_context == test_context


@pytest.mark.asyncio
async def test_exponential_backoff(error_boundary):
    """Test exponential backoff between retries"""
    start_times = []
    
    async def timing_func():
        start_times.append(asyncio.get_event_loop().time())
        if len(start_times) < 3:
            raise ValueError("Retry needed")
        return "success"
    
    await error_boundary.execute_with_boundary(timing_func)
    
    # Check that delays are increasing
    if len(start_times) >= 2:
        delays = [start_times[i+1] - start_times[i] for i in range(len(start_times)-1)]
        assert all(delays[i+1] > delays[i] for i in range(len(delays)-1))