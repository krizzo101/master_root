"""
Unit tests for CheckpointManager
"""

import pytest
import asyncio
from pathlib import Path
import tempfile
from hecaton.safety.checkpoint_manager import CheckpointManager, Checkpoint


@pytest.fixture
async def checkpoint_manager():
    """Create a checkpoint manager for testing"""
    with tempfile.TemporaryDirectory() as tmpdir:
        manager = CheckpointManager(
            max_checkpoints=5,
            storage_path=Path(tmpdir),
            auto_cleanup=True
        )
        yield manager


@pytest.mark.asyncio
async def test_create_checkpoint(checkpoint_manager):
    """Test creating a checkpoint"""
    state = {"counter": 1, "data": [1, 2, 3]}
    metadata = {"task": "test_task"}
    
    checkpoint_id = await checkpoint_manager.create_checkpoint(state, metadata)
    
    assert checkpoint_id is not None
    assert checkpoint_id.startswith("ckpt_")
    assert len(checkpoint_manager.checkpoints) == 1


@pytest.mark.asyncio
async def test_rollback_to_checkpoint(checkpoint_manager):
    """Test rolling back to a checkpoint"""
    # Create multiple checkpoints
    state1 = {"counter": 1}
    state2 = {"counter": 2}
    state3 = {"counter": 3}
    
    ckpt1 = await checkpoint_manager.create_checkpoint(state1)
    ckpt2 = await checkpoint_manager.create_checkpoint(state2)
    ckpt3 = await checkpoint_manager.create_checkpoint(state3)
    
    assert len(checkpoint_manager.checkpoints) == 3
    
    # Rollback to checkpoint 2
    restored_state = await checkpoint_manager.rollback_to_checkpoint(ckpt2)
    
    assert restored_state == state2
    assert len(checkpoint_manager.checkpoints) == 2
    assert ckpt3 not in checkpoint_manager.checkpoints


@pytest.mark.asyncio
async def test_auto_cleanup(checkpoint_manager):
    """Test automatic cleanup of old checkpoints"""
    # Create more than max checkpoints
    for i in range(10):
        await checkpoint_manager.create_checkpoint({"counter": i})
    
    # Should only keep max_checkpoints (5)
    assert len(checkpoint_manager.checkpoints) <= 5
    assert len(checkpoint_manager.checkpoint_order) <= 5


@pytest.mark.asyncio
async def test_get_checkpoint(checkpoint_manager):
    """Test retrieving a specific checkpoint"""
    state = {"test": "data"}
    metadata = {"info": "test"}
    
    checkpoint_id = await checkpoint_manager.create_checkpoint(state, metadata)
    checkpoint = await checkpoint_manager.get_checkpoint(checkpoint_id)
    
    assert checkpoint is not None
    assert checkpoint.state == state
    assert checkpoint.metadata == metadata


@pytest.mark.asyncio
async def test_list_checkpoints(checkpoint_manager):
    """Test listing all checkpoints"""
    # Create multiple checkpoints
    for i in range(3):
        await checkpoint_manager.create_checkpoint({"counter": i})
    
    checkpoints = await checkpoint_manager.list_checkpoints()
    
    assert len(checkpoints) == 3
    assert all("id" in ckpt for ckpt in checkpoints)
    assert all("timestamp" in ckpt for ckpt in checkpoints)


@pytest.mark.asyncio
async def test_prune_checkpoint_branch(checkpoint_manager):
    """Test pruning a checkpoint branch"""
    # Create a branching checkpoint tree
    state1 = {"counter": 1}
    ckpt1 = await checkpoint_manager.create_checkpoint(state1)
    
    state2 = {"counter": 2}
    ckpt2 = await checkpoint_manager.create_checkpoint(state2, {"parent_id": ckpt1})
    
    state3 = {"counter": 3}
    ckpt3 = await checkpoint_manager.create_checkpoint(state3, {"parent_id": ckpt2})
    
    # Prune from checkpoint 2
    await checkpoint_manager.prune_checkpoint_branch(ckpt2)
    
    # Checkpoint 1 should remain, 2 and 3 should be removed
    assert ckpt1 in checkpoint_manager.checkpoints
    assert ckpt2 not in checkpoint_manager.checkpoints
    assert ckpt3 not in checkpoint_manager.checkpoints


@pytest.mark.asyncio
async def test_checkpoint_persistence(checkpoint_manager):
    """Test checkpoint persistence to disk"""
    state = {"persistent": "data"}
    checkpoint_id = await checkpoint_manager.create_checkpoint(state)
    
    # Clear memory cache
    checkpoint_manager.checkpoints.clear()
    
    # Should be able to load from disk
    checkpoint = await checkpoint_manager.get_checkpoint(checkpoint_id)
    
    assert checkpoint is not None
    assert checkpoint.state == state


@pytest.mark.asyncio
async def test_concurrent_checkpoint_creation():
    """Test concurrent checkpoint creation"""
    with tempfile.TemporaryDirectory() as tmpdir:
        manager = CheckpointManager(storage_path=Path(tmpdir))
        
        # Create multiple checkpoints concurrently
        tasks = [
            manager.create_checkpoint({"counter": i})
            for i in range(10)
        ]
        
        checkpoint_ids = await asyncio.gather(*tasks)
        
        assert len(checkpoint_ids) == 10
        assert len(set(checkpoint_ids)) == 10  # All unique
        assert len(manager.checkpoints) == 10