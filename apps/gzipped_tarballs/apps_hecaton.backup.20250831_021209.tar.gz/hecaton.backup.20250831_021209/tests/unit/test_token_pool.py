"""
Unit tests for Token Pool
As specified in specs/testing-strategy.md
"""

import os
import pytest
import threading
from unittest.mock import patch, MagicMock

from hecaton.resources.token_pool import TokenPool


class TestTokenPool:
    """Test suite for TokenPool component"""
    
    def test_loads_exactly_two_tokens(self, monkeypatch):
        """REQ-002: Phase 0 has exactly 2 tokens"""
        # Setup environment
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "test_token_0")
        monkeypatch.setenv("CLAUDE_CODE_TOKEN_1", "test_token_1")
        
        pool = TokenPool()
        assert pool.get_token_count() == 2
        
        # Verify both tokens are loaded
        token1, idx1 = pool.acquire()
        token2, idx2 = pool.acquire()
        assert token1 == "test_token_0"
        assert token2 == "test_token_1"
    
    def test_round_robin_rotation(self, monkeypatch):
        """REQ-002: Tokens rotate in order"""
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "token_a")
        monkeypatch.setenv("CLAUDE_CODE_TOKEN_1", "token_b")
        
        pool = TokenPool()
        
        # First round
        token1 = pool.get_token()
        token2 = pool.get_token()
        
        # Second round (should rotate back)
        token3 = pool.get_token()
        token4 = pool.get_token()
        
        assert token1 == "token_a"  # First token
        assert token2 == "token_b"  # Second token
        assert token3 == "token_a"  # Back to first
        assert token4 == "token_b"  # Back to second
    
    def test_thread_safety(self, monkeypatch):
        """REQ-002: Concurrent access is safe"""
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "token_safe_1")
        monkeypatch.setenv("CLAUDE_CODE_TOKEN_1", "token_safe_2")
        
        pool = TokenPool()
        tokens_acquired = []
        
        def acquire_token():
            token = pool.get_token()
            tokens_acquired.append(token)
        
        # Create many threads to test concurrent access
        threads = []
        for _ in range(100):
            t = threading.Thread(target=acquire_token)
            threads.append(t)
            t.start()
        
        # Wait for all threads
        for t in threads:
            t.join()
        
        # Verify results
        assert len(tokens_acquired) == 100
        # Should have roughly equal distribution
        assert tokens_acquired.count("token_safe_1") > 40
        assert tokens_acquired.count("token_safe_2") > 40
        # Only 2 unique tokens
        assert len(set(tokens_acquired)) == 2
    
    def test_uses_same_token_twice_if_only_one(self, monkeypatch):
        """Phase 0: Can use same token twice for testing"""
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "single_token")
        # Don't set CLAUDE_CODE_TOKEN_1
        
        with patch('hecaton.resources.token_pool.logger') as mock_logger:
            pool = TokenPool()
            assert pool.get_token_count() == 2
            
            # Should log warning
            mock_logger.warning.assert_called_once()
            
            # Both should be the same token
            token1 = pool.get_token()
            token2 = pool.get_token()
            assert token1 == "single_token"
            assert token2 == "single_token"
    
    def test_raises_error_if_no_tokens(self, monkeypatch):
        """Should raise error if no tokens available"""
        # Clear any existing token env vars
        for key in list(os.environ.keys()):
            if "CLAUDE_CODE_TOKEN" in key:
                monkeypatch.delenv(key, raising=False)
        
        with pytest.raises(ValueError, match="No CLAUDE_CODE_TOKEN found"):
            TokenPool()
    
    def test_usage_statistics(self, monkeypatch):
        """Should track usage statistics correctly"""
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "stat_token_1")
        monkeypatch.setenv("CLAUDE_CODE_TOKEN_1", "stat_token_2")
        
        pool = TokenPool()
        
        # Use tokens multiple times
        for _ in range(5):
            pool.get_token()
        
        stats = pool.get_usage_stats()
        assert stats["token_count"] == 2
        assert sum(stats["usage_counts"].values()) == 5
        
        # Should have used both tokens (round-robin)
        assert stats["usage_counts"][0] >= 2
        assert stats["usage_counts"][1] >= 2
    
    def test_acquire_returns_token_and_index(self, monkeypatch):
        """acquire() should return both token and index"""
        monkeypatch.setenv("CLAUDE_CODE_TOKEN", "indexed_token_1")
        monkeypatch.setenv("CLAUDE_CODE_TOKEN_1", "indexed_token_2")
        
        pool = TokenPool()
        
        token1, idx1 = pool.acquire()
        assert token1 == "indexed_token_1"
        assert idx1 == 0
        
        token2, idx2 = pool.acquire()
        assert token2 == "indexed_token_2"
        assert idx2 == 1
        
        # Round robin back to first
        token3, idx3 = pool.acquire()
        assert token3 == "indexed_token_1"
        assert idx3 == 0