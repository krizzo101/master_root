"""Unit tests for AgentRegistry system."""

import unittest
from datetime import datetime, timedelta
import time
from unittest.mock import patch, MagicMock

from src.hecaton.agents.agent_registry import (
    Agent,
    AgentRegistry,
    AgentStatus
)


class TestAgent(unittest.TestCase):
    """Test cases for Agent dataclass."""
    
    def test_agent_creation(self):
        """Test creating an agent with default values."""
        agent = Agent()
        self.assertIsNotNone(agent.id)
        self.assertEqual(agent.name, "")
        self.assertEqual(agent.capabilities, set())
        self.assertEqual(agent.status, AgentStatus.INITIALIZING)
        self.assertEqual(agent.task_count, 0)
        self.assertEqual(agent.error_count, 0)
        self.assertIsInstance(agent.last_heartbeat, datetime)
        self.assertIsInstance(agent.created_at, datetime)
    
    def test_agent_creation_with_values(self):
        """Test creating an agent with custom values."""
        agent = Agent(
            id="agent-123",
            name="TestAgent",
            capabilities={"compute", "storage"},
            status=AgentStatus.IDLE
        )
        self.assertEqual(agent.id, "agent-123")
        self.assertEqual(agent.name, "TestAgent")
        self.assertEqual(agent.capabilities, {"compute", "storage"})
        self.assertEqual(agent.status, AgentStatus.IDLE)
    
    def test_is_healthy(self):
        """Test agent health check."""
        agent = Agent()
        agent.status = AgentStatus.IDLE
        
        # Fresh agent should be healthy
        self.assertTrue(agent.is_healthy())
        
        # Agent with old heartbeat should be unhealthy
        agent.last_heartbeat = datetime.now() - timedelta(seconds=120)
        self.assertFalse(agent.is_healthy(timeout_seconds=60))
        
        # Agent marked offline should always be unhealthy
        agent.last_heartbeat = datetime.now()
        agent.status = AgentStatus.OFFLINE
        self.assertFalse(agent.is_healthy())
    
    def test_update_heartbeat(self):
        """Test updating agent heartbeat."""
        agent = Agent()
        agent.status = AgentStatus.OFFLINE
        old_heartbeat = agent.last_heartbeat
        
        time.sleep(0.01)  # Ensure time difference
        agent.update_heartbeat()
        
        self.assertGreater(agent.last_heartbeat, old_heartbeat)
        self.assertEqual(agent.status, AgentStatus.IDLE)


class TestAgentRegistry(unittest.TestCase):
    """Test cases for AgentRegistry class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.registry = AgentRegistry(heartbeat_timeout=60)
        self.test_agent = Agent(
            id="test-agent-1",
            name="TestAgent1",
            capabilities={"compute", "storage"},
            status=AgentStatus.IDLE
        )
    
    def test_register_agent(self):
        """Test registering an agent."""
        agent_id = self.registry.register(self.test_agent)
        self.assertEqual(agent_id, "test-agent-1")
        self.assertIn("test-agent-1", self.registry._agents)
        
        # Test capability indexing
        self.assertIn("test-agent-1", self.registry._capability_index["compute"])
        self.assertIn("test-agent-1", self.registry._capability_index["storage"])
    
    def test_register_agent_without_id(self):
        """Test registering an agent without ID generates one."""
        agent = Agent(name="NoIDAgent")
        agent_id = self.registry.register(agent)
        self.assertIsNotNone(agent_id)
        self.assertEqual(agent.id, agent_id)
    
    def test_deregister_agent(self):
        """Test removing an agent from registry."""
        self.registry.register(self.test_agent)
        
        # Successful deregistration
        result = self.registry.deregister("test-agent-1")
        self.assertTrue(result)
        self.assertNotIn("test-agent-1", self.registry._agents)
        
        # Capability index should be cleaned up
        self.assertNotIn("test-agent-1", self.registry._capability_index.get("compute", set()))
        
        # Deregistering non-existent agent
        result = self.registry.deregister("non-existent")
        self.assertFalse(result)
    
    def test_find_by_capability(self):
        """Test finding agents by capability."""
        # Register multiple agents
        agent1 = Agent(id="agent-1", capabilities={"compute"}, status=AgentStatus.IDLE)
        agent2 = Agent(id="agent-2", capabilities={"storage"}, status=AgentStatus.IDLE)
        agent3 = Agent(id="agent-3", capabilities={"compute", "storage"}, status=AgentStatus.IDLE)
        
        self.registry.register(agent1)
        self.registry.register(agent2)
        self.registry.register(agent3)
        
        # Find agents with compute capability
        compute_agents = self.registry.find_by_capability("compute")
        self.assertEqual(len(compute_agents), 2)
        agent_ids = [a.id for a in compute_agents]
        self.assertIn("agent-1", agent_ids)
        self.assertIn("agent-3", agent_ids)
        
        # Find agents with storage capability
        storage_agents = self.registry.find_by_capability("storage")
        self.assertEqual(len(storage_agents), 2)
        agent_ids = [a.id for a in storage_agents]
        self.assertIn("agent-2", agent_ids)
        self.assertIn("agent-3", agent_ids)
        
        # Find non-existent capability
        network_agents = self.registry.find_by_capability("network")
        self.assertEqual(len(network_agents), 0)
    
    def test_get_agent(self):
        """Test retrieving a specific agent."""
        self.registry.register(self.test_agent)
        
        # Get existing agent
        agent = self.registry.get_agent("test-agent-1")
        self.assertIsNotNone(agent)
        self.assertEqual(agent.id, "test-agent-1")
        self.assertEqual(agent.name, "TestAgent1")
        
        # Get non-existent agent
        agent = self.registry.get_agent("non-existent")
        self.assertIsNone(agent)
    
    def test_get_all_agents(self):
        """Test getting all registered agents."""
        agent1 = Agent(id="agent-1")
        agent2 = Agent(id="agent-2")
        
        self.registry.register(agent1)
        self.registry.register(agent2)
        
        all_agents = self.registry.get_all_agents()
        self.assertEqual(len(all_agents), 2)
        agent_ids = [a.id for a in all_agents]
        self.assertIn("agent-1", agent_ids)
        self.assertIn("agent-2", agent_ids)
    
    def test_update_heartbeat(self):
        """Test updating agent heartbeat through registry."""
        self.registry.register(self.test_agent)
        old_heartbeat = self.test_agent.last_heartbeat
        
        time.sleep(0.01)
        result = self.registry.update_heartbeat("test-agent-1")
        self.assertTrue(result)
        self.assertGreater(self.test_agent.last_heartbeat, old_heartbeat)
        
        # Update non-existent agent
        result = self.registry.update_heartbeat("non-existent")
        self.assertFalse(result)
    
    def test_get_healthy_unhealthy_agents(self):
        """Test getting healthy and unhealthy agents."""
        # Create healthy agent
        healthy_agent = Agent(id="healthy", status=AgentStatus.IDLE)
        self.registry.register(healthy_agent)
        
        # Create unhealthy agent (old heartbeat)
        unhealthy_agent = Agent(id="unhealthy", status=AgentStatus.IDLE)
        unhealthy_agent.last_heartbeat = datetime.now() - timedelta(seconds=120)
        self.registry.register(unhealthy_agent)
        
        # Create offline agent
        offline_agent = Agent(id="offline", status=AgentStatus.OFFLINE)
        self.registry.register(offline_agent)
        
        healthy = self.registry.get_healthy_agents()
        unhealthy = self.registry.get_unhealthy_agents()
        
        self.assertEqual(len(healthy), 1)
        self.assertEqual(healthy[0].id, "healthy")
        
        self.assertEqual(len(unhealthy), 2)
        unhealthy_ids = [a.id for a in unhealthy]
        self.assertIn("unhealthy", unhealthy_ids)
        self.assertIn("offline", unhealthy_ids)
    
    def test_mark_offline(self):
        """Test marking an agent as offline."""
        self.registry.register(self.test_agent)
        
        result = self.registry.mark_offline("test-agent-1")
        self.assertTrue(result)
        self.assertEqual(self.test_agent.status, AgentStatus.OFFLINE)
        
        # Mark non-existent agent
        result = self.registry.mark_offline("non-existent")
        self.assertFalse(result)
    
    def test_get_least_loaded_agent(self):
        """Test load balancing with least loaded agent selection."""
        # Create agents with different task counts
        agent1 = Agent(id="agent-1", capabilities={"compute"}, status=AgentStatus.IDLE, task_count=5)
        agent2 = Agent(id="agent-2", capabilities={"compute"}, status=AgentStatus.IDLE, task_count=2)
        agent3 = Agent(id="agent-3", capabilities={"compute"}, status=AgentStatus.BUSY, task_count=1)
        agent4 = Agent(id="agent-4", capabilities={"storage"}, status=AgentStatus.IDLE, task_count=0)
        
        self.registry.register(agent1)
        self.registry.register(agent2)
        self.registry.register(agent3)
        self.registry.register(agent4)
        
        # Get least loaded with compute capability
        least_loaded = self.registry.get_least_loaded_agent("compute")
        self.assertIsNotNone(least_loaded)
        self.assertEqual(least_loaded.id, "agent-2")  # agent-3 is busy
        
        # Get least loaded without capability filter
        least_loaded = self.registry.get_least_loaded_agent()
        self.assertIsNotNone(least_loaded)
        self.assertEqual(least_loaded.id, "agent-4")  # Lowest task count overall
        
        # No agents available when all are busy
        agent1.status = AgentStatus.BUSY
        agent2.status = AgentStatus.BUSY
        agent4.status = AgentStatus.BUSY
        least_loaded = self.registry.get_least_loaded_agent()
        self.assertIsNone(least_loaded)
    
    def test_assign_complete_task(self):
        """Test task assignment and completion."""
        self.registry.register(self.test_agent)
        
        # Assign task
        result = self.registry.assign_task("test-agent-1")
        self.assertTrue(result)
        self.assertEqual(self.test_agent.task_count, 1)
        self.assertEqual(self.test_agent.status, AgentStatus.BUSY)
        self.assertEqual(self.registry._task_distribution["test-agent-1"], 1)
        
        # Complete task
        result = self.registry.complete_task("test-agent-1")
        self.assertTrue(result)
        self.assertEqual(self.test_agent.status, AgentStatus.IDLE)
        
        # Non-existent agent
        result = self.registry.assign_task("non-existent")
        self.assertFalse(result)
        result = self.registry.complete_task("non-existent")
        self.assertFalse(result)
    
    def test_report_error(self):
        """Test error reporting for agents."""
        self.registry.register(self.test_agent)
        
        result = self.registry.report_error("test-agent-1")
        self.assertTrue(result)
        self.assertEqual(self.test_agent.error_count, 1)
        self.assertEqual(self.test_agent.status, AgentStatus.ERROR)
        
        # Non-existent agent
        result = self.registry.report_error("non-existent")
        self.assertFalse(result)
    
    def test_get_statistics(self):
        """Test registry statistics generation."""
        # Register agents with various states
        agent1 = Agent(id="agent-1", capabilities={"compute"}, status=AgentStatus.IDLE)
        agent2 = Agent(id="agent-2", capabilities={"storage"}, status=AgentStatus.BUSY)
        agent3 = Agent(id="agent-3", capabilities={"compute", "storage"}, status=AgentStatus.ERROR)
        agent4 = Agent(id="agent-4", capabilities={"network"}, status=AgentStatus.OFFLINE)
        
        self.registry.register(agent1)
        self.registry.register(agent2)
        self.registry.register(agent3)
        self.registry.register(agent4)
        
        # Assign some tasks
        self.registry.assign_task("agent-1")
        self.registry.assign_task("agent-1")
        self.registry.assign_task("agent-2")
        
        stats = self.registry.get_statistics()
        
        self.assertEqual(stats["total_agents"], 4)
        self.assertEqual(stats["healthy_agents"], 3)  # All except offline
        self.assertEqual(stats["unhealthy_agents"], 1)  # Offline agent
        self.assertEqual(stats["total_capabilities"], 3)
        self.assertEqual(stats["total_tasks_assigned"], 3)
        
        # Check status breakdown
        self.assertEqual(stats["status_breakdown"]["idle"], 1)
        self.assertEqual(stats["status_breakdown"]["busy"], 2)  # agent-1 became busy after assign_task
        self.assertEqual(stats["status_breakdown"]["error"], 1)
        self.assertEqual(stats["status_breakdown"]["offline"], 1)
        
        # Check capability coverage
        self.assertEqual(stats["capability_coverage"]["compute"], 2)
        self.assertEqual(stats["capability_coverage"]["storage"], 2)
        self.assertEqual(stats["capability_coverage"]["network"], 1)


if __name__ == "__main__":
    unittest.main()