"""
Unit tests for Worktree Manager
As specified in specs/testing-strategy.md
"""

import subprocess
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, call
from datetime import datetime

from hecaton.resources.worktree import WorktreeManager, AgentWorktree


class TestWorktreeManager:
    """Test suite for WorktreeManager component"""
    
    def test_creates_unique_worktree(self, tmp_path):
        """REQ-003: Each agent gets unique space"""
        with patch('subprocess.run') as mock_run:
            # Mock successful git commands
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="feature/test\n"
            )
            
            manager = WorktreeManager(base_path=tmp_path / "worktrees")
            
            # Create worktrees for two agents
            wt1 = manager.create("agent1")
            wt2 = manager.create("agent2")
            
            # Should have unique paths
            assert wt1 != wt2
            assert "agent1" in str(wt1)
            assert "agent2" in str(wt2)
            
            # Should track both worktrees
            assert len(manager.active_worktrees) == 2
    
    def test_uses_git_branch_not_checkout(self):
        """REQ-003: Critical pattern compliance - must use 'git branch'"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager()
            manager.create("test_agent")
            
            # Collect all git commands that were run
            git_commands = []
            for call_args in mock_run.call_args_list:
                if call_args[0][0][0] == "git":
                    git_commands.append(" ".join(call_args[0][0]))
            
            # Verify 'git branch' was used
            assert any("git branch hecaton" in cmd for cmd in git_commands), \
                "Must use 'git branch' to create branches"
            
            # Verify 'git checkout -b' was NOT used
            assert not any("checkout" in cmd and "-b" in cmd for cmd in git_commands), \
                "Must NOT use 'git checkout -b' (violates Rule 997)"
    
    def test_cleanup_removes_worktree(self, tmp_path):
        """REQ-016: Resource cleanup"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager(base_path=tmp_path / "worktrees")
            
            # Create and then cleanup
            wt_path = manager.create("cleanup_test")
            assert "cleanup_test" in manager.active_worktrees
            
            manager.cleanup("cleanup_test")
            assert "cleanup_test" not in manager.active_worktrees
            
            # Verify git worktree remove was called
            remove_calls = [
                call_args for call_args in mock_run.call_args_list
                if call_args[0][0][0:3] == ["git", "worktree", "remove"]
            ]
            assert len(remove_calls) > 0
    
    def test_generates_unique_branch_names(self):
        """Branch names should be unique with timestamps"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager()
            
            # Mock datetime to control timestamp
            with patch('hecaton.resources.worktree.datetime') as mock_dt:
                mock_dt.now.return_value.strftime.return_value = "20240101_120000"
                
                manager.create("agent_x")
                
                # Check that branch name includes timestamp and agent id
                branch_calls = [
                    call_args for call_args in mock_run.call_args_list
                    if len(call_args[0][0]) >= 3 and 
                    call_args[0][0][0:2] == ["git", "branch"]
                ]
                
                assert any(
                    "hecaton/20240101_120000/agent_x" in str(call_args)
                    for call_args in branch_calls
                )
    
    def test_handles_existing_branch(self):
        """Should handle case where branch already exists"""
        with patch('subprocess.run') as mock_run:
            # First call to rev-parse HEAD returns current branch
            # Second call to rev-parse --verify returns 0 (branch exists)
            # Rest return success
            mock_run.side_effect = [
                MagicMock(returncode=0, stdout="main\n"),  # Get current branch
                MagicMock(returncode=0),  # Branch exists check
                MagicMock(returncode=0),  # Delete existing branch
                MagicMock(returncode=0),  # Create new branch
                MagicMock(returncode=0),  # Add worktree
            ]
            
            manager = WorktreeManager()
            manager.create("existing_branch_test")
            
            # Should have deleted the existing branch
            delete_calls = [
                call_args for call_args in mock_run.call_args_list
                if len(call_args[0][0]) >= 3 and
                call_args[0][0][0:3] == ["git", "branch", "-D"]
            ]
            assert len(delete_calls) > 0
    
    def test_get_worktree_path(self, tmp_path):
        """Should return correct worktree path for agent"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager(base_path=tmp_path / "worktrees")
            
            wt_path = manager.create("path_test")
            retrieved_path = manager.get_worktree_path("path_test")
            
            assert retrieved_path == wt_path
            assert manager.get_worktree_path("nonexistent") is None
    
    def test_list_active_worktrees(self, tmp_path):
        """Should list all active worktrees"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager(base_path=tmp_path / "worktrees")
            
            manager.create("agent1")
            manager.create("agent2")
            manager.create("agent3")
            
            active = manager.list_active_worktrees()
            assert len(active) == 3
            assert "agent1" in active
            assert "agent2" in active
            assert "agent3" in active
    
    def test_cleanup_all(self, tmp_path):
        """Should clean up all worktrees"""
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="main\n"
            )
            
            manager = WorktreeManager(base_path=tmp_path / "worktrees")
            
            manager.create("cleanup1")
            manager.create("cleanup2")
            assert len(manager.active_worktrees) == 2
            
            manager.cleanup_all()
            assert len(manager.active_worktrees) == 0