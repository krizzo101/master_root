"""
Comprehensive unit tests for the MessageBroker class.
"""

import asyncio
import pytest
from datetime import datetime
from typing import List
from unittest.mock import MagicMock, AsyncMock, patch

from hecaton.messaging import Message, AsyncMessageBroker


@pytest.fixture
async def broker():
    """Create and start a message broker for testing."""
    broker = AsyncMessageBroker()
    await broker.start()
    yield broker
    await broker.stop()


@pytest.fixture
def sample_message():
    """Create a sample message for testing."""
    return Message(
        sender="agent_1",
        topic="test_topic",
        payload={"data": "test_data"}
    )


class TestMessage:
    """Tests for the Message dataclass."""
    
    def test_message_creation_with_defaults(self):
        """Test creating a message with default values."""
        msg = Message()
        assert msg.id is not None
        assert len(msg.id) == 36  # UUID4 string length
        assert msg.sender == ""
        assert msg.receiver is None
        assert msg.topic == ""
        assert msg.payload is None
        assert isinstance(msg.timestamp, datetime)
    
    def test_message_creation_with_values(self):
        """Test creating a message with specified values."""
        payload = {"key": "value"}
        msg = Message(
            sender="sender_1",
            receiver="receiver_1",
            topic="topic_1",
            payload=payload
        )
        assert msg.sender == "sender_1"
        assert msg.receiver == "receiver_1"
        assert msg.topic == "topic_1"
        assert msg.payload == payload
    
    def test_message_unique_ids(self):
        """Test that messages get unique IDs."""
        msg1 = Message()
        msg2 = Message()
        assert msg1.id != msg2.id
    
    def test_message_post_init(self):
        """Test post-initialization processing."""
        msg = Message(id="", timestamp=None)
        assert msg.id != ""  # Should generate new ID
        assert msg.timestamp is not None  # Should set timestamp


class TestAsyncMessageBroker:
    """Tests for the AsyncMessageBroker class."""
    
    @pytest.mark.asyncio
    async def test_broker_initialization(self):
        """Test broker initialization state."""
        broker = AsyncMessageBroker()
        assert broker.is_running is False
        assert len(broker._topic_queues) == 0
        assert len(broker._subscribers) == 0
        assert len(broker._direct_queues) == 0
    
    @pytest.mark.asyncio
    async def test_broker_start_stop(self):
        """Test starting and stopping the broker."""
        broker = AsyncMessageBroker()
        
        # Start broker
        await broker.start()
        assert broker.is_running is True
        
        # Starting again should log warning
        with patch('hecaton.messaging.message_broker.logger') as mock_logger:
            await broker.start()
            mock_logger.warning.assert_called_once()
        
        # Stop broker
        await broker.stop()
        assert broker.is_running is False
        assert len(broker._topic_queues) == 0
        assert len(broker._subscribers) == 0
        
        # Stopping again should log warning
        with patch('hecaton.messaging.message_broker.logger') as mock_logger:
            await broker.stop()
            mock_logger.warning.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_publish_without_start(self):
        """Test publishing without starting the broker raises error."""
        broker = AsyncMessageBroker()
        msg = Message(topic="test")
        
        with pytest.raises(RuntimeError, match="Message broker is not running"):
            await broker.publish("test", msg)
    
    @pytest.mark.asyncio
    async def test_publish_subscribe(self, broker, sample_message):
        """Test basic publish/subscribe functionality."""
        received_messages = []
        
        async def callback(msg):
            received_messages.append(msg)
        
        # Subscribe to topic
        await broker.subscribe("test_topic", callback)
        
        # Publish message
        await broker.publish("test_topic", sample_message)
        
        # Allow callback to execute
        await asyncio.sleep(0.1)
        
        assert len(received_messages) == 1
        assert received_messages[0].id == sample_message.id
        assert received_messages[0].topic == "test_topic"
    
    @pytest.mark.asyncio
    async def test_multiple_subscribers(self, broker):
        """Test multiple subscribers to same topic."""
        received_1 = []
        received_2 = []
        
        async def callback_1(msg):
            received_1.append(msg)
        
        async def callback_2(msg):
            received_2.append(msg)
        
        # Subscribe both callbacks
        await broker.subscribe("multi_test", callback_1)
        await broker.subscribe("multi_test", callback_2)
        
        # Publish message
        msg = Message(payload="test")
        await broker.publish("multi_test", msg)
        
        # Allow callbacks to execute
        await asyncio.sleep(0.1)
        
        assert len(received_1) == 1
        assert len(received_2) == 1
        assert received_1[0].id == msg.id
        assert received_2[0].id == msg.id
    
    @pytest.mark.asyncio
    async def test_unsubscribe(self, broker):
        """Test unsubscribing from a topic."""
        received = []
        
        async def callback(msg):
            received.append(msg)
        
        # Subscribe and publish
        await broker.subscribe("unsub_test", callback)
        msg1 = Message(payload="msg1")
        await broker.publish("unsub_test", msg1)
        await asyncio.sleep(0.1)
        
        assert len(received) == 1
        
        # Unsubscribe and publish again
        await broker.unsubscribe("unsub_test", callback)
        msg2 = Message(payload="msg2")
        await broker.publish("unsub_test", msg2)
        await asyncio.sleep(0.1)
        
        assert len(received) == 1  # Should not receive second message
    
    @pytest.mark.asyncio
    async def test_send_direct(self, broker):
        """Test sending direct messages to agents."""
        msg = Message(sender="agent_1", payload="direct_data")
        
        # Send direct message
        await broker.send_direct("agent_2", msg)
        
        # Receive message
        received = await broker.receive_direct("agent_2", timeout=1.0)
        
        assert received is not None
        assert received.id == msg.id
        assert received.receiver == "agent_2"
        assert received.payload == "direct_data"
    
    @pytest.mark.asyncio
    async def test_receive_direct_timeout(self, broker):
        """Test receiving direct message with timeout."""
        # Try to receive from empty queue
        received = await broker.receive_direct("agent_3", timeout=0.1)
        assert received is None
    
    @pytest.mark.asyncio
    async def test_receive_direct_no_timeout(self, broker):
        """Test receiving direct message without timeout."""
        msg = Message(payload="test")
        
        # Send message after delay
        async def delayed_send():
            await asyncio.sleep(0.1)
            await broker.send_direct("agent_4", msg)
        
        # Start send task
        asyncio.create_task(delayed_send())
        
        # Receive should wait for message
        received = await broker.receive_direct("agent_4")
        assert received is not None
        assert received.id == msg.id
    
    @pytest.mark.asyncio
    async def test_get_topic_messages(self, broker):
        """Test getting messages from topic queue without consuming."""
        # Publish multiple messages
        msg1 = Message(payload="msg1")
        msg2 = Message(payload="msg2")
        msg3 = Message(payload="msg3")
        
        await broker.publish("peek_test", msg1)
        await broker.publish("peek_test", msg2)
        await broker.publish("peek_test", msg3)
        
        # Get messages without consuming
        messages = await broker.get_topic_messages("peek_test", limit=2)
        assert len(messages) == 2
        assert messages[0].payload == "msg1"
        assert messages[1].payload == "msg2"
        
        # Messages should still be in queue
        all_messages = await broker.get_topic_messages("peek_test")
        assert len(all_messages) == 3
    
    @pytest.mark.asyncio
    async def test_clear_topic(self, broker):
        """Test clearing messages from a topic."""
        # Publish messages
        await broker.publish("clear_test", Message(payload="msg1"))
        await broker.publish("clear_test", Message(payload="msg2"))
        
        # Verify messages exist
        messages = await broker.get_topic_messages("clear_test")
        assert len(messages) == 2
        
        # Clear topic
        await broker.clear_topic("clear_test")
        
        # Verify messages are gone
        messages = await broker.get_topic_messages("clear_test")
        assert len(messages) == 0
    
    @pytest.mark.asyncio
    async def test_get_topics(self, broker):
        """Test getting list of active topics."""
        # Initially no topics
        topics = await broker.get_topics()
        assert len(topics) == 0
        
        # Publish to different topics
        await broker.publish("topic1", Message())
        await broker.publish("topic2", Message())
        await broker.publish("topic1", Message())  # Duplicate topic
        
        topics = await broker.get_topics()
        assert len(topics) == 2
        assert "topic1" in topics
        assert "topic2" in topics
    
    @pytest.mark.asyncio
    async def test_get_agents(self, broker):
        """Test getting list of agents with direct queues."""
        # Initially no agents
        agents = await broker.get_agents()
        assert len(agents) == 0
        
        # Send direct messages to different agents
        await broker.send_direct("agent1", Message())
        await broker.send_direct("agent2", Message())
        await broker.send_direct("agent1", Message())  # Duplicate agent
        
        agents = await broker.get_agents()
        assert len(agents) == 2
        assert "agent1" in agents
        assert "agent2" in agents
    
    @pytest.mark.asyncio
    async def test_sync_callback(self, broker):
        """Test using synchronous callback."""
        received = []
        
        def sync_callback(msg):
            received.append(msg)
        
        await broker.subscribe("sync_test", sync_callback)
        await broker.publish("sync_test", Message(payload="sync"))
        
        # Allow callback to execute
        await asyncio.sleep(0.1)
        
        assert len(received) == 1
        assert received[0].payload == "sync"
    
    @pytest.mark.asyncio
    async def test_callback_error_handling(self, broker):
        """Test error handling in callbacks."""
        async def failing_callback(msg):
            raise ValueError("Test error")
        
        # Subscribe failing callback
        await broker.subscribe("error_test", failing_callback)
        
        # Publishing should not raise error
        with patch('hecaton.messaging.message_broker.logger') as mock_logger:
            await broker.publish("error_test", Message())
            await asyncio.sleep(0.1)
            
            # Error should be logged
            assert mock_logger.error.called
    
    @pytest.mark.asyncio
    async def test_concurrent_publish(self, broker):
        """Test concurrent publishing to same topic."""
        received = []
        
        async def callback(msg):
            received.append(msg)
        
        await broker.subscribe("concurrent", callback)
        
        # Publish messages concurrently
        tasks = [
            broker.publish("concurrent", Message(payload=i))
            for i in range(10)
        ]
        await asyncio.gather(*tasks)
        
        # Allow callbacks to complete
        await asyncio.sleep(0.2)
        
        assert len(received) == 10
        payloads = {msg.payload for msg in received}
        assert payloads == set(range(10))
    
    @pytest.mark.asyncio
    async def test_broker_cleanup_on_stop(self, broker):
        """Test that broker properly cleans up resources on stop."""
        # Set up some state
        await broker.subscribe("cleanup", lambda msg: None)
        await broker.publish("cleanup", Message())
        await broker.send_direct("agent", Message())
        
        # Verify state exists
        assert len(await broker.get_topics()) > 0
        assert len(await broker.get_agents()) > 0
        
        # Stop broker
        await broker.stop()
        
        # Start new broker and verify clean state
        await broker.start()
        assert len(await broker.get_topics()) == 0
        assert len(await broker.get_agents()) == 0
    
    @pytest.mark.asyncio
    async def test_message_ordering(self, broker):
        """Test that messages maintain order within topics and direct queues."""
        received_topic = []
        
        async def callback(msg):
            received_topic.append(msg.payload)
        
        await broker.subscribe("order_test", callback)
        
        # Publish ordered messages to topic
        for i in range(5):
            await broker.publish("order_test", Message(payload=i))
        
        # Send ordered direct messages
        for i in range(5):
            await broker.send_direct("ordered_agent", Message(payload=i))
        
        # Allow topic callbacks to complete
        await asyncio.sleep(0.1)
        
        # Verify topic order
        assert received_topic == list(range(5))
        
        # Verify direct message order
        direct_messages = []
        for _ in range(5):
            msg = await broker.receive_direct("ordered_agent", timeout=1.0)
            direct_messages.append(msg.payload)
        
        assert direct_messages == list(range(5))