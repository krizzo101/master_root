#!/usr/bin/env python3
"""
End-to-end golden path test for HECATON parallel execution.

Tests:
- 2 agents (code + test) running in parallel
- No worktree collisions
- Proper token rotation
- Performance improvement over sequential
"""

import asyncio
import os
import sys
import time
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from hecaton.agents.real_claude_executor import RealClaudeSubprocessExecutor
from hecaton.orchestration.send_api import SendAPIOrchestrator
from hecaton.resources.secure_token_pool import SecureTokenPool
from hecaton.resources.worktree import WorktreeManager
from hecaton.monitoring.performance_monitor import PerformanceMonitor


async def test_golden_path():
    """
    Golden path test: 2 agents complete task in parallel.
    
    Success criteria:
    - Both agents complete
    - No worktree collisions
    - Total time < sequential baseline
    - Proper cleanup
    """
    print("\n" + "="*60)
    print("HECATON E2E GOLDEN PATH TEST")
    print("="*60 + "\n")
    
    # Initialize components
    try:
        # Token pool with round-robin CLAUDE_CODE_TOKENs
        token_pool = SecureTokenPool()
        token_count = token_pool.get_token_count()
        print(f"✅ Token pool initialized with {token_count} tokens")
        
        # Worktree manager for isolation
        worktree_manager = WorktreeManager(
            base_path="/tmp/hecaton_test_worktrees",
            repo_path=os.getcwd()
        )
        print(f"✅ Worktree manager initialized")
        
        # Performance monitor
        perf_monitor = PerformanceMonitor()
        print(f"✅ Performance monitor initialized")
        
        # Real Claude executor
        executor = RealClaudeSubprocessExecutor(
            token_pool=token_pool,
            worktree_manager=worktree_manager
        )
        print(f"✅ Claude executor initialized")
        
        # Send API orchestrator (max 2 parallel)
        orchestrator = SendAPIOrchestrator(
            executor=executor,
            token_pool=token_pool,
            worktree_manager=worktree_manager,
            performance_monitor=perf_monitor,
            max_parallel=2
        )
        print(f"✅ Send API orchestrator initialized\n")
        
    except Exception as e:
        print(f"❌ Initialization failed: {e}")
        return False
    
    # Test task
    test_task = """
    Create a simple Python function that calculates fibonacci numbers.
    Include proper docstring and type hints.
    """
    
    # Run parallel execution
    print("🚀 Starting parallel execution with 2 agents (code + test)...")
    print("-" * 40)
    
    start_time = time.time()
    
    try:
        # Execute with Send API
        result = await orchestrator.execute(
            task=test_task,
            num_agents=2  # Code and test agents
        )
        
        elapsed = time.time() - start_time
        
        # Check results
        print("\n" + "-" * 40)
        print("📊 RESULTS:")
        
        success = True
        
        # Verify both agents completed
        metrics = result.get("metrics", {})
        if metrics.get("completed", 0) < 2:
            print(f"❌ Not all agents completed: {metrics.get('completed')}/2")
            success = False
        else:
            print(f"✅ Both agents completed successfully")
        
        # Check for errors
        errors = result.get("errors", [])
        if errors:
            print(f"⚠️  Errors encountered: {errors}")
            success = False
        else:
            print(f"✅ No errors reported")
        
        # Performance check
        print(f"\n📈 Performance:")
        print(f"   Total time: {elapsed:.2f}s")
        
        # Sequential baseline (rough estimate: 2x single agent time)
        avg_agent_time = metrics.get("avg_execution_time", elapsed/2)
        sequential_estimate = avg_agent_time * 2
        speedup = sequential_estimate / elapsed if elapsed > 0 else 1.0
        
        print(f"   Est. sequential time: {sequential_estimate:.2f}s")
        print(f"   Speedup: {speedup:.2f}x")
        
        if speedup < 1.5:
            print(f"⚠️  Speedup below target (1.5x)")
            success = False
        else:
            print(f"✅ Good parallelization speedup")
        
        # Check agent results
        print(f"\n📝 Agent outputs:")
        for agent_id, agent_result in result.get("results", {}).items():
            status = agent_result.get("status")
            agent_type = agent_result.get("type")
            print(f"   {agent_type}: {status}")
        
        # Cleanup check
        print(f"\n🧹 Cleanup:")
        worktrees_cleaned = True
        test_worktree_path = Path("/tmp/hecaton_test_worktrees")
        if test_worktree_path.exists():
            remaining = list(test_worktree_path.glob("agent_*"))
            if remaining:
                print(f"⚠️  {len(remaining)} worktrees not cleaned up")
                worktrees_cleaned = False
            else:
                print(f"✅ All worktrees cleaned up")
        
        # Final verdict
        print("\n" + "="*60)
        if success and worktrees_cleaned:
            print("✅ GOLDEN PATH TEST PASSED")
            print(f"   - 2 agents ran in parallel")
            print(f"   - No worktree collisions")
            print(f"   - {speedup:.2f}x speedup achieved")
            print(f"   - Proper cleanup completed")
            return True
        else:
            print("❌ GOLDEN PATH TEST FAILED")
            return False
            
    except Exception as e:
        print(f"\n❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Ensure cleanup
        try:
            # Force cleanup any remaining worktrees
            remaining = list(Path("/tmp/hecaton_test_worktrees").glob("agent_*"))
            for worktree in remaining:
                worktree_manager.cleanup(worktree.name, force=True)
        except:
            pass


async def test_rate_limiting():
    """Test backpressure with rate limiting"""
    print("\n" + "="*60)
    print("RATE LIMITING TEST")
    print("="*60 + "\n")
    
    # This would test with artificially limited token pool
    # to verify backpressure handling
    
    print("⏭️  Rate limiting test not yet implemented")
    return True


async def main():
    """Run all e2e tests"""
    
    # Check for required tokens
    token_count = 0
    for i in range(1, 16):
        if os.getenv(f"CLAUDE_CODE_TOKEN_{i}"):
            token_count += 1
    
    if token_count < 2:
        print("❌ Need at least 2 CLAUDE_CODE_TOKEN_* environment variables for parallel test")
        print("   Set CLAUDE_CODE_TOKEN_1 and CLAUDE_CODE_TOKEN_2")
        return 1
    
    print(f"Found {token_count} Claude tokens for testing\n")
    
    # Run tests
    tests_passed = 0
    tests_total = 0
    
    # Golden path test
    tests_total += 1
    if await test_golden_path():
        tests_passed += 1
    
    # Rate limiting test
    tests_total += 1
    if await test_rate_limiting():
        tests_passed += 1
    
    # Summary
    print("\n" + "="*60)
    print(f"E2E TEST SUMMARY: {tests_passed}/{tests_total} passed")
    print("="*60)
    
    return 0 if tests_passed == tests_total else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))