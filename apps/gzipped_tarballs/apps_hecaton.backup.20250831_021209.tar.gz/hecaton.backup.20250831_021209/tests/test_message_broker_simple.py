#!/usr/bin/env python3
"""Simple test script for the message broker."""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.hecaton.messaging.message_broker import Message, MessageBroker


async def test_basic_functionality():
    """Test basic message broker functionality."""
    print("Testing HECATON Message Broker...")
    print("-" * 50)
    
    # Initialize broker
    broker = MessageBroker()
    print("✓ Message broker initialized")
    
    # Start broker
    await broker.start()
    print("✓ Message broker started")
    
    # Test 1: Basic pub/sub
    print("\nTest 1: Basic Publish/Subscribe")
    received_messages = []
    
    async def test_callback(message):
        received_messages.append(message)
    
    await broker.subscribe("test-topic", test_callback)
    print("  ✓ Subscribed to test-topic")
    
    msg = Message(sender="test-publisher", topic="test-topic", payload="Hello, HECATON!")
    await broker.publish("test-topic", msg)
    print("  ✓ Published message to test-topic")
    
    await asyncio.sleep(0.1)  # Wait for callback
    assert len(received_messages) == 1
    assert received_messages[0].payload == "Hello, HECATON!"
    print("  ✓ Message received via callback")
    
    # Test 2: Direct messaging
    print("\nTest 2: Direct Messaging")
    direct_msg = Message(sender="agent1", payload="Direct message to agent2")
    await broker.send_direct("agent2", direct_msg)
    print("  ✓ Sent direct message to agent2")
    
    received = await broker.receive_direct("agent2", timeout=1.0)
    assert received is not None
    assert received.payload == "Direct message to agent2"
    assert received.receiver == "agent2"
    print("  ✓ Received direct message")
    
    # Test 3: Multiple subscribers
    print("\nTest 3: Multiple Subscribers")
    received1, received2 = [], []
    
    async def callback1(msg):
        received1.append(msg)
    
    async def callback2(msg):
        received2.append(msg)
    
    await broker.subscribe("multi-topic", callback1)
    await broker.subscribe("multi-topic", callback2)
    print("  ✓ Added two subscribers to multi-topic")
    
    multi_msg = Message(sender="publisher", payload="Broadcast message")
    await broker.publish("multi-topic", multi_msg)
    print("  ✓ Published broadcast message")
    
    await asyncio.sleep(0.1)
    assert len(received1) == 1
    assert len(received2) == 1
    assert received1[0].id == received2[0].id
    print("  ✓ Both subscribers received the message")
    
    # Test 4: Topic management
    print("\nTest 4: Topic Management")
    topics = await broker.get_topics()
    assert "test-topic" in topics
    assert "multi-topic" in topics
    print(f"  ✓ Active topics: {topics}")
    
    agents = await broker.get_agents()
    assert "agent2" in agents
    print(f"  ✓ Agents with queues: {agents}")
    
    # Test 5: Message queuing
    print("\nTest 5: Message Queuing")
    for i in range(3):
        await broker.send_direct("agent3", Message(payload=f"Message {i}"))
    print("  ✓ Queued 3 messages for agent3")
    
    messages = []
    for _ in range(3):
        msg = await broker.receive_direct("agent3", timeout=1.0)
        if msg:
            messages.append(msg)
    
    assert len(messages) == 3
    assert messages[0].payload == "Message 0"
    assert messages[1].payload == "Message 1"
    assert messages[2].payload == "Message 2"
    print("  ✓ Messages received in correct order")
    
    # Stop broker
    await broker.stop()
    print("\n✓ Message broker stopped")
    
    print("\n" + "=" * 50)
    print("ALL TESTS PASSED! ✅")
    print("Message broker is fully functional.")
    return True


async def main():
    """Main test runner."""
    try:
        success = await test_basic_functionality()
        return 0 if success else 1
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(result)