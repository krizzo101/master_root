"""
Integration test for Phase 2 Enhanced Workflow patterns
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from hecaton.workflows.handoff_protocol import HandoffProtocol, HandoffPackage, HandoffReason
from hecaton.workflows.progressive_autonomy import (
    ProgressiveAutonomyManager, AutonomyLevel, ActionCategory
)
from hecaton.workflows.quality_gates import (
    SDLCQualityGates, SDLCPhase, ValidationStatus, QualityGate
)


async def test_handoff_workflow():
    """Test agent handoff protocol"""
    
    print("=" * 60)
    print("HANDOFF PROTOCOL TEST")
    print("=" * 60)
    
    handoff_protocol = HandoffProtocol()
    
    # Simulate a complex task requiring multiple handoffs
    task_context = {
        "task_id": "TASK-001",
        "project": "E-commerce Platform",
        "description": "Implement user authentication feature"
    }
    
    # Phase 1: Requirements gathering agent hands off to design agent
    print("\n1. Creating handoff from requirements to design agent...")
    
    handoff1 = await handoff_protocol.prepare_handoff(
        from_agent_id="agent_requirements",
        to_agent_id="agent_architect",
        reason=HandoffReason.PHASE_TRANSITION,
        task_context=task_context,
        completed_work={
            "requirements_gathered": True,
            "user_stories": ["US-001", "US-002", "US-003"],
            "acceptance_criteria": "Defined for all stories"
        },
        remaining_work=["Design system architecture", "Define API contracts", "Create UI mockups"],
        recommendations=["Consider OAuth2 for authentication", "Use JWT tokens for session management"],
        artifacts={
            "requirements_doc": "/docs/auth_requirements.md",
            "user_stories": "/docs/user_stories.yaml"
        }
    )
    
    print(f"   Handoff ID: {handoff1.handoff_id}")
    print(f"   Validation: {handoff1.validation_passed}")
    print(f"   Recommendations: {handoff1.recommendations}")
    
    # Execute the handoff
    success = await handoff_protocol.execute_handoff(handoff1.handoff_id)
    print(f"   Execution: {'✅ Success' if success else '❌ Failed'}")
    
    # Phase 2: Design agent encounters issue, needs specialist
    print("\n2. Creating error recovery handoff to security specialist...")
    
    handoff2 = await handoff_protocol.prepare_handoff(
        from_agent_id="agent_architect",
        to_agent_id="agent_security",
        reason=HandoffReason.SPECIALIZATION,
        task_context={**task_context, "security_concern": "OAuth2 implementation complexity"},
        completed_work={
            "architecture_design": "90% complete",
            "api_contracts": "Drafted",
            "security_review": "Identified concerns"
        },
        remaining_work=["Security architecture review", "OAuth2 implementation guide"],
        recommendations=["Review OWASP guidelines", "Consider using established OAuth library"],
        artifacts={
            "architecture_doc": "/docs/auth_architecture.md",
            "security_concerns": "/docs/security_review.md"
        }
    )
    
    print(f"   Handoff ID: {handoff2.handoff_id}")
    print(f"   Reason: {handoff2.reason.value}")
    
    # Check pending handoffs
    pending = handoff_protocol.get_pending_handoffs("agent_security")
    print(f"   Pending for security agent: {len(pending)}")
    
    # Execute handoff
    await handoff_protocol.execute_handoff(handoff2.handoff_id)
    
    # Get handoff statistics
    stats = handoff_protocol.get_handoff_statistics()
    print(f"\n3. Handoff Statistics:")
    print(f"   Total: {stats['total_handoffs']}")
    print(f"   By reason: {stats['by_reason']}")
    print(f"   Success rate: {stats['success_rate']:.1%}")
    
    return True


async def test_progressive_autonomy():
    """Test progressive autonomy management"""
    
    print("\n" + "=" * 60)
    print("PROGRESSIVE AUTONOMY TEST")
    print("=" * 60)
    
    autonomy_manager = ProgressiveAutonomyManager()
    
    # Register agents with different initial levels
    agents = [
        ("agent_junior", AutonomyLevel.MINIMAL),
        ("agent_senior", AutonomyLevel.MODERATE),
        ("agent_expert", AutonomyLevel.HIGH)
    ]
    
    for agent_id, level in agents:
        autonomy_manager.register_agent(agent_id, level)
        print(f"\n1. Registered {agent_id} with autonomy level: {level.name}")
    
    # Test permission checks for different actions
    print("\n2. Testing permission checks...")
    
    test_actions = [
        (ActionCategory.READ, 0.9),
        (ActionCategory.MODIFY, 0.8),
        (ActionCategory.DELETE, 0.7),
        (ActionCategory.DEPLOY, 0.9)
    ]
    
    for agent_id, _ in agents:
        print(f"\n   Agent: {agent_id}")
        for action, confidence in test_actions:
            allowed, requires_approval, reason = await autonomy_manager.check_permission(
                agent_id, action, confidence
            )
            status = "✅" if allowed else ("⚠️" if requires_approval else "❌")
            print(f"   {status} {action.value}: {reason}")
    
    # Simulate task execution and metric updates
    print("\n3. Simulating task execution and metric updates...")
    
    # Junior agent performs well
    for i in range(15):
        await autonomy_manager.update_metrics(
            "agent_junior",
            task_success=i % 10 != 0,  # 90% success
            task_duration=10.0 + i,
            confidence_score=0.85 + i * 0.01
        )
    
    # Senior agent has mixed results
    for i in range(15):
        await autonomy_manager.update_metrics(
            "agent_senior",
            task_success=i % 3 != 0,  # 67% success
            task_duration=15.0 + i * 2,
            confidence_score=0.6 + i * 0.02
        )
    
    # Check updated autonomy levels
    print("\n4. Checking autonomy adjustments...")
    
    for agent_id, _ in agents:
        status = autonomy_manager.get_agent_status(agent_id)
        print(f"\n   {agent_id}:")
        print(f"   Level: {status['autonomy_level']} (value: {status['level_value']})")
        print(f"   Success rate: {status['metrics']['success_rate']:.1%}")
        print(f"   Avg confidence: {status['metrics']['avg_confidence']:.2f}")
        print(f"   Allowed actions: {', '.join(status['allowed_actions'][:3])}...")
    
    # Check adjustment history
    history = autonomy_manager.get_adjustment_history()
    if history:
        print(f"\n5. Autonomy adjustments made: {len(history)}")
        for adj in history:
            if adj.get("type") != "override":
                print(f"   {adj['agent_id']}: {adj['old_level']} -> {adj['new_level']}")
    
    return True


async def test_quality_gates():
    """Test SDLC quality gates"""
    
    print("\n" + "=" * 60)
    print("SDLC QUALITY GATES TEST")
    print("=" * 60)
    
    quality_gates = SDLCQualityGates()
    
    # Test progression through SDLC phases
    phases = [
        (SDLCPhase.PLANNING, {
            "artifacts": {
                "requirements_doc": "requirements.md",
                "user_stories": "stories.yaml"
            },
            "metrics": {
                "min_requirements": 5,
                "clarity_score": 0.85
            }
        }),
        (SDLCPhase.DESIGN, {
            "artifacts": {
                "design_doc": "design.md",
                "architecture_diagram": "arch.png"
            },
            "metrics": {
                "review_approved": True,
                "patterns_documented": True
            }
        }),
        (SDLCPhase.DEVELOPMENT, {
            "artifacts": {
                "source_code": "src/"
            },
            "metrics": {
                "coverage": 0.85,
                "lint_pass": True,
                "no_critical_issues": True
            }
        }),
        (SDLCPhase.TESTING, {
            "artifacts": {
                "test_suite": "tests/",
                "test_results": "results.xml"
            },
            "metrics": {
                "min_coverage": 0.82,
                "all_tests_pass": True
            }
        })
    ]
    
    print("\n1. Validating SDLC phases...")
    
    for phase, context in phases:
        print(f"\n   Phase: {phase.value}")
        
        passed, results = await quality_gates.validate_phase(phase, context)
        
        print(f"   Overall: {'✅ Passed' if passed else '❌ Failed'}")
        print(f"   Checks: {len(results)} total")
        
        # Show individual results
        for result in results:
            icon = {
                ValidationStatus.PASSED: "✅",
                ValidationStatus.FAILED: "❌",
                ValidationStatus.WARNING: "⚠️",
                ValidationStatus.SKIPPED: "⏭️"
            }.get(result.status, "❓")
            
            print(f"     {icon} {result.check_name}: {result.message[:50]}...")
    
    # Test phase transition
    print("\n2. Testing phase transitions...")
    
    from_phase = SDLCPhase.DEVELOPMENT
    to_phase = SDLCPhase.TESTING
    
    can_transition, reason = await quality_gates.can_transition(
        from_phase, to_phase, phases[2][1]  # Use development context
    )
    
    print(f"   Transition {from_phase.value} -> {to_phase.value}")
    print(f"   Allowed: {'✅' if can_transition else '❌'}")
    print(f"   Reason: {reason}")
    
    # Get validation summary
    summary = quality_gates.get_validation_summary()
    print(f"\n3. Validation Summary:")
    print(f"   Total validations: {summary['total_validations']}")
    print(f"   Success rate: {summary.get('success_rate', 0):.1%}")
    print(f"   Phase breakdowns: {summary.get('by_phase', {})}")
    
    # Test custom gate registration
    print("\n4. Testing custom quality gate...")
    
    custom_gate = QualityGate(
        name="security_scan",
        phase=SDLCPhase.DEPLOYMENT,
        description="Security vulnerability scan",
        required_artifacts=["scan_report"],
        success_criteria={"vulnerabilities": 0, "scan_complete": True}
    )
    
    quality_gates.register_gate(custom_gate)
    
    # Validate with custom gate
    deployment_context = {
        "artifacts": {
            "deployment_plan": "deploy.yaml",
            "rollback_plan": "rollback.md",
            "scan_report": "security_scan.json"
        },
        "metrics": {
            "staging_tested": True,
            "approval_received": True,
            "vulnerabilities": 0,
            "scan_complete": True
        }
    }
    
    passed, results = await quality_gates.validate_phase(SDLCPhase.DEPLOYMENT, deployment_context)
    print(f"   Deployment validation: {'✅ Passed' if passed else '❌ Failed'}")
    
    security_results = [r for r in results if "security" in r.check_name]
    if security_results:
        print(f"   Security scan: {security_results[0].status.value}")
    
    return True


async def test_integrated_workflow():
    """Test all Phase 2 components working together"""
    
    print("\n" + "=" * 60)
    print("INTEGRATED WORKFLOW TEST")
    print("=" * 60)
    
    # Initialize all components
    handoff_protocol = HandoffProtocol()
    autonomy_manager = ProgressiveAutonomyManager()
    quality_gates = SDLCQualityGates()
    
    print("\n1. Setting up integrated workflow...")
    
    # Register agents
    agents = [
        ("planner", AutonomyLevel.MODERATE),
        ("developer", AutonomyLevel.HIGH),
        ("tester", AutonomyLevel.MODERATE)
    ]
    
    for agent_id, level in agents:
        autonomy_manager.register_agent(agent_id, level)
    
    # Simulate workflow through phases
    workflow_phases = [
        (SDLCPhase.PLANNING, "planner"),
        (SDLCPhase.DEVELOPMENT, "developer"),
        (SDLCPhase.TESTING, "tester")
    ]
    
    current_context = {
        "task_id": "FEAT-001",
        "project": "Test Project"
    }
    
    print("\n2. Executing workflow through phases...")
    
    for i, (phase, agent_id) in enumerate(workflow_phases):
        print(f"\n   Phase {i+1}: {phase.value} (Agent: {agent_id})")
        
        # Check agent permissions
        can_modify, _, _ = await autonomy_manager.check_permission(
            agent_id, ActionCategory.MODIFY, confidence=0.9
        )
        print(f"   Can modify: {'✅' if can_modify else '❌'}")
        
        # Prepare phase context
        phase_context = {
            **current_context,
            "artifacts": {f"{phase.value}_artifact": f"{phase.value}.md"},
            "metrics": {"generic_metric": 1.0}
        }
        
        # Validate phase gates (simplified)
        passed, _ = await quality_gates.validate_phase(phase, phase_context)
        print(f"   Quality gates: {'✅ Passed' if passed else '⚠️ Warning'}")
        
        # Create handoff to next agent if not last phase
        if i < len(workflow_phases) - 1:
            next_agent = workflow_phases[i + 1][1]
            
            handoff = await handoff_protocol.prepare_handoff(
                from_agent_id=agent_id,
                to_agent_id=next_agent,
                reason=HandoffReason.PHASE_TRANSITION,
                task_context=current_context,
                completed_work={f"{phase.value}_complete": True},
                remaining_work=[f"Complete {workflow_phases[i+1][0].value}"],
                recommendations=[f"Focus on quality in {workflow_phases[i+1][0].value}"]
            )
            
            await handoff_protocol.execute_handoff(handoff.handoff_id)
            print(f"   Handoff to {next_agent}: ✅")
        
        # Update agent metrics
        await autonomy_manager.update_metrics(
            agent_id,
            task_success=True,
            task_duration=10.0,
            confidence_score=0.9
        )
    
    print("\n3. Workflow Summary:")
    print(f"   Handoffs executed: {len(handoff_protocol.handoff_history)}")
    print(f"   Quality validations: {len(quality_gates.validation_history)}")
    print(f"   Phases completed: {len(workflow_phases)}")
    
    print("\n✅ Integrated workflow completed successfully!")
    
    return True


async def main():
    """Run all Phase 2 integration tests"""
    
    try:
        print("\n🚀 PHASE 2 ENHANCED WORKFLOWS - INTEGRATION TESTS\n")
        
        # Test individual components
        await test_handoff_workflow()
        await test_progressive_autonomy()
        await test_quality_gates()
        
        # Test integrated workflow
        await test_integrated_workflow()
        
        print("\n" + "=" * 60)
        print("✅ ALL PHASE 2 TESTS PASSED SUCCESSFULLY!")
        print("=" * 60)
        
        return 0
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)