"""
Integration test for Phase 1 patterns working together
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from hecaton.safety.checkpoint_manager import CheckpointManager
from hecaton.safety.error_boundaries import ErrorBoundary, ErrorResult
from hecaton.agents.meta_agent import MetaAgent, AgentProfile, AgentCapability
from hecaton.swarm.swarm_decomposer import SwarmTaskDecomposer


async def test_integrated_workflow():
    """Test all Phase 1 components working together"""
    
    print("=" * 60)
    print("PHASE 1 INTEGRATION TEST")
    print("=" * 60)
    
    # 1. Initialize components
    checkpoint_manager = CheckpointManager()
    error_boundary = ErrorBoundary(max_retries=2)
    meta_agent = MetaAgent()
    swarm_decomposer = SwarmTaskDecomposer()
    
    print("\n1. Components initialized successfully")
    
    # 2. Register some test agents with the meta-agent
    agents = [
        AgentProfile(
            agent_id="agent_research",
            capabilities=[AgentCapability.RESEARCH, AgentCapability.DOCUMENTATION],
            performance_score=0.9,
            current_load=0.2,
            success_rate=0.95,
            avg_response_time=5.0,
            specializations={"research": 0.9, "documentation": 0.8}
        ),
        AgentProfile(
            agent_id="agent_coder",
            capabilities=[AgentCapability.CODING, AgentCapability.TESTING],
            performance_score=0.85,
            current_load=0.5,
            success_rate=0.90,
            avg_response_time=8.0,
            specializations={"coding": 0.95, "testing": 0.7}
        ),
        AgentProfile(
            agent_id="agent_reviewer",
            capabilities=[AgentCapability.REVIEW, AgentCapability.SECURITY],
            performance_score=0.88,
            current_load=0.3,
            success_rate=0.92,
            avg_response_time=6.0,
            specializations={"review": 0.85, "security": 0.8}
        )
    ]
    
    for agent in agents:
        meta_agent.register_agent(agent)
    
    print(f"2. Registered {len(agents)} agents with meta-agent")
    
    # 3. Define a complex task
    complex_task = {
        "type": "code_implementation",
        "description": "Implement a new feature with testing",
        "requirements": ["research", "coding", "testing", "documentation"]
    }
    
    print(f"\n3. Created complex task: {complex_task['type']}")
    
    # 4. Create initial checkpoint
    initial_state = {
        "task": complex_task,
        "status": "started",
        "agents": [a.agent_id for a in agents]
    }
    
    checkpoint_id = await checkpoint_manager.create_checkpoint(initial_state)
    print(f"4. Created checkpoint: {checkpoint_id}")
    
    # 5. Decompose task using swarm decomposer
    execution_groups = await swarm_decomposer.decompose_task(complex_task)
    print(f"\n5. Task decomposed into {len(execution_groups)} execution groups:")
    
    for group in execution_groups:
        print(f"   Group {group.group_id}: {len(group.tasks)} tasks, "
              f"parallel={group.can_parallelize}, "
              f"duration={group.total_estimated_duration:.1f}s")
    
    # 6. Process each execution group with error boundaries
    results = []
    
    for group in execution_groups:
        print(f"\n6. Processing execution group {group.group_id}...")
        
        for task_node in group.tasks:
            # Wrap task execution in error boundary
            async def execute_task():
                # Delegate to appropriate agent
                decision = await meta_agent.decide_delegation({
                    "type": task_node.task_type,
                    "description": task_node.description
                })
                
                print(f"   - Task '{task_node.task_id}' delegated to {decision.agent_id} "
                      f"(confidence: {decision.confidence:.2f})")
                
                # Simulate task execution
                if task_node.task_id == "write_tests":
                    # Simulate a recoverable error
                    raise ValueError("Test framework not configured")
                
                return {
                    "task_id": task_node.task_id,
                    "agent": decision.agent_id,
                    "status": "completed"
                }
            
            # Execute with error boundary
            result = await error_boundary.execute_with_boundary(
                execute_task,
                context={"task_id": task_node.task_id}
            )
            
            if isinstance(result, ErrorResult):
                print(f"   ⚠️ Task '{task_node.task_id}' failed: {result.error}")
                print(f"      Severity: {result.severity.value}, "
                      f"Recoverable: {result.recoverable}")
                if result.suggested_action:
                    print(f"      Suggestion: {result.suggested_action}")
                
                # Create recovery checkpoint
                recovery_state = {
                    "task": complex_task,
                    "status": "error_recovery",
                    "failed_task": task_node.task_id,
                    "error": str(result.error)
                }
                recovery_checkpoint = await checkpoint_manager.create_checkpoint(recovery_state)
                print(f"      Created recovery checkpoint: {recovery_checkpoint}")
            else:
                print(f"   ✅ Task '{task_node.task_id}' completed successfully")
                results.append(result)
    
    # 7. Show critical path
    critical_path = swarm_decomposer.get_critical_path()
    if critical_path:
        print(f"\n7. Critical path: {' -> '.join(critical_path)}")
    
    # 8. Show task graph visualization
    print("\n8. Task Decomposition Visualization:")
    print(swarm_decomposer.visualize_graph())
    
    # 9. Update agent performance based on results
    for result in results:
        if isinstance(result, dict) and "agent" in result:
            meta_agent.update_agent_performance(
                result["agent"],
                {"success": True, "response_time": 5.0}
            )
    
    print("\n9. Updated agent performance metrics")
    
    # 10. Show final checkpoint history
    checkpoints = await checkpoint_manager.list_checkpoints()
    print(f"\n10. Total checkpoints created: {len(checkpoints)}")
    
    print("\n" + "=" * 60)
    print("INTEGRATION TEST COMPLETED SUCCESSFULLY")
    print("=" * 60)
    
    return True


async def test_error_recovery_workflow():
    """Test error recovery with checkpoints"""
    
    print("\n" + "=" * 60)
    print("ERROR RECOVERY WORKFLOW TEST")
    print("=" * 60)
    
    checkpoint_manager = CheckpointManager()
    error_boundary = ErrorBoundary(max_retries=1)
    
    # Create multiple checkpoints
    states = [
        {"step": 1, "data": "initial"},
        {"step": 2, "data": "processing"},
        {"step": 3, "data": "nearly_done"}
    ]
    
    checkpoint_ids = []
    for state in states:
        ckpt_id = await checkpoint_manager.create_checkpoint(state)
        checkpoint_ids.append(ckpt_id)
        print(f"Created checkpoint {ckpt_id} for step {state['step']}")
    
    # Simulate a failure
    async def failing_operation():
        raise RuntimeError("Critical failure at step 4")
    
    result = await error_boundary.execute_with_boundary(failing_operation)
    
    if isinstance(result, ErrorResult):
        print(f"\nOperation failed: {result.error}")
        print(f"Rolling back to checkpoint {checkpoint_ids[-2]}...")
        
        restored_state = await checkpoint_manager.rollback_to_checkpoint(checkpoint_ids[-2])
        print(f"Restored to state: {restored_state}")
        
        # Verify remaining checkpoints
        remaining = await checkpoint_manager.list_checkpoints()
        print(f"Remaining checkpoints: {len(remaining)}")
    
    print("\nError recovery test completed")
    return True


async def main():
    """Run all integration tests"""
    
    try:
        # Run integrated workflow test
        await test_integrated_workflow()
        
        # Run error recovery test
        await test_error_recovery_workflow()
        
        print("\n✅ ALL INTEGRATION TESTS PASSED")
        return 0
        
    except Exception as e:
        print(f"\n❌ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)