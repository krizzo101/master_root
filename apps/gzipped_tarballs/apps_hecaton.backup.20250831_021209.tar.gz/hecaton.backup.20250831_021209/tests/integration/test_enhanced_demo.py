#!/usr/bin/env python3
"""
Demonstration of HECATON Enhanced Orchestrator functionality.
This creates input sets that demonstrate the enhanced features.
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from hecaton.config.config_loader import ConfigLoader
from hecaton.orchestration.enhanced_orchestrator import EnhancedOrchestrator
from hecaton.resources.secure_token_pool import SecureTokenPool
from hecaton.resources.worktree import WorktreeManager

# Input sets for demonstrating functionality
INPUT_SETS = {
    "simple_task": {
        "description": "Simple hello world task",
        "task": "Write a Python function that returns 'Hello, World!'",
        "num_agents": 1,
        "expected_flow": [
            "Create checkpoint",
            "Execute with single agent", 
            "Validate quality gates",
            "Return result"
        ]
    },
    
    "complex_task": {
        "description": "Complex multi-component task",
        "task": "Build a FastAPI REST API with JWT authentication, PostgreSQL database, and comprehensive test suite",
        "num_agents": 4,
        "expected_flow": [
            "Task decomposition into subtasks",
            "Agent assignment based on capabilities",
            "Parallel execution groups",
            "Progressive autonomy adjustments",
            "Quality gate validation at each phase",
            "Agent handoffs between phases",
            "Checkpoint creation for recovery"
        ]
    },
    
    "error_recovery": {
        "description": "Task with simulated failure and recovery",
        "task": "Process data with intentional error for testing recovery",
        "num_agents": 2,
        "expected_flow": [
            "Initial execution attempt",
            "Error boundary catches failure",
            "Checkpoint rollback",
            "Retry with adjusted parameters",
            "Successful recovery"
        ]
    },
    
    "phased_workflow": {
        "description": "Full SDLC workflow with phase transitions",
        "task": "Complete software project: requirements, design, implementation, testing, deployment",
        "num_agents": 5,
        "expected_flow": [
            "Requirements gathering (PLANNING phase)",
            "System design (DESIGN phase)",
            "Implementation (DEVELOPMENT phase)",
            "Testing (TESTING phase)",
            "Deployment (DEPLOYMENT phase)",
            "Quality gates at each transition",
            "Agent handoffs between phases"
        ]
    }
}


class MockExecutor:
    """Mock executor that simulates agent execution without real Claude calls"""
    
    def __init__(self):
        self.execution_count = 0
        self.failure_rate = 0.1  # 10% failure rate for testing
    
    async def execute_task(self, task):
        """Simulate task execution"""
        await asyncio.sleep(0.01)  # Simulate work
        
        self.execution_count += 1
        
        # Simulate occasional failures
        import random
        if random.random() < self.failure_rate and self.execution_count < 3:
            return {
                "status": "failed",
                "error": "Simulated error for testing recovery",
                "task": task
            }
        
        # Return success with mock output
        return {
            "status": "completed",
            "output": f"Mock execution result for: {task.get('prompt', 'task')}",
            "success": True,
            "task": task,
            "artifacts": {
                "code": "# Mock generated code",
                "tests": "# Mock test suite",
                "docs": "# Mock documentation"
            }
        }


async def demonstrate_input_set(name: str, input_set: dict):
    """Demonstrate an input set through the enhanced orchestrator"""
    
    print(f"\n{'=' * 80}")
    print(f"DEMONSTRATING: {input_set['description']}")
    print(f"{'=' * 80}")
    print(f"Task: {input_set['task']}")
    print(f"Agents: {input_set['num_agents']}")
    print(f"\nExpected Flow:")
    for i, step in enumerate(input_set['expected_flow'], 1):
        print(f"  {i}. {step}")
    
    # Initialize components
    executor = MockExecutor()
    token_pool = SecureTokenPool(tokens=[f"mock_token_{i}" for i in range(5)])
    worktree_manager = WorktreeManager(base_path="/tmp/hecaton_demo", repo_path="/tmp")
    
    # Load configuration
    config_loader = ConfigLoader()
    enhanced_config = config_loader.get_enhanced_config()
    
    # Create orchestrator
    orchestrator = EnhancedOrchestrator(
        executor=executor,
        token_pool=token_pool,
        worktree_manager=worktree_manager,
        config=enhanced_config
    )
    
    print(f"\n🚀 Executing with Enhanced Orchestrator...")
    print("-" * 40)
    
    try:
        # Execute the task
        result = await orchestrator.execute(
            input_set['task'],
            num_agents=input_set['num_agents']
        )
        
        # Display results
        if result.get('status') == 'success':
            print(f"✅ Execution successful!")
            
            # Show execution details
            if result.get('execution_groups'):
                print(f"   Execution Groups: {result['execution_groups']}")
            if result.get('total_tasks'):
                print(f"   Total Subtasks: {result['total_tasks']}")
            if result.get('checkpoints'):
                print(f"   Checkpoints Created: {len(result['checkpoints'])}")
            if result.get('final_phase'):
                print(f"   Final Phase: {result['final_phase']}")
            if result.get('agent_assignments'):
                print(f"   Agent Assignments: {len(result['agent_assignments'])} tasks assigned")
            
            # Show sample results
            if result.get('results'):
                print(f"\n   Results Summary:")
                for r in result['results'][:3]:
                    if isinstance(r, dict):
                        status = r.get('status', 'unknown')
                        task_info = r.get('task', {})
                        if isinstance(task_info, dict):
                            task_type = task_info.get('type', 'task')
                            print(f"     - {task_type}: {status}")
        else:
            error_msg = result.get('error', 'Unknown error')
            print(f"❌ Execution failed: {error_msg}")
            
            # Show recovery details if available
            if result.get('checkpoint'):
                print(f"   Recovery checkpoint: {result['checkpoint']}")
            if result.get('retry_count'):
                print(f"   Retries attempted: {result['retry_count']}")
    
    except Exception as e:
        print(f"❌ Demonstration error: {e}")
        import traceback
        traceback.print_exc()
    
    # Show orchestrator status
    print(f"\n📊 Orchestrator Status:")
    status = orchestrator.get_status()
    print(f"   Phase: {status['phase']}")
    print(f"   Checkpoints: {status['checkpoints']}")
    if status.get('registered_agents'):
        print(f"   Registered Agents: {status['registered_agents']}")
    if status.get('autonomy_levels'):
        print(f"   Agent Autonomy Levels:")
        for agent, level in list(status['autonomy_levels'].items())[:3]:
            print(f"     - {agent}: {level}")


async def main():
    """Run all demonstrations"""
    
    print("\n" + "=" * 80)
    print("🚀 HECATON ENHANCED ORCHESTRATOR DEMONSTRATION")
    print("=" * 80)
    print("\nThis demonstration uses input sets to show the enhanced features")
    print("of HECATON without requiring actual Claude API calls.")
    print("\nFeatures demonstrated:")
    print("  • Task decomposition and parallel execution")
    print("  • Intelligent agent assignment")
    print("  • Progressive autonomy management")
    print("  • Quality gates and phase transitions")
    print("  • Error boundaries and recovery")
    print("  • Agent handoffs and coordination")
    print("  • Checkpoint and rollback capabilities")
    
    # Run demonstrations
    for name, input_set in INPUT_SETS.items():
        await demonstrate_input_set(name, input_set)
        await asyncio.sleep(0.5)  # Brief pause between demos
    
    print("\n" + "=" * 80)
    print("✅ ALL DEMONSTRATIONS COMPLETE!")
    print("=" * 80)
    print("\nThe enhanced orchestrator successfully demonstrated:")
    print("  • Simple task execution with safety features")
    print("  • Complex task decomposition and parallel execution")
    print("  • Error recovery with checkpoint rollback")
    print("  • Full SDLC workflow with phase transitions")
    print("\nAll enhanced features are integrated and operational!")
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)