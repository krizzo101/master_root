#!/usr/bin/env python3
"""Test script for the HECATON performance monitoring system."""

import sys
import time
import json
sys.path.insert(0, '/home/opsvi/master_root/apps/hecaton')

from src.hecaton.monitoring.performance_monitor import PerformanceMonitor


def test_performance_monitor():
    """Test all features of the PerformanceMonitor."""
    print("=== Testing HECATON Performance Monitor ===\n")
    
    # Create monitor instance
    monitor = PerformanceMonitor()
    
    # Test 1: Track a successful task
    print("Test 1: Tracking successful task...")
    monitor.start_tracking("task_001")
    time.sleep(0.1)  # Simulate work
    monitor.update_peak_memory("task_001")
    metrics = monitor.end_tracking("task_001", success=True, token_usage=150)
    print(f"  Task 001: execution_time={metrics.execution_time:.3f}s, success={metrics.success}")
    
    # Test 2: Track a failed task
    print("\nTest 2: Tracking failed task...")
    monitor.start_tracking("task_002")
    time.sleep(0.05)  # Simulate work
    metrics = monitor.end_tracking("task_002", success=False, error="Simulated error", token_usage=75)
    print(f"  Task 002: execution_time={metrics.execution_time:.3f}s, success={metrics.success}, error={metrics.error}")
    
    # Test 3: Track multiple concurrent tasks
    print("\nTest 3: Tracking multiple concurrent tasks...")
    monitor.start_tracking("task_003")
    monitor.start_tracking("task_004")
    time.sleep(0.03)
    monitor.end_tracking("task_003", success=True, token_usage=200)
    time.sleep(0.02)
    monitor.end_tracking("task_004", success=True, token_usage=180)
    print("  Tasks 003 and 004 tracked successfully")
    
    # Test 4: Get metrics for specific task
    print("\nTest 4: Retrieving specific task metrics...")
    task_metrics = monitor.get_metrics("task_001")
    if task_metrics:
        print(f"  Task 001 metrics retrieved: execution_time={task_metrics.execution_time:.3f}s")
    
    # Test 5: Calculate statistics
    print("\nTest 5: Calculating statistics...")
    stats = monitor.calculate_statistics()
    print(f"  Total tasks: {stats['total_tasks']}")
    print(f"  Successful tasks: {stats['successful_tasks']}")
    print(f"  Failed tasks: {stats['failed_tasks']}")
    print(f"  Success rate: {stats['success_rate']*100:.1f}%")
    print(f"  Avg execution time: {stats['avg_execution_time']:.3f}s")
    print(f"  Peak memory: {stats['peak_memory'] / (1024*1024):.2f} MB")
    print(f"  Total token usage: {stats['total_token_usage']}")
    
    # Test 6: Export metrics to JSON
    print("\nTest 6: Exporting metrics to JSON...")
    json_output = monitor.export_metrics("/tmp/hecaton_test_metrics.json")
    json_data = json.loads(json_output)
    print(f"  Exported {len(json_data['completed_tasks'])} completed tasks")
    print(f"  Exported {len(json_data['active_tasks'])} active tasks")
    print(f"  JSON file saved to: /tmp/hecaton_test_metrics.json")
    
    # Test 7: Get active and completed tasks
    print("\nTest 7: Getting task lists...")
    active = monitor.get_active_tasks()
    completed = monitor.get_completed_tasks()
    print(f"  Active tasks: {active}")
    print(f"  Completed tasks: {completed}")
    
    # Test 8: Reset monitor
    print("\nTest 8: Resetting monitor...")
    monitor.reset()
    stats_after_reset = monitor.calculate_statistics()
    print(f"  Tasks after reset: {stats_after_reset['total_tasks']}")
    
    print("\n=== All tests completed successfully! ===")
    return True


if __name__ == "__main__":
    try:
        success = test_performance_monitor()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\nError during testing: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)