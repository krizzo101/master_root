#!/usr/bin/env python3
"""Quick test version of Phase 3 with 2-second waits instead of 60"""

import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from src.hecaton.orchestration.self_improving_orchestrator import SelfImprovingOrchestrator

async def main():
    """Run test with shorter waits"""
    print("TESTING PHASE 3 (2-second waits)")
    orchestrator = SelfImprovingOrchestrator()
    
    for cycle_num in range(1, 3):  # Only 2 cycles for testing
        print(f"\nCYCLE {cycle_num}")
        results = await orchestrator.run_improvement_cycle()
        
        print(f"• Bottlenecks Found: {results.get('bottlenecks_found', 0)}")
        print(f"• Improvements Executed: {results.get('improvements_executed', 0)}")
        print(f"• Success Rate: {results.get('success_rate', 0.0):.1%}")
        
        if cycle_num < 2:
            print("Waiting 2 seconds...")
            await asyncio.sleep(2)
    
    print("\nTEST COMPLETE")

if __name__ == "__main__":
    asyncio.run(main())