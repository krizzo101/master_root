#!/usr/bin/env python3
"""
Simple test to verify real Claude Code execution works
"""

import asyncio
import os
import sys
from pathlib import Path

# Load tokens
sys.path.insert(0, str(Path(__file__).parent))
from scripts.load_tokens import load_real_tokens
load_real_tokens()

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from hecaton.resources.token_pool import TokenPool
from hecaton.resources.worktree import WorktreeManager
from hecaton.agents.real_claude_executor import RealClaudeSubprocessExecutor


async def test_simple_claude():
    """Test with a simple task"""
    
    print("\n🧪 TESTING REAL CLAUDE CODE EXECUTION")
    print("="*50)
    
    # Initialize
    token_pool = TokenPool()
    print(f"✅ Tokens available: {token_pool.get_token_count()}")
    
    worktree_manager = WorktreeManager(base_path=Path("/tmp/hecaton_test"))
    executor = RealClaudeSubprocessExecutor(token_pool, worktree_manager)
    
    # Simple test task
    test_task = {
        "id": "test-1",
        "prompt": "Print 'Hello from Claude!' and create a file hello.txt with that content"
    }
    
    print(f"\n📋 Task: {test_task['prompt']}")
    print("\n🚀 Executing with real Claude Code...")
    
    result = await executor.execute_single_task(test_task)
    
    print(f"\n📊 Result:")
    print(f"   Status: {result.get('status')}")
    if result.get('output'):
        print(f"   Output: {result.get('output')[:200]}...")
    if result.get('error'):
        print(f"   Error: {result.get('error')}")
    
    return result


if __name__ == "__main__":
    result = asyncio.run(test_simple_claude())
    print("\n✅ Test complete!")