#!/usr/bin/env python3
"""Run message broker tests."""

import sys
import os
import asyncio
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pytest

if __name__ == "__main__":
    # Run the tests
    result = pytest.main([
        "tests/unit/test_message_broker.py",
        "-v",
        "--tb=short"
    ])
    sys.exit(result)