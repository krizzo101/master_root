#!/usr/bin/env python3
"""Test the fixed worktree cleanup functionality"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.hecaton.resources.worktree import WorktreeManager

def test_worktree_cleanup():
    """Test creating and cleaning up a worktree"""
    
    print("Testing worktree cleanup fix...")
    
    # Initialize manager with test paths
    manager = WorktreeManager(
        base_path=Path("/tmp/test_worktrees"),
        repo_path=Path("/home/opsvi/master_root")
    )
    
    # Create a test worktree
    print("Creating test worktree...")
    worktree_path = manager.create("test-agent-001")
    print(f"Created worktree at: {worktree_path}")
    
    # Try to clean it up
    print("Cleaning up worktree...")
    manager.cleanup("test-agent-001", force=True)
    print("✅ Cleanup completed without errors!")
    
    # Check if it's gone
    if not worktree_path.exists():
        print("✅ Worktree directory successfully removed")
    else:
        print("⚠️  Worktree directory still exists but cleanup didn't error")
    
    return True

if __name__ == "__main__":
    try:
        test_worktree_cleanup()
        print("\n✅ All tests passed! Worktree cleanup is fixed.")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)