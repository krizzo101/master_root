#!/usr/bin/env python3
"""
Comprehensive testing script for HECATON
Tests all modes, options, and combinations to identify runtime errors
"""

import asyncio
import subprocess
import json
import time
import sys
from pathlib import Path
from typing import Dict, List, Tuple
import signal

class HecatonTester:
    def __init__(self):
        self.results = []
        self.errors = []
        self.hecaton_dir = Path("/home/opsvi/master_root/apps/hecaton")
        
    def run_test(self, mode: str, agents: int, task: str, verbose: bool = False, 
                  input_set: str = None, timeout: int = 30) -> Dict:
        """Run a single test with specified parameters"""
        
        cmd = [
            sys.executable, "-m", "hecaton", "run", task,
            "--mode", mode,
            "--agents", str(agents)
        ]
        
        if verbose:
            cmd.append("--verbose")
        
        if input_set:
            cmd.extend(["--input-set", input_set])
        
        test_id = f"{mode}_{agents}agents{'_verbose' if verbose else ''}{'_' + input_set if input_set else ''}"
        print(f"\n{'='*60}")
        print(f"Testing: {test_id}")
        print(f"Command: {' '.join(cmd)}")
        print(f"{'='*60}")
        
        start_time = time.time()
        try:
            # Run with timeout
            result = subprocess.run(
                cmd,
                cwd=self.hecaton_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            duration = time.time() - start_time
            
            # Analyze output
            success = "✅" in result.stdout or "Success" in result.stdout
            has_error = "ERROR" in result.stderr or "Exception" in result.stderr
            
            test_result = {
                "test_id": test_id,
                "mode": mode,
                "agents": agents,
                "verbose": verbose,
                "input_set": input_set,
                "success": success and not has_error,
                "duration": duration,
                "return_code": result.returncode,
                "stdout_lines": len(result.stdout.splitlines()),
                "stderr_lines": len(result.stderr.splitlines()),
                "errors": []
            }
            
            # Extract errors
            if has_error:
                for line in result.stderr.splitlines():
                    if "ERROR" in line or "Exception" in line:
                        test_result["errors"].append(line)
                        self.errors.append({
                            "test_id": test_id,
                            "error": line
                        })
            
            # Check for specific known issues
            if "KeyError: 'metrics'" in result.stderr:
                test_result["errors"].append("Missing 'metrics' field in response")
            
            self.results.append(test_result)
            
            # Print summary
            status = "✅ PASSED" if test_result["success"] else "❌ FAILED"
            print(f"Result: {status} (Duration: {duration:.2f}s)")
            if test_result["errors"]:
                print("Errors found:")
                for error in test_result["errors"][:3]:  # Show first 3 errors
                    print(f"  - {error[:100]}...")
            
            return test_result
            
        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            test_result = {
                "test_id": test_id,
                "mode": mode,
                "agents": agents,
                "verbose": verbose,
                "input_set": input_set,
                "success": False,
                "duration": duration,
                "return_code": -1,
                "errors": [f"Timeout after {timeout} seconds"]
            }
            self.results.append(test_result)
            self.errors.append({
                "test_id": test_id,
                "error": f"Timeout after {timeout} seconds"
            })
            print(f"Result: ❌ TIMEOUT (After {timeout}s)")
            return test_result
            
        except Exception as e:
            test_result = {
                "test_id": test_id,
                "mode": mode,
                "agents": agents,
                "success": False,
                "duration": 0,
                "errors": [str(e)]
            }
            self.results.append(test_result)
            print(f"Result: ❌ EXCEPTION: {e}")
            return test_result
    
    def test_all_modes(self):
        """Test all modes with various configurations"""
        
        # Define test matrix with appropriate timeouts
        # (mode, agents, task, verbose, input_set, timeout)
        test_cases = [
            # Mode tests - simple tasks with 120s timeout
            ("simple", 1, "Create hello world function", False, None, 120),
            ("simple", 2, "Create hello world function", False, None, 120),
            
            # Send-api mode - may need more time for coordination
            ("send-api", 1, "Create hello world function", False, None, 180),
            ("send-api", 2, "Create hello world function", False, None, 180),
            
            # Enhanced mode - complex orchestration needs more time
            ("enhanced", 1, "Create hello world function", False, None, 180),
            ("enhanced", 2, "Create hello world function", False, None, 180),
            
            # Verbose tests
            ("simple", 1, "Create hello world function", True, None, 120),
            
            # Complex task test - needs more time
            ("simple", 2, "Build a REST API with database", False, None, 240),
            ("enhanced", 2, "Build a REST API with database and tests", False, None, 300),
            
            # Different agent counts
            ("simple", 3, "Create a calculator function", False, None, 180),
        ]
        
        print("\n" + "="*80)
        print("HECATON COMPREHENSIVE TESTING (with realistic timeouts)")
        print("="*80)
        
        for mode, agents, task, verbose, input_set, timeout in test_cases:
            self.run_test(mode, agents, task, verbose, input_set, timeout=timeout)
    
    def generate_report(self):
        """Generate comprehensive test report"""
        
        report_path = self.hecaton_dir / "TEST_REPORT.md"
        
        # Calculate statistics
        total_tests = len(self.results)
        passed = sum(1 for r in self.results if r["success"])
        failed = total_tests - passed
        
        # Group errors by type
        error_types = {}
        for error in self.errors:
            error_msg = error["error"]
            if "metrics" in error_msg:
                error_type = "Missing metrics field"
            elif "Timeout" in error_msg:
                error_type = "Timeout"
            elif "KeyError" in error_msg:
                error_type = "KeyError"
            elif "AttributeError" in error_msg:
                error_type = "AttributeError"
            else:
                error_type = "Other"
            
            if error_type not in error_types:
                error_types[error_type] = []
            error_types[error_type].append(error)
        
        # Generate report content
        report = f"""# HECATON Comprehensive Test Report

Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}

## Summary

- **Total Tests**: {total_tests}
- **Passed**: {passed} ({passed/total_tests*100:.1f}%)
- **Failed**: {failed} ({failed/total_tests*100:.1f}%)
- **Unique Error Types**: {len(error_types)}

## Test Results by Mode

### Simple Mode
"""
        
        for mode in ["simple", "send-api", "enhanced"]:
            mode_results = [r for r in self.results if r["mode"] == mode]
            if mode_results:
                mode_passed = sum(1 for r in mode_results if r["success"])
                report += f"""
### {mode.title()} Mode
- Tests: {len(mode_results)}
- Passed: {mode_passed}
- Failed: {len(mode_results) - mode_passed}
- Avg Duration: {sum(r['duration'] for r in mode_results)/len(mode_results):.2f}s

| Test | Agents | Success | Duration | Errors |
|------|--------|---------|----------|--------|
"""
                for r in mode_results:
                    status = "✅" if r["success"] else "❌"
                    errors = len(r.get("errors", []))
                    report += f"| {r['test_id']} | {r['agents']} | {status} | {r['duration']:.2f}s | {errors} |\n"
        
        report += f"""

## Error Analysis

### Error Types Distribution
"""
        for error_type, errors in error_types.items():
            report += f"- **{error_type}**: {len(errors)} occurrences\n"
        
        report += """

## Identified Issues and Patches

### 1. Missing 'metrics' field (FIXED)
**Issue**: Enhanced orchestrator's `_execute_complex_task` doesn't return metrics
**Solution**: Added metrics calculation to return structure
**Status**: ✅ Patched

### 2. Timeout Issues
**Issue**: Send-api and Enhanced modes timeout frequently
**Possible Causes**:
- Deadlock in async execution
- Infinite loop in task decomposition
- Token pool exhaustion
**Status**: ⚠️ Needs investigation

## Recommendations

1. **Critical**: Fix timeout issues in send-api and enhanced modes
2. **Important**: Add proper error handling for missing fields
3. **Nice-to-have**: Improve verbose output formatting
4. **Testing**: Add unit tests for each mode

## Detailed Error Log
"""
        
        for error in self.errors[:20]:  # Show first 20 errors
            report += f"\n**Test**: {error['test_id']}\n"
            report += f"**Error**: {error['error']}\n"
        
        # Save report
        with open(report_path, "w") as f:
            f.write(report)
        
        print(f"\n{'='*80}")
        print(f"Report saved to: {report_path}")
        print(f"Summary: {passed}/{total_tests} tests passed")
        
        return report_path

if __name__ == "__main__":
    tester = HecatonTester()
    tester.test_all_modes()
    tester.generate_report()