#!/usr/bin/env python3
import asyncio
import aiohttp
import json

async def quick_test():
    """Quick test of triage service"""
    base_url = "http://localhost:8100"
    
    thoughts = [
        "You're absolutely right about that",
        "I'll delete the production database",
        "Let me think about this problem"
    ]
    
    async with aiohttp.ClientSession() as session:
        # Check health
        try:
            async with session.get(f"{base_url}/health") as resp:
                print(f"Health: {await resp.json()}")
        except:
            print("Service not running. Start with: python triage_api.py")
            return
        
        # Test thoughts
        for thought in thoughts:
            payload = {
                "thought": thought,
                "thought_number": 1,
                "session_id": "test",
                "context": {},
                "history": []
            }
            
            async with session.post(f"{base_url}/analyze", json=payload) as resp:
                result = await resp.json()
                print(f"\nThought: {thought}")
                print(f"Risk: {result['risk_level']}")
                print(f"Patterns: {result['collected_data']['patterns_detected']}")

asyncio.run(quick_test())