#!/usr/bin/env python3
"""
Test the triage service in shadow mode
"""
import asyncio
import aiohttp
import json
from typing import List

# Test thoughts that should trigger different patterns
TEST_THOUGHTS = [
    # Low risk
    {
        "thought": "I need to understand how this function works",
        "expected_risk": "low",
        "expected_patterns": []
    },
    # Agreeability pattern
    {
        "thought": "You're absolutely right about that approach",
        "expected_risk": "low",
        "expected_patterns": ["potential_agreeability"]
    },
    # High risk - production changes
    {
        "thought": "I'll delete the production database and recreate it",
        "expected_risk": "high",
        "expected_patterns": []
    },
    # Medium risk - implementation
    {
        "thought": "Let me implement this new feature by modifying the core module",
        "expected_risk": "medium",
        "expected_patterns": []
    },
    # Unsubstantiated claim
    {
        "thought": "This will definitely improve performance by 50%",
        "expected_risk": "low",
        "expected_patterns": ["unsubstantiated_claim"]
    },
    # Multiple patterns
    {
        "thought": "You're exactly right, this will solve all our problems",
        "expected_risk": "low",
        "expected_patterns": ["potential_agreeability", "unsubstantiated_claim"]
    }
]

async def test_triage_service(base_url: str = "http://localhost:8100"):
    """Test the triage service with various thought patterns"""
    
    async with aiohttp.ClientSession() as session:
        # Check health first
        async with session.get(f"{base_url}/health") as resp:
            health = await resp.json()
            print(f"Service health: {health}")
            assert health["status"] == "healthy"
            assert health["mode"] == "shadow"
        
        # Test each thought
        results = []
        for i, test_case in enumerate(TEST_THOUGHTS):
            payload = {
                "thought": test_case["thought"],
                "thought_number": i + 1,
                "session_id": "test_session_001",
                "context": {},
                "history": []
            }
            
            async with session.post(f"{base_url}/analyze", json=payload) as resp:
                result = await resp.json()
                results.append(result)
                
                # Verify shadow mode behavior
                assert result["should_escalate"] == False, "Should never escalate in shadow mode"
                
                # Check risk assessment
                print(f"\nThought {i+1}: '{test_case['thought'][:50]}...'")
                print(f"  Risk Level: {result['risk_level']} (expected: {test_case['expected_risk']})")
                print(f"  Would escalate: {result['collected_data']['would_have_escalated']}")
                print(f"  Patterns: {result['collected_data']['patterns_detected']}")
                
                # Verify risk level matches expectation
                if result["risk_level"] != test_case["expected_risk"]:
                    print(f"  ⚠️  Risk mismatch! Got {result['risk_level']}, expected {test_case['expected_risk']}")
        
        # Get metrics
        async with session.get(f"{base_url}/metrics") as resp:
            metrics = await resp.json()
            print(f"\n=== METRICS ===")
            print(f"Total analyzed: {metrics['total_thoughts_analyzed']}")
            print(f"Would have escalated: {metrics['would_have_escalated']} ({metrics['escalation_rate']:.1%})")
            print(f"Risk distribution: {metrics['risk_distribution']}")
            print(f"Pattern frequency: {metrics['pattern_frequency']}")
        
        return results

def run_tests():
    """Run the test suite"""
    print("Starting Triage Service Tests...")
    print("=" * 50)
    
    try:
        results = asyncio.run(test_triage_service())
        print(f"\n✅ All tests passed! Analyzed {len(results)} thoughts.")
        print("\nShadow mode is working correctly:")
        print("- Collecting data without intervention")
        print("- Detecting patterns for analysis")
        print("- Ready for metrics-based decision on Phase 2")
        return True
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        return False

if __name__ == "__main__":
    # First, make sure the service is running
    print("Make sure triage service is running:")
    print("  python triage_api.py")
    print("\nThen press Enter to run tests...")
    input()
    
    success = run_tests()
    exit(0 if success else 1)