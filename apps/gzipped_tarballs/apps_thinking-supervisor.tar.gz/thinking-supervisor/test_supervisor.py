#!/usr/bin/env python3
"""
Test cases showing how the supervisor enforces better thinking
"""

from metacognitive_supervisor import MetacognitiveSupervisor
from mcp_integration import EnhancedThinkingServer

def test_reflexive_agreement():
    """Test that reflexive agreement gets blocked"""
    print("=" * 60)
    print("TEST: Reflexive Agreement Detection")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    
    # First agreement - might pass
    response1 = server.process_thinking_request({
        "thought": "You're right about that approach.",
        "thoughtNumber": 1
    })
    print(f"First agreement: Blocked={response1.get('blocked', False)}")
    
    # Second agreement - warning
    response2 = server.process_thinking_request({
        "thought": "Yes, that's absolutely right!",
        "thoughtNumber": 2
    })
    print(f"Second agreement: Blocked={response2.get('blocked', False)}")
    
    # Third agreement - blocked
    response3 = server.process_thinking_request({
        "thought": "Exactly, that's a great idea!",
        "thoughtNumber": 3
    })
    print(f"Third agreement: Blocked={response3.get('blocked', False)}")
    
    if response3.get("blocked"):
        print(f"Block reason: {response3.get('blockReason')}")
        print(f"Must complete: {response3.get('mustComplete')}")
        print(f"Guidance: {response3.get('thoughtGuidance')}")
    
    print()

def test_technical_impossibility():
    """Test detection of technically impossible claims"""
    print("=" * 60)
    print("TEST: Technical Impossibility Detection")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    
    response = server.process_thinking_request({
        "thought": "I'll check this every 30 minutes to ensure it's updated.",
        "thoughtNumber": 1
    })
    
    print(f"Blocked: {response.get('blocked', False)}")
    if response.get("blocked"):
        print(f"Reason: {response.get('blockReason')}")
        print(f"Requirements: {response.get('mustComplete')}")
        print(f"Guidance: {response.get('thoughtGuidance')}")
    
    print()

def test_shallow_analysis():
    """Test detection of shallow thinking"""
    print("=" * 60)
    print("TEST: Shallow Analysis Detection")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    
    # Shallow response
    response1 = server.process_thinking_request({
        "thought": "Yes.",
        "thoughtNumber": 1
    })
    
    print(f"Shallow 'Yes': Requirements={response1.get('requirements')}")
    
    # Better response with analysis
    response2 = server.process_thinking_request({
        "thought": "Yes, this works because the evidence shows X, however the tradeoff is Y, and alternatively we could consider Z.",
        "thoughtNumber": 2
    })
    
    print(f"Detailed response: Requirements={response2.get('requirements')}")
    print()

def test_checkpoint_enforcement():
    """Test mandatory checkpoint requirements"""
    print("=" * 60)
    print("TEST: Checkpoint Enforcement")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    
    # Process 5 thoughts to trigger checkpoint
    for i in range(5):
        response = server.process_thinking_request({
            "thought": f"Thinking about step {i+1}",
            "thoughtNumber": i+1
        })
    
    # The 5th should have mandatory checkpoint
    if response.get("mandatoryCheckpoint"):
        checkpoint = response["mandatoryCheckpoint"]
        print(f"Checkpoint triggered at thought 5")
        print(f"Required: {checkpoint['required']}")
        print(f"Questions to answer:")
        for q in checkpoint['questions']:
            print(f"  - {q}")
        print(f"Enforcement: {checkpoint['enforcement']}")
    
    print()

def test_real_scenario():
    """Test a realistic scenario of poor thinking being corrected"""
    print("=" * 60)
    print("TEST: Real Scenario - Bug Fix Without Analysis")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    server.set_enforcement_level("strict")
    
    # Bad approach - rush to fix without understanding
    bad_thought = """I'll just fix this bug by changing the function."""
    
    response = server.process_thinking_request({
        "thought": bad_thought,
        "thoughtNumber": 1
    })
    
    print(f"Initial thought: '{bad_thought}'")
    print(f"Supervisor response:")
    print(f"  Blocked: {response.get('blocked')}")
    print(f"  Requirements: {response.get('requirements')}")
    print(f"  Prompt: {response.get('metacognitivePrompt')}")
    
    # Forced better approach
    better_thought = """Let me analyze this bug properly:
    1. Root cause: The function doesn't handle null inputs
    2. This indicates a broader pattern of missing validation
    3. Alternative approaches: input validation layer vs individual checks
    4. I'll implement validation at the entry point because it's more maintainable
    5. This will prevent similar bugs in other functions"""
    
    response2 = server.process_thinking_request({
        "thought": better_thought,
        "thoughtNumber": 2
    })
    
    print(f"\nCorrected thought demonstrates:")
    print(f"  - Root cause analysis")
    print(f"  - Pattern recognition")
    print(f"  - Alternative consideration")
    print(f"  - Preventive thinking")
    print(f"  Blocked: {response2.get('blocked', False)}")
    
    print()

def test_enforcement_levels():
    """Test different enforcement levels"""
    print("=" * 60)
    print("TEST: Enforcement Levels")
    print("=" * 60)
    
    server = EnhancedThinkingServer()
    
    test_thought = "Sure, that works."
    
    # Normal mode
    server.set_enforcement_level("normal")
    response_normal = server.process_thinking_request({
        "thought": test_thought,
        "thoughtNumber": 1
    })
    print(f"Normal mode - Blocked: {response_normal.get('blocked', False)}")
    
    # Strict mode  
    server.set_enforcement_level("strict")
    response_strict = server.process_thinking_request({
        "thought": test_thought,
        "thoughtNumber": 1
    })
    print(f"Strict mode - Blocked: {response_strict.get('blocked', False)}")
    
    # Maximum enforcement
    server.set_enforcement_level("maximum")
    response_max = server.process_thinking_request({
        "thought": test_thought,
        "thoughtNumber": 1
    })
    print(f"Maximum mode - Blocked: {response_max.get('blocked', False)}")
    
    print()

if __name__ == "__main__":
    # Run all tests
    test_reflexive_agreement()
    test_technical_impossibility()
    test_shallow_analysis()
    test_checkpoint_enforcement()
    test_real_scenario()
    test_enforcement_levels()
    
    print("=" * 60)
    print("SUMMARY: Supervisor enforces expert thinking patterns")
    print("=" * 60)
    print("""
The supervisor acts as a strict senior engineer reviewing thoughts:
- Blocks reflexive agreement without analysis
- Catches technical impossibilities
- Requires evidence for claims
- Forces consideration of alternatives
- Learns from past failures in KB
- Provides targeted guidance, not generic prompts

This transforms the thinking tool from passive logging to active enforcement.
""")