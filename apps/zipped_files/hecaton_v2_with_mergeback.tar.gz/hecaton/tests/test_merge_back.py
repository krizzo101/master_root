"""
Tests for HECATON merge-back functionality
"""

import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import pytest

from hecaton.config.merge_back import MergeBackConfig
from hecaton.orchestration.merger import ConflictReport, Merger, PatchManifest
from hecaton.orchestration.tasks import create_fixit_tasks


class TestMergeBackConfig(unittest.TestCase):
    """Test MergeBackConfig configuration class"""

    def test_default_config(self):
        """Test default configuration values"""
        config = MergeBackConfig()
        
        self.assertTrue(config.enabled)
        self.assertEqual(config.patch_dir, ".hecaton/patches")
        self.assertEqual(config.target_branch, "main")
        self.assertEqual(config.max_conflicts, 25)
        self.assertEqual(config.max_patch_size_mb, 10.0)

    def test_path_methods(self):
        """Test path generation methods"""
        config = MergeBackConfig()
        run_id = "test-run-123"
        
        patch_path = config.get_patch_path(run_id)
        self.assertEqual(patch_path, Path(".hecaton/patches/test-run-123"))
        
        artifacts_path = config.get_artifacts_path(run_id)
        self.assertEqual(artifacts_path, Path(".hecaton/artifacts/test-run-123"))
        
        integration_branch = config.get_integration_branch(run_id)
        self.assertEqual(integration_branch, "integration/test-run-123")

    def test_validation(self):
        """Test configuration validation"""
        # Valid config should not raise
        config = MergeBackConfig()
        config.validate()
        
        # Invalid max_conflicts
        config.max_conflicts = 0
        with self.assertRaises(ValueError):
            config.validate()
        
        # Invalid max_patch_size_mb
        config = MergeBackConfig()
        config.max_patch_size_mb = -1
        with self.assertRaises(ValueError):
            config.validate()
        
        # Invalid target_branch
        config = MergeBackConfig()
        config.target_branch = ""
        with self.assertRaises(ValueError):
            config.validate()


class TestPatchOrdering(unittest.TestCase):
    """Test patch ordering logic"""

    def setUp(self):
        """Set up test fixtures"""
        self.config = MergeBackConfig()
        self.merger = Merger(self.config, Mock())

    def test_order_patches_by_path(self):
        """Test patches are ordered by path priority"""
        patches = [
            PatchManifest(
                patch_file="001__code__agent1.patch",
                agent_id="agent1",
                agent_role="code",
                commit_sha="abc123",
                files_changed=["src/main.py"],
                insertions=10,
                deletions=5,
                task_hash="hash1",
                run_id="test-run",
                sequence=1,
            ),
            PatchManifest(
                patch_file="002__docs__agent2.patch",
                agent_id="agent2",
                agent_role="docs",
                commit_sha="def456",
                files_changed=["docs/README.md"],
                insertions=20,
                deletions=3,
                task_hash="hash2",
                run_id="test-run",
                sequence=2,
            ),
            PatchManifest(
                patch_file="003__test__agent3.patch",
                agent_id="agent3",
                agent_role="test",
                commit_sha="ghi789",
                files_changed=["tests/test_main.py"],
                insertions=15,
                deletions=2,
                task_hash="hash3",
                run_id="test-run",
                sequence=3,
            ),
        ]
        
        ordered = self.merger.order_patches(patches)
        
        # Docs should come first (path priority)
        self.assertEqual(ordered[0].agent_role, "docs")
        # Tests should come second
        self.assertEqual(ordered[1].agent_role, "test")
        # Code should come last
        self.assertEqual(ordered[2].agent_role, "code")

    def test_order_patches_by_role_weight(self):
        """Test patches are ordered by role weight when paths are same"""
        patches = [
            PatchManifest(
                patch_file="001__code__agent1.patch",
                agent_id="agent1",
                agent_role="code",
                commit_sha="abc123",
                files_changed=["src/main.py"],
                insertions=10,
                deletions=5,
                task_hash="hash1",
                run_id="test-run",
                sequence=1,
            ),
            PatchManifest(
                patch_file="002__review__agent2.patch",
                agent_id="agent2",
                agent_role="review",
                commit_sha="def456",
                files_changed=["src/utils.py"],
                insertions=8,
                deletions=2,
                task_hash="hash2",
                run_id="test-run",
                sequence=2,
            ),
        ]
        
        ordered = self.merger.order_patches(patches)
        
        # Review should come first (lower role weight = 10)
        self.assertEqual(ordered[0].agent_role, "review")
        # Code should come second (higher role weight = 40)
        self.assertEqual(ordered[1].agent_role, "code")

    def test_order_patches_stable_sorting(self):
        """Test that ordering is stable for equal priority patches"""
        patches = [
            PatchManifest(
                patch_file="001__code__agent1.patch",
                agent_id="agent1",
                agent_role="code",
                commit_sha="abc123",
                files_changed=["src/a.py"],
                insertions=5,
                deletions=3,
                task_hash="hash1",
                run_id="test-run",
                sequence=1,
            ),
            PatchManifest(
                patch_file="002__code__agent2.patch",
                agent_id="agent2",
                agent_role="code",
                commit_sha="def456",
                files_changed=["src/b.py"],
                insertions=8,
                deletions=2,
                task_hash="hash2",
                run_id="test-run",
                sequence=2,
            ),
            PatchManifest(
                patch_file="003__code__agent3.patch",
                agent_id="agent3",
                agent_role="code",
                commit_sha="ghi789",
                files_changed=["src/c.py"],
                insertions=12,
                deletions=7,
                task_hash="hash3",
                run_id="test-run",
                sequence=3,
            ),
        ]
        
        ordered = self.merger.order_patches(patches)
        
        # Should maintain sequence order for same priority
        self.assertEqual(ordered[0].sequence, 1)
        self.assertEqual(ordered[1].sequence, 2)
        self.assertEqual(ordered[2].sequence, 3)


class TestFixItTaskCreation(unittest.TestCase):
    """Test Fix-It task creation"""

    def test_create_fixit_tasks_for_conflicts(self):
        """Test creating Fix-It tasks for conflicts"""
        conflicts = [
            ConflictReport(
                patch_file="patch1.patch",
                agent_id="agent1",
                conflicted_files=["src/main.py"],
                conflict_diff="<<<<<<< HEAD\noriginal\n=======\nmodified\n>>>>>>>",
                error_message="Patch failed to apply cleanly",
            ),
            ConflictReport(
                patch_file="patch2.patch",
                agent_id="agent2",
                conflicted_files=["src/utils.py", "src/helpers.py"],
                conflict_diff="<<<<<<< HEAD\noriginal\n=======\nmodified\n>>>>>>>",
                error_message="Patch failed to apply cleanly",
            ),
        ]
        
        tasks = create_fixit_tasks(conflicts, run_id="test-run")
        
        # Should create one task per conflict
        self.assertEqual(len(tasks), 2)
        
        # Check first task
        task1 = tasks[0]
        self.assertEqual(task1["agent_type"], "code")
        self.assertIn("src/main.py", task1["prompt"])
        self.assertIn("patch1.patch", task1["prompt"])
        
        # Check second task
        task2 = tasks[1]
        self.assertEqual(task2["agent_type"], "code")
        self.assertIn("src/utils.py", task2["prompt"])
        self.assertIn("src/helpers.py", task2["prompt"])

    def test_create_fixit_tasks_for_gate_failures(self):
        """Test creating Fix-It tasks for gate failures"""
        from hecaton.orchestration.merger import GatesReport
        
        gates_report = GatesReport(
            success=False,
            passed_gates=[],
            failed_gates=[
                ("pytest", "Test failed: test_main.py::test_function"),
                ("flake8", "E501 line too long (120 > 100 characters)"),
            ],
            logs="Full test output here...",
        )
        
        tasks = create_fixit_tasks([], gates_report, run_id="test-run")
        
        # Should create one task per failed gate
        self.assertEqual(len(tasks), 2)
        
        # Check pytest task
        pytest_task = tasks[0]
        self.assertEqual(pytest_task["agent_type"], "code")
        self.assertIn("pytest", pytest_task["prompt"])
        self.assertIn("test_main.py::test_function", pytest_task["prompt"])
        
        # Check flake8 task
        flake8_task = tasks[1]
        self.assertEqual(flake8_task["agent_type"], "code")
        self.assertIn("flake8", flake8_task["prompt"])
        self.assertIn("E501", flake8_task["prompt"])


@pytest.mark.slow
class TestMergerIntegration(unittest.TestCase):
    """Integration tests for Merger (marked as slow)"""

    def setUp(self):
        """Set up test repository"""
        self.test_dir = tempfile.mkdtemp(prefix="hecaton_test_")
        self.repo_path = Path(self.test_dir) / "repo"
        self.repo_path.mkdir()
        
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=self.repo_path, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@test.com"],
            cwd=self.repo_path,
            check=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=self.repo_path,
            check=True,
        )
        
        # Create initial commit
        (self.repo_path / "README.md").write_text("# Test Project\n")
        subprocess.run(["git", "add", "."], cwd=self.repo_path, check=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=self.repo_path,
            check=True,
        )
        
        # Set up config and merger
        self.config = MergeBackConfig(
            dry_run=True,  # Don't actually push
            gate_commands=[],  # Skip gates for tests
        )
        self.worktree_manager = Mock()
        self.merger = Merger(self.config, self.worktree_manager)

    def tearDown(self):
        """Clean up test repository"""
        import shutil
        
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def create_patch(self, content: str, filename: str) -> Path:
        """Helper to create a patch file"""
        patch_dir = self.repo_path / ".hecaton" / "patches" / "test-run"
        patch_dir.mkdir(parents=True, exist_ok=True)
        patch_file = patch_dir / filename
        patch_file.write_text(content)
        return patch_file

    def test_non_overlapping_patches_merge_success(self):
        """Test that non-overlapping patches merge successfully"""
        # Create two non-overlapping patches
        patch1_content = """From abc123 Mon Sep 17 00:00:00 2001
From: Agent1 <agent1@test.com>
Date: Mon, 1 Jan 2024 00:00:00 +0000
Subject: [PATCH] Add file1

---
 file1.txt | 1 +
 1 file changed, 1 insertion(+)

diff --git a/file1.txt b/file1.txt
new file mode 100644
index 0000000..e212970
--- /dev/null
+++ b/file1.txt
@@ -0,0 +1 @@
+file1
"""
        
        patch2_content = """From def456 Mon Sep 17 00:00:00 2001
From: Agent2 <agent2@test.com>
Date: Mon, 1 Jan 2024 00:01:00 +0000
Subject: [PATCH] Add file2

---
 file2.txt | 1 +
 1 file changed, 1 insertion(+)

diff --git a/file2.txt b/file2.txt
new file mode 100644
index 0000000..6c493ff
--- /dev/null
+++ b/file2.txt
@@ -0,0 +1 @@
+file2
"""
        
        patch1_path = self.create_patch(patch1_content, "001__code__agent1.patch")
        patch2_path = self.create_patch(patch2_content, "002__code__agent2.patch")
        
        # Create manifests
        manifests = [
            PatchManifest(
                patch_file=str(patch1_path),
                agent_id="agent1",
                agent_role="code",
                commit_sha="abc123",
                files_changed=["file1.txt"],
                insertions=1,
                deletions=0,
                task_hash="hash1",
                run_id="test-run",
                sequence=1,
            ),
            PatchManifest(
                patch_file=str(patch2_path),
                agent_id="agent2",
                agent_role="code",
                commit_sha="def456",
                files_changed=["file2.txt"],
                insertions=1,
                deletions=0,
                task_hash="hash2",
                run_id="test-run",
                sequence=2,
            ),
        ]
        
        # Mock worktree creation
        staging_worktree = self.repo_path / "staging"
        staging_worktree.mkdir()
        subprocess.run(
            ["git", "worktree", "add", str(staging_worktree), "main"],
            cwd=self.repo_path,
            check=True,
            capture_output=True,
        )
        
        # Apply patches
        applied, conflicts = self.merger.apply_patches(staging_worktree, manifests)
        
        # Both patches should apply successfully
        self.assertEqual(len(applied), 2)
        self.assertEqual(len(conflicts), 0)
        
        # Verify files were created
        self.assertTrue((staging_worktree / "file1.txt").exists())
        self.assertTrue((staging_worktree / "file2.txt").exists())
        
        # Clean up worktree
        subprocess.run(
            ["git", "worktree", "remove", str(staging_worktree)],
            cwd=self.repo_path,
            capture_output=True,
        )

    def test_overlapping_patches_create_conflicts(self):
        """Test that overlapping patches create conflicts"""
        # Create a base file
        base_file = self.repo_path / "shared.txt"
        base_file.write_text("line1\nline2\nline3\n")
        subprocess.run(["git", "add", "."], cwd=self.repo_path, check=True)
        subprocess.run(
            ["git", "commit", "-m", "Add shared file"],
            cwd=self.repo_path,
            check=True,
        )
        
        # Create two conflicting patches
        patch1_content = """From abc123 Mon Sep 17 00:00:00 2001
From: Agent1 <agent1@test.com>
Date: Mon, 1 Jan 2024 00:00:00 +0000
Subject: [PATCH] Modify shared.txt - version 1

---
 shared.txt | 2 +-
 1 file changed, 1 insertion(+), 1 deletion(-)

diff --git a/shared.txt b/shared.txt
index abc..def 100644
--- a/shared.txt
+++ b/shared.txt
@@ -1,3 +1,3 @@
 line1
-line2
+line2-modified-by-agent1
 line3
"""
        
        patch2_content = """From def456 Mon Sep 17 00:00:00 2001
From: Agent2 <agent2@test.com>
Date: Mon, 1 Jan 2024 00:01:00 +0000
Subject: [PATCH] Modify shared.txt - version 2

---
 shared.txt | 2 +-
 1 file changed, 1 insertion(+), 1 deletion(-)

diff --git a/shared.txt b/shared.txt
index abc..ghi 100644
--- a/shared.txt
+++ b/shared.txt
@@ -1,3 +1,3 @@
 line1
-line2
+line2-modified-by-agent2
 line3
"""
        
        patch1_path = self.create_patch(patch1_content, "001__code__agent1.patch")
        patch2_path = self.create_patch(patch2_content, "002__code__agent2.patch")
        
        # Create manifests
        manifests = [
            PatchManifest(
                patch_file=str(patch1_path),
                agent_id="agent1",
                agent_role="code",
                commit_sha="abc123",
                files_changed=["shared.txt"],
                insertions=1,
                deletions=1,
                task_hash="hash1",
                run_id="test-run",
                sequence=1,
            ),
            PatchManifest(
                patch_file=str(patch2_path),
                agent_id="agent2",
                agent_role="code",
                commit_sha="def456",
                files_changed=["shared.txt"],
                insertions=1,
                deletions=1,
                task_hash="hash2",
                run_id="test-run",
                sequence=2,
            ),
        ]
        
        # Mock worktree creation
        staging_worktree = self.repo_path / "staging"
        staging_worktree.mkdir()
        subprocess.run(
            ["git", "worktree", "add", str(staging_worktree), "main"],
            cwd=self.repo_path,
            check=True,
            capture_output=True,
        )
        
        # Apply patches
        applied, conflicts = self.merger.apply_patches(staging_worktree, manifests)
        
        # First patch should apply, second should conflict
        self.assertEqual(len(applied), 1)
        self.assertEqual(len(conflicts), 1)
        
        # Check conflict details
        conflict = conflicts[0]
        self.assertEqual(conflict.patch_id, "002__code__agent2.patch")
        self.assertIn("shared.txt", conflict.files)
        
        # Clean up worktree
        subprocess.run(
            ["git", "worktree", "remove", "--force", str(staging_worktree)],
            cwd=self.repo_path,
            capture_output=True,
        )


if __name__ == "__main__":
    unittest.main()