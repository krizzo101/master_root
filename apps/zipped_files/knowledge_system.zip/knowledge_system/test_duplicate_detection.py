#!/usr/bin/env python3
"""Test duplicate detection directly"""

import asyncio
import logging
import sys
import os

sys.path.insert(0, "/home/opsvi/master_root")
sys.path.insert(0, "/home/opsvi/master_root/libs/opsvi-llm")
os.environ["NEO4J_URI"] = "bolt://localhost:7687"
os.environ["NEO4J_USER"] = "neo4j"
os.environ["NEO4J_PASSWORD"] = "password"  # From .mcp.json
os.environ["OPENAI_API_KEY"] = "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"

from apps.knowledge_system.mcp_knowledge_tools import EnhancedKnowledgeStore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_duplicate_detection():
    """Test that duplicate detection works"""
    store = EnhancedKnowledgeStore()
    
    # First entry
    content1 = "TEST DUPLICATE: This is a test entry for duplicate detection"
    result1 = await store.store(
        raw_input=content1,
        hint_type="TEST",
        hint_tags=["test", "duplicate"],
        direct_execute=True
    )
    print(f"First entry stored: {result1.get('knowledge_id')}")
    print(f"Superseded count: {result1.get('superseded_count', 0)}")
    
    # Very similar entry (should be detected as duplicate)
    content2 = "TEST DUPLICATE: This is a test entry for duplicate detection with minor changes"
    result2 = await store.store(
        raw_input=content2,
        hint_type="TEST", 
        hint_tags=["test", "duplicate"],
        direct_execute=True
    )
    print(f"\nSecond entry stored: {result2.get('knowledge_id')}")
    print(f"Superseded count: {result2.get('superseded_count', 0)}")
    
    if result2.get('superseded_count', 0) > 0:
        print("\n✅ SUCCESS: Duplicate detection is working!")
    else:
        print("\n❌ FAILURE: Duplicate was not detected")
        
        # Try to understand why
        if not store.embedding_service:
            print("  - Embedding service not available")
        if not store.neo4j_driver:
            print("  - Neo4j driver not available")

if __name__ == "__main__":
    asyncio.run(test_duplicate_detection())