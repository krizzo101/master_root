#!/usr/bin/env python3
"""
Test the enrichment on a small sample first
"""

import sys
import asyncio

sys.path.insert(0, '/home/opsvi/master_root')

from kb_intelligent_enrichment import IntelligentKBEnricher
from neo4j import GraphDatabase


async def test_enrichment():
    """Test on just 5 entries"""
    enricher = IntelligentKBEnricher()
    
    # Get 5 sample entries
    with enricher.driver.session() as session:
        result = session.run("""
            MATCH (k:Knowledge)
            WHERE k.summary IS NULL
            RETURN k.knowledge_id as id,
                   k.content as content,
                   k.knowledge_type as knowledge_type,
                   k.tags as tags,
                   k.summary as summary,
                   k.confidence as confidence,
                   k.usage_count as usage_count,
                   k.success_rate as success_rate,
                   k.created_at as created_at
            LIMIT 5
        """)
        
        entries = list(result)
        
    print(f"Testing enrichment on {len(entries)} entries\n")
    
    # Test relationship detection
    relationships = enricher.detect_relationships(entries)
    print(f"Relationships detected: {relationships}\n")
    
    # Test enrichment
    for entry in entries:
        print(f"Entry: {entry['id'][:8]}...")
        print(f"  Type: {entry.get('knowledge_type')}")
        print(f"  Content preview: {entry.get('content', '')[:100]}...")
        
        updates = await enricher.enrich_entry(entry, relationships)
        
        if updates:
            print(f"  Updates:")
            for key, value in updates.items():
                if key == 'summary':
                    print(f"    {key}: {value}")
                elif key == 'content' and value.startswith(('CRITICAL:', 'DEPRECATED:')):
                    print(f"    {key}: {value[:50]}...")
                elif key == 'confidence':
                    print(f"    {key}: {value:.2f}")
                elif key == 'tags':
                    print(f"    {key}: {value}")
        else:
            print(f"  No updates needed")
        print()


if __name__ == "__main__":
    asyncio.run(test_enrichment())