#!/usr/bin/env python3
"""
Test enrichment on 20 entries to verify it works at scale
"""

import sys
import asyncio

sys.path.insert(0, '/home/opsvi/master_root')

from kb_intelligent_enrichment import IntelligentKBEnricher


async def test_20_entries():
    """Test on 20 entries with rate limiting"""
    enricher = IntelligentKBEnricher()
    
    # Run enrichment on just 20 entries
    await enricher.enrich_knowledge_base(batch_size=5, max_entries=20)


if __name__ == "__main__":
    print("Testing enrichment on 20 entries...")
    print("This will test:")
    print("- Summary generation with GPT-5-nano")
    print("- Relationship detection")
    print("- Quality scoring")
    print("- Rate limiting between batches")
    print()
    
    asyncio.run(test_20_entries())