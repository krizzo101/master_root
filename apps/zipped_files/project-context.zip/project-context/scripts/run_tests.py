#!/usr/bin/env python3
"""Test runner script with comprehensive test execution and reporting."""

import argparse
import asyncio
import os
import sys
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class TestRunner:
    """Comprehensive test runner for the unified context system."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.test_dir = project_root / "tests"
        self.reports_dir = project_root / "test_reports"
        self.reports_dir.mkdir(exist_ok=True)
        
        # Test categories and their configurations
        self.test_categories = {
            "unit": {
                "markers": "unit",
                "timeout": 300,
                "description": "Fast, isolated unit tests"
            },
            "integration": {
                "markers": "integration",
                "timeout": 600,
                "description": "Integration tests with moderate dependencies"
            },
            "e2e": {
                "markers": "e2e",
                "timeout": 1200,
                "description": "End-to-end system tests"
            },
            "performance": {
                "markers": "performance",
                "timeout": 1800,
                "description": "Performance and load tests"
            },
            "database": {
                "markers": "database",
                "timeout": 600,
                "description": "Database validation and schema tests"
            },
            "adapters": {
                "markers": "git_adapter or error_adapter or cicd_adapter",
                "timeout": 900,
                "description": "All adapter-specific tests"
            },
            "correlation": {
                "markers": "adapter_correlation",
                "timeout": 900,
                "description": "Cross-adapter correlation tests"
            },
            "pipeline": {
                "markers": "pipeline",
                "timeout": 1200,
                "description": "Pipeline integration tests"
            }
        }
    
    def run_category(self, category: str, **kwargs) -> Tuple[int, str]:
        """Run tests for a specific category."""
        if category not in self.test_categories:
            raise ValueError(f"Unknown test category: {category}")
        
        config = self.test_categories[category]
        print(f"\n{'='*60}")
        print(f"Running {category.upper()} tests")
        print(f"Description: {config['description']}")
        print(f"Markers: {config['markers']}")
        print(f"{'='*60}")
        
        # Build pytest command
        cmd = [
            "python", "-m", "pytest",
            str(self.test_dir),
            "-m", config["markers"],
            f"--timeout={config['timeout']}",
            f"--junit-xml={self.reports_dir}/{category}_results.xml",
            f"--html={self.reports_dir}/{category}_report.html",
            "--self-contained-html",
            "--tb=short",
            "-v"
        ]
        
        # Add additional options
        if kwargs.get("verbose"):
            cmd.append("-vv")
        
        if kwargs.get("fail_fast"):
            cmd.append("--maxfail=1")
        
        if kwargs.get("capture", "no") == "no":
            cmd.append("-s")
        
        if kwargs.get("coverage"):
            cmd.extend([
                "--cov=src/project_context",
                f"--cov-report=html:{self.reports_dir}/{category}_coverage",
                "--cov-report=term-missing"
            ])
        
        if kwargs.get("parallel"):
            workers = kwargs.get("workers", "auto")
            cmd.extend(["-n", str(workers)])
        
        # Run tests
        try:
            result = subprocess.run(
                cmd,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=config["timeout"] + 60  # Add buffer time
            )
            
            output = f"STDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}"
            return result.returncode, output
            
        except subprocess.TimeoutExpired as e:
            return -1, f"Tests timed out after {e.timeout} seconds"
        except Exception as e:
            return -1, f"Error running tests: {str(e)}"
    
    def run_all(self, **kwargs) -> Dict[str, Tuple[int, str]]:
        """Run all test categories."""
        results = {}
        
        # Define execution order (fast to slow)
        execution_order = ["unit", "database", "adapters", "integration", "correlation", "pipeline", "e2e"]
        
        # Add performance tests if requested
        if kwargs.get("include_performance"):
            execution_order.append("performance")
        
        for category in execution_order:
            if category in self.test_categories:
                print(f"\n🧪 Starting {category} tests...")
                start_time = datetime.now()
                
                returncode, output = self.run_category(category, **kwargs)
                
                end_time = datetime.now()
                duration = (end_time - start_time).total_seconds()
                
                status = "✅ PASSED" if returncode == 0 else "❌ FAILED"
                print(f"{status} - {category} tests completed in {duration:.1f}s")
                
                results[category] = (returncode, output)
                
                # Stop on failure if fail_fast is enabled
                if kwargs.get("fail_fast") and returncode != 0:
                    break
        
        return results
    
    def run_specific_test(self, test_path: str, **kwargs) -> Tuple[int, str]:
        """Run a specific test file or test function.""" 
        print(f"\n🎯 Running specific test: {test_path}")
        
        cmd = [
            "python", "-m", "pytest",
            test_path,
            f"--junit-xml={self.reports_dir}/specific_test_results.xml",
            "--tb=short",
            "-v"
        ]
        
        if kwargs.get("verbose"):
            cmd.append("-vv")
        
        if kwargs.get("capture", "no") == "no":
            cmd.append("-s")
        
        try:
            result = subprocess.run(
                cmd,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=600
            )
            
            output = f"STDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}"
            return result.returncode, output
            
        except subprocess.TimeoutExpired as e:
            return -1, f"Test timed out after {e.timeout} seconds"
        except Exception as e:
            return -1, f"Error running test: {str(e)}"
    
    def generate_summary_report(self, results: Dict[str, Tuple[int, str]]):
        """Generate a summary report of all test results."""
        report_path = self.reports_dir / "test_summary.html"
        
        html_content = """
<!DOCTYPE html>
<html>
<head>
    <title>Unified Context System - Test Results Summary</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background: #f0f0f0; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .category { margin: 10px 0; padding: 15px; border-radius: 5px; }
        .passed { background: #d4edda; border: 1px solid #c3e6cb; }
        .failed { background: #f8d7da; border: 1px solid #f5c6cb; }
        .summary { background: #e2e3e5; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; }
        .metric { background: white; padding: 10px; border-radius: 3px; text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🧪 Unified Context System Test Results</h1>
        <p>Generated: {timestamp}</p>
        <p>Project: {project_path}</p>
    </div>
        """.format(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            project_path=self.project_root
        )
        
        # Calculate summary metrics
        total_categories = len(results)
        passed_categories = sum(1 for code, _ in results.values() if code == 0)
        failed_categories = total_categories - passed_categories
        
        html_content += f"""
    <div class="summary">
        <h2>📊 Summary</h2>
        <div class="metrics">
            <div class="metric">
                <h3>{total_categories}</h3>
                <p>Total Categories</p>
            </div>
            <div class="metric">
                <h3>{passed_categories}</h3>
                <p>Passed</p>
            </div>
            <div class="metric">
                <h3>{failed_categories}</h3>
                <p>Failed</p>
            </div>
        </div>
    </div>
    
    <h2>📋 Category Results</h2>
        """
        
        # Add results for each category
        for category, (returncode, output) in results.items():
            status_class = "passed" if returncode == 0 else "failed"
            status_text = "✅ PASSED" if returncode == 0 else "❌ FAILED"
            
            config = self.test_categories.get(category, {})
            description = config.get("description", "No description available")
            
            html_content += f"""
    <div class="category {status_class}">
        <h3>{category.upper()} - {status_text}</h3>
        <p><strong>Description:</strong> {description}</p>
        <p><strong>Exit Code:</strong> {returncode}</p>
        <details>
            <summary>View Output</summary>
            <pre>{output[:2000]}{'...' if len(output) > 2000 else ''}</pre>
        </details>
    </div>
            """
        
        html_content += """
    <div style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 5px;">
        <h3>📁 Report Files</h3>
        <p>Detailed reports have been generated in the test_reports directory:</p>
        <ul>
            <li><strong>XML Reports:</strong> *_results.xml (for CI/CD integration)</li>
            <li><strong>HTML Reports:</strong> *_report.html (detailed test results)</li>
            <li><strong>Coverage Reports:</strong> *_coverage/ (code coverage analysis)</li>
        </ul>
    </div>
</body>
</html>
        """
        
        with open(report_path, "w") as f:
            f.write(html_content)
        
        print(f"\n📋 Summary report generated: {report_path}")
        return report_path
    
    def setup_environment(self):
        """Set up the test environment."""
        print("🔧 Setting up test environment...")
        
        # Ensure test reports directory exists
        self.reports_dir.mkdir(exist_ok=True)
        
        # Set environment variables for tests
        test_env = {
            "PYTHONPATH": str(self.project_root),
            "TEST_MODE": "true",
            "TEST_REPORTS_DIR": str(self.reports_dir)
        }
        
        for key, value in test_env.items():
            os.environ[key] = value
        
        print("✅ Test environment ready")
    
    def check_dependencies(self):
        """Check that required test dependencies are installed."""
        required_packages = [
            "pytest",
            "pytest-asyncio", 
            "pytest-cov",
            "pytest-html",
            "pytest-timeout"
        ]
        
        missing_packages = []
        
        for package in required_packages:
            try:
                __import__(package.replace("-", "_"))
            except ImportError:
                missing_packages.append(package)
        
        if missing_packages:
            print("❌ Missing required test dependencies:")
            for package in missing_packages:
                print(f"  - {package}")
            print("\nInstall missing dependencies with:")
            print(f"pip install {' '.join(missing_packages)}")
            return False
        
        print("✅ All test dependencies are installed")
        return True


def main():
    """Main test runner function."""
    parser = argparse.ArgumentParser(
        description="Comprehensive test runner for unified context system",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/run_tests.py --all                    # Run all tests
  python scripts/run_tests.py --category unit          # Run only unit tests
  python scripts/run_tests.py --category performance   # Run performance tests
  python scripts/run_tests.py --test tests/test_git_adapter_unit.py  # Run specific test
  python scripts/run_tests.py --all --coverage         # Run all tests with coverage
        """
    )
    
    # Test execution options
    parser.add_argument("--all", action="store_true", help="Run all test categories")
    parser.add_argument("--category", choices=TestRunner(Path.cwd()).test_categories.keys(), 
                       help="Run specific test category")
    parser.add_argument("--test", help="Run specific test file or function")
    
    # Configuration options
    parser.add_argument("--coverage", action="store_true", help="Generate coverage reports")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--fail-fast", action="store_true", help="Stop on first failure")
    parser.add_argument("--capture", choices=["yes", "no"], default="yes", 
                       help="Capture output (no for debugging)")
    parser.add_argument("--parallel", action="store_true", help="Run tests in parallel")
    parser.add_argument("--workers", type=int, default=4, help="Number of parallel workers")
    
    # Special options
    parser.add_argument("--include-performance", action="store_true", 
                       help="Include performance tests in --all")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be run")
    parser.add_argument("--list-categories", action="store_true", help="List available test categories")
    
    args = parser.parse_args()
    
    # Initialize test runner
    project_root = Path.cwd()
    runner = TestRunner(project_root)
    
    # Handle list categories
    if args.list_categories:
        print("📋 Available test categories:")
        for category, config in runner.test_categories.items():
            print(f"  {category:12} - {config['description']}")
        return 0
    
    # Check dependencies
    if not runner.check_dependencies():
        return 1
    
    # Set up environment
    runner.setup_environment()
    
    # Handle dry run
    if args.dry_run:
        if args.all:
            print("Would run all test categories")
        elif args.category:
            print(f"Would run category: {args.category}")
        elif args.test:
            print(f"Would run test: {args.test}")
        return 0
    
    # Run tests based on arguments
    results = {}
    
    try:
        if args.all:
            print("🚀 Running all test categories...")
            results = runner.run_all(
                coverage=args.coverage,
                verbose=args.verbose,
                fail_fast=args.fail_fast,
                capture=args.capture,
                parallel=args.parallel,
                workers=args.workers,
                include_performance=args.include_performance
            )
        
        elif args.category:
            print(f"🚀 Running {args.category} tests...")
            returncode, output = runner.run_category(
                args.category,
                coverage=args.coverage,
                verbose=args.verbose,
                fail_fast=args.fail_fast,
                capture=args.capture,
                parallel=args.parallel,
                workers=args.workers
            )
            results[args.category] = (returncode, output)
        
        elif args.test:
            print(f"🚀 Running specific test: {args.test}")
            returncode, output = runner.run_specific_test(
                args.test,
                verbose=args.verbose,
                capture=args.capture
            )
            results["specific"] = (returncode, output)
        
        else:
            parser.print_help()
            return 1
        
        # Generate summary report
        if results:
            runner.generate_summary_report(results)
            
            # Print final summary
            print(f"\n{'='*60}")
            print("🏁 FINAL RESULTS")
            print(f"{'='*60}")
            
            total_failed = 0
            for category, (returncode, _) in results.items():
                status = "✅ PASSED" if returncode == 0 else "❌ FAILED"
                print(f"{status} - {category}")
                if returncode != 0:
                    total_failed += 1
            
            if total_failed == 0:
                print("\n🎉 All tests PASSED!")
                return 0
            else:
                print(f"\n💥 {total_failed} test category(ies) FAILED")
                return 1
    
    except KeyboardInterrupt:
        print("\n⚠️  Tests interrupted by user")
        return 130
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())