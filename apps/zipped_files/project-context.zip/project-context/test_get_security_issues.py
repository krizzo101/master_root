#!/usr/bin/env python3
"""Test script for the new get_security_issues function implementation."""

import asyncio
import sys
import os
from pathlib import Path

# Add the src directory to Python path
project_root = Path(__file__).parent
src_path = project_root / "src"
sys.path.insert(0, str(src_path))

print(f"Project root: {project_root}")
print(f"Adding to path: {src_path}")
print(f"Python path: {sys.path[:3]}")  # Show first 3 entries

try:
    from project_context.tools.maintenance import get_security_issues
    print("✅ Successfully imported get_security_issues")
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Available files in src/project_context/tools/:")
    tools_dir = src_path / "project_context" / "tools"
    if tools_dir.exists():
        for f in tools_dir.iterdir():
            print(f"  {f.name}")
    sys.exit(1)


async def test_get_security_issues():
    """Test the get_security_issues function."""
    print("\n🔧 Testing get_security_issues implementation...")
    
    try:
        result = await get_security_issues()
        
        print("✅ Function executed successfully")
        print(f"📊 Result keys: {list(result.keys())}")
        
        if "error" in result:
            print(f"⚠️  Error returned: {result['error']}")
        else:
            print(f"🔐 Security events found: {result['summary']['total_security_events']}")
            print(f"🚨 Critical events: {result['summary'].get('critical_events', 0)}")
            print(f"⚡ High severity events: {result['summary'].get('high_events', 0)}")
            print(f"📈 Unique sources: {len(result['summary'].get('unique_sources', []))}")
            
            # Show some sample events if they exist
            if result['security_events']:
                print(f"\n📝 Sample events (first 3):")
                for i, event in enumerate(result['security_events'][:3]):
                    print(f"  {i+1}. {event['event_type']}: {event['description']}")
            
            if result['recommendations']:
                print(f"\n💡 Recommendations ({len(result['recommendations'])} total):")
                for i, rec in enumerate(result['recommendations'][:5]):
                    print(f"  {i+1}. {rec}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing function: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_get_security_issues())
    sys.exit(0 if success else 1)