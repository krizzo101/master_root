#!/usr/bin/env python3
"""Test cross-component communication in unified context system."""

import asyncio
import sys
import json
from pathlib import Path

# Add src to path
sys.path.append('src')

from project_context.db.connections import get_db, initialize_connections
from project_context.integrations.context_bridge import ContextBridge

async def test_cross_component_communication():
    """Test communication between PostgreSQL, Neo4j, Redis and Context Bridge."""
    print("🔄 Testing Cross-Component Communication...")
    
    # Test Database Connections
    print("\n📊 Database Connection Tests:")
    
    # Initialize connections
    try:
        db = await get_db()
        
        # PostgreSQL
        try:
            result = await db.fetch_one("SELECT COUNT(*) as count FROM code_elements")
            count = result['count'] if result else 0
            print(f"✅ PostgreSQL: {count} code elements available")
            pg_available = True
        except Exception as e:
            print(f"❌ PostgreSQL: {e}")
            pg_available = False
        
        # Neo4j (with correct credentials)
        try:
            results = await db.run_cypher("MATCH (n) RETURN count(n) as total")
            count = results[0]['total'] if results else 0
            print(f"✅ Neo4j: {count} nodes available")
            neo4j_available = True
        except Exception as e:
            print(f"❌ Neo4j: {e}")
            neo4j_available = False
        
        # Redis
        try:
            if db.redis_client:
                await db.redis_client.ping()
                print(f"✅ Redis: Connection successful")
                redis_available = True
            else:
                print(f"❌ Redis: Not connected")
                redis_available = False
        except Exception as e:
            print(f"❌ Redis: {e}")
            redis_available = False
            
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        pg_available = neo4j_available = redis_available = False
    
    # Test Context Bridge Integration
    print("\n🌉 Context Bridge Integration Tests:")
    try:
        bridge = ContextBridge()
        
        # Test setting context
        test_context = {
            "current_file": "/test/integration.py",
            "active_symbols": ["test_function", "TestClass"],
            "recent_changes": ["file1.py", "file2.py"]
        }
        
        await bridge.set_current_context(test_context)
        print("✅ Context Bridge: Context set successfully")
        
        # Test retrieving context
        context = await bridge.get_current_context()
        print(f"✅ Context Bridge: Retrieved context with {len(context)} items")
        
        bridge_available = True
        
    except Exception as e:
        print(f"❌ Context Bridge: {e}")
        bridge_available = False
    
    # Test Data Flow
    print("\n🔄 Data Flow Tests:")
    
    if pg_available and redis_available:
        try:
            # Test PostgreSQL -> Redis caching using db connection
            cache_key = "test:cross_component"
            cache_data = {"source": "postgresql", "data": "test_value", "timestamp": "2025-09-03T20:00:00Z"}
            
            await db.redis_client.set(cache_key, json.dumps(cache_data))
            cached = await db.redis_client.get(cache_key)
            
            if cached:
                parsed = json.loads(cached)
                print(f"✅ PostgreSQL -> Redis: Data cached and retrieved successfully")
            
            await db.redis_client.delete(cache_key)
            
        except Exception as e:
            print(f"❌ PostgreSQL -> Redis: {e}")
    
    # Performance metrics test
    print("\n⚡ Performance Metrics:")
    
    start_time = asyncio.get_event_loop().time()
    
    # Test concurrent operations
    tasks = []
    
    if pg_available:
        tasks.append(test_pg_query())
    
    if redis_available:
        tasks.append(test_redis_ops())
    
    if bridge_available:
        tasks.append(test_bridge_ops())
    
    if tasks:
        results = await asyncio.gather(*tasks, return_exceptions=True)
        end_time = asyncio.get_event_loop().time()
        
        print(f"✅ Concurrent Operations: {len([r for r in results if not isinstance(r, Exception)])} successful")
        print(f"⏱️  Total Time: {end_time - start_time:.2f}s")
    
    # Summary
    print(f"\n📊 Component Status Summary:")
    print(f"  PostgreSQL: {'✅' if pg_available else '❌'}")
    print(f"  Neo4j: {'✅' if neo4j_available else '❌'}")  
    print(f"  Redis: {'✅' if redis_available else '❌'}")
    print(f"  Context Bridge: {'✅' if bridge_available else '❌'}")
    
    total_components = 4
    working_components = sum([pg_available, neo4j_available, redis_available, bridge_available])
    
    print(f"\n🎯 Integration Health: {working_components}/{total_components} components operational ({working_components/total_components*100:.1f}%)")
    
    return working_components >= 3  # Success if 75% components working

async def test_pg_query():
    """Test PostgreSQL query performance."""
    db = await get_db()
    result = await db.fetch_one("SELECT COUNT(*) as count FROM code_elements WHERE element_type = 'function'")
    return result['count'] if result else 0

async def test_redis_ops():
    """Test Redis operations."""
    db = await get_db()
    if db.redis_client:
        await db.redis_client.set("test:perf", "value")
        result = await db.redis_client.get("test:perf")
        await db.redis_client.delete("test:perf")
        return result
    return None

async def test_bridge_ops():
    """Test Context Bridge operations."""
    bridge = ContextBridge()
    context = await bridge.get_current_context()
    return len(context)

if __name__ == "__main__":
    success = asyncio.run(test_cross_component_communication())
    exit(0 if success else 1)