#!/usr/bin/env python3
"""Integration test for chat adapter with unified schema."""

import asyncio
import json
import tempfile
from datetime import datetime
from pathlib import Path

from src.project_context.ingestion.adapters.chat_adapter import ChatAdapter
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode


async def test_chat_adapter_integration():
    """Test chat adapter integration with sample data."""
    
    # Create sample configuration
    config = AdapterConfig(
        adapter_id="test_integration_chat",
        source_type="chat",
        batch_mode=BatchMode.STREAMING,
        batch_size=10,
        generate_embeddings=True,
        extract_relationships=True,
        skip_duplicates=True,
        source_config={
            "input_format": "jsonl",
            "file_patterns": ["*.jsonl"],
            "watch_directories": [],
            "extract_entities": True,
            "entity_extraction_config": {
                "enable_url_detection": True,
                "enable_code_detection": True,
                "enable_mention_detection": True,
                "enable_issue_detection": True,
                "enable_tech_keyword_detection": True,
                "enable_email_detection": True,
                "enable_file_path_detection": True,
                "enable_command_detection": True,
                "enable_timestamp_detection": True,
                "enable_named_entity_recognition": False,
                "max_entities_per_type": 50,
            },
            "embedding_config": {
                "service": "simple",  # Use simple embedding for testing
                "model": "test-model",
                "api_key": None,
                "max_tokens": 1000,
                "batch_size": 32,
            },
            "checkpoint_directory": tempfile.gettempdir(),
            "max_checkpoint_hashes": 1000,
        }
    )
    
    # Create sample chat messages
    sample_messages = [
        {
            "id": "msg_001",
            "user_id": "alice_dev",
            "content": "I'm having trouble with the authentication service at /app/auth/service.py. The JWT tokens are not being validated correctly.",
            "timestamp": "2024-01-15T14:30:00Z",
            "conversation_id": "tech_discussion_001",
            "type": "message"
        },
        {
            "id": "msg_002",
            "user_id": "claude_assistant",
            "content": "I can help you debug that! Can you share the error message you're seeing? Also, have you checked if the JWT_SECRET environment variable is set correctly?",
            "timestamp": "2024-01-15T14:31:30Z",
            "conversation_id": "tech_discussion_001",
            "type": "message",
            "is_bot": True
        },
        {
            "id": "msg_003",
            "user_id": "alice_dev",
            "content": "Here's the error: `InvalidTokenError: Unable to decode token`. I'm using the command `python -m pytest tests/test_auth.py -v` to test it. See issue #AUTH-125 for more context.",
            "timestamp": "2024-01-15T14:32:45Z",
            "conversation_id": "tech_discussion_001",
            "type": "message",
            "parent_id": "msg_002"
        },
        {
            "id": "msg_004",
            "user_id": "bob_engineer",
            "content": "I had a similar issue last week. Check if your JWT library version is compatible. We're using PyJWT 2.8.0 with Redis for token storage.",
            "timestamp": "2024-01-15T14:35:20Z",
            "conversation_id": "tech_discussion_001", 
            "type": "message"
        },
        {
            "id": "msg_005",
            "user_id": "system",
            "content": "Alice mentioned @claude_assistant in the discussion",
            "timestamp": "2024-01-15T14:36:00Z",
            "conversation_id": "tech_discussion_001",
            "type": "system"
        }
    ]
    
    # Create temporary JSONL file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False) as temp_file:
        for message in sample_messages:
            json.dump(message, temp_file)
            temp_file.write('\n')
        temp_file_path = temp_file.name
    
    try:
        # Update config to use temporary file
        config.source_config["watch_directories"] = [str(Path(temp_file_path).parent)]
        
        # Initialize chat adapter
        print("🚀 Initializing Chat Adapter...")
        adapter = ChatAdapter(config)
        await adapter.initialize()
        
        try:
            print("📨 Processing chat messages...")
            
            processed_items = []
            relationships = []
            
            # Process messages
            async for raw_message in adapter.fetch_items():
                print(f"  Processing message: {raw_message['id']}")
                
                # Transform message to ContextItem
                context_item = await adapter.transform_item(raw_message)
                
                if context_item is None:  # Skipped due to deduplication
                    print(f"    ⚠️  Message {raw_message['id']} was deduplicated")
                    continue
                    
                processed_items.append(context_item)
                
                print(f"    ✅ Transformed to ContextItem:")
                print(f"       - ID: {context_item.id}")
                print(f"       - Source ID: {context_item.source_id}")
                print(f"       - Actor: {context_item.actor_id} ({context_item.actor_type})")
                print(f"       - Content length: {len(context_item.content or '')}")
                print(f"       - Session: {context_item.session_id}")
                print(f"       - Entity type: {context_item.entity_type}")
                
                # Check embeddings
                if context_item.embedding:
                    print(f"       - Embedding: {len(context_item.embedding)} dimensions")
                
                # Check extracted entities
                if context_item.metrics and "extracted_entities" in context_item.metrics:
                    entities = context_item.metrics["extracted_entities"]
                    print(f"       - Extracted entities:")
                    for entity_type, entity_list in entities.items():
                        if entity_list:
                            print(f"         • {entity_type}: {entity_list}")
                
                # Detect relationships with previous items
                if len(processed_items) > 1:
                    context_window = processed_items[-10:]  # Last 10 items
                    item_relationships = await adapter.detect_relationships(context_item, context_window[:-1])
                    if item_relationships:
                        relationships.extend(item_relationships)
                        print(f"       - Relationships found: {len(item_relationships)}")
                        for rel_type, target_id, confidence in item_relationships:
                            print(f"         • {rel_type} -> {target_id} (confidence: {confidence:.2f})")
                
                print()
            
            # Summary
            print("📊 Processing Summary:")
            print(f"   Total items processed: {len(processed_items)}")
            print(f"   Total relationships detected: {len(relationships)}")
            
            # Entity analysis
            all_entities = {}
            embedding_count = 0
            
            for item in processed_items:
                if item.embedding:
                    embedding_count += 1
                    
                if item.metrics and "extracted_entities" in item.metrics:
                    for entity_type, entity_list in item.metrics["extracted_entities"].items():
                        if entity_type not in all_entities:
                            all_entities[entity_type] = set()
                        all_entities[entity_type].update(entity_list)
            
            print(f"   Items with embeddings: {embedding_count}")
            print(f"   Unique entity types found: {len(all_entities)}")
            
            for entity_type, entity_set in all_entities.items():
                print(f"     • {entity_type}: {len(entity_set)} unique entities")
                # Show sample entities
                sample_entities = list(entity_set)[:3]
                if sample_entities:
                    print(f"       Examples: {', '.join(sample_entities)}")
            
            # Relationship analysis  
            relationship_types = {}
            for rel_type, _, confidence in relationships:
                if rel_type not in relationship_types:
                    relationship_types[rel_type] = []
                relationship_types[rel_type].append(confidence)
            
            print(f"   Relationship types found: {len(relationship_types)}")
            for rel_type, confidences in relationship_types.items():
                avg_confidence = sum(confidences) / len(confidences)
                print(f"     • {rel_type}: {len(confidences)} instances, avg confidence: {avg_confidence:.2f}")
            
            # Validate data structure compatibility
            print("\n🔍 Schema Compatibility Check:")
            for i, item in enumerate(processed_items):
                try:
                    # Attempt to serialize to dict (simulates database storage)
                    item_dict = item.to_dict()
                    
                    # Check required fields
                    required_fields = ["id", "source_type", "source_id", "timestamp"]
                    for field in required_fields:
                        if field not in item_dict or item_dict[field] is None:
                            print(f"   ❌ Item {i}: Missing required field '{field}'")
                        else:
                            print(f"   ✅ Item {i}: Valid '{field}': {item_dict[field]}")
                    
                    # Check data types
                    if item_dict.get("embedding") and not isinstance(item_dict["embedding"], list):
                        print(f"   ❌ Item {i}: Embedding is not a list")
                    elif item_dict.get("embedding"):
                        print(f"   ✅ Item {i}: Embedding is valid list with {len(item_dict['embedding'])} elements")
                    
                except Exception as e:
                    print(f"   ❌ Item {i}: Serialization error: {e}")
            
            print("\n✨ Integration test completed successfully!")
            return True
            
        finally:
            await adapter.cleanup()
            
    finally:
        # Clean up temp file
        Path(temp_file_path).unlink(missing_ok=True)


async def main():
    """Run the integration test."""
    try:
        success = await test_chat_adapter_integration()
        if success:
            print("🎉 All integration tests passed!")
        else:
            print("❌ Integration tests failed!")
    except Exception as e:
        print(f"💥 Integration test error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())