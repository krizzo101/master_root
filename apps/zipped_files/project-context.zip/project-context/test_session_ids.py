#!/usr/bin/env python3
"""
Test Plan: Validate Deterministic Session ID Implementation
Tests the EnhancedOrchestrator session ID mapping before Phase 2+ execution
"""
import asyncio
import sys
import json
from pathlib import Path

# Add paths for imports
sys.path.append("/home/opsvi/master_root/apps/agent-orchestrator")
sys.path.append("/home/opsvi/master_root/apps/project-context")

from src.enhanced_orchestrator import EnhancedAgentTask, EnhancedOrchestrator
from src.execution_plan.adapter import ExecutionPlanAdapter
from execution_plan_schema import TaskType
from execution_plan_template import ExecutionPlanBuilder


async def test_deterministic_session_ids():
    """Test that session IDs are deterministic and trackable"""
    
    print("🧪 TESTING DETERMINISTIC SESSION ID IMPLEMENTATION")
    print("=" * 60)
    
    # Test 1: Create a small test execution plan
    print("📋 TEST 1: Creating test ExecutionPlan...")
    
    builder = ExecutionPlanBuilder("SessionID_Test_Plan")
    
    # Add test tasks that we can monitor
    builder.add_task(
        "test_research",
        TaskType.RESEARCH_GENIUS,
        "Research the current time and date for testing purposes"
    )
    
    builder.add_task(
        "test_simple_calc", 
        TaskType.DEVELOPMENT_SPECIALIST,
        "Calculate 2 + 2 and explain the result"
    )
    
    builder.add_task(
        "test_file_check",
        TaskType.GENERAL_PURPOSE,
        "Check if this test script exists and report its size",
        dependencies=["test_research"]
    )
    
    test_plan = builder.build()
    print(f"   ✅ Test plan created: {len(test_plan.tasks)} tasks")
    
    # Test 2: Convert to EnhancedAgentTasks
    print("\n🔄 TEST 2: Converting to EnhancedAgentTasks...")
    
    adapter = ExecutionPlanAdapter()
    enhanced_tasks = adapter.convert_execution_plan(test_plan)
    
    # Enable monitoring to get deterministic session IDs
    for task in enhanced_tasks:
        task.monitoring_enabled = True
        task.priority_level = "HIGH"  # Use high priority for faster execution
    
    print(f"   ✅ Converted {len(enhanced_tasks)} tasks to EnhancedAgentTasks")
    
    # Test 3: Verify session IDs are deterministic and predictable
    print("\n🎯 TEST 3: Verifying deterministic session IDs...")
    
    session_mappings = {}
    for task in enhanced_tasks:
        session_id = task.agent_uuid
        session_mappings[task.task_id] = session_id
        print(f"   {task.task_id} → {session_id}")
    
    # Test deterministic generation by recreating the same plan
    print("\n🔍 TEST 3a: Verifying reproducibility...")
    builder2 = ExecutionPlanBuilder("SessionID_Test_Plan")  # Same name
    builder2.add_task("test_research", TaskType.RESEARCH_GENIUS, "Research the current time and date for testing purposes")
    builder2.add_task("test_simple_calc", TaskType.DEVELOPMENT_SPECIALIST, "Calculate 2 + 2 and explain the result")
    builder2.add_task("test_file_check", TaskType.GENERAL_PURPOSE, "Check if this test script exists and report its size", dependencies=["test_research"])
    
    test_plan2 = builder2.build()
    enhanced_tasks2 = adapter.convert_execution_plan(test_plan2)
    
    reproducible = True
    for i, task in enumerate(enhanced_tasks2):
        original_uuid = enhanced_tasks[i].agent_uuid
        new_uuid = task.agent_uuid
        if original_uuid != new_uuid:
            print(f"   ❌ UUID mismatch for {task.task_id}: {original_uuid} vs {new_uuid}")
            reproducible = False
    
    if reproducible:
        print("   ✅ Session IDs are reproducible across plan recreations")
    else:
        print("   ❌ Session IDs are NOT reproducible - this needs fixing!")
        return False
    
    # Test 4: Setup test execution environment
    print("\n🚀 TEST 4: Setting up test execution...")
    
    test_output_dir = Path("/home/opsvi/master_root/apps/project-context/session_id_test_output")
    test_output_dir.mkdir(exist_ok=True)
    
    # Use minimal parallelization for testing
    orchestrator = EnhancedOrchestrator(
        output_dir=test_output_dir,
        max_parallel=2,  # Small number for testing
        use_optimizations=True,
        enable_monitoring=True
    )
    
    print(f"   ✅ Test orchestrator initialized")
    print(f"   📁 Test output: {test_output_dir}")
    
    # Test 5: Execute test tasks and monitor session logs
    print("\n⚡ TEST 5: Executing test tasks...")
    print("   Expected session log files:")
    
    claude_logs_dir = Path.home() / ".claude" / "projects"
    for task_id, session_id in session_mappings.items():
        print(f"     {task_id}: ~/.claude/projects/*/{session_id}.jsonl")
    
    # Execute the test batch
    try:
        print("\n   🔄 Starting test execution...")
        results = await orchestrator.execute_batch(enhanced_tasks)
        
        print(f"\n   ✅ Test execution completed!")
        print(f"   Results: {len(results)} tasks executed")
        
        # Analyze results
        successful = [r for r in results if r.get('status') == 'completed']
        failed = [r for r in results if r.get('status') == 'failed']
        
        print(f"   ✅ Successful: {len(successful)}")
        print(f"   ❌ Failed: {len(failed)}")
        
        if failed:
            print("   Failed tasks:")
            for task in failed:
                print(f"     - {task.get('task_id')}: {task.get('error', 'Unknown error')}")
        
    except Exception as e:
        print(f"   ❌ Test execution failed: {str(e)}")
        return False
    
    # Test 6: Verify session log files exist and contain expected data
    print("\n📊 TEST 6: Verifying session log files...")
    
    logs_found = 0
    logs_expected = len(session_mappings)
    
    for task_id, session_id in session_mappings.items():
        log_found = False
        
        # Search for session log in all project directories
        if claude_logs_dir.exists():
            for project_dir in claude_logs_dir.glob("*"):
                if project_dir.is_dir():
                    session_file = project_dir / f"{session_id}.jsonl"
                    if session_file.exists():
                        log_found = True
                        logs_found += 1
                        
                        # Verify log content
                        try:
                            with open(session_file, 'r') as f:
                                log_lines = f.readlines()
                                print(f"   ✅ {task_id} → {len(log_lines)} log entries")
                                
                                # Show sample log entry
                                if log_lines:
                                    sample = json.loads(log_lines[0])
                                    log_type = sample.get('type', 'unknown')
                                    print(f"      Sample log type: {log_type}")
                        
                        except Exception as e:
                            print(f"   ⚠️  {task_id} log file exists but can't read: {e}")
                        break
        
        if not log_found:
            print(f"   ❌ No log file found for {task_id} (session: {session_id})")
    
    print(f"\n   📊 Session logs found: {logs_found}/{logs_expected}")
    
    if logs_found == logs_expected:
        print("   ✅ All session logs created successfully!")
    else:
        print("   ⚠️  Some session logs missing - check configuration")
    
    # Test Summary
    print("\n🎯 TEST SUMMARY")
    print("=" * 40)
    
    test_results = {
        "plan_creation": True,
        "task_conversion": True,
        "session_id_deterministic": reproducible,
        "execution_setup": True,
        "task_execution": len(failed) == 0,
        "session_logs_created": logs_found >= (logs_expected * 0.8)  # 80% threshold
    }
    
    all_passed = all(test_results.values())
    
    for test_name, passed in test_results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"   {test_name}: {status}")
    
    print()
    if all_passed:
        print("🎉 ALL TESTS PASSED!")
        print("✅ Deterministic session ID implementation is ready for Phase 2+ execution")
        print()
        print("📋 Session ID mappings for monitoring:")
        for task_id, session_id in session_mappings.items():
            print(f"   {task_id} → {session_id}")
        print()
        print("🚀 Ready to execute: python execute_phase2_optimized.py")
    else:
        print("❌ TESTS FAILED!")
        print("🔧 Fix issues before proceeding with Phase 2+ execution")
    
    return all_passed


async def main():
    """Run the session ID validation tests"""
    success = await test_deterministic_session_ids()
    
    if success:
        print("\n💡 NEXT STEPS:")
        print("1. Review session log files to ensure they contain expected data")
        print("2. Test monitoring with: python monitor_multi_phase.py")
        print("3. Execute Phase 2 with: python execute_phase2_optimized.py")
    else:
        print("\n🔧 TROUBLESHOOTING:")
        print("1. Check EnhancedOrchestrator configuration")
        print("2. Verify ExecutionPlanAdapter session ID generation")
        print("3. Ensure Claude CLI has proper permissions for log creation")
    
    return success


if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)