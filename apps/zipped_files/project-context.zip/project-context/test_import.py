#!/usr/bin/env python3
"""Test basic imports for MCP integration."""

import sys
from pathlib import Path

# Add project to path
sys.path.append(str(Path(__file__).parent / "src"))

def test_imports():
    """Test all required imports for MCP integration."""
    try:
        print("Testing basic imports...")
        
        # Test basic ingestion imports
        from project_context.ingestion.adapters.chat_adapter import ChatAdapter
        from project_context.ingestion.adapters.code_adapter import CodeAdapter
        print("✅ Adapter imports successful")
        
        # Test orchestrator
        from project_context.ingestion.orchestrator import PipelineOrchestrator
        print("✅ Orchestrator import successful")
        
        # Test pipeline
        from project_context.ingestion.pipeline import IngestionPipeline
        print("✅ Pipeline import successful")
        
        # Test ingestion tools
        from project_context.tools.ingestion_tools import (
            start_ingestion_pipeline,
            get_pipeline_status,
            validate_adapter_integration
        )
        print("✅ Ingestion tools import successful")
        
        # Test tools registration
        from project_context.tools import register_all_tools
        print("✅ Tools registration import successful")
        
        # Test FastMCP
        try:
            from fastmcp import FastMCP
            print("✅ FastMCP import successful")
        except ImportError:
            print("❌ FastMCP not available - may need to install")
        
        print("\n🎉 All imports successful! MCP integration should work.")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

if __name__ == "__main__":
    success = test_imports()
    sys.exit(0 if success else 1)