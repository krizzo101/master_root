#!/usr/bin/env python3
"""Test script for the get_todos MCP tool."""

import asyncio
import json
import sys
import os

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from project_context.tools.maintenance import get_todos

async def test_get_todos():
    """Test the get_todos function."""
    print("Testing get_todos MCP tool...")
    print("=" * 50)
    
    try:
        # Call the get_todos function
        result = await get_todos()
        
        # Print basic stats
        if "error" in result:
            print(f"❌ Error occurred: {result['error']}")
            return False
        
        print("✅ get_todos executed successfully!")
        print("\n📊 STATISTICS:")
        stats = result.get("stats", {})
        print(f"  • Total TODO items: {stats.get('total_items', 0)}")
        print(f"  • TODO count: {stats.get('todos_count', 0)}")
        print(f"  • FIXME count: {stats.get('fixmes_count', 0)}")
        print(f"  • HACK count: {stats.get('hacks_count', 0)}")
        print(f"  • Files with TODOs: {stats.get('unique_files_count', 0)}")
        print(f"  • Files with recent activity: {stats.get('files_with_recent_activity', 0)}")
        print(f"  • Average age (days): {stats.get('avg_age_days', 0):.1f}")
        
        print("\n🔍 PRIORITY DISTRIBUTION:")
        priority_dist = stats.get("priority_distribution", {})
        for priority, count in priority_dist.items():
            print(f"  • {priority.capitalize()}: {count}")
        
        print("\n⏱️  TIME-SERIES DATA:")
        time_series = result.get("time_series", {})
        change_patterns = time_series.get("change_patterns", {})
        print(f"  • Historical changes - Added: {change_patterns.get('added', 0)}, "
              f"Resolved: {change_patterns.get('resolved', 0)}, "
              f"Modified: {change_patterns.get('modified', 0)}")
        
        activity_files = len(time_series.get("activity_by_file", {}))
        print(f"  • Files with activity tracking: {activity_files}")
        
        history_count = len(time_series.get("todo_history", []))
        print(f"  • Historical TODO records: {history_count}")
        
        # Show sample TODO items if any exist
        if result.get("todos"):
            print("\n📝 SAMPLE TODOs:")
            for i, todo in enumerate(result["todos"][:3], 1):
                print(f"  {i}. [{todo['priority'].upper()}] {todo['text']}")
                print(f"     File: {todo['file_path']}:{todo['line_number']}")
                ts_data = todo.get('time_series', {})
                if ts_data.get('age_days') is not None:
                    print(f"     Age: {ts_data['age_days']} days")
        
        print("\n" + "=" * 50)
        print("✅ Test completed successfully!")
        
        # Optionally save full result to file for inspection
        with open('/tmp/get_todos_result.json', 'w') as f:
            json.dump(result, f, indent=2, default=str)
        print("📄 Full result saved to /tmp/get_todos_result.json")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(test_get_todos())
    sys.exit(0 if success else 1)