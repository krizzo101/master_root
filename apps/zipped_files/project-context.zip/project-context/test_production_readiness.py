#!/usr/bin/env python3
"""Validate production readiness of unified context system."""

import asyncio
import sys
import json
import os
import time
from pathlib import Path
import subprocess

# Add src to path
sys.path.append('src')

def test_docker_configuration():
    """Test Docker production configuration."""
    print("🐳 Testing Docker Configuration...")
    
    results = {}
    
    # Test 1: Docker Compose file validity
    print("  Checking docker-compose.prod.yml...", end=" ")
    compose_file = Path("docker-compose.prod.yml")
    if compose_file.exists():
        try:
            result = subprocess.run(
                ["docker-compose", "-f", str(compose_file), "config"],
                capture_output=True, text=True, cwd="."
            )
            if result.returncode == 0:
                results['docker_compose_valid'] = True
                print("✅ (valid)")
            else:
                results['docker_compose_valid'] = False
                print(f"❌ (invalid: {result.stderr[:100]}...)")
        except FileNotFoundError:
            results['docker_compose_valid'] = False
            print("❌ (docker-compose not found)")
    else:
        results['docker_compose_valid'] = False
        print("❌ (file not found)")
    
    # Test 2: Dockerfile production readiness
    print("  Checking Dockerfile.prod...", end=" ")
    dockerfile = Path("Dockerfile.prod")
    if dockerfile.exists():
        content = dockerfile.read_text()
        
        # Check for production best practices
        has_non_root_user = "USER " in content and "root" not in content.split("USER")[-1]
        has_healthcheck = "HEALTHCHECK" in content
        has_minimal_layers = content.count("RUN") <= 5  # Reasonable number of layers
        
        if has_non_root_user and has_healthcheck and has_minimal_layers:
            results['dockerfile_production_ready'] = True
            print("✅ (production ready)")
        else:
            results['dockerfile_production_ready'] = False
            issues = []
            if not has_non_root_user: issues.append("no non-root user")
            if not has_healthcheck: issues.append("no healthcheck")
            if not has_minimal_layers: issues.append("too many layers")
            print(f"⚠️ (issues: {', '.join(issues)})")
    else:
        results['dockerfile_production_ready'] = False
        print("❌ (file not found)")
    
    # Test 3: Environment configuration
    print("  Checking environment configuration...", end=" ")
    env_example = Path(".env.example")
    if env_example.exists():
        content = env_example.read_text()
        
        # Check for required production settings
        has_db_config = all(x in content for x in ["DB_NAME", "DB_USER", "DB_PASSWORD"])
        has_security_config = all(x in content for x in ["API_KEY", "JWT_SECRET"])
        has_monitoring_config = "PROMETHEUS" in content and "LOG_LEVEL" in content
        has_ssl_config = "SSL_" in content
        
        if has_db_config and has_security_config and has_monitoring_config:
            results['env_config_complete'] = True
            print("✅ (comprehensive)")
        else:
            results['env_config_complete'] = False
            missing = []
            if not has_db_config: missing.append("database")
            if not has_security_config: missing.append("security")
            if not has_monitoring_config: missing.append("monitoring")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['env_config_complete'] = False
        print("❌ (.env.example not found)")
    
    return results

def test_security_configuration():
    """Test security configuration."""
    print("🔒 Testing Security Configuration...")
    
    results = {}
    
    # Test 1: Database security
    print("  Checking database security...", end=" ")
    env_example = Path(".env.example")
    if env_example.exists():
        content = env_example.read_text()
        
        # Check for secure defaults
        has_strong_passwords = "your_secure" in content.lower()
        has_jwt_config = "JWT_SECRET" in content
        has_cors_config = "CORS_ORIGINS" in content
        has_rate_limiting = "RATE_LIMIT" in content
        
        security_score = sum([has_strong_passwords, has_jwt_config, has_cors_config, has_rate_limiting])
        
        if security_score >= 3:
            results['database_security'] = True
            print(f"✅ ({security_score}/4 security features)")
        else:
            results['database_security'] = False
            print(f"⚠️ ({security_score}/4 security features)")
    else:
        results['database_security'] = False
        print("❌ (no security config found)")
    
    # Test 2: SSL/TLS configuration
    print("  Checking SSL/TLS configuration...", end=" ")
    nginx_config = Path("nginx/nginx.conf")
    if nginx_config.exists():
        content = nginx_config.read_text()
        
        has_ssl_redirect = "return 301 https://" in content
        has_ssl_certs = "ssl_certificate" in content
        has_security_headers = "X-Frame-Options" in content or "X-Content-Type-Options" in content
        
        if has_ssl_redirect and has_ssl_certs and has_security_headers:
            results['ssl_tls_config'] = True
            print("✅ (complete SSL/TLS setup)")
        else:
            results['ssl_tls_config'] = False
            missing = []
            if not has_ssl_redirect: missing.append("HTTPS redirect")
            if not has_ssl_certs: missing.append("SSL certificates")
            if not has_security_headers: missing.append("security headers")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['ssl_tls_config'] = False
        print("❌ (nginx config not found)")
    
    return results

def test_monitoring_configuration():
    """Test monitoring and observability configuration."""
    print("📊 Testing Monitoring Configuration...")
    
    results = {}
    
    # Test 1: Prometheus configuration
    print("  Checking Prometheus setup...", end=" ")
    prometheus_config = Path("monitoring/prometheus.yml")
    if prometheus_config.exists():
        content = prometheus_config.read_text()
        
        has_scrape_configs = "scrape_configs:" in content
        has_project_context_target = "project-context" in content
        has_retention_policy = "retention" in content
        
        if has_scrape_configs and has_project_context_target:
            results['prometheus_config'] = True
            print("✅ (properly configured)")
        else:
            results['prometheus_config'] = False
            print("⚠️ (incomplete configuration)")
    else:
        results['prometheus_config'] = False
        print("❌ (config file not found)")
    
    # Test 2: Grafana dashboards
    print("  Checking Grafana dashboards...", end=" ")
    grafana_dir = Path("monitoring/grafana")
    if grafana_dir.exists():
        dashboard_files = list(grafana_dir.rglob("*.json"))
        datasource_files = list(grafana_dir.rglob("datasources/*.yml"))
        
        if len(dashboard_files) >= 1 and len(datasource_files) >= 1:
            results['grafana_dashboards'] = True
            print(f"✅ ({len(dashboard_files)} dashboards, {len(datasource_files)} datasources)")
        else:
            results['grafana_dashboards'] = False
            print(f"⚠️ ({len(dashboard_files)} dashboards, {len(datasource_files)} datasources)")
    else:
        results['grafana_dashboards'] = False
        print("❌ (grafana directory not found)")
    
    # Test 3: Logging configuration
    print("  Checking logging configuration...", end=" ")
    docker_compose = Path("docker-compose.prod.yml")
    if docker_compose.exists():
        content = docker_compose.read_text()
        
        has_log_rotation = "max-size" in content and "max-file" in content
        has_log_driver = "logging:" in content
        has_log_level = "LOG_LEVEL" in content
        
        if has_log_rotation and has_log_driver and has_log_level:
            results['logging_config'] = True
            print("✅ (comprehensive logging)")
        else:
            results['logging_config'] = False
            missing = []
            if not has_log_rotation: missing.append("rotation")
            if not has_log_driver: missing.append("driver")
            if not has_log_level: missing.append("level config")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['logging_config'] = False
        print("❌ (docker-compose not found)")
    
    return results

def test_backup_and_recovery():
    """Test backup and recovery procedures."""
    print("💾 Testing Backup & Recovery...")
    
    results = {}
    
    # Test 1: Database backup configuration
    print("  Checking database backup setup...", end=" ")
    backup_script = Path("scripts/backup.sh")
    if backup_script.exists():
        content = backup_script.read_text()
        
        has_pg_dump = "pg_dump" in content
        has_retention = "RETENTION" in content or "days" in content.lower()
        has_compression = "gzip" in content or ".gz" in content
        
        if has_pg_dump and has_retention and has_compression:
            results['database_backup'] = True
            print("✅ (complete backup solution)")
        else:
            results['database_backup'] = False
            missing = []
            if not has_pg_dump: missing.append("pg_dump")
            if not has_retention: missing.append("retention")
            if not has_compression: missing.append("compression")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['database_backup'] = False
        print("❌ (backup script not found)")
    
    # Test 2: Volume persistence
    print("  Checking data persistence...", end=" ")
    docker_compose = Path("docker-compose.prod.yml")
    if docker_compose.exists():
        content = docker_compose.read_text()
        
        has_postgres_volume = "postgres-data:" in content
        has_redis_volume = "redis-data:" in content
        has_project_volume = "project-data:" in content
        has_prometheus_volume = "prometheus-data:" in content
        
        volume_count = sum([has_postgres_volume, has_redis_volume, has_project_volume, has_prometheus_volume])
        
        if volume_count >= 3:
            results['data_persistence'] = True
            print(f"✅ ({volume_count}/4 volumes configured)")
        else:
            results['data_persistence'] = False
            print(f"⚠️ ({volume_count}/4 volumes configured)")
    else:
        results['data_persistence'] = False
        print("❌ (docker-compose not found)")
    
    return results

def test_scalability_configuration():
    """Test scalability and performance configuration."""
    print("🚀 Testing Scalability Configuration...")
    
    results = {}
    
    # Test 1: Database optimization
    print("  Checking database optimization...", end=" ")
    optimization_sql = Path("database_optimizations.sql")
    if optimization_sql.exists():
        content = optimization_sql.read_text()
        
        has_indexes = "CREATE INDEX" in content
        has_connection_tuning = "max_connections" in content.lower() or "shared_buffers" in content.lower()
        has_query_optimization = "ANALYZE" in content or "VACUUM" in content
        
        if has_indexes and has_connection_tuning:
            results['database_optimization'] = True
            print("✅ (optimized)")
        else:
            results['database_optimization'] = False
            missing = []
            if not has_indexes: missing.append("indexes")
            if not has_connection_tuning: missing.append("connection tuning")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['database_optimization'] = False
        print("❌ (optimization file not found)")
    
    # Test 2: Redis configuration
    print("  Checking Redis optimization...", end=" ")
    docker_compose = Path("docker-compose.prod.yml")
    if docker_compose.exists():
        content = docker_compose.read_text()
        
        has_memory_limit = "maxmemory" in content
        has_eviction_policy = "maxmemory-policy" in content
        has_persistence = "save " in content or "appendonly" in content
        
        if has_memory_limit and has_eviction_policy and has_persistence:
            results['redis_optimization'] = True
            print("✅ (optimized)")
        else:
            results['redis_optimization'] = False
            missing = []
            if not has_memory_limit: missing.append("memory limit")
            if not has_eviction_policy: missing.append("eviction policy")
            if not has_persistence: missing.append("persistence")
            print(f"⚠️ (missing: {', '.join(missing)})")
    else:
        results['redis_optimization'] = False
        print("❌ (docker-compose not found)")
    
    # Test 3: Application scaling
    print("  Checking application scaling...", end=" ")
    if docker_compose.exists():
        content = docker_compose.read_text()
        
        has_resource_limits = "cpus:" in content or "memory:" in content
        has_restart_policy = "restart:" in content
        has_healthchecks = "healthcheck:" in content
        has_load_balancer = "nginx" in content.lower()
        
        scaling_features = sum([has_resource_limits, has_restart_policy, has_healthchecks, has_load_balancer])
        
        if scaling_features >= 3:
            results['application_scaling'] = True
            print(f"✅ ({scaling_features}/4 scaling features)")
        else:
            results['application_scaling'] = False
            print(f"⚠️ ({scaling_features}/4 scaling features)")
    else:
        results['application_scaling'] = False
        print("❌ (docker-compose not found)")
    
    return results

def test_deployment_automation():
    """Test deployment automation and CI/CD readiness."""
    print("🤖 Testing Deployment Automation...")
    
    results = {}
    
    # Test 1: Health checks
    print("  Checking health check endpoints...", end=" ")
    docker_compose = Path("docker-compose.prod.yml")
    if docker_compose.exists():
        content = docker_compose.read_text()
        
        health_check_count = content.count("healthcheck:")
        services_count = content.count("container_name:")
        
        if health_check_count >= services_count * 0.8:  # 80% of services have health checks
            results['health_checks'] = True
            print(f"✅ ({health_check_count}/{services_count} services)")
        else:
            results['health_checks'] = False
            print(f"⚠️ ({health_check_count}/{services_count} services)")
    else:
        results['health_checks'] = False
        print("❌ (docker-compose not found)")
    
    # Test 2: Environment variable validation
    print("  Checking environment validation...", end=" ")
    main_py = Path("src/project_context/server/main.py")
    if main_py.exists():
        content = main_py.read_text()
        
        has_env_validation = "os.getenv" in content or "getenv" in content
        has_default_values = "default=" in content
        
        if has_env_validation and has_default_values:
            results['env_validation'] = True
            print("✅ (environment validated)")
        else:
            results['env_validation'] = False
            print("⚠️ (limited validation)")
    else:
        results['env_validation'] = False
        print("❌ (main.py not found)")
    
    # Test 3: Documentation completeness
    print("  Checking documentation...", end=" ")
    readme = Path("README.md")
    prod_guide = Path("PRODUCTION_DEPLOYMENT_SUMMARY.md")
    
    has_readme = readme.exists()
    has_prod_guide = prod_guide.exists()
    
    if has_readme and has_prod_guide:
        results['documentation'] = True
        print("✅ (comprehensive)")
    elif has_readme or has_prod_guide:
        results['documentation'] = False
        print("⚠️ (partial)")
    else:
        results['documentation'] = False
        print("❌ (missing)")
    
    return results

async def run_production_readiness_tests():
    """Run comprehensive production readiness validation."""
    print("🏭 Starting Production Readiness Validation")
    print("=" * 60)
    
    # Change to project-context directory for relative path tests
    original_cwd = os.getcwd()
    try:
        # Run all test categories
        docker_results = test_docker_configuration()
        security_results = test_security_configuration()
        monitoring_results = test_monitoring_configuration()
        backup_results = test_backup_and_recovery()
        scalability_results = test_scalability_configuration()
        deployment_results = test_deployment_automation()
        
        # Compile all results
        all_results = {
            **docker_results,
            **security_results,
            **monitoring_results,
            **backup_results,
            **scalability_results,
            **deployment_results
        }
        
        # Analysis
        print(f"\n📊 Production Readiness Report:")
        print("=" * 60)
        
        total_tests = len(all_results)
        passed_tests = sum(1 for v in all_results.values() if v is True)
        
        print(f"\n✅ Overall Readiness:")
        print(f"  Tests Passed: {passed_tests}/{total_tests} ({passed_tests/total_tests:.1%})")
        
        # Category analysis
        categories = {
            'Docker Configuration': ['docker_compose_valid', 'dockerfile_production_ready', 'env_config_complete'],
            'Security': ['database_security', 'ssl_tls_config'],
            'Monitoring': ['prometheus_config', 'grafana_dashboards', 'logging_config'],
            'Backup & Recovery': ['database_backup', 'data_persistence'],
            'Scalability': ['database_optimization', 'redis_optimization', 'application_scaling'],
            'Deployment': ['health_checks', 'env_validation', 'documentation']
        }
        
        category_scores = {}
        for category, tests in categories.items():
            category_passed = sum(1 for test in tests if all_results.get(test, False))
            category_total = len(tests)
            category_scores[category] = (category_passed, category_total)
            
            print(f"\n{category}:")
            for test in tests:
                status = "✅" if all_results.get(test, False) else "❌"
                test_name = test.replace('_', ' ').title()
                print(f"  {status} {test_name}")
        
        # Production readiness assessment
        print(f"\n🎯 Production Readiness Assessment:")
        
        critical_failures = []
        
        # Critical requirements
        if not all_results.get('docker_compose_valid', False):
            critical_failures.append("Invalid Docker configuration")
        
        if not all_results.get('database_security', False):
            critical_failures.append("Inadequate security configuration")
        
        if not all_results.get('database_backup', False):
            critical_failures.append("No backup strategy")
        
        if not all_results.get('health_checks', False):
            critical_failures.append("Missing health checks")
        
        # Overall assessment
        if passed_tests >= int(total_tests * 0.9) and not critical_failures:  # 90%+ and no critical failures
            print("  🚀 PRODUCTION READY: System meets production standards")
            assessment = "production_ready"
        elif passed_tests >= int(total_tests * 0.8) and len(critical_failures) <= 1:  # 80%+ with minimal critical issues
            print("  ⚠️  NEARLY READY: Minor issues need addressing before production")
            if critical_failures:
                print(f"    Critical issues: {', '.join(critical_failures)}")
            assessment = "nearly_ready"
        elif passed_tests >= int(total_tests * 0.6):  # 60%+
            print("  ❌ NOT READY: Significant issues prevent production deployment")
            if critical_failures:
                print(f"    Critical issues: {', '.join(critical_failures)}")
            assessment = "not_ready"
        else:
            print("  ❌ MAJOR ISSUES: System requires substantial work before production")
            assessment = "major_issues"
        
        # Recommendations
        print(f"\n💡 Recommendations:")
        recommendations = []
        
        if not all_results.get('ssl_tls_config', False):
            recommendations.append("Configure SSL/TLS with proper certificates")
        
        if not all_results.get('prometheus_config', False):
            recommendations.append("Set up comprehensive monitoring with Prometheus")
        
        if not all_results.get('database_optimization', False):
            recommendations.append("Optimize database configuration for production load")
        
        if not all_results.get('documentation', False):
            recommendations.append("Complete production deployment documentation")
        
        if recommendations:
            for i, rec in enumerate(recommendations[:5], 1):  # Limit to top 5
                print(f"  {i}. {rec}")
        else:
            print("  ✅ No immediate recommendations - system is well configured")
        
        # Save detailed report
        report = {
            'timestamp': time.time(),
            'test_results': all_results,
            'category_scores': category_scores,
            'summary': {
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'success_rate': passed_tests/total_tests,
                'assessment': assessment,
                'critical_failures': critical_failures,
                'recommendations': recommendations
            }
        }
        
        report_file = f"PRODUCTION_READINESS_REPORT_{int(time.time())}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"\n💾 Detailed production readiness report saved to: {report_file}")
        
        return assessment in ['production_ready', 'nearly_ready']
        
    finally:
        os.chdir(original_cwd)

if __name__ == "__main__":
    success = asyncio.run(run_production_readiness_tests())
    exit(0 if success else 1)