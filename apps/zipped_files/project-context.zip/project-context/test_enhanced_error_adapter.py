#!/usr/bin/env python3
"""
Comprehensive test suite for Enhanced Error Adapter.

Tests all components of the error ingestion system:
- Multi-format log parsing (JSON, structured, plain text)
- Error classification and severity detection
- Stack trace parsing for multiple languages
- Trend analysis and pattern detection
- Error deduplication and clustering
- Performance monitoring and alerting
- Correlation detection with Git commits and chat
"""

import asyncio
import json
import tempfile
import pytest
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any
from unittest.mock import Mock, AsyncMock, patch

# Test imports
from src.project_context.ingestion.adapters.enhanced_error_adapter import (
    EnhancedErrorAdapter,
    ParsedError,
    TrendAnalyzer,
    ErrorDeduplicator,
    PerformanceMonitor,
    ErrorClassifier,
    LogFormatDetector,
    StackTraceParser,
    CorrelationEngine
)
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


class TestLogFormatDetector:
    """Test log format detection capabilities."""
    
    def setup_method(self):
        self.detector = LogFormatDetector()
    
    def test_json_format_detection(self):
        json_line = '{"timestamp": "2024-01-01T10:00:00Z", "level": "ERROR", "message": "Database connection failed"}'
        assert self.detector.detect_format(json_line) == "json"
    
    def test_structured_format_detection(self):
        structured_line = "2024-01-01 10:00:00 ERROR [DatabaseService] Connection timeout after 30 seconds"
        assert self.detector.detect_format(structured_line) == "structured"
    
    def test_plain_format_detection(self):
        plain_line = "Some random error message without structure"
        assert self.detector.detect_format(plain_line) == "plain"


class TestStackTraceParser:
    """Test stack trace parsing for different languages."""
    
    def setup_method(self):
        self.parser = StackTraceParser()
    
    def test_python_stack_trace_parsing(self):
        python_stack = '''Traceback (most recent call last):
  File "/app/main.py", line 25, in process_data
    result = calculate_value(data)
  File "/app/utils.py", line 15, in calculate_value
    return data / divisor
ZeroDivisionError: division by zero'''
        
        elements = self.parser.parse_stack_trace(python_stack)
        assert len(elements) == 2
        assert elements[0].file_path == "/app/main.py"
        assert elements[0].line_number == 25
        assert elements[0].function_name == "process_data"
    
    def test_java_stack_trace_parsing(self):
        java_stack = '''java.lang.NullPointerException: Cannot invoke method
    at com.example.Service.processRequest(Service.java:45)
    at com.example.Controller.handleRequest(Controller.java:123)'''
        
        elements = self.parser.parse_stack_trace(java_stack)
        assert len(elements) == 2
        assert elements[0].class_name == "Service"
        assert elements[0].function_name == "processRequest"
        assert elements[0].line_number == 45
    
    def test_javascript_stack_trace_parsing(self):
        js_stack = '''TypeError: Cannot read property 'length' of undefined
    at processData (main.js:15:10)
    at handleRequest (app.js:45:5)'''
        
        elements = self.parser.parse_stack_trace(js_stack)
        assert len(elements) == 2
        assert elements[0].function_name == "processData"
        assert elements[0].file_path == "main.js"
        assert elements[0].line_number == 15


class TestErrorClassifier:
    """Test error classification and categorization."""
    
    def setup_method(self):
        self.classifier = ErrorClassifier()
    
    def test_network_error_classification(self):
        error = ParsedError(
            error_id="test_001",
            timestamp=datetime.now(),
            severity="high",
            error_type="ConnectionError",
            message="Connection refused to database server at localhost:5432",
            source="test"
        )
        
        categories, confidence = self.classifier.classify_error(error)
        assert "network" in categories
        assert confidence > 0.7
    
    def test_memory_error_classification(self):
        error = ParsedError(
            error_id="test_002",
            timestamp=datetime.now(),
            severity="critical",
            error_type="OutOfMemoryError",
            message="Java heap space exceeded maximum allocation",
            source="test"
        )
        
        categories, confidence = self.classifier.classify_error(error)
        assert "memory" in categories
        assert confidence > 0.8
    
    def test_security_error_classification(self):
        error = ParsedError(
            error_id="test_003",
            timestamp=datetime.now(),
            severity="high",
            error_type="SecurityException",
            message="Unauthorized access attempt detected for user admin",
            source="test"
        )
        
        categories, confidence = self.classifier.classify_error(error)
        assert "security" in categories


class TestTrendAnalyzer:
    """Test error trend analysis and prediction."""
    
    def setup_method(self):
        self.analyzer = TrendAnalyzer(time_window_hours=24)
    
    def test_trend_analysis_increasing(self):
        # Simulate increasing error pattern
        base_time = datetime.now()
        pattern_id = "test_pattern_001"
        
        # Add data points showing increasing trend
        for i in range(5):
            timestamp = base_time - timedelta(hours=4-i)
            count = i + 1  # Increasing count
            self.analyzer.update_pattern_frequency(pattern_id, timestamp, count)
        
        trends = self.analyzer.get_trending_patterns(min_frequency=1, limit=10)
        assert len(trends) == 1
        assert trends[0]['pattern_id'] == pattern_id
        assert trends[0]['trend_direction'] == 'increasing'
    
    def test_future_prediction(self):
        pattern_id = "test_pattern_002"
        base_time = datetime.now()
        
        # Add steady pattern with slight increase
        for i in range(3):
            timestamp = base_time - timedelta(hours=2-i)
            self.analyzer.update_pattern_frequency(pattern_id, timestamp, 2)
        
        prediction = self.analyzer.predict_future_occurrences(pattern_id, hours_ahead=1)
        assert prediction >= 0


class TestErrorDeduplicator:
    """Test error deduplication and clustering."""
    
    def setup_method(self):
        self.deduplicator = ErrorDeduplicator(similarity_threshold=0.8)
    
    def test_error_clustering(self):
        # Create similar errors
        error1 = ParsedError(
            error_id="err_001",
            timestamp=datetime.now(),
            severity="high",
            error_type="DatabaseError",
            message="Connection timeout to database after 30 seconds",
            source="test",
            file_path="/app/db.py",
            function_name="connect"
        )
        
        error2 = ParsedError(
            error_id="err_002",
            timestamp=datetime.now(),
            severity="high",
            error_type="DatabaseError",
            message="Connection timeout to database after 45 seconds",
            source="test",
            file_path="/app/db.py",
            function_name="connect"
        )
        
        cluster1 = self.deduplicator.find_or_create_cluster(error1)
        cluster2 = self.deduplicator.find_or_create_cluster(error2)
        
        # Should be in same cluster due to high similarity
        assert cluster1 == cluster2
    
    def test_different_errors_separate_clusters(self):
        error1 = ParsedError(
            error_id="err_003",
            timestamp=datetime.now(),
            severity="high",
            error_type="DatabaseError",
            message="Connection timeout",
            source="test",
            file_path="/app/db.py"
        )
        
        error2 = ParsedError(
            error_id="err_004",
            timestamp=datetime.now(),
            severity="medium",
            error_type="ValidationError",
            message="Invalid user input format",
            source="test",
            file_path="/app/validation.py"
        )
        
        cluster1 = self.deduplicator.find_or_create_cluster(error1)
        cluster2 = self.deduplicator.find_or_create_cluster(error2)
        
        # Should be in different clusters
        assert cluster1 != cluster2


class TestPerformanceMonitor:
    """Test performance monitoring and alerting."""
    
    def setup_method(self):
        self.monitor = PerformanceMonitor()
    
    def test_processing_time_tracking(self):
        # Record normal processing times
        for time_ms in [100, 150, 120, 90, 110]:
            self.monitor.record_processing_time(time_ms)
        
        stats = self.monitor.get_performance_stats()
        assert stats['avg_processing_time_ms'] == 114.0
        assert stats['max_processing_time_ms'] == 150
    
    def test_high_processing_time_alert(self):
        # Trigger high processing time alert
        self.monitor.record_processing_time(6000)  # Above 5000ms threshold
        
        alerts = self.monitor.get_recent_alerts()
        assert len(alerts) == 1
        assert alerts[0]['type'] == 'high_processing_time'
        assert alerts[0]['severity'] == 'warning'
    
    def test_error_rate_monitoring(self):
        base_time = datetime.now()
        
        # Record high error rate
        for i in range(150):  # Above 100/min threshold
            self.monitor.record_error_count(base_time, 1)
        
        alerts = self.monitor.get_recent_alerts()
        assert any(alert['type'] == 'high_error_rate' for alert in alerts)
    
    def test_parsing_failure_rate(self):
        # Record some successes and failures
        for _ in range(10):
            self.monitor.record_error_count(datetime.now())
        
        for _ in range(2):  # 20% failure rate, above 10% threshold
            self.monitor.record_parsing_failure()
        
        alerts = self.monitor.get_recent_alerts()
        assert any(alert['type'] == 'high_parsing_failure_rate' for alert in alerts)


class TestEnhancedErrorAdapter:
    """Test the main Enhanced Error Adapter functionality."""
    
    @pytest.fixture
    def adapter_config(self):
        return AdapterConfig(
            adapter_id="test_enhanced_error",
            source_type="error",
            batch_mode=BatchMode.STREAMING,
            batch_size=10,
            source_config={
                "input_sources": ["logs"],
                "log_directories": ["/tmp"],
                "log_file_patterns": ["*.log"],
                "enable_error_classification": True,
                "enable_pattern_detection": True,
                "enable_correlation_detection": True,
                "pattern_similarity_threshold": 0.8,
                "pattern_time_window_hours": 24,
            }
        )
    
    @pytest.fixture
    def adapter(self, adapter_config):
        return EnhancedErrorAdapter(adapter_config)
    
    def test_adapter_initialization(self, adapter):
        assert adapter.trend_analyzer is not None
        assert adapter.deduplicator is not None
        assert adapter.performance_monitor is not None
        assert adapter.classifier is not None
    
    @pytest.mark.asyncio
    async def test_json_log_parsing(self, adapter):
        # Create temporary JSON log file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            json_logs = [
                {
                    "timestamp": "2024-01-01T10:00:00Z",
                    "level": "ERROR",
                    "message": "Database connection failed",
                    "error_type": "ConnectionError",
                    "file": "/app/db.py",
                    "line": 45
                },
                {
                    "timestamp": "2024-01-01T10:01:00Z",
                    "level": "WARNING",
                    "message": "Slow query detected",
                    "error_type": "PerformanceWarning",
                    "file": "/app/queries.py",
                    "line": 123
                }
            ]
            
            for log_entry in json_logs:
                f.write(json.dumps(log_entry) + '\n')
            
            temp_file = Path(f.name)
        
        try:
            # Test parsing
            errors = []
            async for parsed_error in adapter._parse_log_file_enhanced(temp_file):
                errors.append(parsed_error)
            
            assert len(errors) == 2
            assert errors[0].error_type == "ConnectionError"
            assert errors[0].file_path == "/app/db.py"
            assert errors[0].line_number == 45
            assert errors[1].severity == "medium"  # WARNING normalized to medium
        
        finally:
            temp_file.unlink()
    
    @pytest.mark.asyncio
    async def test_structured_log_parsing(self, adapter):
        # Create temporary structured log file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write("2024-01-01 10:00:00 ERROR [DatabaseService] Connection failed to localhost:5432\n")
            f.write("2024-01-01 10:01:00 WARN [CacheService] Cache miss rate high: 85%\n")
            temp_file = Path(f.name)
        
        try:
            errors = []
            async for parsed_error in adapter._parse_log_file_enhanced(temp_file):
                errors.append(parsed_error)
            
            assert len(errors) == 2
            assert errors[0].severity == "high"  # ERROR -> high
            assert "connection" in errors[0].message.lower()
            
        finally:
            temp_file.unlink()
    
    @pytest.mark.asyncio
    async def test_error_transformation(self, adapter):
        raw_error = {
            "error_id": "test_001",
            "timestamp": datetime.now(),
            "severity": "high",
            "error_type": "DatabaseError",
            "message": "Connection timeout",
            "source": "json_log",
            "file_path": "/app/db.py",
            "line_number": 45,
            "categories": ["network", "database"],
            "classification_confidence": 0.85,
            "cluster_id": "cluster_123",
            "is_duplicate": False,
            "stack_elements": []
        }
        
        context_item = await adapter.transform_item(raw_error)
        
        assert isinstance(context_item, ContextItem)
        assert context_item.source_type == "error"
        assert context_item.severity == "high"
        assert context_item.file_path == "/app/db.py"
        assert context_item.line_start == 45
        assert context_item.metrics["cluster_id"] == "cluster_123"
        assert context_item.metrics["is_duplicate"] == False
    
    @pytest.mark.asyncio
    async def test_correlation_detection(self, adapter):
        # Mock correlation engine
        adapter.correlation_engine = Mock()
        adapter.correlation_engine.detect_correlations = AsyncMock(return_value=[
            ("git_commit", "commit_123", 0.8),
            ("similar_error", "error_456", 0.9)
        ])
        
        error_item = ContextItem(
            source_type="error",
            source_id="test_error",
            title="Test Error",
            content="Test error content",
            timestamp=datetime.now(),
            metrics={"error_type": "TestError"}
        )
        
        relationships = await adapter.detect_relationships(error_item, [])
        
        assert len(relationships) >= 2
        assert any(rel[0] == "git_commit" for rel in relationships)
        assert any(rel[0] == "similar_error" for rel in relationships)
    
    @pytest.mark.asyncio
    async def test_adapter_statistics(self, adapter):
        # Add some test data
        adapter.stats["total_errors_processed"] = 100
        adapter.stats["errors_by_severity"]["high"] = 20
        adapter.performance_monitor.record_processing_time(150)
        
        stats = await adapter.get_adapter_statistics()
        
        assert stats["total_errors_processed"] == 100
        assert "performance_stats" in stats
        assert "cluster_count" in stats
        assert "trending_patterns" in stats
    
    @pytest.mark.asyncio
    async def test_trending_errors_api(self, adapter):
        # Add some trend data
        adapter.trend_analyzer.update_pattern_frequency(
            "pattern_001", datetime.now(), 5
        )
        
        trending = await adapter.get_trending_errors(limit=10)
        assert isinstance(trending, list)
    
    @pytest.mark.asyncio
    async def test_error_clusters_api(self, adapter):
        # Add some cluster data
        error = ParsedError(
            error_id="test_001",
            timestamp=datetime.now(),
            severity="high",
            error_type="TestError",
            message="Test message",
            source="test"
        )
        adapter.deduplicator.find_or_create_cluster(error)
        
        clusters = await adapter.get_error_clusters(limit=10)
        assert isinstance(clusters, list)
        assert len(clusters) >= 1
    
    @pytest.mark.asyncio
    async def test_performance_alerts_api(self, adapter):
        # Trigger an alert
        adapter.performance_monitor.record_processing_time(6000)
        
        alerts = await adapter.get_performance_alerts(minutes=15)
        assert isinstance(alerts, list)
        assert len(alerts) >= 1
        assert alerts[0]["type"] == "high_processing_time"


class TestCorrelationEngine:
    """Test correlation detection between errors and other context items."""
    
    @pytest.fixture
    def mock_database(self):
        database = Mock()
        database.fetch_all = AsyncMock(return_value=[])
        return database
    
    @pytest.fixture
    def correlation_engine(self, mock_database):
        return CorrelationEngine(mock_database)
    
    @pytest.mark.asyncio
    async def test_git_correlation_detection(self, correlation_engine, mock_database):
        # Mock git commit data
        mock_database.fetch_all.return_value = [
            {
                "id": "commit_123",
                "source_id": "abc123",
                "timestamp": datetime.now() - timedelta(minutes=30),
                "file_path": "/app/db.py",
                "content": "Fix database connection timeout issue"
            }
        ]
        
        error = ParsedError(
            error_id="error_001",
            timestamp=datetime.now(),
            severity="high",
            error_type="DatabaseError",
            message="Connection timeout",
            source="test",
            file_path="/app/db.py"
        )
        
        correlations = await correlation_engine._find_git_correlations(error)
        assert len(correlations) >= 0  # May be empty due to mock setup
    
    @pytest.mark.asyncio
    async def test_chat_correlation_detection(self, correlation_engine):
        error = ParsedError(
            error_id="error_002",
            timestamp=datetime.now(),
            severity="high",
            error_type="ValidationError",
            message="Invalid input format",
            source="test",
            file_path="/app/validation.py"
        )
        
        # Mock context items (chat messages)
        context_items = [
            ContextItem(
                source_type="chat",
                source_id="chat_001",
                title="Discussion about validation",
                content="We need to fix the validation error in validation.py",
                timestamp=datetime.now() - timedelta(minutes=15)
            )
        ]
        
        correlations = await correlation_engine._find_chat_correlations(error, context_items)
        assert len(correlations) >= 1
        assert correlations[0][0] == "chat_discussion"


def create_test_log_files():
    """Create sample log files for integration testing."""
    test_logs_dir = Path("/tmp/test_error_logs")
    test_logs_dir.mkdir(exist_ok=True)
    
    # JSON format log
    json_log = test_logs_dir / "app.json.log"
    with json_log.open('w') as f:
        logs = [
            {
                "timestamp": "2024-01-01T10:00:00Z",
                "level": "ERROR",
                "message": "Failed to connect to database",
                "error_type": "ConnectionError",
                "file": "/app/database.py",
                "line": 123,
                "stack_trace": "ConnectionError: Failed to connect\\n  at connect() database.py:123"
            },
            {
                "timestamp": "2024-01-01T10:05:00Z", 
                "level": "ERROR",
                "message": "Failed to connect to database",
                "error_type": "ConnectionError",
                "file": "/app/database.py",
                "line": 123
            }
        ]
        for log in logs:
            f.write(json.dumps(log) + '\n')
    
    # Structured format log
    structured_log = test_logs_dir / "app.structured.log"
    with structured_log.open('w') as f:
        f.write("2024-01-01 10:00:00 ERROR [AuthService] Authentication failed for user admin\\n")
        f.write("2024-01-01 10:01:00 WARN [CacheService] High cache miss rate detected\\n")
        f.write("2024-01-01 10:02:00 ERROR [AuthService] Authentication failed for user guest\\n")
    
    return test_logs_dir


@pytest.mark.integration
class TestIntegration:
    """Integration tests for the complete error processing pipeline."""
    
    @pytest.mark.asyncio
    async def test_end_to_end_error_processing(self):
        # Create test configuration
        config = AdapterConfig(
            adapter_id="integration_test",
            source_type="error",
            batch_mode=BatchMode.STREAMING,
            source_config={
                "input_sources": ["logs"],
                "log_directories": ["/tmp/test_error_logs"],
                "log_file_patterns": ["*.log"],
                "enable_error_classification": True,
                "enable_pattern_detection": True,
                "enable_correlation_detection": False,  # Disable for integration test
                "pattern_similarity_threshold": 0.8,
            }
        )
        
        # Create test log files
        test_logs_dir = create_test_log_files()
        
        try:
            # Initialize adapter
            adapter = EnhancedErrorAdapter(config)
            await adapter.initialize()
            
            # Process errors
            processed_errors = []
            async for raw_error in adapter.fetch_items(limit=10):
                context_item = await adapter.transform_item(raw_error)
                processed_errors.append(context_item)
            
            # Verify processing results
            assert len(processed_errors) > 0
            
            # Check that errors were classified
            for error in processed_errors:
                assert error.source_type == "error"
                assert error.severity in ["low", "medium", "high", "critical"]
                assert error.metrics is not None
            
            # Check clustering worked
            clusters = await adapter.get_error_clusters()
            assert len(clusters) > 0
            
            # Check statistics
            stats = await adapter.get_adapter_statistics()
            assert stats["total_errors_processed"] > 0
            assert "performance_stats" in stats
            
            # Cleanup
            await adapter.cleanup()
            
        finally:
            # Clean up test files
            import shutil
            shutil.rmtree(test_logs_dir)


if __name__ == "__main__":
    """Run tests manually for debugging."""
    
    # Create test log files for manual testing
    test_logs_dir = create_test_log_files()
    print(f"Created test log files in: {test_logs_dir}")
    
    # Run a simple test
    async def manual_test():
        config = AdapterConfig(
            adapter_id="manual_test",
            source_type="error", 
            batch_mode=BatchMode.STREAMING,
            source_config={
                "input_sources": ["logs"],
                "log_directories": [str(test_logs_dir)],
                "log_file_patterns": ["*.log"],
                "enable_error_classification": True,
                "enable_pattern_detection": True,
                "enable_correlation_detection": False,
            }
        )
        
        adapter = EnhancedErrorAdapter(config)
        await adapter.initialize()
        
        print("Processing errors...")
        count = 0
        async for raw_error in adapter.fetch_items(limit=5):
            context_item = await adapter.transform_item(raw_error)
            print(f"Processed error: {context_item.title}")
            count += 1
        
        print(f"Processed {count} errors")
        
        # Show statistics
        stats = await adapter.get_adapter_statistics()
        print("\\nStatistics:")
        print(f"  Total processed: {stats.get('total_errors_processed', 0)}")
        print(f"  Clusters: {stats.get('cluster_count', 0)}")
        
        await adapter.cleanup()
    
    # Run the manual test
    asyncio.run(manual_test())
    
    print("\\nManual test completed. Run with pytest for full test suite:")
    print("pytest test_enhanced_error_adapter.py -v")