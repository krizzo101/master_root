"""Database schema validation tests for the unified context system."""

import asyncio
import pytest
import asyncpg
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from unittest.mock import AsyncMock, patch
from uuid import uuid4

from src.project_context.ingestion.database import DatabaseManager
from src.project_context.models.common import ContextItem


@pytest.fixture
def database_config():
    """Create test database configuration."""
    return {
        "connection_string": "postgresql://test_user:test_password@localhost:5432/test_db",
        "pool_size": 5,
        "enable_migrations": True,
        "migration_path": "./migrations",
        "timeout_seconds": 30
    }


@pytest.fixture
def mock_connection():
    """Create mock database connection."""
    conn = AsyncMock(spec=asyncpg.Connection)
    
    # Mock basic connection operations
    conn.execute.return_value = None
    conn.fetch.return_value = []
    conn.fetchrow.return_value = None
    conn.fetchval.return_value = None
    
    # Mock transaction
    transaction = AsyncMock()
    transaction.__aenter__.return_value = transaction
    transaction.__aexit__.return_value = None
    conn.transaction.return_value = transaction
    
    return conn


@pytest.fixture
def sample_context_item():
    """Create sample context item for testing."""
    return ContextItem(
        id=uuid4(),
        source_type="git",
        source_id="commit_123",
        entity_type="commit",
        title="feat: Add user authentication",
        content="Implement JWT-based authentication system",
        timestamp=datetime(2024, 1, 15, 10, 30, 0, tzinfo=timezone.utc),
        actor_id="developer@example.com",
        actor_type="human",
        file_path="src/auth.py",
        line_start=1,
        line_end=50,
        function_name="authenticate",
        class_name="AuthService",
        project_id="my-project",
        severity="medium",
        metrics={
            "commit_hash": "abc123def456",
            "impact_score": 0.8,
            "risk_score": 0.3,
            "changed_files": ["src/auth.py", "tests/test_auth.py"]
        },
        tags=["git", "commit", "authentication", "feature"],
        source_data={"raw_commit": "original git data"}
    )


class TestDatabaseSchemaValidation:
    """Test database schema validation and integrity."""

    @pytest.mark.asyncio
    async def test_required_tables_exist(self, mock_connection):
        """Test that all required tables exist."""
        required_tables = [
            "context_items",
            "context_relationships", 
            "git_processing_checkpoints",
            "adapter_metrics",
            "pipeline_status"
        ]
        
        # Mock table existence check
        mock_connection.fetch.return_value = [
            {"table_name": table} for table in required_tables
        ]
        
        # Query for existing tables
        tables_query = """
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_type = 'BASE TABLE'
        """
        
        result = await mock_connection.fetch(tables_query)
        existing_tables = {row["table_name"] for row in result}
        
        # Verify all required tables exist
        for table in required_tables:
            assert table in existing_tables, f"Required table '{table}' not found"

    @pytest.mark.asyncio
    async def test_context_items_table_schema(self, mock_connection):
        """Test context_items table schema."""
        # Mock column information
        mock_columns = [
            {"column_name": "id", "data_type": "uuid", "is_nullable": "NO"},
            {"column_name": "source_type", "data_type": "character varying", "is_nullable": "NO"},
            {"column_name": "source_id", "data_type": "character varying", "is_nullable": "NO"},
            {"column_name": "entity_type", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "title", "data_type": "text", "is_nullable": "YES"},
            {"column_name": "content", "data_type": "text", "is_nullable": "YES"},
            {"column_name": "timestamp", "data_type": "timestamp with time zone", "is_nullable": "YES"},
            {"column_name": "timestamp_end", "data_type": "timestamp with time zone", "is_nullable": "YES"},
            {"column_name": "actor_id", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "actor_type", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "file_path", "data_type": "text", "is_nullable": "YES"},
            {"column_name": "line_start", "data_type": "integer", "is_nullable": "YES"},
            {"column_name": "line_end", "data_type": "integer", "is_nullable": "YES"},
            {"column_name": "function_name", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "class_name", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "project_id", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "severity", "data_type": "character varying", "is_nullable": "YES"},
            {"column_name": "metrics", "data_type": "jsonb", "is_nullable": "YES"},
            {"column_name": "tags", "data_type": "ARRAY", "is_nullable": "YES"},
            {"column_name": "source_data", "data_type": "jsonb", "is_nullable": "YES"},
            {"column_name": "embedding", "data_type": "vector", "is_nullable": "YES"},
            {"column_name": "created_at", "data_type": "timestamp with time zone", "is_nullable": "NO"},
            {"column_name": "updated_at", "data_type": "timestamp with time zone", "is_nullable": "NO"}
        ]
        
        mock_connection.fetch.return_value = mock_columns
        
        # Query table schema
        schema_query = """
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'context_items'
            ORDER BY ordinal_position
        """
        
        columns = await mock_connection.fetch(schema_query)
        column_info = {col["column_name"]: col for col in columns}
        
        # Verify required columns exist with correct types
        required_columns = {
            "id": {"data_type": "uuid", "is_nullable": "NO"},
            "source_type": {"data_type": "character varying", "is_nullable": "NO"},
            "source_id": {"data_type": "character varying", "is_nullable": "NO"},
            "content": {"data_type": "text", "is_nullable": "YES"},
            "timestamp": {"data_type": "timestamp with time zone", "is_nullable": "YES"},
            "metrics": {"data_type": "jsonb", "is_nullable": "YES"},
            "tags": {"data_type": "ARRAY", "is_nullable": "YES"},
            "created_at": {"data_type": "timestamp with time zone", "is_nullable": "NO"}
        }
        
        for column_name, expected in required_columns.items():
            assert column_name in column_info, f"Required column '{column_name}' not found"
            actual = column_info[column_name]
            assert expected["data_type"] in actual["data_type"], f"Column '{column_name}' has wrong type"
            assert actual["is_nullable"] == expected["is_nullable"], f"Column '{column_name}' has wrong nullable constraint"

    @pytest.mark.asyncio
    async def test_context_relationships_table_schema(self, mock_connection):
        """Test context_relationships table schema."""
        mock_columns = [
            {"column_name": "id", "data_type": "uuid", "is_nullable": "NO"},
            {"column_name": "source_item_id", "data_type": "uuid", "is_nullable": "NO"},
            {"column_name": "target_item_id", "data_type": "uuid", "is_nullable": "NO"},
            {"column_name": "relationship_type", "data_type": "character varying", "is_nullable": "NO"},
            {"column_name": "confidence_score", "data_type": "numeric", "is_nullable": "YES"},
            {"column_name": "metadata", "data_type": "jsonb", "is_nullable": "YES"},
            {"column_name": "created_at", "data_type": "timestamp with time zone", "is_nullable": "NO"}
        ]
        
        mock_connection.fetch.return_value = mock_columns
        
        schema_query = """
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'context_relationships'
            ORDER BY ordinal_position
        """
        
        columns = await mock_connection.fetch(schema_query)
        column_info = {col["column_name"]: col for col in columns}
        
        # Verify relationship table structure
        required_columns = {
            "id": {"data_type": "uuid", "is_nullable": "NO"},
            "source_item_id": {"data_type": "uuid", "is_nullable": "NO"},
            "target_item_id": {"data_type": "uuid", "is_nullable": "NO"},
            "relationship_type": {"data_type": "character varying", "is_nullable": "NO"},
            "confidence_score": {"data_type": "numeric", "is_nullable": "YES"}
        }
        
        for column_name, expected in required_columns.items():
            assert column_name in column_info
            actual = column_info[column_name]
            assert expected["data_type"] in actual["data_type"]
            assert actual["is_nullable"] == expected["is_nullable"]

    @pytest.mark.asyncio
    async def test_required_indexes_exist(self, mock_connection):
        """Test that required indexes exist for performance."""
        required_indexes = [
            ("context_items", "idx_context_items_source_type"),
            ("context_items", "idx_context_items_timestamp"),
            ("context_items", "idx_context_items_project_id"),
            ("context_items", "idx_context_items_actor_id"),
            ("context_items", "idx_context_items_tags"),
            ("context_items", "idx_context_items_embedding"),  # Vector similarity search
            ("context_relationships", "idx_relationships_source_item"),
            ("context_relationships", "idx_relationships_target_item"),
            ("context_relationships", "idx_relationships_type"),
            ("git_processing_checkpoints", "idx_git_checkpoints_repo_branch")
        ]
        
        # Mock index information
        mock_indexes = [
            {"table_name": table, "index_name": index_name}
            for table, index_name in required_indexes
        ]
        
        mock_connection.fetch.return_value = mock_indexes
        
        # Query existing indexes
        indexes_query = """
            SELECT schemaname, tablename as table_name, indexname as index_name
            FROM pg_indexes
            WHERE schemaname = 'public'
        """
        
        indexes = await mock_connection.fetch(indexes_query)
        existing_indexes = {(idx["table_name"], idx["index_name"]) for idx in indexes}
        
        # Verify required indexes exist
        for table, index_name in required_indexes:
            assert (table, index_name) in existing_indexes, f"Required index '{index_name}' on table '{table}' not found"

    @pytest.mark.asyncio
    async def test_foreign_key_constraints(self, mock_connection):
        """Test that foreign key constraints are properly defined."""
        # Mock constraint information
        mock_constraints = [
            {
                "constraint_name": "fk_relationships_source_item",
                "table_name": "context_relationships",
                "column_name": "source_item_id",
                "foreign_table_name": "context_items",
                "foreign_column_name": "id"
            },
            {
                "constraint_name": "fk_relationships_target_item", 
                "table_name": "context_relationships",
                "column_name": "target_item_id",
                "foreign_table_name": "context_items",
                "foreign_column_name": "id"
            }
        ]
        
        mock_connection.fetch.return_value = mock_constraints
        
        # Query foreign key constraints
        fk_query = """
            SELECT 
                tc.constraint_name,
                tc.table_name,
                kcu.column_name,
                ccu.table_name AS foreign_table_name,
                ccu.column_name AS foreign_column_name
            FROM information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
                ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage AS ccu
                ON ccu.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY'
        """
        
        constraints = await mock_connection.fetch(fk_query)
        
        # Verify relationship table foreign keys
        relationship_fks = [c for c in constraints if c["table_name"] == "context_relationships"]
        assert len(relationship_fks) == 2, "context_relationships should have 2 foreign keys"
        
        fk_columns = {c["column_name"] for c in relationship_fks}
        assert "source_item_id" in fk_columns
        assert "target_item_id" in fk_columns

    @pytest.mark.asyncio
    async def test_check_constraints(self, mock_connection):
        """Test that check constraints are properly defined."""
        # Mock check constraints
        mock_constraints = [
            {
                "constraint_name": "chk_confidence_score_range",
                "table_name": "context_relationships",
                "check_clause": "((confidence_score >= 0.0) AND (confidence_score <= 1.0))"
            },
            {
                "constraint_name": "chk_line_numbers_positive",
                "table_name": "context_items", 
                "check_clause": "((line_start > 0) AND ((line_end IS NULL) OR (line_end >= line_start)))"
            }
        ]
        
        mock_connection.fetch.return_value = mock_constraints
        
        # Query check constraints
        check_query = """
            SELECT constraint_name, table_name, check_clause
            FROM information_schema.check_constraints cc
            JOIN information_schema.table_constraints tc
                ON cc.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'CHECK'
        """
        
        constraints = await mock_connection.fetch(check_query)
        constraint_info = {(c["table_name"], c["constraint_name"]): c for c in constraints}
        
        # Verify important check constraints
        assert ("context_relationships", "chk_confidence_score_range") in constraint_info
        assert ("context_items", "chk_line_numbers_positive") in constraint_info


class TestDataIntegrityAndConstraints:
    """Test data integrity and constraint enforcement."""

    @pytest.mark.asyncio
    async def test_context_item_insertion(self, mock_connection, sample_context_item):
        """Test context item insertion with all fields."""
        # Mock successful insertion
        mock_connection.fetchval.return_value = sample_context_item.id
        
        insert_query = """
            INSERT INTO context_items (
                id, source_type, source_id, entity_type, title, content,
                timestamp, timestamp_end, actor_id, actor_type, file_path,
                line_start, line_end, function_name, class_name, project_id,
                severity, metrics, tags, source_data, created_at, updated_at
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
                $15, $16, $17, $18, $19, $20, $21, $22
            ) RETURNING id
        """
        
        result = await mock_connection.fetchval(
            insert_query,
            sample_context_item.id,
            sample_context_item.source_type,
            sample_context_item.source_id,
            sample_context_item.entity_type,
            sample_context_item.title,
            sample_context_item.content,
            sample_context_item.timestamp,
            sample_context_item.timestamp_end,
            sample_context_item.actor_id,
            sample_context_item.actor_type,
            sample_context_item.file_path,
            sample_context_item.line_start,
            sample_context_item.line_end,
            sample_context_item.function_name,
            sample_context_item.class_name,
            sample_context_item.project_id,
            sample_context_item.severity,
            sample_context_item.metrics,
            sample_context_item.tags,
            sample_context_item.source_data,
            datetime.utcnow(),
            datetime.utcnow()
        )
        
        assert result == sample_context_item.id

    @pytest.mark.asyncio
    async def test_relationship_insertion(self, mock_connection):
        """Test relationship insertion with constraints."""
        source_id = uuid4()
        target_id = uuid4()
        relationship_id = uuid4()
        
        mock_connection.fetchval.return_value = relationship_id
        
        insert_query = """
            INSERT INTO context_relationships (
                id, source_item_id, target_item_id, relationship_type,
                confidence_score, metadata, created_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id
        """
        
        result = await mock_connection.fetchval(
            insert_query,
            relationship_id,
            source_id,
            target_id,
            "builds_commit",
            0.95,
            {"detection_method": "commit_sha_match"},
            datetime.utcnow()
        )
        
        assert result == relationship_id

    @pytest.mark.asyncio
    async def test_invalid_confidence_score_rejection(self, mock_connection):
        """Test that invalid confidence scores are rejected."""
        # Mock constraint violation
        mock_connection.fetchval.side_effect = asyncpg.CheckViolationError(
            "new row for relation \"context_relationships\" violates check constraint \"chk_confidence_score_range\""
        )
        
        insert_query = """
            INSERT INTO context_relationships (
                id, source_item_id, target_item_id, relationship_type,
                confidence_score, created_at
            ) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id
        """
        
        # Should raise exception for invalid confidence score
        with pytest.raises(asyncpg.CheckViolationError):
            await mock_connection.fetchval(
                insert_query,
                uuid4(),
                uuid4(),
                uuid4(),
                "test_relationship",
                1.5,  # Invalid: > 1.0
                datetime.utcnow()
            )

    @pytest.mark.asyncio
    async def test_duplicate_prevention(self, mock_connection):
        """Test duplicate prevention via unique constraints."""
        # Mock unique constraint violation
        mock_connection.execute.side_effect = asyncpg.UniqueViolationError(
            "duplicate key value violates unique constraint \"context_items_source_type_source_id_key\""
        )
        
        insert_query = """
            INSERT INTO context_items (
                id, source_type, source_id, title, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6)
        """
        
        # Should raise exception for duplicate source_type + source_id
        with pytest.raises(asyncpg.UniqueViolationError):
            await mock_connection.execute(
                insert_query,
                uuid4(),
                "git",
                "commit_123",  # Duplicate source_id for same source_type
                "Duplicate commit",
                datetime.utcnow(),
                datetime.utcnow()
            )


class TestDatabasePerformance:
    """Test database performance and query optimization."""

    @pytest.mark.asyncio
    async def test_context_item_query_performance(self, mock_connection):
        """Test performance of context item queries."""
        # Mock query result
        mock_connection.fetch.return_value = [
            {
                "id": uuid4(),
                "source_type": "git",
                "source_id": "commit_1",
                "title": "Test commit 1",
                "timestamp": datetime.utcnow()
            }
        ]
        
        # Test indexed queries
        indexed_queries = [
            # Query by source type (should use idx_context_items_source_type)
            ("SELECT * FROM context_items WHERE source_type = $1", ["git"]),
            
            # Query by timestamp range (should use idx_context_items_timestamp)
            ("""SELECT * FROM context_items 
                WHERE timestamp BETWEEN $1 AND $2""", 
             [datetime.utcnow() - timedelta(days=1), datetime.utcnow()]),
            
            # Query by project (should use idx_context_items_project_id)
            ("SELECT * FROM context_items WHERE project_id = $1", ["my-project"]),
            
            # Query by tags (should use idx_context_items_tags)
            ("SELECT * FROM context_items WHERE $1 = ANY(tags)", ["git"]),
        ]
        
        for query, params in indexed_queries:
            # Execute query (would use appropriate index in real DB)
            result = await mock_connection.fetch(query, *params)
            assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_relationship_query_performance(self, mock_connection):
        """Test performance of relationship queries."""
        mock_connection.fetch.return_value = [
            {
                "id": uuid4(),
                "source_item_id": uuid4(),
                "target_item_id": uuid4(),
                "relationship_type": "builds_commit",
                "confidence_score": 0.95
            }
        ]
        
        # Test relationship queries that should use indexes
        relationship_queries = [
            # Find relationships for a specific item
            ("SELECT * FROM context_relationships WHERE source_item_id = $1", [uuid4()]),
            
            # Find relationships of a specific type
            ("SELECT * FROM context_relationships WHERE relationship_type = $1", ["builds_commit"]),
            
            # Bidirectional relationship query
            ("""SELECT * FROM context_relationships 
                WHERE source_item_id = $1 OR target_item_id = $1""", [uuid4()]),
        ]
        
        for query, params in relationship_queries:
            result = await mock_connection.fetch(query, *params)
            assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_complex_join_performance(self, mock_connection):
        """Test performance of complex joins between tables."""
        mock_connection.fetch.return_value = [
            {
                "item_id": uuid4(),
                "item_title": "Test Item",
                "related_id": uuid4(),
                "related_title": "Related Item",
                "relationship_type": "builds_commit"
            }
        ]
        
        # Complex query joining context items with relationships
        complex_query = """
            SELECT 
                ci1.id as item_id,
                ci1.title as item_title,
                ci2.id as related_id,
                ci2.title as related_title,
                cr.relationship_type
            FROM context_items ci1
            JOIN context_relationships cr ON ci1.id = cr.source_item_id
            JOIN context_items ci2 ON cr.target_item_id = ci2.id
            WHERE ci1.source_type = $1
            AND cr.confidence_score > $2
            ORDER BY cr.confidence_score DESC
            LIMIT $3
        """
        
        result = await mock_connection.fetch(complex_query, "git", 0.8, 100)
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_vector_similarity_query(self, mock_connection):
        """Test vector similarity query performance."""
        mock_connection.fetch.return_value = [
            {
                "id": uuid4(),
                "title": "Similar Item",
                "similarity": 0.95
            }
        ]
        
        # Vector similarity search (requires pgvector extension)
        similarity_query = """
            SELECT id, title, 
                   1 - (embedding <-> $1) AS similarity
            FROM context_items
            WHERE embedding IS NOT NULL
            ORDER BY embedding <-> $1
            LIMIT $2
        """
        
        # Mock embedding vector
        query_embedding = [0.1] * 384  # Typical embedding dimension
        
        result = await mock_connection.fetch(similarity_query, query_embedding, 10)
        assert isinstance(result, list)


class TestMigrationValidation:
    """Test database migration validation."""

    @pytest.mark.asyncio
    async def test_migration_table_exists(self, mock_connection):
        """Test that migration tracking table exists."""
        mock_connection.fetchrow.return_value = {"table_name": "schema_migrations"}
        
        query = """
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_name = 'schema_migrations'
        """
        
        result = await mock_connection.fetchrow(query)
        assert result["table_name"] == "schema_migrations"

    @pytest.mark.asyncio
    async def test_applied_migrations(self, mock_connection):
        """Test that all required migrations have been applied."""
        required_migrations = [
            "001_create_context_items",
            "002_create_relationships",
            "003_add_indexes",
            "004_add_git_checkpoints",
            "005_add_vector_support"
        ]
        
        mock_connection.fetch.return_value = [
            {"version": migration} for migration in required_migrations
        ]
        
        query = "SELECT version FROM schema_migrations ORDER BY version"
        
        applied_migrations = await mock_connection.fetch(query)
        applied_versions = {m["version"] for m in applied_migrations}
        
        for migration in required_migrations:
            assert migration in applied_versions, f"Migration {migration} not applied"

    @pytest.mark.asyncio
    async def test_migration_rollback_support(self, mock_connection):
        """Test that migrations support rollback."""
        # Mock rollback functionality test
        mock_connection.execute.return_value = None
        
        # Test rollback of a sample migration
        rollback_query = "DROP TABLE IF EXISTS test_migration_table"
        
        await mock_connection.execute(rollback_query)
        # Should execute without error


class TestDatabaseExtensions:
    """Test required database extensions."""

    @pytest.mark.asyncio
    async def test_pgvector_extension(self, mock_connection):
        """Test that pgvector extension is installed for embeddings."""
        mock_connection.fetchrow.return_value = {"extname": "vector"}
        
        query = """
            SELECT extname FROM pg_extension 
            WHERE extname = 'vector'
        """
        
        result = await mock_connection.fetchrow(query)
        assert result["extname"] == "vector", "pgvector extension not installed"

    @pytest.mark.asyncio
    async def test_uuid_extension(self, mock_connection):
        """Test that UUID extension is available."""
        mock_connection.fetchval.return_value = str(uuid4())
        
        query = "SELECT gen_random_uuid()"
        
        result = await mock_connection.fetchval(query)
        assert result is not None
        assert len(result) == 36  # UUID string length

    @pytest.mark.asyncio
    async def test_jsonb_support(self, mock_connection):
        """Test JSONB functionality."""
        mock_connection.fetchval.return_value = {"test": "value"}
        
        # Test JSONB query
        query = "SELECT $1::jsonb"
        test_json = {"test": "value", "nested": {"key": "data"}}
        
        result = await mock_connection.fetchval(query, test_json)
        assert result == {"test": "value"}


class TestDataConsistency:
    """Test data consistency and referential integrity."""

    @pytest.mark.asyncio
    async def test_orphaned_relationships_detection(self, mock_connection):
        """Test detection of orphaned relationships."""
        # Mock query to find orphaned relationships
        mock_connection.fetch.return_value = []  # No orphaned relationships
        
        orphan_query = """
            SELECT cr.id, cr.source_item_id, cr.target_item_id
            FROM context_relationships cr
            LEFT JOIN context_items ci1 ON cr.source_item_id = ci1.id
            LEFT JOIN context_items ci2 ON cr.target_item_id = ci2.id
            WHERE ci1.id IS NULL OR ci2.id IS NULL
        """
        
        orphaned_relationships = await mock_connection.fetch(orphan_query)
        assert len(orphaned_relationships) == 0, "Found orphaned relationships"

    @pytest.mark.asyncio
    async def test_data_type_consistency(self, mock_connection):
        """Test that data types are consistent across related tables."""
        # Mock validation of ID data types
        mock_connection.fetch.return_value = [
            {"table_name": "context_items", "column_name": "id", "data_type": "uuid"},
            {"table_name": "context_relationships", "column_name": "source_item_id", "data_type": "uuid"},
            {"table_name": "context_relationships", "column_name": "target_item_id", "data_type": "uuid"}
        ]
        
        type_query = """
            SELECT table_name, column_name, data_type
            FROM information_schema.columns
            WHERE column_name IN ('id', 'source_item_id', 'target_item_id')
            AND table_name IN ('context_items', 'context_relationships')
        """
        
        columns = await mock_connection.fetch(type_query)
        
        # All ID columns should be UUID type
        for column in columns:
            assert column["data_type"] == "uuid", f"ID column {column['column_name']} should be UUID type"

    @pytest.mark.asyncio
    async def test_timestamp_consistency(self, mock_connection):
        """Test timestamp consistency and timezone handling."""
        mock_connection.fetchval.return_value = datetime.utcnow()
        
        # Test timezone-aware timestamp insertion
        timestamp_query = "SELECT $1::timestamptz"
        test_timestamp = datetime.now(timezone.utc)
        
        result = await mock_connection.fetchval(timestamp_query, test_timestamp)
        assert isinstance(result, datetime)
        assert result.tzinfo is not None  # Should preserve timezone info


# Database test markers
pytestmark = [
    pytest.mark.database,
    pytest.mark.schema,
]