#!/usr/bin/env python3
"""Comprehensive test suite for the enhanced CodeAdapter with AST analysis and symbol indexing."""

import asyncio
import ast
import json
import tempfile
import pytest
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List
from unittest.mock import Mock, patch

# Import the code adapter
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from project_context.ingestion.adapters.code_adapter import CodeAdapter
from project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from project_context.models.common import ContextItem


class TestCodeAdapter:
    """Test suite for the enhanced CodeAdapter."""
    
    @pytest.fixture
    def adapter_config(self):
        """Create a test adapter configuration."""
        return AdapterConfig(
            adapter_id="test_code_adapter",
            source_type="code",
            batch_mode=BatchMode.BATCH,
            batch_size=10,
            generate_embeddings=False,
            generate_summaries=False,
            extract_relationships=True,
            source_config={
                "scan_directories": [],  # Will be set in tests
                "include_patterns": ["*.py", "*.js", "*.ts"],
                "exclude_patterns": ["__pycache__/**", "*.pyc"],
                "max_file_size_mb": 5,
                "extract_functions": True,
                "extract_classes": True,
                "extract_imports": True,
                "extract_comments": True,
                "enable_advanced_analysis": True,
                "enable_proj_intel": False,  # Disabled for unit tests
            }
        )
    
    @pytest.fixture
    def code_adapter(self, adapter_config):
        """Create a CodeAdapter instance for testing."""
        return CodeAdapter(adapter_config)
    
    @pytest.fixture
    def temp_python_file(self):
        """Create a temporary Python file for testing."""
        content = '''#!/usr/bin/env python3
"""Test module for code analysis."""

import asyncio
import json
from typing import Dict, List, Optional

# Module constant
MAX_RETRIES = 3
DEBUG_MODE = True

class DataProcessor:
    """A class for processing data."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the processor."""
        self.config = config
        self.processed_count = 0
    
    async def process_item(self, item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Process a single item asynchronously."""
        if not item or not isinstance(item, dict):
            return None
        
        # Complex processing logic
        result = {}
        for key, value in item.items():
            if isinstance(value, str):
                result[key] = value.strip().lower()
            elif isinstance(value, int):
                result[key] = value * 2
            else:
                result[key] = value
        
        self.processed_count += 1
        return result
    
    @classmethod
    def create_default(cls):
        """Create processor with default configuration."""
        return cls({"timeout": 30, "retries": MAX_RETRIES})
    
    @staticmethod
    def validate_item(item: Dict[str, Any]) -> bool:
        """Validate an item structure."""
        return bool(item and isinstance(item, dict) and "id" in item)


def process_batch(items: List[Dict[str, Any]], processor: DataProcessor) -> List[Dict[str, Any]]:
    """Process a batch of items."""
    results = []
    
    for item in items:
        if processor.validate_item(item):
            # Simulate async processing in sync function
            result = asyncio.run(processor.process_item(item))
            if result:
                results.append(result)
    
    return results


async def main():
    """Main entry point."""
    processor = DataProcessor.create_default()
    
    test_items = [
        {"id": 1, "name": "  Test Item  ", "value": 42},
        {"id": 2, "name": "Another Item", "value": 100},
    ]
    
    results = process_batch(test_items, processor)
    print(f"Processed {len(results)} items")


if __name__ == "__main__":
    asyncio.run(main())
'''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(content)
            temp_file = Path(f.name)
        
        yield temp_file, content
        
        # Cleanup
        temp_file.unlink()
    
    @pytest.fixture
    def temp_javascript_file(self):
        """Create a temporary JavaScript file for testing."""
        content = '''// Test JavaScript file for code analysis
import { EventEmitter } from 'events';
import axios from 'axios';

const MAX_RETRIES = 3;
const API_BASE_URL = 'https://api.example.com';

/**
 * A class for handling API requests
 */
class ApiClient extends EventEmitter {
    constructor(options = {}) {
        super();
        this.baseUrl = options.baseUrl || API_BASE_URL;
        this.timeout = options.timeout || 5000;
        this.retries = options.retries || MAX_RETRIES;
    }
    
    async fetchData(endpoint) {
        try {
            const response = await axios.get(`${this.baseUrl}${endpoint}`, {
                timeout: this.timeout
            });
            
            this.emit('data', response.data);
            return response.data;
        } catch (error) {
            this.emit('error', error);
            throw error;
        }
    }
    
    static createDefault() {
        return new ApiClient();
    }
}

const processResponse = async (data) => {
    if (!data || typeof data !== 'object') {
        return null;
    }
    
    // Process the response data
    const processed = {
        ...data,
        processedAt: new Date().toISOString(),
        status: 'processed'
    };
    
    return processed;
};

function validateResponse(response) {
    return response && 
           typeof response === 'object' && 
           response.id !== undefined;
}

export { ApiClient, processResponse, validateResponse };
export default ApiClient;
'''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write(content)
            temp_file = Path(f.name)
        
        yield temp_file, content
        
        # Cleanup
        temp_file.unlink()

    # Test Basic Functionality
    
    @pytest.mark.asyncio
    async def test_adapter_initialization(self, code_adapter):
        """Test adapter initialization."""
        await code_adapter.initialize()
        assert code_adapter.config.adapter_id == "test_code_adapter"
        assert code_adapter._language_parsers is not None
        assert "python" in code_adapter._language_parsers

    @pytest.mark.asyncio
    async def test_file_reading_python(self, code_adapter, temp_python_file):
        """Test reading and parsing a Python file."""
        temp_file, content = temp_python_file
        
        raw_item = await code_adapter._read_code_file(temp_file)
        assert raw_item is not None
        assert raw_item["file_path"] == str(temp_file)
        assert raw_item["content"] == content
        assert raw_item["encoding"] in ["utf-8", "utf-8-sig"]

    @pytest.mark.asyncio
    async def test_file_reading_javascript(self, code_adapter, temp_javascript_file):
        """Test reading and parsing a JavaScript file."""
        temp_file, content = temp_javascript_file
        
        raw_item = await code_adapter._read_code_file(temp_file)
        assert raw_item is not None
        assert raw_item["file_path"] == str(temp_file)
        assert raw_item["content"] == content

    # Test Language Detection
    
    def test_language_detection_python(self, code_adapter):
        """Test Python language detection."""
        language = code_adapter._detect_language("test.py", "def hello(): pass")
        assert language == "python"
    
    def test_language_detection_javascript(self, code_adapter):
        """Test JavaScript language detection."""
        language = code_adapter._detect_language("test.js", "function hello() {}")
        assert language == "javascript"
    
    def test_language_detection_typescript(self, code_adapter):
        """Test TypeScript language detection."""
        language = code_adapter._detect_language("test.ts", "function hello(): void {}")
        assert language == "typescript"

    # Test AST-based Python Parsing
    
    def test_python_ast_function_extraction(self, code_adapter, temp_python_file):
        """Test Python function extraction using AST."""
        temp_file, content = temp_python_file
        
        functions = code_adapter._extract_python_functions_ast(ast.parse(content), content)
        
        # Check that functions were extracted
        assert len(functions) >= 3  # process_item, create_default, validate_item, process_batch, main
        
        # Check async function
        async_funcs = [f for f in functions if f.get("is_async")]
        assert len(async_funcs) >= 2  # process_item and main
        
        # Check function details
        process_item_func = next((f for f in functions if f["name"] == "process_item"), None)
        assert process_item_func is not None
        assert process_item_func["is_async"] is True
        assert "item" in [p["name"] for p in process_item_func["parameters"]]

    def test_python_ast_class_extraction(self, code_adapter, temp_python_file):
        """Test Python class extraction using AST."""
        temp_file, content = temp_python_file
        
        classes = code_adapter._extract_python_classes_ast(ast.parse(content), content)
        
        # Check that DataProcessor class was extracted
        assert len(classes) == 1
        
        data_processor = classes[0]
        assert data_processor["name"] == "DataProcessor"
        assert data_processor["docstring"] == "A class for processing data."
        
        # Check methods
        methods = data_processor["methods"]
        method_names = [m["name"] for m in methods]
        assert "__init__" in method_names
        assert "process_item" in method_names
        assert "create_default" in method_names
        assert "validate_item" in method_names
        
        # Check method types
        process_item_method = next(m for m in methods if m["name"] == "process_item")
        assert process_item_method["is_async"] is True
        
        create_default_method = next(m for m in methods if m["name"] == "create_default")
        assert create_default_method["is_classmethod"] is True
        
        validate_item_method = next(m for m in methods if m["name"] == "validate_item")
        assert validate_item_method["is_staticmethod"] is True

    def test_python_ast_import_extraction(self, code_adapter, temp_python_file):
        """Test Python import extraction using AST."""
        temp_file, content = temp_python_file
        
        imports = code_adapter._extract_python_imports_ast(ast.parse(content))
        
        # Check imports
        import_modules = [imp["module"] for imp in imports if imp["type"] == "import"]
        assert "asyncio" in import_modules
        assert "json" in import_modules
        
        # Check from imports
        from_imports = [imp for imp in imports if imp["type"] == "from_import"]
        typing_imports = [imp for imp in from_imports if imp["module"] == "typing"]
        assert len(typing_imports) == 3  # Dict, List, Optional

    # Test Enhanced Symbol Extraction
    
    def test_symbol_extraction_python(self, code_adapter, temp_python_file):
        """Test comprehensive symbol extraction for Python."""
        temp_file, content = temp_python_file
        
        symbols = code_adapter.extract_symbols(content, str(temp_file), "python")
        
        # Check basic structure
        assert symbols["file_path"] == str(temp_file)
        assert symbols["language"] == "python"
        
        # Check functions
        functions = symbols["functions"]
        assert len(functions) >= 3
        
        # Check classes
        classes = symbols["classes"]
        assert len(classes) == 1
        assert classes[0]["name"] == "DataProcessor"
        
        # Check imports
        imports = symbols["imports"]
        assert len(imports) >= 5
        
        # Check constants
        constants = symbols["constants"]
        constant_names = [c["name"] for c in constants]
        assert "MAX_RETRIES" in constant_names
        assert "DEBUG_MODE" in constant_names
        
        # Check complexity metrics
        complexity_metrics = symbols["complexity_metrics"]
        assert complexity_metrics["total_lines"] > 0
        assert complexity_metrics["code_lines"] > 0
        assert complexity_metrics["function_count"] >= 3
        assert complexity_metrics["class_count"] == 1

    def test_symbol_extraction_javascript(self, code_adapter, temp_javascript_file):
        """Test comprehensive symbol extraction for JavaScript."""
        temp_file, content = temp_javascript_file
        
        symbols = code_adapter.extract_symbols(content, str(temp_file), "javascript")
        
        # Check basic structure
        assert symbols["file_path"] == str(temp_file)
        assert symbols["language"] == "javascript"
        
        # Check complexity metrics
        complexity_metrics = symbols["complexity_metrics"]
        assert complexity_metrics["total_lines"] > 0
        assert complexity_metrics["code_lines"] > 0

    # Test Transform Item
    
    @pytest.mark.asyncio
    async def test_transform_item_python(self, code_adapter, temp_python_file):
        """Test transforming a Python file into ContextItem."""
        temp_file, content = temp_python_file
        
        raw_item = {
            "file_path": str(temp_file),
            "content": content,
            "encoding": "utf-8",
            "title": temp_file.name,
            "file_stats": {
                "size": len(content),
                "modified": datetime.utcnow(),
                "created": datetime.utcnow(),
            }
        }
        
        context_item = await code_adapter.transform_item(raw_item)
        
        # Check basic fields
        assert context_item.source_type == "code"
        assert context_item.source_id == str(temp_file)
        assert context_item.file_path == str(temp_file)
        assert context_item.content == content
        
        # Check metadata
        assert context_item.metrics is not None
        assert context_item.metrics["language"] == "python"
        assert "functions" in context_item.metrics
        assert "classes" in context_item.metrics
        assert "imports" in context_item.metrics
        
        # Check detailed symbols (from advanced analysis)
        if "detailed_symbols" in context_item.metrics:
            detailed_symbols = context_item.metrics["detailed_symbols"]
            assert detailed_symbols["language"] == "python"
            assert len(detailed_symbols["functions"]) >= 3
            assert len(detailed_symbols["classes"]) == 1

    # Test Relationship Detection
    
    @pytest.mark.asyncio
    async def test_enhanced_relationship_detection(self, code_adapter, temp_python_file):
        """Test enhanced relationship detection."""
        temp_file, content = temp_python_file
        
        # Create two context items
        raw_item1 = {
            "file_path": str(temp_file),
            "content": content,
            "encoding": "utf-8",
            "title": temp_file.name,
        }
        
        raw_item2 = {
            "file_path": str(temp_file).replace(".py", "_related.py"),
            "content": "import asyncio\nfrom " + temp_file.stem + " import DataProcessor\n\nclass RelatedProcessor(DataProcessor):\n    pass",
            "encoding": "utf-8",
            "title": temp_file.stem + "_related.py",
        }
        
        context_item1 = await code_adapter.transform_item(raw_item1)
        context_item2 = await code_adapter.transform_item(raw_item2)
        
        # Test relationship detection
        relationships = code_adapter.detect_enhanced_relationships(context_item2, [context_item1])
        
        # Should find relationships based on imports and inheritance
        assert len(relationships) > 0
        
        # Check for specific relationship types
        relationship_types = [rel[0] for rel in relationships]
        # Note: Exact relationship detection depends on the implementation
        # This is a basic check that relationships are being detected

    # Test Incremental Analysis
    
    def test_incremental_analysis_enable(self, code_adapter):
        """Test enabling incremental analysis."""
        watch_dirs = ["/test/dir"]
        code_adapter.enable_incremental_analysis(watch_dirs)
        
        assert hasattr(code_adapter, '_incremental_enabled')
        assert code_adapter._incremental_enabled is True
        assert code_adapter._watch_directories == watch_dirs

    def test_changed_files_detection(self, code_adapter):
        """Test detection of changed files."""
        # This test would require creating and modifying actual files
        # For now, we'll test the basic functionality
        
        since = datetime.utcnow() - timedelta(hours=1)
        changed_files = code_adapter.get_changed_files_since(since)
        
        # Should return a list (might be empty if no files changed)
        assert isinstance(changed_files, list)

    def test_cache_invalidation(self, code_adapter):
        """Test cache invalidation for specific files."""
        # Set up some cache data
        test_files = ["/test/file1.py", "/test/file2.py"]
        code_adapter._file_checksums = {f: "dummy_hash" for f in test_files}
        code_adapter._processed_files = set(test_files)
        
        # Invalidate cache
        code_adapter.invalidate_cache_for_files(test_files[:1])
        
        # Check that cache was invalidated for the specified file
        assert test_files[0] not in code_adapter._file_checksums
        assert test_files[0] not in code_adapter._processed_files
        
        # Check that other files are still cached
        assert test_files[1] in code_adapter._file_checksums
        assert test_files[1] in code_adapter._processed_files

    # Test Complexity Calculations
    
    def test_cyclomatic_complexity_calculation(self, code_adapter):
        """Test cyclomatic complexity calculation."""
        # Simple function with no branches
        simple_code = "def simple(): return 1"
        tree = ast.parse(simple_code)
        func_node = tree.body[0]
        complexity = code_adapter._calculate_cyclomatic_complexity(func_node)
        assert complexity == 1
        
        # Function with branches
        complex_code = """
def complex_func(x):
    if x > 0:
        for i in range(x):
            if i % 2 == 0:
                try:
                    result = i / 2
                except ZeroDivisionError:
                    result = 0
            else:
                result = i * 2
        return result
    else:
        return 0
"""
        tree = ast.parse(complex_code)
        func_node = tree.body[0]
        complexity = code_adapter._calculate_cyclomatic_complexity(func_node)
        assert complexity > 1  # Should have higher complexity due to branches

    # Test Error Handling
    
    @pytest.mark.asyncio
    async def test_invalid_python_syntax(self, code_adapter):
        """Test handling of invalid Python syntax."""
        invalid_content = "def invalid_syntax( missing_closing_paren:"
        
        # Should fall back to regex-based parsing
        functions = code_adapter._parse_python(invalid_content, "functions")
        
        # Should return empty list or handle gracefully
        assert isinstance(functions, list)

    @pytest.mark.asyncio
    async def test_file_not_found_handling(self, code_adapter):
        """Test handling of non-existent files."""
        non_existent_file = Path("/non/existent/file.py")
        
        result = await code_adapter._read_code_file(non_existent_file)
        
        # Should return None or handle gracefully
        assert result is None

    # Test Configuration
    
    def test_default_configuration(self):
        """Test default configuration creation."""
        config = CodeAdapter.default_config()
        
        assert config.adapter_id == "code"
        assert config.source_type == "code"
        assert config.batch_mode == BatchMode.BATCH
        assert config.source_config["extract_functions"] is True
        assert config.source_config["extract_classes"] is True
        assert config.source_config["enable_proj_intel"] is True

    @pytest.mark.asyncio
    async def test_cleanup(self, code_adapter):
        """Test adapter cleanup."""
        # Add some data to clean up
        code_adapter._file_checksums = {"test": "hash"}
        code_adapter._processed_files = {"test_file"}
        
        await code_adapter.cleanup()
        
        # Check that data was cleaned up
        assert len(code_adapter._file_checksums) == 0
        assert len(code_adapter._processed_files) == 0


# Integration Tests

class TestCodeAdapterIntegration:
    """Integration tests for the CodeAdapter."""
    
    @pytest.fixture
    def temp_directory(self):
        """Create a temporary directory structure for testing."""
        import tempfile
        import shutil
        
        temp_dir = Path(tempfile.mkdtemp())
        
        # Create test files
        (temp_dir / "main.py").write_text("""
import utils
from models import User

def main():
    user = User("test")
    result = utils.process(user)
    return result
""")
        
        (temp_dir / "utils.py").write_text("""
def process(user):
    return {"processed": True, "user": user.name}
""")
        
        (temp_dir / "models.py").write_text("""
class User:
    def __init__(self, name):
        self.name = name
""")
        
        yield temp_dir
        
        # Cleanup
        shutil.rmtree(temp_dir)

    @pytest.mark.asyncio
    async def test_full_directory_scan(self, temp_directory):
        """Test scanning a full directory structure."""
        config = AdapterConfig(
            adapter_id="integration_test",
            source_type="code",
            batch_mode=BatchMode.STREAMING,
            source_config={
                "scan_directories": [str(temp_directory)],
                "include_patterns": ["*.py"],
                "exclude_patterns": [],
                "extract_functions": True,
                "extract_classes": True,
                "enable_advanced_analysis": True,
            }
        )
        
        adapter = CodeAdapter(config)
        await adapter.initialize()
        
        items = []
        async for raw_item in adapter.fetch_items(limit=10):
            context_item = await adapter.transform_item(raw_item)
            items.append(context_item)
        
        # Should have processed 3 files
        assert len(items) == 3
        
        # Check that all files were processed
        file_names = [Path(item.file_path).name for item in items]
        assert "main.py" in file_names
        assert "utils.py" in file_names
        assert "models.py" in file_names
        
        await adapter.cleanup()


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])