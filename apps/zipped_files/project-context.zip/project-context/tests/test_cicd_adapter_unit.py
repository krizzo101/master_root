"""Comprehensive unit tests for CI/CD Adapters."""

import asyncio
import pytest
import json
import hmac
import hashlib
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from aiohttp import ClientSession, ClientResponse

from src.project_context.ingestion.adapters.cicd_adapter import (
    BaseCICDAdapter,
    GitHubActionsAdapter,
    GitLabCIAdapter,
    JenkinsAdapter,
    AzureDevOpsAdapter,
    CircleCIAdapter,
    CICDAdapterConfig,
    CICDPlatform,
    CICDEventType,
    APIRateLimiter,
    create_cicd_adapter,
)
from src.project_context.ingestion.base_adapter import BatchMode
from src.project_context.models.common import ContextItem


@pytest.fixture
def github_config():
    """Create test configuration for GitHub Actions."""
    return CICDAdapterConfig(
        adapter_id="test_github",
        source_type="cicd",
        batch_mode=BatchMode.STREAMING,
        batch_size=50,
        platform=CICDPlatform.GITHUB_ACTIONS,
        api_token="ghp_test_token",
        webhook_secret="test_secret",
        repositories=["owner/repo1", "owner/repo2"],
        event_types=[CICDEventType.WORKFLOW_COMPLETED, CICDEventType.JOB_COMPLETED],
        track_branches=["main", "develop"],
        api_rate_limit=100,
        historical_sync_days=30,
        enable_commit_correlation=True,
        enable_temporal_correlation=True,
        temporal_window_hours=2,
    )


@pytest.fixture
def gitlab_config():
    """Create test configuration for GitLab CI."""
    return CICDAdapterConfig(
        adapter_id="test_gitlab",
        source_type="cicd",
        platform=CICDPlatform.GITLAB_CI,
        base_url="https://gitlab.example.com/api/v4",
        api_token="glpat_test_token",
        webhook_secret="test_secret",
        projects=["123", "456"],
        event_types=[CICDEventType.WORKFLOW_COMPLETED],
        api_rate_limit=60,
    )


@pytest.fixture
def sample_github_workflow_run():
    """Sample GitHub workflow run data."""
    return {
        "id": 123456789,
        "name": "CI",
        "head_branch": "main",
        "head_sha": "abc123def456",
        "path": ".github/workflows/ci.yml",
        "run_number": 42,
        "run_attempt": 1,
        "status": "completed",
        "conclusion": "success",
        "workflow_id": 987654321,
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-15T10:35:00Z",
        "actor": {"login": "test-user"},
        "event": "push",
        "head_commit": {
            "id": "abc123def456",
            "message": "Add new feature"
        }
    }


@pytest.fixture
def sample_github_workflow_job():
    """Sample GitHub workflow job data."""
    return {
        "id": 987654321,
        "run_id": 123456789,
        "run_attempt": 1,
        "name": "build",
        "status": "completed",
        "conclusion": "success",
        "created_at": "2024-01-15T10:30:00Z",
        "started_at": "2024-01-15T10:30:30Z",
        "completed_at": "2024-01-15T10:35:00Z",
        "runner_name": "GitHub Actions 2",
        "runner_group_name": "Default"
    }


@pytest.fixture
def sample_gitlab_pipeline():
    """Sample GitLab pipeline data."""
    return {
        "id": 123456,
        "status": "success",
        "ref": "main",
        "sha": "abc123def456",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-15T10:35:00Z",
        "duration": 300,
        "user": {
            "id": 1,
            "username": "test-user",
            "name": "Test User"
        },
        "web_url": "https://gitlab.example.com/project/pipelines/123456",
        "source": "push"
    }


@pytest.fixture
def mock_http_session():
    """Mock aiohttp ClientSession."""
    session = AsyncMock(spec=ClientSession)
    response = AsyncMock(spec=ClientResponse)
    response.raise_for_status = Mock()
    response.json = AsyncMock()
    session.get.return_value.__aenter__.return_value = response
    session.post.return_value.__aenter__.return_value = response
    return session, response


class TestCICDAdapterConfig:
    """Tests for CICDAdapterConfig."""

    def test_default_initialization(self):
        """Test default configuration initialization."""
        config = CICDAdapterConfig(
            adapter_id="test_cicd",
            source_type="cicd"
        )
        
        assert config.adapter_id == "test_cicd"
        assert config.source_type == "cicd"
        assert config.platform == CICDPlatform.GITHUB_ACTIONS
        assert config.api_rate_limit == 100
        assert config.historical_sync_enabled is True
        assert config.enable_commit_correlation is True

    def test_custom_initialization(self, github_config):
        """Test custom configuration initialization."""
        assert github_config.platform == CICDPlatform.GITHUB_ACTIONS
        assert github_config.api_token == "ghp_test_token"
        assert github_config.webhook_secret == "test_secret"
        assert "owner/repo1" in github_config.repositories
        assert github_config.api_rate_limit == 100
        assert github_config.historical_sync_days == 30


class TestAPIRateLimiter:
    """Tests for API rate limiter."""

    @pytest.mark.asyncio
    async def test_rate_limiter_allows_requests(self):
        """Test that rate limiter allows requests under limit."""
        limiter = APIRateLimiter(requests_per_minute=60)
        
        # Should allow immediate requests
        await limiter.acquire()
        await limiter.acquire()
        
        # Should have recorded requests
        assert len(limiter.request_times) == 2

    @pytest.mark.asyncio
    async def test_rate_limiter_enforces_limit(self):
        """Test that rate limiter enforces request limit."""
        limiter = APIRateLimiter(requests_per_minute=2)
        
        # Fill up the rate limit
        await limiter.acquire()
        await limiter.acquire()
        
        # Third request should be delayed
        start_time = datetime.utcnow().timestamp()
        await limiter.acquire()
        end_time = datetime.utcnow().timestamp()
        
        # Should have been delayed (allowing some tolerance)
        assert (end_time - start_time) >= 0  # Some delay occurred


class TestGitHubActionsAdapter:
    """Tests for GitHub Actions adapter."""

    @pytest.fixture
    def github_adapter(self, github_config):
        """Create GitHub Actions adapter for testing."""
        return GitHubActionsAdapter(github_config)

    @pytest.mark.asyncio
    async def test_initialization(self, github_adapter, github_config):
        """Test GitHub adapter initialization."""
        assert github_adapter.cicd_config == github_config
        assert github_adapter.api_base == "https://api.github.com"
        assert isinstance(github_adapter.rate_limiter, APIRateLimiter)

    @pytest.mark.asyncio
    async def test_validate_webhook_signature_valid(self, github_adapter):
        """Test webhook signature validation with valid signature."""
        payload = b'{"action": "completed"}'
        secret = "test_secret"
        
        expected_signature = "sha256=" + hmac.new(
            secret.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        is_valid = github_adapter.validate_webhook_signature(payload, expected_signature)
        
        assert is_valid is True

    @pytest.mark.asyncio
    async def test_validate_webhook_signature_invalid(self, github_adapter):
        """Test webhook signature validation with invalid signature."""
        payload = b'{"action": "completed"}'
        invalid_signature = "sha256=invalid"
        
        is_valid = github_adapter.validate_webhook_signature(payload, invalid_signature)
        
        assert is_valid is False

    @pytest.mark.asyncio
    async def test_validate_webhook_signature_no_secret(self, github_config):
        """Test webhook signature validation with no secret configured."""
        github_config.webhook_secret = ""
        adapter = GitHubActionsAdapter(github_config)
        
        payload = b'{"action": "completed"}'
        signature = "anything"
        
        is_valid = adapter.validate_webhook_signature(payload, signature)
        
        assert is_valid is True  # Should skip validation

    def test_transform_workflow_run(self, github_adapter, sample_github_workflow_run):
        """Test transforming GitHub workflow run."""
        result = github_adapter._transform_workflow_run(
            sample_github_workflow_run, 
            "owner/repo"
        )
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "123456789"
        assert result.entity_type == "github_workflow_run"
        assert result.title == "Workflow: CI"
        assert result.project_id == "owner/repo"
        assert result.actor_id == "test-user"
        assert result.metrics["status"] == "completed"
        assert result.metrics["conclusion"] == "success"
        assert result.metrics["run_number"] == 42
        assert result.metrics["commit_sha"] == "abc123def456"

    def test_transform_workflow_job(self, github_adapter, sample_github_workflow_job):
        """Test transforming GitHub workflow job."""
        result = github_adapter._transform_workflow_job(
            sample_github_workflow_job,
            "owner/repo"
        )
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "987654321"
        assert result.entity_type == "github_workflow_job"
        assert result.title == "Job: build"
        assert result.project_id == "owner/repo"
        assert result.actor_id == "GitHub Actions 2"
        assert result.actor_type == "system"
        assert result.metrics["status"] == "completed"
        assert result.metrics["run_id"] == 123456789

    def test_extract_workflow_summary(self, github_adapter, sample_github_workflow_run):
        """Test workflow summary extraction."""
        summary = github_adapter._extract_workflow_summary(sample_github_workflow_run)
        
        assert "Workflow 'CI'" in summary
        assert "main" in summary
        assert "Status: completed" in summary
        assert "Conclusion: success" in summary

    def test_extract_job_summary(self, github_adapter, sample_github_workflow_job):
        """Test job summary extraction.""" 
        summary = github_adapter._extract_job_summary(sample_github_workflow_job)
        
        assert "Job 'build'" in summary
        assert "123456789" in summary
        assert "Status: completed" in summary
        assert "Conclusion: success" in summary
        assert "Runner: GitHub Actions 2" in summary

    def test_get_auth_headers(self, github_adapter):
        """Test authentication headers."""
        headers = github_adapter._get_auth_headers()
        
        assert headers["Authorization"] == "token ghp_test_token"
        assert headers["Accept"] == "application/vnd.github.v3+json"
        assert "User-Agent" in headers

    @pytest.mark.asyncio
    async def test_fetch_historical_data(self, github_adapter, mock_http_session):
        """Test fetching historical workflow data."""
        session, response = mock_http_session
        github_adapter.session = session
        
        # Mock API response
        response.json.return_value = {
            "workflow_runs": [
                sample_github_workflow_run(),
                {**sample_github_workflow_run(), "id": 999, "name": "Test"}
            ]
        }
        
        # Mock rate limiter
        github_adapter.rate_limiter.acquire = AsyncMock()
        
        items = []
        async for item in github_adapter.fetch_historical_data(limit=10):
            items.append(item)
        
        assert len(items) == 4  # 2 runs × 2 repos
        assert all(item["type"] == "workflow_run" for item in items)
        assert items[0]["repository"] == "owner/repo1"

    @pytest.mark.asyncio
    async def test_process_webhook_workflow_run(self, github_adapter):
        """Test processing workflow_run webhook."""
        payload = {
            "workflow_run": sample_github_workflow_run(),
            "repository": {"full_name": "owner/repo"}
        }
        
        result = await github_adapter.process_webhook("workflow_run", payload)
        
        assert isinstance(result, ContextItem)
        assert result.entity_type == "github_workflow_run"
        assert result.source_id == "123456789"

    @pytest.mark.asyncio
    async def test_process_webhook_workflow_job(self, github_adapter):
        """Test processing workflow_job webhook."""
        payload = {
            "workflow_job": sample_github_workflow_job(),
            "repository": {"full_name": "owner/repo"}
        }
        
        result = await github_adapter.process_webhook("workflow_job", payload)
        
        assert isinstance(result, ContextItem)
        assert result.entity_type == "github_workflow_job"
        assert result.source_id == "987654321"


class TestGitLabCIAdapter:
    """Tests for GitLab CI adapter."""

    @pytest.fixture
    def gitlab_adapter(self, gitlab_config):
        """Create GitLab CI adapter for testing."""
        return GitLabCIAdapter(gitlab_config)

    @pytest.mark.asyncio
    async def test_initialization(self, gitlab_adapter, gitlab_config):
        """Test GitLab adapter initialization."""
        assert gitlab_adapter.cicd_config == gitlab_config
        assert gitlab_adapter.api_base == "https://gitlab.example.com/api/v4"

    def test_validate_webhook_signature_valid(self, gitlab_adapter):
        """Test GitLab webhook token validation."""
        payload = b'{"object_kind": "pipeline"}'
        token = "test_secret"
        
        is_valid = gitlab_adapter.validate_webhook_signature(payload, token)
        
        assert is_valid is True

    def test_validate_webhook_signature_invalid(self, gitlab_adapter):
        """Test GitLab webhook token validation with invalid token."""
        payload = b'{"object_kind": "pipeline"}'
        invalid_token = "wrong_secret"
        
        is_valid = gitlab_adapter.validate_webhook_signature(payload, invalid_token)
        
        assert is_valid is False

    def test_transform_pipeline(self, gitlab_adapter, sample_gitlab_pipeline):
        """Test transforming GitLab pipeline."""
        result = gitlab_adapter._transform_pipeline(sample_gitlab_pipeline, "123")
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "123456"
        assert result.entity_type == "gitlab_pipeline"
        assert result.title == "Pipeline #123456 on main"
        assert result.project_id == "123"
        assert result.actor_id == "test-user"
        assert result.metrics["status"] == "success"
        assert result.metrics["ref"] == "main"
        assert result.metrics["duration_ms"] == 300000

    def test_extract_pipeline_summary(self, gitlab_adapter, sample_gitlab_pipeline):
        """Test pipeline summary extraction."""
        summary = gitlab_adapter._extract_pipeline_summary(sample_gitlab_pipeline)
        
        assert "Pipeline #123456" in summary
        assert "main" in summary
        assert "Status: success" in summary
        assert "Duration: 300s" in summary
        assert "User: Test User" in summary

    def test_get_auth_headers(self, gitlab_adapter):
        """Test GitLab authentication headers."""
        headers = gitlab_adapter._get_auth_headers()
        
        assert headers["Authorization"] == "Bearer glpat_test_token"
        assert headers["Content-Type"] == "application/json"

    @pytest.mark.asyncio
    async def test_fetch_historical_data(self, gitlab_adapter, mock_http_session):
        """Test fetching historical pipeline data."""
        session, response = mock_http_session
        gitlab_adapter.session = session
        
        # Mock pipeline and jobs responses
        pipeline_response = [sample_gitlab_pipeline()]
        jobs_response = [{
            "id": 1,
            "status": "success",
            "stage": "build",
            "name": "compile",
            "created_at": "2024-01-15T10:30:00Z",
            "finished_at": "2024-01-15T10:35:00Z",
            "duration": 300
        }]
        
        response.json.side_effect = [pipeline_response, jobs_response]
        gitlab_adapter.rate_limiter.acquire = AsyncMock()
        
        items = []
        async for item in gitlab_adapter.fetch_historical_data(limit=10):
            items.append(item)
        
        # Should get pipelines and jobs for each project
        assert len(items) >= 2  # At least 1 pipeline + 1 job per project
        pipeline_items = [i for i in items if i["type"] == "pipeline"]
        job_items = [i for i in items if i["type"] == "job"]
        assert len(pipeline_items) >= 1
        assert len(job_items) >= 1


class TestJenkinsAdapter:
    """Tests for Jenkins adapter."""

    @pytest.fixture
    def jenkins_config(self):
        """Create Jenkins adapter configuration."""
        return CICDAdapterConfig(
            adapter_id="test_jenkins",
            source_type="cicd",
            platform=CICDPlatform.JENKINS,
            base_url="http://jenkins.example.com:8080",
            api_token="user:api_token",
            projects=["job1", "job2"],  # Jenkins jobs
        )

    @pytest.fixture
    def jenkins_adapter(self, jenkins_config):
        """Create Jenkins adapter for testing."""
        return JenkinsAdapter(jenkins_config)

    @pytest.fixture
    def sample_jenkins_build(self):
        """Sample Jenkins build data."""
        return {
            "number": 42,
            "timestamp": 1705312200000,  # 2024-01-15 10:30:00
            "result": "SUCCESS",
            "duration": 300000,  # 5 minutes
            "url": "http://jenkins.example.com/job/test-job/42/",
            "changeSets": [{
                "items": [{
                    "commitId": "abc123def456",
                    "author": {"fullName": "Test User"},
                    "msg": "Add new feature"
                }]
            }]
        }

    def test_transform_build(self, jenkins_adapter, sample_jenkins_build):
        """Test transforming Jenkins build."""
        result = jenkins_adapter._transform_build(sample_jenkins_build, "test-job")
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "test-job#42"
        assert result.entity_type == "jenkins_build"
        assert result.title == "Build test-job #42"
        assert result.project_id == "test-job"
        assert result.actor_type == "system"
        assert result.metrics["status"] == "SUCCESS"
        assert result.metrics["build_number"] == 42
        assert result.metrics["duration_ms"] == 300000
        assert result.metrics["commit_sha"] == "abc123def456"

    def test_get_auth_headers(self, jenkins_adapter):
        """Test Jenkins authentication headers."""
        headers = jenkins_adapter._get_auth_headers()
        
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Basic ")

    @pytest.mark.asyncio
    async def test_fetch_historical_data(self, jenkins_adapter, mock_http_session):
        """Test fetching historical build data."""
        session, response = mock_http_session
        jenkins_adapter.session = session
        
        # Mock Jenkins API response
        response.json.return_value = {
            "builds": [sample_jenkins_build(), {**sample_jenkins_build(), "number": 41}]
        }
        jenkins_adapter.rate_limiter.acquire = AsyncMock()
        
        items = []
        async for item in jenkins_adapter.fetch_historical_data(limit=10):
            items.append(item)
        
        assert len(items) == 4  # 2 builds × 2 jobs
        assert all(item["type"] == "build" for item in items)

    def test_validate_webhook_signature(self, jenkins_adapter):
        """Test Jenkins webhook signature validation."""
        # Jenkins typically doesn't use webhook signatures
        payload = b'{"build_number": 42}'
        signature = "any_value"
        
        is_valid = jenkins_adapter.validate_webhook_signature(payload, signature)
        
        assert is_valid is True  # Always true for Jenkins


class TestAzureDevOpsAdapter:
    """Tests for Azure DevOps adapter."""

    @pytest.fixture
    def azure_config(self):
        """Create Azure DevOps adapter configuration."""
        return CICDAdapterConfig(
            adapter_id="test_azure",
            source_type="cicd",
            platform=CICDPlatform.AZURE_DEVOPS,
            base_url="https://dev.azure.com",
            api_token="pat_token",
            projects=["org/project1", "org/project2"],
        )

    @pytest.fixture
    def azure_adapter(self, azure_config):
        """Create Azure DevOps adapter for testing."""
        return AzureDevOpsAdapter(azure_config)

    @pytest.fixture
    def sample_azure_build(self):
        """Sample Azure DevOps build data."""
        return {
            "id": 123,
            "buildNumber": "20240115.1",
            "status": "completed",
            "result": "succeeded",
            "startTime": "2024-01-15T10:30:00Z",
            "finishTime": "2024-01-15T10:35:00Z",
            "requestedFor": {"uniqueName": "test@example.com"},
            "definition": {"name": "CI Build"},
            "sourceBranch": "refs/heads/main",
            "sourceVersion": "abc123def456"
        }

    def test_transform_build(self, azure_adapter, sample_azure_build):
        """Test transforming Azure DevOps build."""
        result = azure_adapter._transform_build(sample_azure_build, "org/project")
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "123"
        assert result.entity_type == "azure_build"
        assert result.title == "Build 20240115.1"
        assert result.project_id == "org/project"
        assert result.actor_id == "test@example.com"
        assert result.metrics["status"] == "completed"
        assert result.metrics["result"] == "succeeded"
        assert result.metrics["definition_name"] == "CI Build"

    def test_get_auth_headers(self, azure_adapter):
        """Test Azure DevOps authentication headers."""
        headers = azure_adapter._get_auth_headers()
        
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Basic ")


class TestCircleCIAdapter:
    """Tests for CircleCI adapter."""

    @pytest.fixture
    def circleci_config(self):
        """Create CircleCI adapter configuration."""
        return CICDAdapterConfig(
            adapter_id="test_circleci",
            source_type="cicd",
            platform=CICDPlatform.CIRCLECI,
            api_token="circle_token",
            webhook_secret="circle_secret",
            projects=["github/owner/repo1", "github/owner/repo2"],
        )

    @pytest.fixture
    def circleci_adapter(self, circleci_config):
        """Create CircleCI adapter for testing."""
        return CircleCIAdapter(circleci_config)

    @pytest.fixture
    def sample_circleci_pipeline(self):
        """Sample CircleCI pipeline data."""
        return {
            "id": "123e4567-e89b-12d3-a456-426614174000",
            "number": 42,
            "state": "success",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-15T10:35:00Z",
            "vcs": {
                "revision": "abc123def456",
                "branch": "main"
            }
        }

    def test_transform_pipeline(self, circleci_adapter, sample_circleci_pipeline):
        """Test transforming CircleCI pipeline."""
        result = circleci_adapter._transform_pipeline(
            sample_circleci_pipeline, 
            "github/owner/repo"
        )
        
        assert isinstance(result, ContextItem)
        assert result.source_type == "cicd"
        assert result.source_id == "123e4567-e89b-12d3-a456-426614174000"
        assert result.entity_type == "circleci_pipeline"
        assert result.title == "Pipeline 42"
        assert result.project_id == "github/owner/repo"
        assert result.metrics["status"] == "success"
        assert result.metrics["pipeline_number"] == 42
        assert result.metrics["vcs_revision"] == "abc123def456"

    def test_validate_webhook_signature_valid(self, circleci_adapter):
        """Test CircleCI webhook signature validation."""
        payload = b'{"type": "workflow-completed"}'
        
        expected_signature = hmac.new(
            "circle_secret".encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        is_valid = circleci_adapter.validate_webhook_signature(payload, expected_signature)
        
        assert is_valid is True

    def test_get_auth_headers(self, circleci_adapter):
        """Test CircleCI authentication headers."""
        headers = circleci_adapter._get_auth_headers()
        
        assert headers["Circle-Token"] == "circle_token"
        assert headers["Accept"] == "application/json"


class TestBaseCICDAdapter:
    """Tests for base CI/CD adapter functionality."""

    @pytest.fixture
    def base_adapter(self, github_config):
        """Create a concrete implementation for testing."""
        return GitHubActionsAdapter(github_config)

    @pytest.mark.asyncio
    async def test_start_and_stop(self, base_adapter):
        """Test adapter start and stop lifecycle."""
        # Mock the session creation
        with patch('aiohttp.ClientSession') as mock_session:
            mock_session_instance = AsyncMock()
            mock_session.return_value = mock_session_instance
            
            await base_adapter.start()
            
            assert base_adapter.session is not None
            
            await base_adapter.stop()
            
            # Verify session was closed
            mock_session_instance.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_detect_commit_relationships(self, base_adapter):
        """Test commit-based relationship detection."""
        # Create CI/CD item with commit SHA
        cicd_item = ContextItem(
            source_type="cicd",
            source_id="build_123",
            entity_type="github_workflow_run",
            source_data={"head_sha": "abc123def456"},
            metrics={"commit_sha": "abc123def456"}
        )
        
        # Create git item with matching commit
        git_item = ContextItem(
            source_type="git",
            source_id="commit_456",
            entity_type="commit",
            source_data={"sha": "abc123def456"}
        )
        
        context_window = [git_item]
        
        relationships = await base_adapter._detect_commit_relationships(cicd_item, context_window)
        
        assert len(relationships) == 1
        assert relationships[0][0] == "builds_commit"
        assert relationships[0][1] == str(git_item.id)
        assert relationships[0][2] == 1.0

    @pytest.mark.asyncio
    async def test_detect_temporal_relationships(self, base_adapter):
        """Test temporal relationship detection."""
        base_time = datetime.utcnow()
        
        # Create CI/CD item
        cicd_item = ContextItem(
            source_type="cicd",
            source_id="build_123",
            entity_type="github_workflow_run",
            timestamp=base_time,
            metrics={"status": "failed"}
        )
        
        # Create error item within temporal window
        error_item = ContextItem(
            source_type="error",
            source_id="error_456",
            entity_type="error",
            timestamp=base_time + timedelta(minutes=30),  # Within 2 hour window
            content="Build failed with compilation error"
        )
        
        # Create chat item within temporal window
        chat_item = ContextItem(
            source_type="chat",
            source_id="chat_789",
            entity_type="message",
            timestamp=base_time - timedelta(minutes=15),
            content="Starting the deployment process"
        )
        
        context_window = [error_item, chat_item]
        
        relationships = await base_adapter._detect_temporal_relationships(cicd_item, context_window)
        
        # Should find relationships with both error and chat
        error_rels = [r for r in relationships if r[0] == "error_during_cicd"]
        chat_rels = [r for r in relationships if r[0] == "discussed_during_cicd"]
        
        assert len(error_rels) == 1
        assert len(chat_rels) == 1

    @pytest.mark.asyncio
    async def test_detect_cicd_chain_relationships(self, base_adapter):
        """Test CI/CD pipeline chain relationship detection."""
        build_item = ContextItem(
            source_type="cicd",
            source_id="build_123",
            entity_type="github_workflow_run",
            metrics={"commit_sha": "abc123def456"}
        )
        
        deployment_item = ContextItem(
            source_type="cicd", 
            source_id="deploy_456",
            entity_type="github_deployment",
            metrics={"commit_sha": "abc123def456", "environment": "production"}
        )
        
        relationships = await base_adapter._detect_cicd_chain_relationships(
            build_item, deployment_item, 0.8
        )
        
        assert len(relationships) == 1
        assert relationships[0][0] == "triggers_deployment"
        assert relationships[0][1] == str(deployment_item.id)
        assert relationships[0][2] == 0.64  # 0.8 * 0.8

    def test_extract_artifact_metadata(self, base_adapter):
        """Test artifact metadata extraction."""
        raw_item = {
            "type": "build",
            "data": {
                "artifacts": [
                    {"url": "http://example.com/artifact1.zip", "size": 1024},
                    {"url": "http://example.com/artifact2.jar", "size": 2048}
                ],
                "test_results": {
                    "total": 100,
                    "passed": 95,
                    "failed": 5,
                    "coverage": 85.5
                },
                "quality_gate": {
                    "status": "passed",
                    "coverage": 85.5,
                    "code_smells": 3,
                    "vulnerabilities": 0
                },
                "deployment_strategy": "blue_green",
                "rollback_enabled": True
            }
        }
        
        metadata = base_adapter._extract_artifact_metadata(raw_item)
        
        assert metadata["artifact_count"] == 2
        assert len(metadata["artifact_urls"]) == 2
        assert metadata["tests_total"] == 100
        assert metadata["tests_passed"] == 95
        assert metadata["tests_failed"] == 5
        assert metadata["test_coverage"] == 85.5
        assert metadata["quality_gate_status"] == "passed"
        assert metadata["deployment_strategy"] == "blue_green"
        assert metadata["rollback_enabled"] is True


class TestCICDAdapterFactory:
    """Tests for CI/CD adapter factory function."""

    def test_create_github_adapter(self, github_config):
        """Test creating GitHub Actions adapter."""
        adapter = create_cicd_adapter(CICDPlatform.GITHUB_ACTIONS, github_config)
        
        assert isinstance(adapter, GitHubActionsAdapter)
        assert adapter.cicd_config == github_config

    def test_create_gitlab_adapter(self, gitlab_config):
        """Test creating GitLab CI adapter."""
        adapter = create_cicd_adapter(CICDPlatform.GITLAB_CI, gitlab_config)
        
        assert isinstance(adapter, GitLabCIAdapter)
        assert adapter.cicd_config == gitlab_config

    def test_create_unsupported_adapter(self, github_config):
        """Test creating unsupported adapter type."""
        # Mock an unsupported platform
        with pytest.raises(ValueError, match="Unsupported CI/CD platform"):
            create_cicd_adapter("unsupported_platform", github_config)


class TestErrorHandlingAndEdgeCases:
    """Tests for error handling and edge cases."""

    @pytest.fixture
    def github_adapter(self, github_config):
        """Create GitHub Actions adapter for testing."""
        return GitHubActionsAdapter(github_config)

    @pytest.mark.asyncio
    async def test_transform_item_with_missing_data(self, github_adapter):
        """Test transforming item with missing data fields."""
        incomplete_run = {
            "id": 123,
            "name": "Test Workflow",
            # Missing many expected fields
        }
        
        raw_item = {
            "type": "workflow_run",
            "data": incomplete_run,
            "repository": "owner/repo"
        }
        
        result = await github_adapter._transform_platform_item(raw_item)
        
        assert isinstance(result, ContextItem)
        assert result.source_id == "123"
        assert result.title == "Workflow: Test Workflow"

    @pytest.mark.asyncio
    async def test_webhook_processing_unknown_event(self, github_adapter):
        """Test processing unknown webhook event type."""
        result = await github_adapter.process_webhook("unknown_event", {})
        
        assert result is None

    @pytest.mark.asyncio
    async def test_api_error_handling(self, github_adapter, mock_http_session):
        """Test handling API errors during data fetching."""
        session, response = mock_http_session
        github_adapter.session = session
        
        # Mock API error
        response.raise_for_status.side_effect = Exception("API Error")
        github_adapter.rate_limiter.acquire = AsyncMock()
        
        items = []
        async for item in github_adapter.fetch_historical_data(limit=10):
            items.append(item)
        
        # Should handle errors gracefully and return empty results
        assert len(items) == 0

    def test_invalid_timestamp_handling(self, github_adapter):
        """Test handling invalid timestamp formats."""
        invalid_run = {
            "id": 123,
            "name": "Test",
            "created_at": "invalid-timestamp",
            "updated_at": "also-invalid",
            "status": "completed"
        }
        
        # Should handle invalid timestamps gracefully
        result = github_adapter._transform_workflow_run(invalid_run, "owner/repo")
        
        assert isinstance(result, ContextItem)
        assert result.source_id == "123"


class TestPerformanceAndScalability:
    """Tests for performance and scalability scenarios."""

    @pytest.mark.asyncio
    async def test_concurrent_webhook_processing(self, github_config):
        """Test concurrent webhook processing."""
        adapter = GitHubActionsAdapter(github_config)
        
        # Create multiple webhook payloads
        payloads = []
        for i in range(10):
            payload = {
                "workflow_run": {**sample_github_workflow_run(), "id": i, "name": f"Workflow {i}"},
                "repository": {"full_name": "owner/repo"}
            }
            payloads.append(payload)
        
        # Process webhooks concurrently
        async def process_webhook_with_payload(payload):
            return await adapter.process_webhook("workflow_run", payload)
        
        tasks = [process_webhook_with_payload(p) for p in payloads]
        results = await asyncio.gather(*tasks)
        
        # Verify all webhooks processed successfully
        assert len(results) == 10
        assert all(isinstance(r, ContextItem) for r in results)
        assert len(set(r.source_id for r in results)) == 10  # All unique

    @pytest.mark.asyncio
    async def test_large_batch_processing(self, github_adapter, mock_http_session):
        """Test processing large batches of CI/CD data."""
        session, response = mock_http_session
        github_adapter.session = session
        
        # Mock large batch of workflow runs
        large_batch = {
            "workflow_runs": [
                {**sample_github_workflow_run(), "id": i, "name": f"Workflow {i}"}
                for i in range(500)
            ]
        }
        
        response.json.return_value = large_batch
        github_adapter.rate_limiter.acquire = AsyncMock()
        
        # Process large batch
        items = []
        async for item in github_adapter.fetch_historical_data(limit=1000):
            items.append(item)
            if len(items) >= 100:  # Limit for test performance
                break
        
        assert len(items) >= 100
        assert all(item["type"] == "workflow_run" for item in items)


# Integration test markers for different test categories
pytestmark = [
    pytest.mark.unit,
    pytest.mark.cicd_adapter,
]