"""Performance and load tests for the unified context system."""

import asyncio
import pytest
import time
import statistics
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List
from unittest.mock import Mock, AsyncMock, patch
from uuid import uuid4
import psutil
import sys

from src.project_context.ingestion.adapters.git_adapter import GitAdapter
from src.project_context.ingestion.adapters.error_adapter import ErrorAdapter
from src.project_context.ingestion.adapters.cicd_adapter import GitHubActionsAdapter, CICDAdapterConfig, CICDPlatform
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


# Performance test configuration
PERFORMANCE_CONFIG = {
    "small_load": {
        "items": 100,
        "timeout": 10,
        "memory_limit_mb": 100
    },
    "medium_load": {
        "items": 1000,
        "timeout": 30,
        "memory_limit_mb": 200
    },
    "large_load": {
        "items": 5000,
        "timeout": 120,
        "memory_limit_mb": 500
    }
}


class PerformanceMonitor:
    """Monitor performance metrics during tests."""
    
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.start_memory = None
        self.peak_memory = None
        self.cpu_samples = []
        self.processing_times = []
        self._monitoring = False
        self._monitor_task = None
    
    async def start_monitoring(self):
        """Start performance monitoring."""
        self.start_time = time.time()
        self.start_memory = self._get_memory_usage()
        self.peak_memory = self.start_memory
        self._monitoring = True
        
        # Start background monitoring
        self._monitor_task = asyncio.create_task(self._monitor_resources())
    
    async def stop_monitoring(self):
        """Stop performance monitoring."""
        self.end_time = time.time()
        self._monitoring = False
        
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
    
    async def _monitor_resources(self):
        """Background resource monitoring."""
        while self._monitoring:
            try:
                # Monitor memory
                current_memory = self._get_memory_usage()
                if current_memory > self.peak_memory:
                    self.peak_memory = current_memory
                
                # Monitor CPU
                cpu_percent = psutil.cpu_percent()
                self.cpu_samples.append(cpu_percent)
                
                await asyncio.sleep(0.1)  # Sample every 100ms
            except Exception:
                break  # Stop monitoring on error
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        try:
            process = psutil.Process()
            return process.memory_info().rss / (1024 * 1024)
        except Exception:
            return 0.0
    
    def record_processing_time(self, processing_time: float):
        """Record a processing time measurement."""
        self.processing_times.append(processing_time)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics."""
        if not self.start_time or not self.end_time:
            return {}
        
        total_time = self.end_time - self.start_time
        memory_used = self.peak_memory - self.start_memory
        
        return {
            "total_time_seconds": total_time,
            "memory_used_mb": memory_used,
            "peak_memory_mb": self.peak_memory,
            "avg_cpu_percent": statistics.mean(self.cpu_samples) if self.cpu_samples else 0,
            "max_cpu_percent": max(self.cpu_samples) if self.cpu_samples else 0,
            "avg_processing_time": statistics.mean(self.processing_times) if self.processing_times else 0,
            "max_processing_time": max(self.processing_times) if self.processing_times else 0,
            "min_processing_time": min(self.processing_times) if self.processing_times else 0,
            "processing_samples": len(self.processing_times)
        }


@pytest.fixture
def performance_monitor():
    """Create performance monitor for tests."""
    return PerformanceMonitor()


@pytest.fixture
def git_adapter_for_perf():
    """Create Git adapter optimized for performance testing."""
    config = AdapterConfig(
        adapter_id="perf_git",
        source_type="git",
        batch_mode=BatchMode.BATCH,
        batch_size=100,
        generate_embeddings=False,
        generate_summaries=False,
        source_config={
            "repository_path": "/test/repo",
            "enable_semantic_analysis": False,  # Disable for performance
            "enable_branch_detection": False,
            "include_diff_content": False,  # Skip heavy content
        }
    )
    return GitAdapter(config, AsyncMock())


@pytest.fixture
def error_adapter_for_perf():
    """Create Error adapter optimized for performance testing."""
    config = AdapterConfig(
        adapter_id="perf_error",
        source_type="error",
        batch_mode=BatchMode.BATCH,
        batch_size=100,
        generate_embeddings=False,
        source_config={
            "input_sources": ["logs"],
            "stack_trace_parsing": False,  # Disable for performance
            "group_similar_errors": False,
        }
    )
    return ErrorAdapter(config)


@pytest.fixture
def cicd_adapter_for_perf():
    """Create CI/CD adapter optimized for performance testing."""
    config = CICDAdapterConfig(
        adapter_id="perf_cicd",
        source_type="cicd",
        platform=CICDPlatform.GITHUB_ACTIONS,
        batch_size=100,
        repositories=["owner/repo"],
        enable_commit_correlation=False,  # Disable for performance
        enable_temporal_correlation=False,
        calculate_performance_metrics=False,
    )
    return GitHubActionsAdapter(config)


class TestAdapterPerformance:
    """Test individual adapter performance."""

    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_git_adapter_small_load(self, git_adapter_for_perf, performance_monitor):
        """Test Git adapter performance with small load."""
        load_config = PERFORMANCE_CONFIG["small_load"]
        
        # Generate test commit data
        test_commits = []
        for i in range(load_config["items"]):
            commit = {
                "hash": f"commit_{i:06d}",
                "author": f"author_{i % 10}",
                "author_email": f"author{i % 10}@example.com",
                "commit_date": f"2024-01-{15 + (i % 15):02d} 10:00:00 +0000",
                "subject": f"Commit {i}: Add feature",
                "body": f"This is commit number {i}",
                "changed_files": [
                    {"type": "M", "file": f"src/file_{i % 20}.py"}
                ]
            }
            test_commits.append(commit)
        
        # Mock git operations
        with patch.object(git_adapter_for_perf, '_run_git_command') as git_mock:
            with patch.object(git_adapter_for_perf, '_is_git_repo', return_value=True):
                git_mock.return_value = "git version 2.34.1"
                
                # Mock fetch_items to return test data
                async def mock_fetch_items(*args, **kwargs):
                    for commit in test_commits:
                        yield commit
                
                git_adapter_for_perf.fetch_items = mock_fetch_items
                
                # Mock transformer
                with patch.object(git_adapter_for_perf.transformer, 'create_base_context_item') as mock_create:
                    with patch.object(git_adapter_for_perf.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                        def create_item(source_type, source_id, raw_data):
                            return ContextItem(
                                source_type=source_type,
                                source_id=source_id,
                                title=raw_data.get("subject", f"Item {source_id}")
                            )
                        
                        mock_create.side_effect = create_item
                        mock_transform.side_effect = lambda x: x
                        
                        await performance_monitor.start_monitoring()
                        
                        # Initialize and process
                        await git_adapter_for_perf.initialize()
                        
                        processed_count = 0
                        async for item in git_adapter_for_perf.fetch_items():
                            start_time = time.time()
                            result = await git_adapter_for_perf.transform_item(item)
                            end_time = time.time()
                            
                            performance_monitor.record_processing_time(end_time - start_time)
                            processed_count += 1
                            
                            if processed_count >= load_config["items"]:
                                break
                        
                        await performance_monitor.stop_monitoring()
                        
                        # Verify performance
                        metrics = performance_monitor.get_metrics()
                        
                        assert processed_count == load_config["items"]
                        assert metrics["total_time_seconds"] < load_config["timeout"]
                        assert metrics["peak_memory_mb"] < load_config["memory_limit_mb"]
                        
                        # Performance assertions
                        assert metrics["avg_processing_time"] < 0.01  # < 10ms per item
                        assert metrics["max_processing_time"] < 0.1   # < 100ms max
                        
                        print(f"Git Adapter Small Load Performance:")
                        print(f"  Processed: {processed_count} items")
                        print(f"  Total time: {metrics['total_time_seconds']:.2f}s")
                        print(f"  Memory used: {metrics['memory_used_mb']:.2f}MB")
                        print(f"  Avg processing time: {metrics['avg_processing_time']*1000:.2f}ms")

    @pytest.mark.performance
    @pytest.mark.asyncio 
    async def test_error_adapter_medium_load(self, error_adapter_for_perf, performance_monitor):
        """Test Error adapter performance with medium load."""
        load_config = PERFORMANCE_CONFIG["medium_load"]
        
        # Generate test error data
        test_errors = []
        for i in range(load_config["items"]):
            error = {
                "error_id": f"error_{i:06d}",
                "message": f"Error {i}: Something went wrong",
                "severity": ["error", "warning", "info"][i % 3],
                "timestamp": datetime.utcnow() - timedelta(minutes=i),
                "file_path": f"src/module_{i % 50}.py",
                "line_number": (i % 1000) + 1,
                "error_type": f"ErrorType_{i % 10}",
                "source": "logs"
            }
            test_errors.append(error)
        
        # Mock error processing
        async def mock_fetch_items(*args, **kwargs):
            for error in test_errors:
                yield error
        
        error_adapter_for_perf.fetch_items = mock_fetch_items
        
        with patch.object(error_adapter_for_perf.transformer, 'create_base_context_item') as mock_create:
            with patch.object(error_adapter_for_perf.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                def create_item(source_type, source_id, raw_data):
                    return ContextItem(
                        source_type=source_type,
                        source_id=source_id,
                        title=raw_data.get("message", f"Error {source_id}")
                    )
                
                mock_create.side_effect = create_item
                mock_transform.side_effect = lambda x: x
                
                await performance_monitor.start_monitoring()
                
                await error_adapter_for_perf.initialize()
                
                processed_count = 0
                async for item in error_adapter_for_perf.fetch_items():
                    start_time = time.time()
                    result = await error_adapter_for_perf.transform_item(item)
                    end_time = time.time()
                    
                    performance_monitor.record_processing_time(end_time - start_time)
                    processed_count += 1
                    
                    if processed_count >= load_config["items"]:
                        break
                
                await performance_monitor.stop_monitoring()
                
                # Verify performance
                metrics = performance_monitor.get_metrics()
                
                assert processed_count == load_config["items"]
                assert metrics["total_time_seconds"] < load_config["timeout"]
                assert metrics["peak_memory_mb"] < load_config["memory_limit_mb"]
                
                # Performance assertions
                assert metrics["avg_processing_time"] < 0.01  # < 10ms per item
                
                print(f"Error Adapter Medium Load Performance:")
                print(f"  Processed: {processed_count} items")
                print(f"  Total time: {metrics['total_time_seconds']:.2f}s")
                print(f"  Memory used: {metrics['memory_used_mb']:.2f}MB")
                print(f"  Throughput: {processed_count / metrics['total_time_seconds']:.1f} items/sec")

    @pytest.mark.performance
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_cicd_adapter_large_load(self, cicd_adapter_for_perf, performance_monitor):
        """Test CI/CD adapter performance with large load."""
        load_config = PERFORMANCE_CONFIG["large_load"]
        
        # Generate test CI/CD data
        test_workflows = []
        for i in range(load_config["items"]):
            workflow = {
                "id": i + 1000000,
                "name": f"Workflow {i}",
                "head_branch": f"branch_{i % 20}",
                "head_sha": f"sha_{i:08x}",
                "status": ["completed", "in_progress", "queued"][i % 3],
                "conclusion": ["success", "failure", "cancelled"][i % 3],
                "created_at": f"2024-01-15T{10 + (i % 12):02d}:00:00Z",
                "updated_at": f"2024-01-15T{10 + (i % 12):02d}:05:00Z",
                "actor": {"login": f"user_{i % 25}"}
            }
            test_workflows.append(workflow)
        
        # Mock CI/CD operations
        async def mock_fetch_items(*args, **kwargs):
            for workflow in test_workflows:
                yield {"type": "workflow_run", "data": workflow, "repository": "owner/repo"}
        
        cicd_adapter_for_perf.fetch_items = mock_fetch_items
        
        await performance_monitor.start_monitoring()
        
        # Mock HTTP session
        with patch('aiohttp.ClientSession'):
            await cicd_adapter_for_perf.start()
            
            processed_count = 0
            async for item in cicd_adapter_for_perf.fetch_items():
                start_time = time.time()
                result = await cicd_adapter_for_perf.transform_item(item)
                end_time = time.time()
                
                performance_monitor.record_processing_time(end_time - start_time)
                processed_count += 1
                
                if processed_count >= load_config["items"]:
                    break
            
            await cicd_adapter_for_perf.stop()
        
        await performance_monitor.stop_monitoring()
        
        # Verify performance
        metrics = performance_monitor.get_metrics()
        
        assert processed_count == load_config["items"]
        assert metrics["total_time_seconds"] < load_config["timeout"]
        assert metrics["peak_memory_mb"] < load_config["memory_limit_mb"]
        
        # Performance assertions
        throughput = processed_count / metrics["total_time_seconds"]
        assert throughput > 50  # At least 50 items/second
        assert metrics["avg_processing_time"] < 0.02  # < 20ms per item
        
        print(f"CI/CD Adapter Large Load Performance:")
        print(f"  Processed: {processed_count} items")
        print(f"  Total time: {metrics['total_time_seconds']:.2f}s")
        print(f"  Memory used: {metrics['memory_used_mb']:.2f}MB")
        print(f"  Throughput: {throughput:.1f} items/sec")


class TestConcurrencyPerformance:
    """Test performance under concurrent load."""

    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_concurrent_adapter_processing(self, performance_monitor):
        """Test concurrent processing of multiple adapters."""
        # Create multiple adapters
        adapters = []
        
        for i in range(3):
            config = AdapterConfig(
                adapter_id=f"concurrent_{i}",
                source_type="test",
                batch_mode=BatchMode.STREAMING,
                batch_size=50
            )
            
            # Mock adapter
            adapter = AsyncMock()
            adapter.config = config
            
            # Generate data for each adapter
            async def create_fetch_items(adapter_id):
                for j in range(200):  # 200 items per adapter
                    yield {
                        "id": f"{adapter_id}_{j}",
                        "data": f"Item {j} from adapter {adapter_id}"
                    }
            
            adapter.fetch_items.return_value = create_fetch_items(i)
            adapter.transform_item.side_effect = lambda raw: ContextItem(
                source_type="test",
                source_id=raw["id"],
                title=raw["data"]
            )
            
            adapters.append(adapter)
        
        await performance_monitor.start_monitoring()
        
        # Process adapters concurrently
        async def process_adapter(adapter):
            processed = 0
            async for item in adapter.fetch_items():
                start_time = time.time()
                result = await adapter.transform_item(item)
                end_time = time.time()
                
                performance_monitor.record_processing_time(end_time - start_time)
                processed += 1
            return processed
        
        # Run all adapters concurrently
        tasks = [process_adapter(adapter) for adapter in adapters]
        results = await asyncio.gather(*tasks)
        
        await performance_monitor.stop_monitoring()
        
        # Verify results
        total_processed = sum(results)
        metrics = performance_monitor.get_metrics()
        
        assert total_processed == 600  # 200 × 3 adapters
        assert metrics["total_time_seconds"] < 30  # Should be much faster than sequential
        assert metrics["peak_memory_mb"] < 300
        
        # Concurrent throughput should be high
        throughput = total_processed / metrics["total_time_seconds"]
        assert throughput > 100  # At least 100 items/second concurrently
        
        print(f"Concurrent Processing Performance:")
        print(f"  Adapters: {len(adapters)}")
        print(f"  Total processed: {total_processed} items")
        print(f"  Total time: {metrics['total_time_seconds']:.2f}s")
        print(f"  Concurrent throughput: {throughput:.1f} items/sec")

    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_batch_processing_efficiency(self, performance_monitor):
        """Test efficiency of different batch sizes."""
        batch_sizes = [10, 50, 100, 200]
        results = {}
        
        for batch_size in batch_sizes:
            config = AdapterConfig(
                adapter_id=f"batch_{batch_size}",
                source_type="test",
                batch_mode=BatchMode.BATCH,
                batch_size=batch_size
            )
            
            # Create test data
            test_items = []
            for i in range(1000):  # Fixed dataset size
                test_items.append({
                    "id": f"item_{i:04d}",
                    "data": f"Test item {i}"
                })
            
            # Mock adapter
            adapter = AsyncMock()
            adapter.config = config
            
            async def mock_fetch():
                for item in test_items:
                    yield item
            
            adapter.fetch_items.return_value = mock_fetch()
            adapter.transform_item.side_effect = lambda raw: ContextItem(
                source_type="test",
                source_id=raw["id"],
                title=raw["data"]
            )
            
            # Measure batch processing
            monitor = PerformanceMonitor()
            await monitor.start_monitoring()
            
            processed_count = 0
            batch_count = 0
            current_batch = []
            
            async for item in adapter.fetch_items():
                current_batch.append(item)
                
                if len(current_batch) >= batch_size:
                    # Process batch
                    batch_start = time.time()
                    for batch_item in current_batch:
                        await adapter.transform_item(batch_item)
                        processed_count += 1
                    batch_end = time.time()
                    
                    monitor.record_processing_time(batch_end - batch_start)
                    batch_count += 1
                    current_batch = []
            
            # Process remaining items
            if current_batch:
                for batch_item in current_batch:
                    await adapter.transform_item(batch_item)
                    processed_count += 1
            
            await monitor.stop_monitoring()
            
            metrics = monitor.get_metrics()
            results[batch_size] = {
                "processed": processed_count,
                "time": metrics["total_time_seconds"],
                "throughput": processed_count / metrics["total_time_seconds"],
                "avg_batch_time": metrics["avg_processing_time"]
            }
        
        # Verify batch efficiency
        print("Batch Size Performance Comparison:")
        for batch_size, result in results.items():
            print(f"  Batch size {batch_size}: {result['throughput']:.1f} items/sec, "
                  f"avg batch time: {result['avg_batch_time']*1000:.1f}ms")
        
        # Larger batches should generally be more efficient
        throughputs = [results[bs]["throughput"] for bs in batch_sizes]
        assert max(throughputs) > min(throughputs) * 1.2  # At least 20% improvement


class TestMemoryManagement:
    """Test memory usage and management."""

    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_memory_efficiency_large_dataset(self, performance_monitor):
        """Test memory usage with large datasets."""
        # Create adapter with memory monitoring
        config = AdapterConfig(
            adapter_id="memory_test",
            source_type="test",
            batch_mode=BatchMode.STREAMING,
            batch_size=100
        )
        
        # Generate large dataset (but process in streaming fashion)
        total_items = 10000
        
        # Mock adapter that yields large objects
        adapter = AsyncMock()
        adapter.config = config
        
        async def large_data_fetch():
            for i in range(total_items):
                # Create item with some content to use memory
                yield {
                    "id": f"large_item_{i:06d}",
                    "data": f"Large data item {i}",
                    "content": "x" * 1000,  # 1KB per item
                    "metadata": {
                        "tags": [f"tag_{j}" for j in range(10)],
                        "properties": {f"prop_{k}": f"value_{k}" for k in range(20)}
                    }
                }
        
        adapter.fetch_items.return_value = large_data_fetch()
        adapter.transform_item.side_effect = lambda raw: ContextItem(
            source_type="test",
            source_id=raw["id"],
            title=raw["data"],
            content=raw["content"]
        )
        
        await performance_monitor.start_monitoring()
        
        # Process in streaming fashion (should not accumulate memory)
        processed_count = 0
        async for item in adapter.fetch_items():
            result = await adapter.transform_item(item)
            processed_count += 1
            
            # Periodically check memory usage
            if processed_count % 1000 == 0:
                current_memory = performance_monitor._get_memory_usage()
                print(f"Processed {processed_count} items, memory: {current_memory:.1f}MB")
        
        await performance_monitor.stop_monitoring()
        
        # Verify memory efficiency
        metrics = performance_monitor.get_metrics()
        
        assert processed_count == total_items
        
        # Memory usage should not grow linearly with dataset size
        # (streaming processing should keep memory bounded)
        memory_per_item = metrics["memory_used_mb"] / total_items
        assert memory_per_item < 0.1  # Less than 0.1MB per item accumulated
        
        print(f"Memory Efficiency Test:")
        print(f"  Processed: {processed_count} items")
        print(f"  Memory used: {metrics['memory_used_mb']:.2f}MB")
        print(f"  Memory per item: {memory_per_item*1024:.2f}KB")

    @pytest.mark.performance
    @pytest.mark.asyncio
    async def test_relationship_detection_memory_scaling(self, performance_monitor):
        """Test memory usage of relationship detection with growing context windows."""
        # Test relationship detection memory usage
        context_window_sizes = [10, 50, 100, 500]
        memory_results = {}
        
        for window_size in context_window_sizes:
            # Create context items
            context_items = []
            for i in range(window_size):
                item = ContextItem(
                    id=uuid4(),
                    source_type="test",
                    source_id=f"context_{i}",
                    title=f"Context item {i}",
                    timestamp=datetime.utcnow() - timedelta(minutes=i),
                    metrics={
                        "commit_hash": f"hash_{i % 20}",
                        "changed_files": [f"file_{j}.py" for j in range(i % 5 + 1)]
                    }
                )
                context_items.append(item)
            
            # Create test item for relationship detection
            test_item = ContextItem(
                id=uuid4(),
                source_type="git",
                source_id="test_item",
                entity_type="commit",
                title="Test commit",
                metrics={
                    "commit_hash": "test_hash",
                    "changed_files": ["file_0.py", "file_1.py"]
                }
            )
            
            # Mock adapter with relationship detection
            config = AdapterConfig(
                adapter_id="relationship_test",
                source_type="git",
                extract_relationships=True
            )
            adapter = GitAdapter(config, AsyncMock())
            
            # Measure memory during relationship detection
            start_memory = performance_monitor._get_memory_usage()
            
            start_time = time.time()
            relationships = await adapter.detect_relationships(test_item, context_items)
            end_time = time.time()
            
            end_memory = performance_monitor._get_memory_usage()
            
            memory_results[window_size] = {
                "memory_used": end_memory - start_memory,
                "processing_time": end_time - start_time,
                "relationships_found": len(relationships)
            }
        
        # Verify memory scaling
        print("Relationship Detection Memory Scaling:")
        for window_size, result in memory_results.items():
            print(f"  Window size {window_size}: {result['memory_used']:.2f}MB, "
                  f"{result['processing_time']*1000:.1f}ms, "
                  f"{result['relationships_found']} relationships")
        
        # Memory should scale sub-linearly (not O(n²))
        max_memory = max(r["memory_used"] for r in memory_results.values())
        assert max_memory < 50  # Should use less than 50MB even for large windows


class TestStressTests:
    """Stress tests for extreme conditions."""

    @pytest.mark.stress
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_sustained_high_throughput(self, performance_monitor):
        """Test sustained high throughput processing."""
        # Run high throughput for extended period
        duration_seconds = 60  # 1 minute
        target_throughput = 100  # items/second
        
        config = AdapterConfig(
            adapter_id="stress_test",
            source_type="test",
            batch_mode=BatchMode.STREAMING,
            batch_size=10
        )
        
        # Mock high-speed adapter
        adapter = AsyncMock()
        adapter.config = config
        
        async def high_speed_fetch():
            item_count = 0
            while True:
                yield {
                    "id": f"stress_item_{item_count:08d}",
                    "data": f"Stress test item {item_count}",
                    "timestamp": time.time()
                }
                item_count += 1
                
                # Small delay to control throughput
                await asyncio.sleep(1.0 / target_throughput)
        
        adapter.fetch_items.return_value = high_speed_fetch()
        adapter.transform_item.side_effect = lambda raw: ContextItem(
            source_type="test",
            source_id=raw["id"],
            title=raw["data"]
        )
        
        await performance_monitor.start_monitoring()
        
        # Process for duration
        processed_count = 0
        start_time = time.time()
        
        async for item in adapter.fetch_items():
            await adapter.transform_item(item)
            processed_count += 1
            
            # Check if duration exceeded
            if time.time() - start_time >= duration_seconds:
                break
        
        await performance_monitor.stop_monitoring()
        
        # Verify sustained performance
        metrics = performance_monitor.get_metrics()
        actual_throughput = processed_count / metrics["total_time_seconds"]
        
        assert processed_count >= target_throughput * duration_seconds * 0.8  # 80% of target
        assert actual_throughput >= target_throughput * 0.8
        assert metrics["peak_memory_mb"] < 200  # Memory should stay bounded
        
        print(f"Sustained Throughput Test:")
        print(f"  Duration: {duration_seconds}s")
        print(f"  Processed: {processed_count} items")
        print(f"  Target throughput: {target_throughput} items/sec")
        print(f"  Actual throughput: {actual_throughput:.1f} items/sec")
        print(f"  Peak memory: {metrics['peak_memory_mb']:.1f}MB")

    @pytest.mark.stress
    @pytest.mark.asyncio
    async def test_error_recovery_under_load(self, performance_monitor):
        """Test error recovery while maintaining performance."""
        error_rate = 0.1  # 10% error rate
        total_items = 1000
        
        config = AdapterConfig(
            adapter_id="error_recovery_test",
            source_type="test",
            max_retries=3,
            retry_delay_seconds=0.01
        )
        
        # Mock adapter with intermittent errors
        adapter = AsyncMock()
        adapter.config = config
        
        async def error_prone_fetch():
            for i in range(total_items):
                yield {"id": f"item_{i}", "should_error": i % int(1/error_rate) == 0}
        
        adapter.fetch_items.return_value = error_prone_fetch()
        
        def error_prone_transform(raw):
            if raw.get("should_error", False):
                raise Exception(f"Simulated error for {raw['id']}")
            return ContextItem(source_type="test", source_id=raw["id"], title=f"Item {raw['id']}")
        
        adapter.transform_item.side_effect = error_prone_transform
        
        await performance_monitor.start_monitoring()
        
        # Process with error handling
        processed_count = 0
        error_count = 0
        
        async for item in adapter.fetch_items():
            try:
                start_time = time.time()
                result = await adapter.transform_item(item)
                end_time = time.time()
                
                performance_monitor.record_processing_time(end_time - start_time)
                processed_count += 1
            except Exception:
                error_count += 1
                # Continue processing despite errors
        
        await performance_monitor.stop_monitoring()
        
        # Verify error recovery
        metrics = performance_monitor.get_metrics()
        expected_errors = int(total_items * error_rate)
        expected_processed = total_items - expected_errors
        
        assert processed_count >= expected_processed * 0.9  # Allow some variance
        assert error_count <= expected_errors * 1.1
        assert metrics["total_time_seconds"] < 30  # Should complete reasonably fast
        
        print(f"Error Recovery Test:")
        print(f"  Total items: {total_items}")
        print(f"  Processed: {processed_count}")
        print(f"  Errors: {error_count}")
        print(f"  Error rate: {error_count/total_items:.1%}")
        print(f"  Processing time: {metrics['total_time_seconds']:.2f}s")


# Performance test configuration markers
pytestmark = [
    pytest.mark.performance,
]

# Skip performance tests by default (run with -m performance)
pytest.skip_performance = pytest.mark.skipif(
    "performance" not in sys.argv,
    reason="Performance tests are slow and require -m performance flag"
)