"""Comprehensive tests for all 21 project context tools."""

import pytest
import asyncio
from unittest.mock import AsyncMock, Mock, patch, MagicMock
from typing import Dict, Any, List
import json
from datetime import datetime, timedelta

# Import all tools to test
from project_context.tools.analysis import get_complexity, get_call_graph, get_imports, get_documentation
from project_context.tools.discovery import find_files, get_file_info, find_symbols, get_project_summary
from project_context.tools.architecture import get_entry_points, find_agents, get_data_models, get_dependencies, get_api_endpoints
from project_context.tools.quality import get_tests, get_config, get_quality_metrics
from project_context.tools.maintenance import get_todos, validate_intelligence, get_security_issues
from project_context.tools.change import get_recent_changes, search_code, search_files_by_content


class MockAsyncConnection:
    """Mock AsyncPG connection."""
    
    def __init__(self, return_data=None):
        self.return_data = return_data or []
    
    async def fetch(self, query, *params):
        """Mock fetch method."""
        return self.return_data
    
    async def fetchrow(self, query, *params):
        """Mock fetchrow method."""
        return self.return_data[0] if self.return_data else None


class MockNeo4jSession:
    """Mock Neo4j session."""
    
    def __init__(self, return_data=None):
        self.return_data = return_data or []
    
    async def run(self, query, **params):
        """Mock run method."""
        result = Mock()
        result.data = Mock(return_value=self.return_data)
        return result
    
    async def close(self):
        """Mock close method."""
        pass


class MockRedisClient:
    """Mock Redis client."""
    
    def __init__(self):
        self.data = {}
    
    async def get(self, key):
        """Mock get method."""
        return self.data.get(key)
    
    async def set(self, key, value, ex=None):
        """Mock set method."""
        self.data[key] = value
    
    async def ping(self):
        """Mock ping method."""
        return b'PONG'


@pytest.fixture
def mock_db():
    """Fixture for mocked database connection."""
    return MockAsyncConnection()


@pytest.fixture
def mock_neo4j_session():
    """Fixture for mocked Neo4j session."""
    return MockNeo4jSession()


@pytest.fixture
def mock_redis():
    """Fixture for mocked Redis client."""
    return MockRedisClient()


# ==================== ANALYSIS TOOLS TESTS ====================

class TestAnalysisTools:
    """Test analysis tools."""

    @pytest.mark.asyncio
    async def test_get_complexity_basic(self, mock_db):
        """Test basic complexity analysis."""
        mock_db.return_data = [
            {'file_path': 'test.py', 'element_name': 'func1', 'complexity': 5.5},
            {'file_path': 'test.py', 'element_name': 'func2', 'complexity': 12.0},
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_complexity()
            
        assert isinstance(result, dict)
        assert 'statistics' in result
        assert 'hotspots' in result
        assert 'distribution' in result

    @pytest.mark.asyncio
    async def test_get_complexity_with_filters(self, mock_db):
        """Test complexity analysis with filters."""
        mock_db.return_data = [
            {'file_path': 'src/main.py', 'element_name': 'main', 'complexity': 8.0}
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_complexity(
                file_path='src/main.py',
                element_type='function',
                language='python',
                threshold=5.0
            )
            
        assert isinstance(result, dict)
        assert result['hotspots']  # Should include items above threshold

    @pytest.mark.asyncio
    async def test_get_complexity_error_handling(self):
        """Test complexity analysis error handling."""
        with patch('project_context.tools.analysis.get_db', side_effect=Exception('DB Error')):
            result = await get_complexity()
            
        assert 'error' in result
        assert 'DB Error' in result['error']

    @pytest.mark.asyncio
    async def test_get_call_graph_basic(self, mock_db):
        """Test basic call graph generation."""
        mock_db.return_data = [
            {'caller': 'main', 'callee': 'process_data', 'file_path': 'app.py'},
            {'caller': 'process_data', 'callee': 'validate', 'file_path': 'app.py'},
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_call_graph()
            
        assert isinstance(result, dict)
        assert 'nodes' in result
        assert 'edges' in result
        assert 'statistics' in result

    @pytest.mark.asyncio
    async def test_get_call_graph_no_networkx(self, mock_db):
        """Test call graph without NetworkX."""
        mock_db.return_data = []
        
        with patch('project_context.tools.analysis.HAS_NETWORKX', False), \
             patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_call_graph()
            
        assert isinstance(result, dict)
        # Should still work without advanced graph analysis

    @pytest.mark.asyncio
    async def test_get_imports_basic(self, mock_db):
        """Test import analysis."""
        mock_db.return_data = [
            {'file_path': 'main.py', 'import_statement': 'import json', 'module': 'json'},
            {'file_path': 'utils.py', 'import_statement': 'from main import func', 'module': 'main'},
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_imports()
            
        assert isinstance(result, dict)
        assert 'imports_by_file' in result
        assert 'imports_by_module' in result
        assert 'circular_dependencies' in result

    @pytest.mark.asyncio
    async def test_get_documentation_basic(self, mock_db):
        """Test documentation coverage analysis."""
        mock_db.return_data = [
            {
                'file_path': 'main.py',
                'element_name': 'MyClass',
                'element_type': 'class',
                'docstring': 'A test class.',
                'is_public': True
            },
            {
                'file_path': 'main.py',
                'element_name': 'func_no_doc',
                'element_type': 'function',
                'docstring': None,
                'is_public': True
            }
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_documentation()
            
        assert isinstance(result, dict)
        assert 'summary' in result
        assert 'undocumented_public_apis' in result
        assert 'coverage_by_file' in result


# ==================== DISCOVERY TOOLS TESTS ====================

class TestDiscoveryTools:
    """Test discovery tools."""

    @pytest.mark.asyncio
    async def test_find_files_basic(self, mock_db):
        """Test basic file finding."""
        mock_db.return_data = [
            {
                'file_path': 'src/main.py',
                'file_size': 1024,
                'modified_time': datetime.now(),
                'element_count': 5
            }
        ]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await find_files('*.py')
            
        assert isinstance(result, dict)
        assert 'files' in result
        assert 'statistics' in result

    @pytest.mark.asyncio
    async def test_find_files_with_filters(self, mock_db):
        """Test file finding with filters."""
        mock_db.return_data = []
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await find_files(
                pattern='**/*.py',
                file_type='py',
                element_type='function',
                language='python',
                limit=50
            )
            
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_file_info_basic(self, mock_db):
        """Test file info retrieval."""
        mock_db.return_data = [
            {
                'file_path': 'src/main.py',
                'file_size': 2048,
                'modified_time': datetime.now(),
                'element_count': 10,
                'avg_complexity': 6.5
            }
        ]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await get_file_info('src/main.py')
            
        assert isinstance(result, dict)
        assert 'file_metadata' in result
        assert 'code_elements' in result

    @pytest.mark.asyncio
    async def test_find_symbols_basic(self, mock_db):
        """Test symbol search."""
        mock_db.return_data = [
            {
                'element_name': 'MyFunction',
                'element_type': 'function',
                'file_path': 'utils.py',
                'line_number': 42,
                'signature': 'def MyFunction(x, y):'
            }
        ]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await find_symbols('MyFunction')
            
        assert isinstance(result, dict)
        assert 'symbols' in result
        assert 'statistics' in result

    @pytest.mark.asyncio
    async def test_get_project_summary_basic(self, mock_db):
        """Test project summary generation."""
        mock_db.return_data = [
            {
                'total_files': 150,
                'total_sessions': 25,
                'total_elements': 500,
                'avg_complexity': 7.2,
                'languages': '["Python", "JavaScript"]'
            }
        ]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await get_project_summary()
            
        assert isinstance(result, dict)
        assert 'overview' in result
        assert 'statistics' in result


# ==================== ARCHITECTURE TOOLS TESTS ====================

class TestArchitectureTools:
    """Test architecture analysis tools."""

    @pytest.mark.asyncio
    async def test_get_entry_points_basic(self, mock_db):
        """Test entry point detection."""
        mock_db.return_data = [
            {
                'file_path': 'main.py',
                'element_name': 'main',
                'element_type': 'function',
                'line_number': 10,
                'content': 'if __name__ == "__main__":'
            }
        ]
        
        with patch('project_context.tools.architecture.get_db', return_value=mock_db):
            result = await get_entry_points()
            
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_find_agents_basic(self, mock_db):
        """Test agent discovery."""
        mock_db.return_data = [
            {
                'agent_type': 'DataProcessor',
                'session_id': 'sess_001',
                'created_at': datetime.now(),
                'performance_score': 0.85
            }
        ]
        
        with patch('project_context.tools.architecture.get_db', return_value=mock_db):
            result = await find_agents()
            
        assert isinstance(result, dict)
        assert 'agents' in result
        assert 'performance_metrics' in result

    @pytest.mark.asyncio
    async def test_get_data_models_basic(self, mock_db):
        """Test data model discovery."""
        mock_db.return_data = [
            {
                'element_name': 'UserModel',
                'element_type': 'class',
                'file_path': 'models.py',
                'line_number': 15,
                'base_classes': ['BaseModel'],
                'content': 'class UserModel(BaseModel):'
            }
        ]
        
        with patch('project_context.tools.architecture.get_db', return_value=mock_db):
            result = await get_data_models()
            
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_dependencies_basic(self, mock_db, mock_neo4j_session):
        """Test dependency analysis."""
        mock_db.return_data = [
            {'source': 'main.py', 'target': 'utils.py', 'import_type': 'module'}
        ]
        mock_neo4j_session.return_data = [
            {'source': {'name': 'main.py'}, 'target': {'name': 'utils.py'}}
        ]
        
        with patch('project_context.tools.architecture.get_db', return_value=mock_db), \
             patch('project_context.tools.architecture.get_neo4j_session', return_value=mock_neo4j_session):
            result = await get_dependencies()
            
        assert isinstance(result, dict)
        assert 'nodes' in result
        assert 'edges' in result

    @pytest.mark.asyncio
    async def test_get_api_endpoints_basic(self, mock_db):
        """Test API endpoint discovery."""
        mock_db.return_data = [
            {
                'file_path': 'api.py',
                'element_name': 'get_users',
                'line_number': 25,
                'content': '@app.get("/users")',
                'decorators': '["@app.get(\"/users\")"]'
            }
        ]
        
        with patch('project_context.tools.architecture.get_db', return_value=mock_db):
            result = await get_api_endpoints()
            
        assert isinstance(result, list)


# ==================== QUALITY TOOLS TESTS ====================

class TestQualityTools:
    """Test code quality analysis tools."""

    @pytest.mark.asyncio
    async def test_get_tests_basic(self, mock_db):
        """Test test discovery."""
        mock_db.return_data = [
            {
                'file_path': 'tests/test_main.py',
                'element_count': 5,
                'test_functions': 3
            }
        ]
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            result = await get_tests()
            
        assert isinstance(result, dict)
        assert 'test_files' in result
        assert 'source_mappings' in result

    @pytest.mark.asyncio
    async def test_get_config_basic(self, mock_db):
        """Test configuration discovery."""
        mock_db.return_data = [
            {
                'file_path': '.env',
                'content': 'DATABASE_URL=postgresql://localhost'
            },
            {
                'file_path': 'pyproject.toml',
                'content': '[tool.pytest]'
            }
        ]
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            result = await get_config()
            
        assert isinstance(result, dict)
        assert 'files' in result

    @pytest.mark.asyncio
    async def test_get_quality_metrics_basic(self, mock_db):
        """Test quality metrics calculation."""
        mock_db.return_data = [
            {
                'avg_complexity': 6.5,
                'max_complexity': 15.0,
                'min_complexity': 1.0,
                'total_files': 100,
                'documented_elements': 75,
                'total_elements': 100
            }
        ]
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            result = await get_quality_metrics()
            
        assert isinstance(result, dict)
        assert 'complexity_metrics' in result
        assert 'health_score' in result


# ==================== MAINTENANCE TOOLS TESTS ====================

class TestMaintenanceTools:
    """Test maintenance and health check tools."""

    @pytest.mark.asyncio
    async def test_get_todos_basic(self, mock_db):
        """Test TODO detection."""
        mock_db.return_data = [
            {
                'file_path': 'main.py',
                'line_number': 42,
                'content': '# TODO: Implement error handling',
                'todo_type': 'TODO',
                'priority': 'high'
            }
        ]
        
        with patch('project_context.tools.maintenance.get_db', return_value=mock_db):
            result = await get_todos()
            
        assert isinstance(result, dict)
        assert 'todos' in result
        assert 'stats' in result

    @pytest.mark.asyncio
    async def test_validate_intelligence_basic(self, mock_db, mock_neo4j_session, mock_redis):
        """Test system validation."""
        mock_db.return_data = [{'count': 100}]
        mock_neo4j_session.return_data = [{'count': 50}]
        
        with patch('project_context.tools.maintenance.get_db', return_value=mock_db), \
             patch('project_context.tools.maintenance.get_neo4j_session', return_value=mock_neo4j_session), \
             patch('project_context.tools.maintenance.get_redis', return_value=mock_redis):
            result = await validate_intelligence()
            
        assert isinstance(result, dict)
        assert 'connection_status' in result
        assert 'health_score' in result

    @pytest.mark.asyncio
    async def test_get_security_issues_basic(self, mock_db):
        """Test security issue detection."""
        mock_db.return_data = [
            {
                'file_path': 'config.py',
                'line_number': 15,
                'content': 'PASSWORD = "hardcoded123"',
                'issue_type': 'hardcoded_secret'
            }
        ]
        
        with patch('project_context.tools.maintenance.get_db', return_value=mock_db):
            result = await get_security_issues()
            
        assert isinstance(result, dict)
        assert 'hardcoded_secrets' in result
        assert 'summary' in result


# ==================== CHANGE TOOLS TESTS ====================

class TestChangeTools:
    """Test change tracking and search tools."""

    @pytest.mark.asyncio
    async def test_get_recent_changes_basic(self, mock_db):
        """Test recent changes retrieval."""
        mock_db.return_data = [
            {
                'session_id': 'sess_001',
                'file_path': 'main.py',
                'action': 'modify',
                'timestamp': datetime.now(),
                'change_type': 'code_update'
            }
        ]
        
        with patch('project_context.tools.change.get_db', return_value=mock_db):
            result = await get_recent_changes()
            
        assert isinstance(result, dict)
        assert 'changes' in result
        assert 'statistics' in result

    @pytest.mark.asyncio
    async def test_search_code_basic(self, mock_db):
        """Test code search."""
        mock_db.return_data = [
            {
                'file_path': 'utils.py',
                'line_number': 25,
                'content': 'def search_function():',
                'element_type': 'function',
                'context_before': 'class Utils:',
                'context_after': '    return results'
            }
        ]
        
        with patch('project_context.tools.change.get_db', return_value=mock_db):
            result = await search_code('search_function')
            
        assert isinstance(result, dict)
        assert 'results' in result
        assert 'statistics' in result

    @pytest.mark.asyncio
    async def test_search_files_by_content_basic(self, mock_db):
        """Test file content search."""
        mock_db.return_data = [
            {
                'file_path': 'README.md',
                'file_size': 2048,
                'modified_time': datetime.now(),
                'content_snippet': 'This is a test project...'
            }
        ]
        
        with patch('project_context.tools.change.get_db', return_value=mock_db):
            result = await search_files_by_content('test project')
            
        assert isinstance(result, dict)
        assert 'files' in result
        assert 'statistics' in result


# ==================== ERROR HANDLING TESTS ====================

class TestErrorHandling:
    """Test error handling across all tools."""

    @pytest.mark.asyncio
    async def test_database_connection_error(self):
        """Test handling of database connection errors."""
        with patch('project_context.tools.analysis.get_db', side_effect=Exception('Connection failed')):
            result = await get_complexity()
            assert 'error' in result

    @pytest.mark.asyncio
    async def test_invalid_parameters(self, mock_db):
        """Test handling of invalid parameters."""
        mock_db.return_data = []
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            # Test with invalid limit
            result = await find_files('*', limit=-1)
            assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_empty_results(self, mock_db):
        """Test handling of empty query results."""
        mock_db.return_data = []
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            result = await get_tests()
            assert isinstance(result, dict)
            assert result['test_files'] == []


# ==================== RESPONSE FORMAT TESTS ====================

class TestResponseFormats:
    """Test that all tools return properly formatted responses."""

    @pytest.mark.asyncio
    async def test_complexity_response_format(self, mock_db):
        """Test complexity tool response format."""
        mock_db.return_data = []
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            result = await get_complexity()
            
        # Verify required keys exist
        required_keys = ['statistics', 'hotspots', 'distribution']
        assert all(key in result for key in required_keys)

    @pytest.mark.asyncio
    async def test_project_summary_response_format(self, mock_db):
        """Test project summary response format."""
        mock_db.return_data = [{'total_files': 0, 'total_sessions': 0}]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            result = await get_project_summary()
            
        # Verify structure
        assert isinstance(result, dict)
        assert 'overview' in result or 'statistics' in result

    @pytest.mark.asyncio
    async def test_validation_response_format(self, mock_db, mock_neo4j_session, mock_redis):
        """Test validation tool response format."""
        mock_db.return_data = []
        mock_neo4j_session.return_data = []
        
        with patch('project_context.tools.maintenance.get_db', return_value=mock_db), \
             patch('project_context.tools.maintenance.get_neo4j_session', return_value=mock_neo4j_session), \
             patch('project_context.tools.maintenance.get_redis', return_value=mock_redis):
            result = await validate_intelligence()
            
        # Verify required structure
        required_keys = ['connection_status', 'health_score']
        assert all(key in result for key in required_keys)
        assert isinstance(result['health_score'], (int, float))
        assert 0 <= result['health_score'] <= 100


# ==================== INTEGRATION TESTS ====================

class TestIntegration:
    """Integration tests combining multiple tools."""

    @pytest.mark.asyncio
    async def test_file_analysis_workflow(self, mock_db):
        """Test workflow combining file discovery and analysis."""
        # Setup mock data for file discovery
        mock_db.return_data = [
            {'file_path': 'test.py', 'element_count': 5}
        ]
        
        with patch('project_context.tools.discovery.get_db', return_value=mock_db):
            files_result = await find_files('*.py')
            
        assert isinstance(files_result, dict)
        
        # Setup mock data for complexity analysis
        mock_db.return_data = [
            {'file_path': 'test.py', 'complexity': 8.0}
        ]
        
        with patch('project_context.tools.analysis.get_db', return_value=mock_db):
            complexity_result = await get_complexity('test.py')
            
        assert isinstance(complexity_result, dict)

    @pytest.mark.asyncio
    async def test_quality_assessment_workflow(self, mock_db):
        """Test quality assessment combining multiple tools."""
        # Test configuration discovery
        mock_db.return_data = [
            {'file_path': 'pyproject.toml', 'content': '[tool.pytest]'}
        ]
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            config_result = await get_config()
            
        # Test quality metrics
        mock_db.return_data = [
            {'avg_complexity': 6.0, 'total_files': 50}
        ]
        
        with patch('project_context.tools.quality.get_db', return_value=mock_db):
            metrics_result = await get_quality_metrics()
            
        assert isinstance(config_result, dict)
        assert isinstance(metrics_result, dict)


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--cov=project_context.tools'])