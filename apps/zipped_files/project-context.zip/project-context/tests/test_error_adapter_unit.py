"""Comprehensive unit tests for ErrorAdapter."""

import asyncio
import pytest
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List
from unittest.mock import Mock, AsyncMock, patch, mock_open

from src.project_context.ingestion.adapters.error_adapter import ErrorAdapter
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


@pytest.fixture
def error_config():
    """Create test configuration for ErrorAdapter."""
    return AdapterConfig(
        adapter_id="test_error",
        source_type="error",
        batch_mode=BatchMode.STREAMING,
        batch_size=50,
        generate_embeddings=False,
        source_config={
            "input_sources": ["logs", "ide", "test", "monitor"],
            "log_file_patterns": ["*.log", "error*.log", "*.err"],
            "log_directories": ["./logs", "./log"],
            "ide_diagnostic_formats": ["lsp", "eslint", "pylint"],
            "severity_filters": ["error", "warning"],
            "stack_trace_parsing": True,
            "extract_file_locations": True,
            "group_similar_errors": True,
            "similarity_threshold": 0.8,
            "max_error_age_days": 30,
            "exclude_patterns": [
                r".*DEBUG.*",
                r".*INFO.*",
                r".*connection.*timeout.*",
            ],
        },
    )


@pytest.fixture
def sample_log_data():
    """Sample log data for testing."""
    return [
        "2024-01-15 10:30:15.123 ERROR Failed to connect to database: Connection timeout",
        "2024-01-15 10:30:16.456 WARN User authentication failed for user@example.com",
        "2024-01-15 10:30:17.789 ERROR NullPointerException in UserService.getUser()",
        "    at com.example.UserService.getUser(UserService.java:45)",
        "    at com.example.Controller.handleRequest(Controller.java:123)",
        "2024-01-15 10:30:18.012 INFO Request processed successfully",
        "2024-01-15 10:30:19.345 DEBUG Debugging information",
        "2024-01-15 10:31:20.678 FATAL System out of memory"
    ]


@pytest.fixture
def sample_error_items():
    """Sample error items for testing."""
    return [
        {
            "error_id": "err_001",
            "source": "logs",
            "severity": "error",
            "message": "Database connection failed",
            "error_type": "ConnectionError",
            "timestamp": datetime(2024, 1, 15, 10, 30, 15, tzinfo=timezone.utc),
            "file_path": "/app/database.py",
            "line_number": 42,
            "function_name": "connect_to_db",
            "stack_trace": "Traceback (most recent call last):\n  File \"/app/database.py\", line 42, in connect_to_db\nConnectionError: Unable to connect",
        },
        {
            "error_id": "err_002", 
            "source": "ide",
            "severity": "warning",
            "message": "Unused variable 'temp'",
            "error_type": "PyLintWarning",
            "rule": "unused-variable",
            "rule_id": "W0612",
            "fix_suggestion": "Remove unused variable",
            "file_path": "/app/service.py",
            "line_number": 15,
        },
        {
            "error_id": "err_003",
            "source": "test", 
            "severity": "error",
            "message": "Test failed: Expected 5, got 3",
            "test_name": "test_calculation",
            "test_file": "test_math.py",
            "test_framework": "pytest",
            "assertion": "assert result == 5",
        }
    ]


@pytest.fixture
def error_adapter(error_config):
    """Create ErrorAdapter instance for testing."""
    return ErrorAdapter(error_config)


class TestErrorAdapter:
    """Unit tests for ErrorAdapter class."""

    @pytest.mark.asyncio
    async def test_initialization(self, error_adapter, error_config):
        """Test ErrorAdapter initialization."""
        assert error_adapter.config == error_config
        assert len(error_adapter._processed_logs) == 0
        assert len(error_adapter._error_groups) == 0

    @pytest.mark.asyncio
    async def test_default_config(self):
        """Test default configuration creation."""
        config = ErrorAdapter.default_config()
        
        assert config.adapter_id == "error"
        assert config.source_type == "error"
        assert config.batch_mode == BatchMode.STREAMING
        assert config.batch_size == 100
        assert "logs" in config.source_config["input_sources"]
        assert config.source_config["stack_trace_parsing"] is True

    @pytest.mark.asyncio
    async def test_initialize_with_valid_dirs(self, error_adapter):
        """Test initialization with valid log directories."""
        with patch('pathlib.Path.exists', return_value=True):
            await error_adapter.initialize()
            # Should complete without errors

    @pytest.mark.asyncio
    async def test_initialize_with_invalid_dirs(self, error_adapter, caplog):
        """Test initialization with invalid log directories."""
        with patch('pathlib.Path.exists', return_value=False):
            await error_adapter.initialize()
            # Should log warnings but not fail
            assert "Log directory does not exist" in caplog.text

    @pytest.mark.asyncio
    async def test_transform_item_basic_error(self, error_adapter, sample_error_items):
        """Test transforming a basic error item."""
        raw_error = sample_error_items[0]
        
        with patch.object(error_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(error_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="error",
                    source_id="err_001",
                    title="Database connection failed",
                    content="Database connection failed"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await error_adapter.transform_item(raw_error)
                
                assert result.source_type == "error"
                assert result.source_id == "err_001"
                assert result.title == "Database connection failed"
                assert result.file_path == "/app/database.py"
                assert result.line_start == 42
                assert result.function_name == "connect_to_db"
                assert result.severity == "high"  # "error" maps to "high"

    @pytest.mark.asyncio
    async def test_transform_item_ide_error(self, error_adapter, sample_error_items):
        """Test transforming an IDE diagnostic error."""
        raw_error = sample_error_items[1]
        
        with patch.object(error_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(error_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="error",
                    source_id="err_002",
                    title="Unused variable 'temp'"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await error_adapter.transform_item(raw_error)
                
                assert result.entity_type == "diagnostic"
                assert result.metrics["rule"] == "unused-variable"
                assert result.metrics["rule_id"] == "W0612"
                assert result.metrics["fix_suggestion"] == "Remove unused variable"
                assert "source_ide" in result.tags

    @pytest.mark.asyncio
    async def test_transform_item_test_error(self, error_adapter, sample_error_items):
        """Test transforming a test failure error."""
        raw_error = sample_error_items[2]
        
        with patch.object(error_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(error_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="error",
                    source_id="err_003",
                    title="Test failed: Expected 5, got 3"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await error_adapter.transform_item(raw_error)
                
                assert result.entity_type == "test_failure"
                assert result.metrics["test_name"] == "test_calculation"
                assert result.metrics["test_file"] == "test_math.py"
                assert result.metrics["test_framework"] == "pytest"
                assert result.metrics["assertion"] == "assert result == 5"

    def test_parse_log_line_standard_format(self, error_adapter):
        """Test parsing standard log line format."""
        line = "2024-01-15 10:30:15.123 ERROR Failed to connect to database"
        
        result = error_adapter._parse_log_line(line)
        
        assert result is not None
        assert result["severity"] == "error"
        assert result["message"] == "Failed to connect to database"
        assert result["timestamp"] is not None

    def test_parse_log_line_syslog_format(self, error_adapter):
        """Test parsing syslog format."""
        line = "Jan 15 10:30:15 server ERROR: Critical system failure"
        
        result = error_adapter._parse_log_line(line)
        
        assert result is not None
        assert result["severity"] == "error"
        assert result["message"] == "Critical system failure"

    def test_parse_log_line_json_format(self, error_adapter):
        """Test parsing JSON log format."""
        line = '{"level": "ERROR", "message": "Service unavailable", "timestamp": "2024-01-15T10:30:15Z"}'
        
        result = error_adapter._parse_log_line(line)
        
        assert result is not None
        assert result["severity"] == "error"
        assert result["message"] == "Service unavailable"

    def test_parse_log_line_simple_format(self, error_adapter):
        """Test parsing simple format."""
        line = "ERROR: Authentication failed for user"
        
        result = error_adapter._parse_log_line(line)
        
        assert result is not None
        assert result["severity"] == "error"
        assert result["message"] == "Authentication failed for user"

    def test_parse_log_line_invalid(self, error_adapter):
        """Test parsing invalid log line."""
        line = "This is not a valid log line"
        
        result = error_adapter._parse_log_line(line)
        
        assert result is None

    def test_is_stack_trace_line(self, error_adapter):
        """Test stack trace line detection."""
        # Java stack trace
        assert error_adapter._is_stack_trace_line("    at com.example.Service.method(Service.java:42)") is True
        
        # Python stack trace
        assert error_adapter._is_stack_trace_line('  File "service.py", line 42, in method') is True
        
        # JavaScript stack trace
        assert error_adapter._is_stack_trace_line("    at Service.method (service.js:42:15)") is True
        
        # Python traceback header
        assert error_adapter._is_stack_trace_line("Traceback (most recent call last):") is True
        
        # Exception chain
        assert error_adapter._is_stack_trace_line("Caused by: java.lang.NullPointerException") is True
        
        # Regular log line
        assert error_adapter._is_stack_trace_line("2024-01-15 10:30:15 INFO Regular log message") is False

    def test_normalize_severity(self, error_adapter):
        """Test severity normalization."""
        assert error_adapter._normalize_severity("ERROR") == "error"
        assert error_adapter._normalize_severity("ERR") == "error"
        assert error_adapter._normalize_severity("FATAL") == "error"
        assert error_adapter._normalize_severity("CRITICAL") == "error"
        
        assert error_adapter._normalize_severity("WARN") == "warning"
        assert error_adapter._normalize_severity("WARNING") == "warning"
        
        assert error_adapter._normalize_severity("INFO") == "info"
        assert error_adapter._normalize_severity("INFORMATION") == "info"
        
        assert error_adapter._normalize_severity("DEBUG") == "debug"
        assert error_adapter._normalize_severity("TRACE") == "debug"
        
        assert error_adapter._normalize_severity("UNKNOWN") == "unknown"

    def test_categorize_error(self, error_adapter):
        """Test error categorization."""
        # Network errors
        network_error = {"message": "connection timeout occurred", "error_type": ""}
        assert error_adapter._categorize_error(network_error) == "network"
        
        # File system errors
        fs_error = {"message": "file not found: /path/to/file", "error_type": ""}
        assert error_adapter._categorize_error(fs_error) == "filesystem"
        
        # Memory errors
        memory_error = {"message": "out of memory error", "error_type": ""}
        assert error_adapter._categorize_error(memory_error) == "memory"
        
        # Syntax errors
        syntax_error = {"message": "syntax error at line 42", "error_type": ""}
        assert error_adapter._categorize_error(syntax_error) == "syntax"
        
        # Type errors
        type_error = {"message": "attribute error: object has no attribute", "error_type": ""}
        assert error_adapter._categorize_error(type_error) == "type"
        
        # Database errors
        db_error = {"message": "database connection failed", "error_type": ""}
        assert error_adapter._categorize_error(db_error) == "database"
        
        # Auth errors
        auth_error = {"message": "unauthorized access attempt", "error_type": ""}
        assert error_adapter._categorize_error(auth_error) == "auth"
        
        # Unknown errors
        unknown_error = {"message": "something went wrong", "error_type": ""}
        assert error_adapter._categorize_error(unknown_error) == "unknown"

    def test_extract_location_from_stack_trace_python(self, error_adapter):
        """Test extracting location from Python stack trace."""
        stack_trace = '''Traceback (most recent call last):
  File "service.py", line 42, in process_request
    return self.handle_request(data)
  File "handler.py", line 15, in handle_request
    raise ValueError("Invalid data")
ValueError: Invalid data'''
        
        location = error_adapter._extract_location_from_stack_trace(stack_trace)
        
        assert location["file_path"] == "service.py"
        assert location["line_number"] == 42
        assert location["function_name"] == "process_request"

    def test_extract_location_from_stack_trace_java(self, error_adapter):
        """Test extracting location from Java stack trace."""
        stack_trace = '''Exception in thread "main" java.lang.NullPointerException
    at com.example.Service.processData(Service.java:123)
    at com.example.Controller.handleRequest(Controller.java:45)
    at com.example.Main.main(Main.java:10)'''
        
        location = error_adapter._extract_location_from_stack_trace(stack_trace)
        
        assert location["class_name"] == "com.example.Service"
        assert location["function_name"] == "processData"
        assert location["file_path"] == "Service.java"
        assert location["line_number"] == 123

    def test_parse_severity_levels(self, error_adapter):
        """Test severity parsing and normalization."""
        assert error_adapter._parse_severity("critical") == "high"
        assert error_adapter._parse_severity("fatal") == "high"
        assert error_adapter._parse_severity("error") == "high"
        assert error_adapter._parse_severity("warning") == "medium"
        assert error_adapter._parse_severity("warn") == "medium"
        assert error_adapter._parse_severity("info") == "low"
        assert error_adapter._parse_severity("debug") == "low"
        assert error_adapter._parse_severity("") == "medium"
        assert error_adapter._parse_severity("unknown") == "medium"

    def test_generate_error_id(self, error_adapter):
        """Test error ID generation."""
        error1 = {
            "message": "Database connection failed",
            "file_path": "/app/db.py",
            "line_number": 42
        }
        
        error2 = {
            "message": "Database connection failed",
            "file_path": "/app/db.py", 
            "line_number": 42
        }
        
        error3 = {
            "message": "Different error message",
            "file_path": "/app/db.py",
            "line_number": 42
        }
        
        id1 = error_adapter._generate_error_id(error1)
        id2 = error_adapter._generate_error_id(error2)
        id3 = error_adapter._generate_error_id(error3)
        
        # Same error should generate same ID
        assert id1 == id2
        # Different error should generate different ID
        assert id1 != id3
        # Should have proper format
        assert id1.startswith("error_")
        assert len(id1) == 12  # "error_" + 6 digits

    @pytest.mark.asyncio
    async def test_parse_log_file_with_stack_traces(self, error_adapter, tmp_path):
        """Test parsing log file with multi-line stack traces."""
        log_content = """2024-01-15 10:30:15 ERROR Exception occurred in request processing
    at com.example.Service.process(Service.java:42)
    at com.example.Controller.handle(Controller.java:123)
2024-01-15 10:30:16 INFO Request completed successfully
2024-01-15 10:30:17 ERROR Another error occurred
    File "handler.py", line 15, in process
        raise ValueError("Invalid input")
ValueError: Invalid input"""
        
        log_file = tmp_path / "test.log"
        log_file.write_text(log_content)
        
        errors = []
        async for error in error_adapter._parse_log_file(log_file):
            errors.append(error)
        
        assert len(errors) == 2
        
        # First error with Java stack trace
        error1 = errors[0]
        assert "Exception occurred in request processing" in error1["message"]
        assert "at com.example.Service.process" in error1["stack_trace"]
        assert error1["severity"] == "error"
        
        # Second error with Python stack trace
        error2 = errors[1]
        assert "Another error occurred" in error2["message"]
        assert "ValueError: Invalid input" in error2["stack_trace"]

    @pytest.mark.asyncio
    async def test_parse_log_file_with_filters(self, error_adapter, tmp_path):
        """Test parsing log file with exclusion filters."""
        log_content = """2024-01-15 10:30:15 ERROR Important error
2024-01-15 10:30:16 DEBUG Debug information should be filtered
2024-01-15 10:30:17 INFO Info message should be filtered
2024-01-15 10:30:18 ERROR connection timeout should be filtered
2024-01-15 10:30:19 WARN Important warning"""
        
        log_file = tmp_path / "test.log"
        log_file.write_text(log_content)
        
        errors = []
        async for error in error_adapter._parse_log_file(log_file):
            errors.append(error)
        
        # Should only get ERROR and WARN messages that don't match exclusion patterns
        assert len(errors) == 2
        assert "Important error" in errors[0]["message"]
        assert "Important warning" in errors[1]["message"]

    @pytest.mark.asyncio
    async def test_detect_relationships_similar_errors(self, error_adapter):
        """Test detection of similar error relationships."""
        error1 = ContextItem(
            source_type="error",
            source_id="err1",
            content="Database connection failed: timeout after 30 seconds",
            metrics={
                "error_type": "ConnectionError",
                "category": "network"
            }
        )
        
        error2 = ContextItem(
            source_type="error", 
            source_id="err2",
            content="Database connection failed: timeout after 30 seconds",
            metrics={
                "error_type": "ConnectionError",
                "category": "network"
            }
        )
        
        context_window = [error2]
        
        relationships = await error_adapter.detect_relationships(error1, context_window)
        
        # Should find similar error relationship
        similar_rels = [r for r in relationships if r[0] == "similar_error"]
        assert len(similar_rels) == 1
        assert similar_rels[0][1] == error2.id
        assert similar_rels[0][2] > 0.8  # High similarity

    @pytest.mark.asyncio
    async def test_detect_relationships_same_file(self, error_adapter):
        """Test detection of same file relationships."""
        error1 = ContextItem(
            source_type="error",
            source_id="err1",
            file_path="/app/service.py",
            metrics={}
        )
        
        error2 = ContextItem(
            source_type="error",
            source_id="err2", 
            file_path="/app/service.py",
            metrics={}
        )
        
        context_window = [error2]
        
        relationships = await error_adapter.detect_relationships(error1, context_window)
        
        # Should find same file relationship
        file_rels = [r for r in relationships if r[0] == "same_file"]
        assert len(file_rels) == 1
        assert file_rels[0][1] == error2.id
        assert file_rels[0][2] == 0.7

    def test_calculate_error_similarity_high(self, error_adapter):
        """Test high error similarity calculation."""
        error1 = ContextItem(
            source_type="error",
            content="database connection timeout error",
            file_path="/app/db.py",
            line_start=42,
            metrics={
                "error_type": "ConnectionError",
                "category": "network"
            }
        )
        
        error2 = ContextItem(
            source_type="error",
            content="database connection timeout error", 
            file_path="/app/db.py",
            line_start=45,
            metrics={
                "error_type": "ConnectionError",
                "category": "network"
            }
        )
        
        similarity = error_adapter._calculate_error_similarity(error1, error2)
        
        assert similarity > 0.8  # Should be high similarity

    def test_calculate_error_similarity_low(self, error_adapter):
        """Test low error similarity calculation."""
        error1 = ContextItem(
            source_type="error",
            content="database connection error",
            file_path="/app/db.py",
            metrics={
                "error_type": "ConnectionError",
                "category": "network"
            }
        )
        
        error2 = ContextItem(
            source_type="error", 
            content="authentication failed for user",
            file_path="/app/auth.py",
            metrics={
                "error_type": "AuthError",
                "category": "auth"
            }
        )
        
        similarity = error_adapter._calculate_error_similarity(error1, error2)
        
        assert similarity < 0.3  # Should be low similarity

    def test_stacks_related(self, error_adapter):
        """Test stack trace relationship detection."""
        stack1 = """at com.example.Service.processRequest(Service.java:42)
at com.example.Controller.handleRequest(Controller.java:123)
at com.example.Main.main(Main.java:10)"""
        
        stack2 = """at com.example.Service.processRequest(Service.java:45)
at com.example.Controller.handleRequest(Controller.java:125)
at com.example.Application.run(Application.java:20)"""
        
        stack3 = """at org.different.Service.method(Service.java:10)
at org.different.Handler.process(Handler.java:5)"""
        
        # Related stacks (share functions)
        assert error_adapter._stacks_related(stack1, stack2) is True
        
        # Unrelated stacks
        assert error_adapter._stacks_related(stack1, stack3) is False

    @pytest.mark.asyncio
    async def test_fetch_from_logs(self, error_adapter, tmp_path):
        """Test fetching errors from log files."""
        # Create test log directory and files
        log_dir = tmp_path / "logs"
        log_dir.mkdir()
        
        log_file1 = log_dir / "app.log"
        log_file1.write_text("2024-01-15 10:30:15 ERROR Database connection failed\n2024-01-15 10:30:16 WARN Slow query detected")
        
        log_file2 = log_dir / "error.log" 
        log_file2.write_text("2024-01-15 10:31:00 ERROR Authentication failed")
        
        # Update config to use test directory
        error_adapter.config.source_config["log_directories"] = [str(log_dir)]
        
        errors = []
        async for error in error_adapter._fetch_from_logs():
            errors.append(error)
        
        assert len(errors) >= 2  # Should find errors from both files
        assert all(error["source"] == "logs" for error in errors)

    @pytest.mark.asyncio
    async def test_cleanup(self, error_adapter):
        """Test adapter cleanup."""
        # Add some state to clean
        error_adapter._processed_logs.add("/test/log1.log")
        error_adapter._processed_logs.add("/test/log2.log") 
        error_adapter._error_groups["group1"] = [{"error": "data"}]
        
        await error_adapter.cleanup()
        
        # Verify cleanup
        assert len(error_adapter._processed_logs) == 0
        assert len(error_adapter._error_groups) == 0


class TestErrorHandlingAndEdgeCases:
    """Tests for error handling and edge cases."""

    @pytest.mark.asyncio
    async def test_transform_item_missing_fields(self, error_adapter):
        """Test transforming error item with missing fields."""
        minimal_error = {
            "message": "Some error occurred"
        }
        
        with patch.object(error_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(error_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="error",
                    source_id="error_123456",  # Generated ID
                    title="Some error occurred"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await error_adapter.transform_item(minimal_error)
                
                assert result.source_type == "error"
                assert result.title == "Some error occurred"
                assert result.severity == "medium"  # Default severity

    @pytest.mark.asyncio
    async def test_parse_log_file_with_encoding_errors(self, error_adapter, tmp_path):
        """Test parsing log file with encoding issues."""
        log_file = tmp_path / "bad_encoding.log"
        
        # Write file with mixed encoding
        with open(log_file, 'wb') as f:
            f.write("2024-01-15 10:30:15 ERROR ".encode('utf-8'))
            f.write(b'\xff\xfe')  # Invalid UTF-8 bytes
            f.write(" message\n".encode('utf-8'))
        
        errors = []
        async for error in error_adapter._parse_log_file(log_file):
            errors.append(error)
        
        # Should handle encoding errors gracefully
        assert len(errors) >= 0  # May or may not parse successfully

    @pytest.mark.asyncio
    async def test_parse_log_file_nonexistent(self, error_adapter):
        """Test parsing nonexistent log file."""
        nonexistent_file = Path("/nonexistent/file.log")
        
        errors = []
        try:
            async for error in error_adapter._parse_log_file(nonexistent_file):
                errors.append(error)
        except FileNotFoundError:
            pass  # Expected
        
        assert len(errors) == 0

    def test_extract_error_title_fallbacks(self, error_adapter):
        """Test error title extraction with various fallbacks."""
        # Test with title
        error_with_title = {"title": "Custom Error Title"}
        assert error_adapter._extract_error_title(error_with_title) == "Custom Error Title"
        
        # Test with summary
        error_with_summary = {"summary": "Error Summary"}
        assert error_adapter._extract_error_title(error_with_summary) == "Error Summary"
        
        # Test with error_type
        error_with_type = {"error_type": "ValidationError"}
        assert error_adapter._extract_error_title(error_with_type) == "ValidationError"
        
        # Test with message
        error_with_message = {"message": "Long error message\nwith multiple lines"}
        title = error_adapter._extract_error_title(error_with_message)
        assert title == "Long error message"
        assert len(title) <= 200
        
        # Test with no useful fields
        empty_error = {}
        assert error_adapter._extract_error_title(empty_error) == "Unknown Error"

    def test_extract_error_content_comprehensive(self, error_adapter):
        """Test comprehensive error content extraction."""
        complex_error = {
            "message": "Primary error message",
            "stack_trace": "Stack trace line 1\nStack trace line 2",
            "context": {
                "user_id": "123",
                "request_id": "abc",
                "environment": "production"
            },
            "source": "ide",
            "rule": "no-unused-vars",
            "fix_suggestion": "Remove unused variable 'temp'"
        }
        
        content = error_adapter._extract_error_content(complex_error)
        
        assert "Primary error message" in content
        assert "Stack trace:" in content
        assert "Stack trace line 1" in content
        assert "Context:" in content
        assert "user_id: 123" in content
        assert "Rule: no-unused-vars" in content
        assert "Suggested fix: Remove unused variable 'temp'" in content

    @pytest.mark.asyncio
    async def test_performance_with_large_logs(self, error_adapter, tmp_path):
        """Test performance with large log files."""
        log_file = tmp_path / "large.log"
        
        # Create log file with many entries
        with open(log_file, 'w') as f:
            for i in range(1000):
                f.write(f"2024-01-15 10:30:{i:02d} ERROR Error message {i}\n")
                if i % 10 == 0:  # Add some stack traces
                    f.write("    at Service.method(Service.java:42)\n")
                    f.write("    at Controller.handle(Controller.java:123)\n")
        
        error_count = 0
        async for error in error_adapter._parse_log_file(log_file):
            error_count += 1
        
        assert error_count == 1000

    def test_timestamp_parsing_formats(self, error_adapter):
        """Test parsing various timestamp formats."""
        formats = [
            "2024-01-15 10:30:15.123",
            "2024-01-15 10:30:15",
            "2024-01-15T10:30:15.123Z",
            "2024-01-15T10:30:15Z",
            "Jan 15 10:30:15"
        ]
        
        for fmt in formats:
            result = error_adapter._parse_timestamp(fmt)
            if result:  # Some formats may not parse
                assert isinstance(result, datetime)


class TestIntegrationScenarios:
    """Integration-style tests for realistic scenarios."""

    @pytest.mark.asyncio
    async def test_full_log_processing_pipeline(self, error_adapter, tmp_path):
        """Test complete log processing pipeline."""
        # Set up test log files
        log_dir = tmp_path / "logs"
        log_dir.mkdir()
        
        app_log = log_dir / "app.log"
        app_log.write_text("""2024-01-15 10:30:15.123 ERROR Database connection failed
    at DatabaseManager.connect(DatabaseManager.java:45)
    at ServiceLayer.initialize(ServiceLayer.java:123)
2024-01-15 10:30:16.456 WARN Slow query detected: SELECT * FROM users
2024-01-15 10:30:17.789 ERROR Authentication failed for user@example.com
2024-01-15 10:30:18.012 INFO User logged in successfully""")
        
        # Update adapter configuration
        error_adapter.config.source_config["log_directories"] = [str(log_dir)]
        
        # Process logs
        raw_errors = []
        async for error in error_adapter._fetch_from_logs():
            raw_errors.append(error)
        
        assert len(raw_errors) >= 2  # At least ERROR and WARN
        
        # Transform errors
        transformed_errors = []
        for raw_error in raw_errors:
            with patch.object(error_adapter.transformer, 'create_base_context_item') as mock_create:
                with patch.object(error_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                    mock_item = ContextItem(
                        source_type="error",
                        source_id=error_adapter._generate_error_id(raw_error),
                        title=error_adapter._extract_error_title(raw_error)
                    )
                    mock_create.return_value = mock_item
                    mock_transform.return_value = mock_item
                    
                    transformed = await error_adapter.transform_item(raw_error)
                    transformed_errors.append(transformed)
        
        assert len(transformed_errors) == len(raw_errors)
        assert all(isinstance(e, ContextItem) for e in transformed_errors)
        
        # Test relationships
        if len(transformed_errors) >= 2:
            relationships = await error_adapter.detect_relationships(
                transformed_errors[0], 
                transformed_errors[1:]
            )
            # May or may not find relationships depending on content


# Integration test markers for different test categories
pytestmark = [
    pytest.mark.unit,
    pytest.mark.error_adapter,
]