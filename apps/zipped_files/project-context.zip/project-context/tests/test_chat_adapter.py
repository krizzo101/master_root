"""Comprehensive tests for chat adapter functionality."""

import asyncio
import json
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any
from unittest.mock import AsyncMock, MagicMock, patch
import pytest

from src.project_context.ingestion.adapters.chat_adapter import ChatAdapter
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


class TestChatAdapter:
    """Test suite for ChatAdapter functionality."""

    @pytest.fixture
    def sample_config(self) -> AdapterConfig:
        """Create a sample configuration for testing."""
        return AdapterConfig(
            adapter_id="test_chat",
            source_type="chat",
            batch_mode=BatchMode.STREAMING,
            batch_size=10,
            generate_embeddings=True,
            extract_relationships=True,
            skip_duplicates=True,
            source_config={
                "input_format": "jsonl",
                "file_patterns": ["*.jsonl"],
                "watch_directories": [],
                "extract_entities": True,
                "entity_extraction_config": {
                    "enable_url_detection": True,
                    "enable_code_detection": True,
                    "enable_mention_detection": True,
                    "enable_issue_detection": True,
                    "enable_tech_keyword_detection": True,
                    "enable_email_detection": True,
                    "enable_file_path_detection": True,
                    "enable_command_detection": True,
                    "enable_timestamp_detection": True,
                    "enable_named_entity_recognition": False,  # Disabled for tests
                    "max_entities_per_type": 50,
                },
                "embedding_config": {
                    "service": "simple",  # Use simple embedding for tests
                    "model": "test-model",
                    "api_key": None,
                    "max_tokens": 1000,
                    "batch_size": 32,
                },
                "checkpoint_directory": tempfile.gettempdir(),
                "max_checkpoint_hashes": 1000,
            }
        )

    @pytest.fixture
    def sample_jsonl_messages(self) -> list[Dict[str, Any]]:
        """Sample JSONL messages for testing."""
        return [
            {
                "id": "msg1",
                "user_id": "alice",
                "content": "Hi there! I'm working on a Python script at /home/user/script.py",
                "timestamp": "2024-01-01T10:00:00Z",
                "conversation_id": "conv1",
                "type": "message"
            },
            {
                "id": "msg2", 
                "user_id": "bob_bot",
                "content": "I can help you with that! What specific issue are you facing?",
                "timestamp": "2024-01-01T10:01:00Z",
                "conversation_id": "conv1",
                "type": "message",
                "is_bot": True
            },
            {
                "id": "msg3",
                "user_id": "alice", 
                "content": "I'm getting an error when running `python script.py`. See issue #123",
                "timestamp": "2024-01-01T10:02:00Z",
                "conversation_id": "conv1",
                "type": "message",
                "parent_id": "msg2"
            },
            {
                "id": "msg4",
                "user_id": "system",
                "content": "User alice mentioned @bob_bot",
                "timestamp": "2024-01-01T10:03:00Z", 
                "conversation_id": "conv1",
                "type": "system"
            }
        ]

    @pytest.fixture
    async def temp_jsonl_file(self, sample_jsonl_messages):
        """Create a temporary JSONL file with sample messages."""
        temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
        try:
            for message in sample_jsonl_messages:
                json.dump(message, temp_file)
                temp_file.write('\n')
            temp_file.close()
            yield Path(temp_file.name)
        finally:
            Path(temp_file.name).unlink(missing_ok=True)

    @pytest.fixture
    async def chat_adapter(self, sample_config):
        """Create a ChatAdapter instance for testing."""
        adapter = ChatAdapter(sample_config)
        await adapter.initialize()
        try:
            yield adapter
        finally:
            await adapter.cleanup()

    async def test_adapter_initialization(self, sample_config):
        """Test adapter initialization."""
        adapter = ChatAdapter(sample_config)
        
        assert adapter.config.adapter_id == "test_chat"
        assert adapter.config.source_type == "chat"
        assert adapter._processed_files == set()
        assert adapter._processed_message_hashes == set()
        
        await adapter.initialize()
        
        # Check checkpoint file setup
        assert adapter._checkpoint_file is not None
        assert adapter._checkpoint_file.parent.exists()
        
        await adapter.cleanup()

    async def test_fetch_from_jsonl_file(self, chat_adapter, temp_jsonl_file, sample_config):
        """Test fetching messages from JSONL file."""
        # Update config to point to test file
        chat_adapter.config.source_config["watch_directories"] = [str(temp_jsonl_file.parent)]
        
        messages = []
        async for message in chat_adapter.fetch_items():
            messages.append(message)
            
        assert len(messages) == 4
        assert messages[0]["id"] == "msg1"
        assert messages[0]["user_id"] == "alice"
        assert "script.py" in messages[0]["content"]

    async def test_transform_item_basic(self, chat_adapter, sample_jsonl_messages):
        """Test basic item transformation."""
        raw_message = sample_jsonl_messages[0]
        
        item = await chat_adapter.transform_item(raw_message)
        
        assert isinstance(item, ContextItem)
        assert item.source_type == "chat"
        assert item.source_id == "msg1"
        assert item.actor_id == "alice"
        assert item.actor_type == "human"
        assert item.content == raw_message["content"]
        assert item.session_id == "conv1"
        assert item.entity_type == "message"
        assert item.content_hash is not None

    async def test_transform_item_with_embeddings(self, chat_adapter, sample_jsonl_messages):
        """Test item transformation with embedding generation."""
        raw_message = sample_jsonl_messages[0]
        
        item = await chat_adapter.transform_item(raw_message)
        
        # Should have embedding generated
        assert item.embedding is not None
        assert len(item.embedding) > 0  # Simple embedding should produce some values
        assert item.metrics["embedding_dimensions"] == len(item.embedding)

    async def test_entity_extraction_urls(self, chat_adapter):
        """Test URL entity extraction."""
        content = "Check out https://github.com/user/repo and www.example.com for more info"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "urls" in entities
        assert len(entities["urls"]) == 2
        assert "https://github.com/user/repo" in entities["urls"]
        assert "www.example.com" in entities["urls"]

    async def test_entity_extraction_file_paths(self, chat_adapter):
        """Test file path entity extraction."""
        content = "The script is located at /home/user/script.py and also ./relative/path.txt"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "file_paths" in entities
        assert "/home/user/script.py" in entities["file_paths"]
        assert "./relative/path.txt" in entities["file_paths"]

    async def test_entity_extraction_code_references(self, chat_adapter):
        """Test code reference entity extraction."""
        content = "Call the function getData() or check the MyClass definition"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "code_references" in entities
        assert "getData()" in entities["code_references"]

    async def test_entity_extraction_mentions(self, chat_adapter):
        """Test mention entity extraction."""
        content = "Hey @alice, can you help @bob with this?"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "mentions" in entities
        assert "@alice" in entities["mentions"]
        assert "@bob" in entities["mentions"]

    async def test_entity_extraction_issues(self, chat_adapter):
        """Test issue/ticket entity extraction."""
        content = "This relates to #123, PROJ-456, and bug 789"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "issues" in entities
        assert "#123" in entities["issues"]
        assert "PROJ-456" in entities["issues"]
        assert "bug 789" in entities["issues"]

    async def test_entity_extraction_commands(self, chat_adapter):
        """Test command entity extraction."""
        content = "Run `npm install` or use sudo apt-get update"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "commands" in entities
        commands = entities["commands"]
        assert any("`npm install`" in cmd for cmd in commands)
        assert any("sudo apt-get update" in cmd for cmd in commands)

    async def test_entity_extraction_tech_keywords(self, chat_adapter):
        """Test technology keyword extraction."""
        content = "I'm using Python with Docker and deploying to AWS"
        
        entities = await chat_adapter._extract_entities_enhanced(content)
        
        assert "tech_keywords" in entities
        tech_keywords = entities["tech_keywords"]
        assert "python" in tech_keywords
        assert "docker" in tech_keywords
        assert "aws" in tech_keywords

    async def test_actor_type_detection(self, chat_adapter):
        """Test actor type detection."""
        # Human user
        human_msg = {"user_id": "alice", "content": "Hello"}
        assert chat_adapter._determine_actor_type(human_msg) == "human"
        
        # Bot user
        bot_msg = {"user_id": "assistant_bot", "is_bot": True}
        assert chat_adapter._determine_actor_type(bot_msg) == "ai"
        
        # System message
        system_msg = {"user_id": "system", "type": "system"}
        assert chat_adapter._determine_actor_type(system_msg) == "system"

    async def test_relationship_detection_replies(self, chat_adapter):
        """Test reply relationship detection."""
        # Create parent item
        parent_item = ContextItem(
            source_type="chat",
            source_id="msg1", 
            entity_type="message",
            content="Original message",
            timestamp=datetime.utcnow(),
            metrics={}
        )
        parent_item.id = "uuid-1"
        
        # Create reply item
        reply_item = ContextItem(
            source_type="chat",
            source_id="msg2",
            entity_type="message", 
            content="Reply message",
            timestamp=datetime.utcnow(),
            metrics={"parent_message_id": "msg1"}
        )
        reply_item.id = "uuid-2"
        
        relationships = await chat_adapter.detect_relationships(reply_item, [parent_item])
        
        # Should find reply relationship
        reply_rels = [r for r in relationships if r[0] == "replies_to"]
        assert len(reply_rels) == 1
        assert reply_rels[0][1] == parent_item.id
        assert reply_rels[0][2] == 1.0  # High confidence

    async def test_relationship_detection_same_conversation(self, chat_adapter):
        """Test same conversation relationship detection."""
        item1 = ContextItem(
            source_type="chat",
            source_id="msg1",
            entity_type="message",
            content="Message 1",
            timestamp=datetime.utcnow(),
            session_id="conv1"
        )
        item1.id = "uuid-1"
        
        item2 = ContextItem(
            source_type="chat", 
            source_id="msg2",
            entity_type="message",
            content="Message 2", 
            timestamp=datetime.utcnow(),
            session_id="conv1"
        )
        item2.id = "uuid-2"
        
        relationships = await chat_adapter.detect_relationships(item1, [item2])
        
        # Should find same conversation relationship
        conv_rels = [r for r in relationships if r[0] == "same_conversation"]
        assert len(conv_rels) == 1
        assert conv_rels[0][1] == item2.id

    async def test_deduplication(self, chat_adapter, sample_jsonl_messages):
        """Test message deduplication."""
        raw_message = sample_jsonl_messages[0]
        
        # Transform same message twice
        item1 = await chat_adapter.transform_item(raw_message)
        item2 = await chat_adapter.transform_item(raw_message)
        
        # First should succeed, second should be None (deduplicated)
        assert item1 is not None
        assert item2 is None

    async def test_checkpoint_save_and_load(self, chat_adapter, sample_jsonl_messages):
        """Test checkpoint saving and loading for incremental processing."""
        # Process a message to add hash
        raw_message = sample_jsonl_messages[0]
        await chat_adapter.transform_item(raw_message)
        
        # Save checkpoint
        await chat_adapter._save_processed_hashes()
        
        # Create new adapter instance and load
        new_adapter = ChatAdapter(chat_adapter.config)
        await new_adapter.initialize()
        
        # Should have loaded the hash
        assert len(new_adapter._processed_message_hashes) > 0
        
        await new_adapter.cleanup()

    async def test_embedding_generation_simple(self, chat_adapter):
        """Test simple embedding generation."""
        text = "This is a test message for embedding"
        
        embedding = await chat_adapter.generate_embedding(text)
        
        assert embedding is not None
        assert len(embedding) > 0
        assert all(isinstance(x, float) for x in embedding)

    @patch('sentence_transformers.SentenceTransformer')
    async def test_embedding_generation_sentence_transformers(self, mock_st, sample_config):
        """Test sentence transformers embedding generation."""
        # Setup mock
        mock_model = MagicMock()
        mock_model.encode.return_value = [0.1, 0.2, 0.3]
        mock_st.return_value = mock_model
        
        # Change config to use sentence transformers
        sample_config.source_config["embedding_config"]["service"] = "sentence_transformers"
        
        adapter = ChatAdapter(sample_config)
        await adapter.initialize()
        
        try:
            embedding = await adapter.generate_embedding("test text")
            
            assert embedding == [0.1, 0.2, 0.3]
            mock_model.encode.assert_called_once_with("test text", convert_to_tensor=False)
        finally:
            await adapter.cleanup()

    async def test_timestamp_filtering(self, chat_adapter, sample_jsonl_messages):
        """Test timestamp-based filtering of messages."""
        raw_message = sample_jsonl_messages[0]
        
        # Parse timestamp from message
        msg_time = datetime.fromisoformat(raw_message["timestamp"].replace("Z", "+00:00"))
        
        # Test since filter (should include message)
        since_before = msg_time - timedelta(hours=1)
        parsed_time = chat_adapter._parse_timestamp(raw_message)
        assert parsed_time >= since_before
        
        # Test since filter (should exclude message)
        since_after = msg_time + timedelta(hours=1)
        assert parsed_time < since_after

    async def test_cleanup_resources(self, chat_adapter):
        """Test proper cleanup of adapter resources."""
        # Add some data
        chat_adapter._conversation_contexts["test"] = []
        chat_adapter._last_activity["test"] = datetime.utcnow()
        chat_adapter._processed_files.add("test.jsonl")
        
        await chat_adapter.cleanup()
        
        # Should be cleaned up
        assert len(chat_adapter._conversation_contexts) == 0
        assert len(chat_adapter._last_activity) == 0
        assert len(chat_adapter._processed_files) == 0

    async def test_incremental_file_processing(self, chat_adapter, temp_jsonl_file):
        """Test incremental file processing based on modification time."""
        file_path = temp_jsonl_file
        
        # Test with since date before file modification
        old_date = datetime.fromtimestamp(file_path.stat().st_mtime) - timedelta(days=1)
        should_skip = chat_adapter._should_skip_file_by_timestamp(file_path, old_date)
        assert not should_skip
        
        # Test with since date after file modification
        future_date = datetime.fromtimestamp(file_path.stat().st_mtime) + timedelta(days=1)
        should_skip = chat_adapter._should_skip_file_by_timestamp(file_path, future_date)
        assert should_skip

    async def test_error_handling_invalid_json(self, chat_adapter):
        """Test error handling for invalid JSON in JSONL files."""
        # Create temp file with invalid JSON
        temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
        try:
            temp_file.write('{"valid": "json"}\n')
            temp_file.write('invalid json line\n')
            temp_file.write('{"another": "valid"}\n')
            temp_file.close()
            
            chat_adapter.config.source_config["watch_directories"] = [str(Path(temp_file.name).parent)]
            
            messages = []
            async for message in chat_adapter._read_jsonl_file(Path(temp_file.name), None, None):
                messages.append(message)
                
            # Should get 2 valid messages, invalid line should be skipped
            assert len(messages) == 2
            assert messages[0]["valid"] == "json"
            assert messages[1]["another"] == "valid"
            
        finally:
            Path(temp_file.name).unlink(missing_ok=True)

    def test_default_config(self):
        """Test default configuration generation."""
        config = ChatAdapter.default_config()
        
        assert config.adapter_id == "chat"
        assert config.source_type == "chat" 
        assert config.batch_mode == BatchMode.STREAMING
        assert config.generate_embeddings == True
        assert config.extract_relationships == True
        
        # Check entity extraction config
        entity_config = config.source_config["entity_extraction_config"]
        assert entity_config["enable_url_detection"] == True
        assert entity_config["enable_code_detection"] == True
        assert entity_config["max_entities_per_type"] == 50
        
        # Check embedding config
        embedding_config = config.source_config["embedding_config"]
        assert embedding_config["service"] == "sentence_transformers"
        assert embedding_config["model"] == "all-MiniLM-L6-v2"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])