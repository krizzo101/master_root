"""Comprehensive tests for the enhanced code adapter.

This module provides extensive test coverage for the enhanced code adapter,
including unit tests, integration tests, and performance tests.
"""

import asyncio
import json
import tempfile
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock
from typing import Dict, List, Any

import pytest

from src.project_context.ingestion.adapters.enhanced_code_adapter import EnhancedCodeAdapter
from src.project_context.ingestion.adapters.language_parsers import language_registry
from src.project_context.ingestion.adapters.embedding_generator import EmbeddingGenerator
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


@pytest.fixture
def temp_code_dir():
    """Create a temporary directory with sample code files."""
    temp_dir = Path(tempfile.mkdtemp())
    
    # Create sample Python files
    (temp_dir / "main.py").write_text("""
import asyncio
from typing import List, Optional

class DataProcessor:
    \"\"\"Main data processor class.\"\"\"
    
    def __init__(self, config: dict):
        self.config = config
        self.processed_count = 0
    
    async def process_data(self, data: List[str]) -> Optional[List[str]]:
        \"\"\"Process a list of data items.\"\"\"
        if not data:
            return None
        
        results = []
        for item in data:
            processed_item = await self._process_item(item)
            if processed_item:
                results.append(processed_item)
        
        self.processed_count += len(results)
        return results
    
    async def _process_item(self, item: str) -> Optional[str]:
        \"\"\"Process a single item.\"\"\"
        try:
            # Simulate async processing
            await asyncio.sleep(0.01)
            return item.upper()
        except Exception as e:
            print(f"Error processing item: {e}")
            return None

def main():
    \"\"\"Main entry point.\"\"\"
    processor = DataProcessor({"timeout": 30})
    asyncio.run(processor.process_data(["hello", "world"]))

if __name__ == "__main__":
    main()
""")
    
    (temp_dir / "utils.py").write_text("""
import re
from datetime import datetime
from typing import Union

# Constants
MAX_RETRIES = 3
DEFAULT_TIMEOUT = 30

def validate_input(data: Union[str, int]) -> bool:
    \"\"\"Validate input data.\"\"\"
    if isinstance(data, str):
        return bool(data.strip())
    elif isinstance(data, int):
        return data > 0
    return False

def format_timestamp(timestamp: float) -> str:
    \"\"\"Format timestamp to readable string.\"\"\"
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

class ValidationError(Exception):
    \"\"\"Custom validation error.\"\"\"
    pass

@property
def current_time():
    \"\"\"Get current timestamp.\"\"\"
    return datetime.now()
""")
    
    # Create sample JavaScript file
    (temp_dir / "app.js").write_text("""
const express = require('express');
const { promisify } = require('util');

class ApiServer {
    constructor(port = 3000) {
        this.app = express();
        this.port = port;
        this.setupMiddleware();
        this.setupRoutes();
    }

    setupMiddleware() {
        this.app.use(express.json());
        this.app.use(express.urlencoded({ extended: true }));
    }

    setupRoutes() {
        this.app.get('/health', this.healthCheck.bind(this));
        this.app.post('/api/data', this.processData.bind(this));
    }

    async healthCheck(req, res) {
        res.json({ status: 'ok', timestamp: new Date().toISOString() });
    }

    async processData(req, res) {
        try {
            const { data } = req.body;
            
            if (!data || !Array.isArray(data)) {
                return res.status(400).json({ error: 'Invalid data format' });
            }

            const processedData = await Promise.all(
                data.map(item => this.processItem(item))
            );

            res.json({ 
                success: true, 
                processed: processedData.filter(Boolean),
                count: processedData.length 
            });
        } catch (error) {
            console.error('Processing error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async processItem(item) {
        // Simulate async processing
        return new Promise(resolve => {
            setTimeout(() => {
                resolve(typeof item === 'string' ? item.toUpperCase() : item);
            }, 10);
        });
    }

    start() {
        return new Promise((resolve) => {
            this.server = this.app.listen(this.port, () => {
                console.log(`Server running on port ${this.port}`);
                resolve(this.server);
            });
        });
    }

    stop() {
        if (this.server) {
            this.server.close();
        }
    }
}

// Arrow functions and modern JS patterns
const createApiServer = (config = {}) => {
    const { port = 3000, ...options } = config;
    return new ApiServer(port);
};

const validateData = async (data) => {
    if (!data) throw new Error('Data is required');
    if (!Array.isArray(data)) throw new Error('Data must be an array');
    return data.every(item => typeof item === 'string');
};

// Export patterns
module.exports = { ApiServer, createApiServer, validateData };
""")
    
    # Create subdirectory with more files
    subdir = temp_dir / "lib"
    subdir.mkdir()
    
    (subdir / "database.py").write_text("""
import sqlite3
from contextlib import contextmanager
from typing import Any, Generator

class DatabaseManager:
    \"\"\"Simple database manager.\"\"\"
    
    def __init__(self, db_path: str):
        self.db_path = db_path
    
    @contextmanager
    def get_connection(self) -> Generator[sqlite3.Connection, None, None]:
        \"\"\"Get database connection with context management.\"\"\"
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()
    
    async def execute_query(self, query: str, params: tuple = ()) -> List[Any]:
        \"\"\"Execute a database query.\"\"\"
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return cursor.fetchall()
""")
    
    # Create a test file
    (temp_dir / "test_main.py").write_text("""
import unittest
from unittest.mock import Mock, patch
import asyncio

from main import DataProcessor

class TestDataProcessor(unittest.TestCase):
    \"\"\"Test cases for DataProcessor.\"\"\"
    
    def setUp(self):
        self.processor = DataProcessor({"timeout": 30})
    
    def test_init(self):
        self.assertEqual(self.processor.config["timeout"], 30)
        self.assertEqual(self.processor.processed_count, 0)
    
    async def test_process_data_empty(self):
        result = await self.processor.process_data([])
        self.assertIsNone(result)
    
    async def test_process_data_valid(self):
        data = ["hello", "world"]
        result = await self.processor.process_data(data)
        self.assertEqual(result, ["HELLO", "WORLD"])
        self.assertEqual(self.processor.processed_count, 2)

if __name__ == "__main__":
    unittest.main()
""")
    
    yield temp_dir
    
    # Cleanup
    shutil.rmtree(temp_dir)


@pytest.fixture
def enhanced_adapter_config():
    """Create enhanced adapter configuration."""
    return AdapterConfig(
        adapter_id="test_enhanced_code",
        source_type="code",
        batch_mode=BatchMode.BATCH,
        batch_size=10,
        generate_embeddings=True,
        source_config={
            "scan_directories": ["."],
            "include_patterns": ["*.py", "*.js", "*.ts"],
            "exclude_patterns": ["__pycache__/**", "node_modules/**"],
            "enable_advanced_analysis": True,
            "build_dependency_graph": True,
            "calculate_metrics": True,
            "detect_design_patterns": True,
            "parallel_processing": False,  # Disable for tests
            "enable_file_watching": False,  # Disable for tests
            "enable_incremental_scan": True,
            "use_git_tracking": False,  # Disable for tests
        }
    )


@pytest.fixture
async def enhanced_adapter(enhanced_adapter_config, temp_code_dir):
    """Create enhanced code adapter instance."""
    # Update config to use temp directory
    enhanced_adapter_config.source_config["scan_directories"] = [str(temp_code_dir)]
    
    adapter = EnhancedCodeAdapter(enhanced_adapter_config)
    await adapter.initialize()
    
    yield adapter
    
    await adapter.cleanup()


class TestEnhancedCodeAdapter:
    """Test suite for EnhancedCodeAdapter."""
    
    @pytest.mark.asyncio
    async def test_initialization(self, enhanced_adapter):
        """Test adapter initialization."""
        assert enhanced_adapter.config.adapter_id == "test_enhanced_code"
        assert enhanced_adapter._symbol_index == {}
        assert enhanced_adapter._dependency_graph == {}
        assert not enhanced_adapter._file_watcher_active
    
    @pytest.mark.asyncio
    async def test_fetch_items_basic(self, enhanced_adapter):
        """Test basic item fetching."""
        items = []
        async for item in enhanced_adapter.fetch_items(limit=5):
            items.append(item)
        
        assert len(items) > 0
        assert all(isinstance(item, dict) for item in items)
        assert all("file_path" in item for item in items)
        assert all("content" in item for item in items)
    
    @pytest.mark.asyncio
    async def test_language_detection(self, enhanced_adapter):
        """Test language detection for different file types."""
        # Python file
        py_lang = enhanced_adapter._detect_language("test.py", "def hello(): pass")
        assert py_lang == "python"
        
        # JavaScript file
        js_lang = enhanced_adapter._detect_language("test.js", "function hello() {}")
        assert js_lang == "javascript"
        
        # Unknown file
        unknown_lang = enhanced_adapter._detect_language("test.xyz", "some content")
        assert unknown_lang == "unknown"
    
    @pytest.mark.asyncio
    async def test_transform_item_basic(self, enhanced_adapter):
        """Test basic item transformation."""
        raw_item = {
            "file_path": "/test/sample.py",
            "content": "def hello():\n    return 'world'",
            "encoding": "utf-8",
            "file_stats": {"size": 100, "modified": datetime.now()},
            "title": "sample.py"
        }
        
        context_item = await enhanced_adapter.transform_item(raw_item)
        
        assert isinstance(context_item, ContextItem)
        assert context_item.source_type == "code"
        assert context_item.file_path == "/test/sample.py"
        assert context_item.content == "def hello():\n    return 'world'"
        assert context_item.title == "sample.py"
        assert context_item.metrics is not None
    
    @pytest.mark.asyncio
    async def test_transform_item_with_advanced_analysis(self, enhanced_adapter):
        """Test item transformation with advanced analysis."""
        raw_item = {
            "file_path": "/test/complex.py",
            "content": '''
import asyncio
from typing import List

class TestClass:
    """A test class."""
    
    def __init__(self):
        self.value = 0
    
    async def process(self, items: List[str]) -> List[str]:
        """Process items."""
        results = []
        for item in items:
            if item:
                results.append(item.upper())
        return results
''',
            "encoding": "utf-8",
            "file_stats": {"size": 300, "modified": datetime.now()},
            "title": "complex.py"
        }
        
        context_item = await enhanced_adapter.transform_item(raw_item)
        
        assert context_item.metrics is not None
        assert "detailed_symbols" in context_item.metrics
        
        symbols = context_item.metrics["detailed_symbols"]
        assert symbols["language"] == "python"
        assert len(symbols["functions"]) >= 2  # __init__ and process
        assert len(symbols["classes"]) == 1
        assert len(symbols["imports"]) >= 1
    
    @pytest.mark.asyncio
    async def test_symbol_extraction_python(self, enhanced_adapter):
        """Test Python symbol extraction."""
        code = '''
import os
from typing import List, Optional

class DataProcessor:
    """Main processor class."""
    
    def __init__(self):
        self.count = 0
    
    async def process(self, data: List[str]) -> Optional[List[str]]:
        """Process data."""
        if not data:
            return None
        
        results = []
        for item in data:
            if item.strip():
                results.append(item.upper())
        
        self.count += len(results)
        return results

def helper_function(value: int) -> str:
    """Helper function."""
    return str(value)

# Constants
MAX_SIZE = 1000
DEFAULT_NAME = "default"
'''
        
        symbols = enhanced_adapter.extract_symbols(code, "/test/example.py", "python")
        
        assert symbols["language"] == "python"
        assert len(symbols["functions"]) >= 2  # __init__, process, helper_function
        assert len(symbols["classes"]) == 1
        assert len(symbols["imports"]) >= 2
        assert len(symbols["constants"]) >= 2  # MAX_SIZE, DEFAULT_NAME
    
    @pytest.mark.asyncio
    async def test_symbol_extraction_javascript(self, enhanced_adapter):
        """Test JavaScript symbol extraction."""
        code = '''
const express = require('express');
import { Router } from 'express-router';

class ApiServer {
    constructor(port = 3000) {
        this.port = port;
        this.app = express();
    }
    
    async start() {
        return new Promise(resolve => {
            this.server = this.app.listen(this.port, resolve);
        });
    }
    
    stop() {
        if (this.server) {
            this.server.close();
        }
    }
}

const createServer = (config) => {
    return new ApiServer(config.port);
};

export { ApiServer, createServer };
'''
        
        symbols = enhanced_adapter.extract_symbols(code, "/test/server.js", "javascript")
        
        assert symbols["language"] == "javascript"
        assert len(symbols["functions"]) >= 1  # createServer
        assert len(symbols["classes"]) == 1  # ApiServer
        assert len(symbols["imports"]) >= 1
        assert len(symbols["exports"]) >= 1
    
    @pytest.mark.asyncio
    async def test_complexity_calculation(self, enhanced_adapter):
        """Test complexity calculation."""
        complex_code = '''
def complex_function(data):
    """A complex function."""
    if not data:
        return None
    
    results = []
    for item in data:
        try:
            if isinstance(item, str):
                if len(item) > 10:
                    results.append(item.upper())
                elif len(item) > 5:
                    results.append(item.lower())
                else:
                    results.append(item.title())
            elif isinstance(item, int):
                if item > 100:
                    results.append(str(item * 2))
                else:
                    results.append(str(item))
        except Exception as e:
            print(f"Error: {e}")
            continue
    
    return results if results else None
'''
        
        symbols = enhanced_adapter.extract_symbols(complex_code, "/test/complex.py", "python")
        
        # Should have detected high complexity
        assert len(symbols["functions"]) == 1
        function = symbols["functions"][0]
        assert function["complexity_score"] > 5  # Should be complex
        
        complexity_metrics = symbols.get("complexity_metrics", {})
        assert complexity_metrics.get("total_cyclomatic_complexity", 0) > 5
    
    @pytest.mark.asyncio
    async def test_relationship_detection(self, enhanced_adapter):
        """Test relationship detection between context items."""
        # Create mock context items
        item1 = ContextItem(
            source_type="code",
            source_id="/test/main.py",
            file_path="/test/main.py",
            content="from utils import validate_input\ndef main(): pass",
            metrics={"imports": [{"module": "utils", "name": "validate_input"}]}
        )
        
        item2 = ContextItem(
            source_type="code", 
            source_id="/test/utils.py",
            file_path="/test/utils.py",
            content="def validate_input(data): return bool(data)",
            metrics={"functions": [{"name": "validate_input"}]}
        )
        
        relationships = await enhanced_adapter.detect_relationships(item1, [item2])
        
        # Should detect import relationship
        assert len(relationships) > 0
        relationship_types = [rel[0] for rel in relationships]
        assert any("import" in rel_type for rel_type in relationship_types)
    
    @pytest.mark.asyncio
    async def test_architectural_pattern_detection(self, enhanced_adapter):
        """Test architectural pattern detection."""
        # Singleton pattern
        singleton_code = '''
class DatabaseManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.connection = None
            self.initialized = True
'''
        
        symbols = enhanced_adapter.extract_symbols(singleton_code, "/test/db.py", "python")
        
        # Check if singleton pattern was detected
        detailed_symbols = symbols
        classes = detailed_symbols.get("classes", [])
        assert len(classes) == 1
        
        # The pattern detection should identify this as a potential singleton
        class_info = classes[0]
        methods = class_info.get("methods", [])
        method_names = [m["name"] for m in methods]
        assert "__new__" in method_names
    
    @pytest.mark.asyncio
    async def test_incremental_updates(self, enhanced_adapter, temp_code_dir):
        """Test incremental update functionality."""
        # First scan
        items_first = []
        async for item in enhanced_adapter.fetch_items(limit=10):
            items_first.append(item)
        
        first_count = len(items_first)
        assert first_count > 0
        
        # Add a new file
        new_file = temp_code_dir / "new_module.py"
        new_file.write_text("""
def new_function():
    \"\"\"A new function.\"\"\"
    return "new"
""")
        
        # Wait a bit to ensure different timestamp
        await asyncio.sleep(0.1)
        
        # Incremental scan (since recent time)
        since_time = datetime.now() - timedelta(seconds=1)
        items_incremental = []
        async for item in enhanced_adapter._fetch_incremental_items(since=since_time, limit=10):
            items_incremental.append(item)
        
        # Should find the new file
        new_file_found = any(
            str(new_file) in item.get("file_path", "") 
            for item in items_incremental
        )
        assert new_file_found
    
    @pytest.mark.asyncio
    async def test_quality_metrics_calculation(self, enhanced_adapter):
        """Test quality metrics calculation."""
        code_with_issues = '''
# Poor quality code example
def bad_function(a,b,c,d,e,f,g):  # Too many parameters
    if a:  # No docstring
        if b:
            if c:
                if d:  # Deep nesting
                    if e:
                        if f:
                            return g
                        else:
                            return None
                    else:
                        return None
                else:
                    return None
            else:
                return None
        else:
            return None
    else:
        return None

def another_bad_function():  # No docstring
    x = 1
    y = 2
    z = 3
    # Magic numbers everywhere
    if x == 1:
        return y * 42 + z * 37
    return 0
'''
        
        symbols = enhanced_adapter.extract_symbols(code_with_issues, "/test/bad.py", "python")
        
        # Should detect quality issues
        complexity_metrics = symbols.get("complexity_metrics", {})
        assert complexity_metrics.get("total_cyclomatic_complexity", 0) > 10  # High complexity
        
        functions = symbols.get("functions", [])
        assert len(functions) >= 2
        
        # Check for undocumented functions
        undocumented = [f for f in functions if not f.get("docstring")]
        assert len(undocumented) >= 2  # Both functions lack docstrings


class TestLanguageParsers:
    """Test suite for language-specific parsers."""
    
    def test_python_parser(self):
        """Test Python parser."""
        parser = language_registry.get_parser("python")
        assert parser is not None
        
        code = '''
import os
from typing import List

class TestClass:
    def __init__(self):
        self.value = 0
    
    def method(self, param: str) -> str:
        """A method."""
        return param.upper()

def function():
    pass
'''
        
        result = parser.parse(code, "test.py")
        
        assert result["language"] == "python"
        assert len(result["functions"]) >= 2  # __init__, method, function
        assert len(result["classes"]) == 1
        assert len(result["imports"]) >= 1
    
    def test_javascript_parser(self):
        """Test JavaScript parser."""
        parser = language_registry.get_parser("javascript")
        assert parser is not None
        
        code = '''
const express = require('express');

class Server {
    constructor(port) {
        this.port = port;
    }
    
    start() {
        console.log(`Starting on port ${this.port}`);
    }
}

function createServer(port) {
    return new Server(port);
}

const helper = (data) => {
    return data.map(item => item.toUpperCase());
};

module.exports = { Server, createServer };
'''
        
        result = parser.parse(code, "server.js")
        
        assert result["language"] == "javascript"
        assert len(result["functions"]) >= 1  # createServer
        assert len(result["classes"]) == 1  # Server
        assert len(result["imports"]) >= 1  # require
        assert len(result["arrow_functions"]) >= 1  # helper


class TestEmbeddingGeneration:
    """Test suite for embedding generation."""
    
    @pytest.fixture
    def embedding_generator(self):
        """Create embedding generator for testing."""
        config = {
            "cache_embeddings": False,  # Disable cache for tests
            "model_name": "test_model"
        }
        return EmbeddingGenerator(config)
    
    @pytest.mark.asyncio
    async def test_basic_embedding_generation(self, embedding_generator):
        """Test basic embedding generation."""
        text = "def hello_world(): return 'Hello, World!'"
        
        embedding = await embedding_generator.generate_embedding(text, context="code")
        
        # Should fall back to TF-IDF embedding
        assert embedding is not None
        assert isinstance(embedding, list)
        assert len(embedding) > 0
        assert all(isinstance(x, (int, float)) for x in embedding)
    
    @pytest.mark.asyncio
    async def test_code_embedding_with_symbols(self, embedding_generator):
        """Test code embedding generation with symbol information."""
        code = """
class DataProcessor:
    def __init__(self):
        self.processed = 0
    
    def process(self, data):
        return data.upper()
"""
        
        symbols = {
            "language": "python",
            "functions": [
                {"name": "__init__"}, 
                {"name": "process"}
            ],
            "classes": [
                {"name": "DataProcessor"}
            ],
            "imports": [],
            "complexity_metrics": {
                "cyclomatic_complexity": 3
            }
        }
        
        embedding = await embedding_generator.generate_code_embedding(code, symbols, "processor.py")
        
        assert embedding is not None
        assert isinstance(embedding, list)
        assert len(embedding) > 0
    
    @pytest.mark.asyncio
    async def test_similarity_calculation(self, embedding_generator):
        """Test similarity calculation between embeddings."""
        # Generate embeddings for similar code
        code1 = "def process_data(data): return data.upper()"
        code2 = "def process_info(info): return info.lower()"
        code3 = "class DatabaseConnection: pass"
        
        emb1 = await embedding_generator.generate_embedding(code1)
        emb2 = await embedding_generator.generate_embedding(code2)
        emb3 = await embedding_generator.generate_embedding(code3)
        
        # Similarity between function definitions should be higher
        # than between function and class
        sim_1_2 = embedding_generator.calculate_similarity(emb1, emb2)
        sim_1_3 = embedding_generator.calculate_similarity(emb1, emb3)
        
        assert sim_1_2 > sim_1_3  # Functions should be more similar to each other
    
    @pytest.mark.asyncio
    async def test_batch_embedding_generation(self, embedding_generator):
        """Test batch embedding generation."""
        texts = [
            "def function1(): pass",
            "class Class1: pass", 
            "import os",
            "variable = 42"
        ]
        
        embeddings = await embedding_generator.generate_batch_embeddings(texts)
        
        assert len(embeddings) == len(texts)
        assert all(emb is not None for emb in embeddings)
        assert all(isinstance(emb, list) for emb in embeddings if emb is not None)


class TestIntegration:
    """Integration tests for the complete enhanced code adapter."""
    
    @pytest.mark.asyncio
    async def test_end_to_end_processing(self, enhanced_adapter, temp_code_dir):
        """Test end-to-end processing of code repository."""
        # Process all files
        all_items = []
        async for item in enhanced_adapter.fetch_items():
            all_items.append(item)
        
        assert len(all_items) >= 4  # At least our sample files
        
        # Transform items
        context_items = []
        for raw_item in all_items:
            context_item = await enhanced_adapter.transform_item(raw_item)
            context_items.append(context_item)
        
        # Verify all items were processed correctly
        for item in context_items:
            assert item.source_type == "code"
            assert item.file_path is not None
            assert item.content is not None
            assert item.metrics is not None
            
            # Check for advanced analysis results
            if "detailed_symbols" in item.metrics:
                symbols = item.metrics["detailed_symbols"]
                assert "language" in symbols
                assert symbols["language"] in ["python", "javascript", "unknown"]
    
    @pytest.mark.asyncio
    async def test_repository_statistics(self, enhanced_adapter):
        """Test repository statistics generation."""
        # Let the adapter process some files first
        items = []
        async for item in enhanced_adapter.fetch_items(limit=3):
            items.append(item)
        
        stats = await enhanced_adapter.get_repository_statistics()
        
        assert isinstance(stats, dict)
        assert "files_analyzed" in stats
        assert "total_lines" in stats
        assert "languages" in stats
        assert "last_scan_time" in stats
        
        assert stats["files_analyzed"] >= 0
        assert isinstance(stats["languages"], dict)
    
    @pytest.mark.asyncio
    async def test_comprehensive_report_generation(self, enhanced_adapter):
        """Test comprehensive repository report generation."""
        # Process some files first
        items = []
        async for item in enhanced_adapter.fetch_items(limit=2):
            items.append(item)
        
        report = await enhanced_adapter.get_comprehensive_repository_report()
        
        assert isinstance(report, dict)
        assert "scan_timestamp" in report
        assert "basic_statistics" in report
        assert "quality_metrics" in report
        assert "symbol_index_statistics" in report
        assert "integration_status" in report
        
        # Check integration status
        integration = report["integration_status"]
        assert "git_integration" in integration
        assert "file_watcher" in integration
        assert "incremental_enabled" in integration
    
    @pytest.mark.asyncio
    async def test_error_handling(self, enhanced_adapter, temp_code_dir):
        """Test error handling for invalid files."""
        # Create a file with invalid Python syntax
        invalid_file = temp_code_dir / "invalid.py"
        invalid_file.write_text("def broken_function(\n  # Missing closing parenthesis")
        
        # Create a binary file
        binary_file = temp_code_dir / "binary.bin"
        binary_file.write_bytes(b'\x00\x01\x02\x03\x04\x05')
        
        # Process files - should handle errors gracefully
        items = []
        async for item in enhanced_adapter.fetch_items():
            items.append(item)
        
        # Should have processed valid files and skipped/handled invalid ones
        assert len(items) >= 4  # Our original valid files should still be processed
        
        # Transform items - should handle any that made it through
        for raw_item in items:
            try:
                context_item = await enhanced_adapter.transform_item(raw_item)
                assert isinstance(context_item, ContextItem)
            except Exception as e:
                # Errors should be logged but not crash the process
                assert "error" in str(e).lower() or "invalid" in str(e).lower()


@pytest.mark.performance
class TestPerformance:
    """Performance tests for the enhanced code adapter."""
    
    @pytest.mark.asyncio
    async def test_large_file_processing(self, enhanced_adapter, temp_code_dir):
        """Test processing of larger code files."""
        # Create a larger Python file
        large_content = """
import os
import sys
from typing import List, Dict, Optional, Union

""" + "\n".join([
            f'''
class TestClass{i}:
    """Test class {i}."""
    
    def __init__(self):
        self.value_{i} = {i}
    
    def method_{i}(self, param: str) -> str:
        """Method {i}."""
        if param:
            return f"processed_{i}: {{param}}"
        return f"default_{i}"
    
    async def async_method_{i}(self, data: List[str]) -> List[str]:
        """Async method {i}."""
        results = []
        for item in data:
            if item.strip():
                results.append(f"{{item}}_{{self.value_{i}}}")
        return results

def function_{i}(a: int, b: int = {i}) -> int:
    """Function {i}."""
    try:
        if a > {i}:
            return a * b + {i}
        elif a < -{i}:
            return a - b * {i}
        else:
            return a + b
    except Exception as e:
        print(f"Error in function_{i}: {{e}}")
        return 0
''' for i in range(50)  # 50 classes and functions
        ])
        
        large_file = temp_code_dir / "large_file.py"
        large_file.write_text(large_content)
        
        # Time the processing
        import time
        start_time = time.time()
        
        item = await enhanced_adapter._read_code_file(large_file)
        assert item is not None
        
        context_item = await enhanced_adapter.transform_item(item)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Should complete within reasonable time (adjust threshold as needed)
        assert processing_time < 10.0  # 10 seconds max
        
        # Verify the analysis results
        assert context_item.metrics is not None
        if "detailed_symbols" in context_item.metrics:
            symbols = context_item.metrics["detailed_symbols"]
            assert len(symbols.get("functions", [])) >= 50  # Should find many functions
            assert len(symbols.get("classes", [])) >= 50   # Should find many classes
    
    @pytest.mark.asyncio
    async def test_batch_processing_performance(self, enhanced_adapter_config, temp_code_dir):
        """Test performance of batch processing."""
        # Create multiple files for batch processing
        for i in range(20):
            file_content = f'''
def function_{i}():
    """Function {i}."""
    return {i}

class Class_{i}:
    """Class {i}."""
    def method(self):
        return {i}
'''
            (temp_code_dir / f"batch_file_{i}.py").write_text(file_content)
        
        # Test batch processing
        enhanced_adapter_config.source_config["scan_directories"] = [str(temp_code_dir)]
        enhanced_adapter_config.source_config["parallel_processing"] = True
        enhanced_adapter_config.source_config["max_worker_threads"] = 4
        
        adapter = EnhancedCodeAdapter(enhanced_adapter_config)
        await adapter.initialize()
        
        try:
            import time
            start_time = time.time()
            
            items = []
            async for item in adapter.fetch_items():
                items.append(item)
            
            end_time = time.time()
            processing_time = end_time - start_time
            
            # Should process multiple files efficiently
            assert len(items) >= 20
            assert processing_time < 30.0  # 30 seconds max for batch processing
            
        finally:
            await adapter.cleanup()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])