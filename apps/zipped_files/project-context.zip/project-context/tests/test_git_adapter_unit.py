"""Comprehensive unit tests for GitAdapter."""

import asyncio
import pytest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, Any, List
from unittest.mock import Mock, AsyncMock, patch, MagicMock

from src.project_context.ingestion.adapters.git_adapter import (
    GitAdapter,
    CommitProcessor, 
    GitCheckpointManager,
    CodeChangeAnalyzer,
    GitRepositoryScanner,
    CommitType,
    ProcessingStatus,
    BranchInfo,
    CommitAnalysis,
)
from src.project_context.ingestion.base_adapter import AdapterConfig, BatchMode
from src.project_context.models.common import ContextItem


@pytest.fixture
def git_config():
    """Create test configuration for GitAdapter."""
    return AdapterConfig(
        adapter_id="test_git",
        source_type="git",
        batch_mode=BatchMode.STREAMING,
        batch_size=10,
        generate_embeddings=False,
        source_config={
            "repository_path": "/test/repo",
            "enable_incremental": True,
            "enable_semantic_analysis": True,
            "enable_branch_detection": True,
            "include_commits": True,
            "include_branches": True,
            "include_tags": True,
            "max_commit_age_days": None,
            "exclude_merge_commits": False,
            "include_diff_content": True,
            "max_diff_size_kb": 100,
            "author_filters": [],
            "branch_filters": [],
            "checkpoint_interval": 5,
        }
    )


@pytest.fixture
def sample_commit_data():
    """Sample commit data for testing."""
    return {
        "hash": "abc123def456",
        "author": "Test User",
        "author_email": "test@example.com",
        "committer": "Test User",
        "committer_email": "test@example.com",
        "author_date": "2024-01-15 10:30:00 +0000",
        "commit_date": "2024-01-15 10:30:00 +0000",
        "subject": "feat: Add new feature for testing",
        "body": "This is a test commit that adds a new feature.\n\nBREAKING CHANGE: API updated",
        "branch": "feature/test-branch",
        "changed_files": [
            {"type": "A", "file": "src/new_feature.py"},
            {"type": "M", "file": "src/existing.py"},
            {"type": "D", "file": "old_file.txt"}
        ],
        "parent_commits": ["def456abc789"],
        "diff": "diff --git a/src/new_feature.py b/src/new_feature.py\nnew file mode 100644\n+def new_function():\n+    return 'test'\n"
    }


@pytest.fixture
def database_mock():
    """Mock database connection."""
    mock_db = AsyncMock()
    mock_db.fetchrow.return_value = None
    mock_db.execute.return_value = None
    return mock_db


@pytest.fixture
def git_adapter(git_config, database_mock):
    """Create GitAdapter instance for testing."""
    return GitAdapter(git_config, database_mock)


class TestGitAdapter:
    """Unit tests for GitAdapter class."""

    @pytest.mark.asyncio
    async def test_initialization(self, git_adapter, git_config):
        """Test GitAdapter initialization."""
        assert git_adapter.config == git_config
        assert git_adapter.enable_incremental is True
        assert git_adapter.enable_semantic_analysis is True
        assert git_adapter.enable_branch_detection is True
        assert git_adapter._repo_path == "/test/repo"
        assert git_adapter.checkpoint_interval == 5

    @pytest.mark.asyncio
    async def test_default_config(self):
        """Test default configuration creation."""
        config = GitAdapter.default_config()
        
        assert config.adapter_id == "enhanced_git"
        assert config.source_type == "git"
        assert config.batch_mode == BatchMode.BATCH
        assert config.batch_size == 500
        assert config.source_config["enable_incremental"] is True
        assert config.source_config["enable_semantic_analysis"] is True

    @pytest.mark.asyncio 
    async def test_is_git_repo_valid(self, git_adapter):
        """Test _is_git_repo method with valid repository."""
        with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.return_value = "/test/repo/.git"
            
            result = await git_adapter._is_git_repo()
            
            assert result is True
            mock_git.assert_called_once_with(["rev-parse", "--git-dir"])

    @pytest.mark.asyncio
    async def test_is_git_repo_invalid(self, git_adapter):
        """Test _is_git_repo method with invalid repository."""
        with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.side_effect = Exception("Not a git repository")
            
            result = await git_adapter._is_git_repo()
            
            assert result is False

    @pytest.mark.asyncio
    async def test_initialize_success(self, git_adapter):
        """Test successful adapter initialization."""
        with patch.object(git_adapter, '_is_git_repo', new_callable=AsyncMock) as mock_is_git:
            with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
                with patch.object(git_adapter.repo_scanner, 'scan_branches', new_callable=AsyncMock) as mock_scan:
                    mock_is_git.return_value = True
                    mock_git.return_value = "git version 2.34.1"
                    mock_scan.return_value = {"main": BranchInfo(
                        name="main", head_commit="abc123", base_branch=None,
                        branch_type="main", creation_date=datetime.utcnow(),
                        last_activity=datetime.utcnow(), commit_count=0,
                        is_merged=False, merge_commit=None
                    )}
                    
                    await git_adapter.initialize()
                    
                    mock_is_git.assert_called_once()
                    mock_git.assert_called_once_with(["--version"])
                    mock_scan.assert_called_once()

    @pytest.mark.asyncio
    async def test_initialize_not_git_repo(self, git_adapter):
        """Test initialization failure when not a git repository."""
        with patch.object(git_adapter, '_is_git_repo', new_callable=AsyncMock) as mock_is_git:
            mock_is_git.return_value = False
            
            with pytest.raises(ValueError, match="Not a git repository"):
                await git_adapter.initialize()

    @pytest.mark.asyncio
    async def test_transform_commit_basic(self, git_adapter, sample_commit_data):
        """Test basic commit transformation."""
        with patch.object(git_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(git_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="git",
                    source_id="abc123def456",
                    title="feat: Add new feature for testing",
                    content="Test content"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await git_adapter._transform_commit_enhanced(sample_commit_data)
                
                assert result.source_type == "git"
                assert result.source_id == "abc123def456"
                assert result.title == "feat: Add new feature for testing"
                assert result.actor_id == "Test User"
                assert result.entity_type == "commit"

    @pytest.mark.asyncio
    async def test_transform_commit_with_analysis(self, git_adapter, sample_commit_data):
        """Test commit transformation with analysis data."""
        # Add analysis data to sample
        sample_commit_data['analysis'] = {
            'commit_type': 'feature',
            'impact_score': 0.8,
            'risk_score': 0.3,
            'complexity_delta': 2.5,
            'semantic_tags': ['breaking_change', 'language_py'],
            'patterns': ['single_file_change'],
            'author_patterns': {'author': 'Test User', 'commit_time_hour': 10}
        }
        
        with patch.object(git_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(git_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="git",
                    source_id="abc123def456",
                    title="feat: Add new feature for testing"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                result = await git_adapter._transform_commit_enhanced(sample_commit_data)
                
                # Check analysis data was included in metrics
                assert result.metrics['commit_type'] == 'feature'
                assert result.metrics['impact_score'] == 0.8
                assert result.metrics['risk_score'] == 0.3
                assert result.metrics['complexity_delta'] == 2.5
                assert 'breaking_change' in result.metrics['semantic_tags']
                assert 'high_impact' in result.tags  # Should be added for impact_score > 0.7

    @pytest.mark.asyncio
    async def test_parse_git_log_output(self, git_adapter):
        """Test parsing of git log output."""
        git_log_output = """commit abc123def456
Author:     Test User <test@example.com>
AuthorDate: Mon Jan 15 10:30:00 2024 +0000
Commit:     Test User <test@example.com>
CommitDate: Mon Jan 15 10:30:00 2024 +0000

    feat: Add new feature for testing
    
    This is a test commit body.

A	src/new_feature.py
M	src/existing.py
D	old_file.txt

commit def456abc789  
Author:     Other User <other@example.com>
AuthorDate: Sun Jan 14 15:20:00 2024 +0000
Commit:     Other User <other@example.com>
CommitDate: Sun Jan 14 15:20:00 2024 +0000

    fix: Fix bug in existing code

M	src/existing.py"""

        commits = git_adapter._parse_git_log_output(git_log_output)
        
        assert len(commits) == 2
        
        # Check first commit
        commit1 = commits[0]
        assert commit1['hash'] == 'abc123def456'
        assert commit1['author'] == 'Test User'
        assert commit1['author_email'] == 'test@example.com'
        assert commit1['subject'] == 'feat: Add new feature for testing'
        assert commit1['body'] == 'This is a test commit body.'
        assert len(commit1['changed_files']) == 3
        assert commit1['changed_files'][0] == {'type': 'A', 'file': 'src/new_feature.py'}
        
        # Check second commit  
        commit2 = commits[1]
        assert commit2['hash'] == 'def456abc789'
        assert commit2['author'] == 'Other User'
        assert commit2['subject'] == 'fix: Fix bug in existing code'
        assert len(commit2['changed_files']) == 1

    @pytest.mark.asyncio
    async def test_get_commit_diff(self, git_adapter):
        """Test getting commit diff content."""
        mock_diff = "diff --git a/file.py b/file.py\n+added line\n-removed line"
        
        with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.return_value = mock_diff
            
            result = await git_adapter._get_commit_diff("abc123")
            
            assert result == mock_diff
            mock_git.assert_called_once_with([
                "show", "abc123", "--format=", f"--max-count={100 * 1024}"
            ])

    @pytest.mark.asyncio
    async def test_get_commit_diff_truncated(self, git_adapter):
        """Test commit diff truncation for large diffs."""
        large_diff = "a" * 200000  # 200KB diff
        
        with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.return_value = large_diff
            
            result = await git_adapter._get_commit_diff("abc123")
            
            assert len(result) <= (100 * 1024 + 50)  # Max size + truncation message
            assert "[diff truncated]" in result

    @pytest.mark.asyncio
    async def test_detect_relationships_parent_child(self, git_adapter):
        """Test detection of parent-child commit relationships."""
        # Create test items
        parent_item = ContextItem(
            source_type="git",
            entity_type="commit", 
            source_id="parent123",
            metrics={"commit_hash": "parent123"}
        )
        
        child_item = ContextItem(
            source_type="git",
            entity_type="commit",
            source_id="child456", 
            metrics={"commit_hash": "child456", "parent_commits": ["parent123"]}
        )
        
        context_window = [parent_item]
        
        relationships = await git_adapter.detect_relationships(child_item, context_window)
        
        assert len(relationships) == 1
        assert relationships[0][0] == "parent_commit"
        assert relationships[0][1] == parent_item.id
        assert relationships[0][2] == 1.0

    @pytest.mark.asyncio
    async def test_detect_relationships_file_overlap(self, git_adapter):
        """Test detection of file change overlap relationships."""
        item1 = ContextItem(
            source_type="git",
            entity_type="commit",
            source_id="commit1",
            metrics={"changed_files": ["file1.py", "file2.py"], "impact_score": 0.5}
        )
        
        item2 = ContextItem(
            source_type="git", 
            entity_type="commit",
            source_id="commit2",
            metrics={"changed_files": ["file2.py", "file3.py"], "impact_score": 0.7}
        )
        
        context_window = [item2]
        
        relationships = await git_adapter.detect_relationships(item1, context_window)
        
        # Should find overlapping changes relationship
        overlap_rels = [r for r in relationships if r[0] == "overlapping_changes"]
        assert len(overlap_rels) == 1
        assert overlap_rels[0][1] == item2.id
        assert overlap_rels[0][2] > 0.3  # Should have reasonable confidence

    @pytest.mark.asyncio
    async def test_cleanup(self, git_adapter):
        """Test adapter cleanup."""
        # Set up some state to clean
        git_adapter._processed_commits.add("test_commit")
        git_adapter._commit_count = 10
        git_adapter._current_branch = "test_branch"
        
        await git_adapter.cleanup()
        
        # Verify state was cleaned
        assert len(git_adapter._processed_commits) == 0
        assert git_adapter._commit_count == 0
        assert git_adapter._current_branch is None


class TestCommitProcessor:
    """Unit tests for CommitProcessor class."""

    @pytest.fixture
    def processor(self, git_config):
        """Create CommitProcessor for testing."""
        return CommitProcessor(git_config)

    @pytest.mark.asyncio
    async def test_classify_commit_type_feature(self, processor):
        """Test commit type classification for features."""
        message = "feat: add new user authentication"
        changed_files = [{"file": "auth.py", "type": "A"}]
        
        commit_type = processor._classify_commit_type(message, changed_files)
        
        assert commit_type == CommitType.FEATURE

    @pytest.mark.asyncio
    async def test_classify_commit_type_bugfix(self, processor):
        """Test commit type classification for bug fixes."""
        message = "fix: resolve null pointer exception"
        changed_files = [{"file": "service.py", "type": "M"}]
        
        commit_type = processor._classify_commit_type(message, changed_files)
        
        assert commit_type == CommitType.BUGFIX

    @pytest.mark.asyncio
    async def test_classify_commit_type_merge(self, processor):
        """Test commit type classification for merge commits."""
        message = "merge branch feature/new-ui into main"
        changed_files = [{"file": f"file{i}.py", "type": "M"} for i in range(25)]  # Many files
        
        commit_type = processor._classify_commit_type(message, changed_files)
        
        assert commit_type == CommitType.MERGE

    @pytest.mark.asyncio
    async def test_classify_commit_type_documentation(self, processor):
        """Test commit type classification for documentation."""
        message = "update readme with installation instructions"
        changed_files = [{"file": "README.md", "type": "M"}]
        
        commit_type = processor._classify_commit_type(message, changed_files)
        
        assert commit_type == CommitType.DOCUMENTATION

    @pytest.mark.asyncio
    async def test_calculate_impact_score(self, processor):
        """Test impact score calculation."""
        commit_data = {
            "changed_files": [
                {"file": "core/main.py", "type": "M"},
                {"file": "services/api.py", "type": "M"},
                {"file": "README.md", "type": "M"}
            ],
            "diff": "a" * 5000  # 5KB diff
        }
        
        with patch.object(processor, '_is_core_file', side_effect=lambda f: f.startswith("core/")):
            impact_score = await processor._calculate_impact_score(commit_data)
        
        assert 0.0 <= impact_score <= 1.0
        assert impact_score > 0.3  # Should have moderate impact

    @pytest.mark.asyncio
    async def test_calculate_risk_score(self, processor):
        """Test risk score calculation."""
        commit_data = {
            "changed_files": [
                {"file": "migrations/001_add_users.sql", "type": "A"},
                {"file": "config/production.yml", "type": "M"}
            ],
            "subject": "CRITICAL: Fix database migration"
        }
        
        impact_score = 0.8
        risk_score = processor._calculate_risk_score(commit_data, impact_score)
        
        assert 0.0 <= risk_score <= 1.0
        assert risk_score > 0.5  # Should have high risk due to migration + critical

    @pytest.mark.asyncio
    async def test_extract_semantic_tags(self, processor):
        """Test semantic tag extraction."""
        message = "breaking change: update api with performance improvements"
        changed_files = [
            {"file": "api.py", "type": "M"},
            {"file": "test.js", "type": "A"}
        ]
        
        tags = processor._extract_semantic_tags(message, changed_files)
        
        assert "breaking_change" in tags
        assert "performance" in tags
        assert "language_py" in tags
        assert "language_js" in tags

    @pytest.mark.asyncio
    async def test_detect_commit_patterns(self, processor):
        """Test commit pattern detection."""
        commit_data = {
            "commit_date": "2024-01-15T23:30:00",
            "changed_files": [{"file": "single_file.py", "type": "M"}]
        }
        
        patterns = processor._detect_commit_patterns(commit_data)
        
        assert "late_night_commit" in patterns
        assert "single_file_change" in patterns

    @pytest.mark.asyncio
    async def test_analyze_commit_complete(self, processor, sample_commit_data):
        """Test complete commit analysis."""
        analysis = await processor.analyze_commit(sample_commit_data)
        
        assert isinstance(analysis, CommitAnalysis)
        assert analysis.commit_hash == "abc123def456"
        assert analysis.commit_type == CommitType.FEATURE
        assert 0.0 <= analysis.impact_score <= 1.0
        assert 0.0 <= analysis.risk_score <= 1.0
        assert analysis.complexity_delta > 0  # Should have positive complexity delta
        assert len(analysis.files_impacted) == 3
        assert "breaking_change" in analysis.semantic_tags


class TestGitCheckpointManager:
    """Unit tests for GitCheckpointManager class."""

    @pytest.fixture
    def checkpoint_manager(self, git_config, database_mock):
        """Create GitCheckpointManager for testing."""
        return GitCheckpointManager(git_config, database_mock)

    @pytest.mark.asyncio
    async def test_get_last_processed_commit_exists(self, checkpoint_manager, database_mock):
        """Test getting last processed commit when it exists."""
        database_mock.fetchrow.return_value = {'last_processed_commit': 'abc123'}
        
        result = await checkpoint_manager.get_last_processed_commit("main")
        
        assert result == "abc123"
        database_mock.fetchrow.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_last_processed_commit_not_exists(self, checkpoint_manager, database_mock):
        """Test getting last processed commit when it doesn't exist."""
        database_mock.fetchrow.return_value = None
        
        result = await checkpoint_manager.get_last_processed_commit("main")
        
        assert result is None

    @pytest.mark.asyncio
    async def test_save_checkpoint(self, checkpoint_manager, database_mock):
        """Test saving processing checkpoint."""
        timestamp = datetime.utcnow()
        
        await checkpoint_manager.save_checkpoint("main", "abc123", timestamp, 10)
        
        database_mock.execute.assert_called_once()
        # Verify the SQL query includes expected parameters
        call_args = database_mock.execute.call_args[0]
        assert "INSERT INTO git_processing_checkpoints" in call_args[0]
        assert call_args[1] == "."  # repository_path
        assert call_args[2] == "main"  # branch_name
        assert call_args[3] == "abc123"  # commit_hash


class TestCodeChangeAnalyzer:
    """Unit tests for CodeChangeAnalyzer class."""

    @pytest.fixture
    def analyzer(self, git_config):
        """Create CodeChangeAnalyzer for testing."""
        return CodeChangeAnalyzer(git_config)

    @pytest.mark.asyncio
    async def test_analyze_file_changes(self, analyzer):
        """Test file change analysis."""
        commit_data = {
            "changed_files": [
                {"type": "A", "file": "new_file.py"},
                {"type": "M", "file": "existing.py"},
                {"type": "M", "file": "services/api.py"},
                {"type": "D", "file": "old_file.txt"}
            ]
        }
        
        analysis = await analyzer.analyze_file_changes(commit_data)
        
        assert analysis["total_files"] == 4
        assert analysis["added_files"] == 1
        assert analysis["modified_files"] == 2
        assert analysis["deleted_files"] == 1
        assert analysis["file_types"]["py"] == 3
        assert analysis["file_types"]["txt"] == 1

    @pytest.mark.asyncio
    async def test_is_core_file(self, analyzer):
        """Test core file detection."""
        assert analyzer._is_core_file("src/main.py") is True
        assert analyzer._is_core_file("package.json") is True
        assert analyzer._is_core_file("services/auth.py") is True
        assert analyzer._is_core_file("tests/test_utils.py") is False
        assert analyzer._is_core_file("docs/README.md") is False


class TestGitRepositoryScanner:
    """Unit tests for GitRepositoryScanner class."""

    @pytest.fixture
    def scanner(self, git_config):
        """Create GitRepositoryScanner for testing."""
        return GitRepositoryScanner(git_config)

    @pytest.mark.asyncio
    async def test_classify_branch_type(self, scanner):
        """Test branch type classification."""
        assert scanner._classify_branch_type("main") == "main"
        assert scanner._classify_branch_type("master") == "main"
        assert scanner._classify_branch_type("feature/user-auth") == "feature"
        assert scanner._classify_branch_type("feat/new-ui") == "feature"
        assert scanner._classify_branch_type("hotfix/critical-bug") == "hotfix"
        assert scanner._classify_branch_type("fix/memory-leak") == "hotfix"
        assert scanner._classify_branch_type("release/v1.2.0") == "release"
        assert scanner._classify_branch_type("develop") == "develop"
        assert scanner._classify_branch_type("random-branch") == "unknown"

    @pytest.mark.asyncio
    async def test_scan_branches(self, scanner):
        """Test branch scanning."""
        mock_output = """main|abc123|2024-01-15 10:30:00 +0000|John Doe
feature/user-auth|def456|2024-01-14 15:20:00 +0000|Jane Smith
develop|ghi789|2024-01-13 09:15:00 +0000|Bob Wilson"""

        with patch.object(scanner, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.return_value = mock_output
            
            branches = await scanner.scan_branches()
            
            assert len(branches) == 3
            assert "main" in branches
            assert "feature/user-auth" in branches
            assert "develop" in branches
            
            main_branch = branches["main"]
            assert main_branch.name == "main"
            assert main_branch.head_commit == "abc123"
            assert main_branch.branch_type == "main"


class TestPerformanceAndMemoryUsage:
    """Tests for performance and memory usage scenarios."""

    @pytest.mark.asyncio
    async def test_large_commit_processing(self, git_adapter):
        """Test processing commits with large diffs."""
        large_commit = {
            "hash": "large123",
            "author": "Test User",
            "author_email": "test@example.com",
            "commit_date": "2024-01-15 10:30:00 +0000",
            "subject": "Large commit with many changes",
            "body": "",
            "changed_files": [{"type": "M", "file": f"file_{i}.py"} for i in range(100)],
            "diff": "a" * 500000,  # 500KB diff
            "parent_commits": []
        }
        
        with patch.object(git_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(git_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="git",
                    source_id="large123",
                    title="Large commit with many changes"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                # Should handle large commits without issues
                result = await git_adapter._transform_commit_enhanced(large_commit)
                
                assert result.source_id == "large123"
                assert result.metrics["files_changed_count"] == 100

    @pytest.mark.asyncio
    async def test_concurrent_processing_safety(self, git_adapter, sample_commit_data):
        """Test thread safety during concurrent processing."""
        
        async def process_commit(commit_id):
            commit_data = sample_commit_data.copy()
            commit_data["hash"] = f"commit_{commit_id}"
            commit_data["subject"] = f"Commit #{commit_id}"
            
            with patch.object(git_adapter.transformer, 'create_base_context_item') as mock_create:
                with patch.object(git_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                    mock_item = ContextItem(
                        source_type="git",
                        source_id=f"commit_{commit_id}",
                        title=f"Commit #{commit_id}"
                    )
                    mock_create.return_value = mock_item
                    mock_transform.return_value = mock_item
                    
                    return await git_adapter._transform_commit_enhanced(commit_data)
        
        # Process multiple commits concurrently
        tasks = [process_commit(i) for i in range(10)]
        results = await asyncio.gather(*tasks)
        
        # Verify all commits processed successfully
        assert len(results) == 10
        assert all(isinstance(r, ContextItem) for r in results)
        assert len(set(r.source_id for r in results)) == 10  # All unique


class TestErrorHandling:
    """Tests for error handling scenarios."""

    @pytest.mark.asyncio
    async def test_malformed_commit_data(self, git_adapter):
        """Test handling of malformed commit data."""
        malformed_commit = {
            "hash": None,  # Invalid hash
            "author": "",  # Empty author
            # Missing required fields
        }
        
        with patch.object(git_adapter.transformer, 'create_base_context_item') as mock_create:
            with patch.object(git_adapter.transformer, 'transform_item', new_callable=AsyncMock) as mock_transform:
                mock_item = ContextItem(
                    source_type="git",
                    source_id="unknown",
                    title="Unknown Error"
                )
                mock_create.return_value = mock_item
                mock_transform.return_value = mock_item
                
                # Should handle malformed data gracefully
                result = await git_adapter._transform_commit_enhanced(malformed_commit)
                
                assert result is not None
                assert result.source_type == "git"

    @pytest.mark.asyncio
    async def test_git_command_failure(self, git_adapter):
        """Test handling of git command failures."""
        with patch.object(git_adapter, '_run_git_command', new_callable=AsyncMock) as mock_git:
            mock_git.side_effect = Exception("Git command failed")
            
            with pytest.raises(Exception, match="Git command failed"):
                await git_adapter._get_commit_diff("abc123")

    @pytest.mark.asyncio
    async def test_commit_analysis_error_handling(self, git_config):
        """Test commit analysis error handling."""
        processor = CommitProcessor(git_config)
        
        # Test with completely invalid data
        invalid_commit = {}
        
        analysis = await processor.analyze_commit(invalid_commit)
        
        # Should return default analysis for invalid data
        assert analysis.commit_hash == "unknown"
        assert analysis.commit_type == CommitType.UNKNOWN
        assert analysis.impact_score == 0.0
        assert analysis.risk_score == 0.0


# Integration test markers for different test categories
pytestmark = [
    pytest.mark.unit,
    pytest.mark.git_adapter,
]