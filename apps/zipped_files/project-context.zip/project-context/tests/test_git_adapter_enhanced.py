"""Test suite for the enhanced Git adapter implementation."""

import asyncio
import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch
from pathlib import Path
import sys

# Add source path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from project_context.ingestion.adapters.git_adapter import (
    GitAdapter,
    CommitProcessor, 
    CodeChangeAnalyzer,
    GitRepositoryScanner,
    GitCheckpointManager,
    CommitType,
    ProcessingStatus,
)
from project_context.ingestion.base_adapter import AdapterConfig, BatchMode


class TestCommitProcessor:
    """Test the CommitProcessor component."""
    
    def setup_method(self):
        """Set up test fixtures."""
        config = AdapterConfig(
            adapter_id="test_git",
            source_type="git", 
            source_config={}
        )
        self.processor = CommitProcessor(config)
    
    def test_classify_commit_type(self):
        """Test commit type classification."""
        # Test feature commit
        message = "feat: add new user authentication"
        changed_files = [{"file": "auth.py", "type": "A"}]
        result = self.processor._classify_commit_type(message, changed_files)
        assert result == CommitType.FEATURE
        
        # Test bugfix commit
        message = "fix: resolve login issue with special characters"
        changed_files = [{"file": "auth.py", "type": "M"}]
        result = self.processor._classify_commit_type(message, changed_files)
        assert result == CommitType.BUGFIX
        
        # Test merge commit
        message = "merge branch 'feature/new-ui' into main"
        changed_files = [{"file": f"file_{i}.py", "type": "M"} for i in range(25)]
        result = self.processor._classify_commit_type(message, changed_files)
        assert result == CommitType.MERGE
        
        # Test documentation commit by file extension
        message = "update project documentation"
        changed_files = [{"file": "README.md", "type": "M"}]
        result = self.processor._classify_commit_type(message, changed_files)
        assert result == CommitType.DOCUMENTATION

    @pytest.mark.asyncio
    async def test_calculate_impact_score(self):
        """Test impact score calculation."""
        # High impact: many files, large diff, core files
        commit_data = {
            "changed_files": [
                {"file": "main.py", "type": "M"},
                {"file": "core/api.py", "type": "M"},
                {"file": "models/user.py", "type": "M"},
            ],
            "diff": "x" * 5000  # Large diff
        }
        score = await self.processor._calculate_impact_score(commit_data)
        assert score > 0.5
        
        # Low impact: single file, small diff
        commit_data = {
            "changed_files": [{"file": "test_helper.py", "type": "M"}],
            "diff": "small change"
        }
        score = await self.processor._calculate_impact_score(commit_data)
        assert score < 0.3

    def test_calculate_risk_score(self):
        """Test risk score calculation."""
        # High risk: database migration, critical keywords
        commit_data = {
            "changed_files": [{"file": "migrations/001_schema.sql", "type": "A"}],
            "subject": "critical database migration for user table"
        }
        risk = self.processor._calculate_risk_score(commit_data, 0.5)
        assert risk > 0.7
        
        # Low risk: documentation change
        commit_data = {
            "changed_files": [{"file": "docs/readme.md", "type": "M"}],
            "subject": "update readme with installation instructions"
        }
        risk = self.processor._calculate_risk_score(commit_data, 0.1)
        assert risk < 0.3

    def test_extract_semantic_tags(self):
        """Test semantic tag extraction."""
        message = "breaking change: refactor authentication for security improvement"
        changed_files = [
            {"file": "auth.py", "type": "M"},
            {"file": "api/users.py", "type": "M"}
        ]
        
        tags = self.processor._extract_semantic_tags(message, changed_files)
        
        assert "breaking_change" in tags
        assert "security" in tags
        assert "language_py" in tags
        assert "api_change" in tags

    def test_detect_commit_patterns(self):
        """Test behavioral pattern detection."""
        # Late night commit
        commit_data = {
            "commit_date": "2023-10-15 23:30:00 +0000",
            "changed_files": [{"file": "hotfix.py", "type": "A"}],
            "subject": "quick fix"
        }
        
        patterns = self.processor._detect_commit_patterns(commit_data)
        
        assert "late_night_commit" in patterns
        assert "single_file_change" in patterns
        assert "minimal_description" in patterns

    @pytest.mark.asyncio
    async def test_analyze_commit_full(self):
        """Test complete commit analysis."""
        commit_data = {
            "hash": "abc123def456",
            "subject": "feat: implement user profile API",
            "body": "Add REST endpoints for user profile management",
            "author": "developer@example.com",
            "commit_date": "2023-10-15 14:30:00 +0000",
            "changed_files": [
                {"file": "api/profiles.py", "type": "A"},
                {"file": "models/user.py", "type": "M"},
                {"file": "tests/test_profiles.py", "type": "A"}
            ],
            "diff": "+" * 1000  # Medium size diff
        }
        
        analysis = await self.processor.analyze_commit(commit_data)
        
        assert analysis.commit_hash == "abc123def456"
        assert analysis.commit_type == CommitType.FEATURE
        assert analysis.impact_score > 0
        assert analysis.risk_score >= 0
        assert len(analysis.files_impacted) == 3
        assert "language_py" in analysis.semantic_tags or "api_change" in analysis.semantic_tags


class TestCodeChangeAnalyzer:
    """Test the CodeChangeAnalyzer component."""
    
    def setup_method(self):
        """Set up test fixtures."""
        config = AdapterConfig(
            adapter_id="test_git",
            source_type="git",
            source_config={"repository_path": "."}
        )
        self.analyzer = CodeChangeAnalyzer(config)

    @pytest.mark.asyncio
    async def test_analyze_file_changes(self):
        """Test file change analysis."""
        commit_data = {
            "changed_files": [
                {"file": "src/main.py", "type": "A"},
                {"file": "src/utils.py", "type": "M"},
                {"file": "old_file.py", "type": "D"},
                {"file": "docs/readme.md", "type": "M"},
                {"file": "package.json", "type": "M"}
            ]
        }
        
        analysis = await self.analyzer.analyze_file_changes(commit_data)
        
        assert analysis["total_files"] == 5
        assert analysis["added_files"] == 1
        assert analysis["modified_files"] == 3
        assert analysis["deleted_files"] == 1
        assert "py" in analysis["file_types"]
        assert "md" in analysis["file_types"]
        assert "json" in analysis["file_types"]
        assert "package.json" in analysis["core_files_affected"]


class TestGitRepositoryScanner:
    """Test the GitRepositoryScanner component."""
    
    def setup_method(self):
        """Set up test fixtures."""
        config = AdapterConfig(
            adapter_id="test_git",
            source_type="git",
            source_config={"repository_path": "."}
        )
        self.scanner = GitRepositoryScanner(config)

    def test_classify_branch_type(self):
        """Test branch type classification."""
        assert self.scanner._classify_branch_type("main") == "main"
        assert self.scanner._classify_branch_type("master") == "main"
        assert self.scanner._classify_branch_type("feature/user-auth") == "feature"
        assert self.scanner._classify_branch_type("hotfix/critical-bug") == "hotfix"
        assert self.scanner._classify_branch_type("release/v1.2.0") == "release"
        assert self.scanner._classify_branch_type("develop") == "develop"
        assert self.scanner._classify_branch_type("some-random-branch") == "unknown"


class TestGitCheckpointManager:
    """Test the GitCheckpointManager component."""
    
    def setup_method(self):
        """Set up test fixtures."""
        config = AdapterConfig(
            adapter_id="test_git",
            source_type="git",
            source_config={"repository_path": "/test/repo"}
        )
        self.mock_db = Mock()
        self.manager = GitCheckpointManager(config, self.mock_db)

    @pytest.mark.asyncio
    async def test_get_last_processed_commit(self):
        """Test retrieving last processed commit."""
        # Mock database response
        self.mock_db.execute_query = AsyncMock(return_value={"last_processed_commit": "abc123"})
        
        result = await self.manager.get_last_processed_commit("main")
        assert result == "abc123"
        
        # Test no result
        self.mock_db.execute_query = AsyncMock(return_value=None)
        result = await self.manager.get_last_processed_commit("main")
        assert result is None

    @pytest.mark.asyncio
    async def test_save_checkpoint(self):
        """Test saving checkpoint."""
        self.mock_db.execute_query = AsyncMock()
        
        await self.manager.save_checkpoint(
            "main", 
            "def456", 
            datetime.utcnow(), 
            100
        )
        
        self.mock_db.execute_query.assert_called_once()

    @pytest.mark.asyncio
    async def test_mark_processing_error(self):
        """Test marking processing error."""
        self.mock_db.execute_query = AsyncMock()
        
        await self.manager.mark_processing_error("main", "Test error")
        
        self.mock_db.execute_query.assert_called_once()


class TestGitAdapter:
    """Test the main GitAdapter class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.config = AdapterConfig(
            adapter_id="test_git",
            source_type="git",
            batch_mode=BatchMode.BATCH,
            batch_size=10,
            source_config={
                "repository_path": ".",
                "enable_incremental": True,
                "enable_semantic_analysis": True,
                "enable_branch_detection": True,
            }
        )
        self.adapter = GitAdapter(self.config)

    def test_default_config(self):
        """Test default configuration generation."""
        config = GitAdapter.default_config()
        
        assert config.adapter_id == "git_adapter"
        assert config.source_type == "git"
        assert config.batch_mode == BatchMode.BATCH
        assert config.source_config["enable_incremental"] is True
        assert config.source_config["enable_semantic_analysis"] is True

    @pytest.mark.asyncio
    async def test_initialization_without_git(self):
        """Test adapter initialization when git is not available."""
        # Mock git repository check to fail
        with patch.object(self.adapter, '_is_git_repo', return_value=False):
            with pytest.raises(ValueError, match="Not a git repository"):
                await self.adapter.initialize()

    @pytest.mark.asyncio
    @patch('project_context.ingestion.adapters.git_adapter.asyncio.create_subprocess_exec')
    async def test_git_command_execution(self, mock_subprocess):
        """Test git command execution."""
        # Mock subprocess
        mock_process = Mock()
        mock_process.communicate = AsyncMock(return_value=(b"git output", b""))
        mock_process.returncode = 0
        mock_subprocess.return_value = mock_process
        
        result = await self.adapter._run_git_command(["--version"])
        assert result == "git output"
        
        # Test command failure
        mock_process.returncode = 1
        with pytest.raises(Exception):
            await self.adapter._run_git_command(["invalid-command"])

    def test_parse_git_log_output(self):
        """Test git log output parsing."""
        git_output = """commit abc123def456
Author: Test Author <test@example.com>
AuthorDate: Sun Oct 15 14:30:00 2023 +0000
Commit: Test Author <test@example.com>
CommitDate: Sun Oct 15 14:30:00 2023 +0000

    feat: add new feature
    
    This is the commit body with more details.

M	src/main.py
A	src/new_file.py"""
        
        commits = self.adapter._parse_git_log_output(git_output)
        
        assert len(commits) == 1
        commit = commits[0]
        
        assert commit["hash"] == "abc123def456"
        assert commit["author"] == "Test Author"
        assert commit["author_email"] == "test@example.com"
        assert commit["subject"] == "feat: add new feature"
        assert "more details" in commit["body"]
        assert len(commit["changed_files"]) == 2
        assert commit["changed_files"][0]["type"] == "M"
        assert commit["changed_files"][0]["file"] == "src/main.py"
        assert commit["changed_files"][1]["type"] == "A"
        assert commit["changed_files"][1]["file"] == "src/new_file.py"

    @pytest.mark.asyncio
    async def test_transform_commit(self):
        """Test commit transformation to ContextItem."""
        raw_commit = {
            "type": "commit",
            "hash": "abc123def456",
            "subject": "feat: implement user authentication", 
            "body": "Add login and logout functionality",
            "author": "developer@example.com",
            "author_email": "developer@example.com",
            "commit_date": "2023-10-15 14:30:00 +0000",
            "branch": "feature/auth",
            "changed_files": [
                {"file": "auth.py", "type": "A"},
                {"file": "models/user.py", "type": "M"}
            ],
            "analysis": {
                "commit_type": "feature",
                "impact_score": 0.8,
                "risk_score": 0.3,
                "semantic_tags": ["api_change", "language_py"]
            }
        }
        
        context_item = await self.adapter.transform_item(raw_commit)
        
        assert context_item.source_type == "git"
        assert context_item.source_id == "abc123def456"
        assert context_item.entity_type == "commit"
        assert context_item.title == "feat: implement user authentication"
        assert context_item.actor_id == "developer@example.com"
        assert "git" in context_item.tags
        assert "commit" in context_item.tags
        assert "type_feature" in context_item.tags
        assert context_item.metrics["commit_hash"] == "abc123def456"
        assert context_item.metrics["impact_score"] == 0.8
        assert context_item.metrics["branch_name"] == "feature/auth"

    @pytest.mark.asyncio 
    async def test_cleanup(self):
        """Test adapter cleanup."""
        # Add some processed commits
        self.adapter._processed_commits.add("commit1")
        self.adapter._processed_commits.add("commit2")
        self.adapter._commit_count = 50
        
        await self.adapter.cleanup()
        
        # Verify state is cleared
        assert len(self.adapter._processed_commits) == 0
        assert self.adapter._commit_count == 0
        assert self.adapter._current_branch is None


@pytest.mark.asyncio
async def test_integration_scenario():
    """Test a realistic integration scenario."""
    config = AdapterConfig(
        adapter_id="integration_test",
        source_type="git",
        batch_mode=BatchMode.BATCH, 
        batch_size=5,
        source_config={
            "repository_path": ".",
            "enable_incremental": False,  # Disable for test
            "enable_semantic_analysis": True,
            "max_commit_age_days": 1,  # Very recent only
        }
    )
    
    adapter = GitAdapter(config)
    
    # Mock the git commands to avoid actual git dependency
    with patch.object(adapter, '_is_git_repo', return_value=True), \
         patch.object(adapter, '_run_git_command') as mock_git_cmd:
        
        # Mock git version check
        mock_git_cmd.side_effect = [
            "git version 2.34.1",  # --version
            "",  # Empty log output
        ]
        
        await adapter.initialize()
        
        # Test fetching (should get empty result due to mock)
        items = []
        async for item in adapter.fetch_items(limit=5):
            items.append(item)
        
        # With empty git output, should get no items
        assert len(items) == 0
        
        await adapter.cleanup()


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])