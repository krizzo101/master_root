#!/usr/bin/env python3
"""Integration test for code intelligence adapter with .proj-intel support."""

import asyncio
import json
import os
import sys
from pathlib import Path

# Add src to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

try:
    from project_context.ingestion.adapters.code_adapter import CodeAdapter
    from project_context.ingestion.base_adapter import AdapterConfig, BatchMode
    
    print("✅ Successfully imported code intelligence components")
except ImportError as e:
    print(f"❌ Import failed: {e}")
    sys.exit(1)


def create_test_config():
    """Create test configuration for the code intelligence adapter."""
    return AdapterConfig(
        adapter_id="code_intel_test",
        source_type="code",
        batch_mode=BatchMode.BATCH,
        batch_size=10,
        generate_embeddings=False,  # Disable for testing
        generate_summaries=False,   # Disable for testing
        extract_relationships=True,
        source_config={
            "scan_directories": [str(project_root.parent.parent)],  # master_root
            "include_patterns": ["*.py", "*.md"],
            "max_file_size_mb": 5,
            "enable_proj_intel": True,
            "proj_intel_paths": [".proj-intel"],
            "ingest_file_elements": True,
            "ingest_project_analysis": True,
            "ingest_symbol_index": True,
            "proj_intel_max_age_days": 30,
        }
    )


async def test_basic_functionality():
    """Test basic adapter functionality without database."""
    print("🧪 Testing Code Intelligence Adapter - Basic Functionality")
    print("=" * 60)
    
    config = create_test_config()
    adapter = CodeAdapter(config)
    
    try:
        # Test initialization
        print("1️⃣ Testing initialization...")
        await adapter.initialize()
        print("   ✅ Initialization successful")
        
        # Check if .proj-intel data was found
        print("\n2️⃣ Checking .proj-intel data discovery...")
        if adapter._proj_intel_manifest:
            manifest = adapter._proj_intel_manifest
            print(f"   ✅ Found .proj-intel manifest")
            print(f"      Schema: {manifest.get('schema_version')}")
            print(f"      Generated: {manifest.get('generated_at')}")
            print(f"      Primary file: {manifest.get('primary', 'None')}")
            print(f"      Shards: {len(manifest.get('shards', []))}")
        else:
            print("   ⚠️  No .proj-intel manifest found (normal if not present)")
        
        # Test item fetching
        print("\n3️⃣ Testing item fetching...")
        items_count = 0
        intel_count = 0
        regular_count = 0
        
        async for raw_item in adapter.fetch_items(limit=15):
            items_count += 1
            
            if raw_item.get("intel_data_type"):
                intel_count += 1
                print(f"   📊 Intel item {intel_count}: {raw_item['intel_data_type']} - {raw_item.get('title', 'Untitled')}")
            else:
                regular_count += 1
                if regular_count <= 3:
                    print(f"   📄 Regular item {regular_count}: {raw_item.get('title', Path(raw_item['file_path']).name)}")
            
            # Test transformation on a few items
            if items_count <= 5:
                try:
                    context_item = await adapter.transform_item(raw_item)
                    print(f"      ✅ Transformed to: {context_item.source_type}/{context_item.entity_type}")
                    
                    # Test relationship detection
                    relationships = await adapter.detect_relationships(context_item, [])
                    if relationships:
                        print(f"      🔗 Found {len(relationships)} relationships")
                        
                except Exception as e:
                    print(f"      ❌ Transformation failed: {e}")
        
        print(f"\n📊 Results Summary:")
        print(f"   Total items: {items_count}")
        print(f"   Intelligence items: {intel_count}")  
        print(f"   Regular files: {regular_count}")
        
        # Test cache status
        print(f"\n4️⃣ Cache status:")
        if adapter._proj_intel_cache:
            for cache_type, cache_data in adapter._proj_intel_cache.items():
                if isinstance(cache_data, dict):
                    print(f"   {cache_type}: {len(cache_data)} entries")
                else:
                    print(f"   {cache_type}: {type(cache_data).__name__}")
        else:
            print("   No cached data")
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        await adapter.cleanup()
        
    print("\n✅ Basic functionality test completed successfully!")
    return True


async def test_proj_intel_specific_features():
    """Test .proj-intel specific features."""
    print("\n🔬 Testing .proj-intel Specific Features")
    print("=" * 50)
    
    # Check if we have access to actual .proj-intel data
    master_root = project_root.parent.parent
    proj_intel_path = master_root / ".proj-intel"
    
    if not proj_intel_path.exists():
        print("⚠️  No .proj-intel directory found, skipping specific tests")
        return True
        
    print(f"🎯 Found .proj-intel at: {proj_intel_path}")
    
    # List available files
    intel_files = list(proj_intel_path.glob("*"))
    print(f"📁 Available files: {len(intel_files)}")
    for f in intel_files[:10]:  # Show first 10
        size_mb = f.stat().st_size / (1024*1024) if f.is_file() else 0
        print(f"   {f.name}: {size_mb:.2f}MB")
    
    # Test manifest loading
    manifest_file = proj_intel_path / "proj_intel_manifest.json"
    if manifest_file.exists():
        try:
            with open(manifest_file) as f:
                manifest = json.load(f)
            print(f"✅ Manifest parsed successfully")
            print(f"   Schema: {manifest.get('schema_version')}")
            print(f"   Primary: {manifest.get('primary')}")
            print(f"   Shards: {len(manifest.get('shards', []))}")
        except Exception as e:
            print(f"❌ Manifest parsing failed: {e}")
            
    return True


async def main():
    """Run all tests."""
    print("🚀 Code Intelligence Adapter Test Suite")
    print("=======================================")
    
    success = True
    
    # Run basic tests
    success &= await test_basic_functionality()
    
    # Run .proj-intel specific tests
    success &= await test_proj_intel_specific_features()
    
    if success:
        print("\n🎉 All tests passed successfully!")
        return 0
    else:
        print("\n💥 Some tests failed!")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)