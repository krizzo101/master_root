#!/usr/bin/env python3
"""
Simple API endpoint validation test for FastAPI backend
"""

import pytest
from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_health_endpoint():
    """Test health check endpoint"""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "timestamp" in data
    assert "version" in data

def test_status_endpoint():
    """Test system status endpoint"""
    response = client.get("/api/status")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_tasks_endpoint():
    """Test tasks list endpoint"""
    response = client.get("/api/tasks")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_performance_endpoint():
    """Test performance metrics endpoint"""
    response = client.get("/api/performance")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_quality_report_endpoint():
    """Test quality report endpoint"""
    response = client.get("/api/quality-report")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_directories_endpoint():
    """Test directories endpoint"""
    response = client.get("/api/directories")
    # Should return either 200 with data or 500 if monitoring not ready  
    assert response.status_code in [200, 500]

def test_websocket_stats_endpoint():
    """Test WebSocket stats endpoint"""
    response = client.get("/api/websocket-stats")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_analytics_endpoint():
    """Test analytics endpoint"""
    response = client.get("/api/analytics")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_live_data_endpoint():
    """Test live data endpoint"""
    response = client.get("/api/live-data")
    # Should return either 200 with data or 500 if monitoring not ready
    assert response.status_code in [200, 500]

def test_task_detail_endpoint_404():
    """Test task detail endpoint with non-existent task"""
    response = client.get("/api/tasks/non-existent-task")
    # Should return 404 for non-existent task or 500 if monitoring not ready
    assert response.status_code in [404, 500]

def test_task_logs_endpoint():
    """Test task logs endpoint with non-existent task"""
    response = client.get("/api/logs/non-existent-task")
    # Should return either data or error depending on monitoring state
    assert response.status_code in [200, 500]

if __name__ == "__main__":
    # Run a simple smoke test
    print("🧪 Running FastAPI Backend Smoke Tests...")
    
    # Test health endpoint (most basic)
    try:
        test_health_endpoint()
        print("✅ Health endpoint working")
    except Exception as e:
        print(f"❌ Health endpoint failed: {e}")
        
    # Test other endpoints
    endpoints = [
        ("/api/status", "Status"),
        ("/api/tasks", "Tasks"),  
        ("/api/performance", "Performance"),
        ("/api/quality-report", "Quality Report"),
        ("/api/directories", "Directories"),
        ("/api/websocket-stats", "WebSocket Stats"),
        ("/api/analytics", "Analytics"),
        ("/api/live-data", "Live Data")
    ]
    
    for endpoint, name in endpoints:
        try:
            response = client.get(endpoint)
            if response.status_code == 200:
                print(f"✅ {name} endpoint working")
            elif response.status_code == 500:
                print(f"⚠️  {name} endpoint returns 500 (monitoring service may not be ready)")
            else:
                print(f"❓ {name} endpoint returned status {response.status_code}")
        except Exception as e:
            print(f"❌ {name} endpoint failed: {e}")
    
    print("\n🎯 Backend API validation complete!")