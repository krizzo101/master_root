#!/usr/bin/env python3
"""
WebSocket Test Client - Test the enhanced WebSocket implementation
"""

import asyncio
import json
import logging
import time
import websockets
import uuid
from typing import Dict, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class WebSocketTestClient:
    """Test client for WebSocket functionality"""
    
    def __init__(self, url: str = "ws://localhost:8000/ws"):
        self.url = url
        self.client_id = str(uuid.uuid4())
        self.websocket: Optional[websockets.WebSocketServerProtocol] = None
        self.running = False
        self.stats = {
            "messages_sent": 0,
            "messages_received": 0,
            "heartbeats_received": 0,
            "data_updates": 0,
            "errors": 0,
            "connection_time": 0
        }
        
    async def connect(self):
        """Connect to WebSocket server"""
        try:
            logger.info(f"Connecting to {self.url}")
            self.websocket = await websockets.connect(self.url)
            self.stats["connection_time"] = time.time()
            logger.info(f"Connected successfully as client {self.client_id}")
            return True
        except Exception as e:
            logger.error(f"Connection failed: {e}")
            return False
            
    async def disconnect(self):
        """Disconnect from WebSocket server"""
        self.running = False
        if self.websocket:
            await self.websocket.close()
            logger.info("Disconnected from WebSocket server")
            
    async def send_message(self, message: Dict):
        """Send message to server"""
        try:
            if self.websocket:
                await self.websocket.send(json.dumps(message))
                self.stats["messages_sent"] += 1
                logger.debug(f"Sent: {message}")
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            self.stats["errors"] += 1
            
    async def receive_messages(self):
        """Listen for messages from server"""
        try:
            async for message in self.websocket:
                try:
                    data = json.loads(message)
                    self.stats["messages_received"] += 1
                    await self.handle_message(data)
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON received: {e}")
                    self.stats["errors"] += 1
        except websockets.exceptions.ConnectionClosed:
            logger.info("WebSocket connection closed")
        except Exception as e:
            logger.error(f"Error receiving messages: {e}")
            self.stats["errors"] += 1
            
    async def handle_message(self, data: Dict):
        """Handle received message"""
        message_type = data.get("type")
        
        if message_type == "connection_established":
            logger.info(f"Connection established: {data}")
            self.client_id = data.get("client_id", self.client_id)
            
        elif message_type == "heartbeat":
            self.stats["heartbeats_received"] += 1
            logger.debug("Heartbeat received")
            
            # Respond to heartbeat
            await self.send_message({
                "type": "ping",
                "client_id": self.client_id,
                "timestamp": time.time()
            })
            
        elif message_type == "update":
            data_type = data.get("data_type")
            logger.info(f"Data update received: {data_type}")
            self.stats["data_updates"] += 1
            
        elif message_type == "initial_data":
            data_type = data.get("data_type")
            logger.info(f"Initial data received: {data_type}")
            
        elif message_type == "pong":
            logger.debug("Pong received")
            
        elif message_type == "error":
            logger.error(f"Server error: {data.get('message')}")
            self.stats["errors"] += 1
            
        else:
            logger.debug(f"Unknown message type: {message_type}")
            
    async def test_subscriptions(self):
        """Test subscription functionality"""
        logger.info("Testing subscription functionality")
        
        # Subscribe to different data types
        subscriptions = ["status", "tasks", "performance", "analytics", "quality"]
        
        for subscription in subscriptions:
            await self.send_message({
                "type": "subscribe",
                "action": "subscribe",
                "subscription": subscription,
                "client_id": self.client_id
            })
            await asyncio.sleep(0.5)
            
        # Test unsubscribe
        await self.send_message({
            "type": "subscribe",
            "action": "unsubscribe", 
            "subscription": "quality",
            "client_id": self.client_id
        })
        
        # List subscriptions
        await self.send_message({
            "type": "subscribe",
            "action": "list_subscriptions",
            "client_id": self.client_id
        })
        
    async def test_data_requests(self):
        """Test immediate data request functionality"""
        logger.info("Testing data request functionality")
        
        data_types = ["status", "tasks", "performance", "analytics"]
        
        for data_type in data_types:
            await self.send_message({
                "type": "request_data",
                "data_type": data_type,
                "client_id": self.client_id
            })
            await asyncio.sleep(1)
            
    async def test_stats_request(self):
        """Test stats request"""
        logger.info("Testing stats request")
        
        await self.send_message({
            "type": "get_stats",
            "client_id": self.client_id
        })
        
    async def run_test_session(self, duration: int = 60):
        """Run a complete test session"""
        logger.info(f"Starting test session for {duration} seconds")
        
        if not await self.connect():
            return False
            
        self.running = True
        
        # Start receiving messages
        receive_task = asyncio.create_task(self.receive_messages())
        
        try:
            # Wait for initial connection
            await asyncio.sleep(2)
            
            # Test subscriptions
            await self.test_subscriptions()
            await asyncio.sleep(5)
            
            # Test data requests
            await self.test_data_requests()
            await asyncio.sleep(5)
            
            # Test stats request
            await self.test_stats_request()
            await asyncio.sleep(5)
            
            # Send periodic pings
            ping_interval = 10
            elapsed = 0
            
            while elapsed < duration and self.running:
                await self.send_message({
                    "type": "ping",
                    "client_id": self.client_id,
                    "timestamp": time.time()
                })
                
                await asyncio.sleep(ping_interval)
                elapsed += ping_interval
                
                # Print stats periodically
                if elapsed % 30 == 0:
                    self.print_stats()
                    
        except KeyboardInterrupt:
            logger.info("Test interrupted by user")
        except Exception as e:
            logger.error(f"Test session error: {e}")
        finally:
            await self.disconnect()
            receive_task.cancel()
            
        return True
        
    def print_stats(self):
        """Print current statistics"""
        uptime = time.time() - self.stats["connection_time"] if self.stats["connection_time"] else 0
        
        logger.info("=== WebSocket Test Statistics ===")
        logger.info(f"Uptime: {uptime:.1f} seconds")
        logger.info(f"Messages sent: {self.stats['messages_sent']}")
        logger.info(f"Messages received: {self.stats['messages_received']}")
        logger.info(f"Heartbeats received: {self.stats['heartbeats_received']}")
        logger.info(f"Data updates: {self.stats['data_updates']}")
        logger.info(f"Errors: {self.stats['errors']}")
        logger.info("===================================")


async def test_multiple_clients(num_clients: int = 3, duration: int = 30):
    """Test with multiple concurrent clients"""
    logger.info(f"Testing with {num_clients} concurrent clients for {duration} seconds")
    
    clients = [WebSocketTestClient() for _ in range(num_clients)]
    tasks = []
    
    for i, client in enumerate(clients):
        client.client_id = f"test_client_{i+1}"
        task = asyncio.create_task(client.run_test_session(duration))
        tasks.append(task)
        await asyncio.sleep(1)  # Stagger connections
        
    try:
        await asyncio.gather(*tasks)
    except Exception as e:
        logger.error(f"Multi-client test error: {e}")
        
    # Print combined stats
    total_stats = {
        "messages_sent": sum(c.stats["messages_sent"] for c in clients),
        "messages_received": sum(c.stats["messages_received"] for c in clients),
        "heartbeats_received": sum(c.stats["heartbeats_received"] for c in clients),
        "data_updates": sum(c.stats["data_updates"] for c in clients),
        "errors": sum(c.stats["errors"] for c in clients),
    }
    
    logger.info("=== Combined Multi-Client Statistics ===")
    for key, value in total_stats.items():
        logger.info(f"{key}: {value}")
    logger.info("=========================================")


async def main():
    """Main test function"""
    print("WebSocket Enhanced Implementation Test")
    print("1. Single client test (60 seconds)")
    print("2. Multi-client test (3 clients, 30 seconds)")
    print("3. Custom test")
    
    choice = input("Select test (1/2/3): ").strip()
    
    if choice == "1":
        client = WebSocketTestClient()
        await client.run_test_session(60)
        client.print_stats()
        
    elif choice == "2":
        await test_multiple_clients(3, 30)
        
    elif choice == "3":
        url = input("WebSocket URL (ws://localhost:8000/ws): ").strip() or "ws://localhost:8000/ws"
        duration = int(input("Duration in seconds (30): ") or "30")
        
        client = WebSocketTestClient(url)
        await client.run_test_session(duration)
        client.print_stats()
        
    else:
        print("Invalid choice")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nTest interrupted by user")
    except Exception as e:
        logger.error(f"Test failed: {e}")