#!/usr/bin/env python3
"""
Test script for MonitoringService
"""

import asyncio
import sys
sys.path.append('/home/opsvi/master_root/apps/project-context')
sys.path.append('/home/opsvi/master_root/apps/agent-orchestrator/src')

from monitoring_service import MonitoringService
import json

async def test_monitoring():
    print('=== Testing MonitoringService ===')
    
    # Initialize service
    service = MonitoringService()
    print(f'✅ MonitoringService initialized')
    print(f'   - Found {len(service.output_dirs)} output directories')
    
    # Test directory discovery
    for i, dir_path in enumerate(service.output_dirs):
        tasks_dir = dir_path / 'tasks'
        task_count = len(list(tasks_dir.glob('*.json'))) if tasks_dir.exists() else 0
        print(f'   - {dir_path.name}: {task_count} tasks')
        if i >= 5:  # Limit output
            print(f'   - ... and {len(service.output_dirs) - i - 1} more directories')
            break
    
    # Test data scanning
    try:
        tasks = await service._scan_task_files()
        print(f'✅ Task scanning successful: {len(tasks)} tasks found')
        
        # Show sample task
        if tasks:
            sample_task = list(tasks.values())[0]
            print(f'   - Sample task: {sample_task.get("task_id", "unknown")} ({sample_task.get("status", "unknown")})')
    except Exception as e:
        print(f'❌ Task scanning failed: {e}')
        return
    
    # Test system status
    try:
        status = await service.get_system_status()
        print(f'✅ System status: {status.get("total_tasks", 0)} tasks, {status.get("overall_progress", 0):.1f}% complete')
    except Exception as e:
        print(f'❌ System status failed: {e}')
    
    # Test analytics
    try:
        analytics = await service.get_task_analytics()
        if 'error' not in analytics:
            overview = analytics.get('overview', {})
            print(f'✅ Analytics: {overview.get("total_tasks", 0)} tasks analyzed')
            print(f'   - By status: {overview.get("by_status", {})}')
        else:
            print(f'⚠️  Analytics returned: {analytics["error"]}')
    except Exception as e:
        print(f'❌ Analytics failed: {e}')
    
    print('=== Test Complete ===')

if __name__ == "__main__":
    asyncio.run(test_monitoring())