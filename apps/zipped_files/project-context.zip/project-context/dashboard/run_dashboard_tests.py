#!/usr/bin/env python3
"""
Dashboard Test Runner - Execute comprehensive integration and performance tests
"""

import asyncio
import json
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Add project paths
sys.path.append("/home/opsvi/master_root/apps/project-context")
sys.path.append("/home/opsvi/master_root/apps/project-context/dashboard/backend")

async def run_dashboard_tests():
    """Execute comprehensive dashboard testing suite"""
    logger.info("🚀 Starting Dashboard Integration Testing Suite...")
    
    test_results = {
        "start_time": datetime.now().isoformat(),
        "integration_tests": {},
        "performance_tests": {},
        "overall_status": "running",
        "test_summary": {}
    }
    
    try:
        # 1. Run Integration Tests
        logger.info("📋 Running Integration Tests...")
        
        try:
            from test_integration import DashboardIntegrationTester
            integration_tester = DashboardIntegrationTester()
            integration_results = await integration_tester.run_all_tests()
            test_results["integration_tests"] = integration_results
            logger.info("✅ Integration tests completed successfully")
        except Exception as e:
            logger.error(f"❌ Integration tests failed: {e}")
            test_results["integration_tests"]["error"] = str(e)
        
        # 2. Run Performance Tests
        logger.info("⚡ Running Performance Tests...")
        
        try:
            from test_performance_load import LoadTester
            performance_tester = LoadTester()
            performance_results = await performance_tester.run_load_tests()
            test_results["performance_tests"] = performance_results
            logger.info("✅ Performance tests completed successfully")
        except Exception as e:
            logger.error(f"❌ Performance tests failed: {e}")
            test_results["performance_tests"]["error"] = str(e)
        
        # 3. Generate Comprehensive Summary
        test_summary = generate_comprehensive_summary(test_results)
        test_results["test_summary"] = test_summary
        test_results["overall_status"] = "completed"
        
        # 4. Save Combined Results
        save_test_results(test_results)
        
        # 5. Display Summary
        display_test_summary(test_summary)
        
    except Exception as e:
        logger.error(f"💥 Test suite execution failed: {e}")
        test_results["overall_status"] = "failed"
        test_results["error"] = str(e)
    
    finally:
        test_results["end_time"] = datetime.now().isoformat()
    
    return test_results


def generate_comprehensive_summary(test_results: dict) -> dict:
    """Generate comprehensive test summary"""
    summary = {
        "timestamp": datetime.now().isoformat(),
        "integration_summary": {},
        "performance_summary": {},
        "overall_grade": "UNKNOWN",
        "recommendations": [],
        "critical_issues": [],
        "success_metrics": {}
    }
    
    # Integration Test Summary
    integration_data = test_results.get("integration_tests", {})
    if integration_data and "error" not in integration_data:
        api_tests = integration_data.get("api_tests", [])
        api_success_rate = sum(1 for test in api_tests if test.get("success", False)) / max(len(api_tests), 1)
        
        summary["integration_summary"] = {
            "api_tests_passed": sum(1 for test in api_tests if test.get("success", False)),
            "api_tests_total": len(api_tests),
            "api_success_rate": api_success_rate,
            "websocket_tests": len(integration_data.get("websocket_tests", [])),
            "data_validation_tests": len(integration_data.get("data_validation", [])),
            "error_handling_tests": len(integration_data.get("error_handling", []))
        }
    
    # Performance Test Summary
    performance_data = test_results.get("performance_tests", {})
    if performance_data and "error" not in performance_data:
        perf_summary = performance_data.get("performance_summary", {})
        memory_info = perf_summary.get("memory", {})
        
        summary["performance_summary"] = {
            "peak_memory_mb": memory_info.get("peak_usage", 0),
            "avg_memory_mb": memory_info.get("avg_mb", 0),
            "load_tests_completed": len(performance_data.get("load_tests", [])),
            "concurrent_tests": len(performance_data.get("concurrent_tests", [])),
            "memory_tests": len(performance_data.get("memory_tests", []))
        }
    
    # Calculate Overall Grade
    summary["overall_grade"] = calculate_overall_grade(summary)
    
    # Generate Recommendations
    summary["recommendations"] = generate_recommendations(summary, test_results)
    
    # Identify Critical Issues
    summary["critical_issues"] = identify_critical_issues(test_results)
    
    return summary


def calculate_overall_grade(summary: dict) -> str:
    """Calculate overall testing grade"""
    score = 0
    max_score = 0
    
    # API Success Rate (40% weight)
    api_success = summary.get("integration_summary", {}).get("api_success_rate", 0)
    score += api_success * 40
    max_score += 40
    
    # Memory Usage (30% weight) - Lower is better
    peak_memory = summary.get("performance_summary", {}).get("peak_memory_mb", 0)
    memory_score = max(0, 30 - (peak_memory / 100) * 5)  # Penalty for high memory usage
    score += memory_score
    max_score += 30
    
    # Test Coverage (30% weight)
    integration_tests = summary.get("integration_summary", {}).get("api_tests_total", 0)
    performance_tests = summary.get("performance_summary", {}).get("load_tests_completed", 0)
    test_coverage = min(30, (integration_tests + performance_tests) / 20 * 30)
    score += test_coverage
    max_score += 30
    
    # Calculate percentage and grade
    if max_score == 0:
        return "INCOMPLETE"
    
    percentage = (score / max_score) * 100
    
    if percentage >= 90:
        return "A+ (EXCELLENT)"
    elif percentage >= 80:
        return "A (GOOD)"
    elif percentage >= 70:
        return "B (SATISFACTORY)"
    elif percentage >= 60:
        return "C (NEEDS IMPROVEMENT)"
    else:
        return "D (POOR)"


def generate_recommendations(summary: dict, test_results: dict) -> list:
    """Generate actionable recommendations"""
    recommendations = []
    
    # API Performance Recommendations
    api_success = summary.get("integration_summary", {}).get("api_success_rate", 0)
    if api_success < 0.9:
        recommendations.append("🔧 Improve API reliability - some endpoints failing")
    
    # Memory Usage Recommendations
    peak_memory = summary.get("performance_summary", {}).get("peak_memory_mb", 0)
    if peak_memory > 500:
        recommendations.append("🧠 Consider memory optimization - high memory usage detected")
    
    # Test Coverage Recommendations
    integration_tests = summary.get("integration_summary", {}).get("api_tests_total", 0)
    if integration_tests < 10:
        recommendations.append("📋 Expand test coverage - add more integration tests")
    
    # WebSocket Recommendations
    ws_tests = summary.get("integration_summary", {}).get("websocket_tests", 0)
    if ws_tests == 0:
        recommendations.append("🔌 Add WebSocket stability testing")
    
    # General Recommendations
    if not recommendations:
        recommendations.append("✅ Dashboard testing looks comprehensive and healthy!")
    
    return recommendations


def identify_critical_issues(test_results: dict) -> list:
    """Identify critical issues that need immediate attention"""
    critical_issues = []
    
    # Check for test execution failures
    if "error" in test_results.get("integration_tests", {}):
        critical_issues.append("❌ Integration test suite failed to execute")
    
    if "error" in test_results.get("performance_tests", {}):
        critical_issues.append("❌ Performance test suite failed to execute")
    
    # Check for API failures
    integration_data = test_results.get("integration_tests", {})
    api_tests = integration_data.get("api_tests", [])
    failed_apis = [test for test in api_tests if not test.get("success", False)]
    
    if len(failed_apis) > len(api_tests) * 0.5:  # More than 50% failure
        critical_issues.append(f"🚨 High API failure rate: {len(failed_apis)}/{len(api_tests)} endpoints failing")
    
    # Check for memory leaks
    performance_data = test_results.get("performance_tests", {})
    memory_tests = performance_data.get("memory_tests", [])
    for memory_test in memory_tests:
        if memory_test.get("memory_growth_mb", 0) > 100:
            critical_issues.append("🧠 Potential memory leak detected in long sessions")
    
    return critical_issues


def save_test_results(test_results: dict):
    """Save comprehensive test results"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Save complete results
    results_file = Path(f"/home/opsvi/master_root/apps/project-context/dashboard/backend/complete_test_results_{timestamp}.json")
    with open(results_file, 'w') as f:
        json.dump(test_results, f, indent=2, default=str)
    
    # Save summary report
    summary_file = Path(f"/home/opsvi/master_root/apps/project-context/dashboard/backend/test_summary_{timestamp}.json")
    with open(summary_file, 'w') as f:
        json.dump(test_results.get("test_summary", {}), f, indent=2, default=str)
    
    logger.info(f"💾 Test results saved to {results_file}")
    logger.info(f"📊 Test summary saved to {summary_file}")


def display_test_summary(summary: dict):
    """Display comprehensive test summary"""
    print("\n" + "="*60)
    print("🎯 DASHBOARD INTEGRATION TEST SUMMARY")
    print("="*60)
    
    print(f"\n📊 Overall Grade: {summary.get('overall_grade', 'UNKNOWN')}")
    print(f"🕒 Test Timestamp: {summary.get('timestamp', 'Unknown')}")
    
    # Integration Summary
    integration = summary.get("integration_summary", {})
    if integration:
        print(f"\n🔧 Integration Tests:")
        print(f"   ✅ API Tests Passed: {integration.get('api_tests_passed', 0)}/{integration.get('api_tests_total', 0)}")
        print(f"   📈 Success Rate: {integration.get('api_success_rate', 0):.1%}")
        print(f"   🔌 WebSocket Tests: {integration.get('websocket_tests', 0)}")
        print(f"   🛡️  Error Handling Tests: {integration.get('error_handling_tests', 0)}")
    
    # Performance Summary
    performance = summary.get("performance_summary", {})
    if performance:
        print(f"\n⚡ Performance Tests:")
        print(f"   🧠 Peak Memory: {performance.get('peak_memory_mb', 0):.1f} MB")
        print(f"   📊 Load Tests: {performance.get('load_tests_completed', 0)}")
        print(f"   👥 Concurrent Tests: {performance.get('concurrent_tests', 0)}")
    
    # Critical Issues
    critical_issues = summary.get("critical_issues", [])
    if critical_issues:
        print(f"\n🚨 Critical Issues:")
        for issue in critical_issues:
            print(f"   {issue}")
    
    # Recommendations
    recommendations = summary.get("recommendations", [])
    if recommendations:
        print(f"\n💡 Recommendations:")
        for recommendation in recommendations:
            print(f"   {recommendation}")
    
    print("\n" + "="*60)


async def main():
    """Main test runner"""
    try:
        results = await run_dashboard_tests()
        
        # Return success/failure code
        if results.get("overall_status") == "completed":
            logger.info("🎉 Dashboard testing completed successfully!")
            return 0
        else:
            logger.error("💥 Dashboard testing failed!")
            return 1
            
    except Exception as e:
        logger.error(f"💥 Test runner failed: {e}")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())