#!/usr/bin/env python3
"""Performance testing for unified context system under load."""

import asyncio
import sys
import time
import json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import statistics

# Add src to path
sys.path.append('src')

from project_context.db.connections import get_db
from project_context.tools.discovery import get_project_summary, get_file_info, find_files, find_symbols
from project_context.tools.analysis import get_complexity, get_call_graph, get_imports
from project_context.tools.architecture import get_dependencies, get_data_models
from project_context.integrations.context_bridge import ContextBridge

class PerformanceMetrics:
    def __init__(self):
        self.response_times = []
        self.errors = 0
        self.successful_requests = 0
        self.concurrent_requests = 0
        self.throughput = 0
        self.memory_usage = 0

async def test_single_tool_performance(tool_name, tool_func, *args, **kwargs):
    """Test performance of a single tool."""
    start_time = time.perf_counter()
    try:
        result = await tool_func(*args, **kwargs)
        end_time = time.perf_counter()
        response_time = end_time - start_time
        
        # Calculate result size
        result_size = len(json.dumps(result, default=str)) if result else 0
        
        return {
            'tool': tool_name,
            'success': True,
            'response_time': response_time,
            'result_size': result_size,
            'error': None
        }
    except Exception as e:
        end_time = time.perf_counter()
        return {
            'tool': tool_name,
            'success': False,
            'response_time': end_time - start_time,
            'result_size': 0,
            'error': str(e)
        }

async def test_concurrent_requests(num_concurrent=10, iterations=5):
    """Test system performance under concurrent load."""
    print(f"🚀 Testing {num_concurrent} concurrent requests x {iterations} iterations...")
    
    # Define test scenarios
    test_scenarios = [
        ("get_project_summary", get_project_summary, []),
        ("get_file_info", get_file_info, ["src/project_context/server/main.py"]),
        ("get_complexity", get_complexity, [], {"threshold": 5.0}),
        ("get_imports", get_imports, []),
        ("get_dependencies", get_dependencies, []),
    ]
    
    all_results = []
    start_time = time.perf_counter()
    
    for iteration in range(iterations):
        print(f"  Iteration {iteration + 1}/{iterations}...", end=" ")
        
        # Create concurrent tasks
        tasks = []
        for i in range(num_concurrent):
            scenario = test_scenarios[i % len(test_scenarios)]
            tool_name, tool_func, args = scenario[0], scenario[1], scenario[2]
            kwargs = scenario[3] if len(scenario) > 3 else {}
            
            task = test_single_tool_performance(tool_name, tool_func, *args, **kwargs)
            tasks.append(task)
        
        # Execute concurrently
        iteration_start = time.perf_counter()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        iteration_end = time.perf_counter()
        
        # Process results
        successful = sum(1 for r in results if isinstance(r, dict) and r.get('success', False))
        print(f"{successful}/{num_concurrent} successful ({iteration_end - iteration_start:.2f}s)")
        
        all_results.extend([r for r in results if isinstance(r, dict)])
    
    total_time = time.perf_counter() - start_time
    
    return all_results, total_time

async def test_database_connection_pool():
    """Test database connection pool performance."""
    print("🗄️  Testing database connection pool performance...")
    
    db = await get_db()
    
    # Test PostgreSQL connection pool
    pg_times = []
    pg_errors = 0
    
    for i in range(20):
        start_time = time.perf_counter()
        try:
            result = await db.fetch_one("SELECT COUNT(*) as count FROM code_elements LIMIT 1")
            end_time = time.perf_counter()
            pg_times.append(end_time - start_time)
        except Exception as e:
            pg_errors += 1
            print(f"    PostgreSQL error {i+1}: {e}")
    
    # Test Redis connection pool
    redis_times = []
    redis_errors = 0
    
    if db.redis_client:
        for i in range(20):
            start_time = time.perf_counter()
            try:
                await db.redis_client.ping()
                end_time = time.perf_counter()
                redis_times.append(end_time - start_time)
            except Exception as e:
                redis_errors += 1
                print(f"    Redis error {i+1}: {e}")
    
    # Test Neo4j connection pool  
    neo4j_times = []
    neo4j_errors = 0
    
    if db.neo4j_driver:
        for i in range(10):  # Fewer iterations for Neo4j
            start_time = time.perf_counter()
            try:
                await db.run_cypher("RETURN 1 as test")
                end_time = time.perf_counter()
                neo4j_times.append(end_time - start_time)
            except Exception as e:
                neo4j_errors += 1
                print(f"    Neo4j error {i+1}: {e}")
    
    return {
        'postgresql': {
            'avg_time': statistics.mean(pg_times) if pg_times else 0,
            'min_time': min(pg_times) if pg_times else 0,
            'max_time': max(pg_times) if pg_times else 0,
            'errors': pg_errors,
            'success_rate': len(pg_times) / (len(pg_times) + pg_errors) if (len(pg_times) + pg_errors) > 0 else 0
        },
        'redis': {
            'avg_time': statistics.mean(redis_times) if redis_times else 0,
            'min_time': min(redis_times) if redis_times else 0,
            'max_time': max(redis_times) if redis_times else 0,
            'errors': redis_errors,
            'success_rate': len(redis_times) / (len(redis_times) + redis_errors) if (len(redis_times) + redis_errors) > 0 else 0
        },
        'neo4j': {
            'avg_time': statistics.mean(neo4j_times) if neo4j_times else 0,
            'min_time': min(neo4j_times) if neo4j_times else 0,
            'max_time': max(neo4j_times) if neo4j_times else 0,
            'errors': neo4j_errors,
            'success_rate': len(neo4j_times) / (len(neo4j_times) + neo4j_errors) if (len(neo4j_times) + neo4j_errors) > 0 else 0
        }
    }

async def test_memory_usage():
    """Test memory usage patterns."""
    print("💾 Testing memory usage patterns...")
    
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    initial_memory = process.memory_info().rss / 1024 / 1024  # MB
    
    # Perform memory-intensive operations
    db = await get_db()
    
    # Large query test
    try:
        start_memory = process.memory_info().rss / 1024 / 1024
        large_result = await db.fetch_many("SELECT * FROM code_elements LIMIT 1000")
        end_memory = process.memory_info().rss / 1024 / 1024
        
        large_query_memory_delta = end_memory - start_memory
        print(f"    Large query memory impact: +{large_query_memory_delta:.1f}MB")
        
    except Exception as e:
        print(f"    Large query test failed: {e}")
        large_query_memory_delta = 0
    
    # Context Bridge memory test
    try:
        start_memory = process.memory_info().rss / 1024 / 1024
        bridge = ContextBridge()
        context = await bridge.get_current_context()
        end_memory = process.memory_info().rss / 1024 / 1024
        
        bridge_memory_delta = end_memory - start_memory
        print(f"    Context Bridge memory impact: +{bridge_memory_delta:.1f}MB")
        
    except Exception as e:
        print(f"    Context Bridge test failed: {e}")
        bridge_memory_delta = 0
    
    final_memory = process.memory_info().rss / 1024 / 1024
    total_memory_delta = final_memory - initial_memory
    
    return {
        'initial_memory_mb': initial_memory,
        'final_memory_mb': final_memory,
        'total_delta_mb': total_memory_delta,
        'large_query_delta_mb': large_query_memory_delta,
        'bridge_delta_mb': bridge_memory_delta
    }

async def run_performance_tests():
    """Run comprehensive performance testing."""
    print("⚡ Starting Performance Testing Suite")
    print("=" * 60)
    
    # Test 1: Concurrent requests
    concurrent_results, total_time = await test_concurrent_requests(num_concurrent=5, iterations=3)
    
    # Test 2: Database connection pools
    db_performance = await test_database_connection_pool()
    
    # Test 3: Memory usage
    memory_metrics = await test_memory_usage()
    
    # Analyze results
    print(f"\n📊 Performance Test Results:")
    print("=" * 60)
    
    # Concurrent request analysis
    successful_requests = sum(1 for r in concurrent_results if r.get('success', False))
    total_requests = len(concurrent_results)
    success_rate = successful_requests / total_requests if total_requests > 0 else 0
    
    response_times = [r['response_time'] for r in concurrent_results if r.get('success', False)]
    
    if response_times:
        avg_response_time = statistics.mean(response_times)
        p95_response_time = sorted(response_times)[int(len(response_times) * 0.95)]
        throughput = successful_requests / total_time
        
        print(f"\n🚀 Concurrent Request Performance:")
        print(f"  Total Requests: {total_requests}")
        print(f"  Successful: {successful_requests} ({success_rate:.1%})")
        print(f"  Average Response Time: {avg_response_time:.3f}s")
        print(f"  95th Percentile: {p95_response_time:.3f}s")
        print(f"  Throughput: {throughput:.1f} requests/second")
    
    # Database performance analysis
    print(f"\n🗄️  Database Connection Pool Performance:")
    for db_name, metrics in db_performance.items():
        if metrics['success_rate'] > 0:
            print(f"  {db_name.title()}:")
            print(f"    Success Rate: {metrics['success_rate']:.1%}")
            print(f"    Avg Response: {metrics['avg_time']*1000:.1f}ms")
            print(f"    Range: {metrics['min_time']*1000:.1f}ms - {metrics['max_time']*1000:.1f}ms")
            print(f"    Errors: {metrics['errors']}")
    
    # Memory usage analysis
    print(f"\n💾 Memory Usage Analysis:")
    print(f"  Initial Memory: {memory_metrics['initial_memory_mb']:.1f}MB")
    print(f"  Final Memory: {memory_metrics['final_memory_mb']:.1f}MB")
    print(f"  Total Memory Delta: {memory_metrics['total_delta_mb']:+.1f}MB")
    print(f"  Large Query Impact: {memory_metrics['large_query_delta_mb']:+.1f}MB")
    print(f"  Context Bridge Impact: {memory_metrics['bridge_delta_mb']:+.1f}MB")
    
    # Performance assessment
    print(f"\n🎯 Performance Assessment:")
    
    performance_issues = []
    
    if success_rate < 0.95:
        performance_issues.append(f"Low success rate: {success_rate:.1%}")
    
    if response_times and avg_response_time > 5.0:
        performance_issues.append(f"High average response time: {avg_response_time:.1f}s")
    
    if memory_metrics['total_delta_mb'] > 100:
        performance_issues.append(f"High memory usage: +{memory_metrics['total_delta_mb']:.1f}MB")
    
    if any(db_performance[db]['success_rate'] < 0.95 for db in db_performance):
        performance_issues.append("Database connection issues detected")
    
    if not performance_issues:
        print("  ✅ EXCELLENT: System performing well under load")
        assessment = "excellent"
    elif len(performance_issues) <= 2:
        print(f"  ⚠️  GOOD: Minor performance issues detected")
        for issue in performance_issues:
            print(f"    - {issue}")
        assessment = "good"
    else:
        print(f"  ❌ POOR: Multiple performance issues detected")
        for issue in performance_issues:
            print(f"    - {issue}")
        assessment = "poor"
    
    # Save detailed results
    report = {
        'timestamp': time.time(),
        'concurrent_requests': {
            'total_requests': total_requests,
            'successful_requests': successful_requests,
            'success_rate': success_rate,
            'avg_response_time': avg_response_time if response_times else 0,
            'p95_response_time': p95_response_time if response_times else 0,
            'throughput': throughput if response_times else 0
        },
        'database_performance': db_performance,
        'memory_metrics': memory_metrics,
        'performance_assessment': assessment,
        'issues': performance_issues
    }
    
    report_file = f"PERFORMANCE_TEST_REPORT_{int(time.time())}.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"\n💾 Detailed performance report saved to: {report_file}")
    
    return assessment in ['excellent', 'good']

if __name__ == "__main__":
    success = asyncio.run(run_performance_tests())
    exit(0 if success else 1)