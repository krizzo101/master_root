#!/usr/bin/env python3
"""
Comprehensive Phase 1 Testing Suite
Executes all tests with detailed reporting and coverage analysis.
"""

import asyncio
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

class TestRunner:
    """Manages comprehensive testing execution and reporting."""
    
    def __init__(self):
        self.results = {
            "start_time": datetime.now().isoformat(),
            "test_suites": {},
            "coverage": {},
            "performance": {},
            "errors": []
        }
        self.project_root = Path(__file__).parent
        
    def run_test_suite(self, test_file: str, suite_name: str) -> Dict[str, Any]:
        """Run a specific test suite and capture results."""
        print(f"\n{'='*60}")
        print(f"Running {suite_name}: {test_file}")
        print(f"{'='*60}")
        
        try:
            start_time = time.time()
            result = subprocess.run([
                sys.executable, "-m", "pytest", 
                test_file, 
                "-v", 
                "--tb=short",
                "--no-header",
                "--disable-warnings"
            ], capture_output=True, text=True, timeout=300)
            
            duration = time.time() - start_time
            
            suite_result = {
                "duration": duration,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "passed": result.returncode == 0
            }
            
            # Parse test results
            if result.stdout:
                lines = result.stdout.split('\n')
                passed_count = sum(1 for line in lines if " PASSED " in line)
                failed_count = sum(1 for line in lines if " FAILED " in line)
                skipped_count = sum(1 for line in lines if " SKIPPED " in line)
                
                suite_result.update({
                    "passed_tests": passed_count,
                    "failed_tests": failed_count,
                    "skipped_tests": skipped_count,
                    "total_tests": passed_count + failed_count + skipped_count
                })
            
            print(f"✓ Suite completed in {duration:.2f}s")
            if not suite_result["passed"]:
                print(f"✗ {suite_result.get('failed_tests', 0)} tests failed")
                print("STDERR:", result.stderr[:500])
                
            return suite_result
            
        except subprocess.TimeoutExpired:
            return {
                "duration": 300,
                "returncode": -1,
                "error": "Test suite timed out after 5 minutes",
                "passed": False
            }
        except Exception as e:
            return {
                "duration": 0,
                "returncode": -1,
                "error": str(e),
                "passed": False
            }
    
    def run_all_unit_tests(self):
        """Run all unit tests in the tests/ directory."""
        test_files = [
            ("tests/test_chat_adapter.py", "Chat Adapter Unit Tests"),
            ("tests/test_code_adapter.py", "Code Adapter Unit Tests"), 
            ("tests/test_tools.py", "Tools Unit Tests")
        ]
        
        for test_file, suite_name in test_files:
            if (self.project_root / test_file).exists():
                self.results["test_suites"][suite_name] = self.run_test_suite(test_file, suite_name)
            else:
                print(f"⚠️ Test file not found: {test_file}")
                
    def run_integration_tests(self):
        """Run integration and cross-component tests."""
        integration_tests = [
            ("test_cross_component.py", "Cross-Component Integration Tests"),
            ("test_chat_integration.py", "Chat Integration Tests"),
            ("examples/test_code_intel_integration.py", "Code Intelligence Integration Tests")
        ]
        
        for test_file, suite_name in integration_tests:
            if (self.project_root / test_file).exists():
                self.results["test_suites"][suite_name] = self.run_test_suite(test_file, suite_name)
                
    def run_performance_tests(self):
        """Run performance and load tests."""
        perf_tests = [
            ("test_performance.py", "Performance Tests"),
            ("test_cache_system.py", "Cache System Performance Tests")
        ]
        
        for test_file, suite_name in perf_tests:
            if (self.project_root / test_file).exists():
                self.results["test_suites"][suite_name] = self.run_test_suite(test_file, suite_name)
                
    def run_mcp_tool_tests(self):
        """Run MCP tool integration tests."""
        mcp_tests = [
            ("test_all_21_tools.py", "All MCP Tools Test"),
            ("test_tools.py", "Core Tools Test"),
            ("test_context_bridge.py", "Context Bridge Test")
        ]
        
        for test_file, suite_name in mcp_tests:
            if (self.project_root / test_file).exists():
                self.results["test_suites"][suite_name] = self.run_test_suite(test_file, suite_name)
                
    def run_database_tests(self):
        """Run database validation and integrity tests."""
        db_tests = [
            ("test_session_ids.py", "Session ID Deterministic Tests"),
            ("test_dependencies.py", "Database Dependencies Tests")
        ]
        
        for test_file, suite_name in db_tests:
            if (self.project_root / test_file).exists():
                self.results["test_suites"][suite_name] = self.run_test_suite(test_file, suite_name)
                
    def generate_report(self):
        """Generate comprehensive test report."""
        self.results["end_time"] = datetime.now().isoformat()
        
        # Calculate summary statistics
        total_passed = sum(suite.get("passed_tests", 0) for suite in self.results["test_suites"].values())
        total_failed = sum(suite.get("failed_tests", 0) for suite in self.results["test_suites"].values())
        total_skipped = sum(suite.get("skipped_tests", 0) for suite in self.results["test_suites"].values())
        total_duration = sum(suite.get("duration", 0) for suite in self.results["test_suites"].values())
        
        successful_suites = sum(1 for suite in self.results["test_suites"].values() if suite.get("passed", False))
        total_suites = len(self.results["test_suites"])
        
        print(f"\n{'='*80}")
        print(f"COMPREHENSIVE PHASE 1 TEST REPORT")
        print(f"{'='*80}")
        print(f"Generated: {self.results['end_time']}")
        print(f"Total Duration: {total_duration:.2f} seconds")
        print(f"\nSUMMARY:")
        print(f"  Test Suites: {successful_suites}/{total_suites} passed")
        print(f"  Individual Tests: {total_passed} passed, {total_failed} failed, {total_skipped} skipped")
        print(f"  Total Tests: {total_passed + total_failed + total_skipped}")
        
        if total_failed == 0 and successful_suites == total_suites:
            print(f"\n✅ ALL TESTS PASSED - Phase 1 implementation is READY")
        else:
            print(f"\n❌ {total_failed} tests failed, {total_suites - successful_suites} suites failed")
            
        print(f"\nDETAILED RESULTS:")
        for suite_name, results in self.results["test_suites"].items():
            status = "✅ PASS" if results.get("passed", False) else "❌ FAIL"
            duration = results.get("duration", 0)
            test_count = results.get("total_tests", 0)
            print(f"  {status} {suite_name}: {test_count} tests in {duration:.2f}s")
            
            if not results.get("passed", False) and results.get("error"):
                print(f"    Error: {results['error']}")
                
        # Save detailed results to file
        report_file = self.project_root / "test_results_phase1.json"
        with open(report_file, "w") as f:
            json.dump(self.results, f, indent=2)
        print(f"\nDetailed results saved to: {report_file}")
        
        return total_failed == 0 and successful_suites == total_suites

def main():
    """Main test execution function."""
    print("Starting Comprehensive Phase 1 Testing...")
    
    runner = TestRunner()
    
    # Execute all test categories
    print("\n1. Running Unit Tests...")
    runner.run_all_unit_tests()
    
    print("\n2. Running Integration Tests...")
    runner.run_integration_tests()
    
    print("\n3. Running Performance Tests...")
    runner.run_performance_tests()
    
    print("\n4. Running MCP Tool Tests...")
    runner.run_mcp_tool_tests()
    
    print("\n5. Running Database Tests...")
    runner.run_database_tests()
    
    # Generate final report
    success = runner.generate_report()
    
    if success:
        print(f"\n🎉 PHASE 1 COMPREHENSIVE TESTING COMPLETED SUCCESSFULLY!")
        print(f"✅ All systems validated and ready for production")
        sys.exit(0)
    else:
        print(f"\n⚠️  Some tests failed - Phase 1 needs attention")
        sys.exit(1)

if __name__ == "__main__":
    main()