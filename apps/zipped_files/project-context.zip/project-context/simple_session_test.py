#!/usr/bin/env python3
"""
Simple Session ID Test - validate generation logic
"""
import hashlib

def generate_deterministic_session_id(task_id: str, plan_id: str = "unified_context") -> str:
    """Generate deterministic session ID matching ExecutionPlanAdapter logic"""
    seed_string = f"{plan_id}-{task_id}"
    hash_obj = hashlib.md5(seed_string.encode())
    hex_str = hash_obj.hexdigest()
    # Format as proper UUID
    return f"{hex_str[:8]}-{hex_str[8:12]}-{hex_str[12:16]}-{hex_str[16:20]}-{hex_str[20:32]}"

def main():
    print("🧪 SIMPLE SESSION ID TEST")
    print("=" * 40)
    
    # Test Phase 2 task session IDs
    phase2_tasks = [
        "implement_base_pipeline",
        "implement_chat_adapter", 
        "implement_code_adapter",
        "research_cicd_integration",
        "implement_cicd_adapter"
    ]
    
    print("📋 Phase 2 Task → Session ID Mapping:")
    session_mappings = {}
    
    for task_id in phase2_tasks:
        session_id = generate_deterministic_session_id(task_id)
        session_mappings[task_id] = session_id
        print(f"   {task_id} → {session_id}")
    
    # Test reproducibility
    print("\n🔍 Reproducibility Test:")
    all_reproducible = True
    
    for task_id in phase2_tasks:
        session_id_1 = generate_deterministic_session_id(task_id)
        session_id_2 = generate_deterministic_session_id(task_id)
        
        if session_id_1 != session_id_2:
            print(f"   ❌ {task_id}: {session_id_1} ≠ {session_id_2}")
            all_reproducible = False
    
    if all_reproducible:
        print("   ✅ All session IDs are reproducible")
    
    # Test monitoring commands
    print("\n💡 MONITORING COMMANDS:")
    print("For any Phase 2 task, you can monitor with:")
    
    sample_task = phase2_tasks[0]
    sample_session = session_mappings[sample_task]
    
    print(f"\n   Task: {sample_task}")
    print(f"   Session ID: {sample_session}")
    print(f"   Monitor: tail -f ~/.claude/projects/*/{sample_session}.jsonl")
    print(f"   Analyze: cat ~/.claude/projects/*/{sample_session}.jsonl | jq '.'")
    
    print("\n🎯 VALIDATION RESULT:")
    if all_reproducible:
        print("   ✅ Session ID generation is working correctly")
        print("   🚀 Ready for full testing with: python test_session_ids.py")
        return True
    else:
        print("   ❌ Session ID generation has issues")
        return False

if __name__ == "__main__":
    success = main()
    print()
    if success:
        print("✅ Ready to proceed with Phase 2 execution using deterministic session IDs!")
    else:
        print("❌ Fix session ID issues before proceeding")