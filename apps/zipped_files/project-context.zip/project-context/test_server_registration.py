#!/usr/bin/env python3
"""Test script to verify MCP server tool registration."""

import sys
import traceback
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

def test_imports():
    """Test that all tool modules can be imported."""
    try:
        from project_context.tools import register_all_tools
        print("✓ Successfully imported register_all_tools")
        
        # Test individual tool imports
        from project_context.tools.analysis import get_complexity, get_call_graph, get_imports, get_documentation
        from project_context.tools.discovery import find_files, get_file_info, find_symbols, get_project_summary
        from project_context.tools.architecture import get_entry_points, find_agents, get_data_models, get_dependencies, get_api_endpoints
        from project_context.tools.quality import get_tests, get_config, get_quality_metrics
        from project_context.tools.maintenance import get_todos, validate_intelligence, get_security_issues
        from project_context.tools.change import get_recent_changes, search_code, search_files_by_content
        print("✓ Successfully imported all individual tools")
        
        return True
    except Exception as e:
        print(f"✗ Import failed: {e}")
        traceback.print_exc()
        return False

def test_server_initialization():
    """Test server initialization without running it."""
    try:
        from fastmcp import FastMCP
        print("✓ Successfully imported FastMCP")
        
        # Create a test MCP instance
        test_mcp = FastMCP(
            name="test-project-context",
            version="0.1.0", 
            description="Test MCP server"
        )
        
        # Test tool registration
        from project_context.tools import register_all_tools
        register_all_tools(test_mcp, None, None)
        print("✓ Successfully registered all tools with test MCP server")
        
        # Check registered tools
        tools = list(test_mcp._tools.keys())
        print(f"✓ Registered {len(tools)} tools:")
        for tool in sorted(tools):
            print(f"  - {tool}")
        
        expected_tools = {
            "get_complexity_tool", "get_call_graph_tool", "get_imports_tool", "get_documentation_tool",
            "find_files_tool", "find_symbols_tool", "get_file_info_tool", "get_project_summary_tool", 
            "get_entry_points_tool", "find_agents_tool", "get_data_models_tool", "get_dependencies_tool", "get_api_endpoints_tool",
            "get_tests_tool", "get_config_tool", "get_quality_metrics_tool",
            "get_todos_tool", "validate_intelligence_tool", "get_security_issues_tool",
            "get_recent_changes_tool", "search_code_tool", "search_files_by_content_tool"
        }
        
        registered_tools = set(tools)
        missing_tools = expected_tools - registered_tools
        extra_tools = registered_tools - expected_tools
        
        if missing_tools:
            print(f"⚠ Missing expected tools: {missing_tools}")
        if extra_tools:
            print(f"⚠ Extra tools registered: {extra_tools}")
        
        if len(registered_tools) == len(expected_tools) and not missing_tools:
            print("✓ All 22 expected tools are registered correctly")
            return True
        else:
            print(f"✗ Tool count mismatch: expected {len(expected_tools)}, got {len(registered_tools)}")
            return False
            
    except Exception as e:
        print(f"✗ Server initialization failed: {e}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("Testing Project Context MCP Server Registration")
    print("=" * 50)
    
    success = True
    success &= test_imports()
    print()
    success &= test_server_initialization()
    print()
    
    if success:
        print("✓ All tests passed! MCP server registration is working correctly.")
        sys.exit(0)
    else:
        print("✗ Some tests failed.")
        sys.exit(1)