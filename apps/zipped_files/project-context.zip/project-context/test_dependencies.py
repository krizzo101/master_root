#!/usr/bin/env python3
"""Quick test for get_dependencies function to validate syntax and imports."""

import asyncio
import sys
import os
from pathlib import Path

# Add the project source to Python path
project_root = Path(__file__).parent / "src"
sys.path.insert(0, str(project_root))

async def test_dependencies_syntax():
    """Test that get_dependencies function can be imported and has correct signature."""
    try:
        # Test import
        from project_context.tools.architecture import get_dependencies
        print("✅ Successfully imported get_dependencies function")
        
        # Test function signature (should be async)
        import inspect
        if inspect.iscoroutinefunction(get_dependencies):
            print("✅ get_dependencies is correctly defined as async function")
        else:
            print("❌ get_dependencies should be an async function")
            return False
        
        # Test function signature parameters
        sig = inspect.signature(get_dependencies)
        if len(sig.parameters) == 0:
            print("✅ get_dependencies has correct parameter signature (no parameters)")
        else:
            print(f"❌ get_dependencies should have no parameters, got: {list(sig.parameters.keys())}")
            return False
            
        print("✅ All syntax validation checks passed!")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except SyntaxError as e:
        print(f"❌ Syntax error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

async def main():
    """Run the test."""
    print("Testing get_dependencies implementation...")
    print("=" * 50)
    
    success = await test_dependencies_syntax()
    
    if success:
        print("\n🎉 Implementation validation successful!")
        print("\nFunction structure:")
        from project_context.tools.architecture import get_dependencies
        import inspect
        print(f"Function: {get_dependencies.__name__}")
        print(f"Signature: {inspect.signature(get_dependencies)}")
        print(f"Docstring: {get_dependencies.__doc__[:100]}..." if get_dependencies.__doc__ else "No docstring")
    else:
        print("\n❌ Implementation validation failed!")
        return 1
    
    return 0

if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(result)