#!/usr/bin/env python3
"""Test script for the find_files MCP tool."""

import asyncio
import sys
from pathlib import Path

# Add the src directory to Python path
sys.path.append(str(Path(__file__).parent / "src"))

from project_context.tools.discovery import find_files

async def test_find_files_implementation():
    """Test the find_files function with various scenarios."""
    
    print("🧪 Testing find_files MCP tool implementation...")
    
    # Test 1: Basic functionality
    print("\n1. Testing basic pattern search (*.py)...")
    try:
        result = await find_files(pattern="*.py", limit=5)
        
        if result.get('success'):
            print(f"   ✅ Success: Found {result['summary']['total_files']} Python files")
            if result['files']:
                print(f"   📁 Sample file: {result['files'][0]['file_path']}")
        else:
            print(f"   ❌ Failed: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"   💥 Exception: {e}")
    
    # Test 2: File type filter
    print("\n2. Testing file type filter (file_type='py')...")
    try:
        result = await find_files(file_type="py", limit=3)
        
        if result.get('success'):
            print(f"   ✅ Success: Found {result['summary']['total_files']} files with .py extension")
        else:
            print(f"   ❌ Failed: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"   💥 Exception: {e}")
    
    # Test 3: Element type filter 
    print("\n3. Testing element type filter (element_type='function')...")
    try:
        result = await find_files(element_type="function", limit=3)
        
        if result.get('success'):
            files_count = result['summary']['total_files']
            print(f"   ✅ Success: Found {files_count} files containing functions")
            if result['files']:
                sample = result['files'][0]
                print(f"   📊 Sample: {sample['file_path']} has {sample['element_count']} elements")
        else:
            print(f"   ❌ Failed: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"   💥 Exception: {e}")
    
    # Test 4: Combined filters
    print("\n4. Testing combined filters (pattern='src/**', language='python')...")
    try:
        result = await find_files(pattern="src/*", language="python", limit=5)
        
        if result.get('success'):
            print(f"   ✅ Success: Found {result['summary']['total_files']} Python files in src/")
            print(f"   🏷️  Languages: {result['summary']['languages']}")
        else:
            print(f"   ❌ Failed: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"   💥 Exception: {e}")
    
    # Test 5: Error handling with invalid pattern
    print("\n5. Testing error handling with edge cases...")
    try:
        result = await find_files(pattern="", limit=1)
        
        if result.get('success') is not False:  # Should handle empty pattern gracefully
            print("   ✅ Success: Empty pattern handled gracefully")
        else:
            print(f"   ℹ️  Expected behavior: {result.get('error', 'Empty pattern error')}")
            
    except Exception as e:
        print(f"   💥 Exception (expected): {e}")
    
    print("\n🎯 Testing complete!")
    

if __name__ == "__main__":
    asyncio.run(test_find_files_implementation())