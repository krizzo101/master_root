#!/usr/bin/env python3
"""Quick test of implemented project-context tools."""

import asyncio
import sys
from pathlib import Path

# Add the project to the path
sys.path.append(str(Path(__file__).parent / "src"))

from project_context.db.connections import get_db
from project_context.tools.discovery import get_project_summary

async def test_tools():
    """Test basic functionality of implemented tools."""
    print("🧪 Testing Project Context Tools\n")
    
    # Test database connection
    try:
        db = await get_db()
        print("✅ Database connection established")
        
        # Test a simple query
        result = await db.fetch_one("SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = 'public'")
        print(f"✅ Found {result['count']} tables in database")
        
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return
    
    # Test get_project_summary tool
    try:
        print("\n📊 Testing get_project_summary...")
        summary = await get_project_summary()
        print(f"✅ Project summary generated: {len(summary)} characters")
        print(f"   Sample: {summary[:200]}...")
        
    except Exception as e:
        print(f"❌ get_project_summary failed: {e}")
    
    print("\n✅ Tool testing complete!")

if __name__ == "__main__":
    asyncio.run(test_tools())