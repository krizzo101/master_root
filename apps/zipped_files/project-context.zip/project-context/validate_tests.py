#!/usr/bin/env python3
"""
Phase 1 Test Validation
Validates test files and provides comprehensive analysis without execution.
"""

import ast
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Set

class TestValidator:
    """Validates test files and analyzes test coverage."""
    
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.validation_results = {
            "test_files_found": [],
            "test_functions_found": {},
            "coverage_analysis": {},
            "validation_errors": [],
            "recommendations": []
        }
        
    def find_test_files(self) -> List[Path]:
        """Find all test files in the project."""
        test_files = []
        
        # Find test files in various locations
        patterns = ["test_*.py", "*_test.py"]
        locations = [
            self.project_root,
            self.project_root / "tests",
            self.project_root / "examples"
        ]
        
        for location in locations:
            if location.exists():
                for pattern in patterns:
                    test_files.extend(location.glob(pattern))
                    test_files.extend(location.rglob(pattern))
        
        # Remove duplicates
        return list(set(test_files))
        
    def analyze_test_file(self, test_file: Path) -> Dict[str, Any]:
        """Analyze a test file for functions, classes, and coverage."""
        try:
            with open(test_file, 'r') as f:
                content = f.read()
                
            tree = ast.parse(content)
            
            analysis = {
                "file_path": str(test_file),
                "test_functions": [],
                "test_classes": [],
                "imports": [],
                "fixtures": [],
                "async_tests": [],
                "syntax_valid": True,
                "line_count": len(content.split('\n'))
            }
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if node.name.startswith('test_'):
                        analysis["test_functions"].append(node.name)
                        if any(isinstance(decorator, ast.Name) and 
                              getattr(decorator, 'id', '') == 'pytest' for decorator in node.decorator_list):
                            analysis["fixtures"].append(node.name)
                    if asyncio_in_decorators(node):
                        analysis["async_tests"].append(node.name)
                        
                elif isinstance(node, ast.ClassDef):
                    if node.name.startswith('Test'):
                        analysis["test_classes"].append(node.name)
                        
                elif isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            analysis["imports"].append(alias.name)
                    else:
                        analysis["imports"].append(node.module or "")
                        
            return analysis
            
        except SyntaxError as e:
            return {
                "file_path": str(test_file),
                "syntax_valid": False,
                "syntax_error": str(e),
                "test_functions": [],
                "test_classes": []
            }
        except Exception as e:
            return {
                "file_path": str(test_file),
                "syntax_valid": False,
                "error": str(e),
                "test_functions": [],
                "test_classes": []
            }
    
    def analyze_coverage_areas(self):
        """Analyze what areas of the codebase are covered by tests."""
        src_dir = self.project_root / "src" / "project_context"
        
        if not src_dir.exists():
            return
            
        # Find all Python files in src
        py_files = list(src_dir.rglob("*.py"))
        
        coverage_areas = {
            "adapters": [],
            "tools": [],
            "models": [],
            "server": [],
            "ingestion": [],
            "db": []
        }
        
        for py_file in py_files:
            rel_path = py_file.relative_to(src_dir)
            parts = rel_path.parts
            
            if "adapters" in parts:
                coverage_areas["adapters"].append(str(rel_path))
            elif "tools" in parts:
                coverage_areas["tools"].append(str(rel_path))
            elif "models" in parts:
                coverage_areas["models"].append(str(rel_path))
            elif "server" in parts:
                coverage_areas["server"].append(str(rel_path))
            elif "ingestion" in parts:
                coverage_areas["ingestion"].append(str(rel_path))
            elif "db" in parts:
                coverage_areas["db"].append(str(rel_path))
                
        self.validation_results["coverage_analysis"] = coverage_areas
        
    def validate_all_tests(self):
        """Validate all test files found."""
        test_files = self.find_test_files()
        
        print(f"Found {len(test_files)} test files")
        
        self.validation_results["test_files_found"] = [str(f) for f in test_files]
        
        total_test_functions = 0
        total_test_classes = 0
        
        for test_file in test_files:
            print(f"Analyzing: {test_file.name}")
            analysis = self.analyze_test_file(test_file)
            
            if not analysis["syntax_valid"]:
                self.validation_results["validation_errors"].append({
                    "file": str(test_file),
                    "error": analysis.get("error", analysis.get("syntax_error", "Unknown error"))
                })
                continue
                
            self.validation_results["test_functions_found"][str(test_file)] = analysis
            total_test_functions += len(analysis["test_functions"])
            total_test_classes += len(analysis["test_classes"])
            
            # Print summary for each file
            print(f"  ✓ {len(analysis['test_functions'])} test functions")
            print(f"  ✓ {len(analysis['test_classes'])} test classes")
            print(f"  ✓ {len(analysis['async_tests'])} async tests")
            print(f"  ✓ {analysis['line_count']} lines")
            
        print(f"\nTOTAL TEST COVERAGE:")
        print(f"  Test Functions: {total_test_functions}")
        print(f"  Test Classes: {total_test_classes}")
        print(f"  Test Files: {len(test_files)}")
        
        # Analyze coverage areas
        self.analyze_coverage_areas()
        
        # Generate recommendations
        self.generate_recommendations()
        
    def generate_recommendations(self):
        """Generate recommendations based on analysis."""
        recommendations = []
        
        # Check for critical test coverage
        critical_areas = ["chat_adapter", "code_adapter", "tools", "database", "mcp_integration"]
        
        for area in critical_areas:
            found_tests = any(area in str(test_file).lower() 
                            for test_file in self.validation_results["test_files_found"])
            if not found_tests:
                recommendations.append(f"Missing tests for critical area: {area}")
                
        # Check for async test coverage
        async_test_count = sum(len(analysis.get("async_tests", [])) 
                             for analysis in self.validation_results["test_functions_found"].values())
        if async_test_count < 5:
            recommendations.append("Consider adding more async tests for async functionality")
            
        # Check for integration tests
        integration_tests = [f for f in self.validation_results["test_files_found"] 
                           if "integration" in f.lower() or "cross_component" in f.lower()]
        if len(integration_tests) < 2:
            recommendations.append("Consider adding more integration tests")
            
        self.validation_results["recommendations"] = recommendations
        
    def print_detailed_report(self):
        """Print detailed validation report."""
        print(f"\n{'='*80}")
        print("PHASE 1 TEST VALIDATION REPORT")
        print(f"{'='*80}")
        
        print(f"\nTEST FILES SUMMARY:")
        for test_file in self.validation_results["test_files_found"]:
            print(f"  ✓ {Path(test_file).name}")
            
        print(f"\nCOVERAGE AREAS ANALYSIS:")
        for area, files in self.validation_results["coverage_analysis"].items():
            print(f"  {area.upper()}: {len(files)} files")
            
        if self.validation_results["validation_errors"]:
            print(f"\n❌ VALIDATION ERRORS:")
            for error in self.validation_results["validation_errors"]:
                print(f"  {error['file']}: {error['error']}")
                
        if self.validation_results["recommendations"]:
            print(f"\n💡 RECOMMENDATIONS:")
            for rec in self.validation_results["recommendations"]:
                print(f"  • {rec}")
                
        # Overall assessment
        error_count = len(self.validation_results["validation_errors"])
        test_file_count = len(self.validation_results["test_files_found"])
        total_functions = sum(len(analysis.get("test_functions", [])) 
                            for analysis in self.validation_results["test_functions_found"].values())
        
        print(f"\n{'='*80}")
        print("OVERALL ASSESSMENT")
        print(f"{'='*80}")
        
        if error_count == 0 and test_file_count >= 10 and total_functions >= 50:
            print("✅ EXCELLENT: Comprehensive test suite with good coverage")
            status = "READY"
        elif error_count == 0 and test_file_count >= 5 and total_functions >= 20:
            print("✅ GOOD: Solid test coverage, Phase 1 ready")
            status = "READY"
        elif error_count == 0:
            print("⚠️  BASIC: Minimal test coverage, consider expanding")
            status = "NEEDS_IMPROVEMENT"
        else:
            print("❌ ISSUES: Test validation errors need attention")
            status = "NEEDS_FIXES"
            
        print(f"Status: {status}")
        print(f"Test Files: {test_file_count}")
        print(f"Test Functions: {total_functions}")
        print(f"Validation Errors: {error_count}")
        
        return status

def asyncio_in_decorators(node):
    """Check if function has async-related decorators."""
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Name) and decorator.id in ['asyncio', 'pytest_asyncio']:
            return True
        elif isinstance(decorator, ast.Attribute) and decorator.attr == 'asyncio':
            return True
    return False

def main():
    """Main validation function."""
    print("Starting Phase 1 Test Validation...")
    
    validator = TestValidator()
    validator.validate_all_tests()
    status = validator.print_detailed_report()
    
    # Save results
    results_file = validator.project_root / "test_validation_results.json"
    with open(results_file, 'w') as f:
        json.dump(validator.validation_results, f, indent=2)
    print(f"\nDetailed validation results saved to: {results_file}")
    
    if status in ["READY", "GOOD"]:
        print("\n🎉 Phase 1 testing validation PASSED!")
        return True
    else:
        print("\n⚠️ Phase 1 testing needs attention")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)