#!/usr/bin/env python3
"""Test script for Context Bridge integration."""

import asyncio
import json
from src.project_context.integrations.context_bridge import (
    ContextBridge, 
    IDEContext,
    initialize_context_bridge
)

async def test_context_bridge():
    """Test the Context Bridge integration."""
    print("🔄 Testing Context Bridge Integration...")
    
    # Initialize context bridge
    bridge = await initialize_context_bridge()
    
    # Test context setting and retrieval
    test_context = IDEContext(
        active_file="/test/file.py",
        project_root="/test/project",
        language="python",
        git_branch="main"
    )
    
    print(f"📝 Setting test context: {test_context.active_file}")
    await bridge.set_context(test_context)
    
    # Retrieve context
    current_context = await bridge.get_current_context()
    print(f"📖 Retrieved context: {current_context.active_file if current_context else 'None'}")
    
    # Test context merging with mock query results
    mock_results = [
        {"file_path": "/test/file.py", "function": "test_func", "line": 42},
        {"file_path": "/test/other.py", "function": "other_func", "line": 24}
    ]
    
    merged = bridge.merge_with_query_results(mock_results)
    print(f"🔗 Merged results contain {merged['result_count']} items")
    print(f"🎯 Context relevance: {merged.get('context_relevance', {}).get('file_matches', 0)} file matches")
    
    # Get context summary
    summary = await bridge.get_context_summary()
    print(f"📊 Bridge status: {summary['bridge_status']}")
    print(f"📊 Has context: {summary['has_context']}")
    print(f"📊 Redis available: {summary['redis_available']}")
    
    print("✅ Context Bridge integration test completed!")

if __name__ == "__main__":
    asyncio.run(test_context_bridge())