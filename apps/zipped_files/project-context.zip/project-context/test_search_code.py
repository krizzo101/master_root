#!/usr/bin/env python3
"""Test script for the search_code function."""

import asyncio
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / 'src'))

async def test_search_code():
    """Test the search_code function with various parameters."""
    try:
        from project_context.tools.maintenance import search_code
        
        print("Testing search_code function...")
        
        # Test basic search
        print("\n1. Testing basic search for 'async':")
        result = await search_code("async", max_results=5)
        
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Found {result['statistics']['total_matches']} matches")
            print(f"Search time: {result['statistics']['search_time_ms']}ms")
            print(f"Suggestions: {result['suggestions']}")
            
            if result["matches"]:
                print("Sample matches:")
                for match in result["matches"][:3]:
                    print(f"  - {match.get('element_name', 'N/A')} in {match.get('file_path', 'N/A')} (type: {match.get('element_type', 'N/A')})")
        
        # Test with filters
        print("\n2. Testing search with language filter:")
        result = await search_code("def", language="python", element_type="function", max_results=3)
        
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Found {result['statistics']['total_matches']} Python functions")
            
        # Test with time range (if data exists)
        print("\n3. Testing search with time range (last 24 hours):")
        result = await search_code("", time_range_hours=24, max_results=5)
        
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Found {result['statistics']['total_matches']} recent matches")
            if result["time_series_data"]:
                print(f"Time series data: {len(result['time_series_data'].get('hourly_activity', []))} hourly entries")
        
        print("\nTesting completed successfully!")
        
    except Exception as e:
        print(f"Test failed with exception: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_search_code())