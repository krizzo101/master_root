#!/usr/bin/env python3
"""
Test PracticalOrchestrator with minimal single task to isolate hanging issue
"""
import asyncio
import sys
from pathlib import Path

sys.path.append("/home/opsvi/master_root/apps/agent-orchestrator/src")
from practical_orchestrator import PracticalAgentTask, PracticalOrchestrator

async def test_simple():
    """Test PracticalOrchestrator with one tiny task"""
    
    orchestrator = PracticalOrchestrator(
        output_dir="/home/opsvi/master_root/apps/project-context/test_simple_output",
        max_parallel=1,
        enable_monitoring=True,
        enable_quality_reports=True,
        orchestrator_type="dashboard"  # For 6-token coordination
    )
    
    # Single tiny test task
    tasks = [
        PracticalAgentTask(
            task_id="tiny_test",
            task_type="general-purpose",
            prompt="Say hello and confirm this task is working. Output: 'Hello from dashboard coordination test!'",
            phase_id="test",
            priority="high",
            tags=["test"]
        )
    ]
    
    print(f"🧪 Testing PracticalOrchestrator with 1 tiny task")
    print(f"📁 Output: {orchestrator.output_dir}")
    print(f"🔗 Session ID: {tasks[0].session_id}")
    
    # Execute
    results = await orchestrator.execute_batch(tasks)
    
    print(f"✅ Result: {results}")
    
    return results

if __name__ == "__main__":
    asyncio.run(test_simple())