#!/usr/bin/env python3
"""Test script for the enhanced caching system."""

import asyncio
import tempfile
import time
from pathlib import Path

import sys
sys.path.insert(0, 'src')

from project_context.core.cache import CacheManager, cache_tool_result, set_cache_manager
from project_context.core.cache_watcher import CacheWatcher, project_invalidation_callback


async def test_basic_cache_operations():
    """Test basic cache operations."""
    print("Testing basic cache operations...")
    
    cache = CacheManager()
    
    # Test set and get
    await cache.set("test_key", "test_value", ttl=60)
    result = await cache.get("test_key")
    assert result == "test_value", f"Expected 'test_value', got {result}"
    print("✓ Basic set/get works")
    
    # Test file data caching
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("print('hello world')")
        temp_file = f.name
    
    await cache.set_file_data(temp_file, {"content": "test file data"})
    file_result = await cache.get_file_data(temp_file)
    assert file_result == {"content": "test file data"}, f"File data mismatch: {file_result}"
    print("✓ File data caching works")
    
    # Test project stats caching
    await cache.set_project_stats("complexity", {"avg": 5.2, "max": 15.0})
    stats_result = await cache.get_project_stats("complexity")
    assert stats_result == {"avg": 5.2, "max": 15.0}, f"Stats data mismatch: {stats_result}"
    print("✓ Project stats caching works")
    
    # Test cache stats
    stats = await cache.get_cache_stats()
    assert "default_ttl" in stats, f"Cache stats missing default_ttl: {stats}"
    assert stats["file_data_ttl"] == 60, f"Wrong file_data_ttl: {stats['file_data_ttl']}"
    assert stats["project_stats_ttl"] == 300, f"Wrong project_stats_ttl: {stats['project_stats_ttl']}"
    print("✓ Cache stats work")
    
    # Cleanup
    Path(temp_file).unlink()
    print("Basic cache operations test completed!\n")


async def test_cache_invalidation():
    """Test cache invalidation."""
    print("Testing cache invalidation...")
    
    cache = CacheManager()
    
    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("# Original content")
        temp_file = f.name
    
    # Cache the file data
    await cache.set_file_data(temp_file, {"content": "original data"})
    result = await cache.get_file_data(temp_file)
    assert result == {"content": "original data"}, "Initial cache failed"
    print("✓ Initial file caching works")
    
    # Modify the file (simulate file change)
    time.sleep(0.1)  # Ensure mtime changes
    with open(temp_file, 'w') as f:
        f.write("# Modified content")
    
    # Cache should detect modification and return None (cache miss)
    result = await cache.get_file_data(temp_file)
    assert result is None, f"Cache should have been invalidated, got {result}"
    print("✓ File modification invalidation works")
    
    # Test manual invalidation
    await cache.set_file_data(temp_file, {"content": "new cached data"})
    await cache.invalidate_file(temp_file)
    result = await cache.get_file_data(temp_file)
    assert result is None, "Manual invalidation failed"
    print("✓ Manual file invalidation works")
    
    # Cleanup
    Path(temp_file).unlink()
    print("Cache invalidation test completed!\n")


async def test_cache_decorator():
    """Test the cache decorator."""
    print("Testing cache decorator...")
    
    cache = CacheManager()
    
    # Test function with decorator
    call_count = 0
    
    @cache_tool_result(ttl=60, cache_type="default", key_prefix="test_")
    async def expensive_function(arg1: str, arg2: int = 10):
        nonlocal call_count
        call_count += 1
        await asyncio.sleep(0.01)  # Simulate work
        return {"result": f"{arg1}_{arg2}", "call_count": call_count}
    
    # Attach cache manager
    set_cache_manager(expensive_function, cache)
    
    # First call should execute function
    result1 = await expensive_function("test", 5)
    assert result1["call_count"] == 1, f"First call count wrong: {result1}"
    print("✓ First call executed function")
    
    # Second call with same args should hit cache
    result2 = await expensive_function("test", 5)
    assert result2["call_count"] == 1, f"Second call should hit cache: {result2}"
    print("✓ Second call hit cache")
    
    # Different args should execute function again
    result3 = await expensive_function("test", 6)
    assert result3["call_count"] == 2, f"Different args call count wrong: {result3}"
    print("✓ Different args executed function")
    
    print("Cache decorator test completed!\n")


async def test_file_watcher():
    """Test file watching for cache invalidation."""
    print("Testing file watcher...")
    
    cache = CacheManager()
    
    # Create temporary directory
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Initialize watcher
        watcher = CacheWatcher(
            cache_manager=cache,
            watch_paths={str(temp_path)},
            invalidation_callback=project_invalidation_callback
        )
        
        try:
            await watcher.start()
            print("✓ File watcher started")
            
            # Create a test file
            test_file = temp_path / "test.py"
            test_file.write_text("print('hello')")
            
            # Cache some data for this file
            await cache.set_file_data(str(test_file), {"content": "cached data"})
            result = await cache.get_file_data(str(test_file))
            assert result == {"content": "cached data"}, "Initial caching failed"
            print("✓ File data cached")
            
            # Give watcher time to detect changes
            await asyncio.sleep(0.1)
            
            # Modify the file
            test_file.write_text("print('modified')")
            
            # Give watcher time to process the change
            await asyncio.sleep(0.5)
            
            print("✓ File watcher test setup completed")
            
        finally:
            await watcher.stop()
            print("✓ File watcher stopped")
    
    print("File watcher test completed!\n")


async def run_all_tests():
    """Run all cache tests."""
    print("=== Enhanced Caching System Tests ===\n")
    
    try:
        await test_basic_cache_operations()
        await test_cache_invalidation()
        await test_cache_decorator()
        await test_file_watcher()
        
        print("=== All Tests Passed! ===")
        print("\nEnhanced caching system features:")
        print("✓ Async caching with aiocache")
        print("✓ TTL: 60s for file data, 300s for project stats")
        print("✓ Automatic cache invalidation on file changes")
        print("✓ Decorator for easy caching of tool results")
        print("✓ File system watching for real-time invalidation")
        print("✓ Project-specific invalidation logic")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(run_all_tests())