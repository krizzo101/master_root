#!/usr/bin/env python3
"""Test script for the enhanced code intelligence adapter with .proj-intel support."""

import asyncio
import json
import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from project_context.ingestion.adapters.code_adapter import CodeAdapter
from project_context.ingestion.base_adapter import AdapterConfig


async def test_code_intelligence_adapter():
    """Test the enhanced code intelligence adapter."""
    print("🚀 Testing Code Intelligence Adapter with .proj-intel Support")
    print("=" * 60)
    
    # Create adapter configuration with .proj-intel enabled
    config = AdapterConfig(
        adapter_id="test_code_intelligence",
        source_type="code",
        source_config={
            "scan_directories": ["/home/opsvi/master_root"],
            "enable_proj_intel": True,
            "proj_intel_paths": [".proj-intel"],
            "ingest_file_elements": True,
            "ingest_project_analysis": True,
            "ingest_symbol_index": True,
            "proj_intel_max_age_days": 30,  # Allow older data for testing
        }
    )
    
    # Create and initialize adapter
    adapter = CodeAdapter(config)
    
    try:
        print("📋 Initializing adapter...")
        await adapter.initialize()
        print("✅ Adapter initialized successfully")
        
        print("\n🔍 Testing .proj-intel data fetching...")
        
        # Fetch a limited number of items for testing
        items_fetched = 0
        intel_items = 0
        regular_items = 0
        
        async for item in adapter.fetch_items(limit=20):
            items_fetched += 1
            
            # Transform the item
            try:
                context_item = await adapter.transform_item(item)
                
                if item.get("intel_data_type"):
                    intel_items += 1
                    print(f"📊 Intel Item {intel_items}: {context_item.title}")
                    print(f"   Type: {item['intel_data_type']}")
                    print(f"   Entity: {context_item.entity_type}")
                    print(f"   Tags: {context_item.tags[:5]}...")
                    print(f"   Source: {context_item.source_type}")
                    
                    # Show some metrics for intel items
                    if context_item.metrics:
                        if item['intel_data_type'] == 'file_element':
                            functions = context_item.metrics.get('functions', [])
                            classes = context_item.metrics.get('classes', [])
                            print(f"   Functions: {len(functions)}, Classes: {len(classes)}")
                        elif item['intel_data_type'] == 'project_analysis':
                            collector = context_item.metrics.get('collector', 'unknown')
                            print(f"   Collector: {collector}")
                        elif item['intel_data_type'] == 'symbol':
                            symbol_type = context_item.metrics.get('symbol_type', 'unknown')
                            print(f"   Symbol Type: {symbol_type}")
                    
                    print()
                else:
                    regular_items += 1
                    if regular_items <= 3:  # Only show first few regular items
                        print(f"📄 Regular Item {regular_items}: {context_item.title}")
                        print(f"   Language: {context_item.metrics.get('language', 'unknown')}")
                        print(f"   Entity: {context_item.entity_type}")
                        print()
                        
                # Test relationship detection on first few items
                if items_fetched <= 5:
                    relationships = await adapter.detect_relationships(context_item, [])
                    if relationships:
                        print(f"🔗 Relationships found: {len(relationships)}")
                
            except Exception as e:
                print(f"❌ Error transforming item: {e}")
                print(f"   Item: {item}")
                
            if items_fetched >= 20:
                break
        
        print(f"\n📈 Summary:")
        print(f"   Total items fetched: {items_fetched}")
        print(f"   Intelligence items: {intel_items}")
        print(f"   Regular code items: {regular_items}")
        
        # Test specific .proj-intel data access
        print(f"\n🔎 Testing .proj-intel manifest access...")
        if adapter._proj_intel_manifest:
            print(f"✅ Manifest loaded successfully")
            print(f"   Schema version: {adapter._proj_intel_manifest.get('schema_version')}")
            print(f"   Generated at: {adapter._proj_intel_manifest.get('generated_at')}")
            print(f"   Shards: {len(adapter._proj_intel_manifest.get('shards', []))}")
            print(f"   Indices: {len(adapter._proj_intel_manifest.get('indices', []))}")
        else:
            print("⚠️  No manifest found (this may be normal if .proj-intel doesn't exist)")
            
        # Test cached data
        print(f"\n💾 Testing cached intelligence data...")
        if adapter._proj_intel_cache:
            for cache_key, cache_data in adapter._proj_intel_cache.items():
                print(f"   {cache_key}: {type(cache_data).__name__} with {len(cache_data) if isinstance(cache_data, (dict, list)) else 'N/A'} items")
        else:
            print("   No cached data")
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        try:
            await adapter.cleanup()
            print("✅ Adapter cleanup completed")
        except Exception as e:
            print(f"⚠️  Cleanup error: {e}")

    print("\n🎉 Test completed!")


if __name__ == "__main__":
    asyncio.run(test_code_intelligence_adapter())