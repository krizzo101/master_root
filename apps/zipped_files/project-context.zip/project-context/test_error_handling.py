#!/usr/bin/env python3
"""Test error handling and resilience in unified context system."""

import asyncio
import sys
import json
import time
from pathlib import Path

# Add src to path
sys.path.append('src')

from project_context.db.connections import get_db, db_connections
from project_context.tools.discovery import get_project_summary, get_file_info
from project_context.tools.analysis import get_complexity
from project_context.integrations.context_bridge import ContextBridge

async def test_database_failure_recovery():
    """Test system behavior when databases are unavailable."""
    print("🔧 Testing Database Failure Recovery...")
    
    results = {}
    
    # Test 1: PostgreSQL connection failure simulation
    print("  Testing PostgreSQL failure handling...", end=" ")
    try:
        # Temporarily corrupt the connection string
        original_dsn = db_connections.pg_dsn
        db_connections.pg_dsn = "postgresql://invalid_user:invalid_pass@localhost:5432/nonexistent_db"
        
        # Attempt to reconnect
        try:
            await db_connections.connect_postgres()
            results['pg_failure_handling'] = False
        except Exception:
            results['pg_failure_handling'] = True  # Expected to fail
            print("✅ (graceful failure)")
        
        # Restore connection
        db_connections.pg_dsn = original_dsn
        await db_connections.connect_postgres()
        
    except Exception as e:
        print(f"❌ ({e})")
        results['pg_failure_handling'] = False
    
    # Test 2: Redis connection failure simulation  
    print("  Testing Redis failure handling...", end=" ")
    try:
        # Test with invalid Redis connection
        original_host = db_connections.redis_host
        db_connections.redis_host = "invalid_host"
        
        await db_connections.connect_redis()
        
        # Should handle gracefully (Redis is optional)
        if db_connections.redis_client is None:
            results['redis_failure_handling'] = True
            print("✅ (graceful degradation)")
        else:
            results['redis_failure_handling'] = False
            print("❌ (should degrade gracefully)")
        
        # Restore connection
        db_connections.redis_host = original_host
        await db_connections.connect_redis()
        
    except Exception as e:
        print(f"❌ ({e})")
        results['redis_failure_handling'] = False
    
    # Test 3: Neo4j connection failure simulation
    print("  Testing Neo4j failure handling...", end=" ")
    try:
        # Test with invalid Neo4j connection
        original_uri = db_connections.neo4j_uri
        db_connections.neo4j_uri = "bolt://invalid_host:7687"
        
        await db_connections.connect_neo4j()
        
        # Should handle gracefully (Neo4j is optional)
        if db_connections.neo4j_driver is None:
            results['neo4j_failure_handling'] = True
            print("✅ (graceful degradation)")
        else:
            results['neo4j_failure_handling'] = False  
            print("❌ (should degrade gracefully)")
        
        # Restore connection
        db_connections.neo4j_uri = original_uri
        # Don't restore Neo4j as it has auth issues
        
    except Exception as e:
        print(f"❌ ({e})")
        results['neo4j_failure_handling'] = False
    
    return results

async def test_malformed_input_handling():
    """Test system behavior with malformed or edge case inputs."""
    print("🎭 Testing Malformed Input Handling...")
    
    results = {}
    
    # Test 1: Invalid file paths
    print("  Testing invalid file paths...", end=" ")
    try:
        result = await get_file_info("/nonexistent/path/file.py")
        # Should return graceful error response
        if isinstance(result, dict) and ('error' in result or 'exists' in result):
            results['invalid_file_path'] = True
            print("✅ (graceful error response)")
        else:
            results['invalid_file_path'] = False
            print("❌ (should handle gracefully)")
    except Exception as e:
        results['invalid_file_path'] = False
        print(f"❌ (unhandled exception: {e})")
    
    # Test 2: Very large threshold values
    print("  Testing extreme parameter values...", end=" ")
    try:
        result = await get_complexity(threshold=999999.0)
        # Should handle gracefully
        if isinstance(result, dict):
            results['extreme_parameters'] = True
            print("✅ (handled gracefully)")
        else:
            results['extreme_parameters'] = False
            print("❌ (should return dict)")
    except Exception as e:
        results['extreme_parameters'] = False
        print(f"❌ (unhandled exception: {e})")
    
    # Test 3: Empty string inputs
    print("  Testing empty string inputs...", end=" ")
    try:
        result = await get_file_info("")
        # Should handle gracefully
        if isinstance(result, dict):
            results['empty_string_input'] = True
            print("✅ (handled gracefully)")
        else:
            results['empty_string_input'] = False
            print("❌ (should return dict)")
    except Exception as e:
        results['empty_string_input'] = False
        print(f"❌ (unhandled exception: {e})")
    
    # Test 4: SQL injection attempts (should be prevented by parameterized queries)
    print("  Testing SQL injection prevention...", end=" ")
    try:
        malicious_input = "'; DROP TABLE code_elements; --"
        result = await get_file_info(malicious_input)
        # Should handle safely
        if isinstance(result, dict) and 'error' not in str(result).lower():
            results['sql_injection_prevention'] = True
            print("✅ (safely handled)")
        else:
            results['sql_injection_prevention'] = True  # Error is also acceptable
            print("✅ (safely rejected)")
    except Exception as e:
        # Exception is also acceptable for malicious input
        results['sql_injection_prevention'] = True
        print("✅ (safely rejected)")
    
    return results

async def test_concurrent_access_safety():
    """Test system safety under concurrent access patterns."""
    print("🔄 Testing Concurrent Access Safety...")
    
    results = {}
    
    # Test 1: Concurrent database queries
    print("  Testing concurrent database access...", end=" ")
    try:
        tasks = []
        for i in range(10):
            task = get_project_summary()
            tasks.append(task)
        
        start_time = time.time()
        results_list = await asyncio.gather(*tasks, return_exceptions=True)
        end_time = time.time()
        
        # Analyze results
        successful = sum(1 for r in results_list if isinstance(r, dict) and not isinstance(r, Exception))
        exceptions = sum(1 for r in results_list if isinstance(r, Exception))
        
        if successful >= 8 and exceptions <= 2:  # Allow some failures under high concurrency
            results['concurrent_db_access'] = True
            print(f"✅ ({successful}/10 successful, {end_time-start_time:.1f}s)")
        else:
            results['concurrent_db_access'] = False
            print(f"❌ ({successful}/10 successful, {exceptions} exceptions)")
            
    except Exception as e:
        results['concurrent_db_access'] = False
        print(f"❌ (failed: {e})")
    
    # Test 2: Context Bridge concurrent access
    print("  Testing Context Bridge concurrency...", end=" ")
    try:
        bridge = ContextBridge()
        
        # Concurrent context operations
        tasks = []
        for i in range(5):
            task = bridge.get_current_context()
            tasks.append(task)
        
        results_list = await asyncio.gather(*tasks, return_exceptions=True)
        
        successful = sum(1 for r in results_list if not isinstance(r, Exception))
        
        if successful >= 4:
            results['concurrent_context_access'] = True
            print(f"✅ ({successful}/5 successful)")
        else:
            results['concurrent_context_access'] = False
            print(f"❌ ({successful}/5 successful)")
            
    except Exception as e:
        results['concurrent_context_access'] = False
        print(f"❌ (failed: {e})")
    
    return results

async def test_memory_leak_detection():
    """Test for potential memory leaks during extended operation."""
    print("🧠 Testing Memory Leak Detection...")
    
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    initial_memory = process.memory_info().rss / 1024 / 1024  # MB
    
    print(f"  Initial memory usage: {initial_memory:.1f}MB")
    
    # Perform repeated operations
    print("  Running 50 iterations of various operations...", end=" ")
    
    try:
        for i in range(50):
            # Mix of different operations
            if i % 10 == 0:
                await get_project_summary()
            elif i % 10 == 1:
                await get_file_info("src/project_context/server/main.py")
            elif i % 10 == 2:
                await get_complexity(threshold=5.0)
            else:
                # Simple database operation
                db = await get_db()
                await db.fetch_one("SELECT COUNT(*) as count FROM code_elements LIMIT 1")
        
        final_memory = process.memory_info().rss / 1024 / 1024
        memory_growth = final_memory - initial_memory
        
        print(f"✅ Complete")
        print(f"  Final memory usage: {final_memory:.1f}MB")
        print(f"  Memory growth: {memory_growth:+.1f}MB")
        
        # Memory growth assessment
        if memory_growth < 50:  # Less than 50MB growth is acceptable
            memory_leak_detected = False
            assessment = "✅ No significant memory leaks detected"
        elif memory_growth < 100:
            memory_leak_detected = False
            assessment = "⚠️  Moderate memory growth (acceptable)"
        else:
            memory_leak_detected = True
            assessment = "❌ Significant memory growth (possible leak)"
        
        print(f"  Assessment: {assessment}")
        
        return {
            'initial_memory_mb': initial_memory,
            'final_memory_mb': final_memory,
            'memory_growth_mb': memory_growth,
            'memory_leak_detected': memory_leak_detected
        }
        
    except Exception as e:
        print(f"❌ (failed: {e})")
        return {'error': str(e)}

async def test_graceful_shutdown():
    """Test graceful shutdown procedures."""
    print("🔌 Testing Graceful Shutdown...")
    
    results = {}
    
    # Test connection cleanup
    print("  Testing connection cleanup...", end=" ")
    try:
        db = await get_db()
        
        # Ensure connections are established
        await db.fetch_one("SELECT 1")
        if db.redis_client:
            await db.redis_client.ping()
        
        # Test cleanup
        await db.close_all()
        
        # Verify connections are closed
        try:
            await db.fetch_one("SELECT 1")
            results['connection_cleanup'] = False
            print("❌ (connections not properly closed)")
        except:
            results['connection_cleanup'] = True
            print("✅ (connections properly closed)")
        
        # Reinitialize for remaining tests
        await db.connect_all()
        
    except Exception as e:
        results['connection_cleanup'] = False
        print(f"❌ (cleanup failed: {e})")
    
    return results

async def run_error_handling_tests():
    """Run comprehensive error handling and resilience tests."""
    print("🛡️  Starting Error Handling & Resilience Testing")
    print("=" * 60)
    
    # Run all test categories
    db_failure_results = await test_database_failure_recovery()
    malformed_input_results = await test_malformed_input_handling()
    concurrent_safety_results = await test_concurrent_access_safety()
    memory_leak_results = await test_memory_leak_detection()
    shutdown_results = await test_graceful_shutdown()
    
    # Compile results
    all_results = {
        **db_failure_results,
        **malformed_input_results,
        **concurrent_safety_results,
        **shutdown_results
    }
    
    # Add memory leak results separately
    all_results['memory_leak_test'] = memory_leak_results
    
    # Analysis
    print(f"\n📊 Error Handling & Resilience Report:")
    print("=" * 60)
    
    total_tests = len([k for k in all_results.keys() if k != 'memory_leak_test'])
    passed_tests = sum(1 for k, v in all_results.items() if k != 'memory_leak_test' and v is True)
    
    print(f"\n✅ Test Results Summary:")
    print(f"  Tests Passed: {passed_tests}/{total_tests} ({passed_tests/total_tests:.1%})")
    
    print(f"\n🔧 Database Failure Recovery:")
    print(f"  PostgreSQL failure handling: {'✅' if db_failure_results.get('pg_failure_handling') else '❌'}")
    print(f"  Redis failure handling: {'✅' if db_failure_results.get('redis_failure_handling') else '❌'}")
    print(f"  Neo4j failure handling: {'✅' if db_failure_results.get('neo4j_failure_handling') else '❌'}")
    
    print(f"\n🎭 Input Validation:")
    print(f"  Invalid file paths: {'✅' if malformed_input_results.get('invalid_file_path') else '❌'}")
    print(f"  Extreme parameters: {'✅' if malformed_input_results.get('extreme_parameters') else '❌'}")
    print(f"  Empty string inputs: {'✅' if malformed_input_results.get('empty_string_input') else '❌'}")
    print(f"  SQL injection prevention: {'✅' if malformed_input_results.get('sql_injection_prevention') else '❌'}")
    
    print(f"\n🔄 Concurrent Access Safety:")
    print(f"  Concurrent database access: {'✅' if concurrent_safety_results.get('concurrent_db_access') else '❌'}")
    print(f"  Context Bridge concurrency: {'✅' if concurrent_safety_results.get('concurrent_context_access') else '❌'}")
    
    print(f"\n🧠 Memory Management:")
    if 'error' not in memory_leak_results:
        leak_detected = memory_leak_results.get('memory_leak_detected', True)
        print(f"  Memory leak detection: {'❌' if leak_detected else '✅'}")
        print(f"  Memory growth: {memory_leak_results.get('memory_growth_mb', 0):+.1f}MB")
    else:
        print(f"  Memory leak test: ❌ (failed)")
    
    print(f"\n🔌 Shutdown Procedures:")
    print(f"  Connection cleanup: {'✅' if shutdown_results.get('connection_cleanup') else '❌'}")
    
    # Overall assessment
    print(f"\n🎯 Resilience Assessment:")
    if passed_tests >= int(total_tests * 0.9):  # 90%+
        print("  ✅ EXCELLENT: System demonstrates strong resilience")
        assessment = "excellent"
    elif passed_tests >= int(total_tests * 0.75):  # 75%+
        print("  ⚠️  GOOD: System shows good resilience with minor issues")
        assessment = "good"
    elif passed_tests >= int(total_tests * 0.5):   # 50%+
        print("  ❌ FAIR: System has significant resilience issues")
        assessment = "fair"
    else:
        print("  ❌ POOR: System lacks adequate error handling")
        assessment = "poor"
    
    # Save detailed report
    report = {
        'timestamp': time.time(),
        'test_results': all_results,
        'memory_leak_analysis': memory_leak_results,
        'summary': {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'success_rate': passed_tests/total_tests,
            'assessment': assessment
        }
    }
    
    report_file = f"ERROR_HANDLING_REPORT_{int(time.time())}.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"\n💾 Detailed error handling report saved to: {report_file}")
    
    return assessment in ['excellent', 'good']

if __name__ == "__main__":
    success = asyncio.run(run_error_handling_tests())
    exit(0 if success else 1)