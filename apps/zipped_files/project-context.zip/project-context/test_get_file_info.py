#!/usr/bin/env python3
"""Test script for get_file_info function."""

import asyncio
import json
import sys
from pathlib import Path

# Add the src directory to the Python path
sys.path.append(str(Path(__file__).parent / "src"))

from project_context.tools.discovery import get_file_info


async def test_get_file_info():
    """Test the get_file_info function with this test file."""
    test_file_path = __file__  # Use this test file itself
    
    print(f"Testing get_file_info with file: {test_file_path}")
    print("-" * 50)
    
    try:
        result = await get_file_info(test_file_path)
        
        # Pretty print the result
        print("Result:")
        print(json.dumps(result, indent=2, default=str))
        
        # Check if it has the expected structure
        expected_keys = [
            "file_path", "file_system", "code_elements", 
            "context_items", "monitoring", "relationships", 
            "analysis_timestamp"
        ]
        
        print("\nStructure check:")
        for key in expected_keys:
            if key in result:
                print(f"✓ {key}: present")
            else:
                print(f"✗ {key}: missing")
                
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_get_file_info())