#!/usr/bin/env python3
"""Test script for the get_call_graph implementation."""

import asyncio
import sys
from pathlib import Path

# Add the project to the path
project_root = Path(__file__).parent / "src"
sys.path.insert(0, str(project_root))

from project_context.tools.analysis import get_call_graph


async def test_call_graph():
    """Test the get_call_graph function."""
    
    print("Testing get_call_graph implementation...")
    
    try:
        result = await get_call_graph()
        
        print("\n=== Call Graph Results ===")
        print(f"Total functions: {result['statistics']['total_functions']}")
        print(f"Total calls: {result['statistics']['total_calls']}")
        print(f"Max depth: {result['statistics']['max_depth']}")
        
        print(f"\nNodes found: {len(result['nodes'])}")
        if result['nodes']:
            print("Sample nodes:")
            for i, node in enumerate(result['nodes'][:5]):
                print(f"  {i+1}. {node['name']} ({node['file']}:{node['line_start']})")
        
        print(f"\nEdges found: {len(result['edges'])}")
        if result['edges']:
            print("Sample edges:")
            for i, edge in enumerate(result['edges'][:5]):
                print(f"  {i+1}. {edge['from']} -> {edge['to']} (freq: {edge['frequency']})")
        
        print(f"\nHierarchy roots: {len(result['hierarchy'])}")
        for root_id, hierarchy in result['hierarchy'].items():
            print(f"  - {hierarchy['name']} (depth: {hierarchy['depth']})")
        
        if result['statistics']['most_called']:
            print("\nMost called functions:")
            for called in result['statistics']['most_called'][:5]:
                print(f"  - {called['function']}: {called['frequency']} calls")
        
        if result.get('error'):
            print(f"\nError occurred: {result['error']}")
        else:
            print("\n✅ Call graph generated successfully!")
        
        return result
        
    except Exception as e:
        print(f"❌ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    asyncio.run(test_call_graph())