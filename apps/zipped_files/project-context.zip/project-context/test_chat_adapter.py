#!/usr/bin/env python3
"""
Test script for the enhanced Chat Adapter
"""

import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from project_context.ingestion.adapters.chat_adapter import ChatAdapter
from project_context.ingestion.base_adapter import AdapterConfig


def create_sample_jsonl_data():
    """Create sample JSONL chat data for testing."""
    messages = [
        {
            "id": "msg_1",
            "timestamp": "2024-01-15T10:00:00Z",
            "user_id": "alice",
            "content": "Hey team, I found a bug in the login system. Check out https://github.com/ourrepo/issues/123",
            "type": "message",
        },
        {
            "id": "msg_2", 
            "timestamp": "2024-01-15T10:05:00Z",
            "user_id": "bob_ai",
            "content": "Looking at the issue #123, it seems related to the auth.py file in /src/auth/auth.py. Can you run `pytest tests/test_auth.py`?",
            "type": "bot",
            "parent_id": "msg_1",
        },
        {
            "id": "msg_3",
            "timestamp": "2024-01-15T10:10:00Z", 
            "user_id": "charlie",
            "content": "@alice I see the same issue in our staging environment. The login() function in AuthService class is throwing errors.",
            "type": "message",
            "conversation_id": "conv_auth_bug"
        },
        {
            "id": "msg_4",
            "timestamp": "2024-01-15T10:15:00Z",
            "user_id": "system",
            "content": "Deployment completed to staging environment at 10:14:32 AM",
            "type": "system",
            "is_system": True
        },
        {
            "id": "msg_5",
            "timestamp": "2024-01-15T10:20:00Z",
            "user_id": "alice", 
            "content": "Thanks @charlie! I'll investigate the AuthService.login() method. It might be related to the recent Django update.",
            "type": "message",
            "conversation_id": "conv_auth_bug",
            "parent_id": "msg_3"
        }
    ]
    
    return messages


async def test_chat_adapter():
    """Test the enhanced chat adapter with sample data."""
    print("=== Testing Enhanced Chat Adapter ===\n")
    
    with TemporaryDirectory() as temp_dir:
        # Create sample JSONL file
        jsonl_file = Path(temp_dir) / "test_chat.jsonl"
        sample_data = create_sample_jsonl_data()
        
        with open(jsonl_file, 'w') as f:
            for message in sample_data:
                f.write(json.dumps(message) + '\n')
        
        print(f"Created test file: {jsonl_file}")
        print(f"Sample data: {len(sample_data)} messages")
        
        # Configure chat adapter
        config = ChatAdapter.default_config()
        config.source_config["watch_directories"] = [temp_dir]
        config.source_config["file_patterns"] = ["*.jsonl"]
        config.source_config["extract_entities"] = True
        
        adapter = ChatAdapter(config)
        await adapter.initialize()
        
        # Fetch and transform items
        print("\n=== Processing Messages ===")
        items = []
        async for raw_item in adapter.fetch_items():
            context_item = await adapter.transform_item(raw_item)
            items.append(context_item)
            
            print(f"\nMessage ID: {context_item.source_id}")
            print(f"Actor: {context_item.actor_id} ({context_item.actor_type})")
            print(f"Title: {context_item.title}")
            print(f"Content: {context_item.content[:100]}...")
            
            # Show extracted entities
            if context_item.metrics and "extracted_entities" in context_item.metrics:
                entities = context_item.metrics["extracted_entities"]
                print(f"Extracted entities: {list(entities.keys())}")
                for entity_type, values in entities.items():
                    if values:
                        print(f"  {entity_type}: {values}")
        
        # Test relationship detection
        print(f"\n=== Testing Relationship Detection ===")
        if len(items) >= 2:
            test_item = items[-1]  # Use last message
            context_window = items[:-1]  # Previous messages as context
            
            relationships = await adapter.detect_relationships(test_item, context_window)
            print(f"\nRelationships for message '{test_item.source_id}':")
            for rel_type, target_id, confidence in relationships:
                print(f"  {rel_type} -> {target_id} (confidence: {confidence:.2f})")
        
        # Test configuration
        print(f"\n=== Adapter Configuration ===")
        print(f"Source type: {config.source_type}")
        print(f"Batch mode: {config.batch_mode}")
        print(f"Entity extraction enabled: {config.source_config.get('extract_entities', True)}")
        print(f"Relationship extraction enabled: {config.extract_relationships}")
        
        await adapter.cleanup()
        print(f"\n✅ Chat adapter test completed successfully!")


if __name__ == "__main__":
    asyncio.run(test_chat_adapter())