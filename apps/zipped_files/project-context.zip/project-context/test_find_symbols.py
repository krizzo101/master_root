#!/usr/bin/env python3
"""Test script for find_symbols implementation."""

import asyncio
import sys
import os

# Add src to path to import the module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from project_context.tools.discovery import find_symbols


async def test_find_symbols():
    """Test the find_symbols function with various parameters."""
    
    print("Testing find_symbols function...")
    
    # Test 1: Basic search without filters
    print("\n1. Testing basic search (no filters):")
    result = await find_symbols(limit=5)
    print(f"Success: {result.get('success')}")
    print(f"Count: {result.get('count')}")
    if result.get('success'):
        print("✓ Basic search works")
    else:
        print(f"✗ Error: {result.get('error')}")
    
    # Test 2: Search by symbol name
    print("\n2. Testing search by name ('main'):")
    result = await find_symbols(name="main", limit=5)
    print(f"Success: {result.get('success')}")
    print(f"Count: {result.get('count')}")
    if result.get('success'):
        print("✓ Name search works")
        for symbol in result.get('results', [])[:2]:
            print(f"  Found: {symbol['name']} in {symbol['file_path']}")
    else:
        print(f"✗ Error: {result.get('error')}")
    
    # Test 3: Search by symbol type
    print("\n3. Testing search by symbol type ('function'):")
    result = await find_symbols(symbol_type="function", limit=5)
    print(f"Success: {result.get('success')}")
    print(f"Count: {result.get('count')}")
    if result.get('success'):
        print("✓ Symbol type search works")
    else:
        print(f"✗ Error: {result.get('error')}")
    
    # Test 4: Combined filters
    print("\n4. Testing combined filters (Python functions):")
    result = await find_symbols(symbol_type="function", language="python", limit=3)
    print(f"Success: {result.get('success')}")
    print(f"Count: {result.get('count')}")
    if result.get('success'):
        print("✓ Combined filters work")
    else:
        print(f"✗ Error: {result.get('error')}")
    
    print("\nTest completed!")


if __name__ == "__main__":
    try:
        asyncio.run(test_find_symbols())
    except Exception as e:
        print(f"Test failed with error: {e}")
        import traceback
        traceback.print_exc()