#!/usr/bin/env python3
"""Simple test to check if imports work."""

import sys
from pathlib import Path

# Add the project to the path
project_root = Path(__file__).parent / "src"
sys.path.insert(0, str(project_root))

try:
    from project_context.tools.analysis import get_call_graph
    print("✅ Import successful - get_call_graph function is available")
    
    # Check the function signature
    import inspect
    sig = inspect.signature(get_call_graph)
    print(f"Function signature: {sig}")
    print("Function docstring:")
    print(get_call_graph.__doc__)
    
except ImportError as e:
    print(f"❌ Import error: {e}")
except Exception as e:
    print(f"❌ Other error: {e}")