#!/usr/bin/env python3
"""
Test script for Phase 3 real Claude executor parallel improvements
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.hecaton.agents.real_claude_executor import RealClaudeSubprocessExecutor
from src.hecaton.resources.secure_token_pool import SecureTokenPool
from src.hecaton.resources.worktree_fixed import WorktreeManager


async def test_parallel_improvements():
    """Test the execute_parallel_improvements method"""
    
    print("\n" + "=" * 80)
    print("🧪 TESTING PHASE 3: PARALLEL IMPROVEMENTS EXECUTOR")
    print("=" * 80)
    
    # Initialize resources
    token_pool = SecureTokenPool()
    worktree_manager = WorktreeManager(
        base_path=Path("/home/opsvi/hecaton_phase3_test_worktrees")
    )
    
    print(f"✅ Resources initialized:")
    print(f"   - Tokens available: {token_pool.get_available_count()}")
    print(f"   - Worktree base: {worktree_manager.base_path}")
    
    # Create executor
    executor = RealClaudeSubprocessExecutor(token_pool, worktree_manager)
    
    # Define test tasks (simple ones for testing)
    test_tasks = [
        {
            "id": "test-1",
            "prompt": "Create a simple hello.py file with print('Hello from Agent 1')"
        },
        {
            "id": "test-2", 
            "prompt": "Create a simple world.py file with print('Hello from Agent 2')"
        },
        {
            "id": "test-3",
            "prompt": "Create a simple test.py file with print('Hello from Agent 3')"
        }
    ]
    
    print(f"\n📋 Testing with {len(test_tasks)} parallel tasks")
    
    # Test the new method
    try:
        results = await executor.execute_parallel_improvements(test_tasks)
        
        print("\n📊 Results:")
        for task_id, result in results.items():
            if not task_id.startswith('_'):
                status = result.get('status', 'unknown')
                status_icon = "✅" if status == 'completed' else "❌"
                print(f"{status_icon} {task_id}: {status}")
                if result.get('error'):
                    print(f"   Error: {result['error']}")
        
        # Check if method returns correct format
        assert isinstance(results, dict), "Results should be a dictionary"
        assert all(
            task['id'] in results for task in test_tasks
        ), "All task IDs should be in results"
        
        print("\n✅ Test passed! execute_parallel_improvements() is working correctly")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    # Run test
    success = asyncio.run(test_parallel_improvements())
    
    if success:
        print("\n🎉 Phase 3 executor ready for 15-agent parallel execution!")
    else:
        print("\n⚠️ Phase 3 executor test failed. Please check the implementation.")