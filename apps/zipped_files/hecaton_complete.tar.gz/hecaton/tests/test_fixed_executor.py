#!/usr/bin/env python3
"""
Test script for the fixed RealClaudeSubprocessExecutor
Tests the actual Claude CLI execution with proper commands
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from apps.hecaton.src.hecaton.agents.real_claude_executor import RealClaudeSubprocessExecutor
from apps.hecaton.src.hecaton.resources.secure_token_pool import SecureTokenPool
from apps.hecaton.src.hecaton.resources.worktree_fixed import WorktreeManager


async def test_real_execution():
    """Test real Claude execution with fixed commands"""
    
    print("\n" + "="*60)
    print("TESTING FIXED REAL CLAUDE EXECUTOR")
    print("="*60)
    
    # Check for tokens
    tokens = []
    primary_token = os.environ.get("CLAUDE_CODE_TOKEN")
    if primary_token:
        tokens.append(primary_token)
        print(f"✅ Found primary token: {primary_token[:10]}...")
    
    # Check for numbered tokens
    for i in range(1, 16):
        token = os.environ.get(f"CLAUDE_CODE_TOKEN{i}")
        if token:
            tokens.append(token)
            print(f"✅ Found token {i}: {token[:10]}...")
    
    if not tokens:
        print("❌ ERROR: No CLAUDE_CODE_TOKEN environment variables found")
        print("Please set CLAUDE_CODE_TOKEN or CLAUDE_CODE_TOKEN1..15")
        return False
    
    print(f"\n📦 Found {len(tokens)} tokens")
    
    # Initialize resources
    try:
        token_pool = SecureTokenPool(tokens=tokens)
        worktree_manager = WorktreeManager(base_path=Path("/tmp/hecaton_test"))
        print("✅ Resources initialized")
    except Exception as e:
        print(f"❌ Failed to initialize resources: {e}")
        return False
    
    # Create executor
    executor = RealClaudeSubprocessExecutor(token_pool, worktree_manager)
    print("✅ Executor created")
    
    # Simple test task
    test_task = {
        "id": "test-001",
        "prompt": "What is 2 + 2? Just respond with the number.",
        "model": "sonnet"  # Use fastest model for test
    }
    
    print(f"\n🚀 Executing test task: {test_task['prompt']}")
    print("-" * 40)
    
    try:
        # Execute the task
        result = await executor.execute_task(test_task)
        
        # Check result
        if result.get("status") == "completed":
            print(f"✅ Task completed successfully!")
            print(f"Output: {result.get('output', 'No output')[:100]}...")
            return True
        else:
            print(f"❌ Task failed with status: {result.get('status')}")
            print(f"Error: {result.get('error', 'Unknown error')}")
            if result.get('stderr'):
                print(f"Stderr: {result['stderr']}")
            return False
            
    except Exception as e:
        print(f"❌ Exception during execution: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_parallel_execution():
    """Test parallel execution with multiple agents"""
    
    print("\n" + "="*60)
    print("TESTING PARALLEL EXECUTION")
    print("="*60)
    
    # Get tokens
    tokens = []
    for i in range(16):  # Check primary and 15 numbered
        key = "CLAUDE_CODE_TOKEN" if i == 0 else f"CLAUDE_CODE_TOKEN{i}"
        token = os.environ.get(key)
        if token:
            tokens.append(token)
    
    if len(tokens) < 2:
        print("⚠️  Skipping parallel test - need at least 2 tokens")
        return False
    
    print(f"✅ Found {len(tokens)} tokens for parallel execution")
    
    # Initialize
    token_pool = SecureTokenPool(tokens=tokens)
    worktree_manager = WorktreeManager(base_path=Path("/tmp/hecaton_parallel"))
    executor = RealClaudeSubprocessExecutor(token_pool, worktree_manager)
    
    # Create parallel tasks
    tasks = [
        {"id": "calc-1", "prompt": "What is 10 + 20? Just the number."},
        {"id": "calc-2", "prompt": "What is 5 * 6? Just the number."},
        {"id": "calc-3", "prompt": "What is 100 - 25? Just the number."},
    ]
    
    print(f"\n🚀 Executing {len(tasks)} tasks in parallel...")
    
    try:
        results = await executor.execute_parallel_tasks(tasks, max_parallel=3)
        
        successful = sum(1 for r in results if r.get("status") == "completed")
        print(f"\n📊 Results: {successful}/{len(tasks)} successful")
        
        for result in results:
            status_icon = "✅" if result.get("status") == "completed" else "❌"
            print(f"{status_icon} {result['task_id']}: {result['status']}")
            
        return successful == len(tasks)
        
    except Exception as e:
        print(f"❌ Exception in parallel execution: {e}")
        return False


async def main():
    """Run all tests"""
    
    print("\n🧪 HECATON REAL CLAUDE EXECUTOR TEST SUITE")
    print("=" * 60)
    
    # Test 1: Single execution
    test1_passed = await test_real_execution()
    
    # Test 2: Parallel execution (if we have multiple tokens)
    test2_passed = await test_parallel_execution()
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"Single execution: {'✅ PASSED' if test1_passed else '❌ FAILED'}")
    print(f"Parallel execution: {'✅ PASSED' if test2_passed else '❌ FAILED/SKIPPED'}")
    
    if test1_passed:
        print("\n🎉 Core functionality is working!")
        print("The fixed executor can now run real Claude processes.")
    else:
        print("\n⚠️  Issues detected. Please check:")
        print("1. CLAUDE_CODE_TOKEN environment variable is set")
        print("2. Claude CLI is installed and accessible")
        print("3. Minimal MCP config exists at config/claude_minimal.json")


if __name__ == "__main__":
    asyncio.run(main())