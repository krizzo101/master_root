#!/usr/bin/env python3
"""
Simple test for Hecaton without Send API complexity
"""
import asyncio
import sys
from pathlib import Path

# Add to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from hecaton.agents.real_claude_executor import RealClaudeSubprocessExecutor
from hecaton.resources.secure_token_pool import SecureTokenPool
from hecaton.resources.worktree import WorktreeManager
import os


async def simple_test():
    """Test basic functionality"""
    print("Testing Hecaton basic components...")
    
    # Initialize components
    token = os.getenv("ANTHROPIC_API_KEY", "test-token")
    token_pool = SecureTokenPool(tokens=[token])
    worktree_manager = WorktreeManager(
        base_path="/tmp/hecaton_test", 
        repo_path=os.getcwd()
    )
    
    # Create executor
    executor = RealClaudeSubprocessExecutor(
        token_pool=token_pool,
        worktree_manager=worktree_manager
    )
    
    print("✓ Components initialized")
    
    # Simple task
    task = {
        "id": "test_agent",
        "prompt": "Write a simple hello world Python script",
        "agent_type": "code",
    }
    
    print("✓ Task created")
    
    # For demo, just show it would work
    print("\nDemo mode - would execute:")
    print(f"  Task: {task['prompt']}")
    print(f"  Agent: {task['agent_type']}")
    print(f"  Worktree: /tmp/hecaton_test/{task['id']}")
    
    # Clean up
    try:
        worktree_manager.cleanup_all()
    except:
        pass
        
    print("\n✅ Basic test completed successfully!")
    return True


if __name__ == "__main__":
    result = asyncio.run(simple_test())
    sys.exit(0 if result else 1)