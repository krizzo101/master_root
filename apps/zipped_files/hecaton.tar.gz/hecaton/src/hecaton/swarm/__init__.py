"""
Swarm task decomposition for parallel execution.
"""

from .swarm_decomposer import SwarmTaskDecomposer, ExecutionGroup, TaskNode

__all__ = [
    "SwarmTaskDecomposer",
    "ExecutionGroup",
    "TaskNode",
]