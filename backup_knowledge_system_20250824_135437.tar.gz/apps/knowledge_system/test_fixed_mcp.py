#!/usr/bin/env python3
"""
Test the fixed MCP knowledge tools
"""

import sys
import json
sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.mcp_knowledge_tools import get_enhanced_query

print("="*70)
print("TESTING FIXED MCP KNOWLEDGE QUERY")
print("="*70)

# Get the query tool
query_tool = get_enhanced_query()

# Test 1: Recent with no filter
print("\n1. Recent knowledge (min_confidence=0.0):")
result = query_tool.query(
    query_type="recent",
    min_confidence=0.0,
    limit=10,
    direct_execute=True
)

if "results" in result:
    print(f"   Found {result['count']} items")
    for item in result['results'][:5]:
        conf = item.get('confidence', 'NULL')
        content = item.get('content', '')[:60]
        print(f"   - {item['id']}: {content}... (conf: {conf})")
else:
    print(f"   Query returned: {result}")

# Test 2: Search with no filter
print("\n2. Search for 'GPT' (min_confidence=0.0):")
result = query_tool.query(
    query_type="search",
    query_text="GPT",
    min_confidence=0.0,
    limit=10,
    direct_execute=True
)

if "results" in result:
    print(f"   Found {result['count']} items")
    for item in result['results'][:5]:
        content = item.get('content', '')[:60]
        print(f"   - {content}...")
else:
    print(f"   Query returned: {result}")

# Test 3: Count total accessible
print("\n3. Checking total accessible knowledge:")
from neo4j import GraphDatabase
driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
with driver.session() as session:
    result = session.run("""
        MATCH (k:Knowledge)
        WHERE (k.deprecated = false OR k.deprecated IS NULL)
        RETURN count(k) as total,
               count(CASE WHEN k.confidence_score >= 0.7 THEN 1 END) as high_conf,
               count(CASE WHEN k.confidence_score < 0.7 OR k.confidence_score IS NULL THEN 1 END) as low_conf
    """)
    stats = dict(result.single())
    print(f"   Total accessible: {stats['total']}")
    print(f"   High confidence (>=0.7): {stats['high_conf']}")
    print(f"   Low/NULL confidence: {stats['low_conf']}")

driver.close()

print("\n" + "="*70)
print("TEST COMPLETE - Restart session to use fixed MCP tool")
print("="*70)