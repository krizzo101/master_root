#!/usr/bin/env python3
"""
Search the indexed reference knowledge in Qdrant
"""

import sys
sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.simple_rag import SimpleVectorSearch, SimpleCache
from apps.knowledge_system.embedding_service import get_embedding_service


def search_reference(query: str, limit: int = 5):
    """Search for reference knowledge"""
    print(f"\nSearching for: '{query}'")
    print("=" * 60)
    
    # Initialize components
    vector_search = SimpleVectorSearch()
    cache = SimpleCache()
    embedding_service = get_embedding_service()
    
    # Check cache first
    cached = cache.get_cached_search(query)
    if cached:
        print(f"✅ Cache hit! Found {len(cached)} results")
        knowledge_ids = cached[:limit]
    else:
        # Generate embedding for query
        embedding = embedding_service.generate_embedding(query)
        
        # Search in Qdrant
        knowledge_ids = vector_search.search_similar(embedding, limit)
        
        # Cache results
        if knowledge_ids:
            cache.cache_search(query, knowledge_ids)
            print(f"✅ Found {len(knowledge_ids)} results (cached for next time)")
    
    # Display results
    if knowledge_ids:
        print("\nResults:")
        for i, kid in enumerate(knowledge_ids, 1):
            print(f"  {i}. {kid}")
        
        # Get metadata from Qdrant
        from qdrant_client import QdrantClient
        client = QdrantClient(host="localhost", port=6333)
        points = client.retrieve(
            collection_name="knowledge_vectors",
            ids=[kid for kid in knowledge_ids]
        )
        
        print("\nDetails:")
        for point in points:
            payload = point.payload
            print(f"\n  ID: {payload.get('knowledge_id', 'unknown')}")
            print(f"  Source: {payload.get('source', 'unknown')}")
            print(f"  Type: {payload.get('type', 'unknown')}")
            print(f"  Tags: {', '.join(payload.get('tags', []))}")
    else:
        print("No results found")
    
    print("=" * 60)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        query = ' '.join(sys.argv[1:])
    else:
        query = "OpenAI Python API"
    
    search_reference(query)