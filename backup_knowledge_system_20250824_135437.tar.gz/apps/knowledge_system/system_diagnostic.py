#!/usr/bin/env python3
"""
System Diagnostic - NO FALLBACKS, ONLY TRUTH
Tests each component in isolation to prove it works or expose failures
"""

import sys
import traceback
from neo4j import GraphDatabase
from qdrant_client import QdrantClient
import numpy as np

sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.embedding_service import get_embedding_service
from apps.knowledge_system.hybrid_search import HybridSearch
from apps.knowledge_system.usage_tracking import KnowledgeUsageTracker

# ANSI colors for clear pass/fail
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def test_component(name, test_func):
    """Run a test with no fallbacks - fail loudly"""
    print(f"\n{'='*60}")
    print(f"Testing: {name}")
    print(f"{'='*60}")
    try:
        result = test_func()
        if result:
            print(f"{GREEN}✓ PASSED{RESET}")
            return True
        else:
            print(f"{RED}✗ FAILED - Returned False/None{RESET}")
            return False
    except Exception as e:
        print(f"{RED}✗ FAILED - Exception:{RESET}")
        print(f"  {str(e)}")
        traceback.print_exc()
        return False

def test_neo4j_connection():
    """Test Neo4j connection and auth - NO FALLBACKS"""
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
    
    with driver.session() as session:
        # Test basic query
        result = session.run("MATCH (n) RETURN count(n) as count LIMIT 1")
        count = result.single()["count"]
        print(f"  Neo4j nodes: {count}")
        
        # Test our knowledge nodes
        result = session.run("""
            MATCH (k:Knowledge {direct_ingestion: true})
            RETURN count(k) as count
        """)
        knowledge_count = result.single()["count"]
        print(f"  Knowledge nodes: {knowledge_count}")
        
        # Test relationships exist
        result = session.run("""
            MATCH (k1:Knowledge)-[r:NEXT_CHUNK]->(k2:Knowledge)
            RETURN count(r) as count
        """)
        rel_count = result.single()["count"]
        print(f"  NEXT_CHUNK relationships: {rel_count}")
        
    driver.close()
    return knowledge_count > 0 and rel_count > 0

def test_qdrant_vector_search():
    """Test Qdrant vector search - NO FALLBACKS"""
    client = QdrantClient(host="localhost", port=6333)
    embedding_service = get_embedding_service()
    
    # Generate test embedding
    test_query = "OpenAI streaming API"
    embedding = embedding_service.generate_embedding(test_query)
    print(f"  Embedding dimension: {len(embedding)}")
    
    # Search
    results = client.search(
        collection_name="knowledge_vectors",
        query_vector=embedding,
        limit=5
    )
    
    print(f"  Found {len(results)} results")
    for i, hit in enumerate(results[:3], 1):
        print(f"    {i}. Score: {hit.score:.3f}, ID: {hit.payload.get('knowledge_id', 'unknown')[:20]}...")
    
    return len(results) > 0 and results[0].score > 0.5

def test_graph_traversal():
    """Test graph traversal actually works - NO FALLBACKS"""
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
    
    with driver.session() as session:
        # Find a node with NEXT_CHUNK relationships
        result = session.run("""
            MATCH (k:Knowledge)-[:NEXT_CHUNK]->(k2:Knowledge)
            RETURN k.knowledge_id as start_id
            LIMIT 1
        """)
        record = result.single()
        if not record:
            print(f"  {RED}No nodes with NEXT_CHUNK relationships found!{RESET}")
            return False
        
        start_id = record["start_id"]
        print(f"  Starting from: {start_id}")
        
        # Traverse the graph
        result = session.run("""
            MATCH path = (k:Knowledge {knowledge_id: $kid})-[:NEXT_CHUNK*1..3]-(related:Knowledge)
            RETURN related.knowledge_id as id, length(path) as distance
            ORDER BY distance
        """, kid=start_id)
        
        traversed = []
        for record in result:
            traversed.append((record["id"], record["distance"]))
            print(f"    Distance {record['distance']}: {record['id'][:20]}...")
        
        driver.close()
        
        if len(traversed) == 0:
            print(f"  {RED}Graph traversal returned no results!{RESET}")
            return False
        
        return len(traversed) > 0

def test_hybrid_search_components():
    """Test hybrid search with both vector AND graph scores - NO FALLBACKS"""
    search = HybridSearch()
    
    # Test vector search
    print("\n  Testing Vector Search:")
    vector_results = search._vector_search("OpenAI API", limit=3, expand_depth=0, filters=None)
    for r in vector_results[:2]:
        print(f"    {r.source[:40]}... V:{r.vector_score:.2f} G:{r.graph_score:.2f}")
    
    if not vector_results or vector_results[0].vector_score == 0:
        print(f"  {RED}Vector search not producing scores!{RESET}")
        return False
    
    # Test graph search
    print("\n  Testing Graph Search:")
    graph_results = search._graph_search("streaming", limit=3, expand_depth=1, filters=None)
    for r in graph_results[:2]:
        print(f"    {r.source[:40]}... V:{r.vector_score:.2f} G:{r.graph_score:.2f}")
    
    if not graph_results or graph_results[0].graph_score == 0:
        print(f"  {RED}Graph search not producing scores!{RESET}")
        return False
    
    # Test hybrid (should have BOTH scores)
    print("\n  Testing Hybrid Search:")
    hybrid_results = search._hybrid_search("OpenAI streaming", limit=3, expand_depth=1, filters=None)
    
    has_both_scores = False
    for r in hybrid_results[:3]:
        print(f"    {r.source[:40]}... V:{r.vector_score:.2f} G:{r.graph_score:.2f} C:{r.combined_score:.2f}")
        if r.vector_score > 0 and r.graph_score > 0:
            has_both_scores = True
    
    search.close()
    
    if not has_both_scores:
        print(f"  {YELLOW}Warning: No results with both vector AND graph scores!{RESET}")
    
    return len(hybrid_results) > 0

def test_usage_tracking():
    """Test usage tracking actually records - NO FALLBACKS"""
    tracker = KnowledgeUsageTracker()
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
    
    # Get a real knowledge ID
    with driver.session() as session:
        result = session.run("""
            MATCH (k:Knowledge {direct_ingestion: true})
            RETURN k.knowledge_id as id
            LIMIT 1
        """)
        record = result.single()
        if not record:
            print(f"  {RED}No knowledge nodes found!{RESET}")
            return False
        
        test_id = record["id"]
        print(f"  Testing with ID: {test_id}")
        
        # Track usage
        result = tracker.track_usage(test_id, success=True, context={"query": "test"})
        print(f"  Tracking result: {result}")
        
        if not result["success"]:
            print(f"  {RED}Usage tracking failed!{RESET}")
            return False
        
        # Verify it was recorded
        result = session.run("""
            MATCH (k:Knowledge {knowledge_id: $kid})
            RETURN k.usage_count as count, k.last_used as last_used
        """, kid=test_id)
        record = result.single()
        
        print(f"  Usage count: {record['count']}")
        print(f"  Last used: {record['last_used']}")
        
        driver.close()
        tracker.close()
        
        return record["count"] > 0 and record["last_used"] is not None

def test_mcp_integration():
    """Test MCP integration uses hybrid search - NO FALLBACKS"""
    from apps.knowledge_system.mcp_knowledge_tools import EnhancedKnowledgeQuery
    
    query_tool = EnhancedKnowledgeQuery()
    
    # Force hybrid search
    result = query_tool.query(
        query_type="hybrid",
        query_text="OpenAI streaming",
        limit=3
    )
    
    print(f"  Query type: {result.get('query_type')}")
    print(f"  Strategy: {result.get('strategy')}")
    print(f"  Success: {result.get('success')}")
    
    if 'knowledge' in result:
        for item in result['knowledge'][:2]:
            v_score = item.get('vector_score', 0)
            g_score = item.get('graph_score', 0)
            print(f"    V:{v_score:.2f} G:{g_score:.2f} - {item.get('source', 'unknown')[:40]}...")
    else:
        print(f"  {RED}No knowledge returned!{RESET}")
        return False
    
    # Check if it actually used hybrid search (not a fallback)
    if result.get('strategy') != 'hybrid':
        print(f"  {RED}Not using hybrid strategy! Using: {result.get('strategy')}{RESET}")
        return False
    
    return result.get('success', False)

def main():
    """Run all diagnostics"""
    print("=" * 80)
    print("RAG SYSTEM DIAGNOSTIC - NO FALLBACKS, ONLY TRUTH")
    print("=" * 80)
    
    tests = [
        ("Neo4j Connection & Auth", test_neo4j_connection),
        ("Qdrant Vector Search", test_qdrant_vector_search),
        ("Graph Traversal", test_graph_traversal),
        ("Hybrid Search Components", test_hybrid_search_components),
        ("Usage Tracking", test_usage_tracking),
        ("MCP Integration", test_mcp_integration)
    ]
    
    results = []
    for name, test_func in tests:
        passed = test_component(name, test_func)
        results.append((name, passed))
    
    # Summary
    print("\n" + "=" * 80)
    print("DIAGNOSTIC SUMMARY")
    print("=" * 80)
    
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)
    
    for name, passed in results:
        status = f"{GREEN}PASS{RESET}" if passed else f"{RED}FAIL{RESET}"
        print(f"  {status} - {name}")
    
    print(f"\nResult: {passed_count}/{total_count} components working")
    
    if passed_count == total_count:
        print(f"{GREEN}✓ SYSTEM IS FULLY FUNCTIONAL AS DESIGNED{RESET}")
    else:
        print(f"{RED}✗ SYSTEM HAS FAILURES - NOT WORKING AS ADVERTISED{RESET}")
    
    return passed_count == total_count

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)