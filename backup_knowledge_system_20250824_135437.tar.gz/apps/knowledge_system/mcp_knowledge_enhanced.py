#!/usr/bin/env python3
"""
ENHANCED MCP Knowledge Tool - Using ALL the improvements
Integrates Qdrant, unified search, full 2799 items, etc.
"""

import json
import logging
import os
import sys
from typing import Optional, Dict, Any, List

sys.path.insert(0, "/home/opsvi/master_root")

# Import the REAL unified search system
from apps.knowledge_system.unified_intelligent_search import UnifiedIntelligentSearch
from apps.knowledge_system.knowledge_service import KnowledgeService
from apps.knowledge_system.embedding_service import get_embedding_service
from neo4j import GraphDatabase

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EnhancedKnowledgeMCP:
    """
    The REAL knowledge interface using ALL improvements:
    - Unified intelligent search with Qdrant
    - Full 2,799 knowledge items
    - Vector + graph + semantic search
    - No artificial confidence filters
    """
    
    def __init__(self):
        # Initialize unified search
        self.unified_search = UnifiedIntelligentSearch()
        
        # Initialize knowledge service for storage
        self.knowledge_service = KnowledgeService()
        
        # Direct Neo4j for truth queries
        uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
        user = os.getenv("NEO4J_USER", "neo4j")
        password = os.getenv("NEO4J_PASSWORD", "password")
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        
        logger.info("Enhanced MCP initialized with full capabilities")
    
    def store_knowledge(
        self,
        content: str,
        knowledge_type: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Store knowledge using the full pipeline
        """
        try:
            # Store using knowledge service
            result = self.knowledge_service.store_knowledge(
                content=content,
                knowledge_type=knowledge_type,
                tags=tags,
                confidence_score=0.75  # Default reasonable confidence
            )
            
            return {
                "success": True,
                "knowledge_id": result["knowledge_id"],
                "stored": True,
                "indexed_in_qdrant": result.get("vector_indexed", False),
                "message": "Knowledge stored with full indexing"
            }
            
        except Exception as e:
            logger.error(f"Storage failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def query_knowledge(
        self,
        query_type: str = "search",
        search_text: Optional[str] = None,
        limit: int = 10,
        include_all: bool = True
    ) -> Dict[str, Any]:
        """
        Query using unified search with full capabilities
        """
        try:
            if query_type == "search" and search_text:
                # Use unified intelligent search
                results = self.unified_search.search(
                    query=search_text,
                    limit=limit,
                    include_context=True
                )
                
                # Format results
                knowledge_items = []
                for result in results:
                    item = {
                        "id": result.knowledge_id,
                        "type": result.knowledge_type,
                        "content": result.content,
                        "source": result.source,
                        "confidence": result.combined_score,
                        "vector_score": result.vector_score,
                        "graph_score": result.graph_score,
                        "semantic_score": result.semantic_score
                    }
                    knowledge_items.append(item)
                
                return {
                    "success": True,
                    "results": knowledge_items,
                    "count": len(knowledge_items),
                    "query_type": "unified_search",
                    "total_in_db": self._get_total_count()
                }
                
            elif query_type == "recent":
                # Direct Neo4j query for recent items
                with self.driver.session() as session:
                    # No confidence filter if include_all=True
                    min_conf = 0.0 if include_all else 0.5
                    
                    result = session.run("""
                        MATCH (k:Knowledge)
                        WHERE (k.deprecated = false OR k.deprecated IS NULL)
                        AND (k.confidence_score >= $min_conf OR k.confidence_score IS NULL)
                        RETURN k
                        ORDER BY COALESCE(k.created_at, datetime()) DESC
                        LIMIT $limit
                    """, {"min_conf": min_conf, "limit": limit})
                    
                    knowledge_items = []
                    for record in result:
                        k = dict(record["k"])
                        # Remove embedding from response
                        k.pop("embedding", None)
                        knowledge_items.append(k)
                    
                    return {
                        "success": True,
                        "results": knowledge_items,
                        "count": len(knowledge_items),
                        "query_type": "recent",
                        "total_in_db": self._get_total_count()
                    }
                    
            elif query_type == "stats":
                # Return comprehensive statistics
                return self._get_stats()
                
            else:
                return {
                    "success": False,
                    "error": f"Unknown query type: {query_type}"
                }
                
        except Exception as e:
            logger.error(f"Query failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _get_total_count(self) -> int:
        """Get total knowledge count"""
        with self.driver.session() as session:
            result = session.run("MATCH (k:Knowledge) RETURN count(k) as total")
            return result.single()["total"]
    
    def _get_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics"""
        with self.driver.session() as session:
            result = session.run("""
                MATCH (k:Knowledge)
                RETURN 
                    count(k) as total,
                    count(CASE WHEN k.deprecated = false OR k.deprecated IS NULL THEN 1 END) as active,
                    count(k.embedding) as with_embeddings,
                    count(DISTINCT k.knowledge_type) as unique_types,
                    avg(k.confidence_score) as avg_confidence,
                    min(k.confidence_score) as min_confidence,
                    max(k.confidence_score) as max_confidence
            """)
            
            stats = dict(result.single())
            
            # Get Qdrant stats
            try:
                collection_info = self.unified_search.vector_search.client.get_collection("knowledge")
                stats["qdrant_vectors"] = collection_info.vectors_count
            except:
                stats["qdrant_vectors"] = 0
            
            return {
                "success": True,
                "stats": stats,
                "message": "Complete knowledge system statistics"
            }
    
    def update_knowledge(
        self,
        knowledge_id: str,
        update_type: str,
        reason: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update knowledge based on usage"""
        try:
            if update_type == "success":
                self.knowledge_service.record_usage(knowledge_id, success=True)
            elif update_type == "failure":
                self.knowledge_service.record_usage(knowledge_id, success=False)
            elif update_type == "deprecate":
                with self.driver.session() as session:
                    session.run("""
                        MATCH (k:Knowledge {knowledge_id: $id})
                        SET k.deprecated = true,
                            k.deprecation_reason = $reason,
                            k.deprecated_at = datetime()
                    """, {"id": knowledge_id, "reason": reason})
            
            return {
                "success": True,
                "message": f"Knowledge {knowledge_id} updated: {update_type}"
            }
            
        except Exception as e:
            logger.error(f"Update failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


def test_enhanced_mcp():
    """Test the enhanced MCP directly"""
    print("="*70)
    print("TESTING ENHANCED MCP KNOWLEDGE")
    print("="*70)
    
    mcp = EnhancedKnowledgeMCP()
    
    # Test 1: Get stats
    print("\n1. System Statistics:")
    stats = mcp.query_knowledge(query_type="stats")
    if stats["success"]:
        for key, value in stats["stats"].items():
            print(f"   {key}: {value}")
    
    # Test 2: Search for recent additions
    print("\n2. Search for 'autonomous agents':")
    results = mcp.query_knowledge(
        query_type="search",
        search_text="autonomous agents",
        limit=3
    )
    if results["success"]:
        print(f"   Found {results['count']} results (DB total: {results.get('total_in_db', 'unknown')})")
        for r in results["results"]:
            print(f"   - {r['id']}: {r['content'][:60]}...")
            print(f"     Scores - V:{r.get('vector_score', 0):.2f}, "
                  f"G:{r.get('graph_score', 0):.2f}, "
                  f"S:{r.get('semantic_score', 0):.2f}")
    
    # Test 3: Get recent (with no filter)
    print("\n3. Recent knowledge (no filters):")
    results = mcp.query_knowledge(
        query_type="recent",
        limit=5,
        include_all=True
    )
    if results["success"]:
        print(f"   Found {results['count']} recent items")
        for r in results["results"]:
            conf = r.get('confidence_score', 'NULL')
            print(f"   - {r['knowledge_id']}: conf={conf}")
    
    print("\n" + "="*70)
    print("TEST COMPLETE")


if __name__ == "__main__":
    test_enhanced_mcp()