#!/usr/bin/env python3
"""
Comprehensive test script for the complete knowledge system
Tests all components independently via direct Python calls
"""

import os
import sys
import json
import asyncio
from datetime import datetime
from typing import Dict, Any, List

# Add path for imports
sys.path.insert(0, '/home/opsvi/master_root')
sys.path.insert(0, '/home/opsvi/master_root/apps/knowledge_system')

# Set required environment variables for testing
os.environ['NEO4J_URI'] = os.environ.get('NEO4J_URI', 'bolt://localhost:7687')
os.environ['NEO4J_USER'] = os.environ.get('NEO4J_USER', 'neo4j')
os.environ['NEO4J_PASSWORD'] = os.environ.get('NEO4J_PASSWORD', 'password')
os.environ['OPENAI_API_KEY'] = os.environ.get('OPENAI_API_KEY', 'test-key')

def test_nano_agent():
    """Test the nano agent transformation"""
    print("\n" + "="*60)
    print("TESTING NANO AGENT")
    print("="*60)
    
    from knowledge_nano_agent import KnowledgeNanoAgent, KnowledgeSchema
    
    try:
        # Initialize nano agent
        agent = KnowledgeNanoAgent()
        print("✅ Nano agent initialized")
        
        # Test transformation with valid content
        test_content = """
        When implementing FastMCP with complex types like List[str] or Dict[str, Any],
        the framework generates incomplete JSON schemas that fail validation.
        The solution is to use JSON-encoded string parameters instead.
        """
        
        # Test async transformation
        async def test_transform():
            try:
                result = await agent.transform_knowledge(
                    raw_input=test_content,
                    hint_type="ERROR_SOLUTION",
                    hint_tags=["fastmcp", "validation", "json"]
                )
                print(f"✅ Transformation successful")
                print(f"   Type: {result.knowledge_type}")
                print(f"   Summary: {result.summary[:80]}...")
                print(f"   Tags: {result.tags}")
                print(f"   Confidence: {result.confidence_score}")
                return result
            except RuntimeError as e:
                print(f"❌ Transformation failed (expected if no OpenAI): {e}")
                return None
        
        # Run async test
        result = asyncio.run(test_transform())
        
        # Test error handling with empty content
        try:
            agent.transform_knowledge_sync("")
            print("❌ Should have failed with empty content")
        except ValueError as e:
            print(f"✅ Correctly rejected empty content: {e}")
        
        # Test error handling with short content
        try:
            agent.transform_knowledge_sync("Hi")
            print("❌ Should have failed with short content")
        except ValueError as e:
            print(f"✅ Correctly rejected short content: {e}")
        
    except Exception as e:
        print(f"❌ Nano agent test failed: {e}")
        import traceback
        traceback.print_exc()

def test_embedding_service():
    """Test the embedding service"""
    print("\n" + "="*60)
    print("TESTING EMBEDDING SERVICE")
    print("="*60)
    
    from embedding_service import EmbeddingService
    
    try:
        # Initialize service
        service = EmbeddingService()
        print("✅ Embedding service initialized")
        
        # Test embedding generation
        test_text = "This is a test knowledge entry about Python error handling"
        
        try:
            service._ensure_model_loaded()
            embedding = service.generate_embedding(test_text)
            print(f"✅ Embedding generated: {len(embedding)} dimensions")
            print(f"   Vector sample: [{embedding[0]:.4f}, {embedding[1]:.4f}, ...]")
            
            # Test caching
            embedding2 = service.generate_embedding(test_text)
            if embedding == embedding2:
                print("✅ Embedding caching works")
            
            # Test batch generation
            texts = [
                "First test text",
                "Second test text",
                "Third test text"
            ]
            embeddings = service.generate_embeddings_batch(texts)
            print(f"✅ Batch embeddings generated: {len(embeddings)} vectors")
            
        except Exception as e:
            print(f"⚠️  Embedding generation failed (expected if sentence-transformers not installed): {e}")
        
    except Exception as e:
        print(f"❌ Embedding service test failed: {e}")

def test_knowledge_tools():
    """Test the knowledge tools with direct execution"""
    print("\n" + "="*60)
    print("TESTING KNOWLEDGE TOOLS")
    print("="*60)
    
    from mcp_knowledge_tools import EnhancedKnowledgeStore, EnhancedKnowledgeQuery
    
    try:
        # Test store initialization
        store = EnhancedKnowledgeStore()
        print("✅ Knowledge store initialized")
        
        # Check Neo4j driver
        if store.neo4j_driver:
            print("✅ Neo4j driver available")
        else:
            print("⚠️  Neo4j driver not available - will return queries")
        
        # Check embedding service
        if store.embedding_service:
            print("✅ Embedding service available")
        else:
            print("⚠️  Embedding service not available")
        
        # Test knowledge ID generation
        test_id = store.generate_knowledge_id("test content", "TEST_TYPE")
        print(f"✅ Knowledge ID generated: {test_id}")
        
        # Test similarity calculation
        if store.embedding_service:
            similarity = store._is_similar("Python error handling", "Python exception handling")
            print(f"✅ Similarity calculation: {similarity:.2f}")
        
        # Test query initialization
        query = EnhancedKnowledgeQuery()
        print("✅ Knowledge query initialized")
        
        # Test async store operation
        async def test_store():
            result = await store.store(
                raw_input="Test knowledge about FastMCP validation errors",
                hint_type="ERROR_SOLUTION",
                hint_tags=["test", "fastmcp"],
                direct_execute=True
            )
            return result
        
        # Run async test
        try:
            result = asyncio.run(test_store())
            if result.get("stored"):
                print(f"✅ Knowledge stored directly: {result['knowledge_id']}")
            else:
                print(f"✅ Query generated: {result['knowledge_id']}")
                print(f"   Embedding: {result.get('embedding_generated', False)}")
        except Exception as e:
            print(f"⚠️  Store operation failed (expected without full setup): {e}")
        
        # Test query operation
        query_result = query.query(
            query_type="recent",
            limit=5,
            direct_execute=True
        )
        
        if "results" in query_result:
            print(f"✅ Direct query executed: {query_result['count']} results")
        else:
            print("✅ Query generated for external execution")
        
    except Exception as e:
        print(f"❌ Knowledge tools test failed: {e}")
        import traceback
        traceback.print_exc()

def test_mcp_server():
    """Test the MCP server functions"""
    print("\n" + "="*60)
    print("TESTING MCP SERVER")
    print("="*60)
    
    try:
        # Import server module
        from mcp_knowledge_server import knowledge_store, knowledge_query
        
        print("✅ MCP server functions imported")
        
        # Test knowledge_store function
        async def test_mcp_store():
            result = await knowledge_store(
                content="MCP server test content",
                knowledge_type="TEST",
                tags="test,mcp"
            )
            return json.loads(result)
        
        # Test knowledge_query function
        async def test_mcp_query():
            result = await knowledge_query(
                query_type="recent",
                limit=3
            )
            return json.loads(result)
        
        # Run tests
        try:
            store_result = asyncio.run(test_mcp_store())
            print(f"✅ MCP store function works")
            print(f"   Success: {store_result.get('success')}")
            print(f"   Message: {store_result.get('message', 'N/A')}")
        except Exception as e:
            print(f"⚠️  MCP store failed (expected without full setup): {e}")
        
        try:
            query_result = asyncio.run(test_mcp_query())
            print(f"✅ MCP query function works")
            print(f"   Success: {query_result.get('success')}")
            if "results" in query_result:
                print(f"   Results: {query_result.get('count', 0)} entries")
        except Exception as e:
            print(f"⚠️  MCP query failed (expected without full setup): {e}")
        
    except Exception as e:
        print(f"❌ MCP server test failed: {e}")
        import traceback
        traceback.print_exc()

def test_error_handling():
    """Test that the system fails properly without fallbacks"""
    print("\n" + "="*60)
    print("TESTING ERROR HANDLING (NO FALLBACKS)")
    print("="*60)
    
    from knowledge_nano_agent import KnowledgeNanoAgent
    
    # Test nano agent without OpenAI
    old_key = os.environ.get('OPENAI_API_KEY')
    os.environ['OPENAI_API_KEY'] = 'invalid-key'
    
    try:
        agent = KnowledgeNanoAgent()
        
        # This should fail with a RuntimeError, not return a fallback
        result = agent.transform_knowledge_sync("Test content that should fail")
        print("❌ Should have failed without valid OpenAI key")
    except RuntimeError as e:
        print(f"✅ Correctly failed without OpenAI: {str(e)[:100]}...")
    except Exception as e:
        print(f"⚠️  Failed with unexpected error: {e}")
    finally:
        if old_key:
            os.environ['OPENAI_API_KEY'] = old_key
    
    # Test knowledge tools without Neo4j
    from mcp_knowledge_tools import EnhancedKnowledgeStore
    
    old_uri = os.environ.get('NEO4J_URI')
    del os.environ['NEO4J_URI']
    
    try:
        store = EnhancedKnowledgeStore()
        if not store.neo4j_driver:
            print("✅ Store initialized without Neo4j (will fail on operations)")
        else:
            print("❌ Should not have Neo4j driver without URI")
    except Exception as e:
        print(f"⚠️  Store initialization handled missing Neo4j: {e}")
    finally:
        if old_uri:
            os.environ['NEO4J_URI'] = old_uri

def main():
    """Run all tests"""
    print("="*60)
    print("COMPREHENSIVE KNOWLEDGE SYSTEM TEST")
    print("="*60)
    print(f"Started at: {datetime.now().isoformat()}")
    
    # Run all test suites
    test_nano_agent()
    test_embedding_service()
    test_knowledge_tools()
    test_mcp_server()
    test_error_handling()
    
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print("✅ All components tested")
    print("⚠️  Some features require external services (Neo4j, OpenAI)")
    print("❌ Any failures indicate missing required services")
    print("\nThe system is designed to fail properly without fallbacks.")
    print("Either full functionality or clear error messages.")
    print(f"\nCompleted at: {datetime.now().isoformat()}")

if __name__ == "__main__":
    main()