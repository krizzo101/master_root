#!/usr/bin/env python3
"""
Final Validation - Proves the system works WITHOUT fallbacks
This script will FAIL if any component doesn't work properly
"""

import sys
sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.hybrid_search import HybridSearch
from apps.knowledge_system.usage_tracking import KnowledgeUsageTracker
from apps.knowledge_system.mcp_knowledge_tools import EnhancedKnowledgeQuery

# No try/catch - let it fail if broken
def validate_system():
    print("FINAL VALIDATION - NO FALLBACKS")
    print("=" * 60)
    
    # 1. Test Hybrid Search returns BOTH scores
    print("\n1. Hybrid Search with Graph Expansion:")
    search = HybridSearch()
    results = search.search("OpenAI API", limit=3, strategy="hybrid", expand_depth=1)
    
    assert len(results) > 0, "No results returned"
    
    both_scores_count = 0
    for r in results:
        print(f"   {r.source[:40]:40} V:{r.vector_score:.3f} G:{r.graph_score:.3f}")
        if r.vector_score > 0 and r.graph_score > 0:
            both_scores_count += 1
    
    assert both_scores_count > 0, "No results with both vector AND graph scores"
    print(f"   ✓ {both_scores_count} results have both scores")
    
    # 2. Test Usage Tracking records properly
    print("\n2. Usage Tracking:")
    tracker = KnowledgeUsageTracker()
    test_id = results[0].knowledge_id
    
    track_result = tracker.track_usage(test_id, success=True, context={"query": "test"})
    assert track_result["success"], "Usage tracking failed"
    assert track_result["usage_count"] > 0, "Usage not recorded"
    print(f"   ✓ Tracked usage for {test_id[:20]}... (count: {track_result['usage_count']})")
    
    # 3. Test MCP Integration uses hybrid (not fallback)
    print("\n3. MCP Integration:")
    mcp = EnhancedKnowledgeQuery()
    mcp_result = mcp.query(
        query_type="hybrid",
        query_text="streaming",
        limit=2
    )
    
    assert mcp_result["success"], "MCP query failed"
    assert mcp_result["strategy"] == "hybrid", f"Wrong strategy: {mcp_result['strategy']}"
    
    has_graph_score = False
    for item in mcp_result["knowledge"]:
        if item.get("graph_score", 0) > 0:
            has_graph_score = True
            break
    
    assert has_graph_score, "MCP results have no graph scores"
    print(f"   ✓ MCP using hybrid strategy with graph scores")
    
    # 4. Test Graph Traversal
    print("\n4. Graph Traversal:")
    from neo4j import GraphDatabase
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
    
    with driver.session() as session:
        result = session.run("""
            MATCH path = (k:Knowledge)-[:NEXT_CHUNK*1..2]-(related:Knowledge)
            WHERE k.direct_ingestion = true
            RETURN count(path) as path_count
            LIMIT 1
        """)
        path_count = result.single()["path_count"]
        assert path_count > 0, "No graph paths found"
        print(f"   ✓ Found {path_count} graph paths")
    
    driver.close()
    search.close()
    tracker.close()
    
    print("\n" + "=" * 60)
    print("ALL VALIDATIONS PASSED - SYSTEM WORKS AS DESIGNED")
    print("=" * 60)
    return True

if __name__ == "__main__":
    try:
        success = validate_system()
        sys.exit(0 if success else 1)
    except AssertionError as e:
        print(f"\n✗ VALIDATION FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ SYSTEM ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)