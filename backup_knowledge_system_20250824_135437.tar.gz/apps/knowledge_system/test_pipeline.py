#!/usr/bin/env python3
"""Test the knowledge pipeline with Neo4j"""

import asyncio
import sys
sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.mcp_knowledge_tools import EnhancedKnowledgeStore

async def test():
    store = EnhancedKnowledgeStore()
    
    # Test storing with direct execution
    result = await store.store(
        raw_input="Test knowledge: Python async/await enables concurrent execution",
        hint_type="CODE_PATTERN",
        hint_tags=["python", "async", "test"],
        direct_execute=True
    )
    
    print(f"Store result: {result}")
    print(f"Success: {result.get('success')}")
    print(f"Knowledge ID: {result.get('knowledge_id')}")
    print(f"Direct execution: {result.get('executed_directly', False)}")

asyncio.run(test())