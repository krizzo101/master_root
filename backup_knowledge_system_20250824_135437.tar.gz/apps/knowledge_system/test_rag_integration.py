#!/usr/bin/env python3
"""
Test RAG integration with knowledge system
"""

import asyncio
import logging
import sys
from typing import Dict, Any

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add path for imports
sys.path.insert(0, "/home/opsvi/master_root")

# Import components
from apps.knowledge_system.mcp_knowledge_tools import EnhancedKnowledgeStore, EnhancedKnowledgeQuery
from apps.knowledge_system.simple_rag import test_qdrant_connection, test_redis_connection


async def test_infrastructure():
    """Test that RAG infrastructure is available"""
    print("\n=== Testing Infrastructure ===")
    print(f"Qdrant available: {test_qdrant_connection()}")
    print(f"Redis available: {test_redis_connection()}")
    
    if not test_qdrant_connection():
        print("WARNING: Qdrant not available - semantic search will not work")
    if not test_redis_connection():
        print("WARNING: Redis not available - caching disabled")
    
    return test_qdrant_connection() and test_redis_connection()


async def test_store_with_rag():
    """Test storing knowledge with RAG indexing"""
    print("\n=== Testing Knowledge Storage with RAG ===")
    
    store = EnhancedKnowledgeStore()
    
    # Test data
    test_knowledge = [
        {
            "content": "To fix TypeError in Python, use isinstance() to check variable types before operations",
            "type": "ERROR_SOLUTION",
            "tags": ["python", "error", "type", "debugging"]
        },
        {
            "content": "Use asyncio.gather() to run multiple async tasks concurrently in Python",
            "type": "CODE_PATTERN",
            "tags": ["python", "async", "concurrency", "performance"]
        },
        {
            "content": "Redis cache TTL should be set based on data volatility - use shorter TTL for frequently changing data",
            "type": "BEST_PRACTICE",
            "tags": ["redis", "cache", "performance", "ttl"]
        }
    ]
    
    stored_ids = []
    for item in test_knowledge:
        try:
            result = await store.store(
                raw_input=item["content"],
                hint_type=item["type"],
                hint_tags=item["tags"],
                direct_execute=True
            )
            
            if result.get("success"):
                stored_ids.append(result["knowledge_id"])
                print(f"✓ Stored: {result['knowledge_id'][:8]}... - {item['type']}")
                if result.get("embedding_generated"):
                    print(f"  → Embedding generated and indexed")
            else:
                print(f"✗ Failed to store: {item['content'][:50]}...")
                
        except Exception as e:
            print(f"✗ Error storing knowledge: {e}")
    
    return stored_ids


async def test_semantic_search():
    """Test semantic search functionality"""
    print("\n=== Testing Semantic Search ===")
    
    query = EnhancedKnowledgeQuery()
    
    test_queries = [
        "How to fix Python type errors",
        "async programming patterns",
        "Redis caching best practices",
        "concurrent task execution"
    ]
    
    for q in test_queries:
        print(f"\nQuery: '{q}'")
        
        # Try semantic search
        result = query.query(
            query_type="semantic",
            query_text=q,
            limit=3,
            direct_execute=True
        )
        
        if result.get("success"):
            if result.get("knowledge"):
                print(f"  Found {len(result['knowledge'])} results (type: {result.get('query_type')})")
                for i, k in enumerate(result["knowledge"], 1):
                    content = k.get("content", "")[:80]
                    print(f"  {i}. {content}...")
            elif result.get("knowledge_ids"):
                print(f"  Found {len(result['knowledge_ids'])} knowledge IDs")
                for kid in result["knowledge_ids"]:
                    print(f"    - {kid}")
            else:
                print("  No results found")
        else:
            print(f"  Search failed: {result}")


async def test_cache_performance():
    """Test cache performance"""
    print("\n=== Testing Cache Performance ===")
    
    import time
    query = EnhancedKnowledgeQuery()
    
    test_query = "Python error handling best practices"
    
    # First query (cold)
    start = time.time()
    result1 = query.query(
        query_type="semantic",
        query_text=test_query,
        limit=3,
        direct_execute=True
    )
    cold_time = time.time() - start
    print(f"Cold query time: {cold_time:.3f}s")
    
    # Second query (should be cached)
    start = time.time()
    result2 = query.query(
        query_type="semantic",
        query_text=test_query,
        limit=3,
        direct_execute=True
    )
    cached_time = time.time() - start
    print(f"Cached query time: {cached_time:.3f}s")
    
    if result2.get("query_type") == "semantic_cached":
        print(f"✓ Cache hit! Speedup: {cold_time/cached_time:.1f}x")
    else:
        print("✗ Cache miss (unexpected)")
    
    return cached_time < cold_time


async def test_fallback():
    """Test fallback to keyword search"""
    print("\n=== Testing Fallback to Keyword Search ===")
    
    query = EnhancedKnowledgeQuery()
    
    # Regular keyword search
    result = query.query(
        query_type="search",
        query_text="Python",
        limit=3,
        direct_execute=True
    )
    
    if result.get("success"):
        print(f"✓ Keyword search found {result.get('count', 0)} results")
    else:
        print("✗ Keyword search failed")


async def main():
    """Run all tests"""
    print("=" * 60)
    print("RAG Integration Test Suite")
    print("=" * 60)
    
    # Test infrastructure
    infra_ok = await test_infrastructure()
    
    if not infra_ok:
        print("\nWARNING: Not all infrastructure is available")
        print("Some tests may fail or have reduced functionality")
    
    # Store test knowledge
    stored_ids = await test_store_with_rag()
    
    if stored_ids:
        print(f"\n✓ Stored {len(stored_ids)} test knowledge entries")
        
        # Wait a moment for indexing
        await asyncio.sleep(1)
        
        # Test semantic search
        await test_semantic_search()
        
        # Test cache performance
        await test_cache_performance()
    
    # Test fallback
    await test_fallback()
    
    print("\n" + "=" * 60)
    print("Test Suite Complete")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())