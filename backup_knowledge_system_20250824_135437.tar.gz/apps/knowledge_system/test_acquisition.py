#!/usr/bin/env python3
"""
Test the automated knowledge acquisition with real storage
"""

import asyncio
import json
from datetime import datetime
from automated_acquisition_pipeline import AutomatedAcquisitionPipeline, KnowledgeCandidate

async def test_pipeline():
    """Test pipeline with a few candidates"""
    pipeline = AutomatedAcquisitionPipeline()
    
    # Create test candidates
    test_candidates = [
        KnowledgeCandidate(
            content="Test Pattern: Recursive self-improvement through feedback loops. Systems that modify their own code based on performance metrics show 40% improvement in task completion.",
            source="Test Source",
            type="CODE_PATTERN",
            confidence=0.75,
            tags=["self-improvement", "recursive", "feedback"],
            metadata={"test": True}
        ),
        KnowledgeCandidate(
            content="Architecture: Multi-agent coordination using shared memory banks. Agents can read/write to common knowledge store for emergent collaboration patterns.",
            source="Test Source",
            type="SYSTEM_ARCHITECTURE",
            confidence=0.8,
            tags=["multi-agent", "shared-memory", "collaboration"],
            metadata={"test": True}
        )
    ]
    
    # Test evaluation and storage
    for candidate in test_candidates:
        print(f"\nTesting candidate: {candidate.content[:50]}...")
        
        # Evaluate
        should_store = await pipeline.evaluate_candidate(candidate)
        print(f"Evaluation result: {should_store}")
        
        if should_store:
            # Store
            stored = await pipeline.store_knowledge(candidate)
            print(f"Storage result: {stored}")
    
    print(f"\nFinal stats: {pipeline.stats}")

if __name__ == "__main__":
    asyncio.run(test_pipeline())