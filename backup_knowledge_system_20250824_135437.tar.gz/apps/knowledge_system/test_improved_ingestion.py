#!/usr/bin/env python3
"""
Test the improved ingestion pipeline with relationship creation
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/opsvi/master_root")

from apps.knowledge_system.monitored_ingestion import CuratedDirectIngestion
from neo4j import GraphDatabase

class TestIngestion(CuratedDirectIngestion):
    """Test version that marks nodes as test_run"""
    
    def ensure_source_file(self, file_path: Path, base_path: Path) -> str:
        """Override to mark as test"""
        relative_path = str(file_path.relative_to(base_path))
        
        if relative_path in self.source_files:
            return self.source_files[relative_path]
        
        with self.neo4j_driver.session() as session:
            result = session.run("""
                MERGE (s:SourceFile {path: $path})
                ON CREATE SET 
                    s.created_at = datetime(),
                    s.file_type = $file_type,
                    s.size = $size,
                    s.test_run = true
                RETURN s.path as path
            """, path=relative_path, 
                 file_type=file_path.suffix,
                 size=file_path.stat().st_size)
            
            self.source_files[relative_path] = result.single()['path']
            return self.source_files[relative_path]
    
    def store_chunk(self, content: str, knowledge_type: str, source: str, tags: list, 
                    file_path: str = None, chunk_index: int = None) -> str:
        """Override to mark as test and use simplified ID"""
        try:
            import hashlib
            from datetime import datetime, timezone
            
            # Simpler ID for testing
            knowledge_id = f"test_{hashlib.md5(content[:50].encode()).hexdigest()[:8]}_{int(time.time() % 10000)}"
            
            # Generate embedding
            embed_key = content[:500]
            embedding = self.cache.get_cached_embedding(embed_key)
            
            if embedding:
                self.monitor.update("embeddings_cached")
            else:
                embedding = self.embedding_service.generate_embedding(embed_key)
                self.cache.cache_embedding(embed_key, embedding)
                self.monitor.update("embeddings_generated")
            
            # Index in Qdrant
            metadata = {
                "knowledge_type": knowledge_type,
                "source": source,
                "tags": tags[:10],
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "test_run": True
            }
            self.vector_search.index_knowledge(knowledge_id, embedding, metadata)
            
            # Store in Neo4j with relationships
            with self.neo4j_driver.session() as session:
                # Create Knowledge node
                result = session.run("""
                    CREATE (k:Knowledge {
                        knowledge_id: $knowledge_id,
                        knowledge_type: $knowledge_type,
                        content: $content,
                        source: $source,
                        tags: $tags,
                        confidence_score: 0.7,
                        created_at: datetime(),
                        direct_ingestion: true,
                        test_run: true,
                        embedding_model: 'sentence-transformers/all-MiniLM-L6-v2'
                    })
                    RETURN k.knowledge_id as id
                """, knowledge_id=knowledge_id,
                     knowledge_type=knowledge_type,
                     content=content[:5000],
                     source=source,
                     tags=tags)
                
                result.single()
                
                # Create relationship to SourceFile
                if file_path:
                    session.run("""
                        MATCH (s:SourceFile {path: $file_path})
                        MATCH (k:Knowledge {knowledge_id: $knowledge_id})
                        MERGE (s)-[:CONTAINS]->(k)
                    """, file_path=file_path, knowledge_id=knowledge_id)
                
                # Create NEXT_CHUNK relationship if this is part of a sequence
                if file_path and chunk_index is not None and chunk_index > 0:
                    prev_chunk_id = self.previous_chunk_ids.get(file_path)
                    if prev_chunk_id:
                        session.run("""
                            MATCH (k1:Knowledge {knowledge_id: $prev_id})
                            MATCH (k2:Knowledge {knowledge_id: $curr_id})
                            MERGE (k1)-[:NEXT_CHUNK]->(k2)
                        """, prev_id=prev_chunk_id, curr_id=knowledge_id)
                
                # Update previous chunk tracking
                if file_path and chunk_index is not None:
                    self.previous_chunk_ids[file_path] = knowledge_id
            
            return knowledge_id
            
        except Exception as e:
            print(f"Failed to store chunk: {e}")
            return None

def test_relationships():
    """Test that relationships are created properly"""
    print("="*60)
    print("TESTING IMPROVED INGESTION PIPELINE")
    print("="*60)
    
    # Run test ingestion on 5 files
    ingester = TestIngestion()
    ingester.run_ingestion("/home/opsvi/.reference/openai-python", max_files=5)
    
    # Check relationships
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))
    with driver.session() as session:
        # Check SourceFile nodes
        result = session.run("""
            MATCH (s:SourceFile {test_run: true})
            RETURN count(s) as count
        """)
        print(f"\nSourceFile nodes created: {result.single()['count']}")
        
        # Check Knowledge nodes
        result = session.run("""
            MATCH (k:Knowledge {test_run: true})
            RETURN count(k) as count
        """)
        print(f"Knowledge nodes created: {result.single()['count']}")
        
        # Check CONTAINS relationships
        result = session.run("""
            MATCH (s:SourceFile {test_run: true})-[r:CONTAINS]->(k:Knowledge {test_run: true})
            RETURN count(r) as count
        """)
        print(f"CONTAINS relationships: {result.single()['count']}")
        
        # Check NEXT_CHUNK relationships
        result = session.run("""
            MATCH (k1:Knowledge {test_run: true})-[r:NEXT_CHUNK]->(k2:Knowledge {test_run: true})
            RETURN count(r) as count
        """)
        print(f"NEXT_CHUNK relationships: {result.single()['count']}")
        
        # Show sample graph structure
        result = session.run("""
            MATCH (s:SourceFile {test_run: true})-[:CONTAINS]->(k:Knowledge {test_run: true})
            RETURN s.path as file, collect(k.source)[..3] as chunks
            LIMIT 2
        """)
        print("\nSample graph structure:")
        for record in result:
            print(f"  {record['file']}")
            for chunk in record['chunks']:
                print(f"    -> {chunk}")
    
    driver.close()
    print("\n" + "="*60)
    print("TEST COMPLETE - Relationships created during ingestion!")
    print("="*60)

if __name__ == "__main__":
    test_relationships()