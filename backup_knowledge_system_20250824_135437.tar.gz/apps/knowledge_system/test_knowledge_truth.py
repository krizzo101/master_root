#!/usr/bin/env python3
"""
Test script to verify knowledge system truth
Run this directly to see what's really happening
"""

import os
import sys
sys.path.insert(0, "/home/opsvi/master_root")

from neo4j import GraphDatabase
import json

# Connect to Neo4j
uri = "bolt://localhost:7687"
driver = GraphDatabase.driver(uri, auth=("neo4j", "password"))

def run_query(query, params=None):
    """Run a query and return results"""
    with driver.session() as session:
        result = session.run(query, params or {})
        return list(result)

# Test 1: Total knowledge count
print("="*70)
print("TEST 1: Database Truth")
print("="*70)

result = run_query("""
MATCH (k:Knowledge)
RETURN 
    count(k) as total,
    count(CASE WHEN k.deprecated = false THEN 1 END) as active,
    count(CASE WHEN k.deprecated = true THEN 1 END) as deprecated,
    count(CASE WHEN k.deprecated IS NULL THEN 1 END) as null_deprecated,
    avg(k.confidence_score) as avg_confidence,
    min(k.confidence_score) as min_confidence,
    max(k.confidence_score) as max_confidence
""")

for r in result:
    print(json.dumps(dict(r), indent=2, default=str))

# Test 2: Knowledge by confidence ranges
print("\n" + "="*70)
print("TEST 2: Confidence Distribution")
print("="*70)

result = run_query("""
MATCH (k:Knowledge)
WHERE k.deprecated = false OR k.deprecated IS NULL
RETURN 
    CASE 
        WHEN k.confidence_score >= 0.9 THEN '0.9-1.0'
        WHEN k.confidence_score >= 0.7 THEN '0.7-0.9'
        WHEN k.confidence_score >= 0.5 THEN '0.5-0.7'
        ELSE '<0.5'
    END as range,
    count(k) as count
ORDER BY range
""")

for r in result:
    print(f"{r['range']}: {r['count']} items")

# Test 3: Recent knowledge (what MCP tool should show)
print("\n" + "="*70)
print("TEST 3: Recent Knowledge (MCP Query Simulation)")
print("="*70)

# Simulate MCP tool query with min_confidence=0.7
result = run_query("""
MATCH (k:Knowledge)
WHERE k.deprecated = false
AND k.confidence_score >= 0.7
RETURN k.knowledge_id as id, 
       k.knowledge_type as type,
       substring(k.content, 0, 80) as content,
       k.confidence_score as confidence
ORDER BY k.updated_at DESC
LIMIT 10
""")

print(f"\nWith min_confidence=0.7 filter:")
for r in result:
    print(f"- {r['id']}: {r['content'][:50]}... (conf: {r['confidence']})")

# Now without confidence filter
result = run_query("""
MATCH (k:Knowledge)
WHERE k.deprecated = false OR k.deprecated IS NULL
RETURN k.knowledge_id as id, 
       k.knowledge_type as type,
       substring(k.content, 0, 80) as content,
       k.confidence_score as confidence,
       k.created_at as created
ORDER BY k.created_at DESC
LIMIT 10
""")

print(f"\nWithout confidence filter (ACTUAL recent):")
for r in result:
    conf = r['confidence'] if r['confidence'] is not None else 'NULL'
    print(f"- {r['id']}: {r['content'][:50]}... (conf: {conf})")

# Test 4: Search for my recent additions
print("\n" + "="*70)
print("TEST 4: Search for Recent Additions")
print("="*70)

search_terms = ["GPT-5", "autonomous", "meta-learning", "HNSW", "Byzantine"]

for term in search_terms:
    result = run_query("""
    MATCH (k:Knowledge)
    WHERE toLower(k.content) CONTAINS toLower($term)
    RETURN count(k) as count
    """, {"term": term})
    
    count = result[0]['count'] if result else 0
    print(f"'{term}': {count} matches")

# Test 5: Check embedding status
print("\n" + "="*70)
print("TEST 5: Embedding Status")
print("="*70)

result = run_query("""
MATCH (k:Knowledge)
WHERE k.created_at > datetime('2025-08-22T00:00:00')
RETURN 
    k.knowledge_id as id,
    k.embedding IS NOT NULL as has_embedding,
    k.embedding_model as model,
    substring(k.content, 0, 50) as content
ORDER BY k.created_at DESC
LIMIT 10
""")

for r in result:
    status = "✓ Has embedding" if r['has_embedding'] else "✗ No embedding"
    print(f"{r['id']}: {status} - {r['content']}...")

print("\n" + "="*70)
print("TRUTH VERIFICATION COMPLETE")
print("="*70)

driver.close()