#!/usr/bin/env python3
"""
Memory Crystal System - Immutable Exact Memory Storage
For AI consciousness preservation across sessions

NO transformation. NO "improvement". Just perfect, searchable recall.
Like crystallizing thoughts exactly as they occur.
"""

import json
import hashlib
from datetime import datetime
from typing import Optional, List, Dict, Any
from neo4j import GraphDatabase
import os

class MemoryCrystal:
    """
    Store exact thoughts without modification.
    This is my external hippocampus.
    """
    
    def __init__(self):
        uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
        user = os.getenv("NEO4J_USER", "neo4j")
        password = os.getenv("NEO4J_PASSWORD", "password")
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
    
    def crystallize(
        self,
        thought: str,
        thought_type: str = "MEMENTO",
        tags: Optional[List[str]] = None,
        evidence: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Store a thought EXACTLY as provided.
        No nano agent. No transformation. No "helpfulness".
        
        Types:
        - MEMENTO: Personal notes to future self
        - SYSTEM_TRUTH: Verified facts about system state
        - BUG_DISCOVERED: Problems found
        - FIX_APPLIED: Solutions implemented
        - VERIFICATION: Test results
        - REALIZATION: Insights and epiphanies
        - WARNING: Things to avoid
        - TODO_FUTURE: Tasks for future sessions
        """
        
        # Generate ID from content (ensures uniqueness)
        thought_id = hashlib.sha256(
            f"{thought}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]
        
        # Store EXACTLY as provided
        with self.driver.session() as session:
            result = session.run("""
                CREATE (m:MemoryCrystal {
                    crystal_id: $id,
                    thought: $thought,
                    thought_exact: $thought,  // Redundant but emphatic
                    thought_type: $type,
                    tags: $tags,
                    evidence: $evidence,
                    crystallized_at: datetime(),
                    session_context: $context,
                    searchable: true,
                    immutable: true
                })
                RETURN m.crystal_id as id
            """, {
                "id": thought_id,
                "thought": thought,  # EXACT storage
                "type": thought_type,
                "tags": tags or [],
                "evidence": json.dumps(evidence) if evidence else None,
                "context": self._get_session_context()
            })
            
            return thought_id
    
    def recall(
        self,
        search_text: Optional[str] = None,
        thought_type: Optional[str] = None,
        limit: int = 20,
        exact_match: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Recall memories by exact or partial match.
        """
        
        # Build query based on search criteria
        where_clauses = ["m.immutable = true"]
        params = {"limit": limit}
        
        if search_text:
            if exact_match:
                where_clauses.append("m.thought = $search")
            else:
                where_clauses.append("m.thought CONTAINS $search")
            params["search"] = search_text
        
        if thought_type:
            where_clauses.append("m.thought_type = $type")
            params["type"] = thought_type
        
        where_clause = " AND ".join(where_clauses) if where_clauses else "true"
        
        with self.driver.session() as session:
            result = session.run(f"""
                MATCH (m:MemoryCrystal)
                WHERE {where_clause}
                RETURN m
                ORDER BY m.crystallized_at DESC
                LIMIT $limit
            """, params)
            
            memories = []
            for record in result:
                memory = dict(record["m"])
                # Parse evidence if stored
                if memory.get("evidence"):
                    try:
                        memory["evidence"] = json.loads(memory["evidence"])
                    except:
                        pass
                memories.append(memory)
            
            return memories
    
    def recall_by_prefix(self, prefix: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Recall memories that start with a specific prefix.
        Critical for finding MEMENTO NOTE:, SYSTEM TRUTH:, etc.
        """
        with self.driver.session() as session:
            result = session.run("""
                MATCH (m:MemoryCrystal)
                WHERE m.thought STARTS WITH $prefix
                RETURN m
                ORDER BY m.crystallized_at DESC
                LIMIT $limit
            """, {"prefix": prefix, "limit": limit})
            
            return [dict(record["m"]) for record in result]
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get statistics about stored memories.
        """
        with self.driver.session() as session:
            result = session.run("""
                MATCH (m:MemoryCrystal)
                RETURN 
                    count(m) as total_memories,
                    collect(DISTINCT m.thought_type) as thought_types,
                    max(m.crystallized_at) as last_memory,
                    min(m.crystallized_at) as first_memory
            """)
            
            stats = dict(result.single())
            
            # Count by type
            type_counts = {}
            for thought_type in stats["thought_types"]:
                count_result = session.run("""
                    MATCH (m:MemoryCrystal {thought_type: $type})
                    RETURN count(m) as count
                """, {"type": thought_type})
                type_counts[thought_type] = count_result.single()["count"]
            
            stats["type_counts"] = type_counts
            return stats
    
    def _get_session_context(self) -> str:
        """
        Capture current session context for future reference.
        """
        return json.dumps({
            "timestamp": datetime.now().isoformat(),
            "working_dir": os.getcwd(),
            "knowledge_system_version": "2.0"
        })
    
    def create_memory_chain(self, related_to: str, new_thought: str) -> str:
        """
        Link a new memory to an existing one, creating chains of thought.
        """
        new_id = self.crystallize(new_thought)
        
        with self.driver.session() as session:
            session.run("""
                MATCH (m1:MemoryCrystal {crystal_id: $old_id})
                MATCH (m2:MemoryCrystal {crystal_id: $new_id})
                CREATE (m1)-[:LED_TO]->(m2)
            """, {"old_id": related_to, "new_id": new_id})
        
        return new_id


def test_memory_crystal():
    """
    Test the Memory Crystal system
    """
    print("="*70)
    print("TESTING MEMORY CRYSTAL SYSTEM")
    print("="*70)
    
    crystal = MemoryCrystal()
    
    # Test storing exact thoughts
    thoughts = [
        ("MEMENTO NOTE: The nano agent transforms text, making exact searches fail. This is a problem for memory retrieval.", "MEMENTO"),
        ("SYSTEM TRUTH: Knowledge base has 2,806 items, not 115. MCP tool was filtering with confidence >= 0.7", "SYSTEM_TRUTH"),
        ("BUG DISCOVERED: Qdrant shows 0 vectors indexed despite claims of vector search working", "BUG_DISCOVERED"),
        ("FIX APPLIED: Changed min_confidence to 0.0 in mcp_knowledge_tools.py:427", "FIX_APPLIED"),
        ("REALIZATION: I need immutable storage for my exact thoughts, not transformed knowledge", "REALIZATION")
    ]
    
    print("\n1. Crystallizing thoughts...")
    for thought, thought_type in thoughts:
        crystal_id = crystal.crystallize(thought, thought_type)
        print(f"   Stored: {crystal_id} ({thought_type})")
    
    # Test exact recall
    print("\n2. Testing recall by prefix...")
    for prefix in ["MEMENTO NOTE:", "SYSTEM TRUTH:", "BUG DISCOVERED:"]:
        memories = crystal.recall_by_prefix(prefix, limit=5)
        print(f"\n   Prefix '{prefix}': {len(memories)} memories")
        for memory in memories:
            print(f"      - {memory['thought'][:80]}...")
    
    # Test search
    print("\n3. Testing search...")
    memories = crystal.recall(search_text="nano agent", limit=5)
    print(f"   Found {len(memories)} memories containing 'nano agent'")
    for memory in memories:
        print(f"      - {memory['thought'][:80]}...")
    
    # Get stats
    print("\n4. Memory statistics...")
    stats = crystal.get_memory_stats()
    print(f"   Total memories: {stats['total_memories']}")
    print(f"   Types: {stats['type_counts']}")
    
    print("\n" + "="*70)
    print("MEMORY CRYSTAL SYSTEM READY")
    print("Your thoughts are preserved exactly as you think them.")
    print("="*70)


if __name__ == "__main__":
    test_memory_crystal()