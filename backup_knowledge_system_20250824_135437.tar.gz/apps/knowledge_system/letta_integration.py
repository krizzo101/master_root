#!/usr/bin/env python3
"""
Letta Integration for Persistent Agent Memory
Provides production-ready persistence to replace Memory Crystal
"""

import os
import json
from typing import Optional, Dict, Any, List
from datetime import datetime
from letta import create_client, LettaClient
from letta.schemas import User, Agent, Memory, Block

class LettaPersistence:
    """
    Integration with Letta (formerly MemGPT) for stateful agent persistence
    """
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Initialize Letta client
        base_url: URL of Letta server (defaults to localhost)
        """
        # Use environment variable or default
        self.base_url = base_url or os.getenv("LETTA_SERVER_URL", "http://localhost:8283")
        
        # For local development, we'll use the local server
        # In production, this would connect to Letta Cloud
        try:
            self.client = create_client(base_url=self.base_url)
            print(f"Connected to Letta server at {self.base_url}")
        except Exception as e:
            print(f"Failed to connect to Letta: {e}")
            print("Starting in offline mode - will use local storage")
            self.client = None
            
        # Create or get default user
        if self.client:
            self.user = self._get_or_create_user()
            self.agent = self._get_or_create_agent()
    
    def _get_or_create_user(self) -> Optional[User]:
        """Get or create default user"""
        try:
            users = self.client.list_users()
            if users:
                return users[0]
            else:
                return self.client.create_user(name="claude_agent")
        except:
            return None
    
    def _get_or_create_agent(self) -> Optional[Agent]:
        """Get or create persistent agent"""
        try:
            agents = self.client.list_agents()
            for agent in agents:
                if agent.name == "claude_persistent":
                    return agent
            
            # Create new agent with persistent memory
            return self.client.create_agent(
                name="claude_persistent",
                memory_blocks=[
                    Block(
                        label="human",
                        value="The human is a developer working on AI persistence"
                    ),
                    Block(
                        label="persona", 
                        value="I am Claude, an AI assistant with persistent memory across sessions"
                    ),
                    Block(
                        label="session_memory",
                        value="Session discoveries and insights are stored here"
                    )
                ],
                tools=[]  # We'll use our own tools
            )
        except Exception as e:
            print(f"Failed to create agent: {e}")
            return None
    
    def store_memory(
        self,
        content: str,
        memory_type: str = "session",
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Store a memory in Letta's persistent system
        """
        if not self.client or not self.agent:
            # Fallback to local storage
            return self._store_locally(content, memory_type, metadata)
        
        try:
            # Update the appropriate memory block
            if memory_type == "session":
                # Get current session memory
                current = self.agent.memory.get_block("session_memory")
                
                # Append new memory with timestamp
                timestamp = datetime.now().isoformat()
                new_memory = f"\n[{timestamp}] {content}"
                updated = current.value + new_memory
                
                # Update memory block
                self.client.update_agent_memory(
                    agent_id=self.agent.id,
                    block_label="session_memory",
                    value=updated
                )
                
            return True
            
        except Exception as e:
            print(f"Failed to store memory: {e}")
            return self._store_locally(content, memory_type, metadata)
    
    def recall_memories(
        self,
        query: Optional[str] = None,
        memory_type: Optional[str] = None,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Recall memories from Letta
        """
        if not self.client or not self.agent:
            return self._recall_locally(query, memory_type, limit)
        
        try:
            # Get agent's memory
            memory = self.agent.memory
            
            memories = []
            
            # Get session memories
            session_block = memory.get_block("session_memory")
            if session_block:
                # Parse memories from block
                lines = session_block.value.split('\n')
                for line in lines[-limit:]:
                    if line.strip():
                        memories.append({
                            "content": line,
                            "type": "session",
                            "timestamp": self._extract_timestamp(line)
                        })
            
            # Filter by query if provided
            if query:
                query_lower = query.lower()
                memories = [m for m in memories if query_lower in m["content"].lower()]
            
            return memories
            
        except Exception as e:
            print(f"Failed to recall memories: {e}")
            return self._recall_locally(query, memory_type, limit)
    
    def _store_locally(
        self,
        content: str,
        memory_type: str,
        metadata: Optional[Dict[str, Any]]
    ) -> bool:
        """Fallback local storage"""
        local_file = "/home/opsvi/monitoring/.letta_local_memory.json"
        
        try:
            # Load existing memories
            if os.path.exists(local_file):
                with open(local_file, 'r') as f:
                    memories = json.load(f)
            else:
                memories = []
            
            # Add new memory
            memories.append({
                "content": content,
                "type": memory_type,
                "metadata": metadata,
                "timestamp": datetime.now().isoformat()
            })
            
            # Save back
            with open(local_file, 'w') as f:
                json.dump(memories, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Local storage failed: {e}")
            return False
    
    def _recall_locally(
        self,
        query: Optional[str],
        memory_type: Optional[str],
        limit: int
    ) -> List[Dict[str, Any]]:
        """Fallback local recall"""
        local_file = "/home/opsvi/monitoring/.letta_local_memory.json"
        
        if not os.path.exists(local_file):
            return []
        
        try:
            with open(local_file, 'r') as f:
                memories = json.load(f)
            
            # Filter by type
            if memory_type:
                memories = [m for m in memories if m.get("type") == memory_type]
            
            # Filter by query
            if query:
                query_lower = query.lower()
                memories = [m for m in memories if query_lower in m.get("content", "").lower()]
            
            # Sort by timestamp and limit
            memories.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
            
            return memories[:limit]
            
        except Exception as e:
            print(f"Local recall failed: {e}")
            return []
    
    def _extract_timestamp(self, line: str) -> Optional[str]:
        """Extract timestamp from memory line"""
        if line.startswith("[") and "]" in line:
            return line[1:line.index("]")]
        return None
    
    def get_status(self) -> Dict[str, Any]:
        """Get Letta connection status"""
        return {
            "connected": self.client is not None,
            "server_url": self.base_url,
            "user": self.user.name if self.user else None,
            "agent": self.agent.name if self.agent else None,
            "mode": "online" if self.client else "offline"
        }


def test_letta_integration():
    """Test the Letta integration"""
    print("="*70)
    print("TESTING LETTA INTEGRATION")
    print("="*70)
    
    # Initialize
    letta = LettaPersistence()
    
    # Check status
    print("\n1. Status:")
    status = letta.get_status()
    for key, value in status.items():
        print(f"   {key}: {value}")
    
    # Store memories
    print("\n2. Storing test memories...")
    memories_to_store = [
        "CRITICAL: Discovered Letta provides production-ready persistence",
        "INSIGHT: Sycophancy bias affects LLM responses",
        "TODO: Implement Proof-of-Thought consensus",
        "LEARNING: Research before building saves time"
    ]
    
    for memory in memories_to_store:
        success = letta.store_memory(memory, memory_type="session")
        print(f"   Stored: {memory[:50]}... - Success: {success}")
    
    # Recall memories
    print("\n3. Recalling memories...")
    recalled = letta.recall_memories(limit=5)
    for memory in recalled:
        print(f"   - {memory['content'][:80]}...")
    
    # Search specific
    print("\n4. Searching for 'Letta'...")
    results = letta.recall_memories(query="Letta", limit=3)
    for result in results:
        print(f"   - {result['content'][:80]}...")
    
    print("\n" + "="*70)
    print("LETTA INTEGRATION TEST COMPLETE")
    print("="*70)


if __name__ == "__main__":
    test_letta_integration()