"""Test swarm detection with simple, controlled data"""

import time
from swarm_detection import Agent, SwarmConfig, detect_swarms, SwarmVisualizer

# Create sample agents with clear swarm patterns
sample_agents = []
base_time = time.time()

# Create a tight burst swarm - all agents within 0.1 seconds
print("Creating test agents...")
for i in range(6):
    agent = Agent(
        agent_id=f"burst_{i}",
        start_time=base_time + (i * 0.01),  # Very tight clustering
        end_time=base_time + 2.0,
        priority_score=0.8,
        resources=["/api/data"],
        task_type="burst"
    )
    sample_agents.append(agent)
    print(f"  Agent {agent.agent_id}: start={agent.start_time:.2f}")

# Add some isolated agents
for i in range(2):
    agent = Agent(
        agent_id=f"isolated_{i}",
        start_time=base_time + 100 + (i * 50),  # Far apart
        priority_score=0.5,
        resources=[f"/isolated_{i}"],
        task_type="isolated"
    )
    sample_agents.append(agent)
    print(f"  Agent {agent.agent_id}: start={agent.start_time:.2f}")

# Configure detection
config = SwarmConfig(
    temporal_epsilon=1.0,  # 1 second window
    min_swarm_size=3,      # At least 3 agents
    burst_threshold=4,     # At least 4 for burst
    burst_window=0.5       # 0.5 second window
)

print(f"\nRunning swarm detection with {len(sample_agents)} agents...")
print(f"Config: epsilon={config.temporal_epsilon}, min_size={config.min_swarm_size}")

# Detect swarms
result = detect_swarms(sample_agents, config)

# Display results
print(f"\n🔍 Swarm Detection Results")
print(f"{'=' * 50}")
print(f"Detected {len(result.swarms)} swarms from {len(sample_agents)} agents")

if result.swarms:
    visualizer = SwarmVisualizer()
    for swarm in result.swarms:
        print(f"\n{visualizer.format_swarm_display(swarm)}")
        print(f"  Type: {swarm.classification.primary_type.value}")
        print(f"  Confidence: {swarm.confidence:.2%}")
        print(f"  Agents: {', '.join(a.agent_id for a in swarm.agents)}")
else:
    print("\nNo swarms detected - debugging info:")
    print(f"  Error: {result.error}")
    print(f"  Error message: {result.error_message}")
    
    # Try to understand why
    print("\nAgent temporal distribution:")
    start_times = [a.start_time - base_time for a in sample_agents]
    print(f"  Start times (relative): {[f'{t:.3f}' for t in sorted(start_times)]}")
    
    # Check distances
    print("\nTemporal distances between consecutive agents:")
    sorted_agents = sorted(sample_agents, key=lambda a: a.start_time)
    for i in range(len(sorted_agents) - 1):
        dist = sorted_agents[i+1].start_time - sorted_agents[i].start_time
        print(f"  {sorted_agents[i].agent_id} -> {sorted_agents[i+1].agent_id}: {dist:.3f}s")

print(f"\n📊 Statistics:")
for key, value in result.statistics.items():
    print(f"  {key}: {value}")