#!/usr/bin/env python3
"""
Simplified Dependency Management Validation
Directly tests the DependencyManager component and simulates orchestration patterns
"""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent))

from src.generic_orchestrator import DependencyManager, AgentTask


class DependencyValidator:
    """Validates dependency management logic"""
    
    def __init__(self):
        self.results = []
        self.output_dir = Path("dependency_validation_results")
        self.output_dir.mkdir(exist_ok=True)
    
    async def test_linear_chain(self) -> Dict:
        """Test linear dependency chain A→B→C→D"""
        print("\n[TEST] Linear Dependency Chain")
        
        dm = DependencyManager()
        tasks = [
            AgentTask(task_id="A", task_type="test", prompt="A", dependencies=[]),
            AgentTask(task_id="B", task_type="test", prompt="B", dependencies=["A"]),
            AgentTask(task_id="C", task_type="test", prompt="C", dependencies=["B"]),
            AgentTask(task_id="D", task_type="test", prompt="D", dependencies=["C"])
        ]
        
        execution_order = []
        start_time = time.time()
        
        # Simulate execution
        for _ in range(len(tasks)):
            for task in tasks:
                if await dm.can_run(task):
                    await dm.mark_running(task.task_id)
                    await asyncio.sleep(0.01)  # Simulate work
                    await dm.mark_completed(task.task_id)
                    execution_order.append(task.task_id)
        
        duration = time.time() - start_time
        expected_order = ["A", "B", "C", "D"]
        is_valid = execution_order == expected_order
        
        result = {
            "test": "Linear Chain",
            "passed": is_valid,
            "execution_order": execution_order,
            "expected_order": expected_order,
            "duration": duration
        }
        
        print(f"  Expected: {expected_order}")
        print(f"  Actual:   {execution_order}")
        print(f"  Result:   {'✓ PASSED' if is_valid else '✗ FAILED'}")
        
        return result
    
    async def test_diamond_pattern(self) -> Dict:
        """Test diamond pattern A→[B,C]→D"""
        print("\n[TEST] Diamond Pattern")
        
        dm = DependencyManager()
        tasks = [
            AgentTask(task_id="A", task_type="test", prompt="A", dependencies=[]),
            AgentTask(task_id="B", task_type="test", prompt="B", dependencies=["A"]),
            AgentTask(task_id="C", task_type="test", prompt="C", dependencies=["A"]),
            AgentTask(task_id="D", task_type="test", prompt="D", dependencies=["B", "C"])
        ]
        
        execution_order = []
        start_time = time.time()
        
        # Simulate parallel execution
        completed = set()
        while len(completed) < len(tasks):
            runnable = []
            for task in tasks:
                if task.task_id not in completed and await dm.can_run(task):
                    runnable.append(task)
            
            # Execute all runnable tasks in parallel
            if runnable:
                for task in runnable:
                    await dm.mark_running(task.task_id)
                
                await asyncio.sleep(0.01)  # Simulate parallel work
                
                for task in runnable:
                    await dm.mark_completed(task.task_id)
                    execution_order.append(task.task_id)
                    completed.add(task.task_id)
        
        duration = time.time() - start_time
        
        # Validate: A must be first, D must be last, B and C can be in any order
        is_valid = (
            execution_order[0] == "A" and
            execution_order[-1] == "D" and
            set(execution_order[1:3]) == {"B", "C"}
        )
        
        result = {
            "test": "Diamond Pattern",
            "passed": is_valid,
            "execution_order": execution_order,
            "validation": "A first, D last, B&C in middle",
            "duration": duration
        }
        
        print(f"  Execution: {execution_order}")
        print(f"  Valid: A first={execution_order[0]=='A'}, D last={execution_order[-1]=='D'}, B&C middle={set(execution_order[1:3])=={'B','C'}}")
        print(f"  Result: {'✓ PASSED' if is_valid else '✗ FAILED'}")
        
        return result
    
    async def test_complex_graph(self) -> Dict:
        """Test complex dependency graph with multiple paths"""
        print("\n[TEST] Complex Dependency Graph")
        
        dm = DependencyManager()
        
        # Create a complex graph:
        # Layer 0: A, B, C (no dependencies)
        # Layer 1: D(A), E(A,B), F(B,C)  
        # Layer 2: G(D,E), H(E,F)
        # Layer 3: I(G,H)
        
        tasks = [
            # Layer 0
            AgentTask(task_id="A", task_type="test", prompt="A", dependencies=[]),
            AgentTask(task_id="B", task_type="test", prompt="B", dependencies=[]),
            AgentTask(task_id="C", task_type="test", prompt="C", dependencies=[]),
            # Layer 1
            AgentTask(task_id="D", task_type="test", prompt="D", dependencies=["A"]),
            AgentTask(task_id="E", task_type="test", prompt="E", dependencies=["A", "B"]),
            AgentTask(task_id="F", task_type="test", prompt="F", dependencies=["B", "C"]),
            # Layer 2
            AgentTask(task_id="G", task_type="test", prompt="G", dependencies=["D", "E"]),
            AgentTask(task_id="H", task_type="test", prompt="H", dependencies=["E", "F"]),
            # Layer 3
            AgentTask(task_id="I", task_type="test", prompt="I", dependencies=["G", "H"])
        ]
        
        execution_order = []
        execution_layers = []
        start_time = time.time()
        
        # Simulate layer-based parallel execution
        completed = set()
        while len(completed) < len(tasks):
            layer = []
            for task in tasks:
                if task.task_id not in completed and await dm.can_run(task):
                    layer.append(task.task_id)
                    await dm.mark_running(task.task_id)
            
            if layer:
                await asyncio.sleep(0.01)  # Simulate parallel work
                
                for task_id in layer:
                    await dm.mark_completed(task_id)
                    execution_order.append(task_id)
                    completed.add(task_id)
                
                execution_layers.append(layer)
        
        duration = time.time() - start_time
        
        # Validate layer structure
        expected_layers = [
            {"A", "B", "C"},  # Layer 0
            {"D", "E", "F"},  # Layer 1
            {"G", "H"},       # Layer 2
            {"I"}             # Layer 3
        ]
        
        is_valid = True
        for i, layer in enumerate(execution_layers):
            if i < len(expected_layers):
                if set(layer) != expected_layers[i]:
                    is_valid = False
                    break
        
        result = {
            "test": "Complex Graph",
            "passed": is_valid,
            "execution_layers": execution_layers,
            "expected_layers": [list(l) for l in expected_layers],
            "total_tasks": len(tasks),
            "duration": duration
        }
        
        print(f"  Execution layers:")
        for i, layer in enumerate(execution_layers):
            print(f"    Layer {i}: {layer}")
        print(f"  Result: {'✓ PASSED' if is_valid else '✗ FAILED'}")
        
        return result
    
    async def test_parallel_efficiency(self) -> Dict:
        """Test parallel execution efficiency"""
        print("\n[TEST] Parallel Execution Efficiency")
        
        dm = DependencyManager()
        
        # Create tasks with no dependencies (all can run in parallel)
        tasks = [
            AgentTask(task_id=f"P{i}", task_type="test", prompt=f"P{i}", dependencies=[])
            for i in range(10)
        ]
        
        start_time = time.time()
        
        # Execute all in parallel
        for task in tasks:
            await dm.mark_running(task.task_id)
        
        await asyncio.sleep(0.01)  # Simulate parallel work
        
        for task in tasks:
            await dm.mark_completed(task.task_id)
        
        parallel_duration = time.time() - start_time
        
        # Simulate sequential execution for comparison
        sequential_duration = 0.01 * len(tasks)
        
        efficiency = parallel_duration / sequential_duration if sequential_duration > 0 else 1.0
        
        result = {
            "test": "Parallel Efficiency",
            "passed": efficiency < 0.5,  # Should be much faster than sequential
            "parallel_time": parallel_duration,
            "sequential_estimate": sequential_duration,
            "efficiency_ratio": efficiency,
            "task_count": len(tasks)
        }
        
        print(f"  Parallel time: {parallel_duration:.3f}s")
        print(f"  Sequential estimate: {sequential_duration:.3f}s")
        print(f"  Efficiency ratio: {efficiency:.2%}")
        print(f"  Result: {'✓ PASSED' if result['passed'] else '✗ FAILED'}")
        
        return result
    
    async def test_circular_detection(self) -> Dict:
        """Test circular dependency detection"""
        print("\n[TEST] Circular Dependency Detection")
        
        # Create circular dependencies: A→B→C→A
        tasks = [
            AgentTask(task_id="A", task_type="test", prompt="A", dependencies=["C"]),
            AgentTask(task_id="B", task_type="test", prompt="B", dependencies=["A"]),
            AgentTask(task_id="C", task_type="test", prompt="C", dependencies=["B"])
        ]
        
        # Detect circular dependencies
        def has_circular_deps(tasks: List[AgentTask]) -> bool:
            task_map = {t.task_id: t for t in tasks}
            visited = set()
            rec_stack = set()
            
            def has_cycle(task_id: str) -> bool:
                visited.add(task_id)
                rec_stack.add(task_id)
                
                if task_id in task_map:
                    for dep in task_map[task_id].dependencies:
                        if dep not in visited:
                            if has_cycle(dep):
                                return True
                        elif dep in rec_stack:
                            return True
                
                rec_stack.remove(task_id)
                return False
            
            for task in tasks:
                if task.task_id not in visited:
                    if has_cycle(task.task_id):
                        return True
            return False
        
        has_circular = has_circular_deps(tasks)
        
        # Also test that DependencyManager won't execute circular deps
        dm = DependencyManager()
        can_run_any = False
        for task in tasks:
            if await dm.can_run(task):
                can_run_any = True
                break
        
        result = {
            "test": "Circular Detection",
            "passed": has_circular and not can_run_any,
            "circular_detected": has_circular,
            "prevented_execution": not can_run_any
        }
        
        print(f"  Circular detected: {has_circular}")
        print(f"  Execution prevented: {not can_run_any}")
        print(f"  Result: {'✓ PASSED' if result['passed'] else '✗ FAILED'}")
        
        return result
    
    async def test_failed_dependency(self) -> Dict:
        """Test handling of failed dependencies"""
        print("\n[TEST] Failed Dependency Handling")
        
        dm = DependencyManager()
        tasks = [
            AgentTask(task_id="A", task_type="test", prompt="A", dependencies=[]),
            AgentTask(task_id="B", task_type="test", prompt="B", dependencies=["A"]),
            AgentTask(task_id="C", task_type="test", prompt="C", dependencies=["B"])
        ]
        
        # Execute A successfully
        await dm.mark_running("A")
        await dm.mark_completed("A")
        
        # B fails
        await dm.mark_running("B")
        await dm.mark_failed("B")
        
        # C should not be able to run
        can_run_c = await dm.can_run(tasks[2])
        
        result = {
            "test": "Failed Dependency",
            "passed": not can_run_c,
            "failed_task": "B",
            "blocked_task": "C",
            "c_can_run": can_run_c
        }
        
        print(f"  Failed task: B")
        print(f"  C can run: {can_run_c}")
        print(f"  Result: {'✓ PASSED' if result['passed'] else '✗ FAILED'}")
        
        return result
    
    async def run_all_tests(self) -> Dict:
        """Run all dependency tests"""
        print("=" * 60)
        print("DEPENDENCY MANAGEMENT VALIDATION")
        print("=" * 60)
        
        tests = [
            self.test_linear_chain(),
            self.test_diamond_pattern(),
            self.test_complex_graph(),
            self.test_parallel_efficiency(),
            self.test_circular_detection(),
            self.test_failed_dependency()
        ]
        
        results = await asyncio.gather(*tests)
        
        # Calculate score
        passed = sum(1 for r in results if r["passed"])
        total = len(results)
        score = (passed / total * 10) if total > 0 else 0
        
        # Generate report
        report = {
            "timestamp": datetime.now().isoformat(),
            "test_results": results,
            "summary": {
                "total_tests": total,
                "passed": passed,
                "failed": total - passed,
                "dependency_management_score": round(score, 1)
            }
        }
        
        # Save report
        report_file = self.output_dir / f"validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        # Print summary
        print("\n" + "=" * 60)
        print("SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"\nDEPENDENCY MANAGEMENT SCORE: {score:.1f}/10")
        
        if score >= 9:
            print("\n✓ EXCELLENT: All dependency management features working perfectly")
        elif score >= 7:
            print("\n✓ GOOD: Core dependency management is functional")
        elif score >= 5:
            print("\n⚠ ADEQUATE: Basic dependency management works")
        else:
            print("\n✗ POOR: Significant dependency management issues")
        
        print(f"\nDetailed report saved to: {report_file}")
        
        return report


async def main():
    validator = DependencyValidator()
    report = await validator.run_all_tests()
    return report["summary"]["dependency_management_score"]


if __name__ == "__main__":
    score = asyncio.run(main())
    sys.exit(0 if score >= 7 else 1)