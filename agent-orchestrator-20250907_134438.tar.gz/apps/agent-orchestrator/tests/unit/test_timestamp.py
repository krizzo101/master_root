#!/usr/bin/env python3
from datetime import datetime

def main():
    current_time = datetime.now()
    timestamp_str = current_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    
    print(f"Test successful!")
    print(f"Current timestamp: {timestamp_str}")
    print(f"Unix timestamp: {int(current_time.timestamp())}")
    
    return 0

if __name__ == "__main__":
    exit(main())