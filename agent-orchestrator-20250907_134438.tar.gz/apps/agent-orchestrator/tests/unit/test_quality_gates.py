#!/usr/bin/env python3
"""
Quality Gate System Test Suite

Tests the quality gate and dependency management system with real scenarios.
"""

import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from typing import List

from src.enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask
from src.quality_gates import QualityGateManager, GateStatus, ValidationResult


async def test_basic_quality_gates():
    """Test basic quality gate functionality"""
    print("=== Testing Basic Quality Gates ===")
    
    # Create temporary directory for tests
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Initialize quality gate manager
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Test 1: File-based quality gate
        test_file = temp_path / "test_file.txt"
        
        await qg_manager.define_gate(
            gate_id="file_exists",
            name="Test File Exists",
            description="Test file should exist",
            validator_type="file",
            config={
                "path": str(test_file),
                "exists": True
            }
        )
        
        # Gate should fail initially (file doesn't exist)
        result = await qg_manager.validate_gate("file_exists")
        assert not result.success, "Gate should fail when file doesn't exist"
        print("✓ File gate correctly failed when file missing")
        
        # Create the file
        test_file.write_text("test content")
        
        # Gate should pass now
        result = await qg_manager.validate_gate("file_exists")
        assert result.success, "Gate should pass when file exists"
        print("✓ File gate correctly passed when file exists")
        
        # Test 2: Command-based quality gate
        await qg_manager.define_gate(
            gate_id="command_success",
            name="Command Success",
            description="Test command should succeed",
            validator_type="command",
            config={
                "command": ["echo", "success"],
                "expected_return_code": 0
            }
        )
        
        result = await qg_manager.validate_gate("command_success")
        assert result.success, "Command gate should succeed"
        print("✓ Command gate correctly passed")
        
        # Test 3: Gate with dependencies
        await qg_manager.define_gate(
            gate_id="dependent_gate",
            name="Dependent Gate",
            description="Gate that depends on file existing",
            validator_type="command",
            config={
                "command": ["test", "-f", str(test_file)],
                "expected_return_code": 0
            },
            dependencies=["file_exists"]
        )
        
        result = await qg_manager.validate_gate("dependent_gate")
        assert result.success, "Dependent gate should succeed when dependency passes"
        print("✓ Dependent gate correctly passed")
        
        print("Basic quality gate tests passed!\n")
        return True


async def test_orchestrator_integration():
    """Test quality gate integration with orchestrator"""
    print("=== Testing Orchestrator Integration ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create orchestrator with quality gates
        orchestrator = EnhancedOrchestrator(
            output_dir=temp_path / "orchestrator",
            max_parallel=2,
            enable_quality_gates=True
        )
        
        # Define a simple quality gate
        test_marker = temp_path / "ready_marker.txt"
        
        await orchestrator.define_quality_gate(
            gate_id="system_ready",
            name="System Ready",
            description="System initialization marker exists",
            validator_type="file",
            config={
                "path": str(test_marker),
                "exists": True
            }
        )
        
        # Define test tasks
        def generate_test_tasks() -> List[EnhancedAgentTask]:
            return [
                orchestrator.create_enhanced_task(
                    task_id="init_system",
                    task_type="setup",
                    prompt=f"Create system ready marker at {test_marker}",
                    quality_gates=[]  # No gates for this task
                ),
                orchestrator.create_enhanced_task(
                    task_id="use_system",
                    task_type="operation",
                    prompt="Use the system for processing",
                    dependencies=["init_system"],
                    quality_gates=["system_ready"]  # Depends on system being ready
                )
            ]
        
        # Mock task execution since we're testing gate logic
        class MockOrchestrator(EnhancedOrchestrator):
            async def execute_agent(self, task: EnhancedAgentTask) -> dict:
                """Mock execution that creates the marker file for first task"""
                if task.task_id == "init_system":
                    # Create the marker file
                    test_marker.write_text("system ready")
                    task.status = "completed"
                    task.result = {"message": "System initialized"}
                elif task.task_id == "use_system":
                    # This task should only run after quality gate passes
                    task.status = "completed"
                    task.result = {"message": "System used successfully"}
                
                # Mark dependencies
                await self.dep_manager.mark_completed(task.task_id)
                return task.to_dict()
        
        # Use mock orchestrator
        mock_orchestrator = MockOrchestrator(
            output_dir=temp_path / "orchestrator",
            max_parallel=2,
            enable_quality_gates=True
        )
        
        # Copy quality gates from original
        mock_orchestrator.quality_gate_manager = orchestrator.quality_gate_manager
        
        try:
            results = await mock_orchestrator.run(generate_test_tasks)
            
            assert results['metrics']['completed'] == 2, "Both tasks should complete"
            assert results['metrics']['failed'] == 0, "No tasks should fail"
            
            print("✓ Tasks executed with quality gate validation")
            print(f"✓ Completed: {results['metrics']['completed']}/{results['metrics']['total']}")
            
            # Check quality status
            if 'quality_status' in results:
                gates = results['quality_status']['gates']
                assert gates['system_ready']['status'] == 'passed', "System ready gate should pass"
                print("✓ Quality gates validated correctly")
            
            print("Orchestrator integration tests passed!\n")
            return True
            
        finally:
            if mock_orchestrator.quality_gate_manager:
                await mock_orchestrator.quality_gate_manager.stop_validation_loop()


async def test_parallel_gate_validation():
    """Test parallel validation of multiple gates"""
    print("=== Testing Parallel Gate Validation ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Create multiple gates that will be validated in parallel
        gates = []
        for i in range(5):
            gate_id = f"parallel_gate_{i}"
            await qg_manager.define_gate(
                gate_id=gate_id,
                name=f"Parallel Gate {i}",
                description=f"Gate {i} for parallel testing",
                validator_type="command",
                config={
                    "command": ["sleep", "0.1"],  # Small delay to simulate work
                    "expected_return_code": 0
                }
            )
            gates.append(gate_id)
        
        # Validate all gates in parallel
        start_time = time.time()
        validation_tasks = [qg_manager.validate_gate(gate_id) for gate_id in gates]
        results = await asyncio.gather(*validation_tasks)
        end_time = time.time()
        
        # All should succeed
        for i, result in enumerate(results):
            assert result.success, f"Gate {i} should succeed"
        
        # Should take roughly the same time as sequential (due to parallel execution)
        elapsed = end_time - start_time
        print(f"✓ Validated {len(gates)} gates in parallel in {elapsed:.2f}s")
        
        # Test dependency chain validation
        await qg_manager.define_gate(
            gate_id="chain_gate",
            name="Chain Gate",
            description="Gate depending on all parallel gates",
            validator_type="command",
            config={
                "command": ["echo", "chain complete"],
                "expected_return_code": 0
            },
            dependencies=gates  # Depends on all parallel gates
        )
        
        result = await qg_manager.validate_gate("chain_gate")
        assert result.success, "Chain gate should succeed when all dependencies pass"
        print("✓ Dependency chain validation works")
        
        print("Parallel validation tests passed!\n")
        return True


async def test_error_handling():
    """Test error handling in quality gates"""
    print("=== Testing Error Handling ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Test 1: Invalid validator type
        try:
            await qg_manager.define_gate(
                gate_id="invalid_gate",
                name="Invalid Gate",
                description="Gate with invalid validator",
                validator_type="nonexistent_validator",
                config={}
            )
            assert False, "Should raise error for invalid validator"
        except ValueError:
            print("✓ Correctly rejected invalid validator type")
        
        # Test 2: Failing command gate
        await qg_manager.define_gate(
            gate_id="failing_gate",
            name="Failing Gate",
            description="Gate that should fail",
            validator_type="command",
            config={
                "command": ["false"],  # Command that always fails
                "expected_return_code": 0
            }
        )
        
        result = await qg_manager.validate_gate("failing_gate")
        assert not result.success, "Failing gate should fail"
        print("✓ Failing gate correctly failed")
        
        # Test 3: Missing file gate
        await qg_manager.define_gate(
            gate_id="missing_file_gate",
            name="Missing File Gate", 
            description="Gate for file that doesn't exist",
            validator_type="file",
            config={
                "path": "/nonexistent/file.txt",
                "exists": True
            }
        )
        
        result = await qg_manager.validate_gate("missing_file_gate")
        assert not result.success, "Missing file gate should fail"
        print("✓ Missing file gate correctly failed")
        
        # Test 4: Circular dependency detection (not implemented yet, but good to test)
        await qg_manager.define_gate(
            gate_id="gate_a",
            name="Gate A",
            description="Gate A",
            validator_type="command",
            config={"command": ["echo", "a"], "expected_return_code": 0},
            dependencies=["gate_b"]
        )
        
        await qg_manager.define_gate(
            gate_id="gate_b", 
            name="Gate B",
            description="Gate B",
            validator_type="command",
            config={"command": ["echo", "b"], "expected_return_code": 0},
            dependencies=["gate_a"]  # Circular dependency
        )
        
        # This would cause infinite loop - in real implementation should detect and fail
        print("✓ Circular dependency handling (would need implementation)")
        
        print("Error handling tests passed!\n")
        return True


async def test_real_world_scenario():
    """Test with a realistic scenario similar to unified context system"""
    print("=== Testing Real-World Scenario ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        orchestrator = EnhancedOrchestrator(
            output_dir=temp_path / "orchestrator",
            max_parallel=3,
            enable_quality_gates=True
        )
        
        # Simulate database setup files
        db_config = temp_path / "database.config"
        migration_complete = temp_path / "migration.done"
        api_ready = temp_path / "api.ready"
        
        # Define quality gates for realistic scenario
        await orchestrator.define_quality_gate(
            gate_id="database_configured",
            name="Database Configured",
            description="Database configuration file exists",
            validator_type="file",
            config={
                "path": str(db_config),
                "exists": True,
                "contains": "postgresql"
            }
        )
        
        await orchestrator.define_quality_gate(
            gate_id="migration_finished",
            name="Migration Finished", 
            description="Database migration completed",
            validator_type="file",
            config={
                "path": str(migration_complete),
                "exists": True
            },
            dependencies=["database_configured"]
        )
        
        await orchestrator.define_quality_gate(
            gate_id="api_available",
            name="API Available",
            description="API service is ready",
            validator_type="file",
            config={
                "path": str(api_ready),
                "exists": True
            },
            dependencies=["migration_finished"]
        )
        
        # Define phases
        await orchestrator.define_phase(
            phase_id="setup",
            name="Setup Phase",
            description="Database and infrastructure setup",
            gates=["database_configured", "migration_finished"]
        )
        
        await orchestrator.define_phase(
            phase_id="services",
            name="Services Phase", 
            description="API and service initialization",
            gates=["api_available"]
        )
        
        # Mock realistic tasks
        class RealisticMockOrchestrator(EnhancedOrchestrator):
            async def execute_agent(self, task: EnhancedAgentTask) -> dict:
                """Mock realistic task execution"""
                
                if task.task_id == "setup_database":
                    db_config.write_text("postgresql://localhost:5432/testdb")
                    task.status = "completed"
                    task.result = {"database_url": "postgresql://localhost:5432/testdb"}
                    
                elif task.task_id == "run_migration":
                    migration_complete.write_text("Migration completed successfully")
                    task.status = "completed"
                    task.result = {"migrated_tables": 5, "records_migrated": 1000}
                    
                elif task.task_id == "start_api":
                    api_ready.write_text("API server started on port 8080")
                    task.status = "completed"
                    task.result = {"api_port": 8080, "endpoints": 12}
                    
                elif task.task_id == "validate_system":
                    task.status = "completed"
                    task.result = {"validation_tests": 25, "passed": 25}
                
                await self.dep_manager.mark_completed(task.task_id)
                return task.to_dict()
        
        mock_orchestrator = RealisticMockOrchestrator(
            output_dir=temp_path / "orchestrator",
            max_parallel=3,
            enable_quality_gates=True
        )
        mock_orchestrator.quality_gate_manager = orchestrator.quality_gate_manager
        
        def generate_realistic_tasks() -> List[EnhancedAgentTask]:
            return [
                mock_orchestrator.create_enhanced_task(
                    task_id="setup_database",
                    task_type="infrastructure",
                    prompt="Set up PostgreSQL database with configuration",
                    quality_gates=[],
                    phase_id="setup"
                ),
                mock_orchestrator.create_enhanced_task(
                    task_id="run_migration",
                    task_type="migration",
                    prompt="Run database migration scripts",
                    dependencies=["setup_database"],
                    quality_gates=["database_configured"],
                    phase_id="setup"
                ),
                mock_orchestrator.create_enhanced_task(
                    task_id="start_api",
                    task_type="service",
                    prompt="Start API service",
                    dependencies=["run_migration"], 
                    quality_gates=["migration_finished"],
                    phase_id="services"
                ),
                mock_orchestrator.create_enhanced_task(
                    task_id="validate_system",
                    task_type="validation",
                    prompt="Run full system validation tests",
                    dependencies=["start_api"],
                    quality_gates=["api_available"],
                    phase_id="services"
                )
            ]
        
        try:
            results = await mock_orchestrator.run(generate_realistic_tasks)
            
            assert results['metrics']['completed'] == 4, "All tasks should complete"
            assert results['metrics']['failed'] == 0, "No tasks should fail"
            
            print(f"✓ Realistic scenario completed: {results['metrics']['completed']} tasks")
            
            # Verify quality status
            if 'quality_status' in results:
                phases = results['quality_status']['phases']
                print(f"✓ Setup phase: {phases.get('setup', {}).get('gates_passed', 'N/A')}")
                print(f"✓ Services phase: {phases.get('services', {}).get('gates_passed', 'N/A')}")
            
            print("Real-world scenario test passed!\n")
            return True
            
        finally:
            if mock_orchestrator.quality_gate_manager:
                await mock_orchestrator.quality_gate_manager.stop_validation_loop()


async def run_all_tests():
    """Run all quality gate tests"""
    
    print("Quality Gate System Test Suite")
    print("=" * 50)
    
    tests = [
        test_basic_quality_gates,
        test_orchestrator_integration, 
        test_parallel_gate_validation,
        test_error_handling,
        test_real_world_scenario
    ]
    
    results = []
    for test in tests:
        try:
            result = await test()
            results.append((test.__name__, "PASSED" if result else "FAILED"))
        except Exception as e:
            print(f"❌ {test.__name__} FAILED: {e}")
            import traceback
            traceback.print_exc()
            results.append((test.__name__, "FAILED"))
        
        print()  # Blank line between tests
    
    # Summary
    print("=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status_icon = "✅" if result == "PASSED" else "❌"
        print(f"{status_icon} {test_name}: {result}")
        if result == "PASSED":
            passed += 1
    
    print(f"\nPassed: {passed}/{len(results)} tests")
    
    if passed == len(results):
        print("🎉 All tests passed! Quality gate system is working correctly.")
        return True
    else:
        print("❌ Some tests failed. Please review the issues above.")
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())