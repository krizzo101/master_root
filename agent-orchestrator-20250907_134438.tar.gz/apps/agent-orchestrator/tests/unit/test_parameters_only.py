#!/usr/bin/env python3
"""
Test parameter initialization only (no execution).
This script verifies that new parameters are correctly initialized.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

# Monkey-patch to avoid token issues during testing
import src.generic_orchestrator as gen_orch


class MockTokenPool:
    def __init__(self, tokens=None):
        self.tokens = tokens or ["test_token"]


# Replace TokenPool temporarily
original_token_pool = gen_orch.TokenPool
gen_orch.TokenPool = MockTokenPool

try:
    from src.generic_orchestrator import GenericOrchestrator
    from src.enhanced_orchestrator import EnhancedOrchestrator
    from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig

    
    def test_generic_orchestrator_parameters():
        """Test GenericOrchestrator parameter initialization"""
        print("Testing GenericOrchestrator parameters...")
        
        # Test with old-style parameters only
        orch1 = GenericOrchestrator(
            output_dir=Path("/tmp/test_generic"),
            max_parallel=10,
            tokens=["test"],
            use_optimizations=True
        )
        
        # Verify defaults for new parameters
        assert orch1.agent_execution_profile == "standard"
        assert orch1.agent_debug_mode == False
        assert orch1.enable_dynamic_configs == False
        assert orch1.log_to_work_dir == False
        assert orch1.master_mcp_registry_path is None
        assert orch1.agent_base_work_dir == Path("/tmp/test_generic/agent_workspaces")
        assert orch1.use_optimizations == True
        assert orch1.max_parallel == 10
        
        # Test with all new parameters
        orch2 = GenericOrchestrator(
            output_dir=Path("/tmp/test_generic2"),
            max_parallel=5,
            tokens=["test"],
            use_optimizations=False,
            master_mcp_registry_path=Path("/tmp/registry.json"),
            agent_execution_profile="research",
            agent_debug_mode=True,
            agent_base_work_dir=Path("/tmp/custom"),
            enable_dynamic_configs=True,
            log_to_work_dir=True
        )
        
        # Verify all parameters are set correctly
        assert orch2.agent_execution_profile == "research"
        assert orch2.agent_debug_mode == True
        assert orch2.enable_dynamic_configs == True
        assert orch2.log_to_work_dir == True
        assert orch2.master_mcp_registry_path == Path("/tmp/registry.json")
        assert orch2.agent_base_work_dir == Path("/tmp/custom")
        assert orch2.use_optimizations == False
        assert orch2.max_parallel == 5
        
        print("✓ GenericOrchestrator parameters verified")
    
    
    def test_enhanced_orchestrator_parameters():
        """Test EnhancedOrchestrator parameter initialization"""
        print("Testing EnhancedOrchestrator parameters...")
        
        # Import after monkey-patching
        from enhanced_orchestrator import EnhancedOrchestrator
        
        # Test with old-style parameters
        orch = EnhancedOrchestrator(
            output_dir=Path("/tmp/test_enhanced"),
            max_parallel=8,
            tokens=["test"],
            use_optimizations=True,
            enable_quality_gates=False,
            enable_monitoring=True
        )
        
        # Verify inherited defaults
        assert orch.agent_execution_profile == "standard"
        assert orch.agent_debug_mode == False
        assert orch.enable_dynamic_configs == False
        
        # Test with mixed old and new parameters
        orch2 = EnhancedOrchestrator(
            output_dir=Path("/tmp/test_enhanced2"),
            max_parallel=8,
            tokens=["test"],
            use_optimizations=True,
            enable_quality_gates=True,
            enable_monitoring=False,
            agent_execution_profile="minimal",
            agent_debug_mode=True
        )
        
        assert orch2.agent_execution_profile == "minimal"
        assert orch2.agent_debug_mode == True
        
        print("✓ EnhancedOrchestrator parameters verified")
    
    
    def test_unified_config_parameters():
        """Test UnifiedConfig dataclass parameters"""
        print("Testing UnifiedConfig parameters...")
        
        # Test with old-style config
        config1 = UnifiedConfig(
            output_dir=Path("/tmp/test_unified"),
            max_parallel=12,
            tokens=["test"],
            use_optimizations=True
        )
        
        # Verify defaults for new fields
        assert config1.agent_execution_profile == "standard"
        assert config1.agent_debug_mode == False
        assert config1.enable_dynamic_configs == False
        assert config1.log_to_work_dir == False
        assert config1.master_mcp_registry_path is None
        assert config1.agent_base_work_dir is None
        
        # Test with all parameters
        config2 = UnifiedConfig(
            output_dir=Path("/tmp/test_unified2"),
            max_parallel=15,
            tokens=["test"],
            use_optimizations=False,
            master_mcp_registry_path=Path("/tmp/master.json"),
            agent_execution_profile="full",
            agent_debug_mode=True,
            agent_base_work_dir=Path("/tmp/agents"),
            enable_dynamic_configs=True,
            log_to_work_dir=True
        )
        
        # Verify all parameters
        assert config2.agent_execution_profile == "full"
        assert config2.agent_debug_mode == True
        assert config2.enable_dynamic_configs == True
        assert config2.log_to_work_dir == True
        assert config2.master_mcp_registry_path == Path("/tmp/master.json")
        assert config2.agent_base_work_dir == Path("/tmp/agents")
        
        # Test that config parameters can be passed to orchestrator
        # (Skip actual UnifiedOrchestrator init due to async issues in test environment)
        # The important part is that the UnifiedConfig has the correct fields
        
        print("✓ UnifiedConfig parameters verified")
    
    
    def test_profile_filtering():
        """Test profile filtering function"""
        print("Testing profile filtering...")
        
        orch = GenericOrchestrator(
            output_dir=Path("/tmp/test_filter"),
            tokens=["test"]
        )
        
        test_config = {
            "mcpServers": {
                "shell_exec": {},
                "time": {},
                "mcp_web_search": {},
                "firecrawl": {},
                "research_papers": {},
                "tech_docs": {},
                "knowledge": {},
                "extra_server": {}
            }
        }
        
        # Test different profiles
        minimal = orch._filter_mcp_by_profile(test_config, "minimal")
        assert len(minimal["mcpServers"]) == 2
        
        standard = orch._filter_mcp_by_profile(test_config, "standard")
        assert len(standard["mcpServers"]) == 5
        
        research = orch._filter_mcp_by_profile(test_config, "research")
        assert len(research["mcpServers"]) == 7
        
        full = orch._filter_mcp_by_profile(test_config, "full")
        assert len(full["mcpServers"]) == 8
        
        print("✓ Profile filtering verified")
    
    
    print("=" * 60)
    print("PARAMETER ENHANCEMENT TEST")
    print("=" * 60)
    
    test_generic_orchestrator_parameters()
    test_enhanced_orchestrator_parameters()
    test_unified_config_parameters()
    test_profile_filtering()
    
    print("\n" + "=" * 60)
    print("ALL PARAMETER TESTS PASSED!")
    print("Backward compatibility maintained ✓")
    print("=" * 60)

finally:
    # Restore original TokenPool
    gen_orch.TokenPool = original_token_pool