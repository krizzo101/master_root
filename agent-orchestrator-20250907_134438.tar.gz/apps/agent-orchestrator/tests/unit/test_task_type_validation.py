#!/usr/bin/env python3
"""
Task Type Validation Test Suite
Tests that all valid task types are accepted and invalid ones are rejected
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.execution_plan_api import ExecutionPlanSchemaValidator
from src.working_quality_gates import TaskStructureGate
from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class TestTask:
    """Simple task class for testing"""
    task_id: str
    task_type: str
    prompt: str


def test_execution_plan_validator():
    """Test the ExecutionPlanSchemaValidator task type validation"""
    print("\n" + "="*60)
    print("Testing ExecutionPlanSchemaValidator Task Type Validation")
    print("="*60)
    
    validator = ExecutionPlanSchemaValidator()
    
    # Valid task types that should pass
    valid_types = [
        # Architecture & Design
        "security-architect",
        "solution-architect",
        "requirements-analyst",
        # Development & Testing
        "development-specialist",
        "qa-testing-guru",
        "performance-optimizer",
        # Integration & Data
        "api-integration-specialist",
        "database-specialist",
        # Analysis & Documentation
        "business-analyst",
        "technical-writer",
        "research-genius",
        "code-analyzer",
        # Legacy types
        "general-purpose",
        "web-scraper",
        "data-processor",
        "file-processor",
        "api-caller",
        "validation",
        "monitoring",
    ]
    
    # Invalid task types that should be rejected
    invalid_types = [
        "test-remediation-specialist",  # Old invalid type
        "random-specialist",
        "unknown-type",
        "fake-architect",
    ]
    
    print("\n✅ Testing VALID task types (should all pass):")
    print("-" * 50)
    
    all_valid_passed = True
    for task_type in valid_types:
        tasks = [{"task_id": f"test_{task_type}", "task_type": task_type}]
        invalid = validator._validate_task_types(tasks)
        if invalid:
            print(f"  ❌ {task_type}: FAILED - Incorrectly marked as invalid")
            all_valid_passed = False
        else:
            print(f"  ✓ {task_type}: Passed")
    
    print("\n❌ Testing INVALID task types (should all be rejected):")
    print("-" * 50)
    
    all_invalid_rejected = True
    for task_type in invalid_types:
        tasks = [{"task_id": f"test_{task_type}", "task_type": task_type}]
        invalid = validator._validate_task_types(tasks)
        if not invalid:
            print(f"  ❌ {task_type}: FAILED - Should have been rejected")
            all_invalid_rejected = False
        else:
            print(f"  ✓ {task_type}: Correctly rejected")
    
    print("\n" + "="*60)
    if all_valid_passed and all_invalid_rejected:
        print("✅ ExecutionPlanSchemaValidator: ALL TESTS PASSED")
    else:
        print("❌ ExecutionPlanSchemaValidator: SOME TESTS FAILED")
    print("="*60)
    
    return all_valid_passed and all_invalid_rejected


async def test_task_quality_gate():
    """Test the TaskStructureGate task type validation"""
    print("\n" + "="*60)
    print("Testing TaskStructureGate Task Type Validation")
    print("="*60)
    
    gate = TaskStructureGate()
    
    # Valid task types that should pass (no warnings)
    valid_types = [
        # Architecture & Design
        "security-architect",
        "solution-architect",
        "requirements-analyst",
        # Development & Testing
        "development-specialist",
        "qa-testing-guru",
        "performance-optimizer",
        # Integration & Data
        "api-integration-specialist",
        "database-specialist",
        # Analysis & Documentation
        "business-analyst",
        "technical-writer",
        "research-genius",
        "code-analyzer",
        # Legacy simple types
        "research", "design", "code", "test", "review", "documentation",
    ]
    
    # Invalid task types that should generate warnings
    invalid_types = [
        "test-remediation-specialist",
        "random-specialist",
        "unknown-type",
    ]
    
    print("\n✅ Testing VALID task types (should have no warnings):")
    print("-" * 50)
    
    all_valid_passed = True
    for task_type in valid_types:
        task = TestTask(
            task_id=f"test_{task_type}",
            task_type=task_type,
            prompt="This is a test prompt with sufficient length for validation."
        )
        result = await gate.validate_pre_execution(task)
        
        # Check if there are warnings about task type
        type_warnings = [w for w in result.warnings if "task_type" in w]
        if type_warnings:
            print(f"  ❌ {task_type}: FAILED - Got warning: {type_warnings[0]}")
            all_valid_passed = False
        else:
            print(f"  ✓ {task_type}: Passed (no type warnings)")
    
    print("\n❌ Testing INVALID task types (should generate warnings):")
    print("-" * 50)
    
    all_invalid_warned = True
    for task_type in invalid_types:
        task = TestTask(
            task_id=f"test_{task_type}",
            task_type=task_type,
            prompt="This is a test prompt with sufficient length for validation."
        )
        result = await gate.validate_pre_execution(task)
        
        # Check if there are warnings about task type
        type_warnings = [w for w in result.warnings if "task_type" in w]
        if not type_warnings:
            print(f"  ❌ {task_type}: FAILED - Should have generated a warning")
            all_invalid_warned = False
        else:
            print(f"  ✓ {task_type}: Correctly warned - {type_warnings[0][:50]}...")
    
    print("\n" + "="*60)
    if all_valid_passed and all_invalid_warned:
        print("✅ TaskStructureGate: ALL TESTS PASSED")
    else:
        print("❌ TaskStructureGate: SOME TESTS FAILED")
    print("="*60)
    
    return all_valid_passed and all_invalid_warned


def test_validation_execution_plan():
    """Test that validation_execution_plan_fixed.py uses valid task types"""
    print("\n" + "="*60)
    print("Testing validation_execution_plan_fixed.py Task Types")
    print("="*60)
    
    # Read the file and check for invalid task types
    file_path = Path(__file__).parent / "validation_execution_plan_fixed.py"
    
    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        return False
    
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Check that test-remediation-specialist is NOT present
    if "test-remediation-specialist" in content:
        print("❌ FAILED: Found invalid 'test-remediation-specialist' in file")
        return False
    else:
        print("✓ No invalid 'test-remediation-specialist' found")
    
    # Check that qa-testing-guru IS present (as replacement)
    if "qa-testing-guru" in content:
        print("✓ Valid 'qa-testing-guru' task type is being used")
    else:
        print("⚠️ Warning: 'qa-testing-guru' not found (might be using other valid types)")
    
    print("\n" + "="*60)
    print("✅ validation_execution_plan_fixed.py: TESTS PASSED")
    print("="*60)
    
    return True


async def main():
    """Run all validation tests"""
    print("\n" + "#"*60)
    print("#" + " "*20 + "TASK TYPE VALIDATION" + " "*18 + "#")
    print("#" + " "*18 + "COMPREHENSIVE TEST SUITE" + " "*16 + "#")
    print("#"*60)
    
    results = []
    
    # Test 1: ExecutionPlanValidator
    results.append(("ExecutionPlanSchemaValidator", test_execution_plan_validator()))
    
    # Test 2: TaskStructureGate
    results.append(("TaskStructureGate", await test_task_quality_gate()))
    
    # Test 3: validation_execution_plan_fixed.py
    results.append(("validation_execution_plan_fixed.py", test_validation_execution_plan()))
    
    # Final Summary
    print("\n" + "#"*60)
    print("#" + " "*23 + "FINAL SUMMARY" + " "*22 + "#")
    print("#"*60)
    
    all_passed = all(result[1] for result in results)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name:40} {status}")
    
    print("\n" + "#"*60)
    if all_passed:
        print("#" + " "*15 + "🎉 ALL TESTS PASSED! 🎉" + " "*16 + "#")
        print("#" + " "*10 + "Task type validation is working correctly" + " "*8 + "#")
    else:
        print("#" + " "*18 + "⚠️ SOME TESTS FAILED ⚠️" + " "*15 + "#")
        print("#" + " "*12 + "Please review the failures above" + " "*13 + "#")
    print("#"*60)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))