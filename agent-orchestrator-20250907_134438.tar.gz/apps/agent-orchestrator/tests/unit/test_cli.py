#!/usr/bin/env python3
"""
Test script for CLI interface
"""

import sys
import subprocess
from pathlib import Path

def test_help():
    """Test help output"""
    print("Testing --help flag...")
    result = subprocess.run([sys.executable, "cli_interface.py", "--help"], 
                          capture_output=True, text=True)
    if result.returncode == 0:
        print("✓ Help text displayed successfully")
    else:
        print("✗ Help text failed")
    return result.returncode == 0

def test_version():
    """Test version output"""
    print("Testing --version flag...")
    result = subprocess.run([sys.executable, "cli_interface.py", "--version"], 
                          capture_output=True, text=True)
    if "1.0.0" in result.stdout or "1.0.0" in result.stderr:
        print("✓ Version displayed successfully")
        return True
    else:
        print("✗ Version display failed")
        return False

def test_list_files():
    """Test file listing"""
    print("Testing --list-files flag...")
    result = subprocess.run([sys.executable, "cli_interface.py", "--list-files"], 
                          capture_output=True, text=True)
    print(f"✓ List files executed (exit code: {result.returncode})")
    return True

def test_health_check():
    """Test health check"""
    print("Testing --health-check flag...")
    result = subprocess.run([sys.executable, "cli_interface.py", "--health-check"], 
                          capture_output=True, text=True)
    if "Health Check:" in result.stdout:
        print("✓ Health check executed successfully")
        return True
    else:
        print("✗ Health check failed")
        return False

def test_config_export():
    """Test config export"""
    print("Testing config export...")
    test_file = Path("test_config.yaml")
    result = subprocess.run([sys.executable, "cli_interface.py", 
                           "--export-config", str(test_file)], 
                          capture_output=True, text=True)
    if test_file.exists():
        print("✓ Config exported successfully")
        test_file.unlink()  # Clean up
        return True
    else:
        print("✗ Config export failed")
        return False

def main():
    """Run all tests"""
    print("="*50)
    print("CLI Interface Test Suite")
    print("="*50)
    
    tests = [
        test_help,
        test_version,
        test_list_files,
        test_health_check,
        test_config_export,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"✗ Test failed with exception: {e}")
            failed += 1
        print()
    
    print("="*50)
    print(f"Results: {passed} passed, {failed} failed")
    print("="*50)
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())