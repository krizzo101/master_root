#!/usr/bin/env python3
"""
Test with real Claude log files
"""

import asyncio
import json
import sys
import time
from datetime import datetime
from pathlib import Path

# Test parsing real log file format
def test_real_log_parsing():
    """Test parsing actual Claude log file entries"""
    log_file = Path("/home/opsvi/.claude/projects/-home-opsvi-hecaton-phase2-worktrees-phase2-monitoring-20250827-014155/e6d681a8-1524-4031-8ca6-ab281450cc3d.jsonl")
    
    if not log_file.exists():
        print("Log file not found")
        return False
    
    print("Testing real log file parsing...")
    
    success_count = 0
    error_count = 0
    total_lines = 0
    
    with open(log_file, 'r') as f:
        for line_num, line in enumerate(f, 1):
            total_lines += 1
            if total_lines > 100:  # Test first 100 lines
                break
            
            try:
                data = json.loads(line.strip())
                
                # Check for expected fields
                has_type = 'type' in data
                has_timestamp = 'timestamp' in data
                has_uuid = 'uuid' in data
                
                if has_type and has_timestamp and has_uuid:
                    success_count += 1
                else:
                    print(f"  Line {line_num}: Missing fields - type:{has_type}, timestamp:{has_timestamp}, uuid:{has_uuid}")
                    error_count += 1
                    
            except json.JSONDecodeError as e:
                print(f"  Line {line_num}: JSON decode error: {e}")
                error_count += 1
            except Exception as e:
                print(f"  Line {line_num}: Unexpected error: {e}")
                error_count += 1
    
    print(f"\nParsing results:")
    print(f"  Total lines tested: {total_lines}")
    print(f"  Successfully parsed: {success_count}")
    print(f"  Errors: {error_count}")
    print(f"  Success rate: {(success_count/total_lines)*100:.1f}%")
    
    return error_count == 0


async def test_live_monitoring():
    """Test live monitoring with timeout"""
    from enhanced_swarm_log_tailer import (
        EnhancedSwarmLogTailer,
        SystemConfig,
        SwarmConfig,
        VisualConfig,
        OutputConfig
    )
    
    print("\nTesting live monitoring (5 second timeout)...")
    
    config = SystemConfig(
        projects_dir=Path("~/.claude/projects").expanduser(),
        pattern="*.jsonl",
        max_files=5
    )
    
    swarm_config = SwarmConfig(
        enabled=True,
        time_window_seconds=300,
        min_agents=2
    )
    
    visual_config = VisualConfig(
        use_color=True,
        use_emoji=False,
        color_scheme="default"
    )
    
    output_config = OutputConfig(quiet=False)
    
    tailer = EnhancedSwarmLogTailer(
        system_config=config,
        swarm_config=swarm_config,
        visual_config=visual_config,
        output_config=output_config
    )
    
    # Run for 5 seconds then stop
    try:
        task = asyncio.create_task(tailer.start())
        await asyncio.sleep(5)
        await tailer.stop()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        
        print(f"\nMonitoring test completed:")
        print(f"  Files monitored: {tailer.statistics['files_monitored']}")
        print(f"  Events processed: {tailer.statistics['events_processed']}")
        print(f"  Swarms detected: {tailer.statistics['swarms_detected']}")
        
        return True
        
    except Exception as e:
        print(f"Error during monitoring: {e}")
        return False


async def main():
    """Run all tests"""
    print("="*60)
    print("Testing Enhanced Swarm Log Tailer with Real Data")
    print("="*60)
    
    # Test 1: Parse real log files
    parse_success = test_real_log_parsing()
    
    # Test 2: Live monitoring
    monitor_success = await test_live_monitoring()
    
    print("\n" + "="*60)
    print("Test Results:")
    print(f"  Real log parsing: {'PASS' if parse_success else 'FAIL'}")
    print(f"  Live monitoring: {'PASS' if monitor_success else 'FAIL'}")
    print("="*60)
    
    return parse_success and monitor_success


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)