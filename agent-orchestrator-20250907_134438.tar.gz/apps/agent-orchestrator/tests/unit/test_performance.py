#!/usr/bin/env python3
"""
Performance testing for Enhanced Swarm Log Tailer
"""

import asyncio
import json
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any
import random
import string
import psutil
import gc

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from enhanced_swarm_log_tailer import (
    EnhancedSwarmLogTailer,
    SystemConfig,
    SwarmConfig,
    VisualConfig,
    OutputConfig,
    LogParser
)


class PerformanceTests:
    """Performance test suite"""
    
    def __init__(self):
        self.test_dir = None
        self.results = []
    
    def setup(self):
        """Setup test environment"""
        self.test_dir = Path(tempfile.mkdtemp(prefix="perf_test_"))
        self.projects_dir = self.test_dir / ".claude" / "projects"
        self.projects_dir.mkdir(parents=True, exist_ok=True)
        print(f"Performance test directory: {self.test_dir}")
    
    def teardown(self):
        """Cleanup test environment"""
        if self.test_dir and self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def generate_log_entry(self, timestamp: datetime = None) -> str:
        """Generate a single log entry in JSONL format"""
        if timestamp is None:
            timestamp = datetime.now()
        
        entry = {
            "type": random.choice(["message", "tool_use", "response", "user"]),
            "timestamp": timestamp.isoformat() + "Z",
            "uuid": ''.join(random.choices(string.ascii_lowercase + string.digits, k=16)),
            "session_id": ''.join(random.choices(string.ascii_lowercase + string.digits, k=16)),
            "agent_id": f"agent_{random.randint(1000, 9999)}",
            "content": f"Test message content {random.randint(1, 1000000)}"
        }
        
        # Add random tool use data
        if entry["type"] == "tool_use":
            entry["tool_use"] = {
                "tool": random.choice(["Read", "Write", "Bash", "WebFetch"]),
                "parameters": {"test": "data"}
            }
        
        return json.dumps(entry)
    
    def create_large_log_file(self, num_entries: int, file_path: Path) -> float:
        """Create a large log file and return generation time"""
        start = time.time()
        
        with open(file_path, 'w') as f:
            base_time = datetime.now() - timedelta(hours=1)
            for i in range(num_entries):
                timestamp = base_time + timedelta(seconds=i * 0.1)
                f.write(self.generate_log_entry(timestamp) + '\n')
        
        return time.time() - start
    
    async def test_parsing_speed(self):
        """Test log parsing performance"""
        print("\n" + "="*60)
        print("TEST: Log Parsing Speed")
        print("="*60)
        
        test_sizes = [1000, 10000, 50000, 100000]
        
        for size in test_sizes:
            log_file = self.projects_dir / f"parse_test_{size}.jsonl"
            
            # Generate file
            gen_time = self.create_large_log_file(size, log_file)
            file_size_mb = log_file.stat().st_size / (1024 * 1024)
            
            # Parse file
            parse_start = time.time()
            parsed_count = 0
            error_count = 0
            
            with open(log_file, 'r') as f:
                for line in f:
                    entry = LogParser.parse_line(line)
                    if entry:
                        parsed_count += 1
                    else:
                        error_count += 1
            
            parse_time = time.time() - parse_start
            parse_rate = parsed_count / parse_time if parse_time > 0 else 0
            
            print(f"\nSize: {size:,} entries ({file_size_mb:.1f} MB)")
            print(f"  Generation: {gen_time:.2f}s")
            print(f"  Parsing: {parse_time:.2f}s")
            print(f"  Rate: {parse_rate:,.0f} entries/sec")
            print(f"  Errors: {error_count}")
            
            self.results.append({
                "test": "parsing",
                "size": size,
                "time": parse_time,
                "rate": parse_rate
            })
            
            # Clean up file to save space
            log_file.unlink()
    
    async def test_concurrent_monitoring(self):
        """Test concurrent file monitoring performance"""
        print("\n" + "="*60)
        print("TEST: Concurrent File Monitoring")
        print("="*60)
        
        file_counts = [10, 50, 100, 200]
        
        for count in file_counts:
            # Create test files
            print(f"\nTesting with {count} files...")
            
            for i in range(count):
                log_file = self.projects_dir / f"concurrent_{i:04d}.jsonl"
                self.create_large_log_file(100, log_file)  # 100 entries each
            
            # Configure tailer
            config = SystemConfig(
                projects_dir=self.projects_dir,
                pattern="concurrent_*.jsonl",
                max_files=count,
                worker_threads=min(50, count),
                buffer_size=1000
            )
            
            # Measure file discovery
            from enhanced_swarm_log_tailer import AsyncFileMonitor
            monitor = AsyncFileMonitor(config)
            
            discover_start = time.time()
            files = await monitor.discover_files()
            discover_time = time.time() - discover_start
            
            print(f"  Files discovered: {len(files)}")
            print(f"  Discovery time: {discover_time:.3f}s")
            
            self.results.append({
                "test": "discovery",
                "count": count,
                "time": discover_time
            })
            
            # Clean up files
            for f in self.projects_dir.glob("concurrent_*.jsonl"):
                f.unlink()
    
    async def test_swarm_detection_performance(self):
        """Test swarm detection algorithm performance"""
        print("\n" + "="*60)
        print("TEST: Swarm Detection Performance")
        print("="*60)
        
        event_counts = [100, 500, 1000, 5000]
        
        for count in event_counts:
            print(f"\nTesting with {count} events...")
            
            # Generate events
            from enhanced_swarm_log_tailer import LogEvent, LogEntry, AgentInfo
            
            events = []
            base_time = datetime.now()
            
            for i in range(count):
                entry = LogEntry(
                    type="message",
                    timestamp=base_time + timedelta(seconds=i * 0.1),
                    uuid=f"uuid_{i}",
                    session_id=f"session_{i % 10}",
                    agent_id=f"agent_{i % 20}",
                    content=f"Test content {i}"
                )
                
                event = LogEvent(
                    entry=entry,
                    agent_info=AgentInfo(
                        agent_id=entry.agent_id,
                        session_id=entry.session_id,
                        project_path=Path("/test")
                    )
                )
                events.append(event)
            
            # Test swarm detection
            swarm_config = SwarmConfig(
                enabled=True,
                time_window_seconds=60,
                min_agents=3
            )
            
            # Test simple detector
            from enhanced_swarm_log_tailer import SimpleSwarmDetector
            simple_detector = SimpleSwarmDetector(swarm_config)
            
            simple_start = time.time()
            simple_swarms = await simple_detector.detect_swarms(events)
            simple_time = time.time() - simple_start
            
            print(f"  Simple detector: {simple_time:.3f}s, {len(simple_swarms)} swarms")
            
            # Test advanced detector if available
            try:
                from enhanced_swarm_log_tailer import AdvancedSwarmDetector
                advanced_detector = AdvancedSwarmDetector(swarm_config)
                
                advanced_start = time.time()
                advanced_swarms = await advanced_detector.detect_swarms(events)
                advanced_time = time.time() - advanced_start
                
                print(f"  Advanced detector: {advanced_time:.3f}s, {len(advanced_swarms)} swarms")
                
                self.results.append({
                    "test": "swarm_advanced",
                    "count": count,
                    "time": advanced_time
                })
            except ImportError:
                print("  Advanced detector: Not available (missing scientific libs)")
            
            self.results.append({
                "test": "swarm_simple",
                "count": count,
                "time": simple_time
            })
    
    async def test_memory_usage(self):
        """Test memory usage under load"""
        print("\n" + "="*60)
        print("TEST: Memory Usage")
        print("="*60)
        
        process = psutil.Process()
        
        # Get baseline memory
        gc.collect()
        baseline_memory = process.memory_info().rss / (1024 * 1024)  # MB
        print(f"Baseline memory: {baseline_memory:.1f} MB")
        
        # Create large log file
        log_file = self.projects_dir / "memory_test.jsonl"
        self.create_large_log_file(50000, log_file)
        
        # Configure tailer with limited buffer
        config = SystemConfig(
            projects_dir=self.projects_dir,
            pattern="memory_test.jsonl",
            buffer_size=1000,
            max_memory_mb=100
        )
        
        swarm_config = SwarmConfig(enabled=True)
        visual_config = VisualConfig(use_color=False)
        output_config = OutputConfig(quiet=True)
        
        tailer = EnhancedSwarmLogTailer(
            system_config=config,
            swarm_config=swarm_config,
            visual_config=visual_config,
            output_config=output_config
        )
        
        # Process file
        files = await tailer.file_monitor.discover_files()
        
        # Read and process all entries
        event_count = 0
        with open(log_file, 'r') as f:
            for line in f:
                entry = LogParser.parse_line(line)
                if entry:
                    event_count += 1
                    if event_count % 1000 == 0:
                        current_memory = process.memory_info().rss / (1024 * 1024)
                        memory_increase = current_memory - baseline_memory
                        print(f"  After {event_count:,} events: {current_memory:.1f} MB (+{memory_increase:.1f} MB)")
        
        # Final memory
        gc.collect()
        final_memory = process.memory_info().rss / (1024 * 1024)
        total_increase = final_memory - baseline_memory
        
        print(f"\nFinal memory: {final_memory:.1f} MB")
        print(f"Total increase: {total_increase:.1f} MB")
        
        self.results.append({
            "test": "memory",
            "baseline_mb": baseline_memory,
            "final_mb": final_memory,
            "increase_mb": total_increase
        })
        
        # Clean up
        log_file.unlink()
    
    async def run_all_tests(self):
        """Run all performance tests"""
        print("\n" + "="*70)
        print("PERFORMANCE TEST SUITE FOR ENHANCED SWARM LOG TAILER")
        print("="*70)
        
        self.setup()
        
        try:
            start_time = time.time()
            
            # Run tests
            await self.test_parsing_speed()
            await self.test_concurrent_monitoring()
            await self.test_swarm_detection_performance()
            await self.test_memory_usage()
            
            total_time = time.time() - start_time
            
            # Print summary
            print("\n" + "="*70)
            print("PERFORMANCE TEST SUMMARY")
            print("="*70)
            
            print("\nParsing Performance:")
            for r in self.results:
                if r["test"] == "parsing":
                    print(f"  {r['size']:,} entries: {r['rate']:,.0f} entries/sec")
            
            print("\nFile Discovery Performance:")
            for r in self.results:
                if r["test"] == "discovery":
                    print(f"  {r['count']} files: {r['time']:.3f}s")
            
            print("\nSwarm Detection Performance:")
            for r in self.results:
                if r["test"].startswith("swarm_"):
                    detector = r["test"].split("_")[1]
                    print(f"  {detector.capitalize()} - {r['count']} events: {r['time']:.3f}s")
            
            print("\nMemory Usage:")
            for r in self.results:
                if r["test"] == "memory":
                    print(f"  Baseline: {r['baseline_mb']:.1f} MB")
                    print(f"  Final: {r['final_mb']:.1f} MB")
                    print(f"  Increase: {r['increase_mb']:.1f} MB")
            
            print(f"\nTotal test time: {total_time:.2f} seconds")
            
            # Performance criteria
            print("\n" + "="*70)
            print("PERFORMANCE CRITERIA CHECK")
            print("="*70)
            
            criteria = {
                "Parsing > 10,000 entries/sec": any(
                    r["rate"] > 10000 for r in self.results if r["test"] == "parsing"
                ),
                "File discovery < 1s for 100 files": any(
                    r["time"] < 1.0 for r in self.results 
                    if r["test"] == "discovery" and r["count"] == 100
                ),
                "Memory increase < 200 MB": any(
                    r["increase_mb"] < 200 for r in self.results if r["test"] == "memory"
                )
            }
            
            for criterion, passed in criteria.items():
                status = "✓ PASS" if passed else "✗ FAIL"
                print(f"{status}: {criterion}")
            
            all_passed = all(criteria.values())
            print(f"\nOverall: {'PASS' if all_passed else 'FAIL'}")
            
            return all_passed
            
        finally:
            self.teardown()


async def main():
    """Main entry point"""
    tests = PerformanceTests()
    success = await tests.run_all_tests()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())