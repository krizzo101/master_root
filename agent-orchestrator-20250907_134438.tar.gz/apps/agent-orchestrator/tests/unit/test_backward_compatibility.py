#!/usr/bin/env python3
"""
Test backward compatibility of orchestrator parameter enhancements.
This script verifies that existing code continues to work without modification.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.generic_orchestrator import GenericOrchestrator
from src.enhanced_orchestrator import EnhancedOrchestrator
from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig


def test_generic_orchestrator_backward_compat():
    """Test GenericOrchestrator with old-style initialization"""
    print("Testing GenericOrchestrator backward compatibility...")
    
    # Old-style initialization (should work)
    orch1 = GenericOrchestrator(
        output_dir=Path("/tmp/test_generic"),
        max_parallel=10,
        tokens=None,
        use_optimizations=True
    )
    
    # Verify defaults are set correctly
    assert orch1.agent_execution_profile == "standard"
    assert orch1.agent_debug_mode == False
    assert orch1.enable_dynamic_configs == False
    assert orch1.log_to_work_dir == False
    assert orch1.master_mcp_registry_path is None
    assert orch1.agent_base_work_dir == Path("/tmp/test_generic/agent_workspaces")
    
    # Even simpler initialization
    orch2 = GenericOrchestrator(output_dir=Path("/tmp/test_generic2"))
    assert orch2.max_parallel == 10  # Default value
    assert orch2.use_optimizations == True  # Default value
    
    print("✓ GenericOrchestrator backward compatibility verified")


def test_enhanced_orchestrator_backward_compat():
    """Test EnhancedOrchestrator with old-style initialization"""
    print("Testing EnhancedOrchestrator backward compatibility...")
    
    # Old-style initialization (should work)
    orch = EnhancedOrchestrator(
        output_dir=Path("/tmp/test_enhanced"),
        max_parallel=5,
        tokens=None,
        use_optimizations=True,
        enable_quality_gates=True,
        enable_monitoring=False
    )
    
    # Verify defaults are set correctly (inherited from GenericOrchestrator)
    assert orch.agent_execution_profile == "standard"
    assert orch.agent_debug_mode == False
    assert orch.enable_dynamic_configs == False
    assert orch.log_to_work_dir == False
    assert orch.master_mcp_registry_path is None
    
    print("✓ EnhancedOrchestrator backward compatibility verified")


def test_unified_orchestrator_backward_compat():
    """Test UnifiedOrchestrator with old-style initialization"""
    print("Testing UnifiedOrchestrator backward compatibility...")
    
    # Old-style config (should work)
    config = UnifiedConfig(
        output_dir=Path("/tmp/test_unified"),
        max_parallel=8,
        tokens=None,
        use_optimizations=True
    )
    
    # Verify defaults are set correctly
    assert config.agent_execution_profile == "standard"
    assert config.agent_debug_mode == False
    assert config.enable_dynamic_configs == False
    assert config.log_to_work_dir == False
    assert config.master_mcp_registry_path is None
    assert config.agent_base_work_dir is None
    
    # Create orchestrator with old-style config
    orch = UnifiedOrchestrator(config)
    
    # Verify parameters were passed through correctly
    assert orch.agent_execution_profile == "standard"
    assert orch.agent_debug_mode == False
    
    print("✓ UnifiedOrchestrator backward compatibility verified")


def test_new_parameters():
    """Test that new parameters work correctly"""
    print("Testing new parameter functionality...")
    
    # Test with all new parameters
    orch = GenericOrchestrator(
        output_dir=Path("/tmp/test_new"),
        max_parallel=10,
        tokens=None,
        use_optimizations=True,
        # New parameters
        master_mcp_registry_path=Path("/tmp/master_registry.json"),
        agent_execution_profile="research",
        agent_debug_mode=True,
        agent_base_work_dir=Path("/tmp/custom_workspace"),
        enable_dynamic_configs=True,
        log_to_work_dir=True
    )
    
    # Verify new parameters are set correctly
    assert orch.master_mcp_registry_path == Path("/tmp/master_registry.json")
    assert orch.agent_execution_profile == "research"
    assert orch.agent_debug_mode == True
    assert orch.agent_base_work_dir == Path("/tmp/custom_workspace")
    assert orch.enable_dynamic_configs == True
    assert orch.log_to_work_dir == True
    
    # Verify agent work dir was created
    assert orch.agent_base_work_dir.exists()
    
    print("✓ New parameters working correctly")


def test_profile_filtering():
    """Test the profile filtering function"""
    print("Testing profile filtering...")
    
    orch = GenericOrchestrator(
        output_dir=Path("/tmp/test_filter"),
        agent_execution_profile="minimal"
    )
    
    # Test config with many servers
    test_config = {
        "mcpServers": {
            "shell_exec": {"command": "test1"},
            "time": {"command": "test2"},
            "mcp_web_search": {"command": "test3"},
            "firecrawl": {"command": "test4"},
            "research_papers": {"command": "test5"},
            "tech_docs": {"command": "test6"},
            "knowledge": {"command": "test7"},
            "other_server": {"command": "test8"},
        }
    }
    
    # Test minimal profile
    filtered = orch._filter_mcp_by_profile(test_config, "minimal")
    assert len(filtered["mcpServers"]) == 2
    assert "shell_exec" in filtered["mcpServers"]
    assert "time" in filtered["mcpServers"]
    assert "mcp_web_search" not in filtered["mcpServers"]
    
    # Test standard profile
    filtered = orch._filter_mcp_by_profile(test_config, "standard")
    assert len(filtered["mcpServers"]) == 5
    assert "research_papers" in filtered["mcpServers"]
    assert "tech_docs" not in filtered["mcpServers"]
    
    # Test research profile
    filtered = orch._filter_mcp_by_profile(test_config, "research")
    assert len(filtered["mcpServers"]) == 7
    assert "knowledge" in filtered["mcpServers"]
    assert "other_server" not in filtered["mcpServers"]
    
    # Test full profile (should return unchanged)
    filtered = orch._filter_mcp_by_profile(test_config, "full")
    assert filtered == test_config
    
    print("✓ Profile filtering working correctly")


if __name__ == "__main__":
    print("=" * 60)
    print("ORCHESTRATOR BACKWARD COMPATIBILITY TEST")
    print("=" * 60)
    
    try:
        test_generic_orchestrator_backward_compat()
        test_enhanced_orchestrator_backward_compat()
        test_unified_orchestrator_backward_compat()
        test_new_parameters()
        test_profile_filtering()
        
        print("\n" + "=" * 60)
        print("ALL TESTS PASSED - Full backward compatibility maintained!")
        print("=" * 60)
        
    except AssertionError as e:
        print(f"\n✗ TEST FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ UNEXPECTED ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)