#!/usr/bin/env python3
"""
Test dynamic token pool allocation
"""

import sys
import time
from pathlib import Path

sys.path.append(str(Path(__file__).parent / 'src'))
from dynamic_token_pool import DynamicTokenPool

def test_dynamic_allocation():
    """Test that single agent gets all tokens"""
    
    print("Testing Dynamic Token Pool")
    print("="*50)
    
    # Create pool
    pool = DynamicTokenPool()
    
    # Check initial status
    status = pool.get_status()
    print(f"Initial state:")
    print(f"  Total tokens: {status['total_tokens']}")
    print(f"  Available: {status['available']}")
    print(f"  Instances: {status['instances']}")
    
    # Request tokens (should get all 18)
    print("\nRequesting tokens...")
    tokens = pool.request_tokens()
    
    print(f"✅ Got {len(tokens)} tokens!")
    
    # Check status after allocation
    status = pool.get_status()
    print(f"\nAfter allocation:")
    print(f"  My tokens: {status['my_tokens']}")
    print(f"  In use: {status['in_use']}")
    print(f"  Available: {status['available']}")
    
    # Show distribution
    if status['distribution']:
        print(f"\nToken distribution:")
        for instance, info in status['distribution'].items():
            print(f"  {instance}: {info['tokens']} tokens ({info['percentage']:.1f}%)")
    
    # Simulate second agent
    print("\n" + "="*50)
    print("Simulating what happens when second agent starts...")
    print("(In reality, it would wait for tokens to be released)")
    print("Second agent would start with 0 tokens and gradually get 9")
    
    # Release tokens
    print("\nReleasing all tokens...")
    pool.release_all()
    
    # Final status
    status = pool.get_status()
    print(f"\nFinal state:")
    print(f"  Available: {status['available']}")
    print(f"  Instances: {status['instances']}")
    
    return len(tokens) == 18

if __name__ == "__main__":
    success = test_dynamic_allocation()
    
    if success:
        print("\n✅ SUCCESS: Dynamic pool correctly allocated all 18 tokens to single agent!")
    else:
        print("\n❌ FAILED: Did not get expected token count")
    
    sys.exit(0 if success else 1)