#!/usr/bin/env python3
"""
Test suite for async monitoring system
"""

import asyncio
import json
import tempfile
import time
from pathlib import Path
from datetime import datetime
import sys

sys.path.insert(0, str(Path(__file__).parent))
from async_monitoring import (
    AsyncFileMonitor, 
    MessageQueue, 
    OutputProcessor,
    AsyncMonitoringPipeline,
    LogMessage,
    Priority
)


async def test_single_file_monitoring():
    """Test monitoring a single file"""
    print("\n=== Testing Single File Monitoring ===")
    
    # Create test file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        test_file = Path(f.name)
        f.write("Initial line\n")
    
    try:
        monitor = AsyncFileMonitor()
        messages = []
        
        # Start monitoring
        async def monitor_task():
            async for msg in monitor.tail_file(test_file):
                messages.append(msg)
                print(f"Received: {msg.content}")
                if len(messages) >= 3:
                    break
        
        task = asyncio.create_task(monitor_task())
        
        # Write more lines
        await asyncio.sleep(0.5)
        with open(test_file, 'a') as f:
            f.write("Second line\n")
            f.write("Third line\n")
        
        # Wait for messages
        await asyncio.wait_for(task, timeout=5.0)
        
        assert len(messages) >= 3, f"Expected 3+ messages, got {len(messages)}"
        assert messages[0].content == "Initial line"
        assert messages[1].content == "Second line"
        assert messages[2].content == "Third line"
        
        print("✓ Single file monitoring test passed")
        
    finally:
        test_file.unlink()
        await monitor.stop()


async def test_multiple_files():
    """Test monitoring multiple files concurrently"""
    print("\n=== Testing Multiple File Monitoring ===")
    
    # Create test files
    test_files = []
    for i in range(3):
        with tempfile.NamedTemporaryFile(mode='w', suffix=f'_{i}.log', delete=False) as f:
            test_file = Path(f.name)
            f.write(f"File {i} initial\n")
            test_files.append(test_file)
    
    try:
        monitor = AsyncFileMonitor()
        messages = []
        
        # Start monitoring
        async def monitor_task():
            async for msg in monitor.monitor_files(test_files):
                messages.append(msg)
                print(f"From {msg.file_path.name}: {msg.content}")
                if len(messages) >= 9:  # 3 initial + 6 new
                    break
        
        task = asyncio.create_task(monitor_task())
        
        # Write to all files
        await asyncio.sleep(0.5)
        for i, test_file in enumerate(test_files):
            with open(test_file, 'a') as f:
                f.write(f"File {i} update 1\n")
                f.write(f"File {i} update 2\n")
        
        # Wait for messages
        await asyncio.wait_for(task, timeout=5.0)
        
        assert len(messages) >= 9, f"Expected 9+ messages, got {len(messages)}"
        
        # Check we got messages from all files
        file_names = {msg.file_path.name for msg in messages}
        assert len(file_names) == 3, f"Expected messages from 3 files, got {len(file_names)}"
        
        print("✓ Multiple file monitoring test passed")
        
    finally:
        for test_file in test_files:
            test_file.unlink()
        await monitor.stop()


async def test_json_parsing():
    """Test JSON log parsing"""
    print("\n=== Testing JSON Log Parsing ===")
    
    # Create test file with JSON logs
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        test_file = Path(f.name)
        json_log = {
            "timestamp": datetime.now().isoformat(),
            "agent_id": "agent-001",
            "session_id": "session-123",
            "level": "ERROR",
            "message": "Test error message"
        }
        f.write(json.dumps(json_log) + "\n")
    
    try:
        monitor = AsyncFileMonitor()
        messages = []
        
        # Monitor file
        async def monitor_task():
            async for msg in monitor.tail_file(test_file):
                messages.append(msg)
                break
        
        await asyncio.wait_for(monitor_task(), timeout=2.0)
        
        assert len(messages) == 1
        msg = messages[0]
        assert msg.agent_id == "agent-001"
        assert msg.session_id == "session-123"
        assert msg.priority == Priority.HIGH  # ERROR should be high priority
        
        print("✓ JSON parsing test passed")
        
    finally:
        test_file.unlink()
        await monitor.stop()


async def test_message_queue():
    """Test priority message queue"""
    print("\n=== Testing Message Queue ===")
    
    queue = MessageQueue(high_size=10, medium_size=10, low_size=10)
    
    # Add messages with different priorities
    test_messages = [
        LogMessage(datetime.now(), Path("test.log"), 1, "Low priority", Priority.LOW),
        LogMessage(datetime.now(), Path("test.log"), 2, "High priority", Priority.HIGH),
        LogMessage(datetime.now(), Path("test.log"), 3, "Medium priority", Priority.MEDIUM),
    ]
    
    for msg in test_messages:
        await queue.put(msg)
    
    # Get messages - should get high priority first
    msg1 = await queue.get()
    assert msg1.priority == Priority.HIGH
    assert msg1.content == "High priority"
    
    msg2 = await queue.get()
    assert msg2.priority == Priority.MEDIUM
    assert msg2.content == "Medium priority"
    
    msg3 = await queue.get()
    assert msg3.priority == Priority.LOW
    assert msg3.content == "Low priority"
    
    print("✓ Message queue test passed")


async def test_backpressure():
    """Test queue back-pressure handling"""
    print("\n=== Testing Back-Pressure ===")
    
    queue = MessageQueue(high_size=5, medium_size=5, low_size=5)
    
    # Fill low priority queue
    for i in range(10):
        msg = LogMessage(
            datetime.now(), Path("test.log"), i, 
            f"Low {i}", Priority.LOW
        )
        result = await queue.put(msg)
        if i < 5:
            assert result is True, f"Message {i} should be queued"
        else:
            # After threshold, low priority should be dropped
            pass  # May or may not be dropped depending on threshold
    
    stats = queue.get_stats()
    print(f"Queue stats: {stats}")
    assert stats['messages_dropped'] > 0, "Some messages should be dropped"
    
    print("✓ Back-pressure test passed")


async def test_pipeline_integration():
    """Test complete pipeline integration"""
    print("\n=== Testing Pipeline Integration ===")
    
    # Create test file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        test_file = Path(f.name)
        f.write("Pipeline test line 1\n")
    
    try:
        pipeline = AsyncMonitoringPipeline(max_concurrent=10)
        await pipeline.start([test_file])
        
        # Write more data
        await asyncio.sleep(0.5)
        with open(test_file, 'a') as f:
            for i in range(5):
                f.write(f"Pipeline test line {i+2}\n")
        
        # Let it process
        await asyncio.sleep(2.0)
        
        # Check stats
        stats = pipeline.queue.get_stats()
        print(f"Pipeline stats: {stats}")
        assert stats['messages_queued'] > 0
        assert stats['messages_processed'] > 0
        
        print("✓ Pipeline integration test passed")
        
    finally:
        test_file.unlink()
        await pipeline.stop()


async def test_file_rotation():
    """Test handling of file rotation/truncation"""
    print("\n=== Testing File Rotation ===")
    
    # Create test file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        test_file = Path(f.name)
        f.write("Line before rotation\n")
    
    try:
        monitor = AsyncFileMonitor()
        messages = []
        
        # Start monitoring
        async def monitor_task():
            async for msg in monitor.tail_file(test_file):
                messages.append(msg)
                if len(messages) >= 3:
                    break
        
        task = asyncio.create_task(monitor_task())
        
        # Simulate rotation by truncating file
        await asyncio.sleep(0.5)
        with open(test_file, 'w') as f:
            f.write("Line after rotation 1\n")
            f.write("Line after rotation 2\n")
        
        # Wait for messages
        await asyncio.wait_for(task, timeout=5.0)
        
        # Should have old line and new lines
        assert len(messages) >= 3
        assert "rotation" in messages[-1].content.lower()
        
        print("✓ File rotation test passed")
        
    finally:
        test_file.unlink()
        await monitor.stop()


async def run_all_tests():
    """Run all tests"""
    print("Starting async monitoring tests...")
    
    tests = [
        test_single_file_monitoring,
        test_multiple_files,
        test_json_parsing,
        test_message_queue,
        test_backpressure,
        test_pipeline_integration,
        test_file_rotation
    ]
    
    for test in tests:
        try:
            await test()
        except Exception as e:
            print(f"✗ Test {test.__name__} failed: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n=== All tests completed ===")


if __name__ == "__main__":
    asyncio.run(run_all_tests())