#!/usr/bin/env python3
"""Test error conditions and edge cases"""

import sys
import os
from pathlib import Path
import tempfile
import json

sys.path.insert(0, 'src')

from enhanced_orchestrator import EnhancedOrchestrator
from generic_orchestrator import GenericOrchestrator

print("=== TESTING ERROR CONDITIONS ===")

# Create temp directory for testing
test_dir = Path(tempfile.mkdtemp(prefix="error_test_"))
print(f"Test directory: {test_dir}")

# Test 1: Invalid parameters
print("\n1. Testing invalid parameters...")
test_cases = []

# Test invalid temperature (if implemented)
try:
    orch = GenericOrchestrator(
        output_dir=test_dir / "invalid_temp",
        tokens=["token1"],
        max_parallel=-5  # Invalid negative value
    )
    print("✗ Accepted negative max_parallel (should validate)")
except Exception as e:
    print(f"✓ Rejected negative max_parallel: {e}")

# Test 2: Missing tokens
print("\n2. Testing missing tokens...")
try:
    orch = GenericOrchestrator(
        output_dir=test_dir / "no_tokens",
        tokens=None
    )
    print("✗ Accepted None tokens (should fail)")
except Exception as e:
    print(f"✓ Rejected None tokens: {e}")

# Test empty token list
try:
    orch = GenericOrchestrator(
        output_dir=test_dir / "empty_tokens",
        tokens=[]
    )
    print("✗ Accepted empty token list (should fail)")
except Exception as e:
    print(f"✓ Rejected empty token list: {e}")

# Test 3: Invalid directories
print("\n3. Testing invalid directory paths...")
try:
    # Try to create orchestrator with non-writable directory
    orch = GenericOrchestrator(
        output_dir=Path("/root/cannot_write_here"),
        tokens=["token1"]
    )
    print("✗ Accepted non-writable directory (should fail)")
except Exception as e:
    print(f"✓ Rejected non-writable directory: {type(e).__name__}")

# Test 4: Invalid MCP registry
print("\n4. Testing invalid MCP registry...")
try:
    # Create invalid registry file
    bad_registry_path = test_dir / "bad_registry.json"
    with open(bad_registry_path, 'w') as f:
        f.write("{ invalid json }")
    
    orch = GenericOrchestrator(
        output_dir=test_dir / "bad_mcp",
        tokens=["token1"],
        master_mcp_registry_path=bad_registry_path,
        enable_dynamic_configs=True
    )
    # If it succeeds, check if it handled the error gracefully
    if orch.master_mcp_registry_path == bad_registry_path:
        print("⚠ Accepted invalid registry but may handle gracefully at runtime")
    else:
        print("✓ Invalid registry handled")
except Exception as e:
    print(f"✓ Rejected invalid MCP registry: {type(e).__name__}")

# Test 5: Non-existent MCP registry
print("\n5. Testing non-existent MCP registry...")
try:
    orch = GenericOrchestrator(
        output_dir=test_dir / "no_mcp",
        tokens=["token1"],
        master_mcp_registry_path=Path("/does/not/exist.json"),
        enable_dynamic_configs=True
    )
    # Check if it handles missing file gracefully
    if orch.enable_dynamic_configs:
        print("⚠ Accepted non-existent registry (may fail at runtime)")
    else:
        print("✓ Disabled dynamic configs for missing registry")
except Exception as e:
    print(f"✓ Rejected non-existent registry: {type(e).__name__}")

# Test 6: Invalid execution profile
print("\n6. Testing invalid execution profile...")
try:
    orch = GenericOrchestrator(
        output_dir=test_dir / "bad_profile",
        tokens=["token1"],
        agent_execution_profile="invalid_profile_name"
    )
    # Check if it defaults or accepts
    if orch.agent_execution_profile == "invalid_profile_name":
        print("⚠ Accepted invalid profile (may use as-is)")
    else:
        print(f"✓ Defaulted invalid profile to: {orch.agent_execution_profile}")
except Exception as e:
    print(f"✓ Rejected invalid profile: {e}")

# Test 7: Directory creation failure recovery
print("\n7. Testing directory creation failure...")
try:
    # Try to create a directory with invalid characters (platform dependent)
    invalid_dir = test_dir / "\0invalid"  # Null character
    orch = GenericOrchestrator(
        output_dir=invalid_dir,
        tokens=["token1"]
    )
    print("✗ Created directory with invalid name")
except Exception as e:
    print(f"✓ Failed on invalid directory name: {type(e).__name__}")

# Test 8: Conflicting parameters
print("\n8. Testing conflicting parameters...")
try:
    # Enable log_to_work_dir but no agent_base_work_dir
    orch = GenericOrchestrator(
        output_dir=test_dir / "conflict",
        tokens=["token1"],
        log_to_work_dir=True,
        agent_base_work_dir=None
    )
    # Check if it creates default
    if orch.agent_base_work_dir is not None:
        print(f"✓ Created default agent_base_work_dir: {orch.agent_base_work_dir}")
    else:
        print("✗ log_to_work_dir enabled but no work_dir set")
except Exception as e:
    print(f"✓ Caught conflict: {e}")

# Test 9: Enhanced orchestrator specific errors
print("\n9. Testing EnhancedOrchestrator errors...")
try:
    eo = EnhancedOrchestrator(
        output_dir=test_dir / "enhanced_error",
        tokens=["token1"],
        enable_quality_gates=True,
        quality_gate_config={"invalid": "config"}  # May not be validated
    )
    print("⚠ Accepted potentially invalid quality gate config")
except Exception as e:
    print(f"✓ Rejected invalid config: {e}")

# Test 10: Resource limits
print("\n10. Testing resource limits...")
try:
    # Try extremely high parallel limit
    orch = GenericOrchestrator(
        output_dir=test_dir / "high_parallel",
        tokens=["token1"],
        max_parallel=10000
    )
    if orch.max_parallel == 10000:
        print("⚠ Accepted very high max_parallel (10000)")
    else:
        print(f"✓ Capped max_parallel to: {orch.max_parallel}")
except Exception as e:
    print(f"✓ Rejected extreme max_parallel: {e}")

# Test 11: Token pool edge cases
print("\n11. Testing token pool edge cases...")
try:
    # Single token
    orch = GenericOrchestrator(
        output_dir=test_dir / "single_token",
        tokens=["only-one-token"]
    )
    print("✓ Accepted single token")
    
    # Many tokens
    many_tokens = [f"token-{i}" for i in range(100)]
    orch = GenericOrchestrator(
        output_dir=test_dir / "many_tokens",
        tokens=many_tokens
    )
    print(f"✓ Accepted {len(many_tokens)} tokens")
    
except Exception as e:
    print(f"✗ Token pool edge case failed: {e}")

# Test 12: Special characters in paths
print("\n12. Testing special characters in paths...")
try:
    special_dir = test_dir / "path with spaces" / "and-dashes" / "under_scores"
    orch = GenericOrchestrator(
        output_dir=special_dir,
        tokens=["token1"]
    )
    if special_dir.exists():
        print(f"✓ Created directory with special characters: {special_dir.name}")
    else:
        print("✗ Failed to create directory with special characters")
except Exception as e:
    print(f"✗ Special character test failed: {e}")

print("\n=== ERROR CONDITION TESTING COMPLETE ===")