#!/usr/bin/env python3
"""Test script to verify examples work"""

import sys
import asyncio
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

# Test imports
try:
    from enhanced_swarm_log_tailer import (
        EnhancedSwarmLogTailer,
        LogEntry,
        SwarmPattern,
        SwarmBehavior,
        VisualizationMode
    )
    print("✅ Enhanced log tailer imports successful")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

try:
    from src.generic_orchestrator import AgentOrchestrator
    print("✅ Orchestrator imports successful")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

# Test basic instantiation
async def test_basic():
    try:
        tailer = EnhancedSwarmLogTailer(
            log_files=["test.log"],
            patterns={"ERROR": r"ERROR"},
            enable_swarm_detection=True
        )
        print("✅ Tailer instantiation successful")
        
        orchestrator = AgentOrchestrator()
        print("✅ Orchestrator instantiation successful")
        
        print("\n🎉 All basic tests passed! Examples should work.")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = asyncio.run(test_basic())
    sys.exit(0 if success else 1)