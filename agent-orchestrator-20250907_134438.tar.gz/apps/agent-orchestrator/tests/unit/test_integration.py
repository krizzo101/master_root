#!/usr/bin/env python3
"""Integration tests for orchestrator enhancements"""

import sys
import os
from pathlib import Path
import tempfile
import json
import asyncio

sys.path.insert(0, 'src')

from enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask
from generic_orchestrator import AgentTask

# Provide dummy tokens
dummy_tokens = ["dummy-token-1", "dummy-token-2", "dummy-token-3"]

print("=== INTEGRATION TESTING ===")

# Create temp directory for testing
test_dir = Path(tempfile.mkdtemp(prefix="integration_test_"))
print(f"Test directory: {test_dir}")

async def run_integration_tests():
    """Run async integration tests"""
    
    # Test 1: Create orchestrator with all features enabled
    print("\n1. Testing full-featured orchestrator...")
    try:
        orchestrator = EnhancedOrchestrator(
            output_dir=test_dir / "integration",
            tokens=dummy_tokens,
            max_parallel=5,
            use_optimizations=True,
            # Enhanced features
            enable_quality_gates=True,
            enable_monitoring=True,
            # Dynamic architecture
            master_mcp_registry_path=Path("master_mcp_registry.json"),
            agent_execution_profile="research",
            agent_debug_mode=True,
            agent_base_work_dir=test_dir / "agent_workspaces",
            enable_dynamic_configs=True,
            log_to_work_dir=True
        )
        
        print("✓ Full-featured orchestrator created")
        print(f"  - Quality gates: {orchestrator.enable_quality_gates}")
        print(f"  - Monitoring: {orchestrator.enable_monitoring}")
        print(f"  - Profile: {orchestrator.agent_execution_profile}")
        print(f"  - Debug: {orchestrator.agent_debug_mode}")
        print(f"  - Dynamic configs: {orchestrator.enable_dynamic_configs}")
        
    except Exception as e:
        print(f"✗ Orchestrator creation failed: {e}")
        return
    
    # Test 2: Create and validate tasks
    print("\n2. Testing task creation...")
    try:
        tasks = []
        
        # Create standard task
        task1 = AgentTask(
            task_id="task-1",
            task_type="standard",
            prompt="Perform standard operation",
            dependencies=[]
        )
        tasks.append(task1)
        print(f"✓ Standard task created: {task1.task_id}")
        
        # Create enhanced task with new features
        task2 = EnhancedAgentTask(
            task_id="task-2",
            task_type="enhanced",
            prompt="Perform enhanced operation",
            dependencies=["task-1"],
            quality_gates=["validation"],
            validation_required=True,
            mcp_needs=["firecrawl", "web_search"],
            work_dir_name="enhanced_workspace",
            debug_mode=True
        )
        tasks.append(task2)
        print(f"✓ Enhanced task created: {task2.task_id}")
        print(f"  - Dependencies: {task2.dependencies}")
        print(f"  - Quality gates: {task2.quality_gates}")
        print(f"  - MCP needs: {task2.mcp_needs}")
        print(f"  - Work dir: {task2.work_dir_name}")
        
    except Exception as e:
        print(f"✗ Task creation failed: {e}")
        return
    
    # Test 3: Test dependency management
    print("\n3. Testing dependency management...")
    try:
        # Add tasks to orchestrator's dependency manager
        for task in tasks:
            orchestrator.dependency_manager.add_task(task.task_id, task.dependencies)
        
        # Check dependency resolution
        ready_tasks = orchestrator.dependency_manager.get_ready_tasks()
        print(f"✓ Ready tasks: {ready_tasks}")
        
        # Complete first task
        orchestrator.dependency_manager.complete_task("task-1")
        ready_tasks = orchestrator.dependency_manager.get_ready_tasks()
        print(f"✓ After completing task-1, ready tasks: {ready_tasks}")
        
    except Exception as e:
        print(f"✗ Dependency management failed: {e}")
    
    # Test 4: Test quality gates (if available)
    print("\n4. Testing quality gates...")
    try:
        if orchestrator.enable_quality_gates and orchestrator.quality_gate_manager:
            # Register a simple gate
            orchestrator.quality_gate_manager.register_gate(
                "validation",
                lambda r: {"status": "passed", "score": 0.9}
            )
            
            # Validate a mock result
            result = {"output": "test output", "success": True}
            validation = await orchestrator.quality_gate_manager.validate_result(
                "validation", result
            )
            
            if validation:
                print(f"✓ Quality gate validation: {validation.get('status')}")
            else:
                print("✓ Quality gate registered (validation skipped)")
        else:
            print("  Quality gates not fully configured")
            
    except Exception as e:
        print(f"  Quality gate test skipped: {e}")
    
    # Test 5: Test message bus
    print("\n5. Testing message bus...")
    try:
        # Send a test message
        test_message = {
            "type": "test",
            "content": "Integration test message",
            "timestamp": "2025-09-07T04:00:00"
        }
        
        orchestrator.message_bus.publish("test-channel", test_message)
        print("✓ Message published to bus")
        
        # Check if message directory exists
        message_dir = orchestrator.output_dir / "messages"
        if message_dir.exists():
            print(f"✓ Message directory exists: {message_dir}")
        
    except Exception as e:
        print(f"✗ Message bus test failed: {e}")
    
    # Test 6: Test metrics collection
    print("\n6. Testing metrics collection...")
    try:
        # Update metrics
        orchestrator.metrics["tasks_completed"] = 1
        orchestrator.metrics["total_duration"] = 100.5
        orchestrator.metrics["tasks_failed"] = 0
        
        print("✓ Metrics updated:")
        print(f"  - Tasks completed: {orchestrator.metrics['tasks_completed']}")
        print(f"  - Total duration: {orchestrator.metrics['total_duration']}s")
        print(f"  - Tasks failed: {orchestrator.metrics['tasks_failed']}")
        
    except Exception as e:
        print(f"✗ Metrics test failed: {e}")
    
    # Test 7: Test directory structure
    print("\n7. Testing directory structure...")
    try:
        expected_dirs = [
            orchestrator.output_dir,
            orchestrator.output_dir / "logs",
            orchestrator.agent_base_work_dir,
        ]
        
        for dir_path in expected_dirs:
            if dir_path.exists():
                print(f"✓ Directory exists: {dir_path}")
            else:
                print(f"✗ Directory missing: {dir_path}")
                
    except Exception as e:
        print(f"✗ Directory structure test failed: {e}")
    
    # Test 8: Test orchestrator state after modifications
    print("\n8. Testing self-modification safety...")
    try:
        # Modify orchestrator parameters
        original_profile = orchestrator.agent_execution_profile
        orchestrator.agent_execution_profile = "minimal"
        
        # Verify modification
        if orchestrator.agent_execution_profile == "minimal":
            print("✓ Orchestrator parameters can be modified")
            
        # Restore and verify
        orchestrator.agent_execution_profile = original_profile
        if orchestrator.agent_execution_profile == original_profile:
            print("✓ Orchestrator parameters can be restored")
            
        # Verify core functionality still works
        orchestrator.message_bus.publish("test-channel-2", {"test": "post-modification"})
        print("✓ Core functionality works after modification")
        
    except Exception as e:
        print(f"✗ Self-modification test failed: {e}")
    
    print("\n=== INTEGRATION TESTING COMPLETE ===")

# Run the async tests
if __name__ == "__main__":
    asyncio.run(run_integration_tests())