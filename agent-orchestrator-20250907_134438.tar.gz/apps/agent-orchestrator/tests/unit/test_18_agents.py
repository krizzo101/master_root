#!/usr/bin/env python3
"""
Test 18 Agent Execution - Verify Token Pool Fix
Simple test to confirm all 18 tokens work and agents execute in parallel
"""

import asyncio
import sys
from pathlib import Path
import time

# Add src to path
sys.path.append("src")

from token_loader import load_tokens_from_secrets
from src.enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask


def create_simple_test_tasks(count: int = 18):
    """Create simple independent tasks for testing"""
    tasks = []
    
    for i in range(1, count + 1):
        task = EnhancedAgentTask(
            task_id=f"test_agent_{i:02d}",
            task_type="technical_writer",
            prompt=f"Write a brief paragraph explaining the number {i} and its mathematical properties.",
            team_id=f"test-team-{(i-1)//6 + 1}"  # 3 teams of 6
        )
        tasks.append(task)
    
    return tasks


async def main():
    print("🧪 TESTING 18-AGENT PARALLEL EXECUTION")
    print("Verifying token pool and parallel coordination...")
    
    # Load tokens directly 
    print("\n🔧 Loading tokens...")
    tokens = load_tokens_from_secrets()
    print(f"✅ Loaded {len(tokens)} tokens")
    
    # Create orchestrator with explicit token passing
    output_dir = Path("/tmp/test_18_agents")
    orchestrator = EnhancedOrchestrator(
        output_dir=output_dir,
        max_parallel=18,  # All agents at once
        tokens=tokens,    # Explicit token list
        enable_quality_gates=False,  # Fast execution
        enable_monitoring=True,
        use_optimizations=True
    )
    
    print(f"\n🎯 Orchestrator Status:")
    print(f"  • Token Pool Size: {orchestrator.token_pool.size()}")
    print(f"  • Max Parallel: {orchestrator.max_parallel}")
    
    # Create simple test tasks
    tasks = create_simple_test_tasks(18)
    print(f"\n📋 Created {len(tasks)} test tasks")
    
    # Execute with timing
    print(f"\n⚡ LAUNCHING {len(tasks)} AGENTS SIMULTANEOUSLY...")
    start_time = time.time()
    
    results = await orchestrator.execute_batch(tasks)
    
    end_time = time.time()
    wall_time = end_time - start_time
    
    # Analyze results
    completed = sum(1 for r in results if r["status"] == "completed")
    failed = len(results) - completed
    
    print(f"\n📊 EXECUTION RESULTS:")
    print(f"  • Wall Clock Time: {wall_time:.1f} seconds")
    print(f"  • Tasks Completed: {completed}/{len(results)}")
    print(f"  • Tasks Failed: {failed}")
    print(f"  • Success Rate: {completed/len(results)*100:.1f}%")
    
    if completed > 0:
        # Calculate actual parallelization
        durations = [r["end_time"] - r["start_time"] for r in results if r.get("start_time") and r.get("end_time")]
        if durations:
            total_sequential_time = sum(durations)
            speedup = total_sequential_time / wall_time if wall_time > 0 else 0
            
            print(f"\n⚡ PARALLEL PERFORMANCE:")
            print(f"  • Total Sequential Time: {total_sequential_time:.1f}s")
            print(f"  • Actual Parallel Time: {wall_time:.1f}s")
            print(f"  • Speedup Achieved: {speedup:.1f}x")
            print(f"  • Parallel Efficiency: {speedup/len(results)*100:.1f}%")
    
    # Validate true parallelization
    if completed >= 16:  # Allow for 2 failures
        print(f"\n🎉 SUCCESS: 18-Agent parallel execution verified!")
        print(f"✅ Token pool working correctly with {orchestrator.token_pool.size()} tokens")
        print(f"✅ Parallel coordination achieving ~{speedup:.0f}x speedup")
    else:
        print(f"\n⚠️ PARTIAL SUCCESS: Only {completed}/18 agents completed")
        print(f"Need to investigate remaining issues")
    
    return results


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()