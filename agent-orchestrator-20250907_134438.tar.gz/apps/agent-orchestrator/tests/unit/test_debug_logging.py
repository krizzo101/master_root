#!/usr/bin/env python3
"""Test debug logging functionality"""

import sys
import os
from pathlib import Path
import tempfile
import time

sys.path.insert(0, 'src')

from enhanced_orchestrator import EnhancedOrchestrator
from generic_orchestrator import GenericOrchestrator

# Provide dummy tokens
dummy_tokens = ["dummy-token-1", "dummy-token-2", "dummy-token-3"]

print("=== TESTING DEBUG LOGGING FUNCTIONALITY ===")

# Create temp directory for testing
test_dir = Path(tempfile.mkdtemp(prefix="debug_test_"))
print(f"Test directory: {test_dir}")

# Test 1: Debug logging initialization
print("\n1. Testing debug logging initialization...")
try:
    # Create orchestrator without debug
    orch_no_debug = GenericOrchestrator(
        output_dir=test_dir / "no_debug",
        tokens=dummy_tokens,
        agent_debug_mode=False
    )
    
    # Create orchestrator with debug
    orch_with_debug = GenericOrchestrator(
        output_dir=test_dir / "with_debug",
        tokens=dummy_tokens,
        agent_debug_mode=True
    )
    
    print(f"✓ Non-debug orchestrator: agent_debug_mode={orch_no_debug.agent_debug_mode}")
    print(f"✓ Debug orchestrator: agent_debug_mode={orch_with_debug.agent_debug_mode}")
    
    # Check if log directories were created
    log_dir_no_debug = test_dir / "no_debug" / "logs"
    log_dir_with_debug = test_dir / "with_debug" / "logs"
    
    if log_dir_no_debug.exists():
        print(f"✓ Log directory created (no debug): {log_dir_no_debug}")
    if log_dir_with_debug.exists():
        print(f"✓ Log directory created (with debug): {log_dir_with_debug}")
        
except Exception as e:
    print(f"✗ Debug logging initialization failed: {e}")

# Test 2: Check log file creation
print("\n2. Testing log file creation...")
try:
    # List log files
    if log_dir_with_debug.exists():
        log_files = list(log_dir_with_debug.glob("orchestrator_*.log"))
        if log_files:
            print(f"✓ Log file created: {log_files[0].name}")
            
            # Check file size to see if content was written
            log_size = log_files[0].stat().st_size
            if log_size > 0:
                print(f"✓ Log file has content: {log_size} bytes")
                
                # Read first few lines
                with open(log_files[0]) as f:
                    lines = f.readlines()[:5]
                print(f"✓ Sample log entries: {len(lines)} lines")
                for line in lines[:2]:
                    print(f"  {line.strip()[:100]}...")
            else:
                print("✗ Log file is empty")
        else:
            print("✗ No log files created")
    else:
        print("✗ Log directory doesn't exist")
        
except Exception as e:
    print(f"✗ Log file check failed: {e}")

# Test 3: Enhanced orchestrator debug logging
print("\n3. Testing EnhancedOrchestrator debug logging...")
try:
    eo_debug = EnhancedOrchestrator(
        output_dir=test_dir / "enhanced_debug",
        tokens=dummy_tokens,
        agent_debug_mode=True,
        enable_quality_gates=True,
        enable_monitoring=True
    )
    
    print(f"✓ EnhancedOrchestrator with debug: agent_debug_mode={eo_debug.agent_debug_mode}")
    
    # Check enhanced log directory
    enhanced_log_dir = test_dir / "enhanced_debug" / "logs"
    if enhanced_log_dir.exists():
        enhanced_logs = list(enhanced_log_dir.glob("*.log"))
        print(f"✓ Enhanced log directory has {len(enhanced_logs)} log file(s)")
        
except Exception as e:
    print(f"✗ Enhanced debug logging failed: {e}")

# Test 4: Log to work directory feature
print("\n4. Testing log_to_work_dir feature...")
try:
    orch_log_work = GenericOrchestrator(
        output_dir=test_dir / "log_work",
        tokens=dummy_tokens,
        agent_debug_mode=True,
        log_to_work_dir=True,
        agent_base_work_dir=test_dir / "agent_workspaces"
    )
    
    if orch_log_work.log_to_work_dir:
        print("✓ log_to_work_dir enabled")
        print(f"  Agent logs would be written to: {orch_log_work.agent_base_work_dir}/[agent_id]/logs/")
    else:
        print("✗ log_to_work_dir not enabled")
        
except Exception as e:
    print(f"✗ Log to work dir test failed: {e}")

# Test 5: Debug flag propagation
print("\n5. Testing debug flag propagation...")
try:
    # Test that debug flag would be passed to agents
    test_cases = [
        ("Debug disabled", False, "standard"),
        ("Debug enabled", True, "research"),
        ("Full profile", True, "full"),
    ]
    
    for desc, debug_mode, profile in test_cases:
        orch = GenericOrchestrator(
            output_dir=test_dir / f"propagation_{profile}",
            tokens=dummy_tokens,
            agent_debug_mode=debug_mode,
            agent_execution_profile=profile
        )
        
        print(f"✓ {desc}: debug={orch.agent_debug_mode}, profile={orch.agent_execution_profile}")
        
        # These would be passed to agents at runtime
        expected_flags = []
        if orch.agent_debug_mode:
            expected_flags.append("--debug")
        if orch.agent_execution_profile != "standard":
            expected_flags.append(f"--profile={orch.agent_execution_profile}")
            
        if expected_flags:
            print(f"  Would pass flags to agent: {' '.join(expected_flags)}")
            
except Exception as e:
    print(f"✗ Debug propagation test failed: {e}")

# Test 6: Performance impact check
print("\n6. Testing performance impact...")
try:
    import time
    
    # Time orchestrator creation without debug
    start = time.time()
    for _ in range(5):
        GenericOrchestrator(
            output_dir=test_dir / "perf_no_debug",
            tokens=dummy_tokens,
            agent_debug_mode=False
        )
    no_debug_time = time.time() - start
    
    # Time orchestrator creation with debug
    start = time.time()
    for _ in range(5):
        GenericOrchestrator(
            output_dir=test_dir / "perf_with_debug",
            tokens=dummy_tokens,
            agent_debug_mode=True
        )
    with_debug_time = time.time() - start
    
    overhead = ((with_debug_time - no_debug_time) / no_debug_time) * 100 if no_debug_time > 0 else 0
    
    print(f"✓ No debug: {no_debug_time:.3f}s for 5 iterations")
    print(f"✓ With debug: {with_debug_time:.3f}s for 5 iterations")
    print(f"✓ Debug overhead: {overhead:.1f}%")
    
    if overhead < 50:
        print("✓ Debug overhead is acceptable (<50%)")
    else:
        print(f"⚠ Debug overhead is high: {overhead:.1f}%")
        
except Exception as e:
    print(f"✗ Performance test failed: {e}")

print("\n=== DEBUG LOGGING TESTING COMPLETE ===")