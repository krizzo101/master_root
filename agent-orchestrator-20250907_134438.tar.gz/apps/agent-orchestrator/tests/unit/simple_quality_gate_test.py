#!/usr/bin/env python3
"""
Simple Quality Gate Test

Tests the quality gate system using only file and command validators
to avoid dependency issues.
"""

import asyncio
import tempfile
from pathlib import Path
import sys
import os

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from quality_gates import QualityGateManager, GateStatus
from enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask


async def test_file_based_quality_gates():
    """Test file-based quality gates"""
    print("=== Testing File-Based Quality Gates ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Initialize quality gate manager
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Test file that doesn't exist initially
        test_file = temp_path / "test_file.txt"
        
        # Define a file existence gate
        gate = await qg_manager.define_gate(
            gate_id="file_ready",
            name="File Ready",
            description="Test file must exist",
            validator_type="file",
            config={
                "path": str(test_file),
                "exists": True
            }
        )
        
        print(f"✓ Defined gate: {gate.name}")
        
        # Gate should fail initially
        result = await qg_manager.validate_gate("file_ready")
        if not result.success:
            print("✓ Gate correctly failed when file missing")
        else:
            print("❌ Gate should have failed when file missing")
            return False
        
        # Create the file
        test_file.write_text("Hello, Quality Gates!")
        
        # Gate should pass now
        result = await qg_manager.validate_gate("file_ready")
        if result.success:
            print("✓ Gate correctly passed when file exists")
        else:
            print(f"❌ Gate should have passed when file exists: {result.message}")
            return False
        
        # Test content validation
        await qg_manager.define_gate(
            gate_id="content_check",
            name="Content Check",
            description="File must contain specific text",
            validator_type="file",
            config={
                "path": str(test_file),
                "exists": True,
                "contains": "Quality Gates"
            }
        )
        
        result = await qg_manager.validate_gate("content_check")
        if result.success:
            print("✓ Content validation passed")
        else:
            print(f"❌ Content validation failed: {result.message}")
            return False
        
        print("File-based quality gate tests passed!\n")
        return True


async def test_command_based_quality_gates():
    """Test command-based quality gates"""
    print("=== Testing Command-Based Quality Gates ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Test successful command
        await qg_manager.define_gate(
            gate_id="echo_test",
            name="Echo Test",
            description="Echo command should succeed",
            validator_type="command",
            config={
                "command": ["echo", "success"],
                "expected_return_code": 0
            }
        )
        
        result = await qg_manager.validate_gate("echo_test")
        if result.success:
            print("✓ Echo command gate passed")
        else:
            print(f"❌ Echo command gate failed: {result.message}")
            return False
        
        # Test failing command
        await qg_manager.define_gate(
            gate_id="false_test",
            name="False Test", 
            description="False command should fail",
            validator_type="command",
            config={
                "command": ["false"],
                "expected_return_code": 0
            }
        )
        
        result = await qg_manager.validate_gate("false_test")
        if not result.success:
            print("✓ False command gate correctly failed")
        else:
            print("❌ False command gate should have failed")
            return False
        
        print("Command-based quality gate tests passed!\n")
        return True


async def test_dependency_chain():
    """Test quality gates with dependencies"""
    print("=== Testing Dependency Chain ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Create test files
        file1 = temp_path / "stage1.txt"
        file2 = temp_path / "stage2.txt"
        
        # Define first gate
        await qg_manager.define_gate(
            gate_id="stage1",
            name="Stage 1 Complete",
            description="Stage 1 marker file exists",
            validator_type="file",
            config={
                "path": str(file1),
                "exists": True
            }
        )
        
        # Define second gate that depends on first
        await qg_manager.define_gate(
            gate_id="stage2",
            name="Stage 2 Complete", 
            description="Stage 2 marker file exists",
            validator_type="file",
            config={
                "path": str(file2),
                "exists": True
            },
            dependencies=["stage1"]
        )
        
        # Stage2 should fail because stage1 hasn't passed
        result = await qg_manager.validate_gate("stage2")
        if not result.success:
            print("✓ Stage 2 correctly failed when dependency not met")
        else:
            print("❌ Stage 2 should have failed when dependency not met")
            return False
        
        # Create stage1 file and validate stage1
        file1.write_text("Stage 1 complete")
        result = await qg_manager.validate_gate("stage1")
        if not result.success:
            print(f"❌ Stage 1 validation failed: {result.message}")
            return False
        
        # Stage2 should still fail (file2 doesn't exist)
        result = await qg_manager.validate_gate("stage2")
        if not result.success:
            print("✓ Stage 2 correctly failed when its own conditions not met")
        else:
            print("❌ Stage 2 should have failed when file doesn't exist")
            return False
        
        # Create stage2 file
        file2.write_text("Stage 2 complete")
        
        # Now stage2 should pass
        result = await qg_manager.validate_gate("stage2")
        if result.success:
            print("✓ Stage 2 passed when all dependencies and conditions met")
        else:
            print(f"❌ Stage 2 should have passed: {result.message}")
            return False
        
        print("Dependency chain tests passed!\n")
        return True


async def test_orchestrator_integration():
    """Test integration with enhanced orchestrator"""
    print("=== Testing Orchestrator Integration ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create orchestrator
        orchestrator = EnhancedOrchestrator(
            output_dir=temp_path / "orchestrator",
            max_parallel=2,
            enable_quality_gates=True
        )
        
        # Define a quality gate
        ready_marker = temp_path / "system_ready.txt"
        
        await orchestrator.define_quality_gate(
            gate_id="system_ready",
            name="System Ready",
            description="System ready marker exists",
            validator_type="file",
            config={
                "path": str(ready_marker),
                "exists": True
            }
        )
        
        # Mock task execution
        class TestOrchestrator(EnhancedOrchestrator):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.executed_tasks = []
            
            async def execute_agent(self, task: EnhancedAgentTask) -> dict:
                """Mock execution"""
                self.executed_tasks.append(task.task_id)
                
                if task.task_id == "setup":
                    # Create the ready marker
                    ready_marker.write_text("System is ready")
                    task.status = "completed"
                    task.result = {"setup": "complete"}
                elif task.task_id == "process":
                    # This should only run after quality gate passes
                    task.status = "completed" 
                    task.result = {"processed": True}
                
                await self.dep_manager.mark_completed(task.task_id)
                return task.to_dict()
        
        test_orchestrator = TestOrchestrator(
            output_dir=temp_path / "test_orchestrator",
            max_parallel=2,
            enable_quality_gates=True
        )
        
        # Copy quality gate manager
        test_orchestrator.quality_gate_manager = orchestrator.quality_gate_manager
        
        def generate_test_tasks():
            return [
                test_orchestrator.create_enhanced_task(
                    task_id="setup",
                    task_type="setup",
                    prompt="Set up system",
                    quality_gates=[]
                ),
                test_orchestrator.create_enhanced_task(
                    task_id="process",
                    task_type="process", 
                    prompt="Process data",
                    dependencies=["setup"],
                    quality_gates=["system_ready"]
                )
            ]
        
        # Run the orchestration
        try:
            results = await test_orchestrator.run(generate_test_tasks)
            
            if results['metrics']['completed'] == 2:
                print("✓ Both tasks completed successfully")
            else:
                print(f"❌ Expected 2 completed tasks, got {results['metrics']['completed']}")
                return False
            
            if results['metrics']['failed'] == 0:
                print("✓ No tasks failed")
            else:
                print(f"❌ {results['metrics']['failed']} tasks failed")
                return False
            
            # Check execution order
            if test_orchestrator.executed_tasks == ["setup", "process"]:
                print("✓ Tasks executed in correct order")
            else:
                print(f"❌ Tasks executed in wrong order: {test_orchestrator.executed_tasks}")
                return False
            
            print("Orchestrator integration tests passed!\n")
            return True
            
        finally:
            if test_orchestrator.quality_gate_manager:
                await test_orchestrator.quality_gate_manager.stop_validation_loop()


async def test_status_reporting():
    """Test status reporting functionality"""
    print("=== Testing Status Reporting ===")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        qg_manager = QualityGateManager(temp_path / "gates")
        
        # Define some gates
        await qg_manager.define_gate(
            gate_id="gate1",
            name="Gate 1",
            description="First test gate",
            validator_type="command",
            config={
                "command": ["echo", "gate1"],
                "expected_return_code": 0
            }
        )
        
        await qg_manager.define_gate(
            gate_id="gate2",
            name="Gate 2",
            description="Second test gate", 
            validator_type="command",
            config={
                "command": ["false"],  # This will fail
                "expected_return_code": 0
            }
        )
        
        # Validate gates
        await qg_manager.validate_gate("gate1")  # Should pass
        await qg_manager.validate_gate("gate2")  # Should fail
        
        # Get status report
        status = await qg_manager.get_status_report()
        
        if "gates" in status:
            print("✓ Status report contains gates")
        else:
            print("❌ Status report missing gates section")
            return False
        
        if status["gates"]["gate1"]["status"] == "passed":
            print("✓ Gate1 status correctly reported as passed")
        else:
            print(f"❌ Gate1 status incorrect: {status['gates']['gate1']['status']}")
            return False
        
        if status["gates"]["gate2"]["status"] == "failed":
            print("✓ Gate2 status correctly reported as failed")
        else:
            print(f"❌ Gate2 status incorrect: {status['gates']['gate2']['status']}")
            return False
        
        print("Status reporting tests passed!\n")
        return True


async def run_all_simple_tests():
    """Run all simple tests that don't require external dependencies"""
    
    print("Simple Quality Gate System Test Suite")
    print("=" * 50)
    
    tests = [
        test_file_based_quality_gates,
        test_command_based_quality_gates,
        test_dependency_chain,
        test_orchestrator_integration,
        test_status_reporting
    ]
    
    results = []
    for test in tests:
        try:
            result = await test()
            results.append((test.__name__, "PASSED" if result else "FAILED"))
        except Exception as e:
            print(f"❌ {test.__name__} FAILED: {e}")
            import traceback
            traceback.print_exc()
            results.append((test.__name__, "FAILED"))
        
        print()  # Blank line between tests
    
    # Summary
    print("=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status_icon = "✅" if result == "PASSED" else "❌"
        print(f"{status_icon} {test_name}: {result}")
        if result == "PASSED":
            passed += 1
    
    print(f"\nPassed: {passed}/{len(results)} tests")
    
    if passed == len(results):
        print("🎉 All simple tests passed! Core quality gate system is working.")
        return True
    else:
        print("❌ Some tests failed. Please review the issues above.")
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_simple_tests())
    if success:
        print("\n✅ Quality Gate System implementation is ready for production!")
    else:
        print("\n❌ Quality Gate System needs fixes before production use.")