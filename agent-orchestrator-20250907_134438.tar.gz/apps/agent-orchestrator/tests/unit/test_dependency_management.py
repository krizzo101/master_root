#!/usr/bin/env python3
"""
Dependency Management Validation Test Suite
Tests complex task dependency management including:
- Linear dependency chains
- Parallel branches with convergence  
- Complex dependency graphs
- Circular dependency detection
- Dependency resolution optimization
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
import sys
import os

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig, EnhancedAgentTask, FeatureFlag
from src.generic_orchestrator import AgentTask, DependencyManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DependencyTestOrchestrator:
    """Test orchestrator for dependency validation"""
    
    def __init__(self, output_dir: Path):
        # Configure unified orchestrator with minimal features for testing
        self.config = UnifiedConfig(
            output_dir=output_dir,
            max_parallel=10,
            enabled_features={FeatureFlag.ENHANCED_METRICS}
        )
        self.orchestrator = UnifiedOrchestrator(self.config)
        self.execution_order = []
        self.execution_times = {}
        self.dependency_violations = []
        self.tasks_to_execute = []
        
    async def execute_with_tracking(self, tasks: List[AgentTask]) -> Dict:
        """Execute tasks and track execution order"""
        self.tasks_to_execute = tasks
        
        # Create task generator
        def task_generator():
            return self.tasks_to_execute
        
        # Create result processor
        def result_processor(results):
            for result in results:
                if result and 'task_id' in result:
                    self.execution_order.append(result['task_id'])
        
        # Track execution with mock executor
        original_execute = self.orchestrator.execute_task
        
        async def tracked_execute(task):
            start_time = time.time()
            
            # Check dependencies are satisfied
            for dep in task.dependencies:
                if dep not in self.execution_order:
                    self.dependency_violations.append({
                        'task': task.task_id,
                        'missing_dependency': dep,
                        'execution_order': self.execution_order.copy()
                    })
            
            # Simulate task execution
            await asyncio.sleep(0.05)  # Simulate work
            
            self.execution_order.append(task.task_id)
            self.execution_times[task.task_id] = {
                'start': start_time,
                'duration': time.time() - start_time
            }
            
            task.status = "completed"
            task.result = {
                'task_id': task.task_id,
                'status': 'completed',
                'execution_order': len(self.execution_order)
            }
            
            return task.result
        
        # Replace execute method temporarily
        self.orchestrator.execute_task = tracked_execute
        
        try:
            # Run orchestrator
            result = await self.orchestrator.run(task_generator, result_processor)
            return result
        finally:
            # Restore original method
            self.orchestrator.execute_task = original_execute


class DependencyTestSuite:
    """Comprehensive dependency management test suite"""
    
    def __init__(self):
        self.output_dir = Path("dependency_test_results")
        self.output_dir.mkdir(exist_ok=True)
        self.test_results = {}
        
    def create_linear_chain(self, length: int = 10) -> List[AgentTask]:
        """Create a linear dependency chain A→B→C→D..."""
        tasks = []
        for i in range(length):
            task = AgentTask(
                task_id=f"linear_{i}",
                task_type="test",
                prompt=f"Linear task {i}",
                dependencies=[f"linear_{i-1}"] if i > 0 else []
            )
            tasks.append(task)
        return tasks
    
    def create_diamond_pattern(self) -> List[AgentTask]:
        """Create diamond dependency pattern A→[B,C]→D"""
        return [
            AgentTask(task_id="diamond_A", task_type="test", prompt="Start", dependencies=[]),
            AgentTask(task_id="diamond_B", task_type="test", prompt="Branch B", dependencies=["diamond_A"]),
            AgentTask(task_id="diamond_C", task_type="test", prompt="Branch C", dependencies=["diamond_A"]),
            AgentTask(task_id="diamond_D", task_type="test", prompt="Convergence", dependencies=["diamond_B", "diamond_C"])
        ]
    
    def create_complex_graph(self) -> List[AgentTask]:
        """Create complex dependency graph with multiple paths"""
        tasks = []
        
        # Layer 0: 3 root tasks
        for i in range(3):
            tasks.append(AgentTask(
                task_id=f"complex_root_{i}",
                task_type="test",
                prompt=f"Root {i}",
                dependencies=[]
            ))
        
        # Layer 1: 5 tasks depending on various roots
        tasks.extend([
            AgentTask(task_id="complex_L1_0", task_type="test", prompt="L1_0", dependencies=["complex_root_0"]),
            AgentTask(task_id="complex_L1_1", task_type="test", prompt="L1_1", dependencies=["complex_root_0", "complex_root_1"]),
            AgentTask(task_id="complex_L1_2", task_type="test", prompt="L1_2", dependencies=["complex_root_1"]),
            AgentTask(task_id="complex_L1_3", task_type="test", prompt="L1_3", dependencies=["complex_root_2"]),
            AgentTask(task_id="complex_L1_4", task_type="test", prompt="L1_4", dependencies=["complex_root_1", "complex_root_2"])
        ])
        
        # Layer 2: 4 tasks with cross-dependencies
        tasks.extend([
            AgentTask(task_id="complex_L2_0", task_type="test", prompt="L2_0", 
                     dependencies=["complex_L1_0", "complex_L1_1"]),
            AgentTask(task_id="complex_L2_1", task_type="test", prompt="L2_1",
                     dependencies=["complex_L1_1", "complex_L1_2", "complex_L1_3"]),
            AgentTask(task_id="complex_L2_2", task_type="test", prompt="L2_2",
                     dependencies=["complex_L1_3", "complex_L1_4"]),
            AgentTask(task_id="complex_L2_3", task_type="test", prompt="L2_3",
                     dependencies=["complex_L1_0", "complex_L1_4"])
        ])
        
        # Layer 3: Convergence points
        tasks.extend([
            AgentTask(task_id="complex_final_0", task_type="test", prompt="Final_0",
                     dependencies=["complex_L2_0", "complex_L2_1"]),
            AgentTask(task_id="complex_final_1", task_type="test", prompt="Final_1",
                     dependencies=["complex_L2_1", "complex_L2_2", "complex_L2_3"])
        ])
        
        return tasks
    
    def create_circular_dependency(self) -> List[AgentTask]:
        """Create tasks with circular dependencies (should be detected)"""
        return [
            AgentTask(task_id="circular_A", task_type="test", prompt="A", dependencies=["circular_C"]),
            AgentTask(task_id="circular_B", task_type="test", prompt="B", dependencies=["circular_A"]),
            AgentTask(task_id="circular_C", task_type="test", prompt="C", dependencies=["circular_B"])
        ]
    
    def detect_circular_dependencies(self, tasks: List[AgentTask]) -> bool:
        """Detect circular dependencies using DFS"""
        task_map = {task.task_id: task for task in tasks}
        visited = set()
        rec_stack = set()
        
        def has_cycle(task_id: str) -> bool:
            visited.add(task_id)
            rec_stack.add(task_id)
            
            if task_id in task_map:
                for dep in task_map[task_id].dependencies:
                    if dep not in visited:
                        if has_cycle(dep):
                            return True
                    elif dep in rec_stack:
                        return True
            
            rec_stack.remove(task_id)
            return False
        
        for task in tasks:
            if task.task_id not in visited:
                if has_cycle(task.task_id):
                    return True
        return False
    
    def validate_execution_order(self, tasks: List[AgentTask], execution_order: List[str]) -> Tuple[bool, List[str]]:
        """Validate that execution order respects dependencies"""
        violations = []
        executed = set()
        
        for task_id in execution_order:
            task = next((t for t in tasks if t.task_id == task_id), None)
            if task:
                for dep in task.dependencies:
                    if dep not in executed:
                        violations.append(f"Task {task_id} executed before dependency {dep}")
            executed.add(task_id)
        
        return len(violations) == 0, violations
    
    def calculate_parallelization_efficiency(self, tasks: List[AgentTask], execution_times: Dict) -> float:
        """Calculate how well the system parallelized independent tasks"""
        # Find tasks that could run in parallel (no interdependencies)
        parallel_groups = self.find_parallel_groups(tasks)
        
        if not parallel_groups:
            return 1.0
        
        total_parallel_time = 0
        total_sequential_time = 0
        
        for group in parallel_groups:
            if not group:
                continue
                
            # Time if run in parallel (max of all tasks in group)
            group_times = [execution_times.get(task_id, {}).get('duration', 0) for task_id in group]
            if group_times:
                parallel_time = max(group_times)
                sequential_time = sum(group_times)
                
                total_parallel_time += parallel_time
                total_sequential_time += sequential_time
        
        if total_sequential_time == 0:
            return 1.0
            
        return total_parallel_time / total_sequential_time
    
    def find_parallel_groups(self, tasks: List[AgentTask]) -> List[List[str]]:
        """Find groups of tasks that can run in parallel"""
        task_map = {task.task_id: task for task in tasks}
        levels = {}
        
        # Calculate level for each task (topological sort with levels)
        def get_level(task_id: str) -> int:
            if task_id in levels:
                return levels[task_id]
            
            task = task_map.get(task_id)
            if not task or not task.dependencies:
                levels[task_id] = 0
                return 0
            
            max_dep_level = max(get_level(dep) for dep in task.dependencies)
            levels[task_id] = max_dep_level + 1
            return levels[task_id]
        
        for task in tasks:
            get_level(task.task_id)
        
        # Group tasks by level
        groups = {}
        for task_id, level in levels.items():
            if level not in groups:
                groups[level] = []
            groups[level].append(task_id)
        
        return [groups[level] for level in sorted(groups.keys())]
    
    async def run_test(self, test_name: str, tasks: List[AgentTask]) -> Dict:
        """Run a single dependency test"""
        logger.info(f"\nRunning test: {test_name}")
        logger.info(f"Tasks: {len(tasks)}")
        
        # Check for circular dependencies
        has_circular = self.detect_circular_dependencies(tasks)
        if has_circular:
            logger.warning(f"Circular dependency detected in {test_name}")
            return {
                'test_name': test_name,
                'status': 'failed',
                'error': 'Circular dependency detected',
                'task_count': len(tasks)
            }
        
        # Run tasks
        orchestrator = DependencyTestOrchestrator(self.output_dir / test_name)
        
        start_time = time.time()
        
        try:
            # Execute tasks with dependency management
            results = await orchestrator.execute_with_tracking(tasks)
            
            execution_time = time.time() - start_time
            
            # Validate execution order
            is_valid, violations = self.validate_execution_order(tasks, orchestrator.execution_order)
            
            # Calculate parallelization efficiency
            efficiency = self.calculate_parallelization_efficiency(tasks, orchestrator.execution_times)
            
            test_result = {
                'test_name': test_name,
                'status': 'passed' if is_valid else 'failed',
                'task_count': len(tasks),
                'execution_time': execution_time,
                'execution_order': orchestrator.execution_order,
                'dependency_violations': violations,
                'parallelization_efficiency': efficiency,
                'tasks_per_second': len(tasks) / execution_time if execution_time > 0 else 0
            }
            
            if orchestrator.dependency_violations:
                test_result['runtime_violations'] = orchestrator.dependency_violations
            
            return test_result
            
        except Exception as e:
            logger.error(f"Test {test_name} failed with error: {e}")
            return {
                'test_name': test_name,
                'status': 'error',
                'error': str(e),
                'task_count': len(tasks)
            }
    
    async def run_all_tests(self) -> Dict:
        """Run all dependency management tests"""
        logger.info("Starting Dependency Management Validation Suite")
        
        test_cases = [
            ("Linear Chain (10 tasks)", self.create_linear_chain(10)),
            ("Diamond Pattern", self.create_diamond_pattern()),
            ("Complex Graph (15 tasks)", self.create_complex_graph()),
            ("Linear Chain (50 tasks)", self.create_linear_chain(50)),
            ("Circular Dependency", self.create_circular_dependency())
        ]
        
        results = []
        for test_name, tasks in test_cases:
            result = await self.run_test(test_name, tasks)
            results.append(result)
            
            # Log result
            status_symbol = "✓" if result['status'] == 'passed' else "✗"
            logger.info(f"{status_symbol} {test_name}: {result['status']}")
            if result.get('dependency_violations'):
                for violation in result['dependency_violations']:
                    logger.error(f"  - {violation}")
        
        # Calculate overall score
        passed = sum(1 for r in results if r['status'] == 'passed')
        total = len(results)
        score = (passed / total) * 10 if total > 0 else 0
        
        # Average efficiency
        efficiencies = [r.get('parallelization_efficiency', 0) for r in results if r['status'] == 'passed']
        avg_efficiency = sum(efficiencies) / len(efficiencies) if efficiencies else 0
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'test_results': results,
            'summary': {
                'total_tests': total,
                'passed': passed,
                'failed': total - passed,
                'dependency_management_score': round(score, 2),
                'average_parallelization_efficiency': round(avg_efficiency, 3),
                'circular_dependency_detection': 'working' if any(
                    r['test_name'] == 'Circular Dependency' and r['status'] == 'failed' 
                    for r in results
                ) else 'not working'
            }
        }
        
        # Save detailed report
        report_file = self.output_dir / f"dependency_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"\nDetailed report saved to: {report_file}")
        
        return report
    
    def generate_report(self, results: Dict) -> str:
        """Generate human-readable report"""
        report = []
        report.append("=" * 80)
        report.append("DEPENDENCY MANAGEMENT VALIDATION REPORT")
        report.append("=" * 80)
        report.append(f"Timestamp: {results['timestamp']}")
        report.append("")
        
        report.append("TEST RESULTS:")
        report.append("-" * 40)
        
        for test in results['test_results']:
            status_symbol = "✓" if test['status'] == 'passed' else "✗"
            report.append(f"\n{status_symbol} {test['test_name']}")
            report.append(f"  Status: {test['status']}")
            report.append(f"  Tasks: {test['task_count']}")
            
            if test['status'] == 'passed':
                report.append(f"  Execution Time: {test['execution_time']:.2f}s")
                report.append(f"  Parallelization Efficiency: {test['parallelization_efficiency']:.1%}")
                report.append(f"  Tasks/Second: {test['tasks_per_second']:.2f}")
            elif test['status'] == 'failed':
                if test.get('error'):
                    report.append(f"  Error: {test['error']}")
                if test.get('dependency_violations'):
                    report.append("  Violations:")
                    for violation in test['dependency_violations'][:3]:
                        report.append(f"    - {violation}")
                    if len(test['dependency_violations']) > 3:
                        report.append(f"    ... and {len(test['dependency_violations']) - 3} more")
        
        report.append("\n" + "=" * 40)
        report.append("SUMMARY")
        report.append("=" * 40)
        
        summary = results['summary']
        report.append(f"Total Tests: {summary['total_tests']}")
        report.append(f"Passed: {summary['passed']}")
        report.append(f"Failed: {summary['failed']}")
        report.append(f"Circular Dependency Detection: {summary['circular_dependency_detection']}")
        report.append(f"Average Parallelization Efficiency: {summary['average_parallelization_efficiency']:.1%}")
        report.append("")
        report.append(f"DEPENDENCY MANAGEMENT SCORE: {summary['dependency_management_score']}/10")
        
        report.append("\n" + "=" * 40)
        report.append("ANALYSIS")
        report.append("=" * 40)
        
        score = summary['dependency_management_score']
        if score >= 9:
            report.append("EXCELLENT: Dependency management is working perfectly")
            report.append("- All dependency orders are respected")
            report.append("- Circular dependencies are properly detected")
            report.append("- Parallelization is optimized")
        elif score >= 7:
            report.append("GOOD: Dependency management is mostly working")
            report.append("- Most dependencies are handled correctly")
            report.append("- Some optimization opportunities remain")
        elif score >= 5:
            report.append("ADEQUATE: Basic dependency management is functional")
            report.append("- Core functionality works but needs improvement")
            report.append("- Several dependency handling issues detected")
        else:
            report.append("POOR: Significant dependency management issues")
            report.append("- Multiple dependency violations detected")
            report.append("- System may produce incorrect results")
            report.append("- Immediate fixes required")
        
        return "\n".join(report)


async def main():
    """Main test execution"""
    suite = DependencyTestSuite()
    results = await suite.run_all_tests()
    
    # Generate and print report
    report = suite.generate_report(results)
    print(report)
    
    # Save report
    report_file = suite.output_dir / f"dependency_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with open(report_file, 'w') as f:
        f.write(report)
    
    print(f"\nReport saved to: {report_file}")
    
    return results['summary']['dependency_management_score']


if __name__ == "__main__":
    score = asyncio.run(main())
    sys.exit(0 if score >= 7 else 1)