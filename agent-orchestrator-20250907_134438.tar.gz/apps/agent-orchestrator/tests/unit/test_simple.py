#!/usr/bin/env python3
"""Simple test of the agent orchestrator token system"""

import sys
import os

# Set up the Python path correctly
sys.path.insert(0, '/home/opsvi/master_root/apps/multi-agent-monitor')
sys.path.insert(0, '/home/opsvi/master_root/apps/agent-orchestrator')

# Now try to import and test
try:
    # First test: Can we import the secrets manager directly?
    from src.orchestration.secrets_manager import TokenSecretsManager
    print("✅ Successfully imported TokenSecretsManager")
    
    # Second test: Can we load tokens?
    manager = TokenSecretsManager()
    tokens = manager.load_tokens()
    print(f"✅ Loaded {len(tokens)} tokens from encrypted storage")
    
    # List token keys
    token_keys = [k for k in tokens.keys() if k.startswith("CLAUDE_CODE_TOKEN")]
    print(f"✅ Found {len(token_keys)} CLAUDE_CODE_TOKEN entries")
    
    # Third test: Can we use the dynamic pool?
    sys.path.insert(0, '/home/opsvi/master_root/apps/agent-orchestrator/src')
    from dynamic_token_pool import get_dynamic_tokens
    dynamic_tokens = get_dynamic_tokens()
    print(f"✅ Dynamic pool returned {len(dynamic_tokens)} tokens")
    
    if dynamic_tokens:
        print(f"   First token preview: {dynamic_tokens[0][:20]}...")
    
    print("\n🎉 SUCCESS: Agent orchestrator token system is working!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print(f"   Python path: {sys.path}")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()