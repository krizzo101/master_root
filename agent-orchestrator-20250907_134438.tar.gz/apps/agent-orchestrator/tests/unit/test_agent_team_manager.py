#!/usr/bin/env python3
"""
AgentTeamManager Integration Tests

Tests the integration of AgentTeamManager with all specialist components:
- Enhanced Orchestrator
- Agent Status Monitor  
- Quality Gate Manager
"""

import asyncio
import json
import logging
import shutil
import tempfile
import time
from pathlib import Path
from unittest.mock import Mock, patch

# Add src to path
import sys
sys.path.append(str(Path(__file__).parent / "src"))

from agent_team_manager import AgentTeamManager, TeamStatus, TeamResults
from enhanced_orchestrator import EnhancedAgentTask
from quality_gates import QualityGateManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestAgentTeamManager:
    """Test suite for AgentTeamManager integration"""
    
    def __init__(self):
        self.temp_dir = None
        self.manager = None
    
    def setup(self):
        """Set up test environment"""
        self.temp_dir = Path(tempfile.mkdtemp(prefix="agent_team_test_"))
        print(f"Test directory: {self.temp_dir}")
        
        # Initialize manager with test configuration
        self.manager = AgentTeamManager(
            output_dir=self.temp_dir / "output",
            max_parallel=2,
            tokens=["test-token"],  # Mock token
            enable_quality_gates=True,
            enable_monitoring=True
        )
    
    def teardown(self):
        """Clean up test environment"""
        if self.manager:
            asyncio.run(self.manager.shutdown())
        
        if self.temp_dir and self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            print(f"Cleaned up test directory: {self.temp_dir}")
    
    async def test_manager_initialization(self):
        """Test that AgentTeamManager initializes correctly with all components"""
        print("\n=== Test Manager Initialization ===")
        
        assert self.manager is not None
        assert self.manager.orchestrator is not None
        assert self.manager.monitor is not None
        assert self.manager.quality_gate_manager is not None
        
        print("✓ AgentTeamManager initialized successfully")
        print("✓ Enhanced Orchestrator integrated")
        print("✓ Agent Status Monitor integrated")
        print("✓ Quality Gate Manager integrated")
    
    async def test_quality_gates_setup(self):
        """Test quality gates setup and validation"""
        print("\n=== Test Quality Gates Setup ===")
        
        # Create test file for file validator
        test_file = self.temp_dir / "test_gate.txt"
        test_file.write_text("test content")
        
        gates_config = [
            {
                "gate_id": "test_file_gate",
                "name": "Test File Gate",
                "description": "Test file exists",
                "validator_type": "file",
                "config": {
                    "path": str(test_file),
                    "exists": True,
                    "contains": "test content"
                }
            },
            {
                "gate_id": "test_command_gate",
                "name": "Test Command Gate",
                "description": "Test command succeeds",
                "validator_type": "command",
                "config": {
                    "command": ["echo", "test"],
                    "expected_return_code": 0
                },
                "dependencies": ["test_file_gate"]
            }
        ]
        
        await self.manager.setup_quality_gates(gates_config)
        
        # Wait a moment for validation
        await asyncio.sleep(3)
        
        # Check gate status
        if self.manager.quality_gate_manager:
            status_report = await self.manager.quality_gate_manager.get_status_report()
            print(f"Quality gate status: {status_report['gates']}")
            
            # Verify gates were created
            assert "test_file_gate" in status_report["gates"]
            assert "test_command_gate" in status_report["gates"]
            
            print("✓ Quality gates setup successfully")
            print("✓ File validator working")
            print("✓ Command validator working")
            print("✓ Gate dependencies respected")
        else:
            print("⚠️  Quality gate manager not available")
    
    async def test_team_launch_and_status(self):
        """Test launching a team and getting status updates"""
        print("\n=== Test Team Launch and Status ===")
        
        # Mock the actual agent execution since we don't have real Claude tokens
        with patch.object(self.manager.orchestrator, 'execute_batch') as mock_execute:
            # Mock successful execution
            mock_results = [
                {
                    "task_id": "test_task_1",
                    "status": "completed",
                    "result": {"message": "Task 1 completed successfully"}
                },
                {
                    "task_id": "test_task_2", 
                    "status": "completed",
                    "result": {"message": "Task 2 completed successfully"}
                }
            ]
            
            # Create a future that will complete after a delay
            future = asyncio.Future()
            
            async def delayed_complete():
                await asyncio.sleep(2)  # Simulate execution time
                future.set_result(mock_results)
            
            asyncio.create_task(delayed_complete())
            mock_execute.return_value = future
            
            # Define test tasks
            task_definitions = [
                {
                    "task_id": "test_task_1",
                    "task_type": "test_specialist",
                    "prompt": "Complete test task 1",
                    "team_id": "test-team-001"
                },
                {
                    "task_id": "test_task_2",
                    "task_type": "test_specialist", 
                    "prompt": "Complete test task 2",
                    "dependencies": ["test_task_1"],
                    "team_id": "test-team-001"
                }
            ]
            
            # Launch team
            team_id = self.manager.launch_monitored_team(task_definitions)
            print(f"✓ Launched team: {team_id}")
            
            # Test immediate status
            status = await self.manager.get_team_status(team_id)
            assert status.team_id == team_id
            assert status.agent_count == 2
            print(f"✓ Initial status: {status.status} with {status.agent_count} agents")
            
            # Wait for completion and get final results
            await asyncio.sleep(3)
            
            final_results = await self.manager.get_final_results(team_id)
            print(f"✓ Final results: {final_results.status}")
            print(f"✓ Execution time: {final_results.execution_time:.2f}s")
            
            # Cleanup
            await self.manager.cleanup_team(team_id)
            print("✓ Team cleanup completed")
    
    async def test_monitoring_functionality(self):
        """Test monitoring capabilities"""
        print("\n=== Test Monitoring Functionality ===")
        
        # Mock agent status responses
        with patch.object(self.manager.monitor, 'get_agent_status') as mock_get_status:
            mock_status = Mock()
            mock_status.status = "running"
            mock_status.progress.progress_percentage = 75.0
            mock_status.error_count = 0
            mock_status.last_activity_timestamp = "2023-01-01T12:00:00Z"
            mock_status.progress.current_task = "Processing data"
            
            mock_get_status.return_value = mock_status
            
            # Test getting agent status
            status = await self.manager.monitor.get_agent_status("test-uuid")
            assert status.status == "running"
            assert status.progress.progress_percentage == 75.0
            print("✓ Agent status monitoring working")
            
            # Test team status with monitoring data
            with patch.object(self.manager, 'active_teams', {"test-team": {
                "status": "running",
                "start_time": "2023-01-01T12:00:00",
                "agent_uuids": ["test-uuid"]
            }}):
                team_status = await self.manager.get_team_status("test-team")
                assert team_status.team_id == "test-team"
                assert "test-uuid" in team_status.agent_statuses
                print("✓ Team status with monitoring data working")
    
    async def test_enhanced_orchestrator_integration(self):
        """Test integration with Enhanced Orchestrator"""
        print("\n=== Test Enhanced Orchestrator Integration ===")
        
        # Test enhanced task creation
        enhanced_task = self.manager.orchestrator.create_enhanced_task(
            task_id="test_enhanced",
            task_type="test",
            prompt="Test enhanced task",
            quality_gates=["test_gate"],
            monitoring_enabled=True,
            team_id="test-team"
        )
        
        assert isinstance(enhanced_task, EnhancedAgentTask)
        assert enhanced_task.task_id == "test_enhanced"
        assert enhanced_task.monitoring_enabled == True
        assert enhanced_task.team_id == "test-team"
        assert "test_gate" in enhanced_task.quality_gates
        
        print("✓ Enhanced task creation working")
        print("✓ Quality gate integration working")
        print("✓ Monitoring integration working")
        print("✓ Team ID assignment working")
    
    async def test_error_handling(self):
        """Test error handling and edge cases"""
        print("\n=== Test Error Handling ===")
        
        # Test unknown team status
        status = await self.manager.get_team_status("unknown-team")
        assert status.status == "unknown"
        assert status.agent_count == 0
        print("✓ Unknown team handled correctly")
        
        # Test final results for unknown team
        results = await self.manager.get_final_results("unknown-team")
        assert results.status == "unknown"
        assert results.execution_time == 0.0
        print("✓ Unknown team results handled correctly")
        
        # Test empty task definitions
        try:
            team_id = self.manager.launch_monitored_team([])
            status = await self.manager.get_team_status(team_id)
            assert status.agent_count == 0
            print("✓ Empty task list handled correctly")
        except Exception as e:
            print(f"⚠️  Empty task list error: {e}")
    
    async def test_team_status_api(self):
        """Test TeamStatus API completeness"""
        print("\n=== Test TeamStatus API ===")
        
        # Create a comprehensive team status
        status = TeamStatus(
            team_id="api-test",
            status="running",
            agent_count=5,
            agents_running=2,
            agents_completed=2,
            agents_failed=1,
            overall_progress_percentage=60.0
        )
        
        # Test serialization
        status_dict = status.to_dict()
        assert status_dict["team_id"] == "api-test"
        assert status_dict["agent_count"] == 5
        assert status_dict["overall_progress_percentage"] == 60.0
        assert "last_update" in status_dict
        
        print("✓ TeamStatus serialization working")
        print("✓ All required fields present")
        print("✓ Progress calculation working")
    
    async def test_team_results_api(self):
        """Test TeamResults API completeness"""
        print("\n=== Test TeamResults API ===")
        
        # Create comprehensive team results
        results = TeamResults(
            team_id="results-test",
            status="completed",
            execution_time=120.5,
            success_rate=80.0,
            total_errors=2,
            deliverables_created=["file1.py", "file2.md"],
            quality_gates_passed=3,
            quality_gates_failed=1
        )
        
        # Test serialization
        results_dict = results.to_dict()
        assert results_dict["team_id"] == "results-test"
        assert results_dict["execution_time"] == 120.5
        assert results_dict["success_rate"] == 80.0
        assert len(results_dict["deliverables_created"]) == 2
        
        print("✓ TeamResults serialization working")
        print("✓ All metrics included")
        print("✓ Quality gate metrics working")


async def run_all_tests():
    """Run all integration tests"""
    print("AgentTeamManager Integration Tests")
    print("=" * 50)
    
    test_suite = TestAgentTeamManager()
    
    try:
        # Setup
        test_suite.setup()
        
        # Run tests
        await test_suite.test_manager_initialization()
        await test_suite.test_quality_gates_setup()
        await test_suite.test_team_launch_and_status()
        await test_suite.test_monitoring_functionality()
        await test_suite.test_enhanced_orchestrator_integration()
        await test_suite.test_error_handling()
        await test_suite.test_team_status_api()
        await test_suite.test_team_results_api()
        
        print("\n" + "=" * 50)
        print("🎉 ALL TESTS PASSED!")
        print("✅ AgentTeamManager integration verified")
        print("✅ All specialist components integrated")
        print("✅ Management agent API ready for use")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # Cleanup
        test_suite.teardown()


def test_imports():
    """Test that all components can be imported correctly"""
    print("\n=== Test Imports ===")
    
    try:
        from agent_team_manager import AgentTeamManager, TeamStatus, TeamResults
        print("✓ AgentTeamManager imports working")
        
        from enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask
        print("✓ Enhanced Orchestrator imports working")
        
        from agent_monitor import AgentStatusMonitor, AgentStatus
        print("✓ Agent Monitor imports working")
        
        from quality_gates import QualityGateManager, GateStatus
        print("✓ Quality Gates imports working")
        
        print("✅ All component imports successful")
        return True
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False


def main():
    """Main test runner"""
    print("Starting AgentTeamManager Integration Tests...")
    
    # Test imports first
    if not test_imports():
        print("❌ Import tests failed - cannot proceed with integration tests")
        return
    
    # Run full integration tests
    asyncio.run(run_all_tests())


if __name__ == "__main__":
    main()