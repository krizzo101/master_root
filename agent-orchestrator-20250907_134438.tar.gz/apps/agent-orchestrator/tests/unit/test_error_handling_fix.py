#!/usr/bin/env python3
"""
Comprehensive test suite for error handling fixes in GenericOrchestrator
Tests all error paths and edge cases to ensure no empty error strings
"""

import asyncio
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

# Add the source directory to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import AgentTask, GenericOrchestrator


async def test_empty_stdout_handling():
    """Test that empty stdout produces meaningful error"""
    print("\n=== Testing Empty Stdout Handling ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        task = AgentTask(
            task_id="empty_stdout_test",
            task_type="test",
            prompt="Test with empty stdout"
        )
        
        # Mock subprocess to return empty stdout
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = AsyncMock()
            mock_process.communicate.return_value = (b"", b"")  # Empty stdout and stderr
            mock_process.returncode = 0  # Success code but no output
            mock_subprocess.return_value = mock_process
            
            await orchestrator.execute_agent(task)
            
            # Verify error is not empty
            assert task.error, f"Error should not be empty, got: {repr(task.error)}"
            assert "no output" in task.error.lower(), f"Error should mention no output: {task.error}"
            print(f"✓ Empty stdout error: {task.error}")


async def test_malformed_json_parsing():
    """Test JSON parsing errors provide context"""
    print("\n=== Testing Malformed JSON Parsing ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        task = AgentTask(
            task_id="json_error_test",
            task_type="test",
            prompt="Test with malformed JSON"
        )
        
        # Mock subprocess to return malformed JSON
        malformed_outputs = [
            b"{'not': 'valid json'}",  # Single quotes
            b"{incomplete",  # Incomplete JSON
            b"Not JSON at all",  # Plain text
            b'{"key": undefined}',  # JavaScript undefined
        ]
        
        for idx, bad_output in enumerate(malformed_outputs):
            task_copy = AgentTask(
                task_id=f"json_error_{idx}",
                task_type="test",
                prompt=f"Test {idx}"
            )
            
            with patch('asyncio.create_subprocess_exec') as mock_subprocess:
                mock_process = AsyncMock()
                mock_process.communicate.return_value = (bad_output, b"")
                mock_process.returncode = 0
                mock_subprocess.return_value = mock_process
                
                await orchestrator.execute_agent(task_copy)
                
                # Verify error is descriptive
                assert task_copy.error, f"Error should not be empty for {bad_output}"
                assert "JSON" in task_copy.error, f"Error should mention JSON: {task_copy.error}"
                assert task_copy.raw_output is not None, "Raw output should be preserved"
                print(f"✓ JSON error {idx}: {task_copy.error[:100]}...")


async def test_exception_with_no_message():
    """Test exceptions with empty messages get handled"""
    print("\n=== Testing Exception with No Message ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        task = AgentTask(
            task_id="empty_exception_test",
            task_type="test",
            prompt="Test with empty exception"
        )
        
        # Mock subprocess to raise exception with no message
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_subprocess.side_effect = ValueError()  # Exception with no message
            
            await orchestrator.execute_agent(task)
            
            # Verify error is not empty
            assert task.error, f"Error should not be empty: {repr(task.error)}"
            assert "ValueError" in task.error, f"Error should contain exception type: {task.error}"
            assert task.error_details is not None, "Error details should be present"
            assert task.error_details["type"] == "ValueError"
            print(f"✓ Empty exception error: {task.error}")


async def test_stderr_capture():
    """Test stderr is properly captured and included"""
    print("\n=== Testing Stderr Capture ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        task = AgentTask(
            task_id="stderr_test",
            task_type="test",
            prompt="Test stderr capture"
        )
        
        # Mock subprocess with stderr
        stderr_message = "Error: Something went wrong in the subprocess"
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = AsyncMock()
            mock_process.communicate.return_value = (b"", stderr_message.encode())
            mock_process.returncode = 1
            mock_subprocess.return_value = mock_process
            
            await orchestrator.execute_agent(task)
            
            # Verify stderr is in error
            assert task.error, f"Error should not be empty: {repr(task.error)}"
            assert stderr_message in task.error, f"Error should contain stderr: {task.error}"
            assert "Exit code: 1" in task.error, f"Error should contain exit code: {task.error}"
            print(f"✓ Stderr captured: {task.error}")


async def test_error_details_preservation():
    """Test that error details are properly preserved"""
    print("\n=== Testing Error Details Preservation ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        task = AgentTask(
            task_id="details_test",
            task_type="test",
            prompt="Test error details"
        )
        
        # Mock subprocess to raise specific exception
        test_exception = RuntimeError("Test error with details")
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_subprocess.side_effect = test_exception
            
            await orchestrator.execute_agent(task)
            
            # Verify error details
            assert task.error_details is not None, "Error details should be present"
            assert task.error_details["type"] == "RuntimeError"
            assert task.error_details["message"] == "Test error with details"
            assert "traceback" in task.error_details
            assert "timestamp" in task.error_details
            assert task.error_details["task_id"] == "details_test"
            print(f"✓ Error details preserved: {json.dumps(task.error_details, indent=2)}")


async def test_mixed_error_scenarios():
    """Test various mixed error scenarios"""
    print("\n=== Testing Mixed Error Scenarios ===")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=1,
            tokens=["dummy_token_for_testing"]  # Provide token to avoid loader
        )
        
        # Scenario 1: Success code with invalid JSON
        task1 = AgentTask(
            task_id="mixed_1",
            task_type="test",
            prompt="Success with bad JSON"
        )
        
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = AsyncMock()
            mock_process.communicate.return_value = (b"Not valid JSON", b"")
            mock_process.returncode = 0
            mock_subprocess.return_value = mock_process
            
            await orchestrator.execute_agent(task1)
            assert task1.error and len(task1.error) > 10, f"Error too short: {task1.error}"
            print(f"✓ Mixed scenario 1: {task1.error[:80]}...")
        
        # Scenario 2: Failure with both stdout and stderr
        task2 = AgentTask(
            task_id="mixed_2",
            task_type="test",
            prompt="Failure with outputs"
        )
        
        with patch('asyncio.create_subprocess_exec') as mock_subprocess:
            mock_process = AsyncMock()
            mock_process.communicate.return_value = (
                b"Some debug output",
                b"Fatal error occurred"
            )
            mock_process.returncode = 2
            mock_subprocess.return_value = mock_process
            
            await orchestrator.execute_agent(task2)
            assert "Fatal error" in task2.error, f"Missing stderr: {task2.error}"
            assert "debug output" in task2.error, f"Missing stdout: {task2.error}"
            assert "Exit code: 2" in task2.error, f"Missing exit code: {task2.error}"
            print(f"✓ Mixed scenario 2: {task2.error[:80]}...")


async def test_task_serialization():
    """Test that tasks with errors serialize properly"""
    print("\n=== Testing Task Serialization ===")
    
    task = AgentTask(
        task_id="serialize_test",
        task_type="test",
        prompt="Test serialization"
    )
    
    # Add error details
    task.error = "Test error message"
    task.raw_output = "A" * 2000  # Long output
    task.error_details = {
        "type": "TestError",
        "message": "Test",
        "traceback": ["line 1", "line 2"],
        "timestamp": "2025-01-01T00:00:00"
    }
    
    # Convert to dict
    task_dict = task.to_dict()
    
    # Verify serialization
    assert "error" in task_dict
    assert "raw_output" in task_dict
    assert "error_details" in task_dict
    
    # Verify truncation of long output
    if len(task.raw_output) > 1000:
        assert len(task_dict["raw_output"]) < len(task.raw_output)
        assert "..." in task_dict["raw_output"]
    
    # Verify JSON serializable
    json_str = json.dumps(task_dict)
    assert json_str
    print(f"✓ Task serialization successful, size: {len(json_str)} bytes")


async def main():
    """Run all tests"""
    print("=" * 60)
    print("ERROR HANDLING FIX TEST SUITE")
    print("=" * 60)
    
    tests = [
        test_empty_stdout_handling,
        test_malformed_json_parsing,
        test_exception_with_no_message,
        test_stderr_capture,
        test_error_details_preservation,
        test_mixed_error_scenarios,
        test_task_serialization,
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            await test_func()
            passed += 1
        except Exception as e:
            print(f"\n✗ {test_func.__name__} FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"TEST RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)
    
    if failed == 0:
        print("\n✓ ALL TESTS PASSED - Error handling fix verified!")
        return 0
    else:
        print(f"\n✗ {failed} TESTS FAILED - Please review and fix")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)