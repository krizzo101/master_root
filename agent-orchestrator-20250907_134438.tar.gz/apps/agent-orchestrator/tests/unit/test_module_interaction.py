#!/usr/bin/env python3
"""
Module Interaction Test Suite - Task 0
Tests interaction between orchestrator modules
"""

import asyncio
import json
import pytest
import sys
from pathlib import Path
from typing import Dict, Any, List
from unittest.mock import Mock, AsyncMock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent))

try:
    from src.modules.quality_gates_module import QualityGatesModule
    from src.modules.monitoring_module import MonitoringModule
    from src.modules.collaboration_module import CollaborationModule
    from src.modules.execution_plan_module import ExecutionPlanModule
    from src.unified.unified_orchestrator import UnifiedOrchestrator
    from src.unified.orchestrator_module import ModuleConfig, ModuleRegistry
except ImportError:
    # Fallback for modules that may not exist
    QualityGatesModule = Mock
    MonitoringModule = Mock
    CollaborationModule = Mock
    ExecutionPlanModule = Mock
    UnifiedOrchestrator = Mock
    ModuleConfig = Mock
    ModuleRegistry = Mock


class TestModuleInteraction:
    """Test suite for module interaction patterns"""
    
    @pytest.fixture
    def mock_orchestrator(self):
        """Create mock orchestrator with basic setup"""
        orchestrator = Mock(spec=UnifiedOrchestrator)
        orchestrator.registry = ModuleRegistry()
        orchestrator.tasks = {}
        orchestrator.agent_pool = Mock()
        orchestrator.output_dir = Path("/tmp/test_output")
        orchestrator.logger = Mock()
        return orchestrator
    
    @pytest.fixture
    def quality_gates_module(self, mock_orchestrator):
        """Initialize quality gates module"""
        config = ModuleConfig(
            enabled=True,
            config={
                "gates": [
                    {"name": "syntax_check", "type": "validation"},
                    {"name": "type_check", "type": "validation"}
                ]
            }
        )
        return QualityGatesModule(config, mock_orchestrator)
    
    @pytest.fixture
    def monitoring_module(self, mock_orchestrator):
        """Initialize monitoring module"""
        config = ModuleConfig(
            enabled=True,
            config={
                "check_interval": 5,
                "metrics_enabled": True
            }
        )
        return MonitoringModule(config, mock_orchestrator)
    
    @pytest.fixture
    def collaboration_module(self, mock_orchestrator):
        """Initialize collaboration module"""
        config = ModuleConfig(
            enabled=True,
            config={
                "mode": "parallel",
                "max_agents": 3
            }
        )
        return CollaborationModule(config, mock_orchestrator)
    
    @pytest.fixture
    def execution_plan_module(self, mock_orchestrator):
        """Initialize execution plan module"""
        config = ModuleConfig(
            enabled=True,
            config={
                "mode": "adaptive",
                "phases": ["planning", "execution", "validation"]
            }
        )
        return ExecutionPlanModule(config, mock_orchestrator)
    
    @pytest.mark.asyncio
    async def test_module_registration(self, mock_orchestrator):
        """Test module registration and discovery"""
        registry = ModuleRegistry()
        
        # Register modules
        quality_config = ModuleConfig(enabled=True)
        monitoring_config = ModuleConfig(enabled=True)
        
        quality_module = QualityGatesModule(quality_config, mock_orchestrator)
        monitoring_module = MonitoringModule(monitoring_config, mock_orchestrator)
        
        registry.register(quality_module)
        registry.register(monitoring_module)
        
        # Test discovery
        assert registry.get("QualityGatesModule") is not None
        assert registry.get("MonitoringModule") is not None
        assert len(registry.list_modules()) == 2
    
    @pytest.mark.asyncio
    async def test_quality_monitoring_interaction(
        self, quality_gates_module, monitoring_module
    ):
        """Test interaction between quality gates and monitoring"""
        # Create test task
        task = {
            "task_id": "test_001",
            "task_type": "validation",
            "status": "running"
        }
        
        # Quality gate check
        gate_result = await quality_gates_module.check_gate(
            "syntax_check", task
        )
        
        # Monitoring should track gate results
        metrics = await monitoring_module.collect_metrics()
        
        # Verify interaction
        assert gate_result is not None
        assert metrics is not None
    
    @pytest.mark.asyncio
    async def test_execution_collaboration_interaction(
        self, execution_plan_module, collaboration_module
    ):
        """Test interaction between execution planning and collaboration"""
        # Create execution plan
        plan = await execution_plan_module.create_plan({
            "tasks": [
                {"id": "task_1", "type": "analysis"},
                {"id": "task_2", "type": "implementation"}
            ]
        })
        
        # Setup collaboration for plan execution
        team = await collaboration_module.setup_team(plan)
        
        # Verify interaction
        assert plan is not None
        assert team is not None
    
    @pytest.mark.asyncio
    async def test_full_pipeline_interaction(
        self, quality_gates_module, monitoring_module,
        collaboration_module, execution_plan_module
    ):
        """Test full pipeline with all modules interacting"""
        # Phase 1: Planning
        plan = await execution_plan_module.create_plan({
            "goal": "test_pipeline",
            "tasks": [
                {"id": "t1", "type": "setup"},
                {"id": "t2", "type": "execute"},
                {"id": "t3", "type": "validate"}
            ]
        })
        
        # Phase 2: Team setup
        team = await collaboration_module.setup_team(plan)
        
        # Phase 3: Execute with monitoring
        monitoring_task = asyncio.create_task(
            monitoring_module.monitor_execution(plan)
        )
        
        # Phase 4: Quality gates at each step
        for task in plan.get("tasks", []):
            gate_result = await quality_gates_module.check_gate(
                "syntax_check", task
            )
            assert gate_result is not None
        
        # Phase 5: Complete monitoring
        monitoring_task.cancel()
        
        # Verify all interactions
        assert plan is not None
        assert team is not None
    
    @pytest.mark.asyncio
    async def test_error_propagation_between_modules(
        self, quality_gates_module, monitoring_module
    ):
        """Test error handling across module boundaries"""
        # Simulate error in quality gate
        with patch.object(quality_gates_module, 'check_gate',
                         side_effect=Exception("Gate check failed")):
            
            # Monitoring should capture the error
            error_metrics = await monitoring_module.capture_error(
                "quality_gate_error",
                {"module": "QualityGatesModule", "error": "Gate check failed"}
            )
            
            assert error_metrics is not None
            assert "quality_gate_error" in str(error_metrics)
    
    @pytest.mark.asyncio
    async def test_module_communication_channels(
        self, mock_orchestrator, quality_gates_module, monitoring_module
    ):
        """Test inter-module communication patterns"""
        # Setup communication channel
        event_bus = asyncio.Queue()
        
        # Module 1 sends event
        await event_bus.put({
            "source": "QualityGatesModule",
            "event": "gate_passed",
            "data": {"gate": "syntax_check", "task_id": "test_001"}
        })
        
        # Module 2 receives event
        event = await event_bus.get()
        
        # Process in monitoring module
        await monitoring_module.handle_event(event)
        
        # Verify communication
        assert event["source"] == "QualityGatesModule"
        assert event["event"] == "gate_passed"
    
    @pytest.mark.asyncio
    async def test_module_dependency_resolution(
        self, mock_orchestrator
    ):
        """Test module dependency handling"""
        registry = ModuleRegistry()
        
        # Create modules with dependencies
        config_with_deps = ModuleConfig(
            enabled=True,
            dependencies=["MonitoringModule"]
        )
        
        quality_module = QualityGatesModule(config_with_deps, mock_orchestrator)
        monitoring_module = MonitoringModule(ModuleConfig(enabled=True), mock_orchestrator)
        
        # Register in correct order
        registry.register(monitoring_module)
        registry.register(quality_module)
        
        # Verify dependency resolution
        deps = registry.resolve_dependencies("QualityGatesModule")
        assert "MonitoringModule" in deps
    
    @pytest.mark.asyncio  
    async def test_module_lifecycle_coordination(
        self, quality_gates_module, monitoring_module,
        collaboration_module, execution_plan_module
    ):
        """Test coordinated module lifecycle management"""
        modules = [
            quality_gates_module,
            monitoring_module,
            collaboration_module,
            execution_plan_module
        ]
        
        # Initialize all modules
        init_tasks = [m.initialize() for m in modules]
        await asyncio.gather(*init_tasks)
        
        # Run modules
        run_tasks = [m.run() for m in modules]
        results = await asyncio.gather(*run_tasks, return_exceptions=True)
        
        # Shutdown modules
        shutdown_tasks = [m.shutdown() for m in modules]
        await asyncio.gather(*shutdown_tasks)
        
        # Verify lifecycle
        assert all(r is None or not isinstance(r, Exception) for r in results)
    
    @pytest.mark.asyncio
    async def test_shared_state_management(
        self, mock_orchestrator, quality_gates_module, monitoring_module
    ):
        """Test shared state management between modules"""
        # Create shared state
        shared_state = {
            "tasks": {},
            "metrics": {},
            "gates": {}
        }
        
        # Module 1 updates state
        shared_state["gates"]["syntax_check"] = "passed"
        
        # Module 2 reads state
        gate_status = shared_state["gates"].get("syntax_check")
        
        # Update metrics based on gate status
        if gate_status == "passed":
            shared_state["metrics"]["gates_passed"] = \
                shared_state["metrics"].get("gates_passed", 0) + 1
        
        # Verify state consistency
        assert shared_state["gates"]["syntax_check"] == "passed"
        assert shared_state["metrics"]["gates_passed"] == 1
    
    @pytest.mark.asyncio
    async def test_module_isolation_boundaries(
        self, quality_gates_module, monitoring_module
    ):
        """Test module isolation and boundary enforcement"""
        # Each module should have isolated state
        quality_state = {"internal": "quality_data"}
        monitoring_state = {"internal": "monitoring_data"}
        
        # Modules should not directly access each other's state
        with pytest.raises(AttributeError):
            _ = quality_gates_module.monitoring_state
        
        with pytest.raises(AttributeError):
            _ = monitoring_module.quality_state
        
        # Communication should go through defined interfaces
        assert quality_state["internal"] == "quality_data"
        assert monitoring_state["internal"] == "monitoring_data"


class TestModuleIntegration:
    """Integration tests for module system"""
    
    @pytest.mark.asyncio
    async def test_real_orchestrator_module_loading(self):
        """Test loading modules in real orchestrator"""
        config = {
            "modules": {
                "quality_gates": {"enabled": True},
                "monitoring": {"enabled": True}
            }
        }
        
        with patch("src.unified.unified_orchestrator.TokenPool"):
            orchestrator = UnifiedOrchestrator(config)
            await orchestrator.initialize()
            
            # Verify modules loaded
            assert orchestrator.registry.get("QualityGatesModule") is not None
            assert orchestrator.registry.get("MonitoringModule") is not None
    
    @pytest.mark.asyncio
    async def test_module_hot_reload(self, mock_orchestrator):
        """Test dynamic module reloading"""
        registry = ModuleRegistry()
        
        # Initial module
        v1_config = ModuleConfig(enabled=True, version="1.0")
        v1_module = QualityGatesModule(v1_config, mock_orchestrator)
        registry.register(v1_module)
        
        # Hot reload with new version
        v2_config = ModuleConfig(enabled=True, version="2.0")
        v2_module = QualityGatesModule(v2_config, mock_orchestrator)
        
        # Replace module
        registry.unregister("QualityGatesModule")
        registry.register(v2_module)
        
        # Verify new version
        current = registry.get("QualityGatesModule")
        assert current.config.version == "2.0"


def run_tests():
    """Run test suite"""
    pytest.main([__file__, "-v", "--tb=short"])


if __name__ == "__main__":
    run_tests()