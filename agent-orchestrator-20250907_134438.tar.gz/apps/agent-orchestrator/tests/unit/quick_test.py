#!/usr/bin/env python3
"""
Quick test to prove PracticalOrchestrator works
"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.append('src')
from practical_orchestrator import PracticalOrchestrator, PracticalAgentTask

async def quick_test():
    print("🧪 QUICK PRACTICAL ORCHESTRATOR TEST")
    print("=" * 40)
    
    # Create orchestrator 
    orchestrator = PracticalOrchestrator(
        output_dir="./quick_test_output",
        max_parallel=1  # Single task for quick test
    )
    
    # Progress callback
    def progress_handler(event_type, data):
        print(f"📊 {event_type}: {data}")
    
    orchestrator.set_progress_callback(progress_handler)
    
    # Simple task
    task = PracticalAgentTask(
        task_id="hello_world",
        task_type="development-specialist", 
        prompt="Create a simple Python file called 'hello.py' that contains a function 'say_hello()' which returns the string 'Hello from PracticalOrchestrator!'",
        phase_id="test_phase",
        priority="high",
        tags=["test", "python"]
    )
    
    print(f"🚀 Executing task: {task.task_id}")
    print(f"📍 Session ID: {task.session_id}")
    print(f"📁 Log path: {task.get_log_path()}")
    
    # Execute
    results = await orchestrator.execute_batch([task])
    
    # Show results
    result = results[0]
    print(f"\n✅ Task Status: {result.get('status')}")
    print(f"📊 Enhanced fields:")
    for field in ['session_id', 'phase_id', 'priority', 'tags', 'log_path']:
        print(f"  {field}: {result.get(field)}")
    
    # Check outputs exist
    output_dir = Path("./quick_test_output")
    task_file = output_dir / "tasks" / "hello_world.json"
    quality_file = output_dir / "quality_report.json"
    
    print(f"\n📁 Files created:")
    print(f"  Task output: {task_file.exists()} - {task_file}")
    print(f"  Quality report: {quality_file.exists()} - {quality_file}")
    
    if quality_file.exists():
        with open(quality_file) as f:
            report = json.load(f)
        print(f"📈 Success rate: {report['success_rate']:.1%}")
        print(f"📈 Tasks by type: {report['tasks_by_type']}")
    
    # Show session mapping
    print(f"\n🔍 Session Mapping:")
    orchestrator.print_session_map()
    
    success = result.get('status') == 'completed'
    print(f"\n{'🎉 SUCCESS!' if success else '❌ FAILED'}")
    
    return success

if __name__ == "__main__":
    success = asyncio.run(quick_test())
    print(f"Result: {'PASS' if success else 'FAIL'}")