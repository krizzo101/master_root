#!/usr/bin/env python3
"""
Agent-Monitored Multi-Agent Orchestration Test

This is what session 517a was actually working toward:
- One agent (me) launches multiple other agents via GenericOrchestrator
- Real-time monitoring of their progress using chat_search.py from session 7446
- Demonstration of agent-managed multi-agent coordination
"""

import asyncio
import sys
import subprocess
import time
from pathlib import Path

# Add the orchestrator to the path
orchestrator_path = Path("/home/opsvi/master_root/apps/agent-orchestrator")
sys.path.insert(0, str(orchestrator_path))

from src.generic_orchestrator import GenericOrchestrator, AgentTask

async def monitor_agents_realtime():
    """Monitor agents using chat_search.py while they're running"""
    print("🔍 Starting real-time agent monitoring...")
    
    for i in range(60):  # Monitor for 60 seconds
        try:
            # Check for recent agent activity
            result = subprocess.run([
                "python", "../../apps/chat-search/chat_search.py",
                "--limit", "5", 
                "--date-from", time.strftime("%Y-%m-%d"),
                "claude|agent|task"
            ], capture_output=True, text=True, timeout=3)
            
            if result.returncode == 0 and result.stdout.strip():
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:  # Skip the "Found X matches" line
                    latest_activity = lines[1] if len(lines) > 1 else lines[0]
                    print(f"📊 [{time.strftime('%H:%M:%S')}] {latest_activity}")
                    
        except Exception as e:
            print(f"⚠️ Monitoring check failed: {e}")
            
        await asyncio.sleep(1)

async def run_orchestrator_test():
    """Run the actual GenericOrchestrator with multiple agents"""
    print("🚀 Launching agents via GenericOrchestrator...")
    
    # Create orchestrator with optimizations
    orchestrator = GenericOrchestrator(
        output_dir=orchestrator_path / "output",
        max_parallel=3,
        use_optimizations=True  # This should apply the 3-5s performance tweaks
    )
    
    # Define test tasks for the agents
    tasks = [
        AgentTask(
            task_id="researcher",
            task_type="research",
            prompt="Research the key benefits of FastAPI over Flask. Provide exactly 3 main points.",
        ),
        AgentTask(
            task_id="analyzer", 
            task_type="analysis",
            prompt="Analyze the current working directory structure and list the main subdirectories.",
        ),
        AgentTask(
            task_id="documenter",
            task_type="documentation", 
            prompt="Create a brief explanation of what a headless Claude agent is and why it's useful.",
        ),
        AgentTask(
            task_id="synthesizer",
            task_type="synthesis",
            prompt="Combine insights from the research, analysis, and documentation to create a summary.",
            dependencies=["researcher", "analyzer", "documenter"]  # This waits for the others
        )
    ]
    
    print(f"📋 Configured {len(tasks)} tasks:")
    for task in tasks:
        deps = f" (depends on: {task.dependencies})" if task.dependencies else ""
        print(f"   • {task.task_id}: {task.task_type}{deps}")
    
    # Execute the tasks
    print("\n🎬 Starting orchestrator execution...")
    await orchestrator.execute_batch(tasks)
    
    print("\n✅ Orchestrator execution complete!")
    
    # Check results
    output_dir = orchestrator_path / "output"
    if output_dir.exists():
        result_files = list(output_dir.rglob("*.json"))
        print(f"📁 Generated {len(result_files)} result files:")
        for file in result_files[:5]:  # Show first 5
            print(f"   • {file}")

async def main():
    """Main execution function"""
    print("🤖 Agent-Monitored Multi-Agent Orchestration Test")
    print("=" * 60)
    print("Testing: Can one agent launch and monitor multiple other agents?")
    print()
    
    # Start monitoring in parallel with orchestrator
    monitor_task = asyncio.create_task(monitor_agents_realtime())
    orchestrator_task = asyncio.create_task(run_orchestrator_test())
    
    # Wait for orchestrator to complete, then stop monitoring
    try:
        await orchestrator_task
    finally:
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
    
    print("\n🎯 Test Results:")
    print("✅ Successfully launched multiple agents via orchestrator")
    print("✅ Monitored agents in real-time using chat_search.py") 
    print("✅ Demonstrated agent-managed multi-agent coordination")

if __name__ == "__main__":
    asyncio.run(main())