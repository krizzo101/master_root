#!/usr/bin/env python3
"""Test parameter validation for orchestrator enhancements"""

import sys
import os
from pathlib import Path
import tempfile
import json

sys.path.insert(0, 'src')

from enhanced_orchestrator import EnhancedOrchestrator
from generic_orchestrator import GenericOrchestrator
from unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig, FeatureFlag

# Provide dummy tokens to satisfy TokenPool requirement
dummy_tokens = ["dummy-token-1", "dummy-token-2", "dummy-token-3"]

print("=== TESTING PARAMETER VALIDATION ===")

# Create temp directories for testing
test_dir = Path(tempfile.mkdtemp(prefix="orch_test_"))
print(f"Test directory: {test_dir}")

# Test 1: GenericOrchestrator with new parameters
print("\n1. Testing GenericOrchestrator with new parameters...")
try:
    go = GenericOrchestrator(
        output_dir=test_dir / "generic",
        max_parallel=5,
        tokens=dummy_tokens,
        use_optimizations=True,
        # New parameters
        master_mcp_registry_path=Path("master_mcp_registry.json"),
        agent_execution_profile="research",
        agent_debug_mode=True,
        agent_base_work_dir=test_dir / "agent_workspaces",
        enable_dynamic_configs=True,
        log_to_work_dir=True
    )
    print("✓ GenericOrchestrator with all new parameters: SUCCESS")
    print(f"  - master_mcp_registry_path: {go.master_mcp_registry_path}")
    print(f"  - agent_execution_profile: {go.agent_execution_profile}")
    print(f"  - agent_debug_mode: {go.agent_debug_mode}")
    print(f"  - agent_base_work_dir: {go.agent_base_work_dir}")
    print(f"  - enable_dynamic_configs: {go.enable_dynamic_configs}")
    print(f"  - log_to_work_dir: {go.log_to_work_dir}")
except Exception as e:
    print(f"✗ GenericOrchestrator failed: {e}")

# Test 2: EnhancedOrchestrator with new parameters
print("\n2. Testing EnhancedOrchestrator with new parameters...")
try:
    eo = EnhancedOrchestrator(
        output_dir=test_dir / "enhanced",
        max_parallel=5,
        tokens=dummy_tokens,
        use_optimizations=True,
        # Enhanced features
        enable_quality_gates=True,
        enable_monitoring=True,
        # New parameters
        master_mcp_registry_path=Path("master_mcp_registry.json"),
        agent_execution_profile="full",
        agent_debug_mode=True,
        agent_base_work_dir=test_dir / "agent_workspaces",
        enable_dynamic_configs=True,
        log_to_work_dir=True
    )
    print("✓ EnhancedOrchestrator with all new parameters: SUCCESS")
    print(f"  - master_mcp_registry_path: {eo.master_mcp_registry_path}")
    print(f"  - agent_execution_profile: {eo.agent_execution_profile}")
    print(f"  - agent_debug_mode: {eo.agent_debug_mode}")
except Exception as e:
    print(f"✗ EnhancedOrchestrator failed: {e}")

# Test 3: UnifiedOrchestrator with new parameters
print("\n3. Testing UnifiedOrchestrator with new parameters...")
try:
    config = UnifiedConfig(
        output_dir=test_dir / "unified",
        max_parallel=5,
        tokens=dummy_tokens,
        use_optimizations=True,
        enabled_features=[FeatureFlag.QUALITY_GATES],
        # New parameters
        master_mcp_registry_path=Path("master_mcp_registry.json"),
        agent_execution_profile="minimal",
        agent_debug_mode=True,
        agent_base_work_dir=test_dir / "agent_workspaces",
        enable_dynamic_configs=True,
        log_to_work_dir=True
    )
    uo = UnifiedOrchestrator(config)
    print("✓ UnifiedOrchestrator with all new parameters: SUCCESS")
    print(f"  - master_mcp_registry_path: {uo.master_mcp_registry_path}")
    print(f"  - agent_execution_profile: {uo.agent_execution_profile}")
    print(f"  - agent_debug_mode: {uo.agent_debug_mode}")
except Exception as e:
    print(f"✗ UnifiedOrchestrator failed: {e}")

# Test 4: Backward compatibility - minimal parameters
print("\n4. Testing backward compatibility (minimal parameters)...")
try:
    go_min = GenericOrchestrator(
        output_dir=test_dir / "minimal",
        tokens=dummy_tokens
    )
    print("✓ GenericOrchestrator with minimal parameters: SUCCESS")
    print(f"  - Default master_mcp_registry_path: {go_min.master_mcp_registry_path}")
    print(f"  - Default agent_execution_profile: {go_min.agent_execution_profile}")
    print(f"  - Default agent_debug_mode: {go_min.agent_debug_mode}")
    print(f"  - Default agent_base_work_dir: {go_min.agent_base_work_dir}")
    print(f"  - Default enable_dynamic_configs: {go_min.enable_dynamic_configs}")
    print(f"  - Default log_to_work_dir: {go_min.log_to_work_dir}")
except Exception as e:
    print(f"✗ Backward compatibility failed: {e}")

# Test 5: Parameter defaults work correctly
print("\n5. Testing parameter defaults...")
try:
    eo_defaults = EnhancedOrchestrator(
        output_dir=test_dir / "defaults",
        tokens=dummy_tokens
    )
    # Check defaults
    assert eo_defaults.agent_execution_profile == "standard", "Wrong default profile"
    assert eo_defaults.agent_debug_mode == False, "Wrong default debug mode"
    assert eo_defaults.enable_dynamic_configs == False, "Wrong default dynamic configs"
    assert eo_defaults.log_to_work_dir == False, "Wrong default log_to_work_dir"
    print("✓ All parameter defaults are correct")
except AssertionError as e:
    print(f"✗ Default validation failed: {e}")
except Exception as e:
    print(f"✗ Defaults test failed: {e}")

print("\n=== PARAMETER VALIDATION COMPLETE ===")