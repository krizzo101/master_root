#!/usr/bin/env python3
"""
Comprehensive test suite for UnifiedOrchestrator module loading and functionality
"""

import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime
import tempfile

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from src.unified.unified_orchestrator import (
    UnifiedOrchestrator,
    UnifiedConfig,
    FeatureFlag,
    EnhancedAgentTask,
    create_minimal_orchestrator,
    create_standard_orchestrator,
    create_advanced_orchestrator
)


class TestResults:
    """Track test results"""
    def __init__(self):
        self.passed = []
        self.failed = []
        self.issues = []
        
    def add_pass(self, test_name, details=""):
        self.passed.append({"test": test_name, "details": details})
        print(f"✓ {test_name}")
        
    def add_fail(self, test_name, error):
        self.failed.append({"test": test_name, "error": str(error)})
        print(f"✗ {test_name}: {error}")
        
    def add_issue(self, issue_description, details):
        self.issues.append({"issue": issue_description, "details": details})
        
    def get_summary(self):
        return {
            "total_tests": len(self.passed) + len(self.failed),
            "passed": len(self.passed),
            "failed": len(self.failed),
            "issues_found": len(self.issues),
            "pass_rate": f"{len(self.passed) / (len(self.passed) + len(self.failed)) * 100:.1f}%" if (self.passed or self.failed) else "N/A",
            "passed_tests": self.passed,
            "failed_tests": self.failed,
            "issues": self.issues
        }


async def test_module_loading(results: TestResults):
    """Test 1: Module Loading - Verify all modules load without import errors"""
    print("\n=== TEST 1: MODULE LOADING ===")
    
    try:
        # Test with all features enabled
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_modules_")),
            enabled_features={
                FeatureFlag.QUALITY_GATES,
                FeatureFlag.AGENT_MONITORING,
                FeatureFlag.COLLABORATION,
                FeatureFlag.EXECUTION_PLAN,
                FeatureFlag.ENHANCED_METRICS,
                FeatureFlag.BACKGROUND_EXECUTION,
                FeatureFlag.AUTO_RECOVERY,
                FeatureFlag.STATE_PERSISTENCE
            },
            enable_collaboration=True,
            enable_quality_gates=True,
            enable_monitoring=True,
            enable_auto_recovery=True,
            enable_state_persistence=True
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(2)  # Allow async module loading
        
        loaded_modules = orchestrator.module_registry.list_modules()
        
        expected_modules = ['quality_gates', 'monitoring', 'collaboration', 'execution_plan']
        for module in expected_modules:
            if module in loaded_modules:
                results.add_pass(f"Module loading: {module}")
            else:
                results.add_fail(f"Module loading: {module}", "Module not loaded")
        
        # Test module registry functionality
        for module_name in loaded_modules:
            module = orchestrator.module_registry.get_module(module_name)
            if module:
                results.add_pass(f"Module registry access: {module_name}")
            else:
                results.add_fail(f"Module registry access: {module_name}", "Module not accessible")
                
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Module loading test", str(e))
        results.add_issue("Critical module loading failure", str(e))


async def test_graceful_fallback(results: TestResults):
    """Test 2: Graceful Fallback - Test with no modules enabled"""
    print("\n=== TEST 2: GRACEFUL FALLBACK ===")
    
    try:
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_fallback_")),
            enabled_features=set()  # No features enabled
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(1)
        
        # Should work with no modules
        loaded_modules = orchestrator.module_registry.list_modules()
        if len(loaded_modules) == 0:
            results.add_pass("Graceful fallback with no modules")
        else:
            results.add_fail("Graceful fallback", f"Unexpected modules loaded: {loaded_modules}")
            
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Graceful fallback test", str(e))


async def test_task_execution(results: TestResults):
    """Test 3: Task Execution - Test enhanced task execution with modules"""
    print("\n=== TEST 3: TASK EXECUTION ===")
    
    try:
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_exec_")),
            enabled_features={
                FeatureFlag.QUALITY_GATES,
                FeatureFlag.ENHANCED_METRICS,
                FeatureFlag.AUTO_RECOVERY
            },
            enable_quality_gates=True,
            enable_auto_recovery=True,
            max_retries=2
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(2)
        
        # Create test task
        task = EnhancedAgentTask(
            task_id="test_task_1",
            task_type="analysis",
            prompt="Test analysis task",
            validation_required=True,
            priority=1
        )
        
        # Execute task (will fail due to no agent, but should handle gracefully)
        result = await orchestrator.execute_agent(task)
        
        if result:
            results.add_pass("Task execution with modules")
            
            # Check if quality gates were applied
            if hasattr(task, 'quality_gates'):
                results.add_pass("Quality gates applied to task")
            
            # Check enhanced metrics
            if orchestrator.enhanced_metrics.get('tasks_by_type'):
                results.add_pass("Enhanced metrics tracking")
        else:
            results.add_fail("Task execution", "No result returned")
            
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Task execution test", str(e))
        results.add_issue("Task execution failure", str(e))


async def test_module_interactions(results: TestResults):
    """Test 4: Module Interactions - Test cross-module functionality"""
    print("\n=== TEST 4: MODULE INTERACTIONS ===")
    
    try:
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_interact_")),
            enabled_features={
                FeatureFlag.EXECUTION_PLAN,
                FeatureFlag.QUALITY_GATES,
                FeatureFlag.COLLABORATION,
                FeatureFlag.AGENT_MONITORING
            },
            enable_collaboration=True,
            enable_quality_gates=True,
            enable_monitoring=True
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(2)
        
        # Test module status reporting
        module_status = orchestrator.module_registry.get_status()
        
        for module_name, status in module_status.items():
            if status.get('enabled'):
                results.add_pass(f"Module status: {module_name}")
            else:
                results.add_fail(f"Module status: {module_name}", "Module not enabled")
        
        # Test module metrics
        module_metrics = orchestrator.module_registry.get_metrics()
        if module_metrics:
            results.add_pass("Module metrics collection")
        
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Module interactions test", str(e))


async def test_factory_functions(results: TestResults):
    """Test 5: Factory Functions - Test orchestrator factory functions"""
    print("\n=== TEST 5: FACTORY FUNCTIONS ===")
    
    temp_dir = Path(tempfile.mkdtemp(prefix="test_factory_"))
    
    # Test minimal orchestrator
    try:
        minimal = create_minimal_orchestrator(temp_dir / "minimal")
        await asyncio.sleep(1)
        if len(minimal.config.enabled_features) == 0:
            results.add_pass("Minimal orchestrator creation")
        await minimal.cleanup()
    except Exception as e:
        results.add_fail("Minimal orchestrator", str(e))
    
    # Test standard orchestrator
    try:
        standard = create_standard_orchestrator(temp_dir / "standard")
        await asyncio.sleep(1)
        if FeatureFlag.ENHANCED_METRICS in standard.config.enabled_features:
            results.add_pass("Standard orchestrator creation")
        await standard.cleanup()
    except Exception as e:
        results.add_fail("Standard orchestrator", str(e))
    
    # Test advanced orchestrator
    try:
        advanced = create_advanced_orchestrator(temp_dir / "advanced")
        await asyncio.sleep(2)
        if len(advanced.config.enabled_features) == 8:  # All features
            results.add_pass("Advanced orchestrator creation")
        await advanced.cleanup()
    except Exception as e:
        results.add_fail("Advanced orchestrator", str(e))


async def test_state_persistence(results: TestResults):
    """Test 6: State Persistence - Test checkpoint save/load functionality"""
    print("\n=== TEST 6: STATE PERSISTENCE ===")
    
    try:
        temp_dir = Path(tempfile.mkdtemp(prefix="test_persist_"))
        config = UnifiedConfig(
            output_dir=temp_dir,
            enabled_features={FeatureFlag.STATE_PERSISTENCE},
            enable_state_persistence=True
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(1)
        
        # Create test tasks
        tasks = [
            EnhancedAgentTask(
                task_id=f"persist_task_{i}",
                task_type="test",
                prompt=f"Test task {i}"
            )
            for i in range(3)
        ]
        
        # Save checkpoint
        await orchestrator._save_checkpoint(tasks)
        
        # Check if checkpoint was saved
        checkpoints = list((temp_dir / "checkpoints").glob("*.json"))
        if checkpoints:
            results.add_pass("Checkpoint saving")
            
            # Test loading
            if await orchestrator.load_checkpoint(checkpoints[0]):
                results.add_pass("Checkpoint loading")
            else:
                results.add_fail("Checkpoint loading", "Failed to load checkpoint")
        else:
            results.add_fail("Checkpoint saving", "No checkpoint file created")
            
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("State persistence test", str(e))


async def test_background_jobs(results: TestResults):
    """Test 7: Background Jobs - Test background job management"""
    print("\n=== TEST 7: BACKGROUND JOBS ===")
    
    try:
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_bg_")),
            enabled_features={FeatureFlag.BACKGROUND_EXECUTION}
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(1)
        
        # Launch test background job
        async def test_job():
            await asyncio.sleep(1)
            return "completed"
        
        await orchestrator.launch_background_job("test_job_1", test_job())
        
        # Check job status
        status = await orchestrator.get_background_job_status("test_job_1")
        if status == "running":
            results.add_pass("Background job launch")
            
            # Wait for completion
            await asyncio.sleep(2)
            status = await orchestrator.get_background_job_status("test_job_1")
            if status == "completed":
                results.add_pass("Background job completion")
            else:
                results.add_fail("Background job completion", f"Status: {status}")
        else:
            results.add_fail("Background job launch", f"Initial status: {status}")
            
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Background jobs test", str(e))


async def test_performance(results: TestResults):
    """Test 8: Performance - Test module loading impact"""
    print("\n=== TEST 8: PERFORMANCE ===")
    
    import time
    
    try:
        # Time with no modules
        start = time.time()
        minimal = create_minimal_orchestrator(Path(tempfile.mkdtemp(prefix="perf_min_")))
        await asyncio.sleep(0.5)
        minimal_time = time.time() - start
        await minimal.cleanup()
        
        # Time with all modules
        start = time.time()
        advanced = create_advanced_orchestrator(Path(tempfile.mkdtemp(prefix="perf_adv_")))
        await asyncio.sleep(2)
        advanced_time = time.time() - start
        await advanced.cleanup()
        
        overhead = advanced_time - minimal_time
        results.add_pass(f"Performance test (overhead: {overhead:.2f}s)")
        
        if overhead > 5:
            results.add_issue("High module loading overhead", f"{overhead:.2f} seconds")
            
    except Exception as e:
        results.add_fail("Performance test", str(e))


async def test_error_handling(results: TestResults):
    """Test 9: Error Handling - Test module error recovery"""
    print("\n=== TEST 9: ERROR HANDLING ===")
    
    try:
        config = UnifiedConfig(
            output_dir=Path(tempfile.mkdtemp(prefix="test_error_")),
            enabled_features={FeatureFlag.AUTO_RECOVERY},
            enable_auto_recovery=True,
            max_retries=3
        )
        
        orchestrator = UnifiedOrchestrator(config)
        await asyncio.sleep(1)
        
        # Create task that will fail
        task = EnhancedAgentTask(
            task_id="error_task",
            task_type="invalid_type",  # This might trigger errors
            prompt="Test error handling"
        )
        
        # Should handle errors gracefully
        result = await orchestrator.execute_agent(task)
        if result:
            results.add_pass("Error handling in task execution")
        
        # Test invalid background job
        status = await orchestrator.get_background_job_status("non_existent_job")
        if status == "not_found":
            results.add_pass("Invalid job status handling")
        
        await orchestrator.cleanup()
        
    except Exception as e:
        results.add_fail("Error handling test", str(e))


async def main():
    """Run all tests and generate comprehensive report"""
    print("=" * 60)
    print("UNIFIED ORCHESTRATOR MODULE TESTING")
    print("=" * 60)
    
    results = TestResults()
    
    # Run all tests
    await test_module_loading(results)
    await test_graceful_fallback(results)
    await test_task_execution(results)
    await test_module_interactions(results)
    await test_factory_functions(results)
    await test_state_persistence(results)
    await test_background_jobs(results)
    await test_performance(results)
    await test_error_handling(results)
    
    # Generate report
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    summary = results.get_summary()
    print(f"Total Tests: {summary['total_tests']}")
    print(f"Passed: {summary['passed']}")
    print(f"Failed: {summary['failed']}")
    print(f"Pass Rate: {summary['pass_rate']}")
    print(f"Issues Found: {summary['issues_found']}")
    
    # Save detailed report
    report_path = Path("test_unified_modules_report.json")
    report_path.write_text(json.dumps(summary, indent=2))
    print(f"\nDetailed report saved to: {report_path}")
    
    # Print issues if any
    if summary['issues']:
        print("\n=== ISSUES DISCOVERED ===")
        for issue in summary['issues']:
            print(f"- {issue['issue']}: {issue['details']}")
    
    # Print failed tests
    if summary['failed_tests']:
        print("\n=== FAILED TESTS ===")
        for test in summary['failed_tests']:
            print(f"- {test['test']}: {test['error']}")
    
    return summary


if __name__ == "__main__":
    summary = asyncio.run(main())
    
    # Exit with appropriate code
    if summary['failed'] > 0:
        sys.exit(1)
    sys.exit(0)
