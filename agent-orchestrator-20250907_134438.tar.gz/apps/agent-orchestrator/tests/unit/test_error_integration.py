#!/usr/bin/env python3
"""
Integration test for error handling fixes
Tests with actual agent execution to verify error capture works in practice
"""

import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime

# Add the source directory to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import AgentTask, GenericOrchestrator


async def test_real_error_scenarios():
    """Test actual error scenarios that would produce empty errors before fix"""
    
    output_dir = Path(f"error_fix_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    output_dir.mkdir(exist_ok=True)
    
    print("=" * 60)
    print("ERROR HANDLING INTEGRATION TEST")
    print("=" * 60)
    print(f"\nOutput directory: {output_dir}")
    
    # Create orchestrator
    orchestrator = GenericOrchestrator(
        output_dir=output_dir,
        max_parallel=2,
        tokens=["test_token"]  # Will fail but that's ok for error testing
    )
    
    # Test scenarios that previously produced empty errors
    test_tasks = [
        # Empty prompt - should trigger CLI error
        AgentTask(
            task_id="empty_prompt_task",
            task_type="test",
            prompt="",  # Empty prompt
            context={"test": "empty_prompt"}
        ),
        
        # Invalid JSON response simulation
        AgentTask(
            task_id="invalid_json_task",
            task_type="test",
            prompt="Return plain text instead of JSON",
            context={"test": "invalid_json"}
        ),
        
        # Task that will fail with no stderr
        AgentTask(
            task_id="silent_fail_task",
            task_type="test",
            prompt="Task that fails silently",
            context={"force_fail": True}
        ),
        
        # Normal task to test mixed scenarios
        AgentTask(
            task_id="normal_task",
            task_type="test",
            prompt="Simple test task",
            context={"test": "normal"}
        ),
    ]
    
    # Execute tasks
    print("\nExecuting test tasks...")
    run_result = await orchestrator.run(lambda: test_tasks)
    
    print("\n" + "=" * 60)
    print("RESULTS ANALYSIS")
    print("=" * 60)
    
    empty_errors = []
    good_errors = []
    completed = []
    
    # Extract results from the run output
    results = run_result.get("results", [])
    
    for result in results:
        task_id = result.get("task_id", "unknown")
        status = result.get("status", "unknown")
        error = result.get("error", "")
        
        print(f"\nTask: {task_id}")
        print(f"Status: {status}")
        
        if status == "failed":
            if not error or len(error.strip()) == 0:
                empty_errors.append(task_id)
                print(f"❌ EMPTY ERROR STRING!")
            else:
                good_errors.append(task_id)
                print(f"✓ Error captured ({len(error)} chars): {error[:100]}...")
                
                # Check for error details
                if "error_details" in result and result["error_details"]:
                    print(f"  Error details available: {list(result['error_details'].keys())}")
        else:
            completed.append(task_id)
            print(f"✓ Task completed")
    
    # Verify JSON files written correctly
    print("\n" + "=" * 60)
    print("FILE VERIFICATION")
    print("=" * 60)
    
    task_files = list((output_dir / "tasks").glob("*.json"))
    print(f"\nTask files created: {len(task_files)}")
    
    for task_file in task_files:
        try:
            with open(task_file) as f:
                data = json.load(f)
                if data.get("status") == "failed":
                    error = data.get("error", "")
                    if not error:
                        print(f"❌ Empty error in file: {task_file.name}")
                    else:
                        print(f"✓ Error in file {task_file.name}: {len(error)} chars")
        except Exception as e:
            print(f"❌ Error reading {task_file.name}: {e}")
    
    # Final summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    
    print(f"\nTotal tasks: {len(test_tasks)}")
    print(f"Completed: {len(completed)}")
    print(f"Failed with good errors: {len(good_errors)}")
    print(f"Failed with EMPTY errors: {len(empty_errors)}")
    
    if empty_errors:
        print("\n❌ FIX FAILED - Empty errors detected:")
        for task_id in empty_errors:
            print(f"  - {task_id}")
        return False
    else:
        print("\n✓ FIX SUCCESSFUL - All errors properly captured!")
        return True


async def check_validation_output():
    """Check if previous validation outputs still have empty errors"""
    
    print("\n" + "=" * 60)
    print("CHECKING PREVIOUS VALIDATION OUTPUT")
    print("=" * 60)
    
    validation_dir = Path("/home/opsvi/master_root/apps/agent-orchestrator/unified_orchestrator_validation_20250906_220122")
    
    if not validation_dir.exists():
        print(f"Validation directory not found: {validation_dir}")
        return
    
    # Find all JSON files with empty errors
    empty_error_files = []
    
    for json_file in validation_dir.rglob("*.json"):
        try:
            with open(json_file) as f:
                content = f.read()
                if '"error": ""' in content or '"error": " "' in content:
                    empty_error_files.append(json_file.relative_to(validation_dir))
        except:
            pass
    
    if empty_error_files:
        print(f"\nFound {len(empty_error_files)} files with empty errors in previous validation:")
        for f in empty_error_files[:5]:  # Show first 5
            print(f"  - {f}")
        if len(empty_error_files) > 5:
            print(f"  ... and {len(empty_error_files) - 5} more")
    else:
        print("\nNo empty errors found in previous validation output")


async def main():
    """Run all integration tests"""
    
    # Check previous validation output
    await check_validation_output()
    
    # Run integration test
    success = await test_real_error_scenarios()
    
    if success:
        print("\n" + "=" * 60)
        print("✓ ERROR HANDLING FIX INTEGRATION TEST PASSED")
        print("=" * 60)
        return 0
    else:
        print("\n" + "=" * 60)
        print("✗ ERROR HANDLING FIX INTEGRATION TEST FAILED")
        print("=" * 60)
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)