#!/usr/bin/env python3
"""Test script for the log parser module"""

from claude_monitor.orchestrator.log_parser import LogParser, LogEntry

def test_log_parser():
    """Test the log parser functionality"""
    print("Testing Claude Monitor Log Parser...")
    
    # Initialize parser with small buffer for testing
    parser = LogParser(buffer_size=5)
    
    # Test sample log lines
    test_lines = [
        '2024-09-04 10:15:30 session_id:abc123 user: Hello, how are you?',
        '2024-09-04 10:15:31 session_id:abc123 assistant: I am doing well, thank you for asking!',
        '2024-09-04 10:15:32 session_id:abc123 system: Processing request with 150 tokens',
        '2024-09-04 10:15:33 session_id:def456 user: What is the weather like?',
        '2024-09-04 10:15:34 session_id:def456 error: Failed to connect to weather service',
    ]
    
    print('Parsing test log lines...')
    entries = parser.parse_lines(test_lines)
    
    print(f'✓ Parsed {len(entries)} entries')
    print(f'✓ Active sessions: {parser.get_active_sessions()}')
    
    print("\nParsed entries:")
    for entry in entries:
        content_preview = entry.content[:50] + '...' if len(entry.content) > 50 else entry.content
        print(f'  [{entry.timestamp.strftime("%H:%M:%S")}] {entry.session_id} - {entry.message_type}: {content_preview}')
    
    # Test session summaries
    print("\nSession summaries:")
    for session_id in parser.get_active_sessions():
        summary = parser.get_session_summary(session_id)
        print(f'  {session_id}: {summary["entry_count"]} entries, types: {summary["message_types"]}')
    
    # Test rolling buffer with overflow
    print("\nTesting rolling buffer (max 5 entries)...")
    for i in range(10):
        parser.parse_line(f'2024-09-04 10:16:{i:02d} session_id:test user: Message {i}')
    
    recent = parser.get_recent_entries()
    print(f'✓ Buffer contains {len(recent)} entries (should be 5)')
    
    # Test session-specific buffer
    test_session_entries = parser.buffer.get_session_recent('test')
    print(f'✓ Test session has {len(test_session_entries)} entries')
    
    # Test new session creation
    new_session = parser.start_new_session()
    parser.parse_line(f'2024-09-04 10:17:00 session_id:{new_session} user: New session message')
    print(f'✓ Created new session: {new_session}')
    
    # Test export functionality
    print("\nTesting export functionality...")
    json_export = parser.export_session('abc123', 'json')
    txt_export = parser.export_session('abc123', 'txt')
    
    print(f'✓ JSON export length: {len(json_export)} chars')
    print(f'✓ TXT export length: {len(txt_export)} chars')
    
    print("\n✅ All log parser tests completed successfully!")
    return True

if __name__ == "__main__":
    test_log_parser()