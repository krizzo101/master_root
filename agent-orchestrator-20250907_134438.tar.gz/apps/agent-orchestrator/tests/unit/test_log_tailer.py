#!/usr/bin/env python3
"""
Comprehensive Unit Tests for Enhanced Multi-Agent Log Tailer
=============================================================

This test suite provides comprehensive coverage for all components of the
enhanced_swarm_log_tailer.py including:
- Core data classes
- Log parsing
- File monitoring
- Swarm detection algorithms
- Display management
- Performance benchmarks

Run with: pytest test_log_tailer.py -v --cov=enhanced_swarm_log_tailer --cov-report=html
"""

import asyncio
import json
import os
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional
from unittest.mock import Mock, MagicMock, patch, AsyncMock, mock_open
import pytest
from collections import deque

# Import the module to test
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enhanced_swarm_log_tailer import (
    # Configuration classes
    SystemConfig, SwarmConfig, VisualConfig, OutputConfig,
    # Data classes
    AgentInfo, LogEntry, LogEvent, SwarmGroup,
    # Core components
    ColorManager, LogParser, AsyncFileMonitor, DisplayManager,
    SimpleSwarmDetector, EnhancedSwarmLogTailer
)

# Try to import AdvancedSwarmDetector if available
try:
    from enhanced_swarm_log_tailer import AdvancedSwarmDetector
    ADVANCED_DETECTOR_AVAILABLE = True
except ImportError:
    ADVANCED_DETECTOR_AVAILABLE = False

# ============================================================================
# Test Fixtures
# ============================================================================

class LogFixtures:
    """Sample log data fixtures for testing"""
    
    @staticmethod
    def sample_jsonl_lines() -> List[str]:
        """Generate sample JSONL log lines"""
        return [
            '{"type": "human_message", "timestamp": "2025-09-07T10:00:00.000Z", "uuid": "uuid-1", "session_id": "session-1", "agent_id": "agent-1", "content": "User request"}',
            '{"type": "assistant_message", "timestamp": "2025-09-07T10:00:01.000Z", "uuid": "uuid-2", "session_id": "session-1", "agent_id": "agent-1", "content": "Assistant response"}',
            '{"type": "tool_use", "timestamp": "2025-09-07T10:00:02.000Z", "uuid": "uuid-3", "session_id": "session-2", "agent_id": "agent-2", "tool_use": {"name": "bash", "args": {"command": "ls"}}}',
            '{"type": "error", "timestamp": "2025-09-07T10:00:03.000Z", "uuid": "uuid-4", "session_id": "session-3", "agent_id": "agent-3", "content": "Error occurred", "error_code": 500}',
            '{"type": "swarm_event", "timestamp": "2025-09-07T10:00:04.000Z", "uuid": "uuid-5", "session_id": "session-4", "agent_id": "agent-4", "content": "Swarm detected"}',
        ]
    
    @staticmethod
    def malformed_jsonl_lines() -> List[str]:
        """Generate malformed JSONL lines for error testing"""
        return [
            '',  # Empty line
            '   ',  # Whitespace only
            'not json at all',  # Invalid JSON
            '{"incomplete": ',  # Incomplete JSON
            '{"type": "test"}',  # Missing required fields
            '{"type": "test", "timestamp": "invalid-date", "uuid": "1", "session_id": "s1", "agent_id": "a1"}',  # Invalid timestamp
        ]
    
    @staticmethod
    def burst_event_lines(num_agents: int = 5, burst_time: float = 0.5) -> List[str]:
        """Generate burst of events for swarm detection testing"""
        lines = []
        base_time = datetime.now()
        
        for i in range(num_agents):
            timestamp = base_time + timedelta(seconds=i * burst_time)
            line = {
                "type": "burst_event",
                "timestamp": timestamp.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                "uuid": f"burst-uuid-{i}",
                "session_id": f"burst-session-{i}",
                "agent_id": f"burst-agent-{i}",
                "content": f"Burst event {i}"
            }
            lines.append(json.dumps(line))
        
        return lines
    
    @staticmethod
    def create_temp_log_file(lines: List[str]) -> Path:
        """Create a temporary log file with given lines"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False) as f:
            for line in lines:
                f.write(line + '\n')
            return Path(f.name)

# ============================================================================
# Unit Tests for Core Data Classes
# ============================================================================

class TestDataClasses(unittest.TestCase):
    """Test core data classes"""
    
    def test_agent_info_creation(self):
        """Test AgentInfo creation and attributes"""
        agent = AgentInfo(
            agent_id="test-agent",
            session_id="test-session",
            project_path=Path("/test/path"),
            role="specialist",
            color="\033[38;5;39m",
            icon="●"
        )
        
        self.assertEqual(agent.agent_id, "test-agent")
        self.assertEqual(agent.session_id, "test-session")
        self.assertEqual(agent.project_path, Path("/test/path"))
        self.assertEqual(agent.role, "specialist")
        self.assertEqual(agent.color, "\033[38;5;39m")
        self.assertEqual(agent.icon, "●")
    
    def test_log_entry_creation(self):
        """Test LogEntry creation with all fields"""
        timestamp = datetime.now()
        entry = LogEntry(
            type="test_type",
            timestamp=timestamp,
            uuid="test-uuid",
            session_id="test-session",
            agent_id="test-agent",
            content="Test content",
            tool_use={"name": "test_tool"},
            metadata={"key": "value"}
        )
        
        self.assertEqual(entry.type, "test_type")
        self.assertEqual(entry.timestamp, timestamp)
        self.assertEqual(entry.uuid, "test-uuid")
        self.assertEqual(entry.content, "Test content")
        self.assertIsNotNone(entry.tool_use)
        self.assertEqual(entry.metadata["key"], "value")
    
    def test_log_event_comparison(self):
        """Test LogEvent comparison for priority queue"""
        agent = AgentInfo("agent1", "session1", Path("/test"))
        
        earlier = LogEntry("type1", datetime(2025, 1, 1, 10, 0, 0), "uuid1", "s1", "a1")
        later = LogEntry("type2", datetime(2025, 1, 1, 10, 0, 1), "uuid2", "s1", "a1")
        
        event1 = LogEvent(earlier, agent)
        event2 = LogEvent(later, agent)
        
        self.assertTrue(event1 < event2)
        self.assertFalse(event2 < event1)
    
    def test_swarm_group_creation(self):
        """Test SwarmGroup creation and attributes"""
        start_time = datetime.now()
        swarm = SwarmGroup(
            swarm_id="swarm-1",
            agents={"agent1", "agent2", "agent3"},
            start_time=start_time,
            icon="⚡",
            detection_method="dbscan",
            confidence=0.85
        )
        
        self.assertEqual(swarm.swarm_id, "swarm-1")
        self.assertEqual(len(swarm.agents), 3)
        self.assertIn("agent1", swarm.agents)
        self.assertEqual(swarm.start_time, start_time)
        self.assertEqual(swarm.confidence, 0.85)
        self.assertIsNone(swarm.end_time)

# ============================================================================
# Unit Tests for ColorManager
# ============================================================================

class TestColorManager(unittest.TestCase):
    """Test ColorManager functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.config = VisualConfig(use_color=True)
        self.manager = ColorManager(self.config)
    
    def test_color_assignment(self):
        """Test unique color assignment to agents"""
        async def test():
            color1 = await self.manager.assign_color("agent1")
            color2 = await self.manager.assign_color("agent2")
            color1_again = await self.manager.assign_color("agent1")
            
            # Different agents get different colors
            self.assertNotEqual(color1, color2)
            # Same agent gets same color
            self.assertEqual(color1, color1_again)
            # Colors are from palette
            self.assertIn(color1, self.manager.palette)
        
        asyncio.run(test())
    
    def test_no_color_mode(self):
        """Test behavior when color is disabled"""
        config = VisualConfig(use_color=False)
        manager = ColorManager(config)
        
        async def test():
            color = await manager.assign_color("agent1")
            self.assertEqual(color, "")
        
        asyncio.run(test())
    
    def test_format_with_color(self):
        """Test text formatting with colors"""
        async def test():
            await self.manager.assign_color("agent1")
            formatted = self.manager.format_with_color("Test text", "agent1", bold=True)
            
            # Check that formatting is applied
            self.assertIn("Test text", formatted)
            self.assertIn(self.manager.RESET, formatted)
            if self.manager.agent_colors.get("agent1"):
                self.assertIn(self.manager.BOLD, formatted)
        
        asyncio.run(test())
    
    def test_color_schemes(self):
        """Test different color schemes"""
        for scheme in ["default", "high_contrast", "colorblind"]:
            config = VisualConfig(use_color=True, color_scheme=scheme)
            manager = ColorManager(config)
            self.assertEqual(manager.palette, ColorManager.PALETTES[scheme])

# ============================================================================
# Unit Tests for LogParser
# ============================================================================

class TestLogParser(unittest.TestCase):
    """Test LogParser functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.parser = LogParser()
        self.fixtures = LogFixtures()
    
    def test_parse_valid_line(self):
        """Test parsing valid JSONL lines"""
        lines = self.fixtures.sample_jsonl_lines()
        
        # Test first line (human message)
        entry = self.parser.parse_line(lines[0])
        self.assertIsNotNone(entry)
        self.assertEqual(entry.type, "human_message")
        self.assertEqual(entry.content, "User request")
        self.assertEqual(entry.agent_id, "agent-1")
        
        # Test tool use line
        entry = self.parser.parse_line(lines[2])
        self.assertIsNotNone(entry)
        self.assertEqual(entry.type, "tool_use")
        self.assertIsNotNone(entry.tool_use)
        self.assertEqual(entry.tool_use["name"], "bash")
    
    def test_parse_invalid_lines(self):
        """Test parsing invalid/malformed lines"""
        lines = self.fixtures.malformed_jsonl_lines()
        
        for line in lines:
            entry = self.parser.parse_line(line)
            self.assertIsNone(entry)
    
    def test_timestamp_parsing(self):
        """Test various timestamp formats"""
        test_cases = [
            ("2025-09-07T10:00:00.000Z", datetime(2025, 9, 7, 10, 0, 0, 0)),
            ("2025-09-07T10:00:00Z", datetime(2025, 9, 7, 10, 0, 0)),
            ("2025-09-07 10:00:00.123", datetime(2025, 9, 7, 10, 0, 0, 123000)),
            ("2025-09-07 10:00:00", datetime(2025, 9, 7, 10, 0, 0)),
        ]
        
        for timestamp_str, expected in test_cases:
            result = self.parser._parse_timestamp(timestamp_str)
            self.assertIsNotNone(result)
            # Compare without microseconds for some formats
            self.assertEqual(
                result.replace(microsecond=0),
                expected.replace(microsecond=0)
            )
    
    def test_parse_line_with_metadata(self):
        """Test parsing lines with extra metadata fields"""
        line = '{"type": "test", "timestamp": "2025-09-07T10:00:00Z", "uuid": "1", "session_id": "s1", "agent_id": "a1", "extra_field": "value", "another": 123}'
        
        entry = self.parser.parse_line(line)
        self.assertIsNotNone(entry)
        self.assertEqual(entry.metadata["extra_field"], "value")
        self.assertEqual(entry.metadata["another"], 123)

# ============================================================================
# Unit Tests for AsyncFileMonitor
# ============================================================================

class TestAsyncFileMonitor(unittest.TestCase):
    """Test AsyncFileMonitor functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.config = SystemConfig(
            projects_dir=Path(tempfile.gettempdir()),
            pattern="*.jsonl",
            poll_interval_ms=10
        )
        self.monitor = AsyncFileMonitor(self.config)
        self.fixtures = LogFixtures()
    
    def tearDown(self):
        """Clean up test files"""
        # Clean up position file
        if self.monitor.position_file.exists():
            self.monitor.position_file.unlink()
    
    def test_discover_files(self):
        """Test file discovery"""
        async def test():
            # Create temp files
            temp_files = []
            for i in range(3):
                lines = self.fixtures.sample_jsonl_lines()
                temp_file = self.fixtures.create_temp_log_file(lines)
                temp_files.append(temp_file)
            
            try:
                # Discover files
                self.config.projects_dir = temp_files[0].parent
                files = await self.monitor.discover_files()
                
                # Check that files were discovered
                self.assertGreater(len(files), 0)
                for f in temp_files:
                    self.assertIn(f, files)
            
            finally:
                # Clean up
                for f in temp_files:
                    f.unlink()
        
        asyncio.run(test())
    
    def test_file_position_tracking(self):
        """Test that file positions are tracked correctly"""
        test_file = Path(tempfile.gettempdir()) / "test_position.jsonl"
        
        # Save position
        self.monitor.file_positions[test_file] = 12345
        self.monitor._save_positions()
        
        # Create new monitor and check position loaded
        new_monitor = AsyncFileMonitor(self.config)
        self.assertEqual(new_monitor.file_positions.get(test_file), 12345)
    
    def test_tail_file_basic(self):
        """Test basic file tailing"""
        async def test():
            # Create temp file with initial content
            lines = self.fixtures.sample_jsonl_lines()
            temp_file = self.fixtures.create_temp_log_file(lines[:2])
            
            try:
                # Start tailing
                tail_task = asyncio.create_task(self._collect_lines(temp_file, 2))
                
                # Give it time to read initial lines
                await asyncio.sleep(0.1)
                
                # Append more lines
                with open(temp_file, 'a') as f:
                    f.write(lines[2] + '\n')
                
                # Collect results
                collected = await tail_task
                
                # Should have all lines
                self.assertEqual(len(collected), 3)
            
            finally:
                temp_file.unlink()
        
        asyncio.run(test())
    
    async def _collect_lines(self, file_path: Path, expected_count: int) -> List[str]:
        """Helper to collect lines from tail"""
        collected = []
        async for line in self.monitor.tail_file(file_path):
            collected.append(line)
            if len(collected) >= expected_count:
                break
        return collected
    
    def test_file_truncation_handling(self):
        """Test handling of file truncation"""
        async def test():
            temp_file = Path(tempfile.gettempdir()) / "test_truncate.jsonl"
            
            try:
                # Write initial content
                with open(temp_file, 'w') as f:
                    f.write("Line 1\n" * 100)
                
                # Set position past end
                self.monitor.file_positions[temp_file] = 1000000
                
                # Read should reset position
                lines = self.monitor._read_lines(temp_file, 1000000)
                
                # Should read from beginning
                self.assertGreater(len(lines), 0)
            
            finally:
                if temp_file.exists():
                    temp_file.unlink()
        
        asyncio.run(test())

# ============================================================================
# Unit Tests for SimpleSwarmDetector
# ============================================================================

class TestSimpleSwarmDetector(unittest.TestCase):
    """Test SimpleSwarmDetector functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.config = SwarmConfig(
            enabled=True,
            time_window_seconds=300,
            min_agents=3
        )
        self.detector = SimpleSwarmDetector(self.config)
    
    def test_detect_swarm_basic(self):
        """Test basic swarm detection"""
        async def test():
            # Create burst events
            events = self._create_burst_events(5, 0.5)
            
            # Detect swarms
            swarms = await self.detector.detect_swarms(events)
            
            # Should detect at least one swarm
            self.assertGreater(len(swarms), 0)
            
            # Check swarm properties
            for swarm_id, swarm in swarms.items():
                self.assertGreaterEqual(len(swarm.agents), self.config.min_agents)
                self.assertEqual(swarm.detection_method, "time_window")
        
        asyncio.run(test())
    
    def test_no_swarm_with_few_agents(self):
        """Test that swarm is not detected with too few agents"""
        async def test():
            # Create events with only 2 agents (below threshold)
            events = self._create_burst_events(2, 0.5)
            
            # Detect swarms
            swarms = await self.detector.detect_swarms(events)
            
            # Should not detect any swarms
            self.assertEqual(len(swarms), 0)
        
        asyncio.run(test())
    
    def test_swarm_disabled(self):
        """Test behavior when swarm detection is disabled"""
        async def test():
            self.config.enabled = False
            detector = SimpleSwarmDetector(self.config)
            
            events = self._create_burst_events(10, 0.1)
            swarms = await detector.detect_swarms(events)
            
            self.assertEqual(len(swarms), 0)
        
        asyncio.run(test())
    
    def _create_burst_events(self, num_agents: int, interval: float) -> List[LogEvent]:
        """Helper to create burst events"""
        events = []
        base_time = datetime.now()
        
        for i in range(num_agents):
            timestamp = base_time + timedelta(seconds=i * interval)
            entry = LogEntry(
                type="burst",
                timestamp=timestamp,
                uuid=f"uuid-{i}",
                session_id=f"session-{i}",
                agent_id=f"agent-{i}",
                content=f"Event {i}"
            )
            agent = AgentInfo(
                agent_id=f"agent-{i}",
                session_id=f"session-{i}",
                project_path=Path("/test")
            )
            events.append(LogEvent(entry, agent))
        
        return events

# ============================================================================
# Unit Tests for AdvancedSwarmDetector (if available)
# ============================================================================

@pytest.mark.skipif(not ADVANCED_DETECTOR_AVAILABLE, reason="Scientific libraries not available")
class TestAdvancedSwarmDetector(unittest.TestCase):
    """Test AdvancedSwarmDetector functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.config = SwarmConfig(
            enabled=True,
            time_window_seconds=300,
            min_agents=3,
            temporal_epsilon=5.0
        )
        self.detector = AdvancedSwarmDetector(self.config)
    
    def test_dbscan_clustering(self):
        """Test DBSCAN-based swarm detection"""
        async def test():
            # Create clustered events
            events = []
            base_time = datetime.now()
            
            # Cluster 1: tight temporal cluster
            for i in range(5):
                timestamp = base_time + timedelta(seconds=i * 0.1)
                events.append(self._create_event(f"cluster1-{i}", timestamp))
            
            # Cluster 2: another tight cluster after gap
            for i in range(4):
                timestamp = base_time + timedelta(seconds=10 + i * 0.1)
                events.append(self._create_event(f"cluster2-{i}", timestamp))
            
            # Outlier events
            for i in range(2):
                timestamp = base_time + timedelta(seconds=30 + i * 20)
                events.append(self._create_event(f"outlier-{i}", timestamp))
            
            # Detect swarms
            swarms = await self.detector.detect_swarms(events)
            
            # Should detect clusters
            self.assertGreater(len(swarms), 0)
            
            # Verify detection method
            for swarm in swarms.values():
                self.assertEqual(swarm.detection_method, "dbscan")
                self.assertGreater(swarm.confidence, 0.7)
        
        asyncio.run(test())
    
    def test_swarm_icon_assignment(self):
        """Test icon assignment based on swarm size"""
        test_cases = [
            (2, "→"),     # Pipeline
            (4, "⚡"),     # Burst
            (7, "⫽"),     # Parallel
            (15, "🔺"),   # Hierarchical
        ]
        
        for size, expected_icon in test_cases:
            icon = self.detector._get_swarm_icon(size)
            self.assertEqual(icon, expected_icon)
    
    def test_event_buffer_limit(self):
        """Test that event buffer respects maxlen"""
        # Add many events
        for i in range(15000):
            event = self._create_event(f"agent-{i}", datetime.now())
            self.detector.event_buffer.append(event)
        
        # Buffer should not exceed maxlen
        self.assertLessEqual(len(self.detector.event_buffer), 10000)
    
    def _create_event(self, agent_id: str, timestamp: datetime) -> LogEvent:
        """Helper to create a single event"""
        entry = LogEntry(
            type="test",
            timestamp=timestamp,
            uuid=f"uuid-{agent_id}",
            session_id=f"session-{agent_id}",
            agent_id=agent_id,
            content="Test event"
        )
        agent = AgentInfo(
            agent_id=agent_id,
            session_id=f"session-{agent_id}",
            project_path=Path("/test")
        )
        return LogEvent(entry, agent)

# ============================================================================
# Unit Tests for DisplayManager
# ============================================================================

class TestDisplayManager(unittest.TestCase):
    """Test DisplayManager functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.visual_config = VisualConfig(use_color=True, use_emoji=True)
        self.color_manager = ColorManager(self.visual_config)
        self.display_manager = DisplayManager(self.color_manager, self.visual_config)
    
    @patch('builtins.print')
    def test_display_event(self, mock_print):
        """Test event display"""
        async def test():
            # Create test event
            entry = LogEntry(
                type="test",
                timestamp=datetime.now(),
                uuid="test-uuid",
                session_id="test-session",
                agent_id="test-agent",
                content="Test content"
            )
            agent = AgentInfo(
                agent_id="test-agent",
                session_id="test-session",
                project_path=Path("/test")
            )
            event = LogEvent(entry, agent)
            
            # Display event
            await self.display_manager.display_event(event)
            await self.display_manager.flush_buffer()
            
            # Check that print was called
            mock_print.assert_called()
            output = mock_print.call_args[0][0]
            self.assertIn("test-agent", output)
            self.assertIn("Test content", output)
        
        asyncio.run(test())
    
    def test_content_truncation(self):
        """Test content truncation"""
        async def test():
            self.visual_config.truncate_content = True
            self.visual_config.max_content_length = 10
            
            # Create event with long content
            long_content = "A" * 100
            entry = LogEntry(
                type="test",
                timestamp=datetime.now(),
                uuid="test-uuid",
                session_id="test-session",
                agent_id="test-agent",
                content=long_content
            )
            agent = AgentInfo(
                agent_id="test-agent",
                session_id="test-session",
                project_path=Path("/test")
            )
            event = LogEvent(entry, agent)
            
            # Format event
            formatted = await self.display_manager.format_event(event)
            
            # Check truncation
            self.assertIn("...", formatted)
            self.assertLess(len(formatted), len(long_content) + 50)  # Allow for timestamp etc
        
        asyncio.run(test())
    
    def test_buffer_flushing(self):
        """Test buffer management and flushing"""
        async def test():
            # Add events to buffer
            for i in range(15):
                self.display_manager.buffer.append(f"Line {i}")
            
            # Buffer should trigger flush at 10+ items
            with patch('builtins.print') as mock_print:
                await self.display_manager.flush_buffer()
                
                # Check that all lines were printed
                mock_print.assert_called_once()
                output = mock_print.call_args[0][0]
                for i in range(15):
                    self.assertIn(f"Line {i}", output)
            
            # Buffer should be empty after flush
            self.assertEqual(len(self.display_manager.buffer), 0)
        
        asyncio.run(test())

# ============================================================================
# Integration Tests for EnhancedSwarmLogTailer
# ============================================================================

class TestEnhancedSwarmLogTailer(unittest.TestCase):
    """Integration tests for the main controller"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.system_config = SystemConfig(
            projects_dir=self.temp_dir,
            pattern="*.jsonl",
            poll_interval_ms=10
        )
        self.swarm_config = SwarmConfig(enabled=True)
        self.visual_config = VisualConfig(use_color=False)  # Disable for testing
        self.output_config = OutputConfig(quiet=True)
        
        self.tailer = EnhancedSwarmLogTailer(
            self.system_config,
            self.swarm_config,
            self.visual_config,
            self.output_config
        )
    
    def tearDown(self):
        """Clean up test files"""
        import shutil
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
    
    def test_initialization(self):
        """Test tailer initialization"""
        self.assertIsNotNone(self.tailer.file_monitor)
        self.assertIsNotNone(self.tailer.color_manager)
        self.assertIsNotNone(self.tailer.display_manager)
        self.assertIsNotNone(self.tailer.parser)
        self.assertIsNotNone(self.tailer.swarm_detector)
        self.assertFalse(self.tailer.running)
    
    def test_extract_agent_id(self):
        """Test agent ID extraction from file path"""
        test_cases = [
            (Path("/logs/session_2025_09_07_agent123.jsonl"), "agent123"),
            (Path("/logs/simple.jsonl"), None),  # Falls back to hash
            (Path("/logs/test_file.jsonl"), None),
        ]
        
        for path, expected_suffix in test_cases:
            agent_id = self.tailer._extract_agent_id(path)
            self.assertIsNotNone(agent_id)
            if expected_suffix:
                self.assertTrue(agent_id.endswith(expected_suffix))
            else:
                self.assertTrue(agent_id.startswith("agent_"))
    
    def test_extract_project_path(self):
        """Test project path extraction"""
        test_cases = [
            (Path("/home/user/.claude/projects/proj1/logs/file.jsonl"), Path("/home/user/.claude")),
            (Path("/home/user/projects/proj2/file.jsonl"), Path("/home/user")),
            (Path("/tmp/file.jsonl"), Path("/tmp")),
        ]
        
        for file_path, expected_parent in test_cases:
            project_path = self.tailer._extract_project_path(file_path)
            self.assertIsNotNone(project_path)
    
    @patch('builtins.print')
    def test_startup_banner(self, mock_print):
        """Test startup banner display"""
        self.tailer._print_startup_banner()
        
        # Check that banner was printed
        mock_print.assert_called()
        calls = [call[0][0] for call in mock_print.call_args_list]
        output = '\n'.join(calls)
        
        self.assertIn("Enhanced Multi-Agent Log Tailer", output)
        self.assertIn("Version", output)
        self.assertIn(str(self.system_config.projects_dir), output)
    
    def test_statistics_tracking(self):
        """Test statistics collection"""
        async def test():
            # Set some statistics
            self.tailer.statistics['files_monitored'] = 5
            self.tailer.statistics['events_processed'] = 100
            self.tailer.statistics['swarms_detected'] = 3
            self.tailer.statistics['start_time'] = datetime.now() - timedelta(seconds=10)
            
            with patch('builtins.print') as mock_print:
                self.tailer._print_statistics()
                
                # Check statistics output
                calls = [call[0][0] for call in mock_print.call_args_list]
                output = '\n'.join(calls)
                
                self.assertIn("Files Monitored: 5", output)
                self.assertIn("Events Processed: 100", output)
                self.assertIn("Swarms Detected: 3", output)
                self.assertIn("Processing Rate:", output)
        
        asyncio.run(test())

# ============================================================================
# Performance Benchmarks
# ============================================================================

class TestPerformanceBenchmarks(unittest.TestCase):
    """Performance benchmarks for critical components"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.parser = LogParser()
        self.fixtures = LogFixtures()
    
    def test_parsing_performance(self):
        """Benchmark log parsing performance"""
        lines = self.fixtures.sample_jsonl_lines() * 1000  # 5000 lines
        
        start_time = time.perf_counter()
        for line in lines:
            entry = self.parser.parse_line(line)
        end_time = time.perf_counter()
        
        elapsed = end_time - start_time
        lines_per_second = len(lines) / elapsed
        
        print(f"\nParsing Performance: {lines_per_second:.0f} lines/second")
        print(f"Time for {len(lines)} lines: {elapsed:.3f} seconds")
        
        # Assert minimum performance threshold
        self.assertGreater(lines_per_second, 1000, "Parsing too slow")
    
    def test_swarm_detection_performance(self):
        """Benchmark swarm detection performance"""
        async def test():
            config = SwarmConfig(enabled=True, min_agents=3)
            detector = SimpleSwarmDetector(config)
            
            # Create large event set
            events = []
            for i in range(1000):
                timestamp = datetime.now() + timedelta(seconds=i * 0.1)
                entry = LogEntry(
                    type="test",
                    timestamp=timestamp,
                    uuid=f"uuid-{i}",
                    session_id=f"session-{i}",
                    agent_id=f"agent-{i % 20}",  # 20 unique agents
                    content=f"Event {i}"
                )
                agent = AgentInfo(
                    agent_id=f"agent-{i % 20}",
                    session_id=f"session-{i}",
                    project_path=Path("/test")
                )
                events.append(LogEvent(entry, agent))
            
            start_time = time.perf_counter()
            swarms = await detector.detect_swarms(events)
            end_time = time.perf_counter()
            
            elapsed = end_time - start_time
            events_per_second = len(events) / elapsed
            
            print(f"\nSwarm Detection Performance: {events_per_second:.0f} events/second")
            print(f"Time for {len(events)} events: {elapsed:.3f} seconds")
            print(f"Swarms detected: {len(swarms)}")
            
            # Assert performance threshold
            self.assertLess(elapsed, 1.0, "Swarm detection too slow")
        
        asyncio.run(test())
    
    def test_color_assignment_performance(self):
        """Benchmark color assignment performance"""
        async def test():
            config = VisualConfig(use_color=True)
            manager = ColorManager(config)
            
            num_agents = 1000
            
            start_time = time.perf_counter()
            for i in range(num_agents):
                await manager.assign_color(f"agent-{i}")
            end_time = time.perf_counter()
            
            elapsed = end_time - start_time
            assignments_per_second = num_agents / elapsed
            
            print(f"\nColor Assignment Performance: {assignments_per_second:.0f} assignments/second")
            print(f"Time for {num_agents} agents: {elapsed:.3f} seconds")
            
            # Assert performance threshold
            self.assertGreater(assignments_per_second, 1000, "Color assignment too slow")
        
        asyncio.run(test())
    
    def test_file_monitoring_performance(self):
        """Benchmark file monitoring performance"""
        async def test():
            config = SystemConfig(poll_interval_ms=1)
            monitor = AsyncFileMonitor(config)
            
            # Create test file with many lines
            temp_file = Path(tempfile.gettempdir()) / "perf_test.jsonl"
            num_lines = 10000
            
            try:
                # Write test data
                with open(temp_file, 'w') as f:
                    for i in range(num_lines):
                        f.write(f"Line {i}\n")
                
                start_time = time.perf_counter()
                lines = monitor._read_lines(temp_file, 0)
                end_time = time.perf_counter()
                
                elapsed = end_time - start_time
                lines_per_second = len(lines) / elapsed if elapsed > 0 else 0
                
                print(f"\nFile Reading Performance: {lines_per_second:.0f} lines/second")
                print(f"Time for {len(lines)} lines: {elapsed:.3f} seconds")
                
                # Assert performance threshold
                self.assertGreater(lines_per_second, 10000, "File reading too slow")
            
            finally:
                if temp_file.exists():
                    temp_file.unlink()
        
        asyncio.run(test())

# ============================================================================
# Error Handling and Edge Cases
# ============================================================================

class TestErrorHandlingAndEdgeCases(unittest.TestCase):
    """Test error handling and edge cases"""
    
    def test_empty_log_file(self):
        """Test handling of empty log files"""
        parser = LogParser()
        
        # Empty string
        self.assertIsNone(parser.parse_line(""))
        
        # Whitespace only
        self.assertIsNone(parser.parse_line("   \n\t  "))
    
    def test_corrupted_json(self):
        """Test handling of corrupted JSON"""
        parser = LogParser()
        
        test_cases = [
            '{"broken": "json"',
            '}{invalid',
            'null',
            '[]',
            '{"nested": {"broken": }}'
        ]
        
        for case in test_cases:
            result = parser.parse_line(case)
            self.assertIsNone(result, f"Should handle corrupted JSON: {case}")
    
    def test_missing_required_fields(self):
        """Test handling of missing required fields"""
        parser = LogParser()
        
        # Missing timestamp
        line = '{"type": "test", "uuid": "1", "session_id": "s1", "agent_id": "a1"}'
        entry = parser.parse_line(line)
        self.assertIsNotNone(entry)  # Should use current time as fallback
        
        # Missing type
        line = '{"timestamp": "2025-09-07T10:00:00Z", "uuid": "1", "session_id": "s1", "agent_id": "a1"}'
        entry = parser.parse_line(line)
        self.assertIsNotNone(entry)
        self.assertEqual(entry.type, "unknown")
    
    def test_unicode_handling(self):
        """Test handling of Unicode characters"""
        parser = LogParser()
        
        # Unicode content
        line = '{"type": "test", "timestamp": "2025-09-07T10:00:00Z", "uuid": "1", "session_id": "s1", "agent_id": "a1", "content": "Hello 世界 🌍 émojis"}'
        entry = parser.parse_line(line)
        
        self.assertIsNotNone(entry)
        self.assertIn("世界", entry.content)
        self.assertIn("🌍", entry.content)
        self.assertIn("émojis", entry.content)
    
    def test_large_log_entry(self):
        """Test handling of very large log entries"""
        parser = LogParser()
        
        # Create large content
        large_content = "A" * 1000000  # 1MB of data
        line = json.dumps({
            "type": "test",
            "timestamp": "2025-09-07T10:00:00Z",
            "uuid": "1",
            "session_id": "s1",
            "agent_id": "a1",
            "content": large_content
        })
        
        entry = parser.parse_line(line)
        self.assertIsNotNone(entry)
        self.assertEqual(len(entry.content), 1000000)
    
    def test_concurrent_file_access(self):
        """Test handling of concurrent file access"""
        async def test():
            config = SystemConfig(poll_interval_ms=1)
            monitor = AsyncFileMonitor(config)
            
            temp_file = Path(tempfile.gettempdir()) / "concurrent_test.jsonl"
            
            try:
                # Create file
                with open(temp_file, 'w') as f:
                    f.write("Initial line\n")
                
                # Start multiple tail operations
                tasks = []
                for _ in range(5):
                    task = asyncio.create_task(self._tail_limited(monitor, temp_file, 1))
                    tasks.append(task)
                
                # Let them run briefly
                await asyncio.sleep(0.1)
                
                # Cancel all tasks
                for task in tasks:
                    task.cancel()
                
                # Wait for cleanup
                await asyncio.gather(*tasks, return_exceptions=True)
                
                # Should complete without errors
                self.assertTrue(True)
            
            finally:
                if temp_file.exists():
                    temp_file.unlink()
        
        asyncio.run(test())
    
    async def _tail_limited(self, monitor, file_path, max_lines):
        """Helper to tail limited lines"""
        count = 0
        async for line in monitor.tail_file(file_path):
            count += 1
            if count >= max_lines:
                break
    
    def test_file_deletion_during_monitoring(self):
        """Test handling of file deletion during monitoring"""
        async def test():
            config = SystemConfig(poll_interval_ms=10)
            monitor = AsyncFileMonitor(config)
            
            temp_file = Path(tempfile.gettempdir()) / "delete_test.jsonl"
            
            try:
                # Create file
                with open(temp_file, 'w') as f:
                    f.write("Line 1\n")
                
                # Start tailing
                tail_task = asyncio.create_task(self._tail_with_timeout(monitor, temp_file, 0.5))
                
                # Delete file while monitoring
                await asyncio.sleep(0.1)
                temp_file.unlink()
                
                # Should handle gracefully
                result = await tail_task
                self.assertIsNotNone(result)
            
            except FileNotFoundError:
                # Expected - file was deleted
                pass
            finally:
                if temp_file.exists():
                    temp_file.unlink()
        
        asyncio.run(test())
    
    async def _tail_with_timeout(self, monitor, file_path, timeout):
        """Helper to tail with timeout"""
        lines = []
        try:
            async for line in monitor.tail_file(file_path):
                lines.append(line)
                if time.time() > time.time() + timeout:
                    break
        except Exception:
            pass
        return lines

# ============================================================================
# Test Runner and Coverage
# ============================================================================

def run_tests_with_coverage():
    """Run tests with coverage reporting"""
    import coverage
    
    # Start coverage
    cov = coverage.Coverage()
    cov.start()
    
    # Run tests
    loader = unittest.TestLoader()
    suite = loader.discover('.', pattern='test_*.py')
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Stop coverage
    cov.stop()
    cov.save()
    
    # Generate report
    print("\n" + "="*70)
    print("COVERAGE REPORT")
    print("="*70)
    cov.report(include=["enhanced_swarm_log_tailer.py"])
    
    # Generate HTML report
    cov.html_report(directory="htmlcov", include=["enhanced_swarm_log_tailer.py"])
    print("\nDetailed HTML report generated in htmlcov/index.html")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    # Check if coverage is requested
    if "--coverage" in sys.argv:
        sys.argv.remove("--coverage")
        success = run_tests_with_coverage()
        sys.exit(0 if success else 1)
    else:
        # Run normally
        unittest.main(verbosity=2)