#!/usr/bin/env python3
"""Test dynamic architecture features"""

import sys
import os
from pathlib import Path
import tempfile
import json
import asyncio

sys.path.insert(0, 'src')

from enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask

# Provide dummy tokens
dummy_tokens = ["dummy-token-1", "dummy-token-2", "dummy-token-3"]

print("=== TESTING DYNAMIC ARCHITECTURE FEATURES ===")

# Create temp directory for testing
test_dir = Path(tempfile.mkdtemp(prefix="arch_test_"))
print(f"Test directory: {test_dir}")

# Test 1: Working directory creation with dynamic configs
print("\n1. Testing working directory creation...")
try:
    orchestrator = EnhancedOrchestrator(
        output_dir=test_dir / "orchestrator",
        tokens=dummy_tokens,
        agent_base_work_dir=test_dir / "agent_workspaces",
        enable_dynamic_configs=True,
        log_to_work_dir=True
    )
    
    # Check if agent workspace directory was created
    if orchestrator.agent_base_work_dir.exists():
        print(f"✓ Agent base work directory created: {orchestrator.agent_base_work_dir}")
    else:
        print(f"✗ Agent base work directory not created")
        
    # Check if log directory setup works  
    log_dir = orchestrator.output_dir / "logs"
    if log_dir.exists():
        print(f"✓ Log directory created: {log_dir}")
    else:
        print(f"✗ Log directory not created")
        
except Exception as e:
    print(f"✗ Working directory test failed: {e}")

# Test 2: Agent-specific working directories
print("\n2. Testing agent-specific working directories...")
try:
    # Create a task with custom work directory
    task = EnhancedAgentTask(
        agent_id="test-agent",
        name="Test Agent",
        directive="Test task",
        work_dir_name="custom_work_dir",
        mcp_needs=["firecrawl", "web_search"],
        debug_mode=True
    )
    
    # Test working directory would be created at runtime
    expected_work_dir = orchestrator.agent_base_work_dir / task.work_dir_name
    print(f"✓ Task configured with work_dir_name: {task.work_dir_name}")
    print(f"  Expected location: {expected_work_dir}")
    print(f"✓ Task configured with MCP needs: {task.mcp_needs}")
    print(f"✓ Task debug mode: {task.debug_mode}")
    
except Exception as e:
    print(f"✗ Agent-specific directory test failed: {e}")

# Test 3: MCP config generation for agent
print("\n3. Testing MCP config generation...")
try:
    # Test if orchestrator can generate MCP config
    if orchestrator.enable_dynamic_configs and orchestrator.master_mcp_registry_path:
        print(f"✓ Dynamic configs enabled with registry: {orchestrator.master_mcp_registry_path}")
        
        # Check if master registry exists
        if Path("master_mcp_registry.json").exists():
            print("✓ Master registry file found")
            
            # Test reading and filtering registry
            with open("master_mcp_registry.json") as f:
                registry = json.load(f)
            
            # Filter for specific needs
            mcp_needs = ["firecrawl", "web_search"]
            filtered_servers = {
                k: v for k, v in registry.get("mcpServers", {}).items() 
                if k in mcp_needs
            }
            
            if len(filtered_servers) == len(mcp_needs):
                print(f"✓ Successfully filtered MCP servers for needs: {list(filtered_servers.keys())}")
            else:
                print(f"✗ MCP filtering incomplete: got {list(filtered_servers.keys())}")
        else:
            print("✗ Master registry file not found")
    else:
        print("✗ Dynamic configs not enabled")
        
except Exception as e:
    print(f"✗ MCP config generation test failed: {e}")

# Test 4: Log file routing
print("\n4. Testing log file routing...")
try:
    if orchestrator.log_to_work_dir:
        print("✓ Log to work directory enabled")
        
        # Check if logs would be routed correctly
        agent_work_dir = orchestrator.agent_base_work_dir / "test_agent"
        expected_log_dir = agent_work_dir / "logs"
        
        print(f"  Logs would be written to: {expected_log_dir}")
        print("  (Directory created at agent runtime)")
    else:
        print("  Log to work directory disabled - using default location")
        
except Exception as e:
    print(f"✗ Log routing test failed: {e}")

# Test 5: Profile-based execution
print("\n5. Testing execution profiles...")
profiles = ["minimal", "standard", "research", "full"]
for profile in profiles:
    try:
        orch = EnhancedOrchestrator(
            output_dir=test_dir / f"profile_{profile}",
            tokens=dummy_tokens,
            agent_execution_profile=profile,
            enable_dynamic_configs=True
        )
        print(f"✓ Profile '{profile}' initialized: {orch.agent_execution_profile}")
    except Exception as e:
        print(f"✗ Profile '{profile}' failed: {e}")

# Test 6: Symlink management (conceptual test)
print("\n6. Testing symlink management concepts...")
try:
    # Test symlink creation concept
    source_dir = test_dir / "source"
    source_dir.mkdir(exist_ok=True)
    
    link_dir = test_dir / "symlink_test"
    
    # Create symlink
    if not link_dir.exists():
        link_dir.symlink_to(source_dir)
        
    if link_dir.is_symlink():
        print(f"✓ Symlink created: {link_dir} -> {source_dir}")
        
        # Test symlink removal
        link_dir.unlink()
        if not link_dir.exists():
            print("✓ Symlink successfully removed")
        else:
            print("✗ Symlink removal failed")
    else:
        print("✗ Symlink creation failed")
        
except Exception as e:
    print(f"✗ Symlink test failed: {e}")

print("\n=== DYNAMIC ARCHITECTURE TESTING COMPLETE ===")