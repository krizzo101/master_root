#!/usr/bin/env python3
"""
Fixed Module Validation Test Suite
Tests module initialization, dependencies, and basic functionality
"""

import sys
import asyncio
from pathlib import Path
from typing import Dict, Any
import traceback

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

def test_module_imports():
    """Test that all modules can be imported"""
    print("\n" + "="*60)
    print("Testing Module Imports")
    print("="*60)
    
    modules_to_test = [
        "src.modules.quality_gates_module",
        "src.modules.monitoring_module", 
        "src.modules.collaboration_module",
        "src.modules.execution_plan_module"
    ]
    
    results = []
    for module_name in modules_to_test:
        try:
            __import__(module_name)
            print(f"✅ {module_name}: Import successful")
            results.append(True)
        except Exception as e:
            print(f"❌ {module_name}: Import failed - {e}")
            results.append(False)
    
    return all(results)


def test_module_structure():
    """Test module class structure and dependencies"""
    print("\n" + "="*60)
    print("Testing Module Structure")
    print("="*60)
    
    from src.modules import (
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    )
    
    # Check that modules have expected base structure
    modules = [
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    ]
    
    results = []
    for module_class in modules:
        try:
            # Check for required methods (cleanup is the actual method name, not shutdown)
            required_methods = ['initialize', 'cleanup']
            missing_methods = []
            
            for method in required_methods:
                if not hasattr(module_class, method):
                    missing_methods.append(method)
            
            if missing_methods:
                print(f"❌ {module_class.__name__}: Missing methods: {missing_methods}")
                results.append(False)
            else:
                print(f"✅ {module_class.__name__}: Has required methods")
                results.append(True)
                
        except Exception as e:
            print(f"❌ {module_class.__name__}: Structure check failed - {e}")
            results.append(False)
    
    return all(results)


async def test_module_initialization():
    """Test module initialization with properly configured mock orchestrator"""
    print("\n" + "="*60)
    print("Testing Module Initialization")
    print("="*60)
    
    from src.modules import (
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    )
    
    # Create more complete mock orchestrator
    class MockOrchestrator:
        def __init__(self):
            self.config = {
                "modules": {
                    "quality_gates": {"enabled": True},
                    "monitoring": {"enabled": True},
                    "collaboration": {"enabled": True},
                    "execution_plan": {"enabled": True}
                }
            }
            self.agents = {}
            self.resources = {}
            self.output_dir = Path("/tmp/test_orchestrator")
            self.output_dir.mkdir(exist_ok=True)
            
        async def emit_event(self, event_type: str, data: Dict[str, Any]):
            pass
            
        def get_module(self, module_name: str):
            """Mock method to get other modules"""
            return None
    
    orchestrator = MockOrchestrator()
    
    # Test each module initialization
    modules_to_test = [
        ("QualityGatesModule", QualityGatesModule),
        ("MonitoringModule", MonitoringModule),
        ("CollaborationModule", CollaborationModule),
        ("ExecutionPlanModule", ExecutionPlanModule)
    ]
    
    results = []
    for name, module_class in modules_to_test:
        try:
            module = module_class(orchestrator)
            await module.initialize()
            print(f"✅ {name}: Initialized successfully")
            # Use cleanup method instead of shutdown
            await module.cleanup()
            print(f"✅ {name}: Cleaned up successfully")
            results.append(True)
        except Exception as e:
            print(f"❌ {name}: Test failed - {e}")
            traceback.print_exc()
            results.append(False)
    
    return all(results)


def test_module_exports():
    """Test that __all__ exports match actual module contents"""
    print("\n" + "="*60)
    print("Testing Module Exports")
    print("="*60)
    
    import src.modules as modules_package
    
    # Check that all exported items exist
    missing_exports = []
    for item in modules_package.__all__:
        if not hasattr(modules_package, item):
            missing_exports.append(item)
    
    if missing_exports:
        print(f"❌ Missing exports: {missing_exports}")
        return False
    else:
        print(f"✅ All {len(modules_package.__all__)} exports are valid")
        return True


async def test_module_lifecycle():
    """Test complete module lifecycle: init -> operation -> cleanup"""
    print("\n" + "="*60)
    print("Testing Module Lifecycle")
    print("="*60)
    
    from src.modules import QualityGatesModule
    from src.unified.orchestrator_module import ModuleConfig
    
    class MockOrchestrator:
        def __init__(self):
            self.config = {
                "modules": {
                    "quality_gates": {"enabled": True}
                }
            }
            self.agents = {}
            self.resources = {}
            self.output_dir = Path("/tmp/test_orchestrator")
            self.output_dir.mkdir(exist_ok=True)
            
        async def emit_event(self, event_type: str, data: Dict[str, Any]):
            pass
    
    orchestrator = MockOrchestrator()
    
    try:
        # Create module with config
        config = ModuleConfig(
            enabled=True,
            priority=1,
            config={"strict_mode": False}
        )
        
        module = QualityGatesModule(orchestrator, config)
        
        # Test initialization
        init_result = await module.initialize()
        if not init_result:
            print(f"❌ Module initialization returned False")
            return False
        
        # Check initialized flag
        if not module.initialized:
            print(f"❌ Module not marked as initialized")
            return False
            
        print(f"✅ Module lifecycle: Initialized")
        
        # Test cleanup
        await module.cleanup()
        
        if module.initialized:
            print(f"❌ Module still marked as initialized after cleanup")
            return False
            
        print(f"✅ Module lifecycle: Cleaned up")
        return True
        
    except Exception as e:
        print(f"❌ Module lifecycle test failed: {e}")
        traceback.print_exc()
        return False


async def test_module_dependencies():
    """Test module dependency validation"""
    print("\n" + "="*60)
    print("Testing Module Dependencies")
    print("="*60)
    
    from src.modules import QualityGatesModule
    from src.unified.orchestrator_module import ModuleConfig
    
    class MockOrchestrator:
        def __init__(self):
            self.config = {}
            self.output_dir = Path("/tmp/test_orchestrator")
            
    orchestrator = MockOrchestrator()
    
    # Test with valid dependencies
    config = ModuleConfig(
        enabled=True,
        required_dependencies=["json", "asyncio"],  # These should exist
        optional_dependencies=["nonexistent_module"]  # This shouldn't exist
    )
    
    module = QualityGatesModule(orchestrator, config)
    
    # Should pass despite missing optional dependency
    if module.validate_dependencies():
        print(f"✅ Dependency validation passed with missing optional deps")
    else:
        print(f"❌ Dependency validation failed unexpectedly")
        return False
    
    # Test with invalid required dependencies
    config2 = ModuleConfig(
        enabled=True,
        required_dependencies=["totally_fake_module"]
    )
    
    module2 = QualityGatesModule(orchestrator, config2)
    
    if not module2.validate_dependencies():
        print(f"✅ Dependency validation correctly failed for missing required deps")
        return True
    else:
        print(f"❌ Dependency validation should have failed")
        return False


async def main():
    """Run all module validation tests"""
    print("\n" + "#"*60)
    print("#" + " "*20 + "MODULE VALIDATION" + " "*21 + "#")
    print("#" + " "*15 + "ENHANCED TEST SUITE v2.0" + " "*16 + "#")
    print("#"*60)
    
    results = []
    
    # Test 1: Module imports
    results.append(("Module Imports", test_module_imports()))
    
    # Test 2: Module structure
    results.append(("Module Structure", test_module_structure()))
    
    # Test 3: Module exports
    results.append(("Module Exports", test_module_exports()))
    
    # Test 4: Module initialization
    results.append(("Module Initialization", await test_module_initialization()))
    
    # Test 5: Module lifecycle
    results.append(("Module Lifecycle", await test_module_lifecycle()))
    
    # Test 6: Module dependencies
    results.append(("Module Dependencies", await test_module_dependencies()))
    
    # Final Summary
    print("\n" + "#"*60)
    print("#" + " "*23 + "FINAL SUMMARY" + " "*22 + "#")
    print("#"*60)
    
    all_passed = all(result[1] for result in results)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name:40} {status}")
    
    print("\n" + "#"*60)
    if all_passed:
        print("#" + " "*15 + "🎉 ALL TESTS PASSED! 🎉" + " "*16 + "#")
        print("#" + " "*10 + "Module validation is working correctly" + " "*10 + "#")
    else:
        print("#" + " "*18 + "⚠️ SOME TESTS FAILED ⚠️" + " "*15 + "#")
        print("#" + " "*12 + "Please review the failures above" + " "*13 + "#")
    print("#"*60)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))