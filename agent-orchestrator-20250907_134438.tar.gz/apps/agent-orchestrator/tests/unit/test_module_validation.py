#!/usr/bin/env python3
"""
Module Validation Test Suite
Tests module initialization, dependencies, and basic functionality
"""

import sys
import asyncio
from pathlib import Path
from typing import Dict, Any
import traceback

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

def test_module_imports():
    """Test that all modules can be imported"""
    print("\n" + "="*60)
    print("Testing Module Imports")
    print("="*60)
    
    modules_to_test = [
        "src.modules.quality_gates_module",
        "src.modules.monitoring_module", 
        "src.modules.collaboration_module",
        "src.modules.execution_plan_module"
    ]
    
    results = []
    for module_name in modules_to_test:
        try:
            __import__(module_name)
            print(f"✅ {module_name}: Import successful")
            results.append(True)
        except Exception as e:
            print(f"❌ {module_name}: Import failed - {e}")
            results.append(False)
    
    return all(results)


def test_module_structure():
    """Test module class structure and dependencies"""
    print("\n" + "="*60)
    print("Testing Module Structure")
    print("="*60)
    
    from src.modules import (
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    )
    
    # Check that modules have expected base structure
    modules = [
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    ]
    
    results = []
    for module_class in modules:
        try:
            # Check for required methods
            required_methods = ['initialize', 'shutdown']
            missing_methods = []
            
            for method in required_methods:
                if not hasattr(module_class, method):
                    missing_methods.append(method)
            
            if missing_methods:
                print(f"❌ {module_class.__name__}: Missing methods: {missing_methods}")
                results.append(False)
            else:
                print(f"✅ {module_class.__name__}: Has required methods")
                results.append(True)
                
        except Exception as e:
            print(f"❌ {module_class.__name__}: Structure check failed - {e}")
            results.append(False)
    
    return all(results)


async def test_module_initialization():
    """Test module initialization with mock orchestrator"""
    print("\n" + "="*60)
    print("Testing Module Initialization")
    print("="*60)
    
    from src.modules import (
        QualityGatesModule,
        MonitoringModule,
        CollaborationModule,
        ExecutionPlanModule
    )
    
    # Create mock orchestrator
    class MockOrchestrator:
        def __init__(self):
            self.config = {
                "modules": {
                    "quality_gates": {"enabled": True},
                    "monitoring": {"enabled": True},
                    "collaboration": {"enabled": True},
                    "execution_plan": {"enabled": True}
                }
            }
            self.agents = {}
            self.resources = {}
            
        async def emit_event(self, event_type: str, data: Dict[str, Any]):
            pass
    
    orchestrator = MockOrchestrator()
    
    # Test each module initialization
    modules_to_test = [
        ("QualityGatesModule", QualityGatesModule),
        ("MonitoringModule", MonitoringModule),
        ("CollaborationModule", CollaborationModule),
        ("ExecutionPlanModule", ExecutionPlanModule)
    ]
    
    results = []
    for name, module_class in modules_to_test:
        try:
            module = module_class(orchestrator)
            await module.initialize()
            print(f"✅ {name}: Initialized successfully")
            await module.shutdown()
            results.append(True)
        except Exception as e:
            print(f"❌ {name}: Initialization failed - {e}")
            traceback.print_exc()
            results.append(False)
    
    return all(results)


def test_module_exports():
    """Test that __all__ exports match actual module contents"""
    print("\n" + "="*60)
    print("Testing Module Exports")
    print("="*60)
    
    import src.modules as modules_package
    
    # Check that all exported items exist
    missing_exports = []
    for item in modules_package.__all__:
        if not hasattr(modules_package, item):
            missing_exports.append(item)
    
    if missing_exports:
        print(f"❌ Missing exports: {missing_exports}")
        return False
    else:
        print(f"✅ All {len(modules_package.__all__)} exports are valid")
        return True


async def main():
    """Run all module validation tests"""
    print("\n" + "#"*60)
    print("#" + " "*20 + "MODULE VALIDATION" + " "*21 + "#")
    print("#" + " "*17 + "COMPREHENSIVE TEST SUITE" + " "*17 + "#")
    print("#"*60)
    
    results = []
    
    # Test 1: Module imports
    results.append(("Module Imports", test_module_imports()))
    
    # Test 2: Module structure
    results.append(("Module Structure", test_module_structure()))
    
    # Test 3: Module exports
    results.append(("Module Exports", test_module_exports()))
    
    # Test 4: Module initialization
    results.append(("Module Initialization", await test_module_initialization()))
    
    # Final Summary
    print("\n" + "#"*60)
    print("#" + " "*23 + "FINAL SUMMARY" + " "*22 + "#")
    print("#"*60)
    
    all_passed = all(result[1] for result in results)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test_name:40} {status}")
    
    print("\n" + "#"*60)
    if all_passed:
        print("#" + " "*15 + "🎉 ALL TESTS PASSED! 🎉" + " "*16 + "#")
        print("#" + " "*10 + "Module validation is working correctly" + " "*10 + "#")
    else:
        print("#" + " "*18 + "⚠️ SOME TESTS FAILED ⚠️" + " "*15 + "#")
        print("#" + " "*12 + "Please review the failures above" + " "*13 + "#")
    print("#"*60)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))