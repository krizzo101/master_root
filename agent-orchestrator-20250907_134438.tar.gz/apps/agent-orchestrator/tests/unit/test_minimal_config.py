#!/usr/bin/env python3
"""
Minimal Configuration Test - Absolute Bare Minimum Setup
Tests the simplest possible UnifiedOrchestrator configuration
"""

import asyncio
import sys
from pathlib import Path

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.unified.enhanced_agent_task import EnhancedAgentTask
from src.unified.unified_orchestrator import UnifiedConfig, UnifiedOrchestrator


async def test_absolute_minimum():
    """Test with absolute minimal configuration - single task, no features"""
    print("🔬 Testing Absolute Minimal Configuration")
    print("-" * 40)
    
    # Minimal config - only required parameters
    config = UnifiedConfig(
        output_dir=Path("minimal_test_output"),
        max_parallel=1,  # Single task execution
        enabled_features=set(),  # No features at all
        enable_collaboration=False,
        enable_quality_gates=False,
        enable_monitoring=False,
    )
    
    # Create orchestrator
    orchestrator = UnifiedOrchestrator(config=config)
    
    # Single simple task
    task = EnhancedAgentTask(
        task_id="minimal_test",
        task_type="general-purpose",
        prompt="Write 'Hello from minimal test' to a file called minimal_test.txt",
        agent_uuid="minimal_agent",
        monitoring_enabled=False,
    )
    
    # Execute
    print("Executing minimal task...")
    results = await orchestrator.execute_batch([task])
    
    # Check result
    if results and results[0].get("status") == "completed":
        print("✅ Minimal configuration test PASSED")
        print(f"   Task completed in {results[0].get('execution_time', 'N/A')} seconds")
        return True
    else:
        print("❌ Minimal configuration test FAILED")
        if results:
            print(f"   Error: {results[0].get('error', 'Unknown error')}")
        return False


async def test_minimal_with_dependencies():
    """Test minimal config with task dependencies"""
    print("\n🔗 Testing Minimal Configuration with Dependencies")
    print("-" * 40)
    
    config = UnifiedConfig(
        output_dir=Path("minimal_deps_output"),
        max_parallel=2,  # Allow some parallelism
        enabled_features=set(),
        enable_collaboration=False,
        enable_quality_gates=False,
        enable_monitoring=False,
    )
    
    orchestrator = UnifiedOrchestrator(config=config)
    
    # Two tasks with dependency
    tasks = [
        EnhancedAgentTask(
            task_id="task_1",
            task_type="general-purpose",
            prompt="Create a file called step1.txt with content 'First step complete'",
            agent_uuid="agent_1",
            monitoring_enabled=False,
        ),
        EnhancedAgentTask(
            task_id="task_2",
            task_type="general-purpose",
            prompt="Read step1.txt and create step2.txt with 'Second step: <content from step1>'",
            agent_uuid="agent_2",
            dependencies=["task_1"],  # Depends on task_1
            monitoring_enabled=False,
        ),
    ]
    
    print("Executing 2 dependent tasks...")
    results = await orchestrator.execute_batch(tasks)
    
    # Check results
    completed = sum(1 for r in results if r.get("status") == "completed")
    
    if completed == len(tasks):
        print("✅ Dependency test PASSED")
        print(f"   Both tasks completed successfully")
        return True
    else:
        print("❌ Dependency test FAILED")
        print(f"   Only {completed}/{len(tasks)} tasks completed")
        return False


async def main():
    """Run all minimal configuration tests"""
    print("=" * 50)
    print("MINIMAL CONFIGURATION TEST SUITE")
    print("Testing the bare minimum UnifiedOrchestrator setup")
    print("=" * 50)
    
    tests = [
        ("Absolute Minimum", test_absolute_minimum),
        ("Minimal with Dependencies", test_minimal_with_dependencies),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = await test_func()
            results.append((name, result))
        except Exception as e:
            print(f"❌ {name} crashed: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST RESULTS SUMMARY")
    print("=" * 50)
    
    passed = sum(1 for _, result in results if result)
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All minimal configuration tests passed!")
        print("\n💡 Key Insights:")
        print("  • UnifiedOrchestrator works with absolute minimal config")
        print("  • No features needed for basic task execution")
        print("  • Dependencies work even with minimal setup")
        print("  • Production-ready with just required parameters")
    
    return passed == len(results)


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)