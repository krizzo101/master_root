#!/usr/bin/env python3
"""
Simple test to verify enhanced quality gates system works
"""

import asyncio
import sys
import tempfile
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

async def main():
    try:
        print("🔍 Testing basic imports...")
        
        # Test basic imports
        from enhanced_quality_gates import ContextBroker, ResourcePredictor, AgentMesh
        print("✓ Core components imported successfully")
        
        from enhanced_orchestrator import EnhancedAgentTask  
        print("✓ Enhanced agent task imported successfully")
        
        from enhanced_orchestrator_integration import IntelligentOrchestrator
        print("✓ Intelligent orchestrator imported successfully")
        
        # Test basic functionality
        print("\n🧪 Testing basic functionality...")
        
        # Test ContextBroker
        with tempfile.TemporaryDirectory() as temp_dir:
            context_store = Path(temp_dir) / "contexts"
            broker = ContextBroker(context_store)
            
            context_id = await broker.create_context("test_plan", {"test": "data"})
            assert context_id.startswith("ctx_test_plan_")
            print("✓ ContextBroker works")
            
            # Test ResourcePredictor
            data_path = Path(temp_dir) / "resource_history.json"
            predictor = ResourcePredictor(data_path)
            
            task = EnhancedAgentTask(
                task_id="test_task",
                task_type="code", 
                prompt="Test task",
                context={},
                dependencies=[]
            )
            
            prediction = predictor.predict_resources(task)
            assert prediction.estimated_tokens > 0
            print("✓ ResourcePredictor works")
            
            # Test AgentMesh
            mesh = AgentMesh("test")
            mesh.register_agent("agent_1", ["coding"])
            assert "agent_1" in mesh.active_agents
            print("✓ AgentMesh works")
            
            # Test IntelligentOrchestrator basic setup
            output_dir = Path(temp_dir) / "output"
            orchestrator = IntelligentOrchestrator(
                output_dir=output_dir,
                enable_intelligent_gates=True,
                enable_context_management=True,
                enable_resource_prediction=True,
                enable_collaboration=True
            )
            
            assert orchestrator.enable_intelligent_gates
            print("✓ IntelligentOrchestrator initialization works")
        
        print("\n🎉 ALL BASIC TESTS PASSED!")
        print("\n✅ Enhanced Quality Gate System Status:")
        print("  • Core components working")
        print("  • Import issues resolved") 
        print("  • Basic functionality verified")
        print("  • Integration layer functional")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)