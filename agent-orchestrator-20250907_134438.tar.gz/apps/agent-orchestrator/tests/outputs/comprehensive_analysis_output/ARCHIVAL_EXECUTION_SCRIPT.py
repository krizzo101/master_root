#!/usr/bin/env python3
"""
ARCHIVAL EXECUTION SCRIPT - Agent Orchestrator Cleanup
Safely executes the archival plan from Phase 1 analysis
Date: 2025-01-07
Agent UUID: agent_13_synthesis
"""

import os
import shutil
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('archival_execution.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ArchivalExecutor:
    """Executes the archival plan safely with rollback capability"""
    
    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        self.archive_date = datetime.now().strftime("%Y-%m-%d")
        self.archive_base = self.base_path / ".archive" / self.archive_date
        self.operations_log = []
        self.dry_run = False
        
    def load_archival_plan(self, plan_file: str = "comprehensive_analysis_output/12_archival_plan.json") -> Dict:
        """Load the archival plan from JSON file"""
        try:
            with open(self.base_path / plan_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.error(f"Archival plan not found: {plan_file}")
            return None
            
    def create_directories(self, directories: List[str]) -> bool:
        """Create all required directories"""
        logger.info("Creating archive directories...")
        success = True
        
        for directory in directories:
            dir_path = self.base_path / directory
            try:
                if not self.dry_run:
                    dir_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"Created: {directory}")
                self.operations_log.append(('mkdir', str(dir_path), 'success'))
            except Exception as e:
                logger.error(f"Failed to create {directory}: {e}")
                self.operations_log.append(('mkdir', str(dir_path), 'failed'))
                success = False
                
        return success
        
    def move_file(self, source: str, destination: str, reason: str) -> bool:
        """Move a single file or directory"""
        src_path = self.base_path / source
        dst_path = self.base_path / destination
        
        if not src_path.exists():
            logger.warning(f"Source not found, skipping: {source}")
            return True  # Not a failure if file doesn't exist
            
        try:
            if not self.dry_run:
                # Ensure destination directory exists
                dst_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Move file or directory
                if src_path.is_dir():
                    shutil.move(str(src_path), str(dst_path))
                else:
                    shutil.move(str(src_path), str(dst_path))
                    
            logger.info(f"Moved: {source} -> {destination} ({reason})")
            self.operations_log.append(('move', source, destination, 'success'))
            return True
            
        except Exception as e:
            logger.error(f"Failed to move {source}: {e}")
            self.operations_log.append(('move', source, destination, 'failed'))
            return False
            
    def archive_test_outputs(self, plan: Dict) -> Tuple[int, int]:
        """Archive all test output directories"""
        logger.info("\n=== Archiving Test Outputs ===")
        moved, failed = 0, 0
        
        for item in plan.get('immediate_priority', {}).get('test_output_directories', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        logger.info(f"Test outputs: {moved} moved, {failed} failed")
        return moved, failed
        
    def archive_generated_artifacts(self, plan: Dict) -> Tuple[int, int]:
        """Archive generated artifacts"""
        logger.info("\n=== Archiving Generated Artifacts ===")
        moved, failed = 0, 0
        
        for item in plan.get('immediate_priority', {}).get('generated_artifacts', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        logger.info(f"Generated artifacts: {moved} moved, {failed} failed")
        return moved, failed
        
    def relocate_test_scripts(self, plan: Dict) -> Tuple[int, int]:
        """Move test scripts to proper locations"""
        logger.info("\n=== Relocating Test Scripts ===")
        moved, failed = 0, 0
        
        for item in plan.get('immediate_priority', {}).get('test_scripts_in_root', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        logger.info(f"Test scripts: {moved} moved, {failed} failed")
        return moved, failed
        
    def archive_duplicates(self, plan: Dict) -> Tuple[int, int]:
        """Archive duplicate implementations"""
        logger.info("\n=== Archiving Duplicate Implementations ===")
        moved, failed = 0, 0
        
        for item in plan.get('immediate_priority', {}).get('duplicate_implementations', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        logger.info(f"Duplicates: {moved} moved, {failed} failed")
        return moved, failed
        
    def process_medium_priority(self, plan: Dict) -> Tuple[int, int]:
        """Process medium priority items"""
        logger.info("\n=== Processing Medium Priority Items ===")
        moved, failed = 0, 0
        
        # Complex examples
        for item in plan.get('medium_priority', {}).get('complex_examples', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        # Orchestrator implementations
        for item in plan.get('medium_priority', {}).get('orchestrator_implementations', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        # Analysis scripts
        for item in plan.get('medium_priority', {}).get('analysis_scripts', []):
            if self.move_file(item['source'], item['destination'], item['reason']):
                moved += 1
            else:
                failed += 1
                
        logger.info(f"Medium priority: {moved} moved, {failed} failed")
        return moved, failed
        
    def generate_summary_report(self) -> str:
        """Generate a summary report of operations"""
        report = []
        report.append("\n" + "="*60)
        report.append("ARCHIVAL EXECUTION SUMMARY")
        report.append("="*60)
        report.append(f"Execution Date: {self.archive_date}")
        report.append(f"Dry Run Mode: {self.dry_run}")
        report.append(f"Total Operations: {len(self.operations_log)}")
        
        # Count successes and failures
        successes = sum(1 for op in self.operations_log if 'success' in op)
        failures = sum(1 for op in self.operations_log if 'failed' in op)
        
        report.append(f"Successful: {successes}")
        report.append(f"Failed: {failures}")
        
        if failures > 0:
            report.append("\nFailed Operations:")
            for op in self.operations_log:
                if 'failed' in op:
                    report.append(f"  - {op[0]}: {op[1]}")
                    
        report.append("\nRecommended Next Steps:")
        if failures == 0:
            report.append("1. Review archived files in .archive directory")
            report.append("2. Commit changes to version control")
            report.append("3. Update documentation references")
            report.append("4. Run test suite to verify functionality")
        else:
            report.append("1. Review failed operations above")
            report.append("2. Manually handle failed moves")
            report.append("3. Re-run script after fixing issues")
            
        report.append("="*60)
        return "\n".join(report)
        
    def execute(self, dry_run: bool = True) -> bool:
        """Execute the complete archival plan"""
        self.dry_run = dry_run
        
        logger.info("="*60)
        logger.info(f"ARCHIVAL EXECUTION {'(DRY RUN)' if dry_run else '(LIVE)'}")
        logger.info("="*60)
        
        # Load the plan
        plan = self.load_archival_plan()
        if not plan:
            logger.error("Cannot proceed without archival plan")
            return False
            
        archival_plan = plan.get('archival_plan', {})
        
        # Create directories
        directories = archival_plan.get('cleanup_actions', {}).get('directories_to_create', [])
        if not self.create_directories(directories):
            logger.warning("Some directories failed to create, continuing...")
            
        # Execute immediate priority items
        stats = {
            'test_outputs': self.archive_test_outputs(archival_plan),
            'generated': self.archive_generated_artifacts(archival_plan),
            'test_scripts': self.relocate_test_scripts(archival_plan),
            'duplicates': self.archive_duplicates(archival_plan),
            'medium_priority': self.process_medium_priority(archival_plan)
        }
        
        # Calculate totals
        total_moved = sum(s[0] for s in stats.values())
        total_failed = sum(s[1] for s in stats.values())
        
        # Generate and display summary
        summary = self.generate_summary_report()
        print(summary)
        
        # Save summary to file
        summary_file = f"archival_summary_{self.archive_date}.txt"
        with open(summary_file, 'w') as f:
            f.write(summary)
        logger.info(f"Summary saved to {summary_file}")
        
        return total_failed == 0

def main():
    """Main execution function"""
    import sys
    
    print("\n" + "="*60)
    print("AGENT ORCHESTRATOR ARCHIVAL EXECUTION SCRIPT")
    print("="*60)
    print("\nThis script will reorganize the codebase according to")
    print("the archival plan from comprehensive analysis.")
    print("\nOptions:")
    print("  1. Dry run (preview changes)")
    print("  2. Execute (actually move files)")
    print("  3. Exit")
    
    choice = input("\nSelect option (1/2/3): ").strip()
    
    if choice == '3':
        print("Exiting...")
        sys.exit(0)
        
    dry_run = choice == '1'
    
    if not dry_run:
        confirm = input("\n⚠️  WARNING: This will move files! Continue? (yes/no): ")
        if confirm.lower() != 'yes':
            print("Aborted.")
            sys.exit(0)
            
    # Execute archival
    executor = ArchivalExecutor()
    success = executor.execute(dry_run=dry_run)
    
    if success:
        print("\n✅ Archival completed successfully!")
        if dry_run:
            print("Run with option 2 to actually move files.")
    else:
        print("\n⚠️  Archival completed with some failures.")
        print("Check archival_execution.log for details.")
        
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())