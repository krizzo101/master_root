#!/usr/bin/env python3
"""
Basic Functionality Tests for Agent Orchestrator

Tests what actually works vs what's claimed, without calling Claude API.
This establishes ground truth about current orchestrator capabilities.
"""

import asyncio
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
import json
import os

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.generic_orchestrator import GenericOrchestrator, AgentTask, TokenPool, DependencyManager
from src.token_loader import TokenLoader


class TestBasicFunctionality(unittest.IsolatedAsyncioTestCase):
    """Test current orchestrator basic functionality"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.output_dir = self.temp_dir / "output"
        
        # Set up mock token
        os.environ["CLAUDE_CODE_TOKEN"] = "test-token-123"
    
    def tearDown(self):
        """Clean up test environment"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        
        # Clean up environment
        if "CLAUDE_CODE_TOKEN" in os.environ:
            del os.environ["CLAUDE_CODE_TOKEN"]

    def test_token_loading(self):
        """Test 1: Token loading functionality"""
        loader = TokenLoader()
        tokens = loader.load_tokens()
        
        # Should load the test token
        self.assertEqual(len(tokens), 1)
        self.assertEqual(tokens[0], "test-token-123")
        
        print("✅ Token loading works: Found 1 CLAUDE_CODE_TOKEN")

    def test_token_pool_creation(self):
        """Test 2: TokenPool creation and round-robin"""
        tokens = ["token1", "token2", "token3"]
        pool = TokenPool(tokens)
        
        self.assertEqual(pool.size(), 3)
        
        print("✅ TokenPool creation works: 3 tokens loaded")
        
    async def test_token_pool_acquire(self):
        """Test 3: TokenPool acquire functionality"""
        tokens = ["token1", "token2", "token3"]
        pool = TokenPool(tokens)
        
        # Test round-robin
        token1, idx1 = await pool.acquire()
        token2, idx2 = await pool.acquire()
        token3, idx3 = await pool.acquire()
        token4, idx4 = await pool.acquire()  # Should wrap around
        
        self.assertEqual(token1, "token1")
        self.assertEqual(token2, "token2") 
        self.assertEqual(token3, "token3")
        self.assertEqual(token4, "token1")  # Wrapped around
        
        print("✅ TokenPool round-robin works: Correctly cycles through tokens")

    def test_agent_task_creation(self):
        """Test 4: AgentTask creation and serialization"""
        task = AgentTask(
            task_id="test_task",
            task_type="research",
            prompt="Test prompt",
            dependencies=["dep1", "dep2"]
        )
        
        self.assertEqual(task.task_id, "test_task")
        self.assertEqual(task.status, "pending")
        self.assertEqual(len(task.dependencies), 2)
        
        # Test serialization
        task_dict = task.to_dict()
        self.assertIsInstance(task_dict, dict)
        self.assertEqual(task_dict["task_id"], "test_task")
        
        print("✅ AgentTask creation works: Task created and serialized correctly")

    async def test_dependency_manager(self):
        """Test 5: Dependency management logic"""
        dep_manager = DependencyManager()
        
        # Create tasks
        task_a = AgentTask("task_a", "research", "Task A")
        task_b = AgentTask("task_b", "design", "Task B", dependencies=["task_a"])
        task_c = AgentTask("task_c", "code", "Task C", dependencies=["task_b"])
        
        # Test initial state - only task_a can run
        can_run_a = await dep_manager.can_run(task_a)
        can_run_b = await dep_manager.can_run(task_b)
        can_run_c = await dep_manager.can_run(task_c)
        
        self.assertTrue(can_run_a)
        self.assertFalse(can_run_b)  # Depends on task_a
        self.assertFalse(can_run_c)  # Depends on task_b
        
        # Mark task_a as completed
        await dep_manager.mark_running("task_a")
        await dep_manager.mark_completed("task_a")
        
        # Now task_b should be runnable
        can_run_b_now = await dep_manager.can_run(task_b)
        can_run_c_still = await dep_manager.can_run(task_c)
        
        self.assertTrue(can_run_b_now)
        self.assertFalse(can_run_c_still)  # Still depends on task_b
        
        print("✅ Dependency management works: Correctly handles task dependencies")

    async def test_orchestrator_initialization(self):
        """Test 6: GenericOrchestrator initialization"""
        orchestrator = GenericOrchestrator(
            output_dir=self.output_dir,
            max_parallel=3
        )
        
        self.assertEqual(orchestrator.max_parallel, 3)
        self.assertEqual(orchestrator.token_pool.size(), 1)  # Our test token
        self.assertTrue(self.output_dir.exists())
        self.assertTrue((self.output_dir / "tasks").exists())
        self.assertTrue((self.output_dir / "logs").exists())
        
        print("✅ GenericOrchestrator initialization works: Directories created, token pool initialized")

    @patch('subprocess.run')
    async def test_orchestrator_task_execution_logic(self, mock_subprocess):
        """Test 7: Orchestrator task execution logic (mocked)"""
        
        # Mock subprocess to simulate successful agent execution
        mock_process = MagicMock()
        mock_process.returncode = 0
        mock_process.stdout = json.dumps({"result": "success"}).encode()
        mock_process.stderr = b""
        mock_subprocess.return_value = mock_process
        
        orchestrator = GenericOrchestrator(
            output_dir=self.output_dir,
            max_parallel=2
        )
        
        # Mock the subprocess execution in execute_agent
        with patch('asyncio.create_subprocess_exec') as mock_create_subprocess:
            mock_proc = AsyncMock()
            mock_proc.returncode = 0
            mock_proc.communicate.return_value = (
                json.dumps({"status": "completed", "result": {"output": "test result"}}).encode(),
                b""
            )
            mock_create_subprocess.return_value = mock_proc
            
            # Test single task execution
            task = AgentTask("test_task", "research", "Test task")
            result = await orchestrator.execute_agent(task)
            
            self.assertEqual(result["status"], "completed")
            self.assertEqual(task.status, "completed")
            
        print("✅ Task execution logic works: Single task executed successfully (mocked)")

    @patch('asyncio.create_subprocess_exec')
    async def test_parallel_execution_logic(self, mock_create_subprocess):
        """Test 8: Parallel execution with dependency resolution"""
        
        # Mock subprocess execution
        mock_proc = AsyncMock()
        mock_proc.returncode = 0
        mock_proc.communicate.return_value = (
            json.dumps({"status": "completed", "result": {"output": "test"}}).encode(),
            b""
        )
        mock_create_subprocess.return_value = mock_proc
        
        orchestrator = GenericOrchestrator(
            output_dir=self.output_dir,
            max_parallel=2
        )
        
        # Create tasks with dependencies
        tasks = [
            AgentTask("task1", "research", "Task 1"),
            AgentTask("task2", "research", "Task 2"),  # Parallel with task1
            AgentTask("task3", "design", "Task 3", dependencies=["task1"]),  # Depends on task1
        ]
        
        results = await orchestrator.execute_batch(tasks)
        
        # All tasks should complete
        self.assertEqual(len(results), 3)
        completed = [r for r in results if r["status"] == "completed"]
        self.assertEqual(len(completed), 3)
        
        print("✅ Parallel execution with dependencies works: 3 tasks completed with dependency resolution")

    def test_file_structure_creation(self):
        """Test 9: Output directory structure creation"""
        orchestrator = GenericOrchestrator(
            output_dir=self.output_dir,
            max_parallel=1
        )
        
        # Check required directories exist
        self.assertTrue(self.output_dir.exists())
        self.assertTrue((self.output_dir / "tasks").exists())
        self.assertTrue((self.output_dir / "logs").exists())
        self.assertTrue((self.output_dir / "messages").exists())
        
        print("✅ File structure creation works: All required directories created")

    def test_message_bus_functionality(self):
        """Test 10: MessageBus file-based communication"""
        from src.generic_orchestrator import MessageBus
        
        message_bus = MessageBus(self.temp_dir / "messages")
        
        # Test message sending
        test_message = {"type": "test", "content": "Hello Agent B"}
        asyncio.run(message_bus.send("agent_a", "agent_b", test_message))
        
        # Check message file was created
        message_files = list((self.temp_dir / "messages").glob("agent_b_*.json"))
        self.assertEqual(len(message_files), 1)
        
        # Test message receiving
        messages = asyncio.run(message_bus.receive("agent_b"))
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0]["message"]["content"], "Hello Agent B")
        
        # Message should be deleted after reading
        message_files_after = list((self.temp_dir / "messages").glob("agent_b_*.json"))
        self.assertEqual(len(message_files_after), 0)
        
        print("✅ MessageBus functionality works: Messages sent, received, and cleaned up")


def run_tests():
    """Run all functionality tests"""
    
    print("=== AGENT ORCHESTRATOR BASIC FUNCTIONALITY TESTS ===")
    print("Testing what actually works vs what's claimed...\n")
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestBasicFunctionality)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Summary
    print(f"\n=== TEST RESULTS SUMMARY ===")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.failures:
        print("\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)