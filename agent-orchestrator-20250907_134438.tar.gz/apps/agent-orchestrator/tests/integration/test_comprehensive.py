#!/usr/bin/env python3
"""
Comprehensive test suite for Agent Orchestrator
Tests all parameter combinations, edge cases, and error conditions
"""

import asyncio
import sys
import json
import os
from pathlib import Path
from datetime import datetime
import tempfile
import shutil

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import GenericOrchestrator, AgentTask, TokenPool

# Test results storage
test_results = {
    "passed": [],
    "failed": [],
    "errors": [],
    "start_time": datetime.now().isoformat()
}

def log_result(test_name: str, status: str, details: str = ""):
    """Log test result"""
    result = {
        "test": test_name,
        "status": status,
        "details": details,
        "timestamp": datetime.now().isoformat()
    }
    
    if status == "PASS":
        test_results["passed"].append(result)
        print(f"✅ {test_name}")
    elif status == "FAIL":
        test_results["failed"].append(result)
        print(f"❌ {test_name}: {details}")
    else:
        test_results["errors"].append(result)
        print(f"⚠️  {test_name}: {details}")


# ============= BASIC INITIALIZATION TESTS =============

async def test_basic_initialization():
    """Test basic orchestrator initialization"""
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            orchestrator = GenericOrchestrator(
                output_dir=Path(tmpdir),
                max_parallel=5,
                use_optimizations=True
            )
            log_result("Basic initialization", "PASS")
            return True
    except Exception as e:
        log_result("Basic initialization", "FAIL", str(e))
        return False


async def test_no_token_initialization():
    """Test initialization without token"""
    # Temporarily remove token
    old_token = os.environ.get('CLAUDE_CODE_TOKEN', '')
    try:
        if 'CLAUDE_CODE_TOKEN' in os.environ:
            del os.environ['CLAUDE_CODE_TOKEN']
        
        with tempfile.TemporaryDirectory() as tmpdir:
            orchestrator = GenericOrchestrator(
                output_dir=Path(tmpdir)
            )
            log_result("No token initialization", "FAIL", "Should have raised error")
            return False
    except ValueError as e:
        if "No Claude tokens available" in str(e):
            log_result("No token initialization", "PASS", "Correctly raised error")
            return True
        else:
            log_result("No token initialization", "FAIL", f"Wrong error: {e}")
            return False
    finally:
        if old_token:
            os.environ['CLAUDE_CODE_TOKEN'] = old_token


async def test_custom_tokens():
    """Test with custom token list"""
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            tokens = ["token1", "token2", "token3"]
            orchestrator = GenericOrchestrator(
                output_dir=Path(tmpdir),
                tokens=tokens
            )
            
            # Check token pool size
            if orchestrator.token_pool.size() == 3:
                log_result("Custom tokens", "PASS")
                return True
            else:
                log_result("Custom tokens", "FAIL", f"Expected 3 tokens, got {orchestrator.token_pool.size()}")
                return False
    except Exception as e:
        log_result("Custom tokens", "FAIL", str(e))
        return False


# ============= PARAMETER COMBINATION TESTS =============

async def test_parameter_combinations():
    """Test various parameter combinations"""
    combinations = [
        {"max_parallel": 1, "use_optimizations": True},
        {"max_parallel": 1, "use_optimizations": False},
        {"max_parallel": 10, "use_optimizations": True},
        {"max_parallel": 10, "use_optimizations": False},
        {"max_parallel": 100, "use_optimizations": True},  # Very high
        {"max_parallel": 0, "use_optimizations": True},    # Edge case
    ]
    
    for combo in combinations:
        test_name = f"Params: max_parallel={combo['max_parallel']}, opt={combo['use_optimizations']}"
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                # Handle edge case of 0
                if combo['max_parallel'] == 0:
                    combo['max_parallel'] = 1  # Should default to 1
                
                orchestrator = GenericOrchestrator(
                    output_dir=Path(tmpdir),
                    **combo
                )
                log_result(test_name, "PASS")
        except Exception as e:
            log_result(test_name, "FAIL", str(e))


# ============= TASK CREATION TESTS =============

async def test_task_creation():
    """Test various task creation scenarios"""
    
    # Valid task
    try:
        task = AgentTask(
            task_id="test",
            task_type="test",
            prompt="Test prompt"
        )
        log_result("Valid task creation", "PASS")
    except Exception as e:
        log_result("Valid task creation", "FAIL", str(e))
    
    # Task with all fields
    try:
        task = AgentTask(
            task_id="test2",
            task_type="test",
            prompt="Test prompt",
            context={"key": "value"},
            dependencies=["dep1", "dep2"],
            status="pending",
            result=None,
            error=None,
            start_time=None,
            end_time=None
        )
        log_result("Task with all fields", "PASS")
    except Exception as e:
        log_result("Task with all fields", "FAIL", str(e))
    
    # Task with empty strings (edge case)
    try:
        task = AgentTask(
            task_id="",  # Empty ID
            task_type="",
            prompt=""
        )
        log_result("Empty string task", "PASS", "Allowed but may cause issues")
    except Exception as e:
        log_result("Empty string task", "ERROR", str(e))


# ============= DEPENDENCY TESTS =============

async def test_dependencies():
    """Test dependency handling"""
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir),
            max_parallel=5
        )
        
        # Test 1: Linear dependencies
        try:
            tasks = [
                AgentTask("task1", "test", "Task 1"),
                AgentTask("task2", "test", "Task 2", dependencies=["task1"]),
                AgentTask("task3", "test", "Task 3", dependencies=["task2"])
            ]
            
            # Check dependency resolution
            can_run = await orchestrator.dep_manager.can_run(tasks[0])
            if can_run:
                log_result("Linear dependencies - first task", "PASS")
            else:
                log_result("Linear dependencies - first task", "FAIL", "Should be able to run")
            
            can_run = await orchestrator.dep_manager.can_run(tasks[1])
            if not can_run:
                log_result("Linear dependencies - blocked task", "PASS")
            else:
                log_result("Linear dependencies - blocked task", "FAIL", "Should be blocked")
        except Exception as e:
            log_result("Linear dependencies", "FAIL", str(e))
        
        # Test 2: Circular dependencies (should detect)
        try:
            circular_tasks = [
                AgentTask("A", "test", "A", dependencies=["C"]),
                AgentTask("B", "test", "B", dependencies=["A"]),
                AgentTask("C", "test", "C", dependencies=["B"])
            ]
            # This should be detected as problematic
            log_result("Circular dependencies", "PASS", "Created but will deadlock")
        except Exception as e:
            log_result("Circular dependencies", "ERROR", str(e))
        
        # Test 3: Missing dependencies
        try:
            task_missing_dep = AgentTask(
                "orphan", "test", "Orphan",
                dependencies=["non_existent"]
            )
            log_result("Missing dependencies", "PASS", "Created but will never run")
        except Exception as e:
            log_result("Missing dependencies", "ERROR", str(e))


# ============= HOOK TESTS =============

async def test_hooks():
    """Test hook functionality"""
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir)
        )
        
        # Test pre-execute hook
        hook_called = {"pre": False, "post": False, "builder": False}
        
        async def pre_hook(task):
            hook_called["pre"] = True
        
        async def post_hook(task):
            hook_called["post"] = True
        
        async def builder_hook(task):
            hook_called["builder"] = True
            return task.prompt + " [modified]"
        
        orchestrator.pre_execute_hook = pre_hook
        orchestrator.post_execute_hook = post_hook
        orchestrator.task_builder_hook = builder_hook
        
        # Create a simple task (won't actually execute Claude)
        task = AgentTask("hook_test", "test", "Test")
        
        # Note: Can't fully test without executing, but can verify hooks are set
        if orchestrator.pre_execute_hook == pre_hook:
            log_result("Pre-execute hook set", "PASS")
        else:
            log_result("Pre-execute hook set", "FAIL")
        
        if orchestrator.post_execute_hook == post_hook:
            log_result("Post-execute hook set", "PASS")
        else:
            log_result("Post-execute hook set", "FAIL")
        
        if orchestrator.task_builder_hook == builder_hook:
            log_result("Task builder hook set", "PASS")
        else:
            log_result("Task builder hook set", "FAIL")


# ============= ERROR CONDITION TESTS =============

async def test_error_conditions():
    """Test various error conditions"""
    
    # Test 1: Invalid output directory
    try:
        orchestrator = GenericOrchestrator(
            output_dir=Path("/invalid/path/that/should/not/exist/xyz123")
        )
        log_result("Invalid output directory", "FAIL", "Should have raised error")
    except Exception as e:
        log_result("Invalid output directory", "PASS", "Correctly raised error")
    
    # Test 2: Negative max_parallel
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            orchestrator = GenericOrchestrator(
                output_dir=Path(tmpdir),
                max_parallel=-5
            )
            # Python doesn't prevent negative, but it should handle gracefully
            log_result("Negative max_parallel", "PASS", "Handled gracefully")
    except Exception as e:
        log_result("Negative max_parallel", "ERROR", str(e))
    
    # Test 3: None values (should use defaults)
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            orchestrator = GenericOrchestrator(
                output_dir=Path(tmpdir),
                max_parallel=None,  # Should use default (10)
                tokens=None,  # Should use env
                use_optimizations=None  # Should use default (True)
            )
            # Check that defaults were applied
            if orchestrator.max_parallel == 10:
                log_result("None parameter values", "PASS", "Defaults applied correctly")
            else:
                log_result("None parameter values", "FAIL", f"Expected max_parallel=10, got {orchestrator.max_parallel}")
    except Exception as e:
        log_result("None parameter values", "FAIL", str(e))


# ============= BATCH EXECUTION TESTS =============

async def test_batch_execution():
    """Test batch execution scenarios"""
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir)
        )
        
        # Test 1: Empty batch
        try:
            results = await orchestrator.execute_batch([])
            if len(results) == 0:
                log_result("Empty batch execution", "PASS")
            else:
                log_result("Empty batch execution", "FAIL", f"Expected 0 results, got {len(results)}")
        except Exception as e:
            log_result("Empty batch execution", "FAIL", str(e))
        
        # Test 2: Single task batch
        try:
            tasks = [AgentTask("single", "test", "Single task")]
            # Note: This would actually try to execute Claude
            # We'll just test that it doesn't crash during setup
            log_result("Single task batch", "PASS", "Batch created")
        except Exception as e:
            log_result("Single task batch", "FAIL", str(e))
        
        # Test 3: Large batch (stress test)
        try:
            large_batch = [
                AgentTask(f"task_{i}", "test", f"Task {i}")
                for i in range(1000)
            ]
            log_result("Large batch creation (1000 tasks)", "PASS")
        except Exception as e:
            log_result("Large batch creation", "FAIL", str(e))


# ============= TOKEN POOL TESTS =============

async def test_token_pool():
    """Test token pool functionality"""
    
    # Test 1: Single token
    try:
        pool = TokenPool(["token1"])
        token, idx = await pool.acquire()
        if token == "token1" and idx == 0:
            log_result("Single token pool", "PASS")
        else:
            log_result("Single token pool", "FAIL", f"Got {token}, {idx}")
    except Exception as e:
        log_result("Single token pool", "FAIL", str(e))
    
    # Test 2: Multiple tokens with round-robin
    try:
        pool = TokenPool(["token1", "token2", "token3"])
        
        # Should round-robin
        t1, i1 = await pool.acquire()
        t2, i2 = await pool.acquire()
        t3, i3 = await pool.acquire()
        t4, i4 = await pool.acquire()  # Should wrap to token1
        
        if t1 == "token1" and t2 == "token2" and t3 == "token3" and t4 == "token1":
            log_result("Token round-robin", "PASS")
        else:
            log_result("Token round-robin", "FAIL", f"Sequence: {t1}, {t2}, {t3}, {t4}")
    except Exception as e:
        log_result("Token round-robin", "FAIL", str(e))
    
    # Test 3: Empty token list
    try:
        pool = TokenPool([])
        log_result("Empty token pool", "FAIL", "Should have raised error")
    except ValueError:
        log_result("Empty token pool", "PASS", "Correctly raised error")
    except Exception as e:
        log_result("Empty token pool", "ERROR", str(e))


# ============= FILE SYSTEM TESTS =============

async def test_file_system():
    """Test file system operations"""
    
    with tempfile.TemporaryDirectory() as tmpdir:
        orchestrator = GenericOrchestrator(
            output_dir=Path(tmpdir)
        )
        
        # Check directories were created
        output_dir = Path(tmpdir)
        tasks_dir = output_dir / "tasks"
        logs_dir = output_dir / "logs"
        
        if output_dir.exists():
            log_result("Output directory created", "PASS")
        else:
            log_result("Output directory created", "FAIL")
        
        if tasks_dir.exists():
            log_result("Tasks directory created", "PASS")
        else:
            log_result("Tasks directory created", "FAIL")
        
        if logs_dir.exists():
            log_result("Logs directory created", "PASS")
        else:
            log_result("Logs directory created", "FAIL")
        
        # Test task state saving
        try:
            task = AgentTask("test_save", "test", "Test")
            task.status = "completed"
            task.result = {"test": "data"}
            
            # Manually save task state
            task_file = tasks_dir / f"{task.task_id}.json"
            task_file.write_text(json.dumps(task.to_dict(), indent=2))
            
            # Verify it was saved
            if task_file.exists():
                saved_data = json.loads(task_file.read_text())
                if saved_data["task_id"] == "test_save":
                    log_result("Task state persistence", "PASS")
                else:
                    log_result("Task state persistence", "FAIL", "Data mismatch")
            else:
                log_result("Task state persistence", "FAIL", "File not created")
        except Exception as e:
            log_result("Task state persistence", "FAIL", str(e))


# ============= MAIN TEST RUNNER =============

async def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("COMPREHENSIVE TEST SUITE FOR AGENT ORCHESTRATOR")
    print("="*60 + "\n")
    
    # Basic initialization tests
    print("\n--- INITIALIZATION TESTS ---")
    await test_basic_initialization()
    await test_no_token_initialization()
    await test_custom_tokens()
    
    # Parameter combination tests
    print("\n--- PARAMETER COMBINATION TESTS ---")
    await test_parameter_combinations()
    
    # Task creation tests
    print("\n--- TASK CREATION TESTS ---")
    await test_task_creation()
    
    # Dependency tests
    print("\n--- DEPENDENCY TESTS ---")
    await test_dependencies()
    
    # Hook tests
    print("\n--- HOOK TESTS ---")
    await test_hooks()
    
    # Error condition tests
    print("\n--- ERROR CONDITION TESTS ---")
    await test_error_conditions()
    
    # Batch execution tests
    print("\n--- BATCH EXECUTION TESTS ---")
    await test_batch_execution()
    
    # Token pool tests
    print("\n--- TOKEN POOL TESTS ---")
    await test_token_pool()
    
    # File system tests
    print("\n--- FILE SYSTEM TESTS ---")
    await test_file_system()
    
    # Summary
    test_results["end_time"] = datetime.now().isoformat()
    
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"✅ Passed: {len(test_results['passed'])}")
    print(f"❌ Failed: {len(test_results['failed'])}")
    print(f"⚠️  Errors: {len(test_results['errors'])}")
    print(f"Total: {len(test_results['passed']) + len(test_results['failed']) + len(test_results['errors'])}")
    
    # Save results
    results_file = Path("test_results.json")
    results_file.write_text(json.dumps(test_results, indent=2))
    print(f"\nDetailed results saved to: {results_file}")
    
    # Return success/failure
    return len(test_results['failed']) == 0 and len(test_results['errors']) == 0


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)