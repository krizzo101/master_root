#!/usr/bin/env python3
import asyncio
from pathlib import Path
from typing import Dict, List
import sys

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask

def generate_minimal_single_task() -> List[EnhancedAgentTask]:
    """Single task to test Enhanced Orchestrator basic functionality"""
    return [
        EnhancedAgentTask(
            task_id="simple_test",
            task_type="research",
            prompt="Create a simple text file called 'enhanced_test_output.txt' with the text 'Enhanced orchestrator minimal test successful'",
            quality_gates=[],              # No quality gates
            validation_required=False,     # No validation 
            phase_id="test",              # Simple phase
            monitoring_enabled=False       # No monitoring
        )
    ]

def generate_minimal_workflow() -> List[EnhancedAgentTask]:
    """3-task workflow using Enhanced Orchestrator with minimal features"""
    return [
        EnhancedAgentTask(
            task_id="research_task",
            task_type="research",
            prompt="Research Python best practices for error handling and create a summary file called 'enhanced_research_summary.txt' with 3 key points",
            dependencies=[],
            quality_gates=[],              # No quality gates
            validation_required=False,     # No validation
            phase_id="discovery",          # Phase tracking
            monitoring_enabled=False       # No monitoring
        ),
        EnhancedAgentTask(
            task_id="implementation_task", 
            task_type="development-specialist",
            prompt="Based on the enhanced_research_summary.txt file, create a simple Python example script called 'enhanced_example.py' that demonstrates proper error handling",
            dependencies=["research_task"],
            quality_gates=[],              # No quality gates
            validation_required=False,     # No validation
            phase_id="implementation",     # Phase tracking
            monitoring_enabled=False       # No monitoring
        ),
        EnhancedAgentTask(
            task_id="validation_task",
            task_type="qa-testing-guru", 
            prompt="Test the enhanced_example.py script by running it and create a test report called 'enhanced_test_results.txt' documenting whether it works correctly",
            dependencies=["implementation_task"],
            quality_gates=[],              # No quality gates
            validation_required=False,     # No validation
            phase_id="validation",         # Phase tracking
            monitoring_enabled=False       # No monitoring
        )
    ]

async def run_single_task_test():
    """Test single task execution"""
    print("🔬 Enhanced Orchestrator - Single Task Test")
    print("=" * 50)
    
    # Create minimal enhanced orchestrator
    orchestrator = EnhancedOrchestrator(
        output_dir=Path("test_enhanced_single_output"),
        max_parallel=1,                    # Single task only
        enable_quality_gates=False,        # Disable quality gates
        enable_monitoring=False,           # Disable monitoring
        use_optimizations=True
    )

    # Generate single task
    tasks = generate_minimal_single_task()
    print(f"Generated {len(tasks)} minimal enhanced task")

    # Execute
    try:
        result = await orchestrator.run(
            task_generator=lambda: tasks
        )
        
        metrics = result['metrics']
        success = metrics['completed'] == metrics['total']
        print(f"Single Task Result: {'SUCCESS' if success else 'FAILED'}")
        print(f"Completed: {metrics['completed']}/{metrics['total']}")
        return success
        
    except Exception as e:
        print(f"Single Task Error: {e}")
        return False

async def run_full_workflow_test():
    """Test full 3-task workflow"""
    print("\n🚀 Enhanced Orchestrator - Full Workflow Test")
    print("=" * 50)
    
    # Create minimal enhanced orchestrator  
    orchestrator = EnhancedOrchestrator(
        output_dir=Path("test_enhanced_workflow_output"), 
        max_parallel=3,                    # Allow parallel execution
        enable_quality_gates=False,        # Disable quality gates
        enable_monitoring=False,           # Disable monitoring
        use_optimizations=True
    )

    # Generate full workflow
    tasks = generate_minimal_workflow()
    print(f"Generated {len(tasks)} enhanced workflow tasks")

    # Execute
    try:
        result = await orchestrator.run(
            task_generator=lambda: tasks
        )
        
        metrics = result['metrics']
        success = metrics['completed'] == metrics['total']
        print(f"Full Workflow Result: {'SUCCESS' if success else 'FAILED'}")
        print(f"Completed: {metrics['completed']}/{metrics['total']}")
        return success
        
    except Exception as e:
        print(f"Full Workflow Error: {e}")
        return False

async def main():
    """Main test execution"""
    print("🎯 Enhanced Orchestrator Minimal Test Suite")
    print("=" * 60)
    
    # Phase 1: Single task test
    single_success = await run_single_task_test()
    
    if single_success:
        print("✅ Single task test passed - proceeding to full workflow")
        # Phase 2: Full workflow test  
        workflow_success = await run_full_workflow_test()
        
        if workflow_success:
            print("\n🎉 ALL TESTS PASSED - Enhanced Orchestrator working!")
            return True
        else:
            print("\n❌ Full workflow failed")
            return False
    else:
        print("\n❌ Single task failed - skipping full workflow")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)