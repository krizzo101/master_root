#!/usr/bin/env python3
"""
Comprehensive Test Suite for Self-Improvement Features

This module provides thorough testing of all self-improvement components:
- Enhanced Quality Gates System with Intelligence
- Context Management and Adaptation Engine 
- Resource Prediction and Optimization
- Inter-Agent Collaboration Framework
- Integration and Backward Compatibility

Tests ensure self-improvements work correctly without breaking existing functionality.
"""

import asyncio
import json
import tempfile
import uuid
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, List, Any
import pytest
import time

# Import components to test
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from enhanced_quality_gates import (
    EnhancedQualityGateManager,
    ContextBroker,
    ResourcePredictor,
    PlanAdaptationEngine,
    AgentMesh,
    ExecutionContext,
    ResourcePrediction,
    TaskMetrics,
    Message,
    create_enhanced_quality_manager,
)

from enhanced_orchestrator import (
    EnhancedOrchestrator,
    EnhancedAgentTask,
    BackgroundJob,
)

from working_quality_gates import (
    QualityGate,
    QualityGateManager,
    ValidationResult,
)

from generic_orchestrator import AgentTask


class TestEnhancedQualityGates:
    """Test suite for Enhanced Quality Gates System"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def sample_task(self):
        """Create sample enhanced agent task"""
        return EnhancedAgentTask(
            task_id="test_task_001",
            task_type="code",
            prompt="Implement a function to calculate fibonacci numbers with memoization for performance optimization",
            dependencies=["test_dependency_001"],
            context={"project": "math_utils", "performance": "high"},
            quality_gates=["code_review", "performance_check"],
            validation_required=True,
            agent_uuid="test-agent-001"
        )
    
    @pytest.fixture
    async def context_broker(self, temp_dir):
        """Create context broker for testing"""
        return ContextBroker(temp_dir / "contexts")
    
    @pytest.fixture
    def resource_predictor(self, temp_dir):
        """Create resource predictor for testing"""
        return ResourcePredictor(temp_dir / "resource_history.json")
    
    @pytest.fixture
    def agent_mesh(self):
        """Create agent mesh for testing"""
        return AgentMesh("test_mesh")
    
    @pytest.fixture
    async def enhanced_quality_manager(self, temp_dir):
        """Create enhanced quality gate manager"""
        return create_enhanced_quality_manager(
            output_dir=temp_dir,
            enabled_gates=["structure", "dependencies", "prompt"],
            enable_predictions=True,
            enable_collaboration=True,
            enable_context=True
        )


class TestContextBroker:
    """Test Context Management System"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    async def context_broker(self, temp_dir):
        return ContextBroker(temp_dir / "contexts")
    
    @pytest.mark.asyncio
    async def test_create_and_retrieve_context(self, context_broker):
        """Test context creation and retrieval"""
        # Create context
        plan_id = "test_plan_001"
        initial_data = {"version": "1.0", "project": "test"}
        
        context_id = await context_broker.create_context(plan_id, initial_data)
        
        assert context_id.startswith(f"ctx_{plan_id}")
        assert context_id in context_broker.active_contexts
        
        # Retrieve context
        context_data = await context_broker.get_context_for_task(context_id, "task_001")
        
        assert context_data["global_variables"] == initial_data
        assert "context_id" in context_data
        assert context_data["context_id"] == context_id
    
    @pytest.mark.asyncio
    async def test_context_updates(self, context_broker):
        """Test context updates and persistence"""
        context_id = await context_broker.create_context("test_plan", {})
        
        # Update context with various types of data
        updates = {
            "variables": {"status": "running", "progress": 0.5},
            "artifacts": {"output.txt": Path("/tmp/output.txt")},
            "knowledge": {"learned_patterns": ["pattern1", "pattern2"]},
            "decision": {"action": "retry", "reason": "network_error"},
            "task_id": "task_001"
        }
        
        await context_broker.update_context(context_id, updates)
        
        # Verify updates
        context_data = await context_broker.get_context_for_task(context_id, "task_002")
        
        assert context_data["global_variables"]["status"] == "running"
        assert context_data["global_variables"]["progress"] == 0.5
        assert len(context_data["relevant_decisions"]) == 1
        assert context_data["cross_task_knowledge"]["learned_patterns"] == ["pattern1", "pattern2"]
    
    @pytest.mark.asyncio
    async def test_context_persistence(self, context_broker, temp_dir):
        """Test context persistence to disk"""
        context_id = await context_broker.create_context("persist_test", {"key": "value"})
        
        # Verify file was created
        context_file = temp_dir / "contexts" / f"{context_id}.json"
        assert context_file.exists()
        
        # Verify file contents
        with open(context_file, 'r') as f:
            data = json.load(f)
        
        assert data["context_id"] == context_id
        assert data["plan_id"] == "persist_test"
        assert data["global_variables"]["key"] == "value"
    
    @pytest.mark.asyncio
    async def test_context_subscribers(self, context_broker):
        """Test context update notifications"""
        context_id = await context_broker.create_context("notify_test", {})
        
        # Set up subscriber
        notifications = []
        
        async def subscriber_callback(ctx_id, updates):
            notifications.append((ctx_id, updates))
        
        context_broker.subscribe_to_context_updates(context_id, subscriber_callback)
        
        # Update context
        updates = {"variables": {"test": "notification"}}
        await context_broker.update_context(context_id, updates)
        
        # Verify notification was sent
        assert len(notifications) == 1
        assert notifications[0][0] == context_id
        assert notifications[0][1] == updates


class TestResourcePredictor:
    """Test Resource Prediction and Optimization"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def resource_predictor(self, temp_dir):
        return ResourcePredictor(temp_dir / "resource_history.json")
    
    @pytest.fixture
    def sample_task(self):
        return EnhancedAgentTask(
            task_id="pred_test_001",
            task_type="code",
            prompt="Write a complex algorithm with error handling and documentation",
            dependencies=["analysis_task"],
            context={"complexity": "high", "domain": "algorithms"}
        )
    
    def test_resource_prediction_defaults(self, resource_predictor, sample_task):
        """Test resource prediction with no historical data"""
        prediction = resource_predictor.predict_resources(sample_task)
        
        assert isinstance(prediction, ResourcePrediction)
        assert prediction.estimated_tokens > 0
        assert prediction.estimated_duration > 0
        assert 0 <= prediction.parallel_compatibility <= 1
        assert prediction.optimal_batch_size > 0
        assert 0 <= prediction.confidence <= 1
    
    def test_record_and_predict(self, resource_predictor, sample_task):
        """Test learning from execution history"""
        # Record some execution history
        metrics = TaskMetrics(
            duration=120.5,
            memory_usage=256,
            tokens_used=1500,
            status="completed"
        )
        
        resource_predictor.record_execution(sample_task, metrics)
        
        # Create similar task for prediction
        similar_task = EnhancedAgentTask(
            task_id="similar_task",
            task_type="code", # Same type
            prompt="Write another algorithm with similar complexity",
            dependencies=["prep_task"],
            context={"complexity": "high"}  # Similar context
        )
        
        prediction = resource_predictor.predict_resources(similar_task)
        
        # Should have higher confidence due to similar historical data
        assert prediction.confidence > 0.3
        assert prediction.estimated_duration > 0
    
    def test_pattern_analysis(self, resource_predictor, sample_task):
        """Test pattern analysis from multiple executions"""
        # Record multiple executions of code tasks
        for i in range(5):
            task = EnhancedAgentTask(
                task_id=f"code_task_{i}",
                task_type="code",
                prompt=f"Implement function {i}",
                dependencies=[],
                context={}
            )
            
            metrics = TaskMetrics(
                duration=100.0 + (i * 10),
                tokens_used=1000 + (i * 100),
                status="completed"
            )
            
            resource_predictor.record_execution(task, metrics)
        
        # Should have learned patterns
        assert len(resource_predictor.execution_history) == 5
        assert "code" in resource_predictor.task_patterns
        
        pattern = resource_predictor.task_patterns["code"]
        assert pattern["count"] == 5
        assert pattern["success_rate"] == 1.0  # All completed
        assert pattern["avg_duration"] > 0
    
    def test_similarity_matching(self, resource_predictor):
        """Test task similarity matching algorithm"""
        # Create task with specific features
        base_task = EnhancedAgentTask(
            task_id="base",
            task_type="research",
            prompt="A" * 500,  # 500 char prompt
            dependencies=["dep1", "dep2"],  # 2 dependencies
            context={"size": "medium"}
        )
        
        # Record execution
        resource_predictor.record_execution(base_task, TaskMetrics(duration=60.0, tokens_used=800))
        
        # Test similar task
        similar_task = EnhancedAgentTask(
            task_id="similar",
            task_type="research",  # Same type
            prompt="B" * 450,      # Similar prompt length
            dependencies=["dep3", "dep4"],  # Same dependency count
            context={"size": "medium"}
        )
        
        prediction = resource_predictor.predict_resources(similar_task)
        
        # Should have reasonable confidence due to similarity
        assert prediction.confidence > 0.5


class TestPlanAdaptationEngine:
    """Test Dynamic Plan Adaptation Engine"""
    
    @pytest.fixture
    def mock_orchestrator(self):
        mock = MagicMock()
        mock.quality_gate_manager = MagicMock()
        return mock
    
    @pytest.fixture
    def adaptation_engine(self, mock_orchestrator):
        return PlanAdaptationEngine(mock_orchestrator)
    
    @pytest.fixture
    def mock_execution_plan(self):
        """Mock execution plan for testing"""
        mock_plan = MagicMock()
        mock_plan.id = "test_plan_001"
        mock_plan.tasks = []
        return mock_plan
    
    @pytest.mark.asyncio
    async def test_failure_analysis(self, adaptation_engine):
        """Test failure analysis categorization"""
        # Test transient error
        transient_analysis = await adaptation_engine._analyze_failure("Connection timeout occurred")
        assert transient_analysis["category"] == "transient"
        assert transient_analysis["confidence"] > 0.8
        
        # Test resource limitation
        resource_analysis = await adaptation_engine._analyze_failure("Memory limit exceeded")
        assert resource_analysis["category"] == "resource_limitation"
        assert resource_analysis["confidence"] > 0.7
        
        # Test unknown error
        unknown_analysis = await adaptation_engine._analyze_failure("Mysterious error occurred")
        assert unknown_analysis["category"] == "unknown"
    
    @pytest.mark.asyncio
    async def test_task_failure_adaptation(self, adaptation_engine, mock_execution_plan):
        """Test plan adaptation for task failures"""
        context = {
            "failed_task_id": "task_001",
            "error": "Connection timeout - please retry"
        }
        
        adapted_plan = await adaptation_engine.adapt_plan(
            mock_execution_plan, 
            "task_failure", 
            context
        )
        
        # Should record adaptation
        assert len(adaptation_engine.adaptation_history) == 1
        
        adaptation_record = adaptation_engine.adaptation_history[0]
        assert adaptation_record["trigger"] == "task_failure"
        assert adaptation_record["original_plan_id"] == "test_plan_001"
    
    @pytest.mark.asyncio
    async def test_resource_constraint_adaptation(self, adaptation_engine, mock_execution_plan):
        """Test plan adaptation for resource constraints"""
        context = {
            "constraint_type": "memory_limit",
            "available_memory": "512MB",
            "required_memory": "1GB"
        }
        
        adapted_plan = await adaptation_engine.adapt_plan(
            mock_execution_plan,
            "resource_constraint",
            context
        )
        
        assert adapted_plan is not None
        assert len(adaptation_engine.adaptation_history) == 1


class TestAgentMesh:
    """Test Inter-Agent Collaboration Framework"""
    
    @pytest.fixture
    def agent_mesh(self):
        return AgentMesh("test_collaboration_mesh")
    
    def test_agent_registration(self, agent_mesh):
        """Test agent registration and capabilities"""
        agent_id = "agent_001"
        capabilities = ["code_analysis", "documentation", "testing"]
        
        agent_mesh.register_agent(agent_id, capabilities)
        
        assert agent_id in agent_mesh.active_agents
        agent_info = agent_mesh.active_agents[agent_id]
        assert agent_info["status"] == "active"
        assert agent_info["capabilities"] == capabilities
        assert agent_info["message_count"] == 0
    
    @pytest.mark.asyncio
    async def test_message_passing(self, agent_mesh):
        """Test inter-agent message passing"""
        # Register agents
        agent_mesh.register_agent("sender", ["analysis"])
        agent_mesh.register_agent("receiver", ["implementation"])
        
        # Create message
        message = Message(
            sender_id="sender",
            recipient_id="receiver",
            message_type="request",
            content={"task": "implement_feature", "details": "Add error handling"},
            timestamp=time.time(),
            priority=3
        )
        
        # Send message
        success = await agent_mesh.send_message(message)
        assert success
        
        # Check sender's message count updated
        assert agent_mesh.active_agents["sender"]["message_count"] == 1
        
        # Retrieve messages for receiver
        messages = await agent_mesh.get_messages("receiver", limit=5)
        assert len(messages) == 1
        assert messages[0].content["task"] == "implement_feature"
        assert messages[0].sender_id == "sender"
    
    @pytest.mark.asyncio
    async def test_expert_consultation_pattern(self, agent_mesh):
        """Test built-in expert consultation collaboration pattern"""
        # Register agents with different capabilities
        agent_mesh.register_agent("requester", ["general"])
        agent_mesh.register_agent("expert1", ["database", "optimization"])
        agent_mesh.register_agent("expert2", ["security", "database"])
        
        # Test consultation pattern
        consultation_result = await agent_mesh.collaboration_patterns["expert_consultation"](
            initiator_id="requester",
            question="How to optimize database queries?",
            domain="database"
        )
        
        assert consultation_result["success"]
        assert len(consultation_result["experts_consulted"]) == 2  # Both experts have database capability
        assert "expert1" in consultation_result["experts_consulted"]
        assert "expert2" in consultation_result["experts_consulted"]
        
        # Check messages were sent to experts
        expert1_messages = await agent_mesh.get_messages("expert1")
        expert2_messages = await agent_mesh.get_messages("expert2")
        
        assert len(expert1_messages) == 1
        assert len(expert2_messages) == 1
        assert expert1_messages[0].message_type == "consultation_request"


class TestEnhancedQualityGateManager:
    """Test Enhanced Quality Gate Manager Integration"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    async def enhanced_manager(self, temp_dir):
        return create_enhanced_quality_manager(
            output_dir=temp_dir,
            enabled_gates=["structure", "dependencies", "prompt"],
            enable_predictions=True,
            enable_collaboration=True,
            enable_context=True
        )
    
    @pytest.fixture
    def sample_enhanced_task(self):
        return EnhancedAgentTask(
            task_id="enhanced_test_001",
            task_type="code",
            prompt="Implement a sophisticated caching mechanism with TTL and LRU eviction",
            dependencies=["cache_design"],
            context={"performance": "critical", "memory": "limited"},
            quality_gates=["performance_gate"],
            validation_required=True
        )
    
    @pytest.mark.asyncio
    async def test_context_aware_validation(self, enhanced_manager, sample_enhanced_task):
        """Test validation with context awareness"""
        # First ensure context broker is available
        assert enhanced_manager.context_broker is not None
        
        # Create context
        context_id = await enhanced_manager.context_broker.create_context(
            "test_plan", 
            {"project_type": "high_performance"}
        )
        
        # Add decision history that might conflict
        await enhanced_manager.context_broker.update_context(context_id, {
            "decision": {
                "action": "avoid caching due to memory constraints", 
                "task_id": "previous_task"
            },
            "task_id": "previous_task"
        })
        
        # Validate with context
        results = await enhanced_manager.validate_with_context(sample_enhanced_task, context_id)
        
        assert "context" in results
        context_result = results["context"]
        assert isinstance(context_result, ValidationResult)
        
        # Should detect potential conflict with previous decision
        # (avoiding caching vs implementing caching)
        assert len(context_result.warnings) > 0
    
    @pytest.mark.asyncio
    async def test_resource_prediction_validation(self, enhanced_manager, sample_enhanced_task):
        """Test validation with resource prediction"""
        # Ensure resource predictor is available
        assert enhanced_manager.resource_predictor is not None
        
        # Validate with resource prediction
        results = await enhanced_manager.validate_with_context(sample_enhanced_task)
        
        assert "resources" in results
        resource_result = results["resources"]
        assert isinstance(resource_result, ValidationResult)
        
        # Should have prediction metadata
        assert "prediction" in resource_result.metadata
        prediction_data = resource_result.metadata["prediction"]
        assert "tokens" in prediction_data
        assert "duration" in prediction_data
        assert "confidence" in prediction_data


class TestEnhancedOrchestrator:
    """Test Enhanced Orchestrator Integration"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def mock_tokens(self):
        return ["test_token_1", "test_token_2"]
    
    @pytest.fixture
    def enhanced_orchestrator(self, temp_dir, mock_tokens):
        """Create enhanced orchestrator for testing"""
        return EnhancedOrchestrator(
            output_dir=temp_dir,
            max_parallel=2,
            tokens=mock_tokens,
            enable_quality_gates=True,
            enable_monitoring=False,  # Disable for testing
            quality_gate_config={
                "gates": [
                    {
                        "gate_id": "test_gate",
                        "name": "Test Gate",
                        "description": "Test quality gate",
                        "validator_type": "basic",
                        "config": {}
                    }
                ],
                "phases": []
            }
        )
    
    @pytest.fixture
    def sample_enhanced_tasks(self):
        """Create sample enhanced tasks"""
        return [
            EnhancedAgentTask(
                task_id="enhanced_001",
                task_type="research",
                prompt="Research best practices for async programming",
                dependencies=[],
                quality_gates=["test_gate"],
                validation_required=True
            ),
            EnhancedAgentTask(
                task_id="enhanced_002", 
                task_type="code",
                prompt="Implement async functions based on research",
                dependencies=["enhanced_001"],
                quality_gates=[],
                validation_required=False
            )
        ]
    
    def test_enhanced_orchestrator_initialization(self, enhanced_orchestrator):
        """Test enhanced orchestrator initializes correctly"""
        assert enhanced_orchestrator.enable_quality_gates
        assert enhanced_orchestrator.quality_gate_manager is not None
        assert hasattr(enhanced_orchestrator, 'quality_metrics')
        assert hasattr(enhanced_orchestrator, 'monitoring_metrics')
    
    def test_create_enhanced_task(self, enhanced_orchestrator):
        """Test enhanced task creation utility"""
        task = enhanced_orchestrator.create_enhanced_task(
            task_id="util_test",
            task_type="test",
            prompt="Test enhanced task creation",
            dependencies=["dep1"],
            quality_gates=["gate1"],
            validation_required=True,
            agent_uuid="test-uuid-001"
        )
        
        assert isinstance(task, EnhancedAgentTask)
        assert task.task_id == "util_test"
        assert task.quality_gates == ["gate1"]
        assert task.agent_uuid == "test-uuid-001"
        assert task.validation_required
    
    @pytest.mark.asyncio 
    async def test_backward_compatibility(self, enhanced_orchestrator):
        """Test backward compatibility with regular AgentTasks"""
        # Create regular AgentTask (not Enhanced)
        regular_task = AgentTask(
            task_id="regular_task",
            task_type="test",
            prompt="Test backward compatibility",
            dependencies=[]
        )
        
        # Should be able to execute without errors
        # Mock the execute process to avoid actual claude calls
        with patch.object(enhanced_orchestrator, 'execute_agent_enhanced') as mock_execute:
            mock_execute.return_value = {
                "task_id": "regular_task",
                "status": "completed",
                "result": {"output": "test"}
            }
            
            result = await enhanced_orchestrator.execute_agent(regular_task)
            
            # Should return result without errors
            assert result["task_id"] == "regular_task"
    
    @pytest.mark.asyncio
    async def test_background_job_management(self, enhanced_orchestrator, sample_enhanced_tasks):
        """Test background job creation and management"""
        # Launch background team
        job_id = await enhanced_orchestrator.launch_background_team(
            sample_enhanced_tasks,
            team_id="test_team_001"
        )
        
        assert job_id in enhanced_orchestrator.background_jobs
        
        # Check job status
        job_status = await enhanced_orchestrator.get_background_job_status(job_id)
        assert job_status is not None
        assert job_status["job_id"] == job_id
        assert job_status["team_id"] == "test_team_001"
        assert job_status["status"] == "running"
        assert job_status["agent_count"] == len(sample_enhanced_tasks)


class TestRegressionProtection:
    """Test that self-improvements don't break existing functionality"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    def test_original_quality_gates_still_work(self, temp_dir):
        """Test original quality gate system still functions"""
        from working_quality_gates import QualityGateManager, TaskStructureGate
        
        # Create original quality gate manager
        original_manager = QualityGateManager(enabled_gates=["structure"])
        
        # Test with regular task
        task = AgentTask(
            task_id="regression_test",
            task_type="code", 
            prompt="Test regression protection",
            dependencies=[]
        )
        
        # Should work without errors
        assert original_manager.active_gates["structure"] is not None
        assert isinstance(original_manager.active_gates["structure"], TaskStructureGate)
    
    @pytest.mark.asyncio
    async def test_enhanced_manager_backwards_compatible(self, temp_dir):
        """Test enhanced manager works with original tasks"""
        enhanced_manager = create_enhanced_quality_manager(
            output_dir=temp_dir,
            enabled_gates=["structure", "dependencies"]
        )
        
        # Create regular task (not enhanced)
        regular_task = AgentTask(
            task_id="compat_test", 
            task_type="research",
            prompt="Test compatibility with regular tasks",
            dependencies=[]
        )
        
        # Should validate without errors
        results = await enhanced_manager.validate_pre_execution(regular_task)
        
        assert len(results) >= 2  # structure and dependencies gates
        assert all(isinstance(result, ValidationResult) for result in results.values())
    
    def test_enhanced_task_extends_regular_task(self):
        """Test EnhancedAgentTask properly extends AgentTask"""
        enhanced_task = EnhancedAgentTask(
            task_id="extend_test",
            task_type="test",
            prompt="Test inheritance",
            dependencies=[]
        )
        
        # Should be instance of both
        assert isinstance(enhanced_task, EnhancedAgentTask)
        assert isinstance(enhanced_task, AgentTask)
        
        # Should have all original properties
        assert hasattr(enhanced_task, 'task_id')
        assert hasattr(enhanced_task, 'task_type') 
        assert hasattr(enhanced_task, 'prompt')
        assert hasattr(enhanced_task, 'dependencies')
        assert hasattr(enhanced_task, 'status')
        assert hasattr(enhanced_task, 'result')
        
        # Should have enhanced properties
        assert hasattr(enhanced_task, 'quality_gates')
        assert hasattr(enhanced_task, 'agent_uuid')
        assert hasattr(enhanced_task, 'validation_required')


class TestPerformanceAndScaling:
    """Test performance characteristics of self-improvement features"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.mark.asyncio
    async def test_context_broker_performance(self, temp_dir):
        """Test context broker handles multiple concurrent operations"""
        broker = ContextBroker(temp_dir / "perf_contexts")
        
        # Create multiple contexts concurrently
        async def create_context_with_updates(plan_id: str):
            context_id = await broker.create_context(plan_id, {"test": "data"})
            
            # Perform multiple updates
            for i in range(10):
                await broker.update_context(context_id, {
                    "variables": {f"key_{i}": f"value_{i}"},
                    "decision": {"step": i, "action": f"action_{i}"},
                    "task_id": f"task_{i}"
                })
            
            return context_id
        
        # Run multiple contexts concurrently
        start_time = time.time()
        context_ids = await asyncio.gather(
            *[create_context_with_updates(f"plan_{i}") for i in range(5)]
        )
        end_time = time.time()
        
        assert len(context_ids) == 5
        assert all(cid in broker.active_contexts for cid in context_ids)
        
        # Should complete reasonably quickly
        assert (end_time - start_time) < 5.0  # Less than 5 seconds
    
    def test_resource_predictor_learning_speed(self, temp_dir):
        """Test resource predictor learning converges reasonably"""
        predictor = ResourcePredictor(temp_dir / "perf_history.json")
        
        # Record many similar tasks
        base_task = EnhancedAgentTask(
            task_id="perf_base",
            task_type="code",
            prompt="A" * 100,  # Consistent length
            dependencies=[],
            context={}
        )
        
        # Record executions with slight variations
        confidences = []
        for i in range(20):
            task = EnhancedAgentTask(
                task_id=f"perf_task_{i}",
                task_type="code",
                prompt="B" * (100 + i),  # Slight variation
                dependencies=[],
                context={}
            )
            
            metrics = TaskMetrics(
                duration=60.0 + (i * 2),  # Slight variation
                tokens_used=1000 + (i * 50),
                status="completed"
            )
            
            predictor.record_execution(task, metrics)
            
            # Test prediction confidence
            prediction = predictor.predict_resources(base_task)
            confidences.append(prediction.confidence)
        
        # Confidence should improve over time
        assert confidences[-1] > confidences[0]  # Later confidence > initial
        assert confidences[-1] > 0.7  # Should reach reasonable confidence
    
    @pytest.mark.asyncio
    async def test_agent_mesh_message_throughput(self):
        """Test agent mesh can handle high message volume"""
        mesh = AgentMesh("throughput_test")
        
        # Register multiple agents
        for i in range(10):
            mesh.register_agent(f"agent_{i}", [f"capability_{i}"])
        
        # Send many messages
        start_time = time.time()
        message_count = 100
        
        for i in range(message_count):
            sender = f"agent_{i % 10}"
            receiver = f"agent_{(i + 1) % 10}"
            
            message = Message(
                sender_id=sender,
                recipient_id=receiver,
                message_type="throughput_test",
                content={"msg_id": i, "data": "x" * 100},
                timestamp=time.time()
            )
            
            await mesh.send_message(message)
        
        end_time = time.time()
        
        # Should handle messages efficiently
        assert (end_time - start_time) < 2.0  # Less than 2 seconds for 100 messages
        
        # Verify all messages were queued
        total_queued = sum(len(mesh.message_queue[f"agent_{i}"]) for i in range(10))
        assert total_queued == message_count


# Integration test that runs a complete self-improvement cycle
class TestSelfImprovementIntegration:
    """Integration test for complete self-improvement workflow"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.mark.asyncio
    async def test_complete_self_improvement_cycle(self, temp_dir):
        """Test complete self-improvement cycle integration"""
        # Create enhanced orchestrator with all features
        orchestrator = EnhancedOrchestrator(
            output_dir=temp_dir,
            max_parallel=2,
            tokens=["test_token"],
            enable_quality_gates=True,
            enable_monitoring=False,  # Disable for testing
            quality_gate_config={
                "gates": [
                    {
                        "gate_id": "improvement_gate",
                        "name": "Self-Improvement Gate",
                        "description": "Validates self-improvement tasks",
                        "validator_type": "basic",
                        "config": {}
                    }
                ],
                "phases": [
                    {
                        "phase_id": "improvement_phase",
                        "name": "Self-Improvement Phase",
                        "description": "Phase for orchestrator self-improvement",
                        "gates": ["improvement_gate"]
                    }
                ]
            }
        )
        
        # Create self-improvement tasks
        improvement_tasks = [
            EnhancedAgentTask(
                task_id="analyze_performance",
                task_type="research", 
                prompt="Analyze current orchestrator performance metrics and identify improvement opportunities",
                dependencies=[],
                quality_gates=[],
                phase_id="improvement_phase",
                context={"self_improvement": True, "focus": "performance"}
            ),
            EnhancedAgentTask(
                task_id="design_optimization",
                task_type="design",
                prompt="Design optimization strategy based on performance analysis",
                dependencies=["analyze_performance"],
                quality_gates=["improvement_gate"],
                phase_id="improvement_phase",
                context={"self_improvement": True, "focus": "optimization"}
            ),
            EnhancedAgentTask(
                task_id="validate_improvements",
                task_type="test",
                prompt="Validate that proposed improvements maintain system reliability",
                dependencies=["design_optimization"],
                quality_gates=["improvement_gate"], 
                phase_id="improvement_phase",
                context={"self_improvement": True, "focus": "validation"}
            )
        ]
        
        # Test context-aware validation
        if orchestrator.quality_gate_manager:
            enhanced_manager = orchestrator.quality_gate_manager
            if hasattr(enhanced_manager, 'context_broker') and enhanced_manager.context_broker:
                # Create execution context
                context_id = await enhanced_manager.context_broker.create_context(
                    "self_improvement_plan",
                    {"goal": "enhance_orchestrator", "safety": "high_priority"}
                )
                
                # Validate tasks with context
                for task in improvement_tasks:
                    if hasattr(enhanced_manager, 'validate_with_context'):
                        results = await enhanced_manager.validate_with_context(task, context_id)
                        
                        # All validations should pass for well-formed tasks
                        for gate_name, result in results.items():
                            assert isinstance(result, ValidationResult)
                            # Warnings are okay, but no blocking issues
                            assert result.passed, f"Validation failed for {gate_name}: {result.issues}"
        
        # Test resource prediction
        if orchestrator.quality_gate_manager and hasattr(orchestrator.quality_gate_manager, 'resource_predictor'):
            predictor = orchestrator.quality_gate_manager.resource_predictor
            if predictor:
                for task in improvement_tasks:
                    prediction = predictor.predict_resources(task)
                    assert isinstance(prediction, ResourcePrediction)
                    assert prediction.estimated_tokens > 0
                    assert prediction.estimated_duration > 0
        
        # Test collaboration mesh
        if orchestrator.quality_gate_manager and hasattr(orchestrator.quality_gate_manager, 'agent_mesh'):
            mesh = orchestrator.quality_gate_manager.agent_mesh
            if mesh:
                # Register improvement agents
                mesh.register_agent("performance_analyst", ["performance", "metrics"])
                mesh.register_agent("optimization_designer", ["optimization", "architecture"])
                mesh.register_agent("validation_tester", ["testing", "validation"])
                
                # Test expert consultation for performance improvement
                consultation = await mesh.collaboration_patterns["expert_consultation"](
                    initiator_id="coordination_agent",
                    question="How to optimize task execution performance?",
                    domain="performance"
                )
                
                assert consultation["success"]
                assert "performance_analyst" in consultation["experts_consulted"]
        
        # Verify all features are working together
        assert orchestrator.enable_quality_gates
        assert orchestrator.quality_gate_manager is not None
        assert len(improvement_tasks) == 3
        assert all(task.context.get("self_improvement") for task in improvement_tasks)
        
        print("✅ Complete self-improvement integration test passed")
        print("   - Enhanced quality gates validated tasks")
        print("   - Resource prediction estimated requirements") 
        print("   - Context management tracked improvement goals")
        print("   - Collaboration mesh coordinated expert consultation")
        print("   - All components integrated successfully")


if __name__ == "__main__":
    """Run comprehensive tests"""
    print("🧪 Running Comprehensive Self-Improvement Tests")
    print("=" * 60)
    
    # Run pytest with verbose output
    exit_code = pytest.main([
        __file__, 
        "-v", 
        "--tb=short",
        "--asyncio-mode=auto"
    ])
    
    if exit_code == 0:
        print("\n✅ ALL SELF-IMPROVEMENT TESTS PASSED!")
        print("   Self-improvement features validated and working correctly")
        print("   No regressions detected in existing functionality")
    else:
        print("\n❌ SOME TESTS FAILED") 
        print("   Review test output above for details")
    
    sys.exit(exit_code)