#!/usr/bin/env python3
"""
Test script for the Real-Time Agent Status API
Tests integration with chat_search and basic functionality
"""

import asyncio
import json
import sys
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent))
sys.path.append(str(Path(__file__).parent / "src"))

try:
    from src.agent_monitor import AgentStatusMonitor, AgentStatus
    from src.log_parser import AgentLogParser
    print("✓ Successfully imported monitoring components")
except ImportError as e:
    print(f"✗ Import error: {e}")
    sys.exit(1)


def create_test_log_file(uuid: str, log_dir: Path):
    """Create a test log file for testing"""
    log_file = log_dir / f"{uuid}.jsonl"
    
    test_entries = [
        {
            "timestamp": "2025-01-01T10:00:00Z",
            "sessionId": uuid,
            "message": {
                "role": "user",
                "content": "Starting task: Build monitoring system"
            }
        },
        {
            "timestamp": "2025-01-01T10:01:00Z",
            "sessionId": uuid,
            "message": {
                "role": "assistant",
                "content": "I'll help you build a monitoring system. Let me start by creating the core components."
            }
        },
        {
            "timestamp": "2025-01-01T10:02:00Z",
            "sessionId": uuid,
            "message": {
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "id": "tool1",
                        "name": "Write",
                        "input": {
                            "file_path": "/tmp/monitor.py",
                            "content": "class Monitor: pass"
                        }
                    }
                ]
            }
        },
        {
            "timestamp": "2025-01-01T10:03:00Z",
            "sessionId": uuid,
            "message": {
                "role": "user",
                "content": "Tool result: File created successfully"
            }
        },
        {
            "timestamp": "2025-01-01T10:04:00Z",
            "sessionId": uuid,
            "message": {
                "role": "assistant",
                "content": "Task completed successfully. Progress: 100%"
            }
        }
    ]
    
    with open(log_file, 'w') as f:
        for entry in test_entries:
            f.write(json.dumps(entry) + '\n')
    
    return log_file


async def test_agent_status_monitor():
    """Test the AgentStatusMonitor class"""
    print("\n=== Testing AgentStatusMonitor ===")
    
    # Create test environment
    test_dir = Path("/tmp/test_monitoring")
    test_dir.mkdir(exist_ok=True)
    
    test_uuid = "12345678-1234-4567-8901-123456789012"
    
    # Create test log file
    log_file = create_test_log_file(test_uuid, test_dir)
    print(f"✓ Created test log file: {log_file}")
    
    # Initialize monitor
    try:
        monitor = AgentStatusMonitor(str(test_dir))
        print("✓ AgentStatusMonitor initialized successfully")
    except Exception as e:
        print(f"✗ Error initializing AgentStatusMonitor: {e}")
        return False
    
    # Test getting agent status
    try:
        status = await monitor.get_agent_status(test_uuid)
        print(f"✓ Retrieved agent status: {status.status}")
        print(f"  - Progress: {status.progress.progress_percentage}%")
        print(f"  - Error count: {status.error_count}")
        print(f"  - Last activity: {status.last_activity_timestamp}")
        print(f"  - Completed tasks: {len(status.progress.completed_tasks)}")
    except Exception as e:
        print(f"✗ Error getting agent status: {e}")
        return False
    
    # Test getting all agent statuses
    try:
        all_statuses = await monitor.get_all_agent_statuses()
        print(f"✓ Retrieved {len(all_statuses)} agent statuses")
    except Exception as e:
        print(f"✗ Error getting all agent statuses: {e}")
        return False
    
    print("✓ AgentStatusMonitor tests passed")
    return True


async def test_log_parser():
    """Test the AgentLogParser class"""
    print("\n=== Testing AgentLogParser ===")
    
    test_dir = Path("/tmp/test_monitoring")
    test_uuid = "12345678-1234-4567-8901-123456789012"
    
    try:
        parser = AgentLogParser(str(test_dir))
        print("✓ AgentLogParser initialized successfully")
    except Exception as e:
        print(f"✗ Error initializing AgentLogParser: {e}")
        return False
    
    # Test parsing progress
    try:
        progress = await parser.parse_agent_progress(test_uuid)
        print(f"✓ Parsed progress: {progress.progress_percentage}%")
        print(f"  - Current task: {progress.current_task}")
        print(f"  - Completed tasks: {len(progress.completed_tasks)}")
    except Exception as e:
        print(f"✗ Error parsing progress: {e}")
        return False
    
    # Test error detection
    try:
        errors = await parser.detect_agent_errors(test_uuid)
        print(f"✓ Detected {len(errors)} errors")
    except Exception as e:
        print(f"✗ Error detecting errors: {e}")
        return False
    
    # Test context usage check
    try:
        context_usage = await parser.check_context_usage(test_uuid)
        print(f"✓ Context usage: {context_usage:.1f}%")
    except Exception as e:
        print(f"✗ Error checking context usage: {e}")
        return False
    
    # Test deliverables extraction
    try:
        deliverables = await parser.get_agent_deliverables(test_uuid)
        print(f"✓ Found {len(deliverables)} deliverables: {deliverables}")
    except Exception as e:
        print(f"✗ Error getting deliverables: {e}")
        return False
    
    print("✓ AgentLogParser tests passed")
    return True


def test_chat_search_integration():
    """Test direct integration with chat_search"""
    print("\n=== Testing Chat Search Integration ===")
    
    try:
        # Try importing chat_search directly
        sys.path.append(str(Path(__file__).parent.parent / "chat-search"))
        from chat_search import ChatSearcher
        print("✓ Successfully imported ChatSearcher")
        
        # Test basic functionality
        test_dir = Path("/tmp/test_monitoring")
        searcher = ChatSearcher(str(test_dir))
        
        # Try searching for something in our test log
        results = searcher.search(
            query="monitoring",
            limit=5
        )
        print(f"✓ Search completed, found {len(results)} results")
        
        return True
        
    except Exception as e:
        print(f"✗ Chat search integration error: {e}")
        return False


async def test_real_monitoring():
    """Test with real Claude project logs if they exist"""
    print("\n=== Testing Real Monitoring (Optional) ===")
    
    # Check if real Claude logs exist
    real_logs_dir = Path.home() / ".claude" / "projects" / "-home-opsvi-master-root-apps-agent-orchestrator"
    
    if not real_logs_dir.exists():
        print("ℹ No real Claude logs found, skipping real monitoring test")
        return True
        
    try:
        monitor = AgentStatusMonitor(str(real_logs_dir))
        all_statuses = await monitor.get_all_agent_statuses()
        
        if all_statuses:
            print(f"✓ Found {len(all_statuses)} real agents")
            for uuid, status in list(all_statuses.items())[:3]:  # Show first 3
                print(f"  - {uuid[:8]}: {status.status}")
        else:
            print("ℹ No active agents found in real logs")
            
        return True
        
    except Exception as e:
        print(f"✗ Error testing real monitoring: {e}")
        return False


async def run_all_tests():
    """Run all monitoring tests"""
    print("=" * 60)
    print("Real-Time Agent Status API - Integration Tests")
    print("=" * 60)
    
    tests = [
        test_chat_search_integration,
        test_agent_status_monitor,
        test_log_parser,
        test_real_monitoring
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if asyncio.iscoroutinefunction(test):
                result = await test()
            else:
                result = test()
                
            if result:
                passed += 1
            else:
                failed += 1
                
        except Exception as e:
            print(f"✗ Test {test.__name__} failed with exception: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("Test Results Summary")
    print("=" * 60)
    print(f"✓ Passed: {passed}")
    print(f"✗ Failed: {failed}")
    print(f"Total: {passed + failed}")
    
    if failed == 0:
        print("\n🎉 All tests passed! Real-Time Agent Status API is ready.")
        return True
    else:
        print(f"\n⚠️ {failed} test(s) failed. Please check the errors above.")
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)