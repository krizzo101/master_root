#!/usr/bin/env python3
"""
Test the new UnifiedOrchestrator to verify consolidation success
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Test basic functionality first
def test_imports():
    """Test that we can import the UnifiedOrchestrator"""
    try:
        from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig
        from src.unified.enhanced_agent_task import EnhancedAgentTask
        print("✅ All imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False

async def test_basic_orchestration():
    """Test basic orchestration without extra features"""
    try:
        from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig
        from src.unified.enhanced_agent_task import EnhancedAgentTask
        
        # Create minimal config
        config = UnifiedConfig(
            output_dir=Path("test_unified_output"),
            max_parallel=2,
            enabled_features=set(),  # No extra features
            enable_collaboration=False,
            enable_quality_gates=False,
            enable_monitoring=False
        )
        
        # Create orchestrator
        orchestrator = UnifiedOrchestrator(config=config)
        
        # Create simple test task
        task = EnhancedAgentTask(
            task_id="test_basic_task",
            task_type="general-purpose",
            prompt="Echo 'UnifiedOrchestrator is working!' and create a test file with this message."
        )
        
        # Execute
        print("🧪 Testing basic orchestration...")
        results = await orchestrator.execute_batch([task])
        
        if results and len(results) > 0:
            result = results[0]
            status = result.get("status", "unknown")
            
            if status == "completed":
                print("✅ Basic orchestration works!")
                return True
            else:
                print(f"⚠️ Task status: {status}")
                if "error" in result:
                    print(f"Error: {result['error']}")
                return False
        else:
            print("❌ No results returned")
            return False
            
    except Exception as e:
        print(f"❌ Basic test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_enhanced_features():
    """Test with enhanced features enabled"""
    try:
        from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig, FeatureFlag
        from src.unified.enhanced_agent_task import EnhancedAgentTask
        
        # Create config with enhanced features
        config = UnifiedConfig(
            output_dir=Path("test_enhanced_output"),
            max_parallel=2,
            enabled_features={FeatureFlag.ENHANCED_METRICS, FeatureFlag.BACKGROUND_EXECUTION},
            enable_collaboration=False,
            enable_quality_gates=False,
            enable_monitoring=True
        )
        
        orchestrator = UnifiedOrchestrator(config=config)
        
        # Create enhanced task with UUID
        task = EnhancedAgentTask(
            task_id="test_enhanced_task",
            task_type="general-purpose",
            prompt="Test enhanced features - create a JSON file with current timestamp and UUID.",
            agent_uuid="test_agent_001",
            monitoring_enabled=True
        )
        
        print("🧪 Testing enhanced features...")
        results = await orchestrator.execute_batch([task])
        
        if results and results[0].get("status") == "completed":
            print("✅ Enhanced features work!")
            
            # Check if metrics were collected
            metrics = orchestrator.get_metrics()
            if metrics:
                print(f"📊 Metrics collected: {metrics}")
                
            return True
        else:
            print(f"⚠️ Enhanced test failed: {results[0] if results else 'No results'}")
            return False
            
    except Exception as e:
        print(f"❌ Enhanced test failed: {e}")
        return False

async def test_collaboration_features():
    """Test with collaboration features enabled"""
    try:
        from src.unified.unified_orchestrator import UnifiedOrchestrator, UnifiedConfig, FeatureFlag
        from src.unified.enhanced_agent_task import EnhancedAgentTask
        
        # Create config with collaboration
        config = UnifiedConfig(
            output_dir=Path("test_collaboration_output"),
            max_parallel=2,
            enabled_features={FeatureFlag.COLLABORATION, FeatureFlag.ENHANCED_METRICS},
            enable_collaboration=True,
            enable_quality_gates=False,
            enable_monitoring=False
        )
        
        orchestrator = UnifiedOrchestrator(config=config)
        
        # Create collaboration task
        task = EnhancedAgentTask(
            task_id="test_collaboration_task", 
            task_type="general-purpose",
            prompt="Test collaboration - create a team workspace and test file.",
            team_id="test_team_alpha",
            collaboration_mode="traditional"  # Start with traditional mode
        )
        
        print("🧪 Testing collaboration features...")
        results = await orchestrator.execute_batch([task])
        
        if results and results[0].get("status") == "completed":
            print("✅ Collaboration features work!")
            return True
        else:
            print(f"⚠️ Collaboration test failed: {results[0] if results else 'No results'}")
            return False
            
    except Exception as e:
        print(f"❌ Collaboration test failed: {e}")
        return False

async def main():
    """Run all tests"""
    print("🚀 TESTING UNIFIED ORCHESTRATOR")
    print("=" * 50)
    
    tests = [
        ("Import Test", test_imports),
        ("Basic Orchestration", test_basic_orchestration),
        ("Enhanced Features", test_enhanced_features), 
        ("Collaboration Features", test_collaboration_features)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n🔍 Running {test_name}...")
        try:
            if asyncio.iscoroutinefunction(test_func):
                result = await test_func()
            else:
                result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 OVERALL: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 ALL TESTS PASSED - UnifiedOrchestrator is ready!")
        return True
    elif passed > 0:
        print("⚠️ Some tests passed - partial functionality available")
        return True
    else:
        print("💥 All tests failed - check the implementation")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)