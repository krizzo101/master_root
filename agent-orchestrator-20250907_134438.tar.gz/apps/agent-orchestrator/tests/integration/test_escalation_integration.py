#!/usr/bin/env python3
"""
Test script for escalation integration layer

Tests:
1. Backward compatibility - existing orchestrator usage continues to work
2. EscalationAwareOrchestrator basic functionality
3. AgentTeamManager integration with escalation
4. Configuration options for enabling/disabling escalation
"""

import asyncio
import logging
import sys
import tempfile
from pathlib import Path

# Add src directory to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from escalation_integration import (
    EscalationAwareOrchestrator,
    EscalationConfig,
    create_development_orchestrator,
    create_production_orchestrator,
)
from enhanced_orchestrator import EnhancedOrchestrator
from generic_orchestrator import AgentTask, GenericOrchestrator
from agent_team_manager import AgentTeamManager, create_database_migration_team_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestEscalationIntegration:
    """Test suite for escalation integration layer"""

    def __init__(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.test_results = []

    async def test_backward_compatibility(self):
        """Test that existing orchestrator usage continues to work unchanged"""
        logger.info("Testing backward compatibility...")
        
        try:
            # Test GenericOrchestrator still works
            generic_orchestrator = GenericOrchestrator(
                output_dir=self.temp_dir / "generic_test",
                max_parallel=2
            )
            
            # Create a simple task
            def generate_test_tasks():
                return [
                    AgentTask(
                        task_id="test_task_1",
                        task_type="test",
                        prompt="This is a test task for backward compatibility testing."
                    )
                ]
            
            # This should work without any escalation features
            result = await generic_orchestrator.run(generate_test_tasks)
            
            assert result is not None, "GenericOrchestrator should return result"
            assert "metrics" in result, "Result should contain metrics"
            
            self.test_results.append(("backward_compatibility_generic", True, None))
            
            # Test EnhancedOrchestrator still works
            enhanced_orchestrator = EnhancedOrchestrator(
                output_dir=self.temp_dir / "enhanced_test",
                max_parallel=2,
                enable_quality_gates=False,  # Disable for simple test
                enable_monitoring=False,
            )
            
            result = await enhanced_orchestrator.run(generate_test_tasks)
            assert result is not None, "EnhancedOrchestrator should return result"
            
            self.test_results.append(("backward_compatibility_enhanced", True, None))
            
            logger.info("✓ Backward compatibility tests passed")
            
        except Exception as e:
            logger.error(f"✗ Backward compatibility test failed: {e}")
            self.test_results.append(("backward_compatibility", False, str(e)))

    async def test_escalation_aware_orchestrator_basic(self):
        """Test basic EscalationAwareOrchestrator functionality"""
        logger.info("Testing EscalationAwareOrchestrator basic functionality...")
        
        try:
            # Test with escalation disabled (should work like EnhancedOrchestrator)
            config_disabled = EscalationConfig(enable_escalation=False)
            
            orchestrator_disabled = EscalationAwareOrchestrator(
                output_dir=self.temp_dir / "escalation_disabled",
                max_parallel=2,
                enable_quality_gates=False,
                enable_monitoring=False,
                escalation_config=config_disabled,
            )
            
            def generate_test_tasks():
                return [
                    AgentTask(
                        task_id="test_task_disabled",
                        task_type="test",
                        prompt="Test with escalation disabled."
                    )
                ]
            
            result = await orchestrator_disabled.run(generate_test_tasks)
            assert result is not None, "Should work with escalation disabled"
            
            await orchestrator_disabled.shutdown()
            self.test_results.append(("escalation_disabled", True, None))
            
            # Test with escalation enabled
            config_enabled = EscalationConfig(
                enable_escalation=True,
                failure_threshold=2,
                enable_auto_replacement=True,
            )
            
            orchestrator_enabled = EscalationAwareOrchestrator(
                output_dir=self.temp_dir / "escalation_enabled",
                max_parallel=2,
                enable_quality_gates=False,
                enable_monitoring=False,
                escalation_config=config_enabled,
            )
            
            # Test escalation-aware task creation
            escalation_task = orchestrator_enabled.create_escalation_aware_task(
                task_id="test_escalation_task",
                task_type="test",
                prompt="Test escalation-aware task creation.",
                escalation_enabled=True,
                complexity_level="low",
            )
            
            assert escalation_task.escalation_enabled, "Task should have escalation enabled"
            assert escalation_task.complexity_level == "low", "Task should have correct complexity"
            
            await orchestrator_enabled.shutdown()
            self.test_results.append(("escalation_enabled", True, None))
            
            logger.info("✓ EscalationAwareOrchestrator basic tests passed")
            
        except Exception as e:
            logger.error(f"✗ EscalationAwareOrchestrator basic test failed: {e}")
            self.test_results.append(("escalation_aware_basic", False, str(e)))

    async def test_agent_team_manager_integration(self):
        """Test AgentTeamManager integration with escalation system"""
        logger.info("Testing AgentTeamManager escalation integration...")
        
        try:
            # Test with escalation disabled
            manager_disabled = AgentTeamManager(
                output_dir=self.temp_dir / "team_disabled",
                max_parallel=2,
                enable_quality_gates=False,
                enable_monitoring=False,
                enable_escalation=False,
            )
            
            # Should use standard EnhancedOrchestrator
            assert isinstance(manager_disabled.orchestrator, EnhancedOrchestrator)
            assert not isinstance(manager_disabled.orchestrator, EscalationAwareOrchestrator)
            
            dashboard_disabled = await manager_disabled.get_escalation_dashboard()
            assert not dashboard_disabled.get("escalation_enabled", True), "Should report escalation disabled"
            
            await manager_disabled.shutdown()
            self.test_results.append(("team_manager_disabled", True, None))
            
            # Test with escalation enabled
            escalation_config = EscalationConfig(
                enable_escalation=True,
                failure_threshold=2,
            )
            
            manager_enabled = AgentTeamManager(
                output_dir=self.temp_dir / "team_enabled",
                max_parallel=2,
                enable_quality_gates=False,
                enable_monitoring=False,
                enable_escalation=True,
                escalation_config=escalation_config,
            )
            
            # Should use EscalationAwareOrchestrator
            assert isinstance(manager_enabled.orchestrator, EscalationAwareOrchestrator)
            
            dashboard_enabled = await manager_enabled.get_escalation_dashboard()
            assert dashboard_enabled.get("escalation_enabled", False), "Should report escalation enabled"
            
            await manager_enabled.shutdown()
            self.test_results.append(("team_manager_enabled", True, None))
            
            logger.info("✓ AgentTeamManager integration tests passed")
            
        except Exception as e:
            logger.error(f"✗ AgentTeamManager integration test failed: {e}")
            self.test_results.append(("team_manager_integration", False, str(e)))

    async def test_factory_functions(self):
        """Test factory functions with escalation configuration"""
        logger.info("Testing factory functions...")
        
        try:
            # Test development orchestrator factory
            dev_orchestrator = create_development_orchestrator(
                output_dir=self.temp_dir / "dev_factory",
                enable_escalation=True,
            )
            
            assert isinstance(dev_orchestrator, EscalationAwareOrchestrator)
            assert dev_orchestrator.escalation_enabled
            
            await dev_orchestrator.shutdown()
            self.test_results.append(("factory_dev_orchestrator", True, None))
            
            # Test production orchestrator factory
            prod_orchestrator = create_production_orchestrator(
                output_dir=self.temp_dir / "prod_factory",
                enable_escalation=True,
            )
            
            assert isinstance(prod_orchestrator, EscalationAwareOrchestrator)
            assert prod_orchestrator.escalation_enabled
            # Production should have more conservative settings
            assert prod_orchestrator.escalation_config.failure_threshold >= 5
            
            await prod_orchestrator.shutdown()
            self.test_results.append(("factory_prod_orchestrator", True, None))
            
            # Test team manager factory
            team_manager = create_database_migration_team_manager(
                output_dir=self.temp_dir / "team_factory",
                database_url="postgresql://localhost:5432/test",
                enable_escalation=True,
            )
            
            assert isinstance(team_manager.orchestrator, EscalationAwareOrchestrator)
            assert team_manager.enable_escalation
            
            await team_manager.shutdown()
            self.test_results.append(("factory_team_manager", True, None))
            
            logger.info("✓ Factory function tests passed")
            
        except Exception as e:
            logger.error(f"✗ Factory function test failed: {e}")
            self.test_results.append(("factory_functions", False, str(e)))

    async def test_configuration_options(self):
        """Test various configuration options work correctly"""
        logger.info("Testing configuration options...")
        
        try:
            # Test different escalation configurations
            configs_to_test = [
                EscalationConfig(
                    enable_escalation=True,
                    enable_auto_replacement=True,
                    enable_sub_swarm_delegation=False,
                    failure_threshold=1,
                ),
                EscalationConfig(
                    enable_escalation=True,
                    enable_auto_replacement=False,
                    enable_sub_swarm_delegation=True,
                    failure_threshold=5,
                ),
                EscalationConfig(
                    enable_escalation=False,
                ),
            ]
            
            for i, config in enumerate(configs_to_test):
                orchestrator = EscalationAwareOrchestrator(
                    output_dir=self.temp_dir / f"config_test_{i}",
                    max_parallel=1,
                    enable_quality_gates=False,
                    enable_monitoring=False,
                    escalation_config=config,
                )
                
                assert orchestrator.escalation_enabled == config.enable_escalation
                if config.enable_escalation:
                    assert orchestrator.escalation_config.failure_threshold == config.failure_threshold
                
                await orchestrator.shutdown()
            
            self.test_results.append(("configuration_options", True, None))
            logger.info("✓ Configuration options tests passed")
            
        except Exception as e:
            logger.error(f"✗ Configuration options test failed: {e}")
            self.test_results.append(("configuration_options", False, str(e)))

    async def run_all_tests(self):
        """Run all integration tests"""
        logger.info("=" * 60)
        logger.info("Running Escalation Integration Tests")
        logger.info("=" * 60)
        
        await self.test_backward_compatibility()
        await self.test_escalation_aware_orchestrator_basic()
        await self.test_agent_team_manager_integration()
        await self.test_factory_functions()
        await self.test_configuration_options()
        
        # Print results
        logger.info("=" * 60)
        logger.info("Test Results Summary")
        logger.info("=" * 60)
        
        passed = 0
        failed = 0
        
        for test_name, success, error in self.test_results:
            status = "PASS" if success else "FAIL"
            logger.info(f"{test_name}: {status}")
            if error:
                logger.info(f"  Error: {error}")
            
            if success:
                passed += 1
            else:
                failed += 1
        
        logger.info("=" * 60)
        logger.info(f"Total: {passed + failed}, Passed: {passed}, Failed: {failed}")
        
        if failed == 0:
            logger.info("🎉 All tests passed! Integration layer is working correctly.")
            return True
        else:
            logger.error(f"❌ {failed} tests failed. Integration needs fixes.")
            return False


async def main():
    """Main test runner"""
    tester = TestEscalationIntegration()
    
    try:
        success = await tester.run_all_tests()
        return 0 if success else 1
    except Exception as e:
        logger.error(f"Test runner failed: {e}")
        return 1
    finally:
        # Cleanup temp directory
        import shutil
        try:
            shutil.rmtree(tester.temp_dir)
        except:
            pass


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))