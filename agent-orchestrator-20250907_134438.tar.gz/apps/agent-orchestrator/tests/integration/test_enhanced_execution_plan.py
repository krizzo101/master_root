#!/usr/bin/env python3
import asyncio
from pathlib import Path
from typing import Dict, List
import sys
import json

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask

# Import ExecutionPlan components
try:
    from execution_plan_schema import ExecutionPlan, TaskDefinition, ExecutionPhase, TaskType, ExecutionMode, TaskPriority
    from execution_plan_parser import ExecutionPlanParser
    EXECUTION_PLAN_AVAILABLE = True
    print("✅ ExecutionPlan components imported successfully")
except ImportError as e:
    print(f"❌ ExecutionPlan import failed: {e}")
    EXECUTION_PLAN_AVAILABLE = False

def create_execution_plan() -> ExecutionPlan:
    """Create ExecutionPlan using the schema system"""
    if not EXECUTION_PLAN_AVAILABLE:
        raise RuntimeError("ExecutionPlan not available")
    
    # Define tasks using ExecutionPlan schema
    tasks = [
        TaskDefinition(
            task_id="research_task",
            task_type=TaskType.RESEARCH,
            description="Research Python best practices for error handling and create a summary file",
            prompt="Research Python best practices for error handling and create a summary file called 'ep_research_summary.txt' with 3 key points",
            dependencies=[],
            priority=TaskPriority.HIGH,
            timeout_seconds=300
        ),
        TaskDefinition(
            task_id="implementation_task",
            task_type=TaskType.DEVELOPMENT_SPECIALIST,
            description="Create Python example demonstrating error handling",
            prompt="Based on the ep_research_summary.txt file, create a simple Python example script called 'ep_example.py' that demonstrates proper error handling",
            dependencies=["research_task"],
            priority=TaskPriority.NORMAL,
            timeout_seconds=300
        ),
        TaskDefinition(
            task_id="validation_task", 
            task_type=TaskType.QA_TESTING_GURU,
            description="Test and validate the implementation",
            prompt="Test the ep_example.py script by running it and create a test report called 'ep_test_results.txt' documenting whether it works correctly",
            dependencies=["implementation_task"],
            priority=TaskPriority.NORMAL,
            timeout_seconds=300
        )
    ]
    
    # Create execution phases
    phases = [
        ExecutionPhase(
            phase_id="discovery",
            phase_name="Research Phase",
            task_ids=["research_task"],
            description="Research and gather information"
        ),
        ExecutionPhase(
            phase_id="implementation",
            phase_name="Implementation Phase", 
            task_ids=["implementation_task"],
            description="Implement solution based on research"
        ),
        ExecutionPhase(
            phase_id="validation",
            phase_name="Validation Phase",
            task_ids=["validation_task"],
            description="Test and validate implementation"
        )
    ]
    
    # Create complete ExecutionPlan
    plan = ExecutionPlan(
        plan_id="enhanced_orchestrator_test",
        plan_name="Enhanced Orchestrator ExecutionPlan Test",
        description="Test ExecutionPlan integration with Enhanced Orchestrator",
        tasks=tasks,
        phases=phases,
        execution_mode=ExecutionMode.SEQUENTIAL,
        max_parallel_tasks=3
    )
    
    return plan

async def test_execution_plan_mode():
    """Test Enhanced Orchestrator with ExecutionPlan enabled"""
    print("🚀 Enhanced Orchestrator - ExecutionPlan Mode Test")
    print("=" * 60)
    
    if not EXECUTION_PLAN_AVAILABLE:
        print("❌ ExecutionPlan not available - skipping test")
        return False
    
    try:
        # Create ExecutionPlan
        execution_plan = create_execution_plan()
        print(f"✅ Created ExecutionPlan with {len(execution_plan.tasks)} tasks and {len(execution_plan.phases)} phases")
        
        # Create Enhanced Orchestrator with ExecutionPlan support
        orchestrator = EnhancedOrchestrator(
            output_dir=Path("test_enhanced_execution_plan_output"),
            max_parallel=3,
            enable_quality_gates=True,        # Enable quality gates
            enable_monitoring=True,           # Enable monitoring  
            use_optimizations=True
        )
        
        print("✅ Enhanced Orchestrator created with full features enabled")
        
        # Execute using ExecutionPlan
        print("🎯 Executing ExecutionPlan...")
        
        # Check if orchestrator has execute_plan method
        if hasattr(orchestrator, 'execute_plan'):
            result = await orchestrator.execute_plan(execution_plan)
            print("✅ ExecutionPlan executed successfully")
            
            # Check results
            metrics = result.get('metrics', {})
            success = metrics.get('completed', 0) == metrics.get('total', 0)
            
            print(f"📊 Results: {metrics.get('completed', 0)}/{metrics.get('total', 0)} tasks completed")
            print(f"⏱️  Average time: {metrics.get('total_duration', 0) / max(metrics.get('completed', 1), 1):.2f}s per task")
            
            return success
        else:
            print("❌ Orchestrator does not have execute_plan method")
            return False
            
    except Exception as e:
        print(f"❌ ExecutionPlan test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_fallback_with_execution_plan_tasks():
    """Test creating EnhancedAgentTasks from ExecutionPlan concepts but using regular orchestrator"""
    print("\n🔄 Enhanced Orchestrator - ExecutionPlan-Style Tasks (Fallback)")
    print("=" * 60)
    
    # Create enhanced tasks inspired by ExecutionPlan structure
    tasks = [
        EnhancedAgentTask(
            task_id="ep_research_task",
            task_type="research",
            prompt="Research Python best practices for error handling and create a summary file called 'ep_fallback_research.txt' with 3 key points",
            dependencies=[],
            quality_gates=["research_quality"],    # Enable quality gates
            validation_required=True,              # Enable validation
            phase_id="discovery",
            monitoring_enabled=True                # Enable monitoring
        ),
        EnhancedAgentTask(
            task_id="ep_implementation_task",
            task_type="development-specialist", 
            prompt="Based on the ep_fallback_research.txt file, create a simple Python example script called 'ep_fallback_example.py' that demonstrates proper error handling",
            dependencies=["ep_research_task"],
            quality_gates=["code_quality"],        # Enable quality gates
            validation_required=True,              # Enable validation  
            phase_id="implementation",
            monitoring_enabled=True                # Enable monitoring
        ),
        EnhancedAgentTask(
            task_id="ep_validation_task",
            task_type="qa-testing-guru",
            prompt="Test the ep_fallback_example.py script by running it and create a test report called 'ep_fallback_test_results.txt' documenting whether it works correctly",
            dependencies=["ep_implementation_task"],
            quality_gates=["validation_quality"],  # Enable quality gates
            validation_required=True,              # Enable validation
            phase_id="validation", 
            monitoring_enabled=True                # Enable monitoring
        )
    ]
    
    # Create Enhanced Orchestrator with all features enabled
    orchestrator = EnhancedOrchestrator(
        output_dir=Path("test_enhanced_full_features_output"),
        max_parallel=3,
        enable_quality_gates=True,        # Enable quality gates
        enable_monitoring=True,           # Enable monitoring
        use_optimizations=True
    )
    
    print(f"✅ Created Enhanced Orchestrator with all features enabled")
    print(f"📋 Generated {len(tasks)} ExecutionPlan-style enhanced tasks")
    
    # Execute using standard run method but with enhanced tasks
    try:
        result = await orchestrator.run(
            task_generator=lambda: tasks
        )
        
        metrics = result['metrics']
        success = metrics['completed'] == metrics['total']
        
        print(f"📊 Results: {metrics['completed']}/{metrics['total']} tasks completed")
        print(f"⏱️  Average time: {metrics.get('total_duration', 0) / max(metrics['completed'], 1):.2f}s per task")
        print(f"🎯 Success: {'✅' if success else '❌'}")
        
        return success
        
    except Exception as e:
        print(f"❌ Enhanced features test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def main():
    """Main test execution"""
    print("🎯 Enhanced Orchestrator ExecutionPlan Test Suite")
    print("=" * 70)
    
    # Test 1: Full ExecutionPlan mode (if available)
    execution_plan_success = await test_execution_plan_mode()
    
    # Test 2: ExecutionPlan-style tasks with enhanced features
    enhanced_features_success = await test_fallback_with_execution_plan_tasks()
    
    print("\n" + "=" * 70)
    print("📊 FINAL RESULTS:")
    print(f"   ExecutionPlan Mode: {'✅ SUCCESS' if execution_plan_success else '❌ FAILED/UNAVAILABLE'}")
    print(f"   Enhanced Features: {'✅ SUCCESS' if enhanced_features_success else '❌ FAILED'}")
    
    if execution_plan_success:
        print("\n🎉 Full ExecutionPlan integration working!")
    elif enhanced_features_success:
        print("\n✅ Enhanced Orchestrator with advanced features working!")
    else:
        print("\n❌ Both tests failed")
    
    return execution_plan_success or enhanced_features_success

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)