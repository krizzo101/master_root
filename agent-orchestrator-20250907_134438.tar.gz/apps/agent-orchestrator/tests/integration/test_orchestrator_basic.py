#!/usr/bin/env python3
"""
Basic Orchestrator Test - Quick Proof of Concept
Tests that the orchestrator works with simple, fast tasks
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime

# Add orchestrator to path
sys.path.insert(0, str(Path(__file__).parent))
from src.generic_orchestrator import GenericOrchestrator, AgentTask

def create_test_tasks():
    """Create simple, fast test tasks"""
    return [
        AgentTask(
            task_id="test_001_math",
            task_type="simple_calculation",
            prompt="""**MISSION: Quick Math Test**
            
            Perform this simple calculation and provide the answer:
            
            Calculate: (15 + 27) × 3 - 8
            
            **DELIVERABLES:**
            1. Show your work step by step
            2. Provide the final answer
            3. Verify the result by working backwards
            
            Keep this brief - should take less than 30 seconds."""
        ),
        
        AgentTask(
            task_id="test_002_file",
            task_type="file_operations",
            prompt="""**MISSION: File Operations Test**
            
            Create a simple test file to verify file operations work.
            
            **REQUIREMENTS:**
            1. Write a file called "test_output.txt" with current timestamp
            2. Read the file back and verify contents
            3. Create a summary of what you did
            
            **DELIVERABLES:**
            - Confirmation that file operations work
            - Brief summary of actions taken
            
            Keep this simple and fast."""
        ),
        
        AgentTask(
            task_id="test_003_synthesis", 
            task_type="synthesis",
            prompt="""**MISSION: Synthesis Test**
            
            Review the outputs from the math and file operation tests.
            Create a brief synthesis report.
            
            **REQUIREMENTS:**
            1. Summarize what the other agents accomplished
            2. Confirm orchestrator is working properly
            3. Note any issues or successes
            
            **DELIVERABLES:**
            - Brief test summary report
            - Overall orchestrator health assessment""",
            dependencies=["test_001_math", "test_002_file"]
        )
    ]

async def main():
    print("🧪 BASIC ORCHESTRATOR TEST")
    print("=" * 50)
    print("Testing with 3 simple, fast tasks")
    
    # Create timestamped output directory  
    output_dir = Path(f"test_basic_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    
    # Setup orchestrator - small parallel for quick test
    orchestrator = GenericOrchestrator(
        output_dir=output_dir,
        max_parallel=3  # Run all 3 tasks as fast as possible
    )
    
    print(f"📁 Output: {output_dir}")
    print(f"📋 Debug: {orchestrator.log_file}")
    print(f"🎯 Max parallel: {orchestrator.max_parallel}")
    print()
    
    # Custom result processor for clear test feedback
    async def test_result_processor(tasks, results):
        print("\n" + "=" * 50)
        print("🧪 TEST RESULTS")
        print("=" * 50)
        
        passed = 0
        failed = 0
        
        for task, result in zip(tasks, results):
            status = "✅ PASS" if result.get('status') == 'completed' else "❌ FAIL"
            runtime = result.get('end_time', 0) - result.get('start_time', 0)
            
            print(f"{status} {task.task_id} ({runtime:.1f}s)")
            
            if result.get('status') == 'completed':
                passed += 1
            else:
                failed += 1
                print(f"   Error: {result.get('error', 'Unknown error')}")
        
        print(f"\n📊 SUMMARY: {passed} passed, {failed} failed")
        
        if failed == 0:
            print("🎉 ALL TESTS PASSED - Orchestrator is working!")
        else:
            print("⚠️  Some tests failed - check debug logs")
        
        return {"passed": passed, "failed": failed}
    
    # Run the test
    try:
        print("🚀 Starting test execution...")
        
        results = await orchestrator.run(
            task_generator=create_test_tasks,
            result_processor=test_result_processor
        )
        
        print(f"\n📁 Full results saved to: {output_dir}")
        print(f"📋 Debug logs: {orchestrator.log_file}")
        
        # Quick validation
        if results and results.get('metrics', {}).get('failed', 1) == 0:
            print("\n✅ ORCHESTRATOR TEST: SUCCESS")
            return True
        else:
            print("\n❌ ORCHESTRATOR TEST: FAILED")
            return False
        
    except Exception as e:
        print(f"\n💥 TEST EXECUTION FAILED: {e}")
        print(f"📋 Check logs: {orchestrator.log_file}")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)