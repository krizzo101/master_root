#!/usr/bin/env python3
"""
Integration tests for Enhanced Swarm Log Tailer
"""

import asyncio
import json
import os
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any
import random
import string

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enhanced_swarm_log_tailer import (
    EnhancedSwarmLogTailer,
    SystemConfig,
    SwarmConfig,
    VisualConfig,
    OutputConfig,
    LogParser,
    LogEntry
)

class TestDataGenerator:
    """Generate realistic Claude Code log data for testing"""
    
    @staticmethod
    def generate_session_id() -> str:
        """Generate random session ID"""
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    
    @staticmethod
    def generate_agent_id() -> str:
        """Generate random agent ID"""
        return f"agent_{TestDataGenerator.generate_session_id()[:8]}"
    
    @staticmethod
    def generate_log_entry(
        entry_type: str = "message",
        timestamp: datetime = None,
        agent_id: str = None,
        session_id: str = None,
        content: str = None,
        tool_use: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Generate a single log entry"""
        if timestamp is None:
            timestamp = datetime.now()
        
        entry = {
            "type": entry_type,
            "timestamp": timestamp.isoformat() + "Z",
            "uuid": TestDataGenerator.generate_session_id(),
            "session_id": session_id or TestDataGenerator.generate_session_id(),
            "agent_id": agent_id or TestDataGenerator.generate_agent_id(),
        }
        
        if content:
            entry["content"] = content
        
        if tool_use:
            entry["tool_use"] = tool_use
        
        return entry
    
    @staticmethod
    def generate_swarm_burst(
        num_agents: int = 5,
        burst_duration_seconds: float = 2.0,
        base_time: datetime = None
    ) -> List[Dict[str, Any]]:
        """Generate a burst of activity simulating a swarm"""
        if base_time is None:
            base_time = datetime.now()
        
        entries = []
        agents = [TestDataGenerator.generate_agent_id() for _ in range(num_agents)]
        session_id = TestDataGenerator.generate_session_id()
        
        # Generate entries for each agent within burst window
        for i, agent_id in enumerate(agents):
            # Add time offset within burst window
            time_offset = random.uniform(0, burst_duration_seconds)
            entry_time = base_time + timedelta(seconds=time_offset)
            
            # Generate multiple entries per agent
            for j in range(random.randint(3, 10)):
                entry = TestDataGenerator.generate_log_entry(
                    entry_type=random.choice(["message", "tool_use", "response"]),
                    timestamp=entry_time + timedelta(milliseconds=j * 100),
                    agent_id=agent_id,
                    session_id=session_id,
                    content=f"Swarm activity from {agent_id} - message {j}"
                )
                entries.append(entry)
        
        return sorted(entries, key=lambda x: x["timestamp"])
    
    @staticmethod
    def generate_normal_activity(
        num_agents: int = 3,
        duration_seconds: float = 60.0,
        base_time: datetime = None
    ) -> List[Dict[str, Any]]:
        """Generate normal (non-swarm) agent activity"""
        if base_time is None:
            base_time = datetime.now()
        
        entries = []
        agents = [TestDataGenerator.generate_agent_id() for _ in range(num_agents)]
        
        for agent_id in agents:
            session_id = TestDataGenerator.generate_session_id()
            
            # Generate sparse entries over time period
            num_entries = random.randint(5, 15)
            for i in range(num_entries):
                time_offset = random.uniform(0, duration_seconds)
                entry = TestDataGenerator.generate_log_entry(
                    entry_type=random.choice(["message", "tool_use", "response"]),
                    timestamp=base_time + timedelta(seconds=time_offset),
                    agent_id=agent_id,
                    session_id=session_id,
                    content=f"Normal activity from {agent_id} - message {i}"
                )
                entries.append(entry)
        
        return sorted(entries, key=lambda x: x["timestamp"])
    
    @staticmethod
    def write_log_file(file_path: Path, entries: List[Dict[str, Any]]) -> None:
        """Write log entries to JSONL file"""
        with open(file_path, 'w') as f:
            for entry in entries:
                f.write(json.dumps(entry) + '\n')


class IntegrationTests:
    """Integration test suite for Enhanced Swarm Log Tailer"""
    
    def __init__(self):
        self.test_results = []
        self.test_dir = None
        self.start_time = None
    
    def setup(self):
        """Setup test environment"""
        self.test_dir = Path(tempfile.mkdtemp(prefix="swarm_test_"))
        self.projects_dir = self.test_dir / ".claude" / "projects"
        self.projects_dir.mkdir(parents=True, exist_ok=True)
        self.start_time = datetime.now()
        print(f"Test directory: {self.test_dir}")
        print(f"Projects directory: {self.projects_dir}")
    
    def teardown(self):
        """Cleanup test environment"""
        if self.test_dir and self.test_dir.exists():
            import shutil
            shutil.rmtree(self.test_dir)
    
    def log_result(self, test_name: str, passed: bool, details: str = "", duration_ms: float = 0):
        """Log test result"""
        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "details": details,
            "duration_ms": duration_ms
        })
        
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status}: {test_name}")
        if details:
            print(f"  Details: {details}")
        if duration_ms > 0:
            print(f"  Duration: {duration_ms:.2f}ms")
    
    async def test_swarm_detection_accuracy(self):
        """Test swarm detection with known swarm patterns"""
        test_name = "Swarm Detection Accuracy"
        start = time.time()
        
        try:
            # Create test data with 3 swarms
            swarm1_entries = TestDataGenerator.generate_swarm_burst(
                num_agents=5, 
                burst_duration_seconds=1.0
            )
            
            swarm2_entries = TestDataGenerator.generate_swarm_burst(
                num_agents=8, 
                burst_duration_seconds=2.0,
                base_time=datetime.now() + timedelta(seconds=10)
            )
            
            swarm3_entries = TestDataGenerator.generate_swarm_burst(
                num_agents=15, 
                burst_duration_seconds=3.0,
                base_time=datetime.now() + timedelta(seconds=20)
            )
            
            # Add normal activity
            normal_entries = TestDataGenerator.generate_normal_activity(
                num_agents=3,
                duration_seconds=30
            )
            
            # Write to log files
            all_entries = swarm1_entries + swarm2_entries + swarm3_entries + normal_entries
            log_file = self.projects_dir / "test_swarm_detection.jsonl"
            TestDataGenerator.write_log_file(log_file, all_entries)
            
            # Configure and run tailer
            config = SystemConfig(
                projects_dir=self.projects_dir,
                pattern="*.jsonl",
                include_historical=True
            )
            
            swarm_config = SwarmConfig(
                enabled=True,
                time_window_seconds=60,
                min_agents=3
            )
            
            visual_config = VisualConfig(use_color=False, use_emoji=False)
            output_config = OutputConfig(quiet=True)
            
            tailer = EnhancedSwarmLogTailer(
                system_config=config,
                swarm_config=swarm_config,
                visual_config=visual_config,
                output_config=output_config
            )
            
            # Process events
            files = await tailer.file_monitor.discover_files()
            
            # Read and parse all entries
            events = []
            for file_path in files:
                with open(file_path, 'r') as f:
                    for line in f:
                        entry = LogParser.parse_line(line)
                        if entry:
                            from enhanced_swarm_log_tailer import LogEvent, AgentInfo
                            event = LogEvent(
                                entry=entry,
                                agent_info=AgentInfo(
                                    agent_id=entry.agent_id,
                                    session_id=entry.session_id,
                                    project_path=file_path.parent
                                )
                            )
                            events.append(event)
            
            # Detect swarms
            swarms = await tailer.swarm_detector.detect_swarms(events)
            
            # Validate results
            num_swarms = len(swarms)
            expected_swarms = 3  # We created 3 swarms
            
            passed = num_swarms >= expected_swarms - 1  # Allow some tolerance
            details = f"Detected {num_swarms} swarms (expected ~{expected_swarms})"
            
            if swarms:
                details += f", Sizes: {[len(s.agents) for s in swarms.values()]}"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def test_performance_large_files(self):
        """Test performance with large number of log entries"""
        test_name = "Performance with Large Files"
        start = time.time()
        
        try:
            # Generate large dataset
            num_entries = 10000
            entries = []
            base_time = datetime.now() - timedelta(hours=1)
            
            print(f"  Generating {num_entries} log entries...")
            
            for i in range(num_entries):
                entry = TestDataGenerator.generate_log_entry(
                    timestamp=base_time + timedelta(seconds=i * 0.1),
                    content=f"Performance test entry {i}"
                )
                entries.append(entry)
            
            # Write to file
            log_file = self.projects_dir / "test_performance.jsonl"
            TestDataGenerator.write_log_file(log_file, entries)
            
            # Measure processing time
            parse_start = time.time()
            
            parsed_count = 0
            with open(log_file, 'r') as f:
                for line in f:
                    entry = LogParser.parse_line(line)
                    if entry:
                        parsed_count += 1
            
            parse_duration = time.time() - parse_start
            parse_rate = parsed_count / parse_duration if parse_duration > 0 else 0
            
            passed = parse_rate > 1000  # Should parse > 1000 entries/second
            details = f"Parsed {parsed_count} entries in {parse_duration:.2f}s ({parse_rate:.0f} entries/sec)"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def test_concurrent_file_monitoring(self):
        """Test monitoring multiple files concurrently"""
        test_name = "Concurrent File Monitoring"
        start = time.time()
        
        try:
            # Create multiple log files
            num_files = 20
            print(f"  Creating {num_files} log files...")
            
            for i in range(num_files):
                entries = TestDataGenerator.generate_normal_activity(
                    num_agents=2,
                    duration_seconds=10
                )
                log_file = self.projects_dir / f"test_concurrent_{i:02d}.jsonl"
                TestDataGenerator.write_log_file(log_file, entries)
            
            # Configure tailer
            config = SystemConfig(
                projects_dir=self.projects_dir,
                pattern="*.jsonl",
                max_files=num_files,
                worker_threads=10
            )
            
            # Discover files
            from enhanced_swarm_log_tailer import AsyncFileMonitor
            monitor = AsyncFileMonitor(config)
            files = await monitor.discover_files()
            
            passed = len(files) == num_files
            details = f"Found {len(files)}/{num_files} files"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def test_terminal_output_formatting(self):
        """Test terminal output formatting and color management"""
        test_name = "Terminal Output Formatting"
        start = time.time()
        
        try:
            from enhanced_swarm_log_tailer import ColorManager, DisplayManager
            
            # Test color manager
            visual_config = VisualConfig(
                use_color=True,
                use_emoji=True,
                color_scheme="default"
            )
            
            color_manager = ColorManager(visual_config)
            display_manager = DisplayManager(color_manager, visual_config)
            
            # Test color assignment
            agent_ids = ["agent1", "agent2", "agent3"]
            colors = []
            
            for agent_id in agent_ids:
                color = await color_manager.assign_color(agent_id)
                colors.append(color)
            
            # Verify unique colors assigned
            unique_colors = len(set(colors))
            
            # Test formatting
            from enhanced_swarm_log_tailer import LogEvent, LogEntry, AgentInfo
            
            test_entry = LogEntry(
                type="message",
                timestamp=datetime.now(),
                uuid="test-uuid",
                session_id="test-session",
                agent_id="agent1",
                content="Test message content"
            )
            
            test_event = LogEvent(
                entry=test_entry,
                agent_info=AgentInfo(
                    agent_id="agent1",
                    session_id="test-session",
                    project_path=Path("/test")
                )
            )
            
            formatted = await display_manager.format_event(test_event)
            
            passed = unique_colors == len(agent_ids) and len(formatted) > 0
            details = f"Assigned {unique_colors} unique colors, formatted output length: {len(formatted)}"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def test_error_handling(self):
        """Test error handling and edge cases"""
        test_name = "Error Handling"
        start = time.time()
        
        try:
            # Test invalid JSON parsing
            invalid_json = '{"invalid": json}'
            parsed = LogParser.parse_line(invalid_json)
            test1_passed = parsed is None
            
            # Test empty line parsing
            empty_parsed = LogParser.parse_line("")
            test2_passed = empty_parsed is None
            
            # Test missing timestamp
            no_timestamp = json.dumps({"type": "message", "content": "test"})
            parsed_no_ts = LogParser.parse_line(no_timestamp)
            test3_passed = parsed_no_ts is not None  # Should handle missing timestamp
            
            # Test non-existent directory
            config = SystemConfig(
                projects_dir=Path("/non/existent/directory"),
                pattern="*.jsonl"
            )
            
            from enhanced_swarm_log_tailer import AsyncFileMonitor
            monitor = AsyncFileMonitor(config)
            files = await monitor.discover_files()
            test4_passed = len(files) == 0  # Should return empty list
            
            all_passed = test1_passed and test2_passed and test3_passed and test4_passed
            details = f"Invalid JSON: {test1_passed}, Empty line: {test2_passed}, "
            details += f"Missing timestamp: {test3_passed}, Non-existent dir: {test4_passed}"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, all_passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def test_memory_management(self):
        """Test memory management with large buffers"""
        test_name = "Memory Management"
        start = time.time()
        
        try:
            from collections import deque
            
            # Test event buffer with maxlen
            buffer = deque(maxlen=1000)
            
            # Add more than maxlen items
            for i in range(2000):
                buffer.append(f"item_{i}")
            
            test1_passed = len(buffer) == 1000
            
            # Test that oldest items were removed
            test2_passed = "item_999" not in buffer and "item_1000" in buffer
            
            passed = test1_passed and test2_passed
            details = f"Buffer size limited: {test1_passed}, Old items removed: {test2_passed}"
            
            duration = (time.time() - start) * 1000
            self.log_result(test_name, passed, details, duration)
            
        except Exception as e:
            self.log_result(test_name, False, f"Error: {str(e)}")
    
    async def run_all_tests(self):
        """Run all integration tests"""
        print("\n" + "="*70)
        print("Running Integration Tests for Enhanced Swarm Log Tailer")
        print("="*70 + "\n")
        
        self.setup()
        
        try:
            # Run tests
            await self.test_swarm_detection_accuracy()
            await self.test_performance_large_files()
            await self.test_concurrent_file_monitoring()
            await self.test_terminal_output_formatting()
            await self.test_error_handling()
            await self.test_memory_management()
            
            # Print summary
            print("\n" + "="*70)
            print("Test Summary")
            print("="*70)
            
            total_tests = len(self.test_results)
            passed_tests = sum(1 for r in self.test_results if r["passed"])
            failed_tests = total_tests - passed_tests
            
            print(f"Total Tests: {total_tests}")
            print(f"Passed: {passed_tests}")
            print(f"Failed: {failed_tests}")
            
            if failed_tests > 0:
                print("\nFailed Tests:")
                for result in self.test_results:
                    if not result["passed"]:
                        print(f"  - {result['test']}: {result['details']}")
            
            total_duration = (datetime.now() - self.start_time).total_seconds()
            print(f"\nTotal Runtime: {total_duration:.2f} seconds")
            
            return failed_tests == 0
            
        finally:
            self.teardown()


async def main():
    """Main entry point for integration tests"""
    tests = IntegrationTests()
    success = await tests.run_all_tests()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())