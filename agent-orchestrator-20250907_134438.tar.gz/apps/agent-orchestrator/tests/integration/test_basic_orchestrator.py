#!/usr/bin/env python3
"""
Basic Test Execution Plan for Generic Orchestrator
This script demonstrates the generic orchestrator with a simple multi-stage workflow
"""

import asyncio
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.generic_orchestrator import AgentTask, GenericOrchestrator


def generate_basic_test_tasks() -> List[AgentTask]:
    """Generate a basic test execution plan with dependencies"""
    
    tasks = []
    
    # Task 1: Initial setup and environment check
    tasks.append(AgentTask(
        task_id="setup_001",
        task_type="setup",
        prompt="""You are a setup agent. Perform initial environment validation:

1. Check current working directory and list its contents
2. Verify Python version and basic system info
3. Create a simple test file called 'orchestrator_test.txt' with timestamp
4. Report environment status

Provide a brief summary of the setup status.""",
        dependencies=[],
        context={"phase": "initialization", "priority": "high"}
    ))
    
    # Task 2: Data preparation (depends on setup)
    tasks.append(AgentTask(
        task_id="data_prep_001",
        task_type="data_processing",
        prompt="""You are a data preparation agent. Your task:

1. Read the orchestrator_test.txt file created by the setup agent
2. Create a JSON data structure with sample test data:
   - 10 random numbers between 1-100
   - Current timestamp
   - Test metadata
3. Save this as 'test_data.json'
4. Validate the JSON structure is correct

Report the data preparation results and file contents.""",
        dependencies=["setup_001"],
        context={"phase": "data_preparation", "priority": "normal"}
    ))
    
    # Task 3: Analysis task (depends on data prep)
    tasks.append(AgentTask(
        task_id="analysis_001",
        task_type="analysis",
        prompt="""You are an analysis agent. Analyze the prepared data:

1. Read the test_data.json file
2. Calculate statistics on the random numbers:
   - Mean, median, min, max
   - Standard deviation if possible
3. Create a summary analysis report
4. Save results as 'analysis_results.json'

Provide insights about the data patterns found.""",
        dependencies=["data_prep_001"],
        context={"phase": "analysis", "priority": "normal"}
    ))
    
    # Task 4: Parallel processing task 1 (also depends on data prep)
    tasks.append(AgentTask(
        task_id="process_001",
        task_type="processing",
        prompt="""You are a processing agent (Worker 1). Process the data:

1. Read test_data.json
2. Filter numbers greater than 50
3. Sort them in descending order
4. Save as 'processed_high_numbers.json'
5. Count how many numbers were processed

Report processing results and count.""",
        dependencies=["data_prep_001"],
        context={"phase": "parallel_processing", "priority": "normal", "worker": 1}
    ))
    
    # Task 5: Parallel processing task 2 (also depends on data prep)
    tasks.append(AgentTask(
        task_id="process_002",
        task_type="processing", 
        prompt="""You are a processing agent (Worker 2). Process the data:

1. Read test_data.json
2. Filter numbers less than or equal to 50
3. Sort them in ascending order
4. Save as 'processed_low_numbers.json'
5. Count how many numbers were processed

Report processing results and count.""",
        dependencies=["data_prep_001"],
        context={"phase": "parallel_processing", "priority": "normal", "worker": 2}
    ))
    
    # Task 6: Final aggregation (depends on analysis and both processing tasks)
    tasks.append(AgentTask(
        task_id="aggregate_001",
        task_type="aggregation",
        prompt="""You are an aggregation agent. Combine all results:

1. Read analysis_results.json, processed_high_numbers.json, processed_low_numbers.json
2. Create a comprehensive final report including:
   - Original data summary
   - Analysis statistics
   - High numbers processing results
   - Low numbers processing results
   - Total processing summary
3. Save as 'final_report.json'
4. Also create a human-readable summary as 'final_summary.txt'

Provide the final comprehensive summary of the entire workflow.""",
        dependencies=["analysis_001", "process_001", "process_002"],
        context={"phase": "aggregation", "priority": "high"}
    ))
    
    return tasks


async def process_test_results(results: List[Dict]):
    """Process and display test results"""
    print("\n" + "="*60)
    print("🎯 TEST EXECUTION RESULTS")
    print("="*60)
    
    completed = 0
    failed = 0
    
    for result in results:
        task_id = result.get('task_id', 'unknown')
        status = result.get('status', 'unknown')
        task_type = result.get('task_type', 'unknown')
        
        if status == 'completed':
            completed += 1
            print(f"✅ {task_id} ({task_type}): COMPLETED")
            
            # Show execution time if available
            start_time = result.get('start_time')
            end_time = result.get('end_time')
            if start_time and end_time:
                duration = end_time - start_time
                print(f"   Duration: {duration:.2f}s")
        else:
            failed += 1
            print(f"❌ {task_id} ({task_type}): {status.upper()}")
            error = result.get('error')
            if error:
                print(f"   Error: {error}")
    
    print(f"\n📊 Summary: {completed} completed, {failed} failed")
    print("="*60)


async def run_basic_test():
    """Run the basic orchestrator test"""
    
    print("🚀 GENERIC ORCHESTRATOR BASIC TEST")
    print("="*60)
    print(f"Start time: {datetime.now()}")
    print("="*60)
    
    # Create output directory for this test
    test_output_dir = Path("quick_test_output")
    test_output_dir.mkdir(exist_ok=True)
    
    try:
        # Create orchestrator with basic settings
        orchestrator = GenericOrchestrator(
            output_dir=test_output_dir,
            max_parallel=3,  # Allow 3 parallel tasks
            tokens=None,     # Use default token loading
            use_optimizations=True
        )
        
        print(f"📁 Output directory: {test_output_dir.absolute()}")
        print(f"⚡ Max parallel tasks: 3")
        print("🎬 Starting orchestration...\n")
        
        # Run the orchestration
        result = await orchestrator.run(
            task_generator=generate_basic_test_tasks,
            result_processor=process_test_results
        )
        
        # Display final metrics
        metrics = result.get('metrics', {})
        print("\n" + "="*60)
        print("📈 FINAL METRICS")
        print("="*60)
        print(f"Total tasks: {metrics.get('total', 0)}")
        print(f"Completed: {metrics.get('completed', 0)}")
        print(f"Failed: {metrics.get('failed', 0)}")
        
        if metrics.get('completed', 0) > 0:
            avg_time = metrics.get('total_duration', 0) / metrics.get('completed', 1)
            print(f"Average task time: {avg_time:.2f}s")
        
        start_time = metrics.get('start_time')
        end_time = metrics.get('end_time')
        if start_time and end_time:
            print(f"Total execution time: {start_time} → {end_time}")
        
        print("="*60)
        
        # Check if test was successful
        success_rate = metrics.get('completed', 0) / max(metrics.get('total', 1), 1)
        if success_rate >= 0.8:  # 80% success rate
            print("🎉 TEST PASSED! Generic orchestrator working correctly.")
            return True
        else:
            print("❌ TEST FAILED! Too many task failures.")
            return False
            
    except Exception as e:
        print(f"\n💥 ORCHESTRATOR ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    try:
        success = asyncio.run(run_basic_test())
        if success:
            print("\n✅ Basic orchestrator test completed successfully!")
            sys.exit(0)
        else:
            print("\n❌ Basic orchestrator test failed!")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        sys.exit(1)