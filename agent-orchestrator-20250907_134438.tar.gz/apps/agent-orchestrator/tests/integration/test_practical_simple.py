#!/usr/bin/env python3
import asyncio
from pathlib import Path
from typing import Dict, List
import sys

# Add src to Python path  
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.practical_orchestrator import PracticalOrchestrator, PracticalAgentTask

def generate_simple_tasks() -> List[PracticalAgentTask]:
    """Simple tasks to test PracticalOrchestrator functionality"""
    return [
        PracticalAgentTask(
            task_id="research_task",
            task_type="research", 
            prompt="Research Python best practices for error handling and create a summary file called 'research_summary.txt' with 3 key points",
            dependencies=[],
            phase_id="discovery",
            priority="high",
            tags=["research", "python"]
        ),
        PracticalAgentTask(
            task_id="implementation_task",
            task_type="development-specialist",
            prompt="Based on the research_summary.txt file, create a simple Python example script called 'example.py' that demonstrates proper error handling", 
            dependencies=["research_task"],
            phase_id="implementation", 
            priority="normal",
            tags=["coding", "python"]
        ),
        PracticalAgentTask(
            task_id="validation_task",
            task_type="qa-testing-guru",
            prompt="Test the example.py script by running it and create a test report called 'test_results.txt' documenting whether it works correctly",
            dependencies=["implementation_task"],
            phase_id="validation",
            priority="normal", 
            tags=["testing", "validation"]
        )
    ]

async def main():
    """Test PracticalOrchestrator with monitoring"""
    print("🚀 Testing PracticalOrchestrator (Simple Version)")
    print("=" * 50)
    
    # Create orchestrator - use string path to avoid issues
    orchestrator = PracticalOrchestrator(
        output_dir="test_practical_simple_output",
        max_parallel=7,
        enable_monitoring=True,
        enable_quality_reports=True
    )

    # Add progress monitoring
    def progress_handler(event_type: str, data: Dict):
        print(f"📊 {event_type}: {data}")

    orchestrator.set_progress_callback(progress_handler)

    # Generate tasks
    tasks = generate_simple_tasks()
    print(f"Generated {len(tasks)} enhanced tasks")

    # Execute using parent's execute_batch to avoid the broken _execute_task method
    print("Starting execution...")
    results = await orchestrator.execute_batch(tasks)

    print(f"\n✅ Results: {len(results)} tasks completed")
    
    # Show enhanced features
    orchestrator.print_session_map()
    
    return len(results) == 3

if __name__ == "__main__":
    success = asyncio.run(main())
    print(f"Success: {success}")
    exit(0 if success else 1)