#!/usr/bin/env python3
"""
Unit Tests for Enhanced Quality Gates System

Focused unit tests for each component of the enhanced quality gates:
- IntelligentQualityGate with ML validation
- ContextBroker with shared execution context  
- ResourcePredictor with ML-based predictions
- PlanAdaptationEngine with dynamic adaptation
- AgentMesh with inter-agent collaboration

Each test is isolated and tests specific functionality in detail.
"""

import asyncio
import json
import tempfile
import time
import uuid
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
import statistics

# Import components under test
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from enhanced_quality_gates import (
    ContextBroker,
    ExecutionContext, 
    ResourcePredictor,
    ResourcePrediction,
    TaskMetrics,
    PlanAdaptationEngine,
    AgentMesh,
    Message,
    IntelligentQualityGate,
    EnhancedQualityGateManager
)

from enhanced_orchestrator import EnhancedAgentTask
from working_quality_gates import ValidationResult


class TestExecutionContext:
    """Test ExecutionContext data structure"""
    
    def test_execution_context_creation(self):
        """Test ExecutionContext initialization"""
        context = ExecutionContext(
            context_id="ctx_001",
            plan_id="plan_001", 
            global_variables={"version": "1.0"},
            shared_artifacts={},
            decision_history=[],
            cross_task_knowledge={}
        )
        
        assert context.context_id == "ctx_001"
        assert context.plan_id == "plan_001"
        assert context.global_variables["version"] == "1.0"
        assert isinstance(context.shared_artifacts, dict)
        assert isinstance(context.decision_history, list)
        assert isinstance(context.cross_task_knowledge, dict)
    
    def test_execution_context_defaults(self):
        """Test ExecutionContext with default values"""
        context = ExecutionContext(
            context_id="ctx_002",
            plan_id="plan_002"
        )
        
        assert context.global_variables == {}
        assert context.shared_artifacts == {}
        assert context.decision_history == []
        assert context.cross_task_knowledge == {}


class TestContextBrokerDetailed:
    """Detailed unit tests for ContextBroker"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def context_broker(self, temp_dir):
        return ContextBroker(temp_dir / "contexts")
    
    @pytest.mark.asyncio
    async def test_context_id_generation(self, context_broker):
        """Test context ID generation format"""
        plan_id = "test_plan_123"
        context_id = await context_broker.create_context(plan_id)
        
        # Should follow format: ctx_{plan_id}_{8_char_hex}
        assert context_id.startswith(f"ctx_{plan_id}_")
        
        parts = context_id.split("_")
        assert len(parts) == 4  # ctx, test, plan, 123, hex
        assert len(parts[-1]) == 8  # 8 character hex suffix
    
    @pytest.mark.asyncio 
    async def test_context_variable_updates(self, context_broker):
        """Test specific variable update scenarios"""
        context_id = await context_broker.create_context("var_test", {"initial": "value"})
        
        # Update with new variables
        await context_broker.update_context(context_id, {
            "variables": {"status": "running", "progress": 0.25}
        })
        
        context = context_broker.active_contexts[context_id]
        assert context.global_variables["initial"] == "value"  # Preserved
        assert context.global_variables["status"] == "running"  # Added
        assert context.global_variables["progress"] == 0.25    # Added
        
        # Update existing variables
        await context_broker.update_context(context_id, {
            "variables": {"status": "completed", "result": "success"}
        })
        
        assert context.global_variables["status"] == "completed"  # Updated
        assert context.global_variables["progress"] == 0.25       # Preserved
        assert context.global_variables["result"] == "success"    # Added
    
    @pytest.mark.asyncio
    async def test_artifact_path_handling(self, context_broker):
        """Test shared artifact path management"""
        context_id = await context_broker.create_context("artifact_test")
        
        # Add artifacts
        artifacts = {
            "output.txt": Path("/tmp/output.txt"),
            "data.json": Path("/home/user/data.json"),
            "log.txt": Path("relative/path/log.txt")
        }
        
        await context_broker.update_context(context_id, {
            "artifacts": artifacts
        })
        
        context = context_broker.active_contexts[context_id]
        assert len(context.shared_artifacts) == 3
        assert context.shared_artifacts["output.txt"] == Path("/tmp/output.txt")
        assert isinstance(context.shared_artifacts["data.json"], Path)
    
    @pytest.mark.asyncio
    async def test_decision_history_ordering(self, context_broker):
        """Test decision history maintains chronological order"""
        context_id = await context_broker.create_context("decision_test")
        
        # Add decisions with delays to test timestamp ordering
        decisions = [
            {"decision": "start_phase_1", "task_id": "task_1"},
            {"decision": "retry_failed_task", "task_id": "task_2"},
            {"decision": "skip_optional_step", "task_id": "task_3"}
        ]
        
        for i, decision in enumerate(decisions):
            await context_broker.update_context(context_id, decision)
            # Small delay to ensure different timestamps
            await asyncio.sleep(0.01)
        
        context = context_broker.active_contexts[context_id]
        history = context.decision_history
        
        assert len(history) == 3
        
        # Check timestamps are in ascending order
        timestamps = [d["timestamp"] for d in history]
        assert timestamps == sorted(timestamps)
        
        # Check decisions are in order
        assert history[0]["decision"] == "start_phase_1"
        assert history[1]["decision"] == "retry_failed_task"
        assert history[2]["decision"] == "skip_optional_step"
    
    @pytest.mark.asyncio
    async def test_cross_task_knowledge_accumulation(self, context_broker):
        """Test cross-task knowledge accumulation"""
        context_id = await context_broker.create_context("knowledge_test")
        
        # Add knowledge from different tasks
        await context_broker.update_context(context_id, {
            "knowledge": {
                "patterns_found": ["pattern_a", "pattern_b"],
                "performance_metrics": {"avg_time": 120.5}
            }
        })
        
        await context_broker.update_context(context_id, {
            "knowledge": {
                "patterns_found": ["pattern_c"],  # Should merge
                "error_patterns": ["timeout", "connection_error"],
                "performance_metrics": {"max_memory": 256}  # Should merge
            }
        })
        
        context = context_broker.active_contexts[context_id]
        knowledge = context.cross_task_knowledge
        
        # Should have merged patterns_found
        assert "patterns_found" in knowledge
        # Should have both performance metrics
        assert knowledge["performance_metrics"]["avg_time"] == 120.5
        assert knowledge["performance_metrics"]["max_memory"] == 256
        assert "error_patterns" in knowledge
    
    def test_decision_relevance_logic(self, context_broker):
        """Test decision relevance determination"""
        decision = {
            "task_id": "task_a",
            "decision": "use_caching_strategy",
            "timestamp": time.time()
        }
        
        # Different task - should be relevant (to share knowledge)
        assert context_broker._is_decision_relevant(decision, "task_b")
        
        # Same task - should not be relevant (avoid self-reference)
        assert not context_broker._is_decision_relevant(decision, "task_a")
    
    @pytest.mark.asyncio
    async def test_subscriber_notification_isolation(self, context_broker):
        """Test subscriber notifications don't interfere with each other"""
        context_id = await context_broker.create_context("notify_isolation_test")
        
        # Set up multiple subscribers
        notifications_1 = []
        notifications_2 = []
        error_notifications = []
        
        async def subscriber_1(ctx_id, updates):
            notifications_1.append((ctx_id, updates))
        
        async def subscriber_2(ctx_id, updates):
            notifications_2.append((ctx_id, updates))
        
        async def error_subscriber(ctx_id, updates):
            error_notifications.append((ctx_id, updates))
            raise Exception("Subscriber error")
        
        context_broker.subscribe_to_context_updates(context_id, subscriber_1)
        context_broker.subscribe_to_context_updates(context_id, subscriber_2)
        context_broker.subscribe_to_context_updates(context_id, error_subscriber)
        
        # Update context
        updates = {"variables": {"test": "isolation"}}
        await context_broker.update_context(context_id, updates)
        
        # All subscribers should receive notification
        assert len(notifications_1) == 1
        assert len(notifications_2) == 1
        assert len(error_notifications) == 1
        
        # Error in one subscriber shouldn't affect others
        assert notifications_1[0] == (context_id, updates)
        assert notifications_2[0] == (context_id, updates)


class TestResourcePredictorDetailed:
    """Detailed unit tests for ResourcePredictor"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def resource_predictor(self, temp_dir):
        return ResourcePredictor(temp_dir / "resource_test.json")
    
    def test_task_feature_extraction(self, resource_predictor):
        """Test feature extraction from tasks"""
        task = EnhancedAgentTask(
            task_id="feature_test",
            task_type="code",
            prompt="A" * 500,  # 500 chars
            dependencies=["dep1", "dep2", "dep3"],  # 3 deps
            context={"complexity": "high", "domain": "ml"},
            quality_gates=["performance", "security"]
        )
        
        prediction = resource_predictor.predict_resources(task)
        
        # Verify prediction structure
        assert isinstance(prediction, ResourcePrediction)
        assert prediction.estimated_tokens > 0
        assert prediction.estimated_duration > 0
        assert 0 <= prediction.parallel_compatibility <= 1
        assert prediction.optimal_batch_size > 0
        assert 0 <= prediction.confidence <= 1
    
    def test_similarity_scoring_algorithm(self, resource_predictor):
        """Test task similarity scoring accuracy"""
        # Create base task and record execution
        base_task = EnhancedAgentTask(
            task_id="base_task",
            task_type="research",
            prompt="X" * 200,
            dependencies=["dep1"],
            context={}
        )
        
        resource_predictor.record_execution(base_task, TaskMetrics(duration=60.0, tokens_used=1000))
        
        # Test various similarity scenarios
        test_cases = [
            # Very similar task
            {
                "task": EnhancedAgentTask(
                    task_id="similar_1",
                    task_type="research",  # Same type
                    prompt="Y" * 190,      # Similar length (200 vs 190)
                    dependencies=["dep2"], # Same count
                    context={}
                ),
                "expected_similarity": "high"
            },
            # Moderately similar task
            {
                "task": EnhancedAgentTask(
                    task_id="moderate_1", 
                    task_type="research",  # Same type
                    prompt="Z" * 400,      # Different length (200 vs 400)
                    dependencies=["dep1", "dep2", "dep3"], # Different count
                    context={}
                ),
                "expected_similarity": "moderate"
            },
            # Dissimilar task
            {
                "task": EnhancedAgentTask(
                    task_id="different_1",
                    task_type="code",      # Different type
                    prompt="A" * 1000,     # Very different length
                    dependencies=[],       # Different count
                    context={}
                ),
                "expected_similarity": "low"
            }
        ]
        
        for case in test_cases:
            features = {
                "task_type": case["task"].task_type,
                "prompt_length": len(case["task"].prompt),
                "context_size": len(json.dumps(case["task"].context)),
                "dependencies_count": len(case["task"].dependencies),
                "has_quality_gates": len(getattr(case["task"], 'quality_gates', [])) > 0
            }
            
            similar_tasks = resource_predictor._find_similar_tasks(features)
            
            if case["expected_similarity"] == "high":
                assert len(similar_tasks) > 0, f"Should find similar tasks for {case['task'].task_id}"
            elif case["expected_similarity"] == "low":
                # May or may not find similar tasks due to threshold
                pass  # This is acceptable
    
    def test_parallel_compatibility_calculation(self, resource_predictor):
        """Test parallel compatibility scoring logic"""
        # Test task with many dependencies (should reduce parallel score)
        high_dep_task = EnhancedAgentTask(
            task_id="high_dep",
            task_type="code",
            prompt="Test high dependencies",
            dependencies=[f"dep_{i}" for i in range(5)]  # 5 dependencies
        )
        
        # Test task with few dependencies
        low_dep_task = EnhancedAgentTask(
            task_id="low_dep", 
            task_type="research",
            prompt="Test low dependencies",
            dependencies=["dep_1"]  # 1 dependency
        )
        
        high_dep_score = resource_predictor._calculate_parallel_compatibility(high_dep_task, [])
        low_dep_score = resource_predictor._calculate_parallel_compatibility(low_dep_task, [])
        
        # High dependency task should have lower parallel compatibility
        assert high_dep_score < low_dep_score
        
        # Test task type effects
        review_task = EnhancedAgentTask(
            task_id="review_task",
            task_type="review",  # Should reduce compatibility
            prompt="Review code",
            dependencies=[]
        )
        
        review_score = resource_predictor._calculate_parallel_compatibility(review_task, [])
        
        # Review tasks should have lower parallel compatibility
        assert review_score < 0.7  # Base score reduced
    
    def test_optimal_batch_size_logic(self, resource_predictor):
        """Test optimal batch size determination"""
        test_cases = [
            {"task_type": "code", "expected_max": 2},
            {"task_type": "design", "expected_max": 2}, 
            {"task_type": "research", "expected_max": 4},
            {"task_type": "documentation", "expected_max": 4},
            {"task_type": "unknown_type", "expected_max": 3}
        ]
        
        for case in test_cases:
            features = {"task_type": case["task_type"]}
            batch_size = resource_predictor._determine_optimal_batch_size(features, [])
            
            assert batch_size <= case["expected_max"], f"Batch size {batch_size} too high for {case['task_type']}"
            assert batch_size > 0, f"Batch size must be positive for {case['task_type']}"
    
    def test_pattern_analysis_accuracy(self, resource_predictor):
        """Test pattern analysis statistical accuracy"""
        # Record multiple executions of same task type
        executions = [
            {"duration": 100.0, "tokens": 1000, "success": True},
            {"duration": 110.0, "tokens": 1100, "success": True},
            {"duration": 90.0, "tokens": 900, "success": False},
            {"duration": 105.0, "tokens": 1050, "success": True},
            {"duration": 95.0, "tokens": 950, "success": True}
        ]
        
        for i, exec_data in enumerate(executions):
            task = EnhancedAgentTask(
                task_id=f"pattern_task_{i}",
                task_type="algorithm",
                prompt="Test pattern analysis",
                dependencies=[]
            )
            
            metrics = TaskMetrics(
                duration=exec_data["duration"],
                tokens_used=exec_data["tokens"],
                status="completed" if exec_data["success"] else "failed"
            )
            
            resource_predictor.record_execution(task, metrics)
        
        # Check computed patterns
        assert "algorithm" in resource_predictor.task_patterns
        pattern = resource_predictor.task_patterns["algorithm"]
        
        assert pattern["count"] == 5
        
        # Check average duration calculation
        expected_avg_duration = sum(e["duration"] for e in executions) / len(executions)
        assert abs(pattern["avg_duration"] - expected_avg_duration) < 1.0
        
        # Check average tokens calculation 
        expected_avg_tokens = sum(e["tokens"] for e in executions) / len(executions)
        assert abs(pattern["avg_tokens"] - expected_avg_tokens) < 10
        
        # Check success rate calculation
        expected_success_rate = sum(1 for e in executions if e["success"]) / len(executions)
        assert abs(pattern["success_rate"] - expected_success_rate) < 0.01


class TestPlanAdaptationEngineDetailed:
    """Detailed unit tests for PlanAdaptationEngine"""
    
    @pytest.fixture
    def mock_orchestrator(self):
        mock = MagicMock()
        mock.quality_gate_manager = MagicMock()
        return mock
    
    @pytest.fixture
    def adaptation_engine(self, mock_orchestrator):
        return PlanAdaptationEngine(mock_orchestrator)
    
    @pytest.fixture
    def mock_plan(self):
        mock = MagicMock()
        mock.id = "test_plan_001"
        mock.tasks = []
        return mock
    
    def test_adaptation_strategy_registration(self, adaptation_engine):
        """Test adaptation strategies are properly registered"""
        expected_strategies = {
            'task_failure',
            'resource_constraint', 
            'quality_gate_failure',
            'dependency_change'
        }
        
        assert set(adaptation_engine.adaptation_strategies.keys()) == expected_strategies
        
        # All strategies should be callable
        for strategy in adaptation_engine.adaptation_strategies.values():
            assert callable(strategy)
    
    @pytest.mark.asyncio
    async def test_failure_analysis_categories(self, adaptation_engine):
        """Test failure analysis categorization accuracy"""
        test_cases = [
            # Transient errors
            {"error": "Connection timeout occurred while contacting server", "expected": "transient"},
            {"error": "Temporary network failure - please retry", "expected": "transient"},
            {"error": "Service temporarily unavailable", "expected": "transient"},
            
            # Resource limitation errors
            {"error": "Memory limit exceeded: requested 2GB, available 1GB", "expected": "resource_limitation"},
            {"error": "Process limit exceeded - too many concurrent processes", "expected": "resource_limitation"},
            {"error": "File too large to process in available memory", "expected": "resource_limitation"},
            
            # Approach mismatch errors
            {"error": "Invalid approach for this type of task", "expected": "approach_mismatch"},
            {"error": "Method not supported by current system", "expected": "approach_mismatch"},
            {"error": "Incompatible with target environment", "expected": "approach_mismatch"},
            
            # Unknown errors
            {"error": "Mysterious quantum flux detected in coffee machine", "expected": "unknown"},
            {"error": "Error code XYZ-999: Contact system administrator", "expected": "unknown"}
        ]
        
        for case in test_cases:
            analysis = await adaptation_engine._analyze_failure(case["error"])
            assert analysis["category"] == case["expected"], f"Failed for: {case['error']}"
            assert 0.5 <= analysis["confidence"] <= 1.0, f"Invalid confidence for: {case['error']}"
    
    @pytest.mark.asyncio
    async def test_adaptation_history_tracking(self, adaptation_engine, mock_plan):
        """Test adaptation history is properly recorded"""
        # Perform multiple adaptations
        contexts = [
            {"failed_task_id": "task_001", "error": "timeout"},
            {"constraint_type": "memory_limit", "available": "512MB"},
            {"failed_gates": {"performance": "too_slow"}}
        ]
        
        triggers = ["task_failure", "resource_constraint", "quality_gate_failure"]
        
        for trigger, context in zip(triggers, contexts):
            await adaptation_engine.adapt_plan(mock_plan, trigger, context)
        
        # Check history was recorded
        assert len(adaptation_engine.adaptation_history) == 3
        
        # Check history details
        for i, record in enumerate(adaptation_engine.adaptation_history):
            assert record["trigger"] == triggers[i]
            assert record["original_plan_id"] == "test_plan_001"
            assert "timestamp" in record
            assert "context" in record
            assert record["context"] == contexts[i]
    
    @pytest.mark.asyncio
    async def test_task_failure_adaptation_logic(self, adaptation_engine, mock_plan):
        """Test task failure adaptation decision logic"""
        # Test transient failure -> retry
        transient_context = {
            "failed_task_id": "task_retry", 
            "error": "Connection timeout - temporary network issue"
        }
        
        with patch.object(adaptation_engine, '_add_retry_to_plan') as mock_retry:
            mock_retry.return_value = mock_plan
            
            await adaptation_engine._handle_task_failure(mock_plan, transient_context)
            mock_retry.assert_called_once_with(mock_plan, "task_retry")
        
        # Test resource limitation -> decompose
        resource_context = {
            "failed_task_id": "task_decompose",
            "error": "Memory limit exceeded - task too large"
        }
        
        with patch.object(adaptation_engine, '_decompose_task_in_plan') as mock_decompose:
            mock_decompose.return_value = mock_plan
            
            await adaptation_engine._handle_task_failure(mock_plan, resource_context)
            mock_decompose.assert_called_once_with(mock_plan, "task_decompose")
        
        # Test unknown failure -> skip
        unknown_context = {
            "failed_task_id": "task_skip",
            "error": "Unknown system error occurred"
        }
        
        with patch.object(adaptation_engine, '_skip_task_in_plan') as mock_skip:
            mock_skip.return_value = mock_plan
            
            await adaptation_engine._handle_task_failure(mock_plan, unknown_context)
            mock_skip.assert_called_once_with(mock_plan, "task_skip")
    
    @pytest.mark.asyncio
    async def test_adaptation_context_preservation(self, adaptation_engine, mock_plan):
        """Test that adaptation context is preserved correctly"""
        detailed_context = {
            "failed_task_id": "complex_task",
            "error": "Multi-step process failed at step 3 of 5",
            "step_details": {
                "step_1": "completed",
                "step_2": "completed", 
                "step_3": "failed_validation",
                "step_4": "not_started",
                "step_5": "not_started"
            },
            "recovery_options": ["retry_step_3", "skip_to_step_4", "rollback"],
            "user_preferences": {"max_retries": 3, "auto_skip": False}
        }
        
        await adaptation_engine.adapt_plan(mock_plan, "task_failure", detailed_context)
        
        # Verify context was preserved in history
        history_record = adaptation_engine.adaptation_history[0]
        preserved_context = history_record["context"]
        
        assert preserved_context["failed_task_id"] == "complex_task"
        assert preserved_context["step_details"]["step_3"] == "failed_validation"
        assert preserved_context["user_preferences"]["max_retries"] == 3


class TestAgentMeshDetailed:
    """Detailed unit tests for AgentMesh"""
    
    @pytest.fixture
    def agent_mesh(self):
        return AgentMesh("detailed_test_mesh")
    
    def test_mesh_id_generation(self):
        """Test mesh ID generation"""
        # Test custom mesh ID
        custom_mesh = AgentMesh("custom_mesh_id")
        assert custom_mesh.mesh_id == "custom_mesh_id"
        
        # Test auto-generated mesh ID
        auto_mesh = AgentMesh()
        assert auto_mesh.mesh_id.startswith("mesh_")
        assert len(auto_mesh.mesh_id.split("_")[1]) == 8  # 8 char hex
    
    def test_agent_capability_matching(self, agent_mesh):
        """Test capability-based agent matching"""
        # Register agents with different capabilities
        agent_mesh.register_agent("generalist", ["general", "documentation"])
        agent_mesh.register_agent("backend_expert", ["python", "database", "api"])
        agent_mesh.register_agent("frontend_expert", ["javascript", "react", "css"])
        agent_mesh.register_agent("devops_expert", ["docker", "kubernetes", "monitoring"])
        
        # Test finding agents by capability
        agents_with_database = [
            agent_id for agent_id, info in agent_mesh.active_agents.items()
            if "database" in info.get("capabilities", [])
        ]
        assert "backend_expert" in agents_with_database
        assert len(agents_with_database) == 1
        
        agents_with_general = [
            agent_id for agent_id, info in agent_mesh.active_agents.items()
            if "general" in info.get("capabilities", [])
        ]
        assert "generalist" in agents_with_general
    
    def test_message_queue_management(self, agent_mesh):
        """Test message queue behavior and limits"""
        agent_mesh.register_agent("sender", [])
        agent_mesh.register_agent("receiver", [])
        
        # Send messages up to queue limit
        messages_sent = []
        for i in range(150):  # More than maxlen=100
            message = Message(
                sender_id="sender",
                recipient_id="receiver",
                message_type="test",
                content={"msg_num": i},
                timestamp=time.time()
            )
            messages_sent.append(message)
            
            # Use asyncio.run for each message to avoid async context issues
            asyncio.run(agent_mesh.send_message(message))
        
        # Queue should be limited to 100 messages
        receiver_queue = agent_mesh.message_queue["receiver"]
        assert len(receiver_queue) == 100
        
        # Should contain the latest 100 messages (50-149)
        latest_messages = list(receiver_queue)
        assert latest_messages[0].content["msg_num"] == 50  # Oldest in queue
        assert latest_messages[-1].content["msg_num"] == 149  # Newest in queue
    
    @pytest.mark.asyncio
    async def test_message_priority_handling(self, agent_mesh):
        """Test message priority doesn't affect basic delivery (priority is informational)"""
        agent_mesh.register_agent("sender", [])
        agent_mesh.register_agent("receiver", [])
        
        # Send messages with different priorities
        messages = [
            Message("sender", "receiver", "low_priority", {"data": "low"}, time.time(), priority=1),
            Message("sender", "receiver", "high_priority", {"data": "high"}, time.time(), priority=5),
            Message("sender", "receiver", "med_priority", {"data": "med"}, time.time(), priority=3)
        ]
        
        for message in messages:
            await agent_mesh.send_message(message)
        
        # Retrieve messages (priority is informational, FIFO order maintained)
        received = await agent_mesh.get_messages("receiver", limit=5)
        assert len(received) == 3
        
        # Messages should be in FIFO order
        assert received[0].content["data"] == "low"
        assert received[1].content["data"] == "high" 
        assert received[2].content["data"] == "med"
    
    @pytest.mark.asyncio
    async def test_message_correlation(self, agent_mesh):
        """Test message correlation ID handling"""
        agent_mesh.register_agent("requester", [])
        agent_mesh.register_agent("responder", [])
        
        correlation_id = f"corr_{uuid.uuid4().hex[:8]}"
        
        # Send request with correlation ID
        request = Message(
            sender_id="requester",
            recipient_id="responder", 
            message_type="request",
            content={"query": "status_check"},
            timestamp=time.time(),
            correlation_id=correlation_id
        )
        
        await agent_mesh.send_message(request)
        
        # Send response with same correlation ID
        response = Message(
            sender_id="responder",
            recipient_id="requester",
            message_type="response", 
            content={"status": "ok"},
            timestamp=time.time(),
            correlation_id=correlation_id
        )
        
        await agent_mesh.send_message(response)
        
        # Retrieve and verify correlation
        responder_messages = await agent_mesh.get_messages("responder")
        requester_messages = await agent_mesh.get_messages("requester")
        
        assert len(responder_messages) == 1
        assert len(requester_messages) == 1
        
        assert responder_messages[0].correlation_id == correlation_id
        assert requester_messages[0].correlation_id == correlation_id
    
    def test_agent_status_tracking(self, agent_mesh):
        """Test agent status and activity tracking"""
        before_registration = time.time()
        
        agent_mesh.register_agent("tracked_agent", ["tracking", "monitoring"])
        
        after_registration = time.time()
        
        agent_info = agent_mesh.active_agents["tracked_agent"]
        
        assert agent_info["status"] == "active"
        assert agent_info["capabilities"] == ["tracking", "monitoring"]
        assert agent_info["message_count"] == 0
        assert before_registration <= agent_info["last_seen"] <= after_registration
        
        # Send message to update message count
        asyncio.run(agent_mesh.send_message(Message(
            sender_id="tracked_agent",
            recipient_id="tracked_agent", 
            message_type="self_test",
            content={},
            timestamp=time.time()
        )))
        
        # Message count should increase
        assert agent_mesh.active_agents["tracked_agent"]["message_count"] == 1


class TestIntelligentQualityGate:
    """Unit tests for IntelligentQualityGate"""
    
    @pytest.fixture
    def temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)
    
    @pytest.fixture
    def resource_predictor(self, temp_dir):
        return ResourcePredictor(temp_dir / "intelligent_gate_test.json")
    
    @pytest.fixture
    def intelligent_gate(self, resource_predictor):
        return IntelligentQualityGate("ml_enhanced_gate", resource_predictor)
    
    @pytest.mark.asyncio
    async def test_ml_enhanced_validation(self, intelligent_gate):
        """Test ML-enhanced validation features"""
        # Create task with predictable characteristics
        task = EnhancedAgentTask(
            task_id="ml_test_task",
            task_type="code",
            prompt="Complex algorithm implementation with optimization requirements",
            dependencies=["analysis_task"],
            context={"complexity": "high"}
        )
        
        # Mock parent validation
        with patch.object(IntelligentQualityGate.__bases__[0], 'validate_pre_execution') as mock_parent:
            mock_parent.return_value = ValidationResult(
                passed=True,
                issues=[],
                warnings=[],
                gate_name="ml_enhanced_gate"
            )
            
            result = await intelligent_gate.validate_pre_execution(task)
            
            # Should call parent validation
            mock_parent.assert_called_once_with(task)
            
            # Should add ML-based warnings for unusual tasks or long duration
            # (exact warnings depend on prediction, but structure should be correct)
            assert isinstance(result, ValidationResult)
            assert result.gate_name == "ml_enhanced_gate"
    
    def test_validation_history_tracking(self, intelligent_gate):
        """Test validation history accumulation"""
        # Create multiple validation scenarios
        tasks = [
            EnhancedAgentTask(task_id=f"hist_task_{i}", task_type="test", prompt=f"Task {i}", dependencies=[])
            for i in range(3)
        ]
        
        # Run validations
        for task in tasks:
            asyncio.run(intelligent_gate.validate_pre_execution(task))
        
        # Check history was recorded
        assert len(intelligent_gate.validation_history) == 3
        
        for i, record in enumerate(intelligent_gate.validation_history):
            assert record["task_id"] == f"hist_task_{i}"
            assert "timestamp" in record
            assert "passed" in record
            assert "issues_count" in record
            assert "warnings_count" in record


if __name__ == "__main__":
    """Run unit tests"""
    print("🔬 Running Enhanced Quality Gates Unit Tests")
    print("=" * 60)
    
    exit_code = pytest.main([
        __file__,
        "-v",
        "--tb=short", 
        "--asyncio-mode=auto",
        "-x"  # Stop on first failure for faster feedback
    ])
    
    if exit_code == 0:
        print("\n✅ ALL UNIT TESTS PASSED!")
        print("   Enhanced Quality Gates components working correctly")
    else:
        print("\n❌ SOME UNIT TESTS FAILED")
        print("   Check test output above for details")
    
    sys.exit(exit_code)