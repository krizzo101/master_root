#!/usr/bin/env python3
"""
Comprehensive Parallel Agent Orchestrator Test Suite
Tests token pool management, parallel execution, timing, and edge cases
"""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

from src.generic_orchestrator import GenericOrchestrator, AgentTask


class ParallelExecutionTester:
    """Comprehensive parallel execution testing framework"""
    
    def __init__(self, max_parallel: int = 3):
        # Create output directory for test results
        output_dir = Path("parallel_test_results")
        self.orchestrator = GenericOrchestrator(output_dir=output_dir, max_parallel=max_parallel)
        self.results = {
            'test_start_time': None,
            'test_end_time': None,
            'token_pool_size': 0,
            'max_parallel': max_parallel,
            'test_scenarios': [],
            'performance_metrics': {},
            'edge_case_results': {},
            'summary': {}
        }
        
    def create_test_tasks(self) -> List[AgentTask]:
        """Create 5 independent test tasks for parallel execution"""
        tasks = [
            AgentTask(
                task_id="analyze_token_loader",
                task_type="research-genius",
                prompt="Analyze the token_loader.py file and report its key functions, methods, and purpose. Focus on token management capabilities.",
                context={"file_path": "src/token_loader.py", "analysis_type": "code_review"}
            ),
            AgentTask(
                task_id="count_src_files",
                task_type="development-specialist", 
                prompt="List all Python files in the src/ directory, count total lines of code, and provide a brief summary of each file's purpose.",
                context={"directory": "src/", "task_type": "file_analysis"}
            ),
            AgentTask(
                task_id="git_status_analysis",
                task_type="solution-architect",
                prompt="Check the git status, analyze recent commits, and summarize the current state of the repository including any pending changes.",
                context={"git_analysis": True, "include_history": True}
            ),
            AgentTask(
                task_id="generate_unit_tests",
                task_type="qa-testing-guru",
                prompt="Create a simple Python test file with 3 basic unit tests for testing agent orchestration functionality. Include setup, execution, and validation tests.",
                context={"test_framework": "unittest", "test_count": 3}
            ),
            AgentTask(
                task_id="orchestrator_summary",
                task_type="technical-writer",
                prompt="Create a brief technical summary of the orchestrator's main components, architecture, and key capabilities based on the codebase structure.",
                context={"documentation_type": "technical_summary", "focus": "architecture"}
            )
        ]
        return tasks
    
    def create_edge_case_tasks(self) -> List[AgentTask]:
        """Create tasks for edge case testing (more tasks than tokens)"""
        edge_tasks = []
        for i in range(7):  # More than our 4-token pool
            edge_tasks.append(AgentTask(
                task_id=f"edge_task_{i+1}",
                task_type="general-purpose",
                prompt=f"Simple task {i+1}: Generate a list of {(i+1)*3} random words and create a short sentence using them.",
                context={"task_number": i+1, "word_count": (i+1)*3}
            ))
        return edge_tasks
    
    async def run_parallel_test(self) -> Dict[str, Any]:
        """Execute main parallel test with 5 independent agents"""
        print("🚀 Starting Parallel Agent Execution Test...")
        
        # Setup
        self.results['test_start_time'] = datetime.now().isoformat()
        self.results['token_pool_size'] = len(self.orchestrator.token_pool.tokens)
        
        # Create and execute tasks
        tasks = self.create_test_tasks()
        start_time = time.time()
        
        print(f"Launching {len(tasks)} agents in parallel (max_parallel={self.orchestrator.max_parallel})")
        
        # Execute parallel tasks
        execution_results = await self.orchestrator.execute_batch(tasks)
        
        end_time = time.time()
        execution_duration = end_time - start_time
        
        # Analyze results
        test_scenario = {
            'scenario': 'main_parallel_test',
            'task_count': len(tasks),
            'execution_time': execution_duration,
            'results': execution_results,
            'success_count': len([r for r in execution_results if r.get('status') == 'completed']),
            'failure_count': len([r for r in execution_results if r.get('status') == 'failed'])
        }
        
        self.results['test_scenarios'].append(test_scenario)
        
        # Extract token usage statistics if available
        self._analyze_token_usage(execution_results)
        
        print(f"✅ Parallel test completed in {execution_duration:.2f}s")
        return test_scenario
    
    async def run_edge_case_tests(self) -> Dict[str, Any]:
        """Test edge cases: more agents than tokens, failure scenarios"""
        print("🧪 Running Edge Case Tests...")
        
        # Test 1: More agents than tokens
        edge_tasks = self.create_edge_case_tasks()
        start_time = time.time()
        
        print(f"Testing {len(edge_tasks)} agents with {self.results['token_pool_size']} tokens...")
        edge_results = await self.orchestrator.execute_batch(edge_tasks)
        
        edge_duration = time.time() - start_time
        
        edge_scenario = {
            'scenario': 'more_agents_than_tokens',
            'task_count': len(edge_tasks),
            'token_count': self.results['token_pool_size'],
            'execution_time': edge_duration,
            'success_count': len([r for r in edge_results if r.get('status') == 'completed']),
            'failure_count': len([r for r in edge_results if r.get('status') == 'failed']),
            'token_cycling_test': True
        }
        
        self.results['edge_case_results'] = edge_scenario
        print(f"✅ Edge case testing completed in {edge_duration:.2f}s")
        
        return edge_scenario
    
    def _analyze_token_usage(self, execution_results: List[Dict[str, Any]]):
        """Analyze token allocation and usage patterns"""
        token_stats = {
            'total_executions': len(execution_results),
            'token_distribution': {},
            'concurrent_execution_detected': False,
            'timing_overlap_analysis': []
        }
        
        # Check for timing overlaps (indicates true parallelism)
        start_times = []
        end_times = []
        
        for result in execution_results:
            if 'metadata' in result and 'timing' in result['metadata']:
                timing = result['metadata']['timing']
                if 'start_time' in timing:
                    start_times.append(timing['start_time'])
                if 'end_time' in timing:
                    end_times.append(timing['end_time'])
        
        # Detect overlapping execution windows
        if len(start_times) >= 2 and len(end_times) >= 2:
            start_times.sort()
            end_times.sort()
            
            # Check if any task started before another finished
            for i in range(len(start_times)-1):
                if start_times[i+1] < end_times[i]:
                    token_stats['concurrent_execution_detected'] = True
                    break
        
        self.results['performance_metrics']['token_usage'] = token_stats
    
    def generate_comprehensive_report(self) -> Dict[str, Any]:
        """Generate final test report with all metrics and analysis"""
        self.results['test_end_time'] = datetime.now().isoformat()
        
        # Calculate summary statistics
        total_tasks = sum(scenario.get('task_count', 0) for scenario in self.results['test_scenarios'])
        total_successes = sum(scenario.get('success_count', 0) for scenario in self.results['test_scenarios'])
        
        if 'edge_case_results' in self.results:
            total_tasks += self.results['edge_case_results'].get('task_count', 0)
            total_successes += self.results['edge_case_results'].get('success_count', 0)
        
        self.results['summary'] = {
            'total_tasks_executed': total_tasks,
            'total_successful': total_successes,
            'overall_success_rate': (total_successes / total_tasks * 100) if total_tasks > 0 else 0,
            'parallel_execution_verified': self.results.get('performance_metrics', {}).get('token_usage', {}).get('concurrent_execution_detected', False),
            'token_pool_utilization': f"{self.results['token_pool_size']} tokens available",
            'max_parallel_setting': self.results['max_parallel']
        }
        
        return self.results
    
    def print_report(self):
        """Print formatted test report to console"""
        print("\n" + "="*60)
        print("🔍 COMPREHENSIVE PARALLEL EXECUTION TEST REPORT")
        print("="*60)
        
        print(f"\n📊 TEST CONFIGURATION:")
        print(f"   • Token Pool Size: {self.results['token_pool_size']}")
        print(f"   • Max Parallel Agents: {self.results['max_parallel']}")
        print(f"   • Test Duration: {self.results['test_start_time']} to {self.results['test_end_time']}")
        
        print(f"\n🚀 EXECUTION RESULTS:")
        for scenario in self.results['test_scenarios']:
            print(f"   • {scenario['scenario']}: {scenario['success_count']}/{scenario['task_count']} tasks succeeded ({scenario['execution_time']:.2f}s)")
        
        if 'edge_case_results' in self.results:
            edge = self.results['edge_case_results']
            print(f"   • Edge Case Test: {edge['success_count']}/{edge['task_count']} tasks succeeded ({edge['execution_time']:.2f}s)")
        
        print(f"\n📈 PERFORMANCE ANALYSIS:")
        summary = self.results['summary']
        print(f"   • Overall Success Rate: {summary['overall_success_rate']:.1f}%")
        print(f"   • Parallel Execution Detected: {'✅ YES' if summary['parallel_execution_verified'] else '❌ NO'}")
        print(f"   • Token Pool Utilization: {summary['token_pool_utilization']}")
        
        if self.results.get('performance_metrics', {}).get('token_usage', {}).get('concurrent_execution_detected'):
            print(f"   • ✅ TRUE PARALLELISM CONFIRMED: Tasks executed concurrently")
        
        print(f"\n💡 SUMMARY:")
        print(f"   Orchestrator successfully managed {summary['total_tasks_executed']} total tasks")
        print(f"   with {summary['total_successful']} successful completions.")
        if summary['parallel_execution_verified']:
            print(f"   ✅ Parallel execution is working correctly with token rotation.")
        else:
            print(f"   ⚠️  Parallel execution needs verification - check token pool and timing.")


async def main():
    """Main test execution function"""
    print("🧪 Initializing Comprehensive Parallel Agent Orchestrator Tests...")
    
    # Initialize tester
    tester = ParallelExecutionTester(max_parallel=3)
    
    try:
        # Run main parallel test
        await tester.run_parallel_test()
        
        # Run edge case tests
        await tester.run_edge_case_tests()
        
        # Generate and display report
        final_report = tester.generate_comprehensive_report()
        tester.print_report()
        
        # Save detailed report to file
        report_file = Path("comprehensive_test_report.json")
        with open(report_file, 'w') as f:
            json.dump(final_report, f, indent=2, default=str)
        
        print(f"\n📄 Detailed report saved to: {report_file}")
        
    except Exception as e:
        print(f"❌ Test execution failed: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())