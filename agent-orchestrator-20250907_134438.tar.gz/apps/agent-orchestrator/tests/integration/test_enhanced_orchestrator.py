#!/usr/bin/env python3
"""
Test script for Enhanced Orchestrator backward compatibility and new features
"""

import asyncio
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from generic_orchestrator import AgentTask, GenericOrchestrator
from enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask, create_enhanced_task, create_team_tasks

async def test_backward_compatibility():
    """Test that existing GenericOrchestrator code works with EnhancedOrchestrator"""
    
    print("Testing backward compatibility...")
    
    def generate_regular_tasks():
        """Generate regular AgentTask objects (existing pattern)"""
        return [
            AgentTask(
                task_id="backward_test_1",
                task_type="test",
                prompt="This is a backward compatibility test",
                dependencies=[]
            ),
            AgentTask(
                task_id="backward_test_2", 
                task_type="test",
                prompt="This depends on test 1",
                dependencies=["backward_test_1"]
            )
        ]
    
    # Create enhanced orchestrator but use it like the old one
    orchestrator = EnhancedOrchestrator(
        output_dir=Path("/tmp/backward_compat_test"),
        max_parallel=2,
        # Disable enhanced features for pure backward compatibility
        enable_monitoring=False,
        enable_quality_gates=False
    )
    
    print("Created EnhancedOrchestrator with disabled enhanced features")
    
    # This should work exactly like the original GenericOrchestrator
    try:
        result = await orchestrator.run(generate_regular_tasks)
        print("✓ Backward compatibility test PASSED")
        print(f"  Completed: {result['metrics']['completed']}")
        print(f"  Failed: {result['metrics']['failed']}")
        return True
    except Exception as e:
        print(f"✗ Backward compatibility test FAILED: {e}")
        return False

async def test_enhanced_features():
    """Test new enhanced features"""
    
    print("\nTesting enhanced features...")
    
    team_id = "team-phase1-003"
    
    # Create enhanced tasks using new functions
    tasks = create_team_tasks(team_id, [
        {
            "task_id": "enhanced_test_1",
            "task_type": "research", 
            "prompt": "Enhanced task with UUID tracking",
            "monitoring_enabled": True,
            "quality_gates": []
        },
        {
            "task_id": "enhanced_test_2",
            "task_type": "implementation",
            "prompt": "Second enhanced task",
            "dependencies": ["enhanced_test_1"],
            "monitoring_enabled": True,
            "quality_gates": []
        }
    ])
    
    print(f"Created {len(tasks)} enhanced tasks for team {team_id}")
    
    # Create orchestrator with enhanced features
    orchestrator = EnhancedOrchestrator(
        output_dir=Path("/tmp/enhanced_test"),
        max_parallel=2,
        enable_monitoring=True,
        enable_quality_gates=True
    )
    
    print("Created EnhancedOrchestrator with full features enabled")
    
    try:
        # Test synchronous execution (original behavior)
        result = await orchestrator.run(lambda: tasks)
        print("✓ Enhanced synchronous execution PASSED")
        print(f"  Completed: {result['metrics']['completed']}")
        print(f"  Monitoring metrics: {result.get('monitoring_metrics', 'N/A')}")
        
        # Test background execution (new feature)
        bg_tasks = create_team_tasks(f"{team_id}-bg", [
            {
                "task_id": "bg_test_1",
                "task_type": "background",
                "prompt": "Background task test",
                "monitoring_enabled": True
            }
        ])
        
        job_id = await orchestrator.launch_background_team(bg_tasks)
        print(f"✓ Background team launched: {job_id}")
        
        # Check job status
        status = await orchestrator.get_background_job_status(job_id)
        if status:
            print(f"✓ Background job status retrieved: {status['status']}")
        else:
            print("✗ Could not retrieve background job status")
        
        return True
        
    except Exception as e:
        print(f"✗ Enhanced features test FAILED: {e}")
        return False

async def test_uuid_generation():
    """Test UUID generation and team coordination"""
    
    print("\nTesting UUID generation...")
    
    # Test automatic UUID generation
    task1 = create_enhanced_task(
        task_id="uuid_test_1",
        task_type="test",
        prompt="Test automatic UUID generation"
    )
    
    print(f"✓ Auto-generated UUID: {task1.agent_uuid}")
    
    # Test team coordination
    team_id = "team-uuid-test-001"
    tasks = create_team_tasks(team_id, [
        {
            "task_id": "team_task_1",
            "task_type": "test",
            "prompt": "First team task"
        },
        {
            "task_id": "team_task_2", 
            "task_type": "test",
            "prompt": "Second team task"
        }
    ])
    
    print(f"✓ Created team {team_id} with coordinated UUIDs:")
    for task in tasks:
        print(f"  {task.task_id}: {task.agent_uuid}")
        print(f"  Team ID: {task.team_id}")
    
    return True

async def main():
    """Run all tests"""
    
    print("Enhanced Orchestrator Test Suite")
    print("=" * 40)
    
    test_results = []
    
    # Test backward compatibility first
    test_results.append(await test_backward_compatibility())
    
    # Test enhanced features
    test_results.append(await test_enhanced_features())
    
    # Test UUID coordination
    test_results.append(await test_uuid_generation())
    
    print("\n" + "=" * 40)
    print("Test Results Summary")
    print("=" * 40)
    
    passed = sum(test_results)
    total = len(test_results)
    
    print(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        print("✓ All tests PASSED - Enhanced Orchestrator is ready!")
        return 0
    else:
        print("✗ Some tests FAILED - Please check implementation")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)