#!/usr/bin/env python3
import asyncio
from pathlib import Path
from typing import Dict, List
import sys

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.generic_orchestrator import GenericOrchestrator, AgentTask

def generate_test_tasks() -> List[AgentTask]:
    """Test workflow based on the report specifications"""
    return [
        AgentTask(
            task_id="research_task",
            task_type="research",
            prompt="Research Python best practices for error handling and create a summary file called 'research_summary.txt' with 3 key points",
            dependencies=[]
        ),
        AgentTask(
            task_id="implementation_task", 
            task_type="coding",
            prompt="Based on the research_summary.txt file, create a simple Python example script called 'example.py' that demonstrates proper error handling",
            dependencies=["research_task"]
        ),
        AgentTask(
            task_id="validation_task",
            task_type="testing",
            prompt="Test the example.py script by running it and create a test report called 'test_results.txt' documenting whether it works correctly",
            dependencies=["implementation_task"]
        )
    ]

async def process_results(results: List[Dict]):
    """Process results after completion"""
    print("📊 WORKFLOW RESULTS:")
    for result in results:
        task_id = result.get('task_id')
        status = result.get('status')
        duration = None
        if result.get('start_time') and result.get('end_time'):
            duration = result.get('end_time') - result.get('start_time')
            print(f"  ✓ {task_id}: {status} ({duration:.2f}s)")
        else:
            print(f"  ✗ {task_id}: {status}")

async def main():
    """Main execution function"""
    print("🚀 Testing Generic Orchestrator Report Claims")
    print("=" * 60)
    
    # Create orchestrator instance
    orchestrator = GenericOrchestrator(
        output_dir=Path("test_orchestrator_report_output"),
        max_parallel=7,
        use_optimizations=True
    )

    # Run the workflow
    result = await orchestrator.run(
        task_generator=generate_test_tasks,
        result_processor=process_results
    )

    # Check success
    metrics = result['metrics']
    success = metrics['completed'] == metrics['total']
    print(f"\n🎯 FINAL RESULT: {'SUCCESS' if success else 'FAILED'}")
    print(f"   Completed: {metrics['completed']}/{metrics['total']}")
    print(f"   Failed: {metrics['failed']}")
    
    return success

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)