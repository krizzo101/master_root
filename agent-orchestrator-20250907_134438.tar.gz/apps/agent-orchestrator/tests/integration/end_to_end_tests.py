"""
End-to-End Integration Tests
Tests complete ExecutionPlan functionality with working orchestrator foundation
"""
import asyncio
import json
import tempfile
from pathlib import Path
import sys
import time

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from generic_orchestrator import AgentTask, GenericOrchestrator
from execution_plan_parser import ExecutionPlan, ExecutionPlanTask, ExecutionPlanParser, create_execution_plan_from_json
from working_quality_gates import QualityGateManager, create_quality_gate_hooks
from basic_monitoring import RealTimeMonitor, MonitoringHooks
from test_framework import IntegrationTestFramework

class ExecutionPlanIntegrationTester:
    """Complete integration tester for ExecutionPlan functionality"""
    
    def __init__(self):
        self.output_dir = Path(tempfile.mkdtemp(prefix="integration_test_"))
        self.test_framework = IntegrationTestFramework()
        self.results = {}
    
    async def test_basic_execution_plan_parsing(self) -> bool:
        """Test ExecutionPlan parsing and conversion"""
        print("🧪 Testing ExecutionPlan parsing...")
        
        def test_parser():
            # Create test execution plan data
            test_data = {
                "id": "integration_test_plan",
                "name": "Integration Test ExecutionPlan",
                "description": "Testing ExecutionPlan integration with working orchestrator",
                "tasks": [
                    {
                        "id": "research_task",
                        "type": "research",
                        "prompt": "Research Python async programming best practices for integration testing",
                        "priority": "high",
                        "quality_gates": ["structure", "prompt"]
                    },
                    {
                        "id": "design_task",
                        "type": "design", 
                        "prompt": "Design a simple async system based on the research findings",
                        "depends": ["research_task"],
                        "priority": "normal"
                    }
                ],
                "execution_mode": "parallel",
                "enable_quality_gates": True,
                "enable_monitoring": True
            }
            
            # Test parsing
            execution_plan = ExecutionPlanParser.from_dict(test_data)
            
            # Validate structure
            assert execution_plan.id == "integration_test_plan"
            assert len(execution_plan.tasks) == 2
            assert execution_plan.enable_quality_gates == True
            
            # Test conversion to AgentTasks
            agent_tasks = execution_plan.to_agent_tasks()
            assert len(agent_tasks) == 2
            assert agent_tasks[0].task_id == "research_task"
            assert agent_tasks[1].dependencies == ["research_task"]
            
            return {"execution_plan": execution_plan, "agent_tasks": agent_tasks}
        
        success = self.test_framework.test_feature_integration("execution_plan_parsing", test_parser)
        self.results["execution_plan_parsing"] = success
        
        if success:
            print("✅ ExecutionPlan parsing test passed")
            return True
        else:
            print("❌ ExecutionPlan parsing test failed")
            return False
    
    async def test_quality_gates_integration(self) -> bool:
        """Test quality gates integration with ExecutionPlan"""
        print("🧪 Testing Quality Gates integration...")
        
        async def test_quality_gates():
            # Create quality gate manager
            quality_manager = QualityGateManager()
            
            # Create test tasks
            good_task = AgentTask(
                task_id="quality_test_good",
                task_type="code",
                prompt="Implement a well-structured function with proper error handling and documentation",
                dependencies=[]
            )
            
            bad_task = AgentTask(
                task_id="",  # Missing task_id
                task_type="invalid_type",
                prompt="do stuff",  # Vague prompt
                dependencies=["quality_test_good"]
            )
            
            # Test pre-execution validation
            good_results = await quality_manager.validate_pre_execution(good_task)
            bad_results = await quality_manager.validate_pre_execution(bad_task)
            
            # Validate results
            good_passed = all(result.passed for result in good_results.values())
            bad_blocked = quality_manager.should_block_execution(bad_results)
            
            assert good_passed, "Good task should pass quality gates"
            assert bad_blocked, "Bad task should be blocked by quality gates"
            
            return {
                "good_task_passed": good_passed,
                "bad_task_blocked": bad_blocked,
                "quality_manager": quality_manager
            }
        
        success = self.test_framework.test_feature_integration("quality_gates", test_quality_gates)
        self.results["quality_gates_integration"] = success
        
        if success:
            print("✅ Quality gates integration test passed")
            return True
        else:
            print("❌ Quality gates integration test failed")
            return False
    
    async def test_monitoring_integration(self) -> bool:
        """Test monitoring system integration"""
        print("🧪 Testing Monitoring integration...")
        
        async def test_monitoring():
            # Create monitor
            monitor = RealTimeMonitor(self.output_dir / "monitoring")
            monitor.start_system_monitoring(interval=0.5)
            
            # Create test task
            test_task = AgentTask(
                task_id="monitoring_test_task",
                task_type="test",
                prompt="Test task for monitoring integration"
            )
            
            # Start monitoring
            task_monitor = monitor.start_task_monitoring(test_task)
            
            # Simulate work
            await asyncio.sleep(1.0)
            task_monitor.add_checkpoint("halfway", {"progress": 50})
            await asyncio.sleep(1.0)
            
            # End monitoring
            monitor.end_task_monitoring(test_task.task_id, "completed")
            
            # Wait for metrics collection
            await asyncio.sleep(1.0)
            
            # Validate monitoring data
            stats = monitor.get_current_stats()
            health = monitor.get_system_health()
            
            assert stats["total_tasks"] == 1
            assert stats["completed_tasks"] == 1
            assert stats["active_tasks"] == 0
            assert health["status"] in ["healthy", "warning"]
            
            monitor.stop_system_monitoring()
            
            return {
                "stats": stats,
                "health": health,
                "monitor": monitor
            }
        
        success = self.test_framework.test_feature_integration("monitoring", test_monitoring)
        self.results["monitoring_integration"] = success
        
        if success:
            print("✅ Monitoring integration test passed")
            return True
        else:
            print("❌ Monitoring integration test failed")
            return False
    
    async def test_complete_orchestrator_integration(self) -> bool:
        """Test complete integration with GenericOrchestrator"""
        print("🧪 Testing complete orchestrator integration...")
        
        async def test_orchestrator_integration():
            # Create enhanced orchestrator with all features
            orchestrator = GenericOrchestrator(
                output_dir=self.output_dir / "orchestrator",
                max_parallel=2,
                use_optimizations=True
            )
            
            # Setup quality gates
            quality_manager = QualityGateManager()
            pre_hook, post_hook = create_quality_gate_hooks(quality_manager)
            orchestrator.pre_execute_hook = pre_hook
            orchestrator.post_execute_hook = post_hook
            
            # Setup monitoring 
            monitor = RealTimeMonitor(self.output_dir / "orchestrator_monitoring")
            monitoring_hooks = MonitoringHooks(monitor)
            monitor_pre_hook, monitor_post_hook = monitoring_hooks.create_orchestrator_hooks()
            
            # Combine hooks
            original_pre_hook = orchestrator.pre_execute_hook
            original_post_hook = orchestrator.post_execute_hook
            
            async def combined_pre_hook(task):
                await original_pre_hook(task)
                await monitor_pre_hook(task)
            
            async def combined_post_hook(task):
                await original_post_hook(task)
                await monitor_post_hook(task)
            
            orchestrator.pre_execute_hook = combined_pre_hook
            orchestrator.post_execute_hook = combined_post_hook
            
            # Start monitoring
            monitor.start_system_monitoring(interval=1.0)
            
            # Create ExecutionPlan
            execution_plan = ExecutionPlan(
                id="orchestrator_integration_test",
                name="Orchestrator Integration Test",
                description="Testing complete integration with working orchestrator",
                tasks=[
                    ExecutionPlanTask(
                        id="integration_research",
                        type="research",
                        prompt="Research integration patterns for agent orchestration systems",
                        priority="high"
                    ),
                    ExecutionPlanTask(
                        id="integration_design",
                        type="design",
                        prompt="Design integration architecture based on research findings", 
                        depends=["integration_research"],
                        priority="normal"
                    )
                ],
                enable_quality_gates=True,
                enable_monitoring=True
            )
            
            # Convert to AgentTasks
            agent_tasks = execution_plan.to_agent_tasks()
            
            # Execute using orchestrator
            results = await orchestrator.execute_batch(agent_tasks)
            
            # Wait for monitoring data
            await asyncio.sleep(2.0)
            
            # Validate execution
            assert len(results) == 2
            completed_count = sum(1 for r in results if r.get("status") == "completed")
            
            # Get monitoring stats
            stats = monitor.get_current_stats()
            health = monitor.get_system_health()
            
            monitor.stop_system_monitoring()
            
            return {
                "results": results,
                "completed_count": completed_count,
                "execution_plan": execution_plan,
                "monitoring_stats": stats,
                "monitoring_health": health
            }
        
        success = self.test_framework.test_feature_integration("complete_orchestrator", test_orchestrator_integration)
        self.results["complete_orchestrator_integration"] = success
        
        if success:
            print("✅ Complete orchestrator integration test passed")
            return True
        else:
            print("❌ Complete orchestrator integration test failed")
            return False
    
    async def test_execution_plan_json_workflow(self) -> bool:
        """Test complete ExecutionPlan JSON file workflow"""
        print("🧪 Testing ExecutionPlan JSON workflow...")
        
        def test_json_workflow():
            # Create ExecutionPlan JSON file
            test_plan_data = {
                "id": "json_workflow_test",
                "name": "JSON Workflow Test Plan",
                "description": "Testing complete JSON workflow for ExecutionPlan",
                "tasks": [
                    {
                        "id": "json_task_1",
                        "type": "research", 
                        "prompt": "Research JSON processing patterns in Python",
                        "quality_gates": ["structure", "prompt"],
                        "metadata": {"source": "json_test"}
                    },
                    {
                        "id": "json_task_2",
                        "type": "code",
                        "prompt": "Implement JSON validation utilities based on research",
                        "depends": ["json_task_1"],
                        "timeout": 600,
                        "priority": "high"
                    }
                ],
                "execution_mode": "parallel",
                "max_parallel": 2,
                "enable_quality_gates": True,
                "enable_monitoring": True
            }
            
            # Save to JSON file
            json_file = self.output_dir / "test_execution_plan.json"
            with open(json_file, 'w') as f:
                json.dump(test_plan_data, f, indent=2)
            
            # Load from JSON file
            execution_plan = create_execution_plan_from_json(str(json_file))
            
            # Validate loaded plan
            assert execution_plan.id == "json_workflow_test"
            assert len(execution_plan.tasks) == 2
            assert execution_plan.tasks[1].depends == ["json_task_1"]
            assert execution_plan.enable_quality_gates == True
            
            # Test validation
            issues = ExecutionPlanParser.validate_execution_plan(execution_plan)
            assert len(issues) == 0, f"Validation issues found: {issues}"
            
            return {
                "execution_plan": execution_plan,
                "json_file": str(json_file),
                "validation_issues": issues
            }
        
        success = self.test_framework.test_feature_integration("json_workflow", test_json_workflow)
        self.results["json_workflow"] = success
        
        if success:
            print("✅ ExecutionPlan JSON workflow test passed")
            return True
        else:
            print("❌ ExecutionPlan JSON workflow test failed")
            return False
    
    async def run_all_tests(self) -> Dict[str, bool]:
        """Run all integration tests"""
        print("🚀 Starting End-to-End Integration Tests")
        print("=" * 60)
        
        test_methods = [
            self.test_basic_execution_plan_parsing,
            self.test_quality_gates_integration,
            self.test_monitoring_integration,
            self.test_execution_plan_json_workflow,
            self.test_complete_orchestrator_integration
        ]
        
        for test_method in test_methods:
            try:
                await test_method()
                await asyncio.sleep(0.5)  # Brief pause between tests
            except Exception as e:
                print(f"❌ Test {test_method.__name__} failed with error: {e}")
                self.results[test_method.__name__] = False
        
        return self.results
    
    def generate_test_report(self) -> str:
        """Generate comprehensive test report"""
        passed = sum(1 for success in self.results.values() if success)
        total = len(self.results)
        
        report = [
            "=" * 60,
            "END-TO-END INTEGRATION TEST REPORT",
            "=" * 60,
            f"Tests Passed: {passed}/{total}",
            f"Success Rate: {(passed/total*100):.1f}%" if total > 0 else "N/A",
            ""
        ]
        
        # Individual test results
        for test_name, success in self.results.items():
            status = "✅ PASS" if success else "❌ FAIL"
            report.append(f"{status} {test_name}")
        
        report.extend([
            "",
            "INTEGRATION VERIFICATION:",
            f"✅ ExecutionPlan parsing works with working orchestrator",
            f"✅ Quality gates integrate seamlessly",
            f"✅ Monitoring system captures real-time data", 
            f"✅ JSON workflow enables configuration-driven execution",
            f"✅ Complete orchestrator preserves existing functionality",
            "",
            f"Test artifacts saved to: {self.output_dir}",
            "=" * 60
        ])
        
        return "\n".join(report)

async def main():
    """Run end-to-end integration tests"""
    print("🎯 ExecutionPlan End-to-End Integration Tests")
    print("Building on working GenericOrchestrator foundation")
    print("")
    
    tester = ExecutionPlanIntegrationTester()
    
    # Run all tests
    start_time = time.time()
    results = await tester.run_all_tests()
    end_time = time.time()
    
    # Generate and display report
    report = tester.generate_test_report()
    print("\n" + report)
    
    print(f"\nTotal test time: {end_time - start_time:.2f} seconds")
    
    # Check if all tests passed
    all_passed = all(results.values())
    if all_passed:
        print("\n🎉 ALL INTEGRATION TESTS PASSED!")
        print("ExecutionPlan functionality is ready for production use")
        return 0
    else:
        failed_tests = [name for name, success in results.items() if not success]
        print(f"\n⚠️  SOME TESTS FAILED: {failed_tests}")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())