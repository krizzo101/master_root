#!/usr/bin/env python3
import asyncio
from pathlib import Path
from typing import Dict, List
import sys

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.practical_orchestrator import PracticalOrchestrator, PracticalAgentTask, create_practical_orchestrator

def generate_practical_test_tasks() -> List[PracticalAgentTask]:
    """Enhanced test workflow using PracticalAgentTask features"""
    return [
        PracticalAgentTask(
            task_id="research_task",
            task_type="research",
            prompt="Research Python best practices for error handling and create a summary file called 'research_summary.txt' with 3 key points",
            dependencies=[],
            phase_id="discovery",
            priority="high",
            tags=["research", "python", "error-handling"]
        ),
        PracticalAgentTask(
            task_id="implementation_task", 
            task_type="development-specialist",
            prompt="Based on the research_summary.txt file, create a simple Python example script called 'example.py' that demonstrates proper error handling",
            dependencies=["research_task"],
            phase_id="implementation",
            priority="normal",
            tags=["coding", "python", "error-handling", "demo"]
        ),
        PracticalAgentTask(
            task_id="validation_task",
            task_type="qa-testing-guru",
            prompt="Test the example.py script by running it and create a test report called 'test_results.txt' documenting whether it works correctly",
            dependencies=["implementation_task"],
            phase_id="validation",
            priority="normal",
            tags=["testing", "validation", "qa"]
        )
    ]

async def process_results(results: List[Dict]):
    """Enhanced result processor showing practical orchestrator benefits"""
    print("📊 ENHANCED WORKFLOW RESULTS:")
    for result in results:
        task_id = result.get('task_id')
        status = result.get('status')
        duration = None
        if result.get('start_time') and result.get('end_time'):
            duration = result.get('end_time') - result.get('start_time')
        
        phase_id = result.get('phase_id', 'unknown')
        priority = result.get('priority', 'normal')
        files_created = result.get('files_created', [])
        session_id = result.get('session_id', 'unknown')
        
        status_emoji = "✅" if status == "completed" else "❌"
        
        print(f"  {status_emoji} {task_id} ({phase_id}/{priority})")
        if duration:
            print(f"      Duration: {duration:.2f}s")
        if files_created:
            print(f"      Files Created: {', '.join(files_created)}")
        print(f"      Session ID: {session_id}")
        print()

async def main():
    """Main execution function using PracticalOrchestrator"""
    print("🚀 Testing PracticalOrchestrator Enhanced Features")
    print("=" * 60)
    
    # Create practical orchestrator with monitoring
    orchestrator = create_practical_orchestrator(
        output_dir="test_practical_orchestrator_output",
        max_parallel=7,
        enable_monitoring=True
    )

    # Set up progress monitoring callback
    def progress_handler(event_type: str, data: Dict):
        if event_type == "task_started":
            print(f"🟡 Starting: {data['task_id']} ({data.get('task_type', 'unknown')}) - Session: {data.get('session_id', 'unknown')}")
        elif event_type == "task_completed":
            status_emoji = "🟢" if data.get('status') == 'completed' else "🔴"
            print(f"{status_emoji} Finished: {data['task_id']} in {data.get('duration', 0):.1f}s - Created {data.get('files_created', 0)} files")
        elif event_type == "batch_started":
            print(f"📦 Starting batch: {data['total_tasks']} tasks across phases: {data.get('phases', [])}")
        elif event_type == "batch_completed":
            print(f"📈 Batch complete: {data['completed']}/{data['total_tasks']} succeeded, {data['failed']} failed")
        elif event_type == "quality_report_generated":
            print(f"📋 Quality report: {data['success_rate']:.1%} success rate, {data['total_files_created']} files created")

    orchestrator.set_progress_callback(progress_handler)

    # Run the enhanced workflow
    result = await orchestrator.run(
        task_generator=generate_practical_test_tasks,
        result_processor=process_results
    )

    # Print session mapping for monitoring
    print("\n" + "=" * 60)
    orchestrator.print_session_map()

    # Print monitoring commands
    print("🔍 MONITORING COMMANDS:")
    commands = orchestrator.get_monitoring_commands()
    for cmd in commands[:6]:  # Show first few commands
        print(f"  {cmd}")

    # Check success
    metrics = result['metrics']
    success = metrics['completed'] == metrics['total']
    
    print(f"\n🎯 FINAL RESULT: {'SUCCESS' if success else 'FAILED'}")
    print(f"   Completed: {metrics['completed']}/{metrics['total']}")
    print(f"   Failed: {metrics['failed']}")
    print(f"   Quality Report: test_practical_orchestrator_output/quality_report.json")
    
    return success

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)