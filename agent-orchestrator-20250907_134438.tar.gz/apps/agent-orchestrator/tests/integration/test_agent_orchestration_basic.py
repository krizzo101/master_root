#!/usr/bin/env python3
"""
Basic unit tests for agent orchestration functionality.
Tests setup, execution, and validation of the orchestrator system.
"""

import unittest
import asyncio
import json
import tempfile
import os
from unittest.mock import Mock, patch, AsyncMock
from pathlib import Path

# Import orchestrator components
from src.generic_orchestrator import GenericOrchestrator, AgentTask, TokenPool


class TestAgentOrchestrationBasic(unittest.TestCase):
    """Basic unit tests for agent orchestration functionality"""

    def setUp(self):
        """Set up test environment before each test"""
        self.temp_dir = tempfile.mkdtemp()
        self.test_token = "test-token-12345"
        self.orchestrator = GenericOrchestrator(
            output_dir=self.temp_dir,
            tokens=[self.test_token],
            max_concurrent_agents=2
        )

    def tearDown(self):
        """Clean up after each test"""
        # Clean up temp directory
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_orchestrator_setup(self):
        """Test 1: Setup - Verify orchestrator initializes correctly"""
        # Test orchestrator initialization
        self.assertIsNotNone(self.orchestrator)
        self.assertEqual(self.orchestrator.output_dir, self.temp_dir)
        self.assertEqual(self.orchestrator.max_concurrent_agents, 2)
        
        # Test token pool setup
        self.assertIsNotNone(self.orchestrator.token_pool)
        self.assertEqual(len(self.orchestrator.token_pool.tokens), 1)
        self.assertEqual(self.orchestrator.token_pool.tokens[0], self.test_token)
        
        # Test task tracking initialization
        self.assertEqual(len(self.orchestrator.tasks), 0)
        self.assertEqual(len(self.orchestrator.running_agents), 0)
        
        print("✓ Orchestrator setup test passed")

    def test_task_creation_and_execution(self):
        """Test 2: Execution - Verify task creation and basic execution flow"""
        # Create test task
        task = AgentTask(
            task_id="test-task-1",
            task_type="analysis",
            prompt="Analyze test data",
            context={"test": "data"}
        )
        
        # Test task properties
        self.assertEqual(task.task_id, "test-task-1")
        self.assertEqual(task.task_type, "analysis")
        self.assertEqual(task.status, "pending")
        self.assertIsNone(task.result)
        self.assertIsNone(task.error)
        
        # Test task serialization
        task_dict = task.to_dict()
        self.assertIsInstance(task_dict, dict)
        self.assertEqual(task_dict["task_id"], "test-task-1")
        self.assertEqual(task_dict["status"], "pending")
        
        # Add task to orchestrator
        self.orchestrator.add_task(task)
        self.assertEqual(len(self.orchestrator.tasks), 1)
        self.assertIn("test-task-1", self.orchestrator.tasks)
        
        print("✓ Task creation and execution test passed")

    @patch('src.generic_orchestrator.subprocess')
    def test_validation_and_results(self, mock_subprocess):
        """Test 3: Validation - Verify result handling and validation"""
        # Mock subprocess execution
        mock_process = Mock()
        mock_process.stdout = '{"status": "success", "result": "test output"}'
        mock_process.stderr = ""
        mock_process.returncode = 0
        mock_subprocess.run.return_value = mock_process
        
        # Create and add test task
        task = AgentTask(
            task_id="test-validation-1",
            task_type="validation",
            prompt="Validate test scenario",
            context={"validation": "test"}
        )
        
        self.orchestrator.add_task(task)
        
        # Test task validation logic
        task_from_orchestrator = self.orchestrator.tasks["test-validation-1"]
        self.assertEqual(task_from_orchestrator.status, "pending")
        
        # Simulate task completion
        task_from_orchestrator.status = "completed"
        task_from_orchestrator.result = {
            "status": "success",
            "output": "test validation passed",
            "metrics": {"duration": 1.5}
        }
        
        # Test result validation
        self.assertEqual(task_from_orchestrator.status, "completed")
        self.assertIsNotNone(task_from_orchestrator.result)
        self.assertEqual(task_from_orchestrator.result["status"], "success")
        self.assertIn("output", task_from_orchestrator.result)
        self.assertIn("metrics", task_from_orchestrator.result)
        
        # Test error handling
        error_task = AgentTask(
            task_id="test-error-1",
            task_type="error_test",
            prompt="This should fail"
        )
        
        error_task.status = "failed"
        error_task.error = "Test error message"
        
        self.assertEqual(error_task.status, "failed")
        self.assertIsNotNone(error_task.error)
        self.assertEqual(error_task.error, "Test error message")
        
        print("✓ Validation and results test passed")


if __name__ == '__main__':
    # Run the tests
    print("Running basic agent orchestration tests...")
    print("=" * 50)
    
    unittest.main(verbosity=2)