#!/usr/bin/env python3
"""
Comprehensive tests for ExecutionPlan integration with the agent orchestrator.

Tests all execution modes, quality gate integration, and backward compatibility.
"""

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Import components to test
from src.execution_plan import (
    ExecutionPlan,
    TaskDefinition,
    QualityGate,
    ExecutionPhase,
    ExecutionMode,
    TaskType,
    QualityGateType,
    ValidationLevel
)
from src.execution_plan.template import ExecutionPlanBuilder
from src.execution_plan.adapter import ExecutionPlanAdapter
from src.enhanced_orchestrator import EnhancedOrchestrator, EnhancedAgentTask
from src.generic_orchestrator import GenericOrchestrator, AgentTask


class TestExecutionPlanIntegration(unittest.IsolatedAsyncioTestCase):
    """Test ExecutionPlan integration with orchestrator"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.output_dir = self.temp_dir / "output"
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def tearDown(self):
        """Clean up test environment"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_execution_plan_creation(self):
        """Test ExecutionPlan creation and validation"""
        
        # Create simple execution plan
        builder = ExecutionPlanBuilder(
            name="Test Plan", 
            description="Test execution plan"
        )
        
        builder.add_task(
            task_id="test_task",
            task_type=TaskType.GENERAL_PURPOSE,
            prompt="Test task prompt"
        )
        
        plan = builder.build()
        
        # Validate plan
        self.assertEqual(plan.name, "Test Plan")
        self.assertEqual(len(plan.tasks), 1)
        self.assertEqual(plan.tasks[0].task_id, "test_task")
        
        # Test validation
        errors = plan.validate()
        self.assertEqual(len(errors), 0)
    
    def test_execution_plan_validation_errors(self):
        """Test ExecutionPlan validation catches errors"""
        
        # Create plan with validation errors
        plan = ExecutionPlan(
            plan_id="",  # Missing plan_id
            name="",     # Missing name
            description="Test",
            tasks=[
                TaskDefinition(
                    task_id="task1",
                    task_type=TaskType.GENERAL_PURPOSE,
                    prompt="Task 1",
                    dependencies=["nonexistent_task"]  # Invalid dependency
                )
            ]
        )
        
        errors = plan.validate()
        self.assertGreater(len(errors), 0)
        self.assertTrue(any("plan_id is required" in error for error in errors))
        self.assertTrue(any("name is required" in error for error in errors))
        self.assertTrue(any("unknown dependency" in error for error in errors))
    
    def test_execution_plan_dependency_ordering(self):
        """Test dependency-based execution ordering"""
        
        builder = ExecutionPlanBuilder(name="Dependency Test")
        
        # Create tasks with dependencies
        builder.add_task("task_c", TaskType.GENERAL_PURPOSE, "Task C", dependencies=["task_b"])
        builder.add_task("task_b", TaskType.GENERAL_PURPOSE, "Task B", dependencies=["task_a"]) 
        builder.add_task("task_a", TaskType.GENERAL_PURPOSE, "Task A", dependencies=[])
        
        plan = builder.build()
        
        # Get execution order
        execution_order = plan.get_execution_order()
        
        # Verify correct ordering
        self.assertEqual(len(execution_order), 3)  # 3 batches
        self.assertEqual(execution_order[0], ["task_a"])  # A runs first
        self.assertEqual(execution_order[1], ["task_b"])  # B runs after A
        self.assertEqual(execution_order[2], ["task_c"])  # C runs after B
    
    def test_circular_dependency_detection(self):
        """Test circular dependency detection"""
        
        # Create plan with circular dependency
        plan = ExecutionPlan(
            plan_id="circular_test",
            name="Circular Test",
            description="Test circular dependencies",
            tasks=[
                TaskDefinition(
                    task_id="task_a",
                    task_type=TaskType.GENERAL_PURPOSE,
                    prompt="Task A",
                    dependencies=["task_b"]
                ),
                TaskDefinition(
                    task_id="task_b", 
                    task_type=TaskType.GENERAL_PURPOSE,
                    prompt="Task B",
                    dependencies=["task_a"]
                )
            ]
        )
        
        # Validation should catch circular dependency
        errors = plan.validate()
        self.assertTrue(any("circular dependency" in error.lower() for error in errors))
    
    def test_execution_plan_adapter_conversion(self):
        """Test ExecutionPlanAdapter converts plans correctly"""
        
        # Create test plan
        builder = ExecutionPlanBuilder(name="Adapter Test")
        builder.add_task(
            task_id="convert_test",
            task_type=TaskType.QA_TESTING_GURU,
            prompt="Test conversion",
            validation_level=ValidationLevel.STRICT
        )
        
        plan = builder.build()
        
        # Convert with adapter
        adapter = ExecutionPlanAdapter()
        converted = adapter.convert_execution_plan(plan)
        
        # Verify conversion
        self.assertIn("tasks", converted)
        self.assertIn("config", converted)
        self.assertEqual(len(converted["tasks"]), 1)
        
        enhanced_task = converted["tasks"][0]
        self.assertIsInstance(enhanced_task, EnhancedAgentTask)
        self.assertEqual(enhanced_task.task_id, "convert_test")
        self.assertEqual(enhanced_task.task_type, "qa-testing-guru")
        self.assertTrue(enhanced_task.validation_required)  # STRICT -> True
    
    def test_task_type_conversion(self):
        """Test task type enum to string conversion"""
        
        adapter = ExecutionPlanAdapter()
        
        # Test enum conversion
        self.assertEqual(
            adapter.convert_task_type(TaskType.GENERAL_PURPOSE), 
            "general-purpose"
        )
        self.assertEqual(
            adapter.convert_task_type(TaskType.DATABASE_SPECIALIST),
            "database-specialist"
        )
        
        # Test string passthrough
        self.assertEqual(
            adapter.convert_task_type("custom-agent-type"),
            "custom-agent-type"
        )
    
    def test_deterministic_uuid_generation(self):
        """Test deterministic UUID generation for reproducible logs"""
        
        adapter = ExecutionPlanAdapter()
        
        # Same inputs should generate same UUID
        uuid1 = adapter.generate_deterministic_uuid("task1", "plan1")
        uuid2 = adapter.generate_deterministic_uuid("task1", "plan1")
        self.assertEqual(uuid1, uuid2)
        
        # Different inputs should generate different UUIDs
        uuid3 = adapter.generate_deterministic_uuid("task2", "plan1")
        self.assertNotEqual(uuid1, uuid3)
        
        # Verify UUID format
        import re
        uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
        self.assertTrue(re.match(uuid_pattern, uuid1))
    
    @patch('src.enhanced_orchestrator.subprocess')
    async def test_enhanced_orchestrator_execution_plan_integration(self, mock_subprocess):
        """Test ExecutionPlan execution through EnhancedOrchestrator"""
        
        # Mock subprocess for agent execution
        mock_process = AsyncMock()
        mock_process.returncode = 0
        mock_process.communicate.return_value = (
            json.dumps({"status": "completed", "result": "success"}).encode(),
            b""
        )
        mock_subprocess.create_subprocess_exec.return_value = mock_process
        
        # Create orchestrator
        orchestrator = EnhancedOrchestrator(
            output_dir=self.output_dir,
            max_parallel=2,
            enable_quality_gates=False,  # Disable for simple test
            enable_monitoring=False
        )
        
        # Create simple execution plan
        builder = ExecutionPlanBuilder(name="Integration Test")
        builder.add_task(
            task_id="integration_task",
            task_type=TaskType.GENERAL_PURPOSE,
            prompt="Test integration"
        )
        
        plan = builder.build()
        
        # Execute plan
        result = await orchestrator.execute_plan(plan)
        
        # Verify execution
        self.assertEqual(result["plan_name"], "Integration Test")
        self.assertEqual(result["total_tasks"], 1)
        self.assertIn("results", result)
        self.assertIn("metrics", result)
    
    async def test_execution_modes(self):
        """Test different execution modes (parallel, sequential, mixed)"""
        
        # Mock orchestrator methods to avoid actual agent execution
        with patch.object(EnhancedOrchestrator, 'execute_agent') as mock_execute:
            mock_execute.return_value = {
                "task_id": "mock_task",
                "status": "completed",
                "result": {"success": True}
            }
            
            orchestrator = EnhancedOrchestrator(
                output_dir=self.output_dir,
                max_parallel=3,
                enable_quality_gates=False,
                enable_monitoring=False
            )
            
            # Test PARALLEL mode
            parallel_plan = ExecutionPlanBuilder(name="Parallel Test")
            parallel_plan.set_execution_mode(ExecutionMode.PARALLEL)
            for i in range(3):
                parallel_plan.add_task(f"parallel_task_{i}", TaskType.GENERAL_PURPOSE, f"Task {i}")
            
            parallel_result = await orchestrator.execute_plan(parallel_plan.build())
            self.assertEqual(parallel_result["execution_mode"], "parallel")
            
            # Test SEQUENTIAL mode  
            sequential_plan = ExecutionPlanBuilder(name="Sequential Test")
            sequential_plan.set_execution_mode(ExecutionMode.SEQUENTIAL)
            sequential_plan.add_task("seq_task_1", TaskType.GENERAL_PURPOSE, "Task 1")
            sequential_plan.add_task("seq_task_2", TaskType.GENERAL_PURPOSE, "Task 2", dependencies=["seq_task_1"])
            
            sequential_result = await orchestrator.execute_plan(sequential_plan.build())
            self.assertEqual(sequential_result["execution_mode"], "sequential")
    
    def test_quality_gate_conversion(self):
        """Test quality gate conversion from ExecutionPlan to orchestrator format"""
        
        adapter = ExecutionPlanAdapter()
        
        # Create test quality gate
        gate = QualityGate(
            gate_id="test_gate",
            name="Test Gate",
            description="Test quality gate",
            gate_type=QualityGateType.HTTP,
            config={"url": "http://test.com", "timeout": 30},
            dependencies=["prereq_gate"],
            timeout_seconds=120
        )
        
        # Convert
        converted = adapter.convert_quality_gate(gate)
        
        # Verify conversion
        self.assertEqual(converted["gate_id"], "test_gate")
        self.assertEqual(converted["validator_type"], "http")
        self.assertEqual(converted["config"]["url"], "http://test.com")
        self.assertEqual(converted["dependencies"], ["prereq_gate"])
        self.assertEqual(converted["timeout_seconds"], 120)
    
    def test_template_patterns(self):
        """Test pre-built template patterns"""
        
        # Test simple parallel plan
        from src.execution_plan.template import create_simple_parallel_plan
        
        tasks = [
            {
                "task_id": "task1",
                "task_type": "general-purpose",
                "prompt": "Task 1"
            },
            {
                "task_id": "task2", 
                "task_type": "qa-testing-guru",
                "prompt": "Task 2"
            }
        ]
        
        plan = create_simple_parallel_plan(
            name="Template Test",
            tasks=tasks,
            description="Test template"
        )
        
        self.assertEqual(plan.name, "Template Test")
        self.assertEqual(len(plan.tasks), 2)
        self.assertEqual(plan.execution_mode, ExecutionMode.PARALLEL)
        
        # Verify tasks
        task_ids = [task.task_id for task in plan.tasks]
        self.assertIn("task1", task_ids)
        self.assertIn("task2", task_ids)
    
    def test_sdlc_pipeline_template(self):
        """Test SDLC pipeline template creation"""
        
        from src.execution_plan.template import create_sdlc_pipeline_plan
        
        plan = create_sdlc_pipeline_plan(
            project_name="Test Project",
            requirements="Build a simple web app"
        )
        
        # Verify SDLC structure
        self.assertIn("Test Project", plan.name)
        self.assertEqual(plan.execution_mode, ExecutionMode.MIXED)
        
        # Should have multiple phases
        phase_ids = [phase.phase_id for phase in plan.phases]
        self.assertIn("discovery", phase_ids)
        self.assertIn("design", phase_ids)
        self.assertIn("development", phase_ids)
        self.assertIn("testing", phase_ids)
        self.assertIn("deployment", phase_ids)
        
        # Should have quality gates
        self.assertGreater(len(plan.quality_gates), 0)
        
        # Should have proper task dependencies
        task_deps = {task.task_id: task.dependencies for task in plan.tasks}
        
        # Design tasks should depend on discovery
        design_tasks = [tid for tid, deps in task_deps.items() if "design" in tid.lower()]
        discovery_tasks = [tid for tid in task_deps.keys() if "research" in tid.lower() or "requirements" in tid.lower()]
        
        if design_tasks and discovery_tasks:
            # At least one design task should depend on a discovery task
            has_dependency = any(
                any(dep in discovery_tasks for dep in task_deps[design_task])
                for design_task in design_tasks
            )
            self.assertTrue(has_dependency, "Design tasks should depend on discovery tasks")
    
    def test_compatibility_validation(self):
        """Test orchestrator compatibility validation"""
        
        adapter = ExecutionPlanAdapter()
        
        # Create plan with potential compatibility issues
        builder = ExecutionPlanBuilder(name="Compatibility Test")
        builder.set_execution_mode(ExecutionMode.MIXED, max_parallel=100)  # High parallel count
        
        # Add task with custom type
        builder.add_task("custom_task", "custom-agent-type", "Custom task")
        
        plan = builder.build()
        
        # Validate compatibility
        warnings = adapter.validate_orchestrator_compatibility(plan)
        
        # Should warn about high parallel count
        high_parallel_warning = any("high parallel" in warning.lower() for warning in warnings)
        self.assertTrue(high_parallel_warning)
        
        # Should warn about mixed mode
        mixed_mode_warning = any("mixed execution" in warning.lower() for warning in warnings)
        self.assertTrue(mixed_mode_warning)
    
    def test_json_serialization(self):
        """Test ExecutionPlan JSON serialization/deserialization"""
        
        # Create plan with various features
        builder = ExecutionPlanBuilder(name="JSON Test")
        builder.add_task(
            task_id="json_task",
            task_type=TaskType.TECHNICAL_WRITER,
            prompt="Write documentation",
            validation_level=ValidationLevel.STANDARD
        )
        
        builder.add_quality_gate(
            gate_id="docs_ready",
            name="Documentation Ready",
            description="Documentation is complete",
            gate_type=QualityGateType.FILE_EXISTS,
            config={"file_path": "docs/README.md"}
        )
        
        original_plan = builder.build()
        
        # Serialize to JSON
        json_str = original_plan.to_json()
        self.assertIsInstance(json_str, str)
        
        # Parse JSON
        json_data = json.loads(json_str)
        self.assertIn("plan_id", json_data)
        self.assertIn("tasks", json_data)
        self.assertIn("quality_gates", json_data)
        
        # Deserialize from JSON
        restored_plan = ExecutionPlan.from_json(json_str)
        
        # Verify restoration
        self.assertEqual(restored_plan.name, original_plan.name)
        self.assertEqual(len(restored_plan.tasks), len(original_plan.tasks))
        self.assertEqual(len(restored_plan.quality_gates), len(original_plan.quality_gates))
        
        # Verify task restoration
        original_task = original_plan.tasks[0]
        restored_task = restored_plan.tasks[0]
        self.assertEqual(restored_task.task_id, original_task.task_id)
        self.assertEqual(restored_task.task_type, original_task.task_type)
        
        # Verify quality gate restoration
        original_gate = original_plan.quality_gates[0] 
        restored_gate = restored_plan.quality_gates[0]
        self.assertEqual(restored_gate.gate_id, original_gate.gate_id)
        self.assertEqual(restored_gate.gate_type, original_gate.gate_type)
    
    def test_backward_compatibility(self):
        """Test that existing AgentTask functionality still works"""
        
        # Create regular AgentTask
        regular_task = AgentTask(
            task_id="regular_task",
            task_type="general-purpose", 
            prompt="Regular task test"
        )
        
        # Should be convertible to EnhancedAgentTask
        enhanced_task = EnhancedAgentTask(
            task_id=regular_task.task_id,
            task_type=regular_task.task_type,
            prompt=regular_task.prompt,
            dependencies=regular_task.dependencies,
            context=regular_task.context
        )
        
        # Verify conversion preserved data
        self.assertEqual(enhanced_task.task_id, regular_task.task_id)
        self.assertEqual(enhanced_task.task_type, regular_task.task_type)
        self.assertEqual(enhanced_task.prompt, regular_task.prompt)


if __name__ == "__main__":
    # Run tests
    unittest.main()