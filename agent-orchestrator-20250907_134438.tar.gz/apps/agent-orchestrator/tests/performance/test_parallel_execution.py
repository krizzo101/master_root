#!/usr/bin/env python3
"""
Test parallel execution with multiple tokens
Verifies that the orchestrator properly uses all available tokens
"""

import asyncio
import sys
import time
from pathlib import Path

sys.path.append(str(Path(__file__).parent / 'src'))
from generic_orchestrator import GenericOrchestrator, AgentTask

async def test_parallel_execution():
    """Test that multiple agents run in parallel"""
    
    output_dir = Path("/tmp/orchestrator_test")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create orchestrator with max parallelism
    orchestrator = GenericOrchestrator(
        output_dir=output_dir,
        max_parallel=15,  # Use all available tokens
        use_optimizations=True
    )
    
    print(f"Token pool size: {len(orchestrator.token_pool.tokens)}")
    print(f"Max parallel: {orchestrator.max_parallel}")
    
    # Create simple test tasks
    tasks = []
    for i in range(5):  # Test with 5 parallel tasks
        task = AgentTask(
            task_id=f"test_task_{i}",
            task_type="test",
            prompt=f"Write a simple Python function that returns the number {i}. Just the function, no explanation.",
            dependencies=[]
        )
        tasks.append(task)
    
    print(f"\nExecuting {len(tasks)} tasks in parallel...")
    start_time = time.time()
    
    # Execute tasks
    results = await orchestrator.execute_batch(tasks)
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"\n✅ Execution complete!")
    print(f"Duration: {duration:.2f} seconds")
    print(f"Tasks completed: {len(results)}")
    
    # Calculate if they ran in parallel
    avg_task_time = duration / len(tasks)
    if duration < 60:  # If all 5 tasks completed in under 60 seconds
        print(f"✅ PARALLEL EXECUTION CONFIRMED - Average time per task: {avg_task_time:.2f}s")
        print(f"   (Sequential would take ~{len(tasks) * 30}+ seconds)")
    else:
        print(f"⚠️  May have run sequentially - took {duration:.2f}s")
    
    # Show which tokens were used
    print(f"\nToken allocation:")
    for i, result in enumerate(results):
        print(f"  Task {i}: {result.get('task_id')} - Status: {result.get('status')}")
    
    return len(orchestrator.token_pool.tokens) > 1

if __name__ == "__main__":
    success = asyncio.run(test_parallel_execution())
    
    if success:
        print("\n✅ Orchestrator is working with multiple tokens!")
    else:
        print("\n⚠️  Orchestrator may be using only 1 token")
    
    sys.exit(0 if success else 1)