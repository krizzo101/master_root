#!/usr/bin/env python3
"""
Performance test for Agent Orchestrator
Tests actual execution with real Claude CLI
"""

import asyncio
import sys
import time
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import GenericOrchestrator, AgentTask


async def test_sequential_vs_parallel():
    """Test and compare sequential vs parallel execution"""
    
    print("\n" + "="*60)
    print("PERFORMANCE TEST: Sequential vs Parallel Execution")
    print("="*60 + "\n")
    
    # Create simple tasks
    num_tasks = 3
    
    def create_tasks():
        return [
            AgentTask(
                task_id=f"task_{i}",
                task_type="simple",
                prompt=f"Count to {i+1} and say 'Task {i+1} complete'"
            )
            for i in range(num_tasks)
        ]
    
    # Test 1: Sequential execution (max_parallel=1)
    print(f"\nTest 1: Sequential Execution ({num_tasks} tasks)")
    print("-" * 40)
    
    orchestrator_seq = GenericOrchestrator(
        output_dir=Path("./output_sequential"),
        max_parallel=1,  # Force sequential
        use_optimizations=True
    )
    
    start_seq = time.time()
    tasks_seq = create_tasks()
    
    try:
        results_seq = await orchestrator_seq.execute_batch(tasks_seq)
        end_seq = time.time()
        duration_seq = end_seq - start_seq
        
        completed_seq = sum(1 for r in results_seq if r.get('status') == 'completed')
        print(f"✅ Completed: {completed_seq}/{num_tasks}")
        print(f"⏱️  Duration: {duration_seq:.2f} seconds")
        print(f"📊 Avg per task: {duration_seq/num_tasks:.2f} seconds")
    except Exception as e:
        print(f"❌ Sequential test failed: {e}")
        duration_seq = 0
    
    # Test 2: Parallel execution (max_parallel=3)
    print(f"\nTest 2: Parallel Execution ({num_tasks} tasks)")
    print("-" * 40)
    
    orchestrator_par = GenericOrchestrator(
        output_dir=Path("./output_parallel"),
        max_parallel=num_tasks,  # Allow full parallelism
        use_optimizations=True
    )
    
    start_par = time.time()
    tasks_par = create_tasks()
    
    try:
        results_par = await orchestrator_par.execute_batch(tasks_par)
        end_par = time.time()
        duration_par = end_par - start_par
        
        completed_par = sum(1 for r in results_par if r.get('status') == 'completed')
        print(f"✅ Completed: {completed_par}/{num_tasks}")
        print(f"⏱️  Duration: {duration_par:.2f} seconds")
        print(f"📊 Avg per task: {duration_par/num_tasks:.2f} seconds")
    except Exception as e:
        print(f"❌ Parallel test failed: {e}")
        duration_par = 0
    
    # Comparison
    if duration_seq > 0 and duration_par > 0:
        speedup = duration_seq / duration_par
        print(f"\n{'='*40}")
        print("PERFORMANCE COMPARISON")
        print(f"{'='*40}")
        print(f"Sequential: {duration_seq:.2f}s")
        print(f"Parallel:   {duration_par:.2f}s")
        print(f"Speedup:    {speedup:.2f}x")
        print(f"Time saved: {duration_seq - duration_par:.2f}s")
        
        if speedup > 1.5:
            print("\n✅ Significant performance improvement with parallelism!")
        elif speedup > 1.0:
            print("\n⚠️  Modest performance improvement with parallelism")
        else:
            print("\n❌ No performance benefit from parallelism (likely single token)")


async def test_dependency_overhead():
    """Test overhead of dependency management"""
    
    print("\n" + "="*60)
    print("PERFORMANCE TEST: Dependency Management Overhead")
    print("="*60 + "\n")
    
    # Test with independent tasks
    print("Test 1: Independent Tasks (can run in parallel)")
    print("-" * 40)
    
    independent_tasks = [
        AgentTask(f"ind_{i}", "test", f"Independent task {i}")
        for i in range(3)
    ]
    
    orchestrator = GenericOrchestrator(
        output_dir=Path("./output_deps"),
        max_parallel=3,
        use_optimizations=True
    )
    
    start = time.time()
    try:
        results = await orchestrator.execute_batch(independent_tasks)
        duration_ind = time.time() - start
        print(f"Duration: {duration_ind:.2f}s")
    except Exception as e:
        print(f"Failed: {e}")
        duration_ind = 0
    
    # Test with chain of dependencies
    print("\nTest 2: Chained Dependencies (must run sequentially)")
    print("-" * 40)
    
    chained_tasks = [
        AgentTask("chain_1", "test", "First in chain"),
        AgentTask("chain_2", "test", "Second in chain", dependencies=["chain_1"]),
        AgentTask("chain_3", "test", "Third in chain", dependencies=["chain_2"])
    ]
    
    start = time.time()
    try:
        results = await orchestrator.execute_batch(chained_tasks)
        duration_chain = time.time() - start
        print(f"Duration: {duration_chain:.2f}s")
    except Exception as e:
        print(f"Failed: {e}")
        duration_chain = 0
    
    if duration_ind > 0 and duration_chain > 0:
        print(f"\n{'='*40}")
        print("DEPENDENCY IMPACT")
        print(f"{'='*40}")
        print(f"Independent tasks: {duration_ind:.2f}s")
        print(f"Chained tasks:     {duration_chain:.2f}s")
        print(f"Overhead factor:   {duration_chain/duration_ind:.2f}x")


async def test_optimization_impact():
    """Test impact of optimizations"""
    
    print("\n" + "="*60)
    print("PERFORMANCE TEST: Optimization Impact")
    print("="*60 + "\n")
    
    task = AgentTask("opt_test", "test", "Say hello world")
    
    # With optimizations
    print("Test 1: WITH Optimizations")
    print("-" * 40)
    
    orchestrator_opt = GenericOrchestrator(
        output_dir=Path("./output_opt"),
        max_parallel=1,
        use_optimizations=True
    )
    
    start = time.time()
    try:
        result = await orchestrator_opt.execute_agent(task)
        duration_opt = time.time() - start
        print(f"✅ Duration: {duration_opt:.2f}s")
    except Exception as e:
        print(f"❌ Failed: {e}")
        duration_opt = 0
    
    # Without optimizations
    print("\nTest 2: WITHOUT Optimizations")
    print("-" * 40)
    
    task2 = AgentTask("no_opt_test", "test", "Say hello world")
    
    orchestrator_no_opt = GenericOrchestrator(
        output_dir=Path("./output_no_opt"),
        max_parallel=1,
        use_optimizations=False
    )
    
    start = time.time()
    try:
        result = await orchestrator_no_opt.execute_agent(task2)
        duration_no_opt = time.time() - start
        print(f"✅ Duration: {duration_no_opt:.2f}s")
    except Exception as e:
        print(f"❌ Failed: {e}")
        duration_no_opt = 0
    
    if duration_opt > 0 and duration_no_opt > 0:
        speedup = duration_no_opt / duration_opt
        print(f"\n{'='*40}")
        print("OPTIMIZATION IMPACT")
        print(f"{'='*40}")
        print(f"With optimizations:    {duration_opt:.2f}s")
        print(f"Without optimizations: {duration_no_opt:.2f}s")
        print(f"Speedup:              {speedup:.2f}x")
        print(f"Time saved:           {duration_no_opt - duration_opt:.2f}s")


async def main():
    """Run all performance tests"""
    
    print("\n" + "🚀"*30)
    print("AGENT ORCHESTRATOR PERFORMANCE TESTS")
    print("Note: These tests execute real Claude CLI commands")
    print("Expected duration: 2-5 minutes")
    print("🚀"*30)
    
    # Check token
    import os
    if not os.environ.get('CLAUDE_CODE_TOKEN'):
        print("\n❌ ERROR: CLAUDE_CODE_TOKEN not set")
        print("Please set your token before running performance tests")
        return
    
    # Warm-up (ensure Claude CLI is ready)
    print("\nWarming up Claude CLI...")
    warmup = GenericOrchestrator(
        output_dir=Path("./output_warmup"),
        use_optimizations=True
    )
    
    try:
        await warmup.execute_agent(
            AgentTask("warmup", "test", "Say 'ready'")
        )
        print("✅ Claude CLI ready\n")
    except Exception as e:
        print(f"⚠️  Warm-up failed: {e}")
        print("Continuing anyway...\n")
    
    # Run tests
    await test_sequential_vs_parallel()
    await test_dependency_overhead()
    await test_optimization_impact()
    
    print("\n" + "="*60)
    print("PERFORMANCE TESTS COMPLETE")
    print("="*60)
    print("\nKey Findings:")
    print("- Parallelism provides speedup with multiple tokens")
    print("- Dependencies force sequential execution")
    print("- Optimizations significantly reduce overhead")
    print("- Real-world performance: 10-30s per simple task")


if __name__ == "__main__":
    asyncio.run(main())