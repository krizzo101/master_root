#!/usr/bin/env python3
"""
Test maximum parallel execution with all available tokens
"""

import asyncio
import sys
import time
from pathlib import Path

sys.path.append('src')
from practical_orchestrator import PracticalOrchestrator, PracticalAgentTask

async def test_maximum_parallel():
    """Test with maximum parallel execution"""
    
    print("🚀 TESTING MAXIMUM PARALLEL EXECUTION")
    print("=" * 50)
    
    # Create orchestrator with maximum parallel
    orchestrator = PracticalOrchestrator(
        output_dir="./test_max_parallel_output",
        max_parallel=18,  # Use all available tokens
        enable_monitoring=True
    )
    
    print(f"⚡ Token pool size: {orchestrator.token_pool.size()}")
    print(f"⚡ Max parallel: {orchestrator.max_parallel}")
    
    # Progress monitoring
    progress_events = []
    def progress_monitor(event_type: str, data: dict):
        timestamp = time.strftime("%H:%M:%S.%f")[:-3]  # Include milliseconds
        progress_events.append((timestamp, event_type, data))
        print(f"[{timestamp}] 📊 {event_type}: {data}")
    
    orchestrator.set_progress_callback(progress_monitor)
    
    # Create 18 simple tasks to test maximum parallel
    tasks = []
    for i in range(18):
        task = PracticalAgentTask(
            task_id=f"max_parallel_task_{i+1:02d}",
            task_type="development-specialist",
            prompt=f"""Create a simple test function for task {i+1}.
            
            Requirements:
            1. Create a Python function called 'test_function_{i+1}'
            2. The function should return 'Task {i+1} executed successfully'
            3. Add a simple docstring
            4. Include a basic test case
            """,
            phase_id="max_parallel_test",
            priority="normal" if i < 12 else "high",  # Mix priorities
            tags=["test", "parallel", f"batch_{i//6 + 1}"]  # Group into batches
        )
        tasks.append(task)
    
    print(f"\n🧪 Testing with {len(tasks)} parallel tasks...")
    print(f"📍 Session IDs generated:")
    for i, task in enumerate(tasks[:5], 1):  # Show first 5
        print(f"  {task.task_id} → {task.session_id}")
    print(f"  ... and {len(tasks)-5} more")
    
    # Execute all tasks
    start_time = time.time()
    print(f"\n⏱️  Starting execution at {time.strftime('%H:%M:%S')}")
    
    try:
        results = await orchestrator.execute_batch(tasks)
        end_time = time.time()
        
        # Analyze results
        completed = len([r for r in results if isinstance(r, dict) and r.get("status") == "completed"])
        failed = len([r for r in results if isinstance(r, dict) and r.get("status") == "failed"]) 
        errors = len([r for r in results if isinstance(r, Exception)])
        
        total_duration = end_time - start_time
        
        print(f"\n📊 EXECUTION RESULTS")
        print("=" * 30)
        print(f"⏱️  Total time: {total_duration:.2f} seconds")
        print(f"✅ Completed: {completed}")
        print(f"❌ Failed: {failed}")
        print(f"💥 Errors: {errors}")
        print(f"📈 Success rate: {completed/len(tasks):.1%}")
        print(f"⚡ Tasks per second: {completed/total_duration:.2f}")
        
        # Show parallelization effectiveness
        theoretical_sequential_time = len(tasks) * 30  # Assume 30s per task
        parallelization_speedup = theoretical_sequential_time / total_duration if total_duration > 0 else 0
        
        print(f"\n🚀 PARALLELIZATION ANALYSIS")
        print("=" * 30)
        print(f"📏 Theoretical sequential time: {theoretical_sequential_time//60:.0f}m {theoretical_sequential_time%60:.0f}s")
        print(f"⚡ Actual parallel time: {total_duration//60:.0f}m {total_duration%60:.0f}s")
        print(f"🎯 Speedup factor: {parallelization_speedup:.1f}x")
        
        # Show quality report info
        quality_file = Path("./test_max_parallel_output/quality_report.json")
        if quality_file.exists():
            print(f"📊 Quality report: {quality_file}")
        
        return completed == len(tasks)
        
    except Exception as e:
        print(f"\n💥 EXECUTION FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🧪 MAXIMUM PARALLEL EXECUTION TEST")
    print("This will test PracticalOrchestrator with 18 parallel tasks")
    print("=" * 60)
    
    try:
        success = asyncio.run(test_maximum_parallel())
        
        if success:
            print(f"\n🎉 SUCCESS! Maximum parallel execution is working!")
            print(f"🚀 PracticalOrchestrator ready for production use")
        else:
            print(f"\n⚠️  Some issues detected. Check the output above.")
            
    except KeyboardInterrupt:
        print(f"\n👋 Test cancelled")
    except Exception as e:
        print(f"\n💥 Test failed: {e}")