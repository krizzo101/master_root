#!/usr/bin/env python3
"""
Detailed test to verify parallel execution is actually happening
"""

import asyncio
import json
import sys
import time
from pathlib import Path
from datetime import datetime

sys.path.append(str(Path(__file__).parent / 'src'))
from generic_orchestrator import GenericOrchestrator, AgentTask

async def test_with_detailed_logging():
    """Test with detailed timing to verify parallelism"""
    
    output_dir = Path("/tmp/parallel_test_detailed")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Create orchestrator
    orchestrator = GenericOrchestrator(
        output_dir=output_dir,
        max_parallel=15
    )
    
    print(f"=" * 60)
    print(f"ORCHESTRATOR CONFIGURATION")
    print(f"=" * 60)
    print(f"Token pool size: {len(orchestrator.token_pool.tokens)}")
    print(f"Max parallel: {orchestrator.max_parallel}")
    print(f"Output dir: {output_dir}")
    
    # Create test tasks with more complex prompts
    tasks = []
    for i in range(3):  # Start with just 3 tasks
        task = AgentTask(
            task_id=f"task_{i}",
            task_type="test",
            prompt=f"""Create a Python function called 'process_{i}' that:
1. Takes a list of numbers as input
2. Filters out numbers less than {i}
3. Returns the sum of remaining numbers
Include a docstring and type hints.""",
            dependencies=[]
        )
        tasks.append(task)
    
    print(f"\n" + "=" * 60)
    print(f"EXECUTING {len(tasks)} TASKS")
    print(f"=" * 60)
    
    # Record individual task timings
    task_starts = {}
    task_ends = {}
    
    # Start time
    overall_start = time.time()
    print(f"Start time: {datetime.now().strftime('%H:%M:%S.%f')}")
    
    # Execute tasks and monitor
    print("\nTask execution timeline:")
    
    # We need to trace actual execution
    results = []
    for task in tasks:
        task_starts[task.task_id] = time.time()
        print(f"  {datetime.now().strftime('%H:%M:%S.%f')} - Starting {task.task_id}")
    
    # Execute batch
    results = await orchestrator.execute_batch(tasks)
    
    overall_end = time.time()
    overall_duration = overall_end - overall_start
    
    print(f"\nEnd time: {datetime.now().strftime('%H:%M:%S.%f')}")
    print(f"Total duration: {overall_duration:.2f} seconds")
    
    # Analyze results
    print(f"\n" + "=" * 60)
    print(f"RESULTS ANALYSIS")
    print(f"=" * 60)
    
    for i, result in enumerate(results):
        task_file = output_dir / "tasks" / f"{result['task_id']}.json"
        if task_file.exists():
            task_data = json.loads(task_file.read_text())
            
            # Check timing from the task data
            if 'start_time' in task_data and 'end_time' in task_data:
                task_duration = task_data['end_time'] - task_data['start_time']
                print(f"\n{result['task_id']}:")
                print(f"  Status: {task_data['status']}")
                print(f"  Duration: {task_duration:.2f}s")
                print(f"  Start: {task_data['start_time']}")
                print(f"  End: {task_data['end_time']}")
                
                # Check if actual code was generated
                if task_data.get('result', {}).get('result'):
                    code = task_data['result']['result']
                    print(f"  Generated code: {len(code)} characters")
                    if 'def process_' in code:
                        print(f"  ✓ Correct function generated")
                else:
                    print(f"  ✗ No code generated")
    
    # Determine if parallel
    print(f"\n" + "=" * 60)
    print(f"PARALLEL EXECUTION ANALYSIS")
    print(f"=" * 60)
    
    avg_task_time = overall_duration / len(tasks)
    print(f"Average time per task: {avg_task_time:.2f}s")
    
    # Check task overlap by looking at actual timestamps
    task_files = list((output_dir / "tasks").glob("*.json"))
    if len(task_files) >= 2:
        times = []
        for tf in task_files:
            data = json.loads(tf.read_text())
            if 'start_time' in data and 'end_time' in data:
                times.append({
                    'task': tf.stem,
                    'start': data['start_time'],
                    'end': data['end_time']
                })
        
        # Sort by start time
        times.sort(key=lambda x: x['start'])
        
        # Check for overlap
        overlaps = []
        for i in range(len(times) - 1):
            if times[i]['end'] > times[i+1]['start']:
                overlaps.append((times[i]['task'], times[i+1]['task']))
                print(f"  ✓ {times[i]['task']} and {times[i+1]['task']} ran in parallel")
        
        if overlaps:
            print(f"\n✅ CONFIRMED: {len(overlaps)} task pairs ran in parallel")
        else:
            print(f"\n⚠️  WARNING: No task overlap detected - may be sequential")
    
    # Final verdict
    print(f"\n" + "=" * 60)
    if overall_duration < len(tasks) * 10:  # Assuming ~10s per sequential task minimum
        print(f"✅ PARALLEL EXECUTION LIKELY")
        print(f"   {len(tasks)} tasks in {overall_duration:.2f}s")
        print(f"   Sequential estimate: {len(tasks) * 10}+ seconds")
    else:
        print(f"⚠️  SEQUENTIAL EXECUTION SUSPECTED")
        print(f"   {len(tasks)} tasks took {overall_duration:.2f}s")
    
    return len(orchestrator.token_pool.tokens) > 1 and overall_duration < len(tasks) * 10

if __name__ == "__main__":
    success = asyncio.run(test_with_detailed_logging())
    sys.exit(0 if success else 1)