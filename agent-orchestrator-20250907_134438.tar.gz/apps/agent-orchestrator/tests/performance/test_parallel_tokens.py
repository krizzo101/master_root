#!/usr/bin/env python3
"""
Test parallel execution with multiple tokens from encrypted storage
"""

import asyncio
import sys
import time
from pathlib import Path
from datetime import datetime

sys.path.insert(0, "src")

from generic_orchestrator import GenericOrchestrator, AgentTask


async def test_parallel_with_tokens():
    """Test that multiple tokens enable true parallel execution"""
    
    print("\n" + "="*60)
    print("TESTING PARALLEL EXECUTION WITH ENCRYPTED TOKENS")
    print("="*60 + "\n")
    
    # Create orchestrator - should auto-load tokens
    orchestrator = GenericOrchestrator(
        output_dir=Path("./output_parallel_test"),
        max_parallel=15,  # Allow using all tokens
        use_optimizations=True
    )
    
    print(f"✅ Orchestrator initialized")
    print(f"📊 Token pool size: {orchestrator.token_pool.size()}")
    print(f"⚡ Max parallel: {orchestrator.max_parallel}")
    print(f"🚀 Effective parallelism: {min(orchestrator.token_pool.size(), orchestrator.max_parallel)}")
    
    # Create independent tasks that can run in parallel
    num_tasks = 5  # Start with 5 for quick test
    
    tasks = [
        AgentTask(
            task_id=f"parallel_task_{i}",
            task_type="simple",
            prompt=f"Say 'Task {i} executing with token' and return immediately"
        )
        for i in range(1, num_tasks + 1)
    ]
    
    print(f"\n📋 Created {num_tasks} independent tasks")
    print("⏱️  Starting parallel execution...\n")
    
    start_time = time.time()
    
    try:
        # Execute all tasks
        results = await orchestrator.execute_batch(tasks)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Analyze results
        completed = sum(1 for r in results if r.get('status') == 'completed')
        failed = sum(1 for r in results if r.get('status') == 'failed')
        
        print(f"\n{'='*40}")
        print("RESULTS")
        print(f"{'='*40}")
        print(f"✅ Completed: {completed}/{num_tasks}")
        print(f"❌ Failed: {failed}/{num_tasks}")
        print(f"⏱️  Total duration: {duration:.2f} seconds")
        print(f"📊 Average per task: {duration/num_tasks:.2f} seconds")
        
        # Check if tasks ran in parallel
        if duration < (num_tasks * 10):  # Assuming each task takes ~10-20s
            print(f"\n🎉 SUCCESS: Tasks executed in parallel!")
            print(f"   Sequential would take ~{num_tasks * 15}s")
            print(f"   Actual time: {duration:.2f}s")
            print(f"   Speedup: ~{(num_tasks * 15) / duration:.1f}x")
        else:
            print(f"\n⚠️  Tasks may have run sequentially")
            
    except Exception as e:
        print(f"\n❌ Error during execution: {e}")
        import traceback
        traceback.print_exc()


async def test_token_rotation():
    """Test that tokens are properly rotated"""
    
    print("\n" + "="*60)
    print("TESTING TOKEN ROTATION")
    print("="*60 + "\n")
    
    orchestrator = GenericOrchestrator(
        output_dir=Path("./output_rotation_test"),
        max_parallel=3
    )
    
    print(f"Token pool size: {orchestrator.token_pool.size()}")
    
    # Test acquiring tokens in sequence
    print("\nTesting round-robin token allocation:")
    
    for i in range(10):
        token, idx = await orchestrator.token_pool.acquire()
        print(f"  Request {i+1}: Got token index {idx}")
    
    print("\n✅ Token rotation working correctly")


async def main():
    """Run all token tests"""
    
    print("\n🔐 ENCRYPTED TOKEN INTEGRATION TEST")
    print("="*60)
    
    # First verify tokens are loaded
    from token_loader import load_tokens_from_secrets
    tokens = load_tokens_from_secrets()
    
    if not tokens:
        print("❌ No tokens found! Cannot proceed with parallel testing.")
        print("\nTo set up tokens:")
        print("1. Check /home/opsvi/master_root/apps/multi-agent-monitor/.secrets/")
        print("2. Or set CLAUDE_CODE_TOKEN environment variable")
        return
    
    print(f"\n✅ Found {len(tokens)} tokens in encrypted storage")
    print("Ready for parallel execution testing!\n")
    
    # Run tests
    await test_token_rotation()
    await test_parallel_with_tokens()
    
    print("\n" + "="*60)
    print("TOKEN INTEGRATION TEST COMPLETE")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())