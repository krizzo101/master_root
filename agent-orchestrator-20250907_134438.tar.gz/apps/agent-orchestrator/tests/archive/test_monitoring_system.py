#!/usr/bin/env python3
"""
Test script for the real-time monitoring system
Validates monitoring integration, metrics collection, and dashboard functionality
"""
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

# Add current directory to path
sys.path.append(str(Path(__file__).parent))

from src.generic_orchestrator import AgentTask
from src.monitoring import (
    MetricsCollector,
    MetricType,
    RealtimeMonitor,
    DashboardServer,
    MonitoringWebSocketServer
)
from src.monitoring.orchestrator_integration import (
    MonitoredGenericOrchestrator,
    run_monitored_orchestrator_batch
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_metrics_collector():
    """Test the metrics collection system"""
    print("🧪 Testing MetricsCollector...")
    
    collector = MetricsCollector(history_size=100)
    
    # Test basic metric recording
    collector.record_task_started("test_task_1", "agent_1")
    collector.record_task_completed("test_task_1", "agent_1", execution_time=1.5)
    collector.record_token_usage("agent_1", input_tokens=100, output_tokens=50)
    
    # Test failure recording
    collector.record_task_started("test_task_2", "agent_2")
    collector.record_task_failed("test_task_2", "agent_2", error="Test error")
    
    # Wait for aggregation
    await asyncio.sleep(1)
    
    # Check summary
    summary = collector.get_summary()
    print(f"   ✅ Summary - Total: {summary.total_tasks}, Completed: {summary.completed_tasks}, Failed: {summary.failed_tasks}")
    
    # Test recent metrics
    recent_metrics = collector.get_recent_metrics(60)
    print(f"   ✅ Recent metrics: {len(recent_metrics)} entries")
    
    # Test active tasks
    active_tasks = collector.get_active_tasks()
    print(f"   ✅ Active tasks: {len(active_tasks)}")
    
    collector.shutdown()
    print("   ✅ MetricsCollector test passed\n")
    
    return True


async def test_monitored_orchestrator():
    """Test the monitored orchestrator integration"""
    print("🧪 Testing MonitoredGenericOrchestrator...")
    
    output_dir = Path(__file__).parent / "test_monitoring_output"
    output_dir.mkdir(exist_ok=True)
    
    # Create test tasks
    tasks = [
        AgentTask(
            task_id="monitor_test_1",
            task_type="general-purpose",
            prompt="Analyze the current date and time, then provide a brief summary."
        ),
        AgentTask(
            task_id="monitor_test_2", 
            task_type="general-purpose",
            prompt="List 5 benefits of automated testing in software development."
        )
    ]
    
    try:
        # Test with monitoring
        results, metrics_summary = await run_monitored_orchestrator_batch(
            tasks=tasks,
            output_dir=output_dir,  # Pass Path object
            max_parallel=2
        )
        
        print(f"   ✅ Executed {len(results)} tasks")
        print(f"   ✅ Metrics - Total: {metrics_summary['total_tasks']}, Completed: {metrics_summary['completed_tasks']}")
        print(f"   ✅ Average execution time: {metrics_summary['average_execution_time']:.1f}s")
        
        return True
    
    except Exception as e:
        print(f"   ❌ MonitoredGenericOrchestrator test failed: {e}")
        return False
    
    finally:
        print("   ✅ MonitoredGenericOrchestrator test completed\n")


async def test_websocket_server():
    """Test the WebSocket server functionality"""
    print("🧪 Testing MonitoringWebSocketServer...")
    
    collector = MetricsCollector()
    server = MonitoringWebSocketServer(port=8777, collector=collector)  # Different port
    
    try:
        # Start server
        await server.start_server()
        print("   ✅ WebSocket server started")
        
        # Simulate some metrics
        collector.record_task_started("ws_test_1")
        collector.record_task_completed("ws_test_1", execution_time=0.5)
        
        stats = server.get_server_stats()
        print(f"   ✅ Server stats: {stats}")
        
        # Stop server
        await server.stop_server()
        print("   ✅ WebSocket server stopped")
        
        return True
    
    except Exception as e:
        print(f"   ❌ WebSocket server test failed: {e}")
        return False
    
    finally:
        collector.shutdown()
        print("   ✅ WebSocket server test completed\n")


async def test_dashboard_server():
    """Test the dashboard server"""
    print("🧪 Testing DashboardServer...")
    
    collector = MetricsCollector()
    dashboard = DashboardServer(port=8778, collector=collector)  # Different port
    
    try:
        # Start server
        await dashboard.start_server()
        print("   ✅ Dashboard server started")
        
        # Add some test data
        collector.record_task_started("dashboard_test_1")
        collector.record_task_completed("dashboard_test_1", execution_time=1.0)
        
        await asyncio.sleep(1)  # Let metrics aggregate
        
        print(f"   ✅ Dashboard accessible at http://localhost:8778")
        
        return True
    
    except Exception as e:
        print(f"   ❌ Dashboard server test failed: {e}")
        return False
    
    finally:
        collector.shutdown()
        print("   ✅ Dashboard server test completed\n")


async def test_realtime_monitor_integration():
    """Test the complete realtime monitor system"""
    print("🧪 Testing RealtimeMonitor integration...")
    
    monitor = RealtimeMonitor(
        dashboard_port=8779,    # Different ports
        websocket_port=8780
    )
    
    try:
        # Start monitoring system
        await monitor.start()
        print("   ✅ RealtimeMonitor started")
        
        # Generate some test metrics
        collector = monitor.collector
        for i in range(5):
            collector.record_task_started(f"integration_test_{i}")
            await asyncio.sleep(0.1)
            collector.record_task_completed(f"integration_test_{i}", execution_time=0.2)
        
        # Check status
        status = monitor.get_status()
        print(f"   ✅ Monitor status: Running={status['running']}")
        print(f"   ✅ Active tasks: {status['metrics_collector']['active_tasks']}")
        
        # Stop monitoring system
        await monitor.stop()
        print("   ✅ RealtimeMonitor stopped")
        
        return True
    
    except Exception as e:
        print(f"   ❌ RealtimeMonitor test failed: {e}")
        return False
    
    finally:
        print("   ✅ RealtimeMonitor integration test completed\n")


async def run_monitoring_demo():
    """Run a comprehensive demo of the monitoring system"""
    print("🚀 Running Monitoring System Demo...")
    print("=" * 50)
    
    # Start the full monitoring system
    monitor = RealtimeMonitor(
        dashboard_port=8781,
        websocket_port=8782
    )
    
    try:
        await monitor.start()
        print("📊 Monitoring system started!")
        print("🌐 Dashboard: http://localhost:8781")
        print("🔌 WebSocket API: ws://localhost:8782")
        
        # Create a realistic workload
        output_dir = Path(__file__).parent / "demo_monitoring_output"
        output_dir.mkdir(exist_ok=True)
        
        # Create orchestrator with monitoring
        orchestrator = MonitoredGenericOrchestrator(
            output_dir=str(output_dir),
            max_parallel=3,
            collector=monitor.collector
        )
        
        # Create demo tasks
        demo_tasks = [
            AgentTask(
                task_id="demo_analysis",
                task_type="research-genius", 
                prompt="Analyze the benefits of real-time monitoring in distributed systems"
            ),
            AgentTask(
                task_id="demo_architecture",
                task_type="solution-architect",
                prompt="Design a scalable architecture for a microservices monitoring system"
            ),
            AgentTask(
                task_id="demo_implementation",
                task_type="development-specialist",
                prompt="Create a sample monitoring dashboard component using modern web technologies"
            ),
            AgentTask(
                task_id="demo_testing", 
                task_type="qa-testing-guru",
                prompt="Design comprehensive test cases for a real-time monitoring system"
            ),
            AgentTask(
                task_id="demo_documentation",
                task_type="technical-writer",
                prompt="Write user documentation for a monitoring dashboard interface"
            )
        ]
        
        print(f"\n🎯 Executing {len(demo_tasks)} demo tasks...")
        
        # Execute tasks
        start_time = time.time()
        results = await orchestrator.execute_batch(demo_tasks)
        execution_time = time.time() - start_time
        
        print(f"⚡ Execution completed in {execution_time:.1f} seconds")
        
        # Show metrics summary
        await asyncio.sleep(2)  # Wait for metrics aggregation
        summary = monitor.collector.get_summary()
        
        print(f"\n📈 Final Metrics Summary:")
        print(f"   Total Tasks: {summary.total_tasks}")
        print(f"   Completed: {summary.completed_tasks}")
        print(f"   Failed: {summary.failed_tasks}")
        print(f"   Average Execution Time: {summary.average_execution_time:.1f}s")
        print(f"   Throughput: {summary.throughput_per_minute:.1f} tasks/min")
        print(f"   Error Rate: {summary.error_rate * 100:.1f}%")
        
        # Keep servers running for manual testing
        print(f"\n🎮 Demo servers running...")
        print(f"   Visit http://localhost:8781 to see the live dashboard")
        print(f"   Press Ctrl+C to stop the demo")
        
        # Wait for user interrupt
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 Stopping demo...")
    
    finally:
        await monitor.stop()
        print("✅ Demo completed successfully!")


async def main():
    """Main test runner"""
    print("🧪 Agent Orchestrator Monitoring System Tests")
    print("=" * 60)
    
    tests = [
        ("Metrics Collector", test_metrics_collector),
        ("Monitored Orchestrator", test_monitored_orchestrator),
        ("WebSocket Server", test_websocket_server),
        ("Dashboard Server", test_dashboard_server),
        ("RealtimeMonitor Integration", test_realtime_monitor_integration)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            if result:
                passed += 1
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
    
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if len(sys.argv) > 1 and sys.argv[1] == "--demo":
        print("\n" + "=" * 60)
        await run_monitoring_demo()
    
    return 0 if passed == total else 1


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n👋 Tests interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Test runner failed: {e}")
        sys.exit(1)