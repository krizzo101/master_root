#!/usr/bin/env python3
"""
Test CollaborativeOrchestrator backwards compatibility and new features
"""

import asyncio
import tempfile
import json
from pathlib import Path
from typing import List

# Add src to path
import sys
sys.path.append(str(Path(__file__).parent / "src"))

from collaborative_orchestrator import (
    CollaborativeOrchestrator,
    CollaborativeTask,
    CollaborationConfig,
    run_traditional,
)
from generic_orchestrator import AgentTask


async def test_backwards_compatibility():
    """Test that CollaborativeOrchestrator works as drop-in replacement"""
    print("🔄 Testing backwards compatibility...")
    
    # Create orchestrator without collaboration config (traditional mode)
    output_dir = Path(tempfile.mkdtemp(prefix="compat_test_"))
    
    orchestrator = CollaborativeOrchestrator(
        output_dir=output_dir,
        max_parallel=2,
        # No collaboration_config = traditional mode
    )
    
    def generate_traditional_tasks() -> List[AgentTask]:
        return [
            AgentTask(
                task_id="test_task_1",
                task_type="research", 
                prompt="Test research task - should work exactly like GenericOrchestrator",
                dependencies=[],
            ),
        ]
    
    async def process_results(results: List[dict]):
        assert len(results) == 1
        assert results[0]['task_id'] == "test_task_1"
        print(f"  ✅ Task completed: {results[0]['status']}")
    
    # Use traditional interface
    results = await run_traditional(
        orchestrator=orchestrator,
        task_generator=generate_traditional_tasks,
        result_processor=process_results,
    )
    
    # Verify traditional results structure
    assert 'metrics' in results
    assert 'results' in results
    assert results['metrics']['total'] == 1
    
    print("  ✅ Backwards compatibility verified")
    return True


async def test_collaborative_features():
    """Test new collaborative features"""
    print("🤝 Testing collaborative features...")
    
    # Create orchestrator with collaboration
    output_dir = Path(tempfile.mkdtemp(prefix="collab_test_"))
    
    collaboration_config = CollaborationConfig(
        enable_messaging=True,
        enable_shared_workspace=True,
        enable_team_formation=True,
        max_team_size=3,
    )
    
    orchestrator = CollaborativeOrchestrator(
        output_dir=output_dir,
        max_parallel=2,
        collaboration_config=collaboration_config,
    )
    
    # Test collaborative tasks
    tasks = [
        CollaborativeTask(
            task_id="collab_task_1",
            task_type="research",
            prompt="Test collaborative research - agents should be able to communicate",
            collaboration_enabled=True,
            required_capabilities=["research"],
            collaboration_mode="shared",
        ),
        
        CollaborativeTask(
            task_id="collab_task_2", 
            task_type="synthesis",
            prompt="Test collaborative synthesis building on research",
            dependencies=["collab_task_1"],
            collaboration_enabled=True,
            required_capabilities=["synthesis"],
            collaboration_mode="review",
        ),
    ]
    
    # Execute collaborative tasks
    results = await orchestrator.run_collaborative(tasks=tasks)
    
    # Verify collaborative results structure
    assert 'metrics' in results
    assert 'results' in results 
    assert 'collaboration_events' in results
    assert 'message_history' in results
    
    assert results['metrics']['total'] == 2
    assert len(results['results']) == 2
    
    # Check collaboration-specific data
    for task_result in results['results']:
        assert 'collaboration_enabled' in task_result
        assert 'assigned_agents' in task_result
        if task_result['collaboration_enabled']:
            print(f"  ✅ Collaborative task: {task_result['task_id']}")
    
    # Check collaboration summary was created
    summary_file = output_dir / "collaboration_summary.json"
    assert summary_file.exists()
    
    with open(summary_file) as f:
        summary = json.load(f)
    
    assert 'execution_mode' in summary
    assert 'collaboration_config' in summary
    assert 'collaboration_events' in summary
    
    print(f"  ✅ Collaboration events logged: {len(results['collaboration_events'])}")
    print(f"  ✅ Collaboration summary saved: {summary_file}")
    
    return True


async def test_hybrid_mode():
    """Test hybrid mode (mix of collaborative and traditional)"""
    print("🔀 Testing hybrid mode...")
    
    output_dir = Path(tempfile.mkdtemp(prefix="hybrid_test_"))
    
    orchestrator = CollaborativeOrchestrator(
        output_dir=output_dir,
        max_parallel=2,
        collaboration_config=CollaborationConfig(
            enable_messaging=True,
            enable_shared_workspace=True,
        ),
    )
    
    # Enable hybrid mode
    orchestrator.enable_hybrid_mode()
    
    tasks = [
        # Traditional task
        CollaborativeTask(
            task_id="traditional_task",
            task_type="research",
            prompt="Traditional research task",
            collaboration_enabled=False,  # Traditional execution
        ),
        
        # Collaborative task
        CollaborativeTask(
            task_id="collaborative_task", 
            task_type="analysis",
            prompt="Collaborative analysis task",
            dependencies=["traditional_task"],
            collaboration_enabled=True,  # Collaborative execution
            collaboration_mode="shared",
        ),
    ]
    
    results = await orchestrator.run_collaborative(tasks=tasks)
    
    # Verify mixed execution
    traditional_task = next(r for r in results['results'] if r['task_id'] == 'traditional_task')
    collaborative_task = next(r for r in results['results'] if r['task_id'] == 'collaborative_task')
    
    assert not traditional_task['collaboration_enabled']
    assert collaborative_task['collaboration_enabled']
    
    print("  ✅ Hybrid mode working - mixed traditional and collaborative execution")
    return True


async def test_configuration_validation():
    """Test collaboration configuration options"""
    print("⚙️  Testing configuration options...")
    
    # Test various configurations
    configs = [
        CollaborationConfig(enable_messaging=True, enable_shared_workspace=False),
        CollaborationConfig(enable_messaging=False, enable_shared_workspace=True), 
        CollaborationConfig(max_team_size=5, team_formation_mode="manual"),
        CollaborationConfig(workspace_sync_interval=0.5, collaboration_timeout=120.0),
    ]
    
    for i, config in enumerate(configs):
        output_dir = Path(tempfile.mkdtemp(prefix=f"config_test_{i}_"))
        
        orchestrator = CollaborativeOrchestrator(
            output_dir=output_dir,
            max_parallel=1,
            collaboration_config=config,
        )
        
        # Verify config applied
        assert orchestrator.collaboration_config.enable_messaging == config.enable_messaging
        assert orchestrator.collaboration_config.enable_shared_workspace == config.enable_shared_workspace
        
        print(f"  ✅ Configuration {i+1}: {config}")
    
    return True


async def main():
    """Run all tests"""
    print("🚀 COLLABORATIVE ORCHESTRATOR TESTS")
    print("=" * 50)
    
    try:
        # Test backwards compatibility
        await test_backwards_compatibility()
        
        # Test collaborative features  
        await test_collaborative_features()
        
        # Test hybrid mode
        await test_hybrid_mode()
        
        # Test configuration options
        await test_configuration_validation()
        
        print("\n" + "=" * 50)
        print("✅ ALL TESTS PASSED!")
        print("\nCollaborativeOrchestrator successfully provides:")
        print("  • Full backwards compatibility with GenericOrchestrator")
        print("  • Real-time agent collaboration features")
        print("  • Hybrid execution modes")
        print("  • Flexible configuration options")
        print("  • Comprehensive monitoring and logging")
        print("=" * 50)
        
        return True
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        raise


if __name__ == "__main__":
    success = asyncio.run(main())
    if not success:
        exit(1)