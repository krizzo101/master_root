#!/usr/bin/env python3
"""
Test script for the async web server
"""

import asyncio
import sys
import os

# Add the src directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

async def test_server_import():
    """Test if we can import and instantiate the server"""
    try:
        from async_web_server import AsyncWebServer, RequestQualityGate
        print("✅ Successfully imported AsyncWebServer")
        
        # Test instantiation
        server = AsyncWebServer(host="127.0.0.1", port=8001, max_parallel=5)
        print("✅ Successfully instantiated AsyncWebServer")
        
        # Test adding quality gate
        class TestQualityGate(RequestQualityGate):
            async def validate_input(self, request):
                return {"passed": True, "issues": []}
        
        server.add_quality_gate(TestQualityGate())
        print("✅ Successfully added quality gate")
        
        # Test metrics
        metrics = await server.monitor.get_metrics_summary()
        print(f"✅ Retrieved metrics: {len(metrics)} fields")
        
        print("\n🎉 All basic functionality tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(test_server_import())
    sys.exit(0 if success else 1)