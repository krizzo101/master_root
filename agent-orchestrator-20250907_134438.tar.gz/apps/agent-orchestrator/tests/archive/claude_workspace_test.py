#!/usr/bin/env python3
"""
Simple test of GenericOrchestrator for Claude workspace automation
Tests basic functionality with 2 simple tasks
"""
import asyncio
import sys
from datetime import datetime
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from generic_orchestrator import GenericOrchestrator, AgentTask

def generate_test_tasks():
    """Generate simple test tasks to verify orchestrator works"""
    return [
        AgentTask(
            task_id="env_check",
            task_type="environment",
            prompt="Check the current working directory and list 3 files. Create a file called 'env_test.txt' with the current timestamp and directory path.",
            dependencies=[]
        ),
        AgentTask(
            task_id="summary",
            task_type="analysis", 
            prompt="Read the env_test.txt file created by the previous task and create a summary file called 'test_summary.txt' that confirms the test worked.",
            dependencies=["env_check"]
        )
    ]

async def main():
    print("🧪 TESTING ORCHESTRATOR FOR CLAUDE WORKSPACE")
    print("=" * 50)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(f"claude_workspace_test_{timestamp}")
    
    print(f"📁 Output directory: {output_dir}")
    print(f"⏰ Start time: {datetime.now()}")
    
    try:
        orchestrator = GenericOrchestrator(
            output_dir=output_dir,
            max_parallel=2,
            use_optimizations=True
        )
        
        print("✅ Orchestrator created successfully")
        print("🚀 Starting task execution...")
        
        result = await orchestrator.run(task_generator=generate_test_tasks)
        
        print(f"⏰ End time: {datetime.now()}")
        print("📊 RESULTS:")
        print(f"   Success: {result.get('success', 'Unknown')}")
        print(f"   Completed: {result.get('metrics', {}).get('completed', 0)}")
        print(f"   Total: {result.get('metrics', {}).get('total', 0)}")
        
        # Check if test files were created
        env_test = output_dir / "tasks" / "env_test.txt"
        summary_test = output_dir / "tasks" / "test_summary.txt"
        
        print("\n📂 FILE CHECK:")
        print(f"   env_test.txt exists: {env_test.exists()}")
        print(f"   test_summary.txt exists: {summary_test.exists()}")
        
        if env_test.exists():
            print(f"   env_test.txt content preview: {env_test.read_text()[:100]}...")
            
        return result
        
    except Exception as e:
        print(f"❌ ERROR: {e}")
        return None

if __name__ == "__main__":
    result = asyncio.run(main())
    success = result and result.get('metrics', {}).get('completed', 0) == 2
    print(f"\n🎯 FINAL RESULT: {'SUCCESS' if success else 'FAILED'}")