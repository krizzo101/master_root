#!/usr/bin/env python3
"""
Test script to prove PracticalOrchestrator works end-to-end
"""

import asyncio
import json
import sys
import time
from pathlib import Path

# Add src to path
sys.path.append('src')

from practical_orchestrator import PracticalOrchestrator, PracticalAgentTask


def progress_monitor(event_type: str, data: dict):
    """Progress monitoring callback"""
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] 📊 {event_type}: {data}")


async def test_simple_tasks():
    """Test 1: Simple tasks with dependencies"""
    print("\n🧪 TEST 1: Simple Tasks with Dependencies")
    print("=" * 50)
    
    # Create orchestrator
    orchestrator = PracticalOrchestrator(
        output_dir="./test_output_simple",
        max_parallel=2,
        enable_monitoring=True
    )
    
    # Set up monitoring
    orchestrator.set_progress_callback(progress_monitor)
    
    # Create test tasks
    tasks = [
        PracticalAgentTask(
            task_id="create_file",
            task_type="development-specialist",
            prompt="""Create a simple Python file named 'hello.py' with a function that returns 'Hello, World!'
            
Make sure to:
1. Write the file to the current directory
2. Include proper function definition
3. Add a simple docstring
4. Return the expected string""",
            phase_id="creation",
            priority="high",
            tags=["python", "file-creation"]
        ),
        PracticalAgentTask(
            task_id="test_file",
            task_type="qa-testing-guru", 
            prompt="""Create a test file for hello.py that tests the hello_world function.
            
Requirements:
1. Create test_hello.py
2. Import the hello_world function
3. Test that it returns 'Hello, World!'
4. Use proper test structure""",
            dependencies=["create_file"],
            phase_id="testing",
            priority="normal",
            tags=["testing", "python"]
        )
    ]
    
    # Execute tasks
    print(f"🚀 Starting {len(tasks)} tasks...")
    results = await orchestrator.execute_batch(tasks)
    
    # Show session mapping
    print("\n🔍 Session Mapping:")
    orchestrator.print_session_map()
    
    # Analyze results
    completed = len([r for r in results if r.get("status") == "completed"])
    failed = len([r for r in results if r.get("status") == "failed"])
    
    print(f"\n✅ Results: {completed} completed, {failed} failed")
    
    return results, orchestrator


async def test_realistic_project_tasks():
    """Test 2: Realistic project-context style tasks"""
    print("\n🧪 TEST 2: Realistic Project Tasks")
    print("=" * 50)
    
    orchestrator = PracticalOrchestrator(
        output_dir="./test_output_realistic",
        max_parallel=3
    )
    
    orchestrator.set_progress_callback(progress_monitor)
    
    # Realistic tasks similar to project-context work
    tasks = [
        PracticalAgentTask(
            task_id="analyze_codebase",
            task_type="research-genius",
            prompt="""Analyze the current directory structure and identify:
            1. Python files and their purposes
            2. Key dependencies and imports
            3. Architecture patterns
            4. Potential improvement areas
            
            Provide a structured analysis report.""",
            phase_id="analysis", 
            priority="high",
            tags=["research", "codebase"]
        ),
        PracticalAgentTask(
            task_id="create_config",
            task_type="development-specialist",
            prompt="""Create a configuration file (config.yaml) for the practical orchestrator with:
            1. Default settings
            2. Monitoring options
            3. Quality report settings
            4. Task execution parameters""",
            dependencies=["analyze_codebase"],
            phase_id="configuration",
            priority="normal", 
            tags=["config", "yaml"]
        ),
        PracticalAgentTask(
            task_id="document_api",
            task_type="technical-writer",
            prompt="""Create API documentation for PracticalOrchestrator in markdown format:
            1. Class overview and purpose
            2. Constructor parameters
            3. Key methods and usage
            4. Example code snippets
            5. Comparison with other orchestrators""",
            dependencies=["analyze_codebase", "create_config"],
            phase_id="documentation",
            priority="low",
            tags=["documentation", "api"]
        )
    ]
    
    print(f"🚀 Starting {len(tasks)} realistic tasks...")
    results = await orchestrator.execute_batch(tasks)
    
    # Show results
    completed = len([r for r in results if r.get("status") == "completed"])
    failed = len([r for r in results if r.get("status") == "failed"])
    
    print(f"\n✅ Results: {completed} completed, {failed} failed")
    
    return results, orchestrator


async def verify_quality_reports(orchestrator: PracticalOrchestrator, test_name: str):
    """Verify quality report was generated and contains expected data"""
    print(f"\n📊 QUALITY REPORT VERIFICATION: {test_name}")
    print("=" * 50)
    
    report_file = orchestrator.output_dir / "quality_report.json"
    
    if report_file.exists():
        print(f"✅ Quality report exists: {report_file}")
        
        with open(report_file) as f:
            report = json.load(f)
        
        print(f"📈 Total tasks: {report['total_tasks']}")
        print(f"📈 Completed: {report['completed_tasks']}")
        print(f"📈 Failed: {report['failed_tasks']}")
        print(f"📈 Success rate: {report['success_rate']:.1%}")
        print(f"📈 Average duration: {report['average_duration']:.2f}s")
        print(f"📈 Files created: {report['files_created_total']}")
        print(f"📈 Tasks by type: {report['tasks_by_type']}")
        print(f"📈 Tasks by phase: {report['tasks_by_phase']}")
        
        if report['fastest_task']:
            print(f"⚡ Fastest task: {report['fastest_task']['task_id']} ({report['fastest_task']['duration']:.2f}s)")
        if report['slowest_task']:
            print(f"🐌 Slowest task: {report['slowest_task']['task_id']} ({report['slowest_task']['duration']:.2f}s)")
            
        return True
    else:
        print(f"❌ Quality report missing: {report_file}")
        return False


async def verify_task_outputs(orchestrator: PracticalOrchestrator, test_name: str):
    """Verify individual task outputs contain enhanced data"""
    print(f"\n📁 TASK OUTPUTS VERIFICATION: {test_name}")
    print("=" * 50)
    
    tasks_dir = orchestrator.output_dir / "tasks"
    
    if not tasks_dir.exists():
        print(f"❌ Tasks directory missing: {tasks_dir}")
        return False
    
    task_files = list(tasks_dir.glob("*.json"))
    print(f"📄 Found {len(task_files)} task output files")
    
    for task_file in task_files:
        print(f"\n📄 Checking {task_file.name}:")
        
        with open(task_file) as f:
            task_data = json.load(f)
        
        # Verify enhanced fields are present
        enhanced_fields = ['session_id', 'phase_id', 'priority', 'tags', 'log_path']
        
        for field in enhanced_fields:
            if field in task_data:
                print(f"  ✅ {field}: {task_data[field]}")
            else:
                print(f"  ❌ Missing {field}")
        
        # Check for files tracking
        if 'files_created' in task_data:
            print(f"  📁 Files created: {task_data['files_created']}")
        if 'files_modified' in task_data:
            print(f"  📝 Files modified: {task_data['files_modified']}")
        if 'metrics' in task_data:
            print(f"  📊 Metrics: {task_data['metrics']}")
    
    return len(task_files) > 0


async def main():
    """Run all tests and prove PracticalOrchestrator works"""
    
    print("🧪 PRACTICAL ORCHESTRATOR END-TO-END TESTING")
    print("=" * 60)
    
    try:
        # Test 1: Simple tasks
        simple_results, simple_orchestrator = await test_simple_tasks()
        simple_success = await verify_quality_reports(simple_orchestrator, "Simple Tasks")
        simple_outputs = await verify_task_outputs(simple_orchestrator, "Simple Tasks")
        
        # Test 2: Realistic tasks  
        realistic_results, realistic_orchestrator = await test_realistic_project_tasks()
        realistic_success = await verify_quality_reports(realistic_orchestrator, "Realistic Tasks")
        realistic_outputs = await verify_task_outputs(realistic_orchestrator, "Realistic Tasks")
        
        # Final summary
        print(f"\n🏆 FINAL RESULTS")
        print("=" * 30)
        
        simple_completed = len([r for r in simple_results if r.get("status") == "completed"])
        realistic_completed = len([r for r in realistic_results if r.get("status") == "completed"])
        
        total_tasks = len(simple_results) + len(realistic_results)
        total_completed = simple_completed + realistic_completed
        
        print(f"📊 Total tasks executed: {total_tasks}")
        print(f"✅ Total completed: {total_completed}")
        print(f"📈 Overall success rate: {total_completed/total_tasks:.1%}")
        print(f"📊 Quality reports generated: {simple_success and realistic_success}")
        print(f"📁 Enhanced task outputs: {simple_outputs and realistic_outputs}")
        
        if total_completed == total_tasks and simple_success and realistic_success:
            print(f"\n🎉 ALL TESTS PASSED! PracticalOrchestrator is working perfectly!")
            return True
        else:
            print(f"\n⚠️  Some tests failed. Check the output above.")
            return False
            
    except Exception as e:
        print(f"\n💥 Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)