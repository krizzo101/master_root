#!/usr/bin/env python3
"""
Test script for the enhanced quality gates system
Validates security scanning, compliance checking, and code analysis functionality
"""
import asyncio
import json
import logging
import sys
import tempfile
from pathlib import Path

# Add current directory to path
sys.path.append(str(Path(__file__).parent))

from src.quality_gates_enhanced import (
    EnhancedQualityGateManager,
    SecurityValidator,
    ComplianceChecker,
    CodeSecurityAnalyzer,
    ComplianceStandard,
    validate_comprehensive_quality,
    quick_security_scan,
    quick_compliance_check,
    quick_security_analysis
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_security_validator():
    """Test the security validation system"""
    print("🔒 Testing SecurityValidator...")
    
    # Create test files with security issues
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create a Python file with security issues
        test_file = temp_path / "test_security.py"
        test_file.write_text("""
import os
import subprocess

# Hardcoded password - security issue
password = "super_secret_password_123"
api_key = "sk-1234567890abcdef"

def dangerous_function(user_input):
    # Command injection vulnerability
    result = subprocess.run(f"echo {user_input}", shell=True)
    
    # Code injection vulnerability  
    eval(user_input)
    
    return result

def weak_crypto():
    import hashlib
    # Weak hash function
    return hashlib.md5(b"test").hexdigest()
""")
        
        # Create requirements.txt with potentially vulnerable dependency
        req_file = temp_path / "requirements.txt"
        req_file.write_text("requests==2.0.0\npillow==6.0.0\n")
        
        # Test the validator
        validator = SecurityValidator()
        result = await validator.validate_directory(temp_path)
        
        print(f"   ✅ Security scan completed")
        print(f"   📊 Found {result.total_vulnerabilities} vulnerabilities")
        print(f"   🎯 Risk score: {result.risk_score:.1f}")
        print(f"   🔒 Is secure: {result.is_secure}")
        
        # Test individual file validation
        file_result = await validator.validate_file(test_file)
        print(f"   📄 File scan found {file_result.total_vulnerabilities} issues")
        
        print("   ✅ SecurityValidator test completed\n")
        return result.total_vulnerabilities > 0


async def test_compliance_checker():
    """Test the compliance checking system"""
    print("📋 Testing ComplianceChecker...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create files with compliance issues
        gdpr_file = temp_path / "user_data.py"
        gdpr_file.write_text("""
# GDPR compliance issues
user_email = "test@example.com"
user_phone = "+1-555-0123"
user_address = "123 Main St, City, State"

def process_user_data(email, phone, ssn):
    # Processing PII without proper consent handling
    return f"Processing {email}, {phone}, {ssn}"

# Hardcoded credentials in PII context
database_password = "db_pass_12345"
""")
        
        sox_file = temp_path / "financial.py"
        sox_file.write_text("""
# SOX compliance issues
def process_financial_data():
    revenue = 1000000
    expenses = 750000
    audit_trail = []  # Missing proper audit controls
    
    return {"revenue": revenue, "expenses": expenses}
""")
        
        # Test the compliance checker
        standards = [ComplianceStandard.GDPR, ComplianceStandard.SOX, ComplianceStandard.OWASP]
        checker = ComplianceChecker(standards=standards)
        result = await checker.check_directory(temp_path)
        
        print(f"   ✅ Compliance check completed")
        print(f"   📊 Found {result.total_issues} compliance issues")
        print(f"   🎯 Compliance score: {result.compliance_score:.1f}")
        print(f"   ✅ Is compliant: {result.is_compliant}")
        print(f"   📜 Standards checked: {', '.join(result.standards_checked)}")
        
        print("   ✅ ComplianceChecker test completed\n")
        return result.total_issues > 0


async def test_code_security_analyzer():
    """Test the code security analysis system"""
    print("🔍 Testing CodeSecurityAnalyzer...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create Python file with security issues
        python_file = temp_path / "insecure_code.py"
        python_file.write_text("""
import pickle
import subprocess
import random

# Security issues for AST analysis
def dangerous_operations(user_data):
    # Code injection
    eval(user_data)
    exec(user_data)
    
    # Command injection
    subprocess.run(user_data, shell=True)
    
    # Insecure deserialization
    pickle.loads(user_data)
    
    return "processed"

# Hardcoded credentials
SECRET_KEY = "sk-1234567890abcdef_secret_key"
DB_PASSWORD = "super_secret_db_password"

def weak_randomness():
    # Weak random number generation
    return random.randint(1, 1000000)
""")
        
        # Create JavaScript file with security issues  
        js_file = temp_path / "insecure.js"
        js_file.write_text("""
// JavaScript security issues
function processInput(userInput) {
    // Code injection via eval
    eval(userInput);
    
    // XSS via innerHTML
    document.getElementById('content').innerHTML = userInput + "<div>More content</div>";
    
    return true;
}

// Hardcoded API key
const API_KEY = "sk-abcdef1234567890";
""")
        
        # Test the analyzer
        analyzer = CodeSecurityAnalyzer(languages=['python', 'javascript'])
        result = await analyzer.analyze_directory(temp_path)
        
        print(f"   ✅ Code analysis completed")
        print(f"   📊 Found {result.total_issues} security issues")
        print(f"   🎯 Security score: {result.security_score:.1f}")
        print(f"   ⚠️  Has critical issues: {result.has_critical_issues}")
        print(f"   📁 Files analyzed: {len(result.files_analyzed)}")
        
        # Test individual file analysis
        file_result = await analyzer.analyze_file(python_file)
        print(f"   📄 Python file analysis found {file_result.total_issues} issues")
        
        print("   ✅ CodeSecurityAnalyzer test completed\n")
        return result.total_issues > 0


async def test_enhanced_quality_gate_manager():
    """Test the comprehensive quality gate manager"""
    print("🏁 Testing EnhancedQualityGateManager...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create comprehensive test files
        security_file = temp_path / "security_issues.py"
        security_file.write_text("""
import subprocess
import pickle

# Multiple security issues
password = "hardcoded_password_123"

def vulnerable_function(user_input):
    eval(user_input)  # Code injection
    subprocess.run(user_input, shell=True)  # Command injection
    pickle.loads(user_input)  # Insecure deserialization
    
    # GDPR issue - processing PII
    email = "user@example.com"
    return f"Processed {email}"
""")
        
        compliance_file = temp_path / "compliance_issues.py"
        compliance_file.write_text("""
# GDPR and SOX compliance issues
user_data = {
    "email": "test@example.com",
    "phone": "+1-555-0123", 
    "ssn": "123-45-6789"
}

# Financial data without audit controls
revenue_data = {"q1": 1000000, "q2": 1200000}
""")
        
        # Test with all gates enabled
        manager = EnhancedQualityGateManager(
            enable_security_scan=True,
            enable_compliance_check=True,
            enable_code_analysis=True,
            pass_threshold=80.0,
            warning_threshold=60.0
        )
        
        # Test parallel execution
        report = await manager.validate_all(temp_path, parallel_execution=True)
        
        print(f"   ✅ Enhanced quality gate validation completed")
        print(f"   📊 Overall status: {report.overall_status.value}")
        print(f"   🎯 Overall score: {report.overall_score:.1f}/100")
        print(f"   ⏱️  Total execution time: {report.total_execution_time:.2f}s")
        print(f"   📋 Gates executed: {report.total_gates}")
        print(f"   ✅ Passed gates: {report.passed_gates}")
        print(f"   ❌ Failed gates: {report.failed_gates}")
        
        # Test export functionality
        export_file = temp_path / "quality_report.json"
        await manager.export_report(report, export_file, 'json')
        print(f"   📄 Report exported to: {export_file}")
        
        # Test security-only validation
        security_report = await manager.validate_security_only(temp_path)
        print(f"   🔒 Security-only validation: {security_report.overall_status.value}")
        
        print("   ✅ EnhancedQualityGateManager test completed\n")
        return len(report.recommendations) > 0


async def test_convenience_functions():
    """Test convenience functions for quick validation"""
    print("⚡ Testing convenience functions...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create test file
        test_file = temp_path / "quick_test.py"
        test_file.write_text("""
import os
password = "secret123"

def test_function():
    eval("print('hello')")
    return True
""")
        
        # Test quick security scan
        security_result = await quick_security_scan(temp_path)
        print(f"   🔒 Quick security scan: {security_result.total_vulnerabilities} vulnerabilities")
        
        # Test quick compliance check
        compliance_result = await quick_compliance_check(temp_path)
        print(f"   📋 Quick compliance check: {compliance_result.total_issues} issues")
        
        # Test quick security analysis
        analysis_result = await quick_security_analysis(temp_path)
        print(f"   🔍 Quick security analysis: {analysis_result.total_issues} issues")
        
        # Test comprehensive validation
        comprehensive_result = await validate_comprehensive_quality(temp_path, parallel_execution=True)
        print(f"   🏁 Comprehensive validation: {comprehensive_result.overall_status.value}")
        
        print("   ✅ Convenience functions test completed\n")
        return True


async def run_performance_benchmark():
    """Run performance benchmark on larger codebase"""
    print("🚀 Running performance benchmark...")
    
    # Test on current codebase directory
    target_dir = Path(__file__).parent / "src"
    
    if target_dir.exists():
        import time
        start_time = time.time()
        
        # Run comprehensive validation
        manager = EnhancedQualityGateManager()
        report = await manager.validate_all(target_dir, parallel_execution=True)
        
        end_time = time.time()
        
        print(f"   ⏱️  Benchmark completed in {end_time - start_time:.2f}s")
        print(f"   📊 Overall score: {report.overall_score:.1f}/100")
        print(f"   📁 Files analyzed: {len(report.summary.get('security_scan_summary', {}).get('details', {}).get('scanned_files', []))}")
        print(f"   🎯 Status: {report.overall_status.value}")
        
        return True
    else:
        print("   ⏭️  Skipping benchmark - source directory not found")
        return True


async def main():
    """Main test runner"""
    print("🧪 Enhanced Quality Gates System Tests")
    print("=" * 50)
    
    tests = [
        ("Security Validator", test_security_validator),
        ("Compliance Checker", test_compliance_checker), 
        ("Code Security Analyzer", test_code_security_analyzer),
        ("Enhanced Quality Gate Manager", test_enhanced_quality_gate_manager),
        ("Convenience Functions", test_convenience_functions),
        ("Performance Benchmark", run_performance_benchmark)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            print(f"Running {test_name}...")
            result = await test_func()
            if result:
                passed += 1
                print(f"✅ {test_name} PASSED\n")
            else:
                print(f"❌ {test_name} FAILED\n")
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}\n")
            logger.exception("Test failed")
    
    print("=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All enhanced quality gate tests passed!")
        return 0
    else:
        print("⚠️  Some tests failed - review implementation")
        return 1


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n👋 Tests interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Test runner failed: {e}")
        sys.exit(1)