#!/usr/bin/env python3
"""
Quick test to validate the demonstration framework is working.
This script performs basic import tests and structure validation.
"""

import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test that all required modules can be imported"""
    print("🧪 Testing escalation system imports...")
    
    try:
        # Core escalation manager
        from escalation_manager import (
            EscalationManager, 
            EscalationType, 
            EscalationReason,
            EscalationRequest,
            EscalationResponse,
            IntelligentAgent
        )
        print("✅ escalation_manager imports successful")
        
        # Integration layer
        from escalation_integration import (
            EscalationAwareOrchestrator,
            EscalationConfig,
            create_development_orchestrator
        )
        print("✅ escalation_integration imports successful")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False

def test_demo_structure():
    """Test that demonstration scripts have correct structure"""
    print("\n🏗️ Testing demonstration script structure...")
    
    # Check that demo files exist
    demo_files = [
        "escalation_demo.py",
        "escalation_validator.py", 
        "escalation_benchmarks.py",
        "run_complete_validation.py",
        "README.md"
    ]
    
    examples_dir = Path(__file__).parent
    missing_files = []
    
    for file_name in demo_files:
        file_path = examples_dir / file_name
        if not file_path.exists():
            missing_files.append(file_name)
        else:
            print(f"✅ {file_name} exists")
    
    if missing_files:
        print(f"❌ Missing files: {missing_files}")
        return False
    
    return True

def test_basic_functionality():
    """Test basic escalation system functionality"""
    print("\n⚙️ Testing basic escalation functionality...")
    
    try:
        from escalation_manager import EscalationType, EscalationReason, EscalationRequest
        import uuid
        
        # Test EscalationRequest creation
        request = EscalationRequest(
            escalation_id=str(uuid.uuid4()),
            agent_id="test_agent",
            agent_uuid=str(uuid.uuid4()),
            escalation_type=EscalationType.REPLACEMENT,
            escalation_reason=EscalationReason.FAILURE_THRESHOLD,
            problem_description="Test escalation request"
        )
        
        print("✅ EscalationRequest creation successful")
        
        # Test to_dict method
        request_dict = request.to_dict()
        assert isinstance(request_dict, dict)
        assert "escalation_id" in request_dict
        print("✅ EscalationRequest serialization successful")
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        return False

def test_configuration():
    """Test escalation configuration"""
    print("\n🔧 Testing escalation configuration...")
    
    try:
        from escalation_integration import EscalationConfig, create_development_orchestrator
        from pathlib import Path
        
        # Test configuration creation
        config = EscalationConfig(
            enable_escalation=True,
            failure_threshold=3,
            context_threshold=0.9
        )
        
        config_dict = config.to_dict()
        assert isinstance(config_dict, dict)
        print("✅ EscalationConfig creation and serialization successful")
        
        # Test orchestrator factory
        output_dir = Path("/tmp/test_escalation")
        output_dir.mkdir(exist_ok=True)
        
        # This should not fail even with dummy tokens
        orchestrator = create_development_orchestrator(
            output_dir=output_dir,
            tokens=["test_token"],
            max_parallel=2,
            enable_escalation=True
        )
        
        assert orchestrator is not None
        assert orchestrator.escalation_config is not None
        print("✅ Development orchestrator creation successful")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Testing Escalation System Demonstration Framework")
    print("=" * 60)
    
    tests = [
        ("Import Tests", test_imports),
        ("Structure Tests", test_demo_structure), 
        ("Functionality Tests", test_basic_functionality),
        ("Configuration Tests", test_configuration)
    ]
    
    passed_tests = 0
    total_tests = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 {test_name}")
        print("-" * 30)
        
        if test_func():
            passed_tests += 1
            print(f"✅ {test_name} PASSED")
        else:
            print(f"❌ {test_name} FAILED")
    
    print("\n" + "=" * 60)
    print("📊 TEST RESULTS")
    print("=" * 60)
    
    print(f"Tests Passed: {passed_tests}/{total_tests}")
    print(f"Success Rate: {passed_tests/total_tests:.1%}")
    
    if passed_tests == total_tests:
        print("🎉 All tests passed! Demonstration framework is ready.")
        print("\n🎯 Ready to run:")
        print("  • python examples/escalation_demo.py")
        print("  • python examples/escalation_validator.py") 
        print("  • python examples/escalation_benchmarks.py")
        print("  • python examples/run_complete_validation.py")
        return 0
    else:
        print("⚠️  Some tests failed. Review errors before running demonstrations.")
        return 1

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)