#!/usr/bin/env python3
"""
Test script for the async web server
Demonstrates basic functionality and endpoints
"""

import asyncio
import aiohttp
import json
import time
from typing import Dict, Any

async def test_server(base_url: str = "http://localhost:8000"):
    """Test the async web server endpoints"""
    
    async with aiohttp.ClientSession() as session:
        print(f"Testing server at {base_url}")
        
        # Test health check
        print("\n1. Testing health check...")
        try:
            async with session.get(f"{base_url}/health") as resp:
                health = await resp.json()
                print(f"✓ Health check: {health}")
        except Exception as e:
            print(f"✗ Health check failed: {e}")
        
        # Test metrics endpoint
        print("\n2. Testing metrics endpoint...")
        try:
            async with session.get(f"{base_url}/metrics") as resp:
                metrics = await resp.json()
                print(f"✓ Initial metrics: {metrics}")
        except Exception as e:
            print(f"✗ Metrics failed: {e}")
        
        # Test basic GET request
        print("\n3. Testing basic GET request...")
        try:
            async with session.get(f"{base_url}/test/get") as resp:
                result = await resp.json()
                print(f"✓ GET response: {result}")
        except Exception as e:
            print(f"✗ GET request failed: {e}")
        
        # Test POST request
        print("\n4. Testing POST request...")
        try:
            test_data = {"message": "Hello from client", "timestamp": time.time()}
            async with session.post(
                f"{base_url}/test/post",
                json=test_data,
                headers={"Content-Type": "application/json"}
            ) as resp:
                result = await resp.json()
                print(f"✓ POST response: {result}")
        except Exception as e:
            print(f"✗ POST request failed: {e}")
        
        # Test concurrent requests
        print("\n5. Testing concurrent requests...")
        try:
            tasks = []
            for i in range(10):
                task = session.get(f"{base_url}/test/concurrent/{i}")
                tasks.append(task)
            
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            successful = 0
            for i, resp in enumerate(responses):
                if isinstance(resp, Exception):
                    print(f"✗ Request {i} failed: {resp}")
                else:
                    result = await resp.json()
                    successful += 1
                    resp.close()
            
            print(f"✓ Concurrent requests: {successful}/10 successful")
        except Exception as e:
            print(f"✗ Concurrent requests failed: {e}")
        
        # Test final metrics
        print("\n6. Testing final metrics...")
        try:
            async with session.get(f"{base_url}/metrics") as resp:
                metrics = await resp.json()
                print(f"✓ Final metrics: {metrics}")
        except Exception as e:
            print(f"✗ Final metrics failed: {e}")


async def run_load_test(base_url: str = "http://localhost:8000", requests: int = 100):
    """Run a simple load test"""
    
    print(f"\n🚀 Running load test with {requests} requests...")
    
    async with aiohttp.ClientSession() as session:
        start_time = time.time()
        
        # Create request tasks
        tasks = []
        for i in range(requests):
            endpoint = f"/load-test/{i}"
            if i % 4 == 0:
                # POST request
                task = session.post(
                    f"{base_url}{endpoint}",
                    json={"request_id": i, "data": f"test_data_{i}"}
                )
            else:
                # GET request
                task = session.get(f"{base_url}{endpoint}")
            tasks.append(task)
        
        # Execute all requests concurrently
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Count results
        successful = 0
        failed = 0
        
        for resp in responses:
            if isinstance(resp, Exception):
                failed += 1
            else:
                successful += 1
                resp.close()
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"✓ Load test completed:")
        print(f"  - Total requests: {requests}")
        print(f"  - Successful: {successful}")
        print(f"  - Failed: {failed}")
        print(f"  - Duration: {duration:.2f} seconds")
        print(f"  - Requests/second: {requests/duration:.2f}")
        
        # Get final metrics
        try:
            async with session.get(f"{base_url}/metrics") as resp:
                metrics = await resp.json()
                print(f"  - Server metrics: {metrics}")
        except Exception as e:
            print(f"  - Could not get metrics: {e}")


if __name__ == "__main__":
    import sys
    
    base_url = "http://localhost:8000"
    if len(sys.argv) > 1:
        base_url = sys.argv[1]
    
    print("Async Web Server Test Suite")
    print("=" * 40)
    
    # Run basic tests
    asyncio.run(test_server(base_url))
    
    # Run load test
    asyncio.run(run_load_test(base_url, 50))
    
    print("\n✅ Test suite completed!")