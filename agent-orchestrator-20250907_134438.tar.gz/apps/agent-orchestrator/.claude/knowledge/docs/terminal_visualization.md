# Terminal Visualization Guidelines for Monitoring Applications

## Executive Summary

This document provides comprehensive guidelines for implementing effective terminal visualization in monitoring and logging applications, with a focus on color systems, accessibility, and cross-platform compatibility.

## 1. ANSI Color System Overview

### Standard Color Support Levels

#### Basic 8-Color Support (Universal)
- **Colors**: Black, Red, Green, Yellow, Blue, Magenta, Cyan, White
- **Codes**: 30-37 (foreground), 40-47 (background)
- **Compatibility**: 99% of terminals
- **Use Case**: Critical error states, basic status indicators

#### 16-Color Support (High Intensity)
- **Colors**: Basic 8 + bright variants
- **Codes**: 90-97 (bright foreground), 100-107 (bright background)
- **Compatibility**: 95% of modern terminals
- **Use Case**: Extended status differentiation

#### 256-Color Support (Extended)
- **Format**: `\033[38;5;{n}m` (foreground), `\033[48;5;{n}m` (background)
- **Palette**: 16 basic + 216 RGB + 24 grayscale
- **Compatibility**: 90% of modern terminals
- **Use Case**: Gradient indicators, heat maps

#### True Color Support (24-bit RGB)
- **Format**: `\033[38;2;{r};{g};{b}m`
- **Colors**: 16.7 million colors
- **Compatibility**: 70% of modern terminals (NOT Terminal.app on macOS)
- **Use Case**: Data visualization, custom branding

### Detection Strategy
```python
# Recommended approach for color level detection
def detect_color_support():
    if os.environ.get('NO_COLOR'):
        return 0
    elif 'COLORTERM' in os.environ:
        if os.environ['COLORTERM'] in ['truecolor', '24bit']:
            return 24
    elif 'TERM' in os.environ:
        term = os.environ['TERM']
        if '256' in term:
            return 256
        elif term in ['xterm', 'screen', 'vt100', 'rxvt']:
            return 16
    return 8  # Safe default
```

## 2. Log Level Color Scheme

### Industry Standard Severity Mapping

| Level | Severity | Primary Color | ANSI Code | Emoji | Semantic Meaning |
|-------|----------|--------------|-----------|--------|------------------|
| EMERGENCY | 0 | Bright Red + Blink | `\033[91;5m` | 🚨 | System unusable |
| ALERT | 1 | Bright Red | `\033[91m` | ⚠️ | Immediate action required |
| CRITICAL | 2 | Red | `\033[31m` | ❌ | Critical conditions |
| ERROR | 3 | Light Red | `\033[91m` | ❗ | Error conditions |
| WARNING | 4 | Yellow | `\033[93m` | ⚡ | Warning conditions |
| NOTICE | 5 | Cyan | `\033[96m` | 📌 | Normal but significant |
| INFO | 6 | Green | `\033[92m` | ℹ️ | Informational messages |
| DEBUG | 7 | Gray/Dim | `\033[90m` | 🔍 | Debug-level messages |

### Alternative Accessible Scheme (Color-Blind Safe)
```python
COLOR_BLIND_SAFE = {
    'ERROR': '\033[38;5;196m',    # Pure Red (#ff0000)
    'WARNING': '\033[38;5;214m',  # Orange (#ffaa00)
    'INFO': '\033[38;5;39m',      # Blue (#0087ff)
    'SUCCESS': '\033[38;5;46m',   # Green (#00ff00)
    'DEBUG': '\033[38;5;245m',    # Gray (#8a8a8a)
}
```

## 3. Accessibility Considerations

### WCAG Compliance for Terminal Applications

#### Contrast Ratios
- **Minimum (AA)**: 4.5:1 for normal text
- **Enhanced (AAA)**: 7:1 for normal text
- **Large Text**: 3:1 minimum (14pt bold or 18pt regular)

#### Recommended Color Combinations
```python
HIGH_CONTRAST_PAIRS = [
    # Background -> Foreground (contrast ratio)
    ('black', 'white'),      # 21:1
    ('black', 'yellow'),     # 19.6:1
    ('black', 'cyan'),       # 16:1
    ('black', 'green'),      # 15.3:1
    ('blue', 'white'),       # 8.6:1
    ('red', 'white'),        # 4:1 (minimum)
]
```

### Color Blindness Support
- **8% of males** and **0.5% of females** have color vision deficiency
- **Never rely solely on color** for critical information
- Always provide secondary indicators (symbols, text, patterns)

#### Universal Design Patterns
```python
STATUS_INDICATORS = {
    'success': '✓ SUCCESS (green)',
    'warning': '⚡ WARNING (yellow)',
    'error': '✗ ERROR (red)',
    'info': 'ℹ INFO (blue)',
}
```

## 4. Emoji Usage Guidelines

### Cross-Platform Compatibility

#### Safe Emoji Set (Universal Support)
```python
SAFE_EMOJIS = {
    # Status
    '✓': 'Success/Complete',
    '✗': 'Error/Failed',
    '⚡': 'Warning/Alert',
    'ℹ': 'Information',
    '⚠': 'Caution',
    
    # Progress
    '●': 'Active/Running',
    '○': 'Inactive/Stopped',
    '◐': 'Partial/Loading',
    
    # Directional
    '→': 'Forward/Next',
    '←': 'Back/Previous',
    '↑': 'Up/Increase',
    '↓': 'Down/Decrease',
}
```

#### Platform-Specific Considerations

**Windows**
- Legacy console (cmd.exe): Limited Unicode support
- PowerShell 5.x: No emoji support
- Windows Terminal: Full emoji support
- **Recommendation**: Detect terminal type, provide fallback

**macOS**
- Terminal.app: No true color, monochrome emoji only
- iTerm2: Full color emoji support
- **Recommendation**: Use Unicode symbols for Terminal.app

**Linux**
- GNOME Terminal: Monochrome emoji (VTE limitation)
- Konsole/Kitty: Full color emoji support
- **Recommendation**: Provide ASCII fallbacks

### Fallback Strategy
```python
def get_indicator(name, use_emoji=True):
    EMOJI_MAP = {
        'success': ('✓', '[OK]'),
        'error': ('✗', '[ERR]'),
        'warning': ('⚡', '[WARN]'),
        'info': ('ℹ', '[INFO]'),
    }
    
    if not use_emoji or not supports_unicode():
        return EMOJI_MAP[name][1]  # ASCII fallback
    return EMOJI_MAP[name][0]      # Unicode emoji
```

## 5. Visual Hierarchy Best Practices

### Information Density Management

#### Progressive Disclosure
1. **Summary Line**: Status icon + timestamp + severity + message
2. **Context Line**: Source + category + tags (dimmed)
3. **Detail Block**: Stack trace, metadata (collapsed by default)

#### Visual Weight Distribution
```python
VISUAL_HIERARCHY = {
    'critical': Colors.BOLD + Colors.RED,        # Highest weight
    'important': Colors.BOLD,                    # High weight
    'normal': Colors.RESET,                      # Standard weight
    'context': Colors.DIM,                       # Low weight
    'metadata': Colors.DIM + Colors.GRAY,        # Lowest weight
}
```

### Monitoring Dashboard Patterns

#### Real-Time Log Streaming
```python
LOG_FORMAT = {
    'timestamp': Colors.DIM + Colors.GRAY,
    'level': LEVEL_COLORS[level],
    'source': Colors.CYAN,
    'message': Colors.RESET,
    'tags': Colors.DIM + Colors.BLUE,
}
```

#### Status Dashboard Layout
```
┌─────────────────────────────────────────┐
│ 🟢 System Status: HEALTHY               │
├─────────────────────────────────────────┤
│ CPU:  ████████░░ 78% │ MEM: ███░░░ 45% │
│ DISK: ██████░░░░ 62% │ NET: ████░░ 67% │
├─────────────────────────────────────────┤
│ Services (12/15 running)                │
│ ● API Gateway    ✓ Database             │
│ ● Auth Service   ⚡ Cache (degraded)     │
│ ✗ Analytics      ● Message Queue        │
└─────────────────────────────────────────┘
```

## 6. Performance Optimization

### Color Rendering Performance

#### Batching ANSI Sequences
```python
# Inefficient: Multiple write calls
for line in lines:
    print(f"{Colors.RED}{line}{Colors.RESET}")

# Efficient: Single formatted string
output = ''.join(f"{Colors.RED}{line}{Colors.RESET}\n" for line in lines)
print(output, end='')
```

#### Caching Color Decisions
```python
class ColorCache:
    def __init__(self):
        self._cache = {}
        self._color_level = detect_color_support()
    
    def get_color(self, severity):
        if severity not in self._cache:
            self._cache[severity] = self._compute_color(severity)
        return self._cache[severity]
```

### Terminal Buffer Management
- Limit output rate to prevent buffer overflow
- Use line buffering for real-time updates
- Implement pagination for large datasets
- Clear screen strategically (not per update)

## 7. Implementation Checklist

### Minimum Viable Implementation
- [ ] Detect terminal color support level
- [ ] Implement 8-color fallback
- [ ] Add NO_COLOR environment variable support
- [ ] Use standard severity-to-color mapping
- [ ] Include text-based status indicators

### Enhanced Features
- [ ] 256-color gradient indicators
- [ ] Color blindness mode toggle
- [ ] Configurable color themes
- [ ] Emoji support detection
- [ ] Custom color palettes

### Accessibility Compliance
- [ ] Contrast ratio validation
- [ ] Non-color indicators for all states
- [ ] Screen reader compatible output mode
- [ ] High contrast mode option
- [ ] Reduced motion mode (no blinking)

## 8. Testing Strategy

### Cross-Platform Testing Matrix
| Platform | Terminal | Expected Support |
|----------|----------|-----------------|
| Windows 10+ | Windows Terminal | Full |
| Windows | PowerShell 5 | Basic |
| Windows | CMD | Minimal |
| macOS | iTerm2 | Full |
| macOS | Terminal.app | 256-color |
| Linux | GNOME Terminal | 256-color |
| Linux | Konsole | True color |
| WSL | Windows Terminal | Full |

### Automated Testing
```python
def test_color_degradation():
    """Test graceful degradation of color support"""
    test_cases = [
        ('NO_COLOR=1', 0),
        ('TERM=dumb', 0),
        ('TERM=xterm', 16),
        ('TERM=xterm-256color', 256),
        ('COLORTERM=truecolor', 24),
    ]
    for env, expected in test_cases:
        assert detect_color_support(env) == expected
```

## 9. Reference Resources

### Standards & Specifications
- ANSI X3.64 (ECMA-48) - Control sequences
- ISO/IEC 8613-6 - Color specifications
- WCAG 2.1 - Web Content Accessibility Guidelines
- Unicode 15.0 - Emoji specifications

### Tools & Libraries
- **colorama**: Cross-platform ANSI color support
- **rich**: Advanced terminal formatting
- **blessed**: Terminal UI toolkit
- **chalk**: Terminal string styling

### Testing Tools
- **contrast-ratio**: WCAG contrast validation
- **colorblind**: Color blindness simulation
- **terminal-size**: Terminal dimension detection

## 10. Quick Reference Card

```python
# Essential ANSI codes
RESET = '\033[0m'
BOLD = '\033[1m'
DIM = '\033[2m'
BLINK = '\033[5m'

# Basic colors (30-37 foreground, 40-47 background)
BLACK, RED, GREEN, YELLOW = 0, 1, 2, 3
BLUE, MAGENTA, CYAN, WHITE = 4, 5, 6, 7

# Usage pattern
def colorize(text, fg=None, bg=None, bold=False):
    codes = []
    if bold: codes.append('1')
    if fg: codes.append(f'3{fg}')
    if bg: codes.append(f'4{bg}')
    if not codes: return text
    return f"\033[{';'.join(codes)}m{text}\033[0m"

# Environment detection
NO_COLOR = os.environ.get('NO_COLOR')
FORCE_COLOR = os.environ.get('FORCE_COLOR')
IS_TTY = sys.stdout.isatty()
```

---

*Document Version: 1.0.0*  
*Last Updated: 2025-01-07*  
*Maintainer: Terminal Visualization Research Team*