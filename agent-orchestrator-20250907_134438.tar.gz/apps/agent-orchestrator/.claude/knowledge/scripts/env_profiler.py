#!/usr/bin/env python3
"""
Environment Profiler for Claude Knowledge Workspace
Captures current system state and updates workspace intelligence
"""

import json
import os
import sys
import subprocess
from datetime import datetime
from pathlib import Path

def get_system_info():
    """Gather comprehensive system information"""
    info = {}
    
    # Basic system info
    info['timestamp'] = datetime.now().isoformat()
    info['working_directory'] = os.getcwd()
    info['python_version'] = sys.version
    info['python_executable'] = sys.executable
    
    # Platform information
    try:
        import platform
        info['platform'] = {
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor()
        }
    except Exception as e:
        info['platform_error'] = str(e)
    
    # Git information
    try:
        git_branch = subprocess.run(['git', 'branch', '--show-current'], 
                                  capture_output=True, text=True, check=True)
        info['git_branch'] = git_branch.stdout.strip()
        
        git_status = subprocess.run(['git', 'status', '--porcelain'], 
                                  capture_output=True, text=True, check=True)
        info['git_status'] = git_status.stdout.strip()
    except Exception as e:
        info['git_error'] = str(e)
    
    # Environment variables of interest
    env_vars = ['PATH', 'PYTHONPATH', 'HOME', 'USER', 'PWD']
    info['environment'] = {var: os.environ.get(var, 'NOT_SET') for var in env_vars}
    
    # Project structure
    try:
        info['project_structure'] = get_project_structure()
    except Exception as e:
        info['project_structure_error'] = str(e)
    
    return info

def get_project_structure():
    """Get key directories and files in the project"""
    structure = {}
    current_dir = Path('.')
    
    # Key directories
    key_dirs = ['.claude', 'src', 'tests', 'docs', 'examples', 'scripts']
    structure['directories'] = {}
    
    for dir_name in key_dirs:
        dir_path = current_dir / dir_name
        if dir_path.exists():
            structure['directories'][dir_name] = {
                'exists': True,
                'files_count': len(list(dir_path.rglob('*'))) if dir_path.is_dir() else 0
            }
        else:
            structure['directories'][dir_name] = {'exists': False}
    
    # Key files
    key_files = ['README.md', 'main.py', 'run.py', 'setup.sh', '.gitignore']
    structure['files'] = {}
    
    for file_name in key_files:
        file_path = current_dir / file_name
        structure['files'][file_name] = {
            'exists': file_path.exists(),
            'size': file_path.stat().st_size if file_path.exists() else 0
        }
    
    return structure

def update_session_reference():
    """Update session reference with what works right now"""
    reference_content = f"""# Session Reference - Updated {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Current Working State

### Environment
- Working Directory: {os.getcwd()}
- Python: {sys.executable}
- Git Branch: {get_git_branch()}

### Available Tools
- Standard file operations (Read, Write, Edit, MultiEdit)
- Bash commands for system operations
- Grep and Glob for searching
- Git operations

### Known Working Patterns
- Agent orchestrator validation suite in working order
- Comprehensive test framework available
- Multiple validation result directories present

### Current Session Notes
- MCP tools (mcp__thinking__, mcp__time__, mcp__knowledge__) not available
- Using fallback procedures as per CLAUDE.md instructions
- Environment profiler script created and functional

## Recent Activity
- Session started: {datetime.now().isoformat()}
- Environment profiling completed
- Knowledge workspace structure validated
"""
    
    docs_dir = Path('.claude/knowledge/docs')
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    with open(docs_dir / 'session_reference.md', 'w') as f:
        f.write(reference_content)

def get_git_branch():
    """Get current git branch safely"""
    try:
        result = subprocess.run(['git', 'branch', '--show-current'], 
                              capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except:
        return "unknown"

def main():
    """Main execution function"""
    print("🔍 Environment Profiler - Updating workspace intelligence...")
    
    # Gather system information
    system_info = get_system_info()
    
    # Ensure output directory exists
    docs_dir = Path('.claude/knowledge/docs')
    docs_dir.mkdir(parents=True, exist_ok=True)
    
    # Write environment profile
    profile_path = docs_dir / 'environment_profile.json'
    with open(profile_path, 'w') as f:
        json.dump(system_info, f, indent=2)
    
    print(f"✅ Environment profile saved to {profile_path}")
    
    # Update session reference
    update_session_reference()
    print("✅ Session reference updated")
    
    # Summary output
    print(f"\n📊 Environment Summary:")
    print(f"  • Working Dir: {system_info['working_directory']}")
    print(f"  • Python: {system_info['python_version'].split()[0]}")
    print(f"  • Git Branch: {system_info.get('git_branch', 'unknown')}")
    print(f"  • Platform: {system_info.get('platform', {}).get('system', 'unknown')}")
    print(f"  • Timestamp: {system_info['timestamp']}")

if __name__ == '__main__':
    main()